codeunit 10044626 "LSCNA POS Trans. Events H."
{
    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnAfterProcessRefundSelection, '', false, false)]
    local procedure UpdateTotalRefund(var POSTransaction: Record "LSC POS Transaction"; var POSTransLine: Record "LSC POS Trans. Line")
    var
        CustomerOrderMgt: Codeunit "LSCNA Customer Order Mgt.";
    begin
        CustomerOrderMgt.UpdateTotals(POSTransaction, POSTransLine);
    end;

    [Obsolete('Eventsubscriber is obsolete. From now it is Local', '25.0')]
    procedure OnAfterVoidLine(var POSTransaction: Record "LSC POS Transaction"; var POSTransLine: Record "LSC POS Trans. Line")
    begin
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnAfterVoidLine, '', false, false)]
    local procedure OnAfterVoidLine2(var POSTransaction: Record "LSC POS Transaction"; var POSTransLine: Record "LSC POS Trans. Line")
    var
        TransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        TransactionMgt.SetTaxInfoFromStore(POSTransaction, POSTransLine);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", 'OnAfterCheckMemberCardv2', '', false, false)]
    local procedure UpdateTotal(var PosTransaction: Record "LSC POS Transaction")
    var
        POSTransactionCodeunit: Codeunit "LSC POS Transaction";
    begin
        POSTransactionCodeunit.CalcTotals();
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnFindPosCommandBeforeValidateInput, '', false, false)]
    local procedure OnFindPosCommandBeforeValidateInput(PosCommand: Enum "LSC POS Command"; var IsHandled: Boolean)
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.OnFindPosCommandBeforeValidateInput(PosCommand, IsHandled);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnBeforePOSCommandCaseProcessed, '', false, false)]
    local procedure OnBeforePOSCommandCaseProcessed(POSTrans: Record "LSC POS Transaction"; POSTransLine: Record "LSC POS Trans. Line"; CurrInput: Text; POSSESSION: Codeunit "LSC POS Session"; STATE: Enum "LSC POS Transaction State"; Command: Code[20]; var Processed: Boolean)
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.OnBeforePOSCommandCaseProcessed(Command, Processed);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnAfterPOSCommandCaseProcessedV2, '', false, false)]
    local procedure OnAfterPOSCommandCaseProcessed(PosCommand: Enum "LSC POS Command"; MenuLine: Record "LSC POS Menu Line"; var TenderType: Record "LSC Tender Type"; StoreSetup: Record "LSC Store"; var Balance: Decimal; var REC: Record "LSC POS Transaction"; var Currency: Record Currency; var CardEntry: Record "LSC POS Card Entry"; var CustomerOrCardNo: Code[20]; var ReadFromMSR: Boolean; var ChangeTender: Boolean; var TrainingActive: Boolean; STATE: Enum "LSC POS Transaction State"; var PaymentAmount: Decimal; var CurrInput: Text; var gInsertTmpPayment: Boolean; var Processed: Boolean)
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.OnAfterPOSCommandCaseProcessed(PosCommand, Processed);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", ItemLineOnAfterCheckVATSetups, '', false, false)]
    local procedure ItemLineOnAfterCheckVATSetups(var POSTransaction: Record "LSC POS Transaction"; var Item: Record Item; var IsHandled: Boolean)
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.ItemLineOnAfterCheckVATSetups(POSTransaction, Item, IsHandled);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", ItemLineOnAfterEvaluateSalesIsReturnSales, '', false, false)]
    local procedure OnAfterEvaluateSalesIsReturnSales(var POSTransaction: Record "LSC POS Transaction"; var Item: Record Item; var IsHandled: Boolean)
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.ItemLineOnAfterEvaluateSalesIsReturnSales(POSTransaction, Item, IsHandled);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", 'OnBeforeEvaluateSaleIsReturnItemPhase1', '', false, false)]
    local procedure OnBeforeEvaluateSaleIsReturnItemPhase1()
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.OnBeforeEvaluateSaleIsReturnItemPhase1();
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", InsertPaymentLineOnBeforeSetAmountsMultiplyInTenderOperations, '', false, false)]
    local procedure InsertPaymentLineOnBeforeSetAmountsMultiplyInTenderOperations(TenderType: Record "LSC Tender Type"; var NewLine: Record "LSC POS Trans. Line"; PosFuncProfile: Record "LSC POS Func. Profile"; PaymentAmount: Decimal; var isHandled: Boolean)
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.InsertPaymentLineOnBeforeSetAmountsMultiplyInTenderOperations(TenderType, NewLine, PosFuncProfile, PaymentAmount, isHandled);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnBeforeInsertLineInsertPaymentLine, '', false, false)]
    local procedure OnBeforeInsertLineInsertPaymentLine(var POSTransaction: Record "LSC POS Transaction"; var POSTransLine: Record "LSC POS Trans. Line"; var CurrInput: Text; var TenderTypeCode: Code[10]; Balance: Decimal; PaymentAmount: Decimal; STATE: Code[10]; var isHandled: Boolean)
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.OnBeforeInsertLineInsertPaymentLine(POSTransLine);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnTransactionTenderedAfterInitAmounts, '', false, false)]
    local procedure OnTransactionTenderedAfterInitAmounts(var REC: Record "LSC POS Transaction"; var TenderType: Record "LSC Tender Type"; var PaymentAmount: Decimal; var ChangeTender: Boolean; var IsHandled: Boolean)
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.OnTransactionTenderedAfterInitAmounts(REC, TenderType, PaymentAmount, ChangeTender, IsHandled);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnBeforeCheckStoreVATGroupCodeIsEmpty, '', false, false)]
    local procedure OnBeforeCheckStoreVATGroupCodeIsEmpty(Store: Record "LSC Store"; var SkipVatProdPostGrpLimitationCheck: Boolean; var IsHandled: Boolean)
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.OnBeforeCheckStoreVATGroupCodeIsEmpty(Store, SkipVatProdPostGrpLimitationCheck, IsHandled);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnTenderKeyPressedExAfterInitNewLine, '', false, false)]
    local procedure OnTenderKeyPressedExAfterInitNewLine(var REC: Record "LSC POS Transaction"; var TenderType: Record "LSC Tender Type"; var IsHandled: Boolean)
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.OnTenderKeyPressedExAfterInitNewLine(REC, TenderType, IsHandled);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", 'OnBeforeRoundPaymentAmount_TenderKeyPressedEx', '', false, false)]
    local procedure OnBeforeRoundPaymentAmount_TenderKeyPressedEx(var REC: Record "LSC POS Transaction"; TenderType: Record "LSC Tender Type"; PosFuncProfile: Record "LSC POS Func. Profile"; var Balance: Decimal)
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.OnBeforeRoundPaymentAmount_TenderKeyPressedEx(REC, TenderType, PosFuncProfile, Balance);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnBeforeClearPrepaymentFromCustomer, '', false, false)]
    local procedure OnBeforeClearPrepaymentFromCustomer(Rec: Record "LSC POS Transaction"; var Customer: Record Customer; StoreSetup: Record "LSC Store")
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.OnBeforeClearPrepaymentFromCustomer(Rec, Customer, StoreSetup);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnBeforePosFuncChangeVATBusOnLinev2, '', false, false)]
    local procedure OnBeforePosFuncChangeVATBusOnLinev2(var POSTransaction: Record "LSC POS Transaction"; var Customer: Record Customer; var IsHandled: Boolean)
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.OnBeforePosFuncChangeVATBusOnLine(POSTransaction, Customer, IsHandled);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnAfterOfferPosCalcDeletAllProcessCustomer, '', false, false)]
    local procedure OnAfterOfferPosCalcDeletAllProcessCustomer(var POSTransLine2: Record "LSC POS Trans. Line")
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.OnAfterOfferPosCalcDeletAllProcessCustomer(POSTransLine2);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnBeforeInsertIncExpLineValidateAmount, '', false, false)]
    local procedure OnBeforeInsertIncExpLineValidateAmount(var NewLine: Record "LSC POS Trans. Line"; var PaymentAmount: Decimal; var IsHandled: Boolean)
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.OnBeforeInsertIncExpLineValidateAmount(NewLine, PaymentAmount, IsHandled);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnAfterCalculateAmountToDiscDiscAmountGetAmountToDiscount, '', true, false)]
    local procedure OnAfterCalculateAmountToDiscDiscAmountGetAmountToDiscount(var POSTransLine: Record "LSC POS Trans. Line"; var AmountToDisc: Decimal)
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.OnAfterCalculateAmountToDiscDiscAmountGetAmountToDiscount(POSTransLine, AmountToDisc);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnBeforeGetBalanceCalcTotals, '', true, false)]
    local procedure OnBeforeGetBalanceCalcTotals(var POSTransaction: Record "LSC POS Transaction"; var PosFuncProfile: Record "LSC POS Func. Profile"; var Balance: Decimal; var IsHandled: Boolean)
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.OnBeforeGetBalanceCalcTotals(POSTransaction, PosFuncProfile, Balance, IsHandled);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnTotalPressedBeforeDisplayTotal, '', true, false)]
    local procedure OnTotalPressedBeforeDisplayTotal(PosFuncProfile: Record "LSC POS Func. Profile"; Balance: Decimal; var IsHandled: Boolean)
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.OnTotalPressedBeforeDisplayTotal(PosFuncProfile, Balance, IsHandled);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnTotalPressedAfterSetInfoTextDescriptions, '', true, false)]
    local procedure OnTotalPressedAfterSetInfoTextDescriptions(var CustomerOrderLine_Temp: Record "LSC Customer Order Line" temporary; PosFuncProfile: Record "LSC POS Func. Profile"; var InfoTextDescription: Text; var InfoTextDescription2: Text)
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.OnTotalPressedAfterSetInfoTextDescriptions(CustomerOrderLine_Temp, PosFuncProfile, InfoTextDescription2);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnTotDiscAmPressedAfterCalcNewBalanceV2, '', true, false)]
    local procedure OnTotDiscAmPressedAfterCalcNewBalance(Rec: Record "LSC POS Transaction"; NewBalance: Decimal; var Tax: Decimal; var AmDec: Decimal)
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.OnTotDiscAmPressedAfterCalcNewBalance(Rec, NewBalance, Tax, AmDec);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnAccNoCheckOnIncExpPressed, '', true, false)]
    local procedure OnAccNoCheckOnIncExpPressed(AccNo: Code[20]; var IsHandled: Boolean)
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.OnAccNoCheckOnIncExpPressed(AccNo, IsHandled);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnBeforeStartNewTransaction, '', true, false)]
    local procedure OnBeforeStartNewTransaction()
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.OnBeforeStartNewTransaction();
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnStartNewTransactionBeforeInsertLoadCardNoInNewTrans, '', true, false)]
    local procedure OnStartNewTransactionBeforeInsertLoadCardNoInNewTrans(var POSTransaction: Record "LSC POS Transaction"; Store: Record "LSC Store")
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.OnStartNewTransactionBeforeInsertLoadCardNoInNewTrans(POSTransaction, Store);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnValidatePriceCheckAfterInitTmpLine, '', true, false)]
    local procedure OnValidatePriceCheckAfterInitTmpLine(var TmpLine: Record "LSC POS Trans. Line")
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.OnValidatePriceCheckAfterInitTmpLine(TmpLine);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnMakeRepayTransBeforeInsertLineRec, '', true, false)]
    local procedure OnMakeRepayTransBeforeInsertLineRec(var POSTransLine: Record "LSC POS Trans. Line")
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.OnMakeRepayTransBeforeInsertLineRec(POSTransLine);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnBeforeGetNewBalance, '', true, false)]
    local procedure OnBeforeGetNewBalance(PosTrLine: Record "LSC POS Trans. Line"; var NewBalance: Decimal; var IsHandled: Boolean)
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.OnBeforeGetNewBalance(PosTrLine, NewBalance, IsHandled);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnAfterUpdateMemberContextV2, '', true, false)]
    local procedure OnAfterUpdateMemberContext(POSTransaction: Record "LSC POS Transaction")
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.OnAfterUpdateMemberContext(POSTransaction);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnBeforeInsertPosTransLineBuffer, '', true, false)]
    local procedure OnAfterpPosTransLineBufferItemSet(var pPosTransLineBuffer: Record "LSC POS Trans. Line" temporary; TransSalesEntry: Record "LSC Trans. Sales Entry")
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.OnBeforeInsertPosTransLineBuffer(pPosTransLineBuffer, TransSalesEntry);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnBeforeInsertCopiedTransLine, '', false, false)]
    local procedure OnBeforeInsertCopiedTransLine(var newLine: Record "LSC POS Trans. Line"; var pPosTransLineBuffer: Record "LSC POS Trans. Line" temporary; var pSelectionBuffer: Record "LSC POS Trans. Line" temporary; var pTrans: Record "LSC Transaction Header")
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.UpdateSalesTaxAmountsOnInsertCopiedTransLine(newLine);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnBeforeInsertIncExpLine, '', true, false)]
    local procedure OnBeforeInsertIncExpLine(var NewLine: Record "LSC POS Trans. Line"; POSTransaction: Record "LSC POS Transaction"; TransIncomeExpenseEntry_L: Record "LSC Trans. Inc./Exp. Entry")
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.SetTaxDataOnInsertIncExpLine(NewLine, TransIncomeExpenseEntry_L);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnNextInfoPhase103AfterValidateInfo, '', true, false)]
    local procedure OnNextInfoPhase103AfterValidateInfo(var POSTransaction: Record "LSC POS Transaction")
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.SetWICTransaction(POSTransaction);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnAfterNextInfoPhase201, '', true, false)]
    local procedure OnAfterNextInfoPhase201(Item: Record Item; var CurrInput: Text)
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.GetTareWeight(Item, CurrInput);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnAfterGetTotalNetAmount, '', true, false)]
    local procedure OnAfterGetTotalNetAmount(var POSTransaction: Record "LSC POS Transaction"; var TotalNetAmount: Decimal)
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.GetTotalNetAmount(POSTransaction, TotalNetAmount);
    end;
}