codeunit 10015030 "LSC Staff Mgmt GDPR"
{

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Data Classification Mgt.", OnGetDataPrivacyEntities, '', true, false)]
    local procedure OnGetDataPrivacyEntities(var DataPrivacyEntities: Record "Data Privacy Entities")
    begin
        if not DataPrivacyEntities.Get(10015057) then begin
            DataPrivacyEntities.Init();
            DataPrivacyEntities."Table No." := 10015057;
            DataPrivacyEntities."Key Field No." := 1;

            DataPrivacyEntities."Default Data Sensitivity" := DataPrivacyEntities."Default Data Sensitivity"::Normal;
            DataPrivacyEntities.Include := True;
            DataPrivacyEntities."Page No." := 10015097;
            DataPrivacyEntities.Insert(true);
        end;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Data Privacy Mgmt", OnCreateData, '', true, false)]
    local procedure CreateData(EntityTypeTableNo: Integer; EntityNo: Code[50]; var PackageCode: Code[20]; ActionType: Option "Export a data subject's data","Create a data privacy configuration package"; DataSensitivityOption: Option Sensitive,Personal,"Company Confidential",Normal,Unclassified)
    var
        StaffMgmtEmployee: Record "LSC STAFF Employee";
        DataPrivacy: Codeunit "Data Privacy Mgmt";
        RecRef: RecordRef;
    begin

        if EntityTypeTableNo = Database::"LSC STAFF Employee" then begin
            RecRef.GetTable(StaffMgmtEmployee);
            DataPrivacy.CreateRelatedData(RecRef, EntityTypeTableNo, EntityNo, PackageCode, ActionType, DataSensitivityOption);
        end;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Data Privacy Mgmt", OnAfterGetPackageCode, '', true, false)]
    local procedure GetPackageCode(EntityTypeTableNo: Integer; EntityNo: Code[50]; ActionType: Option "Export a data subject's data","Create a data privacy configuration package"; var PackageCodeTemp: Code[20]; var PackageCodeKeep: Code[20])
    var
        TempEntityNumber: Code[17];
    begin

        if StrLen(EntityNo) >= 18 then
            TempEntityNumber := CopyStr(EntityNo, (StrLen(EntityNo) mod 17) + 1, (StrLen(EntityNo) - (StrLen(EntityNo) mod 17)))
        else
            TempEntityNumber := CopyStr(EntityNo, 1, StrLen(EntityNo));

        if EntityTypeTableNo = Database::"LSC STAFF Employee" then begin
            PackageCodeTemp := 'SM*' + TempEntityNumber;
            PackageCodeKeep := 'SME' + TempEntityNumber;
        end;
    end;

    [EventSubscriber(ObjectType::Page, Page::"Data Privacy Wizard", OnDrillDownForEntityNumber, '', true, false)]
    local procedure DrilldownForEntityNumber(EntityTypeTableNo: Integer; var EntityNo: Code[50])
    var
        StaffMgmtEmployee: Record "LSC STAFF Employee";
        DataPrivacyEntities: Record "Data Privacy Entities";
        EmployeeList: Page "LSC STAFF Mgt. Employee List";
        Instream: InStream;
        FilterAsText: Text;
        DataSubjectBlockedMsg: Label 'This data subject is already marked as blocked. You can export the related data.';
    begin

        if EntityTypeTableNo = Database::"LSC STAFF Employee" then begin
            if DataPrivacyEntities.Get(Database::"LSC STAFF Employee") then begin
                DataPrivacyEntities.CalcFields("Entity Filter");
                DataPrivacyEntities."Entity Filter".CreateInStream(Instream);
                Instream.ReadText(FilterAsText);
            end;

            EmployeeList.LookupMode := true;
            EmployeeList.SetTableView(StaffMgmtEmployee);
            if EmployeeList.RunModal = ACTION::LookupOK then begin
                EmployeeList.GetRecord(StaffMgmtEmployee);
                if StaffMgmtEmployee.Status = StaffMgmtEmployee.Status::Blocked then
                    Message(DataSubjectBlockedMsg);
                EntityNo := StaffMgmtEmployee."No.";
            end;
        end;
    end;

}
