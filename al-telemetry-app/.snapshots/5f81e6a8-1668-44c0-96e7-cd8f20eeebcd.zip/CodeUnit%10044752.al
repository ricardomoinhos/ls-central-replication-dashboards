codeunit 10044752 "LSCNA BOUtils" implements "LSCNA IBOUtils"
{
    Access = Internal;

    procedure UseSalesTax(pStoreNo: Code[20]): Boolean
    var
        BOUtils: Codeunit "LSC BO Utils";
    begin
        exit(BOUtils.UseSalesTax(pStoreNo));
    end;
}