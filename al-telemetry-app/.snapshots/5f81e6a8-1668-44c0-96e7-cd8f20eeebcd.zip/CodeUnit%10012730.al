codeunit 10012730 "LSC POS Ctrl Interface NODLL" implements "LSC IEPOSControl"
{
    Access = Internal;

    var
        CONTROLLIB: Codeunit "LSC POS Control Library";
        HasControlLibBeenSet: Boolean;
        _POSWebTemplateHandler: Codeunit "LSC POS Web Template Handler";
        TmpLookupIndexes: Record "LSC POS Pair Value" temporary;
        TmpDataGridIndexes: Record "LSC POS Pair Value" temporary;
        POSSession: Codeunit "LSC POS Session";
        LookupFunctions: array[64] of Codeunit "LSC POS Lookup Functions";
        DataGridFunctions: array[64] of Codeunit "LSC POS DataGrid Functions";
        ZoomFunctions: Codeunit "LSC POS Zoom Functions";
        TmpDataGridIndex: Integer;
        TmpDataGridLineNo: Integer;
        TmpIndex: Integer;
        _ShouldUseDefaults, _DefaultConfirmValue : Boolean;
        _DefaultStrMenuValue: Integer;
        _Logger: Codeunit "LSC Debug Log";

        DgFnUninitializedErr: Label 'DataGrid Functions Codeunit not initialized for Grid ID: %1';
        LookupFnUninitializedErr: Label 'LookupFunctions Codeunit not initialized for Lookup ID: %1';
        TmpLookupIndex: Integer;
        TmpLookupLineNo: Integer;
        LookupStack: array[64] of Integer;
        LookupStackIndex: Integer;
        LastLookupIndex: Integer;

    procedure SetControlLibrary(var pCONTROLLIB: Codeunit "LSC POS Control Library")
    var
        tmp: Codeunit "LSC POS Control Library";
    begin
        tmp := CONTROLLIB;
        CONTROLLIB := pCONTROLLIB;
        MergeNewContextWithContextFromTop(tmp);
    end;

    procedure SetInitialized(pInitalized: Boolean)
    begin
        CONTROLLIB.SetInitialized(pInitalized);
    end;

    procedure GetInitialized(): Boolean
    begin
        exit(CONTROLLIB.GetInitialized());
    end;

    internal procedure GetWebTemplateHandler() c: Codeunit "LSC POS Web Template Handler";
    begin
        c := _POSWebTemplateHandler; // internal
    end;

    internal procedure GetControlLibrary() c: Codeunit "LSC POS Control Library"
    begin
        c := CONTROLLIB; // internal
    end;

    procedure PreProcessEvent(var evnt: Codeunit "LSC POS Event"): Boolean
    var
        PosImageUtils: Codeunit "LSC POS Image Utils";
    begin
        case evnt.EventType of
            "LSC POS Event Type"::CALLWEBAPI:
                begin
                    case evnt.StrData of
                        '###UPDATEPOSTAGS':
                            _POSWebTemplateHandler.UpdatePosTags(evnt.StrData2);
                        '###FETCH':
                            _POSWebTemplateHandler.LoadTemplateResource(evnt.Sender(), evnt.StrData2(), evnt.IntData1, evnt.IntData2, evnt.IntData3, evnt.StrData3, evnt.StrData4);
                        else
                            _POSWebTemplateHandler.HandleTemplateEvent(evnt.Sender(), evnt.StrData(), evnt.StrData2(), evnt.StrData3(), evnt.StrData4());
                    end;
                    exit(true);
                end;
            "LSC POS Event Type"::MEDIADATA:
                begin
                    case evnt.IntData1 of
                        1:
                            PosImageUtils.GetPlaylist(evnt.StrData, CONTROLLIB);
                        else
                            PosImageUtils.GetImg(evnt.StrData, CONTROLLIB); // Note: could also debounce + collect multiple images and split + loop in AL
                    end;
                    exit(true);
                end;
        end;

        exit(CONTROLLIB.PreProcessEvent(evnt));
    end;

    procedure PostProcessEvent(var evnt: Codeunit "LSC POS Event"): Boolean
    begin
        exit(CONTROLLIB.PostProcessEvent(evnt));
    end;

    local procedure MergeNewContextWithContextFromTop(var TOPCONTROLLIB: Codeunit "LSC POS Control Library")
    var
        ctx: Codeunit "LSC POS Context";
        dict: Dictionary of [Text, Text];
    begin
        // We could stack these up and pop when a POS closes (would need to store the original CONTROLLIB too)
        // but it should be enough to just wait for "any" POS to open and overwrite the "current" CONTROLLIB
        if not HasControlLibBeenSet then begin
            TOPCONTROLLIB.GetContext(ctx);
            ctx.GetContextModel(dict);
            CONTROLLIB.UpdateContext(dict, '', true);
            HasControlLibBeenSet := true;
        end;
    end;

    procedure InitControl(var pCONTROLLIB: Codeunit "LSC POS Control Library"): Boolean
    begin
        CLEAR(_POSWebTemplateHandler);
        CLEAR(CONTROLLIB);
        SetControlLibrary(pCONTROLLIB);

        TmpLookupIndexes.Reset;
        TmpLookupIndexes.DeleteAll;
        TmpLookupIndex := 0;
        TmpLookupLineNo := 0;
        TmpLookupIndexes.SetCurrentKey(Description);

        LookupStackIndex := 0;
        LastLookupIndex := 0;
        Clear(LookupStack);

        TmpDataGridIndexes.Reset;
        TmpDataGridIndexes.DeleteAll;
        TmpDataGridIndex := 0;
        TmpDataGridLineNo := 0;
        TmpDataGridIndexes.SetCurrentKey(Description);

        SetDialogHandlerValues(false, false, 0);

        exit(true);
    end;

    procedure PosIsActive(): Boolean
    begin
        exit(CONTROLLIB.PosIsActive());
    end;

    procedure LogEvent(var pPOSEvent: Codeunit "LSC POS Event")
    begin
        _Logger.LogEvent(pPOSEvent);
    end;

    procedure LogDebug(message: Text)
    begin
        _Logger.LogDebug(message);
    end;

    procedure LogWarning(message: Text)
    begin
        _Logger.LogWarning(message);
    end;

    procedure LogTrace(message: Text)
    begin
        _Logger.LogTrace(message);
    end;

    procedure LoadPOS()
    begin
        CONTROLLIB.SetPosCtrlActiveInteraceProfile(POSSession.InterfaceProfileID, POSSession.Store."Interface Profile");
        CONTROLLIB.SetPosCtrlActiveStyle(POSSession.PosStyleID, POSSession.Store."Style Profile");
        CONTROLLIB.SetPosCtrlActiveMenuProfile(POSSession.MenuProfileID, POSSession.Store."Menu Profile");
        LoadPosContextMenus();

        CONTROLLIB.SendPosCommandEvent('_FORMLOAD', '');
    end;

    procedure LoadHardware()
    var
        HardwareProfileID: Text;
    begin
        HardwareProfileID := POSSession.HardwareProfileID;
        if HardwareProfileID = '' then
            HardwareProfileID := Format("LSC POS Profile ID"::DefaultHardware);

        UploadHardwareProfile(HardwareProfileID);
    end;

    procedure ShowTooltip(txt: Text; contentType: Integer)
    begin
        CONTROLLIB.ShowTooltip(txt, contentType);
    end;

    procedure LoadPosPanelControlsEx(pInterfaceProfileIDFilter: Text; pPanelIDFilter: Text; pMenuProfileIDFilter: Text)
    begin
        //Loads POS Panel Controls ..and loads the controls specified also
        //We Just Refresh the Panel here...
        RefreshPosPanel(pInterfaceProfileIDFilter, pPanelIDFilter, pMenuProfileIDFilter);
    end;

    procedure LoadPosContextMenus()
    begin
        CONTROLLIB.LoadPosContextMenus();
    end;

    procedure LoadScanners(HardwareProfileId: Code[20])
    var
        ProfileDevices: Record "LSC POS Hardware Profile Dev.";
        PosScanner: Record "LSC POS Scanner";
        PosScannerEntityTemp: Record "LSC POS Scanner Entity" temporary;
    begin
        ProfileDevices.SetRange("Profile ID", HardwareProfileId);
        ProfileDevices.SetRange("Device Type", ProfileDevices."Device Type"::Scanner);
        if ProfileDevices.IsEmpty then
            exit;
        ProfileDevices.FindSet();
        repeat
            if PosScanner.Get(ProfileDevices."Device ID") then begin
                PosScannerEntityTemp.TransferFields(PosScanner);
                PosScannerEntityTemp.ScannerType := PosScanner.Scanner.AsInteger();
                CONTROLLIB.AddJsonRequest('SCANNERSETUP', PosScannerEntityTemp.AsJson());
            end;
        until ProfileDevices.Next = 0;
    end;

    procedure LoadScales(HardwareProfileId: Code[20])
    var
        ProfileDevices: Record "LSC POS Hardware Profile Dev.";
        PosScale: Record "LSC POS Scale";
        PosScaleEntityTemp: Record "LSC POS Scale Entity" temporary;
    begin
        ProfileDevices.SetRange("Profile ID", HardwareProfileId);
        ProfileDevices.SetRange("Device Type", ProfileDevices."Device Type"::Scale);
        if ProfileDevices.IsEmpty then
            exit;
        ProfileDevices.FindSet();
        repeat
            if PosScale.Get(ProfileDevices."Device ID") then begin
                PosScaleEntityTemp.TransferFields(PosScale);
                PosScaleEntityTemp.WeightConversionFactor := PosScale."Weight Conversion Factor".AsInteger();
                PosScaleEntityTemp.UnitPriceConversionFactor := PosScale."Unit Price Conversion Factor".AsInteger();
                CONTROLLIB.AddJsonRequest('SCALESETUP', PosScaleEntityTemp.AsJson());
            end;
        until ProfileDevices.Next = 0;
    end;

    procedure LoadDrawers(HardwareProfileId: Code[20])
    var
        ProfileDevices: Record "LSC POS Hardware Profile Dev.";
        PosDrawer: Record "LSC POS Drawer";
        PosDrawerEntityTemp: Record "LSC POS Drawer Entity" temporary;
    begin
        ProfileDevices.SetRange("Profile ID", HardwareProfileId);
        ProfileDevices.SetRange("Device Type", ProfileDevices."Device Type"::Drawer);
        if ProfileDevices.IsEmpty then
            exit;
        ProfileDevices.FindSet();
        repeat
            if PosDrawer.Get(ProfileDevices."Device ID") then begin
                PosDrawerEntityTemp.TransferFields(PosDrawer);
                PosDrawerEntityTemp.DrawerStatus := PosDrawer."Drawer Status".AsInteger();
                PosDrawerEntityTemp.DrawerType := PosDrawer.Drawer.AsInteger();
                PosDrawerEntityTemp.DrawerAlertType := PosDrawer."Drawer Alert Type".AsInteger();
                CONTROLLIB.AddJsonRequest('DRAWERSETUP', PosDrawerEntityTemp.AsJson());
            end;
        until ProfileDevices.Next = 0;
    end;

    procedure LoadDisplays(HardwareProfileId: Code[20])
    var
        ProfileDevices: Record "LSC POS Hardware Profile Dev.";
        PosDisplay: Record "LSC POS Display";
        PosDisplayEntityTemp: Record "LSC POS Display Entity" temporary;
    begin
        ProfileDevices.SetRange("Profile ID", HardwareProfileId);
        ProfileDevices.SetRange("Device Type", ProfileDevices."Device Type"::Display);
        if ProfileDevices.IsEmpty then
            exit;
        ProfileDevices.FindSet();
        repeat
            if PosDisplay.Get(ProfileDevices."Device ID") then begin
                PosDisplayEntityTemp.TransferFields(PosDisplay);
                PosDisplayEntityTemp.DisplayType := PosDisplay.Display.AsInteger();
                CONTROLLIB.AddJsonRequest('DISPLAYSETUP', PosDisplayEntityTemp.AsJson());
            end;
        until ProfileDevices.Next = 0;
    end;

    procedure LoadMSRs(HardwareProfileId: Code[20])
    var
        ProfileDevices: Record "LSC POS Hardware Profile Dev.";
        PosMsr: Record "LSC POS MSR";
        PosMsrEntityTemp: Record "LSC POS MSR Entity" temporary;
    begin
        ProfileDevices.SetRange("Profile ID", HardwareProfileId);
        ProfileDevices.SetRange("Device Type", ProfileDevices."Device Type"::MSR);
        if ProfileDevices.IsEmpty then
            exit;
        ProfileDevices.FindSet();
        repeat
            if PosMsr.Get(ProfileDevices."Device ID") then begin
                PosMsrEntityTemp.TransferFields(PosMsr);
                PosMsrEntityTemp.DeviceName := PosMsr."MSR Device Name" + PosMsr."MSR Device Name 2";
                PosMsrEntityTemp.MsrType := PosMsr."MSR Type".AsInteger();
                CONTROLLIB.AddJsonRequest('MSRDEVICESETUP', PosMsrEntityTemp.AsJson());
            end;
        until ProfileDevices.Next = 0;
    end;

    procedure LoadProperties(HardwareProfileId: Code[20])
    var
        ProfileDevices: Record "LSC POS Hardware Profile Dev.";
        DevicePropertyProfile: Text;
        DeviceServerHost: Text;
        DeviceServerHTTPS: Boolean;
    begin
        ProfileDevices.SetRange("Profile ID", HardwareProfileId);
        ProfileDevices.SetFilter("Device ID", '<>%1', '');
        if ProfileDevices.IsEmpty then
            exit;

        ProfileDevices.FindSet();
        repeat
            DevicePropertyProfile := ProfileDevices.GetCustomPropertiesProfileID();
            if (DevicePropertyProfile <> '') then begin
                ProfileDevices.GetDeviceServerHostInfo(DeviceServerHost, DeviceServerHTTPS);
                if (DeviceServerHost <> '') then
                    LoadPropertiesFromProfileId(DevicePropertyProfile);
            end;
        until ProfileDevices.Next = 0;
    end;

    procedure LoadPropertiesFromProfileId(ProfileId: Code[20])
    var
        PosCustomProperties: Record "LSC POS Custom Prop. Line";
        PosCustomPropertiesEntityTemp: Record "LSC POS Custom Prop. Entity" temporary;
        DeviceServerHost: Text;
        DeviceServerHTTPS: Boolean;
    begin
        PosCustomProperties.SetRange("Profile ID", ProfileId);
        if PosCustomProperties.IsEmpty then
            exit;

        PosCustomProperties.FindSet();
        repeat
            PosCustomPropertiesEntityTemp.TransferFields(PosCustomProperties);
            PosCustomPropertiesEntityTemp.DeviceHost := DeviceServerHost;
            PosCustomPropertiesEntityTemp.HTTPS := DeviceServerHTTPS;
            CONTROLLIB.AddJsonRequest('PROPERTYPROFILE', PosCustomPropertiesEntityTemp.AsJson());
        until PosCustomProperties.Next = 0;
    end;

    procedure LoadSerialDevices(HardwareProfileId: Code[20])
    var
        ProfileDevices: Record "LSC POS Hardware Profile Dev.";
        PosSerialDevice: Record "LSC POS Serial Device";
        PosSerialDeviceEntityTemp: Record "LSC POS Serial Device Entity" temporary;
    begin
        ProfileDevices.SetRange("Profile ID", HardwareProfileId);
        ProfileDevices.SetRange("Device Type", ProfileDevices."Device Type"::Serial);
        if ProfileDevices.IsEmpty then
            exit;
        ProfileDevices.FindSet();
        repeat
            if PosSerialDevice.Get(ProfileDevices."Device ID") then begin
                PosSerialDeviceEntityTemp.TransferFields(PosSerialDevice);
                PosSerialDeviceEntityTemp.SerialParity := PosSerialDevice."Serial Parity".AsInteger();
                PosSerialDeviceEntityTemp.SerialStopBits := PosSerialDevice."Serial Stop Bits".AsInteger();
                PosSerialDeviceEntityTemp.SerialHandshake := PosSerialDevice."Serial Handshake".AsInteger();
                CONTROLLIB.AddJsonRequest('SERIALDEVICESETUP', PosSerialDeviceEntityTemp.AsJson());
            end;
        until ProfileDevices.Next = 0;
    end;

    procedure LoadAuthenticationDevices(HardwareProfileId: Code[20])
    var
        ProfileDevices: Record "LSC POS Hardware Profile Dev.";
        PosAuthDevice: Record "LSC POS Auth. Device";
        PosAuthDeviceEntityTemp: Record "LSC POS Auth. Device Entity" temporary;
    begin
        ProfileDevices.SetRange("Profile ID", HardwareProfileId);
        ProfileDevices.SetRange("Device Type", ProfileDevices."Device Type"::Authentication);
        if ProfileDevices.IsEmpty then
            exit;
        ProfileDevices.FindSet();
        repeat
            if PosAuthDevice.Get(ProfileDevices."Device ID") then begin
                PosAuthDeviceEntityTemp.TransferFields(PosAuthDevice);
                CONTROLLIB.AddJsonRequest('KEYLOCKSETUP', PosAuthDeviceEntityTemp.AsJson());
            end;
        until ProfileDevices.Next = 0;
    end;

    procedure LoadPrinters(HardwareProfileId: Code[20])
    var
        ProfileDevices: Record "LSC POS Hardware Profile Dev.";
        PosPrinter: Record "LSC POS Printer";
        PosPrinterEntityTemp: Record "LSC POS Printer Entity" temporary;
        Logo: Text;
    begin
        ProfileDevices.SetRange("Profile ID", HardwareProfileId);
        ProfileDevices.SetRange("Device Type", ProfileDevices."Device Type"::Printer);
        if ProfileDevices.IsEmpty then
            exit;
        ProfileDevices.FindSet();
        repeat
            if PosPrinter.Get(ProfileDevices."Device ID") then begin
                if not (PosPrinter.Printer in [PosPrinter.Printer::Windows, PosPrinter.Printer::Email, PosPrinter.Printer::"EFT-Printer", PosPrinter.Printer::"Custom-Printer"]) then begin
                    PosPrinterEntityTemp.TransferFields(PosPrinter);
                    Logo := POSSession.AddWebTemplateImage(PosPrinter.RecordId, '');
                    PosPrinterEntityTemp.LogoCode := Logo;
                    PosPrinterEntityTemp.LogoObj := Logo;
                    PosPrinterEntityTemp.PrinterType := PosPrinter.Printer.AsInteger();
                    PosPrinterEntityTemp.LogoSize := PosPrinter."Logo Size".AsInteger();
                    PosPrinterEntityTemp.LogoType := PosPrinter."Logo Type".AsInteger();
                    PosPrinterEntityTemp.LogoAlign := PosPrinter."Logo Align".AsInteger();
                    CONTROLLIB.AddJsonRequest('PRINTERSETUP', PosPrinterEntityTemp.AsJson());
                end;
            end;
        until ProfileDevices.Next = 0;
    end;

    procedure LoadRfids(HardwareProfileId: Code[20])
    var
        ProfileDevices: Record "LSC POS Hardware Profile Dev.";
        PosRfid: Record "LSC POS RFID";
        PosRfidEntityTemp: Record "LSC POS RFID Entity" temporary;
    begin
        ProfileDevices.SetRange("Profile ID", HardwareProfileId);
        ProfileDevices.SetRange("Device Type", ProfileDevices."Device Type"::RFID);
        if ProfileDevices.IsEmpty then
            exit;
        ProfileDevices.FindSet();
        repeat
            if PosRfid.Get(ProfileDevices."Device ID") then begin
                PosRfidEntityTemp.TransferFields(PosRfid);
                CONTROLLIB.AddJsonRequest('RFIDSETUP', PosRfidEntityTemp.AsJson());
            end;
        until ProfileDevices.Next = 0;
    end;

    procedure LoadLights(HardwareProfileId: Code[20])
    var
        ProfileDevices: Record "LSC POS Hardware Profile Dev.";
        PosLight: Record "LSC POS Light";
        PosLightEntityTemp: Record "LSC POS Light Entity" temporary;
    begin
        ProfileDevices.SetRange("Profile ID", HardwareProfileId);
        ProfileDevices.SetRange("Device Type", ProfileDevices."Device Type"::Light);
        if not ProfileDevices.FindSet() then
            exit;
        repeat
            if PosLight.Get(ProfileDevices."Device ID") then begin
                PosLightEntityTemp.TransferFields(PosLight);
                CONTROLLIB.AddJsonRequest('LIGHTSETUP', PosLightEntityTemp.AsJson());
            end;
        until ProfileDevices.Next = 0;
    end;

    procedure LoadDallasKeys(HardwareProfileId: Code[20])
    var
        ProfileDevices: Record "LSC POS Hardware Profile Dev.";
        PosDallasKey: Record "LSC POS Dallas Key";
        PosDallasKeyEntityTemp: Record "LSC POS Dallas Key Entity" temporary;
    begin
        ProfileDevices.SetRange("Profile ID", HardwareProfileId);
        ProfileDevices.SetRange("Device Type", ProfileDevices."Device Type"::DallasKey);
        if ProfileDevices.IsEmpty then
            exit;
        ProfileDevices.FindSet();
        repeat
            if PosDallasKey.Get(ProfileDevices."Device ID") then begin
                PosDallasKeyEntityTemp.TransferFields(PosDallasKey);
                PosDallasKeyEntityTemp.Parity := PosDallasKey.Parity.AsInteger();
                PosDallasKeyEntityTemp.Handshake := PosDallasKey."Flow Control".AsInteger();
                PosDallasKeyEntityTemp.StopBits := PosDallasKey."Stop Bits".AsInteger();
                CONTROLLIB.AddJsonRequest('DALLASKEYSETUP', PosDallasKeyEntityTemp.AsJson());
            end;
        until ProfileDevices.Next = 0;
    end;

    procedure LoadHardwareProfile(pHardwareProfileID: Code[10])
    begin
        CONTROLLIB.UpdatePOSData1(DATABASE::"LSC POS Hardware Profile", 1, pHardwareProfileID);

        LoadProperties(pHardwareProfileID);
        LoadPrinters(pHardwareProfileID);
        LoadDrawers(pHardwareProfileID);
        LoadScanners(pHardwareProfileID);
        LoadScales(pHardwareProfileID);
        LoadDisplays(pHardwareProfileID);
        LoadSerialDevices(pHardwareProfileID);
        LoadMSRs(pHardwareProfileID);
        LoadDallasKeys(pHardwareProfileID);
        LoadRfids(pHardwareProfileID);
        LoadLights(pHardwareProfileID);
        LoadAuthenticationDevices(pHardwareProfileID);
    end;

    procedure UploadHardwareProfile(pHardwareProfileID: Code[10])
    begin
        if pHardwareProfileID = '' then
            exit;

        LoadHardwareProfile(pHardwareProfileID);
        CONTROLLIB.LoadKeyCommands();
    end;

    procedure UploadMenuHeaderRec(var pTempMenuHeader: Record "LSC POS Menu Header"; pProfileIDFilter: Text; pMenuIDFilter: Text)
    var
        fltGroup: Integer;
        MenuEntities: Record "LSC POS Menu Entity" temporary;
        ControlLibServer: Codeunit "LSC Control Lib. Server";
        tmpImg: Text;
    begin
        fltGroup := pTempMenuHeader.FilterGroup();
        pTempMenuHeader.FilterGroup(2);
        pTempMenuHeader.SETFILTER("Profile ID", pProfileIDFilter);
        pTempMenuHeader.SETFILTER("Menu ID", pMenuIDFilter);
        if pTempMenuHeader.Find('-') then
            repeat
                MenuEntities.TransferFields(pTempMenuHeader, true);
                tmpImg := CONTROLLIB.GetPosImage(Enum::"LSC POS Control Type"::Menu, pTempMenuHeader."Menu ID");
                if tmpImg = '' then
                    tmpImg := ControlLibServer.GetImg(pTempMenuHeader.RecordId, CONTROLLIB);
                MenuEntities.Img := tmpImg;
                MenuEntities.Insert();
            until pTempMenuHeader.Next = 0;
        pTempMenuHeader.SETFILTER("Profile ID", '');
        pTempMenuHeader.SETFILTER("Menu ID", '');
        pTempMenuHeader.FilterGroup(fltGroup);
        CONTROLLIB.UploadMenuHeaderRec(MenuEntities);
    end;

    procedure UploadMenuLineRec(var pTempMenuLines: Record "LSC POS Menu Line"; pProfileIDFilter: Text; pMenuIDFilter: Text; pButtonKeyFilter: Text)
    var
        fltGroup: Integer;
        MenuButtonEntities: Record "LSC POS Menu Button Entity" temporary;
        ControlLibServer: Codeunit "LSC Control Lib. Server";
        PosCtrlUtils: Codeunit "LSC Pos Control Utils";
        tmpImg: Text;
    begin
        fltGroup := pTempMenuLines.FilterGroup();
        pTempMenuLines.FilterGroup(2);
        pTempMenuLines.SETFILTER("Profile ID", pProfileIDFilter);
        pTempMenuLines.SETFILTER("Menu ID", pMenuIDFilter);
        pTempMenuLines.SETFILTER("Key No.", pButtonKeyFilter);
        if pTempMenuLines.Find('-') then
            repeat
                ControlLibServer.UpdateMenuLine(pTempMenuLines);
                MenuButtonEntities.TransferFields(pTempMenuLines, true);
                tmpImg := CONTROLLIB.GetPosImage(Enum::"LSC POS Control Type"::MenuButton, PosCtrlUtils.GetTextAndNumberControlID(pTempMenuLines."Menu ID", pTempMenuLines."Key No.")); // if img already sent to ControlLib
                if tmpImg = '' then
                    tmpImg := ControlLibServer.GetImg(pTempMenuLines.RecordId, CONTROLLIB); // if temp recID matches persistant recID -> GetImg
                MenuButtonEntities.Img := tmpImg;
                MenuButtonEntities.Insert();
            until pTempMenuLines.Next = 0;
        pTempMenuLines.SETFILTER("Profile ID", '');
        pTempMenuLines.SETFILTER("Menu ID", '');
        pTempMenuLines.SETFILTER("Key No.", '');
        pTempMenuLines.FilterGroup(fltGroup);
        CONTROLLIB.UploadMenuLineRec(MenuButtonEntities);
    end;

    procedure UploadPosPanel(var pPosPanelRec: Record "LSC POS Panel"; var pPosPanelRowColumnRec: Record "LSC POS Panel Row/Column"; var pPosPanelControlRec: Record "LSC POS Panel Control Line"; pProfileIDFilter: Text; pPanelFilter: Text)
    begin
        UploadPosPanelRec(pPosPanelRec, pProfileIDFilter, pPanelFilter);
        UploadPosPanelRowColumnsRec(pPosPanelRowColumnRec, pProfileIDFilter, pPanelFilter);
        UploadPosPanelControlsRec(pPosPanelControlRec, pProfileIDFilter, pPanelFilter, false);
    end;

    procedure UploadPosPanelControlsEx(pInterfaceProfileIDFilter: Text; pPanelIDFilter: Text; pMenuProfileIDFilter: Text)
    begin
        LoadPosPanelControlsEx(pInterfaceProfileIDFilter, pPanelIDFilter, pMenuProfileIDFilter);
    end;

    procedure UploadPosPanelRec(var pPosPanelRec: Record "LSC POS Panel"; pProfileIDFilter: Text; pPanelFilter: Text)
    var
        PanelEntity: Record "LSC POS Panel Entity";
    begin
        if not pPosPanelRec.IsTemporary then //if we are not in a temp table, we need to set the filters
            if IsPanelControlFilterEmpty('UploadPosPanelRec', pProfileIDFilter, pPanelFilter) then
                exit;

        if pProfileIDFilter <> '' then
            pPosPanelRec.SetFilter("Interface Profile ID", pProfileIDFilter);

        if pPanelFilter <> '' then
            pPosPanelRec.SetFilter("Control ID", pPanelFilter);

        if pPosPanelRec.Find('-') then begin
            repeat
                PanelEntity.Init();
                PanelEntity.TransferFields(pPosPanelRec, false);
                PanelEntity.ControlID := pPosPanelRec."Control ID";
                PanelEntity.ProfileID := pPosPanelRec."Interface Profile ID";
                if not PanelEntity.Insert() then
                    PanelEntity.Modify();
            until pPosPanelRec.Next = 0;

            CONTROLLIB.UploadPosPanelRec(PanelEntity);
        end;
    end;

    procedure UploadPosPanelRowColumnsRec(var pPosPanelRowColumnRec: Record "LSC POS Panel Row/Column"; pProfileIDFilter: Text; pPanelFilter: Text)
    var
        PanelRowColumnEntity: Record "LSC POS Panel RowColumn Entity";
    begin
        if not pPosPanelRowColumnRec.IsTemporary then //if we are not in a temp table, we need to set the filters
            if IsPanelControlFilterEmpty('UploadPosPanelRowColumnsRec', pProfileIDFilter, pPanelFilter) then
                exit;

        if pProfileIDFilter <> '' then
            pPosPanelRowColumnRec.SetFilter("Interface Profile ID", pProfileIDFilter);

        if pPanelFilter <> '' then
            pPosPanelRowColumnRec.SetFilter("Panel Control ID", pPanelFilter);

        if pPosPanelRowColumnRec.Find('-') then begin
            repeat
                PanelRowColumnEntity.Init();
                PanelRowColumnEntity.TransferFields(pPosPanelRowColumnRec, true);
                if not PanelRowColumnEntity.Insert() then
                    PanelRowColumnEntity.Modify();
            until pPosPanelRowColumnRec.Next = 0;

            CONTROLLIB.UploadPosPanelRowColumnsRec(PanelRowColumnEntity);
        end;
    end;

    procedure UploadPosPanelControlsRec(var pPosPanelControlRec: Record "LSC POS Panel Control Line"; pProfileIDFilter: Text; pPanelFilter: Text; pMerge: Boolean)
    var
        PanelControlEntity: Record "LSC POS Panel Ctrl Line Entity";
    begin
        if not pPosPanelControlRec.IsTemporary then //if we are not in a temp table, we need to set the filters
            if IsPanelControlFilterEmpty('UploadPosPanelControlsRec', pProfileIDFilter, pPanelFilter) then
                exit;

        if pProfileIDFilter <> '' then
            pPosPanelControlRec.SetFilter("Interface Profile ID", pProfileIDFilter);

        if pPanelFilter <> '' then
            pPosPanelControlRec.SetFilter("Panel Control ID", pPanelFilter);

        if pPosPanelControlRec.Find('-') then begin
            repeat
                PanelControlEntity.Init();
                PanelControlEntity.TransferFields(pPosPanelControlRec, true);
                if not PanelControlEntity.Insert() then
                    PanelControlEntity.Modify();
            until pPosPanelControlRec.Next = 0;

            CONTROLLIB.UploadPosPanelControlsRec(PanelControlEntity, pMerge);
        end;
    end;

    local procedure IsPanelControlFilterEmpty(pFunctionName: Text; pProfileIDFilter: Text; pPanelFilter: Text): Boolean
    var
        ProfileFilterEmpty: Label '%1: Interface Profile ID filter is empty. No records will be uploaded.';
        PanelFilterEmpty: Label '%1: Panel ID filter is empty. No records will be uploaded.';
    begin
        if pProfileIDFilter = '' then begin
            LogWarning(StrSubstNo(ProfileFilterEmpty, pFunctionName));
            exit(true);
        end;

        if pPanelFilter = '' then begin
            LogWarning(StrSubstNo(PanelFilterEmpty, pFunctionName));
            exit(true);
        end;

        exit(false);
    end;

    procedure ActiveDataGrid(): Code[20]
    begin
        exit(CONTROLLIB.GetActiveDataGrid())
    end;

    procedure DataGridMarkedCountChanged(pDataGridID: Code[20]; pMarkCount: Integer)
    begin
        if CopyStr(SelectStr(1, pDataGridID), 1, StrLen(Format("LSC POS Data Grid Id"::"#LOOKUPGRIDFILTER"))) = Format("LSC POS Data Grid Id"::"#LOOKUPGRIDFILTER") then begin
            if LookupStackIndex > 0 then
                LookupFunctions[LookupStack[LookupStackIndex]].ProcessFilterGridPressed(pDataGridID, pMarkCount);
        end;
    end;

    procedure ShowPanel(pPanelID: Code[20])
    begin
        CONTROLLIB.ShowPanel(pPanelID);
    end;

    procedure ShowPanelModal(pPanelID: Code[20]; pPayload: Text)
    begin
        CONTROLLIB.ShowPanelModal(pPanelID, pPayload);
    end;

    procedure ShowMenu(pMenuID: Code[20]; pButtonPadID: Code[20])
    begin
        CONTROLLIB.ShowMenu(pMenuID, pButtonPadID);
    end;

    procedure StackMenu(pMenuID: Code[20]; pButtonPadID: Code[20])
    begin
        CONTROLLIB.StackMenu(pMenuID, pButtonPadID);
    end;

    procedure PopMenu(pButtonPadID: Code[20])
    begin
        CONTROLLIB.PopMenu(pButtonPadID);
    end;

    procedure ShowControl(pPanelID: Code[20]; pColumn: Integer; pRow: Integer; pColumnSpan: Integer; pRowSpan: Integer; pControlType: Enum "LSC POS Control Type"; pControlID: Text)
    begin
        CONTROLLIB.ShowControl(pPanelID, pColumn, pRow, pColumnSpan, pRowSpan, pControlType, pControlID);
    end;

    procedure HideControl(pControlType: Enum "LSC POS Control Type"; pControlID: Text)
    begin
        CONTROLLIB.HideControl(pControlType, pControlID);
    end;

    procedure PopupMenu(pMenu: Code[20])
    begin
        CONTROLLIB.PopupMenu(pMenu);
    end;

    procedure SetInputText(pInputID: Code[20]; pInputText: Text)
    begin
        CONTROLLIB.SetInputText(pInputID, pInputText);
    end;

    procedure GetInputText(pInputID: Code[20]): Text
    begin
        exit(CONTROLLIB.GetInputText(pInputID));
    end;

    procedure HidePanel(pPanelID: Text; pDialogResultOK: Boolean)
    begin
        CONTROLLIB.HidePanel(pPanelID, pDialogResultOK);
    end;

    procedure ActivateInput(pInputID: Code[20])
    begin
        CONTROLLIB.ActivateInput(pInputID);
    end;

    procedure Lookup(var LookupSetup: Record "LSC POS Lookup"; "Filter": Code[29]; var PosTransLine: Record "LSC POS Trans. Line"; MgrKey: Boolean; CustomerNo: Code[20]; var pRecRef: RecordRef; var pFlowFieldBuffer: Record "LSC FlowField Buffer" temporary): Boolean
    var
        LookupIndex: Integer;
        retval: Boolean;
    begin
        TmpLookupIndexes.SetRange(Description, LookupSetup."Lookup ID");
        if TmpLookupIndexes.IsEmpty then begin
            //Lookup codeunit has not been initialized for this lookup
            TmpLookupIndex += 1;
            TmpLookupIndexes.Description := LookupSetup."Lookup ID";
            TmpLookupIndexes."Integer Value" := TmpLookupIndex;
            TmpLookupLineNo += 1;
            TmpLookupIndexes."Line No." := TmpLookupLineNo;
            TmpLookupIndexes.Insert;
            LookupIndex := TmpLookupIndex;
        end
        else begin
            TmpLookupIndexes.FindFirst;
            LookupIndex := TmpLookupIndexes."Integer Value";  //Use the existing (initialized) codeunit
        end;

        if LookupStackIndex > 0 then
            LookupFunctions[LookupStack[LookupStackIndex]].SaveState();

        LookupStackIndex += 1;
        LookupStack[LookupStackIndex] := LookupIndex;

        LookupFunctions[LookupIndex].Lookup(LookupSetup, Filter, PosTransLine, MgrKey, CustomerNo, pRecRef, '', '', '', pFlowFieldBuffer);

        exit(retval);
    end;

    procedure LookupDataRequest(gridID: Text; lookupID: Text; fromPage: Integer; pageCount: Integer; pageSize: Integer; sortColumn: Integer; sortAscending: Boolean; filterString: Text): Boolean
    begin
        if LookupStackIndex > 0 then
            exit(LookupFunctions[LookupStack[LookupStackIndex]].LookupDataRequest(gridID, lookupID, fromPage, pageCount, pageSize, sortColumn, sortAscending, filterString));
    end;

    procedure LookupDataFind(pGridId: Code[20]; pLookupID: Code[20]; pFindText: Text): Boolean
    begin
        if LookupStackIndex > 0 then
            exit(LookupFunctions[LookupStack[LookupStackIndex]].LookupDataFind(pGridId, pLookupID, pFindText));
    end;

    procedure SetLookupAssistValue(pValue: Text)
    begin
        CONTROLLIB.SetLookupAssistValue(pValue);
    end;

    procedure InitDataGridControl(gridID: Text; dataTableID: Text)
    var
        DataTableSetup: Record "LSC POS Data Table";
        DummyPosTransLine: Record "LSC POS Trans. Line";
        DummyRecRef: RecordRef;
        DummyFlowFieldBuffer: Record "LSC FlowField Buffer" temporary;
    begin
        TmpDataGridIndexes.SetRange(Description, gridID);
        if TmpDataGridIndexes.IsEmpty then begin
            TmpDataGridIndex += 1;
            TmpDataGridIndexes.Description := gridID;
            TmpDataGridIndexes."Integer Value" := TmpDataGridIndex;
            TmpDataGridLineNo += 1;
            TmpDataGridIndexes."Line No." := TmpDataGridLineNo;
            TmpDataGridIndexes.Insert;
            TmpIndex := TmpDataGridIndex;
        end
        else begin
            TmpDataGridIndexes.FindFirst;
            TmpIndex := TmpDataGridIndexes."Integer Value";  //Use the existing (initialized) codeunit
        end;

        DataTableSetup.Get(dataTableID);
        DataGridFunctions[TmpIndex].InitDataGrid(DataTableSetup, gridID, DummyRecRef, DummyPosTransLine, '', DummyFlowFieldBuffer);
    end;

    procedure InitDataGridControlEx(gridID: Text; dataTableID: Text; var recRef: RecordRef)
    var
        DataTableSetup: Record "LSC POS Data Table";
        DataTableColumns: Record "LSC POS Data Table Columns";
    begin
        //InitDataGridControlEx
        DataTableSetup.Get(dataTableID);

        DataTableColumns.Reset;
        DataTableColumns.SetRange("Data Table ID", DataTableSetup."Data Table ID");
        DataTableColumns.SetRange("Table No.", DataTableSetup."Table No.");

        InitDataGridControlDyn(gridID, DataTableSetup, DataTableColumns, recRef);
    end;

    procedure InitDataGridControlDyn(pGridID: Text; var pDataTableSetup: Record "LSC POS Data Table"; var pDataTableColumns: Record "LSC POS Data Table Columns"; var precRef: RecordRef)
    var
        DummyPosTransLine: Record "LSC POS Trans. Line";
        DummyFlowFieldBuffer: Record "LSC FlowField Buffer" temporary;
    begin
        //InitDataGridControlDyn
        TmpDataGridIndexes.SetRange(Description, pGridID);
        if TmpDataGridIndexes.IsEmpty then begin
            TmpDataGridIndex += 1;
            TmpDataGridIndexes.Description := pGridID;
            TmpDataGridIndexes."Integer Value" := TmpDataGridIndex;
            TmpDataGridLineNo += 1;
            TmpDataGridIndexes."Line No." := TmpDataGridLineNo;
            TmpDataGridIndexes.Insert;
            TmpIndex := TmpDataGridIndex;
        end
        else begin
            TmpDataGridIndexes.FindFirst;
            TmpIndex := TmpDataGridIndexes."Integer Value";  //Use the existing (initialized) codeunit
        end;

        DataGridFunctions[TmpIndex].InitDyn(pDataTableSetup, pDataTableColumns, pGridID, precRef, DummyPosTransLine, '', DummyFlowFieldBuffer);
    end;

    procedure DataRequest(gridID: Code[20]; dataTableID: Code[20]; fromPage: Integer; pageCount: Integer; pageSize: Integer; sortColumn: Integer; sortAscending: Boolean; filterString: Text): Boolean
    begin
        TmpDataGridIndexes.SetRange(Description, gridID);
        if not TmpDataGridIndexes.FindFirst then begin
            if fromPage = -1 then //begin
                InitDataGridControl(gridID, dataTableID);
            //exit;
            //end;
            exit;
        end;

        TmpIndex := TmpDataGridIndexes."Integer Value";  //Use the existing (initialized) codeunit

        if DataGridFunctions[TmpIndex].DataTableID() <> dataTableID then begin
            InitDataGridControl(gridID, dataTableID);
            exit;
        end;

        exit(DataGridFunctions[TmpIndex].DataRequest(gridID, dataTableID, fromPage, pageCount, pageSize, sortColumn, sortAscending, filterString));
    end;

    procedure DataFind(pGridId: Code[20]; pDataTableID: Code[10]; pFindText: Text): Boolean
    begin
        TmpDataGridIndexes.SetRange(Description, pGridId);
        if not TmpDataGridIndexes.FindFirst then begin
            PosMessage(StrSubstNo(DgFnUninitializedErr, pGridId));
            exit;
        end;

        TmpIndex := TmpDataGridIndexes."Integer Value";  //Use the existing (initialized) codeunit

        exit(DataGridFunctions[TmpIndex].DataFind(pGridId, pDataTableID, pFindText));
    end;

    procedure GetDataGridRowIndex(pDataGridID: Text): Integer
    begin
        exit(CONTROLLIB.GetDataGridCurrentRowIndex(pDataGridID));
    end;

    procedure GetDataGridColumnIndex(pDataGridID: Text): Integer
    begin
        exit(CONTROLLIB.GetDataGridCurrentColumnIndex(pDataGridID));
    end;

    procedure GetGridDataTableID(pDataGridID: Text): Text
    begin
        exit(CONTROLLIB.GetGridDataTableID(pDataGridID));
    end;

    procedure GetLookupCommand(pLookupID: Code[20]): Code[20]
    var
        LocalLookupIndex: Integer;
    begin
        TmpLookupIndexes.SetRange(Description, pLookupID);
        if not TmpLookupIndexes.FindFirst then begin
            PosMessage(StrSubstNo(LookupFnUninitializedErr, pLookupID));
            exit;
        end;

        LocalLookupIndex := TmpLookupIndexes."Integer Value";  //Use the existing (initialized) codeunit

        exit(LookupFunctions[LocalLookupIndex].GetLookupCommand);
    end;

    procedure GetLookupKeyValue(pLookupID: Code[20]): Code[60]
    var
        LocalLookupIndex: Integer;
    begin
        TmpLookupIndexes.SetRange(Description, pLookupID);
        if not TmpLookupIndexes.FindFirst then begin
            PosMessage(StrSubstNo(LookupFnUninitializedErr, pLookupID));
            exit;
        end;

        LocalLookupIndex := TmpLookupIndexes."Integer Value";  //Use the existing (initialized) codeunit

        exit(LookupFunctions[LocalLookupIndex].GetLookupKeyValue);
    end;

    procedure GetLookupActiveRecordID(pLookupID: Code[20]; var pRecordID: RecordID): Boolean
    var
        LocalLookupIndex: Integer;
    begin
        TmpLookupIndexes.SetRange(Description, pLookupID);
        if not TmpLookupIndexes.FindFirst then begin
            PosMessage(StrSubstNo(LookupFnUninitializedErr, pLookupID));
            exit;
        end;

        LocalLookupIndex := TmpLookupIndexes."Integer Value";  //Use the existing (initialized) codeunit

        exit(LookupFunctions[LocalLookupIndex].GetActiveRecordID(pRecordID));
    end;

    procedure GetLookupMarkedRecords(pLookupID: Code[20]; var pRecordIDStringArray: JsonArray; pRemoveMarks: Boolean)
    var
        LocalLookupIndex: Integer;
    begin
        TmpLookupIndexes.SetRange(Description, pLookupID);
        if not TmpLookupIndexes.FindFirst then begin
            PosMessage(StrSubstNo(LookupFnUninitializedErr, pLookupID));
            exit;
        end;

        LocalLookupIndex := TmpLookupIndexes."Integer Value";  //Use the existing (initialized) codeunit

        CONTROLLIB.GetDataGridMarkedRecords(LookupFunctions[LocalLookupIndex].GetDataGridID(), pRecordIDStringArray, pRemoveMarks);
    end;

    procedure PosConfirm(Txt: Text; YesDefault: Boolean): Boolean
    begin
        if ShouldPreventDialogs() then
            exit(_DefaultConfirmValue);
        Commit;
        exit(Dialog.Confirm(Txt, YesDefault));
    end;

    procedure PosMessage(Txt: Text): Boolean
    begin
        LogDebug(StrSubstNo('**PosMessage: Text: %1', Txt));
        if ShouldPreventDialogs() then
            exit(true);
        Dialog.Message(Txt);
        exit(true);
    end;

    local procedure ShouldPreventDialogs(): Boolean
    begin
        if _ShouldUseDefaults then
            exit(true);
        if not System.GuiAllowed() then begin
            LogDebug('ShouldPreventDialogs: Gui not allowed and defaults aren''t set, this would normally cause a runtime error');
            exit(true);
        end;
    end;

    procedure SetDialogHandlerValues(ShouldUseDefaults: Boolean; DefaultConfirmValue: Boolean; DefaultStrMenuValue: Integer)
    begin
        _ShouldUseDefaults := ShouldUseDefaults;
        _DefaultConfirmValue := DefaultConfirmValue;
        _DefaultStrMenuValue := DefaultStrMenuValue;
    end;

    procedure OpenNumericKeyboard(Caption: Text; DefaultValue: Text; payload: Text)
    begin
        //OpenNumericKeyboard
        SetButtonCaption(Format("LSC POS Menu Id"::"#NUMPADTITL"), 1, "LSC Button Caption Type"::MainText, Caption);
        SetInputText(Format("LSC POS Input Control Id"::"#NUMPADINPUT"), DefaultValue);
        ShowPanelModal(Format("LSC POS Panel Id"::"#NUMPAD"), payload);
    end;

    procedure OpenAlphabeticKeyboard(Caption: Text; DefaultValue: Text; UsePasswordChar: Boolean; Payload: Text; Maxlength: Integer)
    begin
        //CONTROLLIB.ShowAlphabeticKeyboardExe(Caption, DefaultValue, UsePasswordChar, Payload, Maxlength);
        if UsePasswordChar then
            CONTROLLIB.SetInputPasswordChar(Format("LSC POS Input Control Id"::"#KEYBOARDINPUT"), '*')
        else
            CONTROLLIB.SetInputPasswordChar(Format("LSC POS Input Control Id"::"#KEYBOARDINPUT"), '');

        CONTROLLIB.SetInputPrompt(Format("LSC POS Input Control Id"::"#KEYBOARDINPUT"), Caption);
        CONTROLLIB.SetInputMaxLength(Format("LSC POS Input Control Id"::"#KEYBOARDINPUT"), Maxlength);
        CONTROLLIB.SetInputText(Format("LSC POS Input Control Id"::"#KEYBOARDINPUT"), DefaultValue);

        CONTROLLIB.ShowPanelModal(Format("LSC POS Panel Id"::"#KEYBOARD"), Payload);
    end;

    procedure OpenCalendar(Caption: Text[50]; DefaultValue: DateTime; payload: Text)
    begin
        SetValue("LSC POS Tag"::DTPCAPTION, Caption);
        CONTROLLIB.SendPosCommandEvent(Format("LSC POS Command"::DTP_RESET), Format(DefaultValue, 0, 9));
        ShowPanelModal(Format("LSC POS Panel Id"::"#CALENDAR"), payload);
    end;

    procedure GetSelectedDate(): DateTime
    begin
        EXIT(CONTROLLIB.GetSelectedDate);
    end;

    procedure SetSelectedDate(DateTimeIn: DateTime)
    begin
        CONTROLLIB.SetSelectedDate(DateTimeIn);
    end;

    procedure ActivePanel(): Code[20]
    begin
        exit(CONTROLLIB.ActivePanelID);
    end;

    procedure Print(var pPrintBufferRecRef: RecordRef): Boolean
    var
        pErrorText: Text;
    begin
        PrintEx('', pPrintBufferRecRef, pErrorText, true, '');
    end;

    procedure PrintEx(pPrinterID: Text; var pPrintBufferRecRef: RecordRef; var pErrorText: Text; pShowDialog: Boolean; pPrintJobID: Text): Boolean
    var
        PrintDialog: Page "LSC POS Print Dialog";
        PrintResult: Action;
    begin
        PrintDialog.SetPrintInfo(pPrinterID, pPrintJobID, pPrintBufferRecRef);
        Commit();
        PrintResult := PrintDialog.RunModal();
        pErrorText := PrintDialog.GetErrorMessage();
        exit(PrintDialog.GetPrintResult);
    end;

    procedure OpenDrawer(deviceID: Text; SuppressAlerts: Boolean; RunDialog: Boolean): Boolean
    var
        DrawerDialog: Page "LSC POS Drawer Dialog";
    begin
        if RunDialog then begin
            DrawerDialog.SetDrawerId(deviceID);
            Commit();
            DrawerDialog.RunModal();
        end else begin
            if SuppressAlerts then
                CONTROLLIB.SendPOSCommandEvent('_DM_DR_OPEN_NOALERT', deviceID)
            else
                CONTROLLIB.SendPOSCommandEvent('_DM_DR_OPEN', deviceID);
        end;
        exit(true);
    end;

    procedure ClearLineDisplay(deviceID: Text[20]): Boolean
    begin
        CONTROLLIB.SendPOSCommandEvent('_DM_LD_CLEAR', deviceID);
        exit(true);
    end;

    local procedure DisplayText(jObj: JsonObject)
    var
        jArr: JsonArray;
    begin
        jArr.Add(jObj);
        CONTROLLIB.SendPOSCommandEvent('_DM_LD_DISPLAY_TEXT', Format(jArr));
    end;

    procedure DisplayTextAt(deviceID: Text[20]; row: Integer; column: Integer; text: Text[30]; attribute: Integer): Boolean
    var
        jObj: JsonObject;
    begin
        jObj.Add('i', deviceID);
        jObj.Add('r', row);
        jObj.Add('c', column);
        jObj.Add('t1', text);
        jObj.Add('a', attribute);
        DisplayText(jObj);
        exit(true);
    end;

    procedure DisplayText(deviceID: Text[20]; text: Text[30]; attribute: Integer): Boolean
    var
        jObj: JsonObject;
    begin
        jObj.Add('i', deviceID);
        jObj.Add('t1', text);
        // jObj.Add('a', attribute); // not used...
        DisplayText(jObj);
        exit(true);
    end;

    procedure DisplayTextEx(deviceID: Text[20]; text1: Text; text2: Text; attribute: Integer): Boolean
    var
        jObj: JsonObject;
    begin
        jObj.Add('i', deviceID);
        jObj.Add('t1', text1);
        jObj.Add('t2', text2);
        // jObj.Add('a', attribute); // not used...
        DisplayText(jObj);
        exit(true);
    end;

    procedure DirectIO(hwstHost: Text; hwstHttps: Boolean; deviceType: Enum "LSC Hardware Profile Devices"; deviceID: Text; command: Integer; data: Integer; stringData: Text; payload: Text)
    var
        jArr: JsonArray;
        jObj: JsonObject;
    begin
        jObj.Add('host', hwstHost);
        jObj.Add('https', hwstHttps);
        jObj.Add('deviceType', Format(deviceType));
        jObj.Add('deviceID', deviceID);
        jObj.Add('command', command);
        jObj.Add('data', data);
        jObj.Add('stringData', stringData);
        jObj.Add('payload', payload);

        jArr.Add(jObj);
        CONTROLLIB.SendPOSCommandEvent('_DM_DIRECTIO', Format(jArr));
    end;

    procedure PostEvent(pValue1: Text; pValue2: Text; pValue3: Text; pValue4: Text)
    begin
        if pValue1 = 'RUNCOMMAND' then
            CONTROLLIB.SendPOSCommandEvent(pValue2, pValue3, pValue4);
    end;

    procedure UpdateSessionPermissions()
    begin
        CONTROLLIB.UpdateMenuPermissions();
    end;

    procedure UpdateTagExpressions(var dict: Dictionary of [Text, Text])
    begin
        CONTROLLIB.UpdateTagExpressions(dict);
    end;

    procedure UpdatePOSContext(var pContextModel: Dictionary of [Text, Text]; pTag: Text)
    begin
        CONTROLLIB.UpdateContext(pContextModel, pTag, false);
    end;

    procedure SetValue(pKey: Text; pValue: Text) oldValue: Text
    begin
        oldValue := CONTROLLIB.SetValue(pKey, pValue);
    end;

    procedure SetValue(pKey: Enum "LSC POS Tag"; pValue: Text) oldValue: Text
    begin
        oldValue := SetValue(format(pKey), pValue);
    end;

    procedure GetValue(pKey: Text): Text
    begin
        exit(CONTROLLIB.GetValue(pKey));
    end;

    procedure GetValue(pKey: Enum "LSC POS Tag"): Text
    begin
        exit(GetValue(format(pKey)));
    end;

    procedure DeleteContextByTag(pTag: Text)
    begin
        CONTROLLIB.ClearByTag(pTag);
    end;

    procedure SetButtonCaption(menuID: Code[20]; buttonNo: Integer; captionNo: Enum "LSC Button Caption Type"; newValue: Text)
    begin
        CONTROLLIB.SetButtonCaption(menuID, buttonNo, captionNo, newValue);
    end;

    procedure GetButtonCaption(menuID: Code[20]; buttonNo: Integer; captionNo: Enum "LSC Button Caption Type"): Text
    begin
        exit(CONTROLLIB.GetButtonCaption(menuID, buttonNo, captionNo));
    end;

    procedure SetButtonEnabled(menuID: Code[20]; buttonNo: Integer; newValue: Boolean)
    begin
        CONTROLLIB.SetButtonEnabled(menuID, buttonNo, newValue);
    end;

    procedure SetButtonHighlighted(menuID: Code[20]; buttonNo: Integer; newValue: Boolean)
    begin
        CONTROLLIB.SetButtonHighlighted(menuID, buttonNo, newValue);
    end;

    procedure RefreshMenu(pMenuProfileID: Code[10]; pMenuID: Code[20])
    var
        Menu: Record "LSC POS Menu Header";
        MenuLine: Record "LSC POS Menu Line";
        MenuEntity: Record "LSC POS Menu Entity" temporary;
        ControlLibServer: Codeunit "LSC Control Lib. Server";
        tmpImg, tmpPosition : Text;
    begin
        if Menu.Get(pMenuProfileID, pMenuID) then begin
            MenuEntity.TransferFields(Menu, true);
            tmpPosition := CONTROLLIB.GetMenuPosition(pMenuID);
            tmpImg := CONTROLLIB.GetPosImage(Enum::"LSC POS Control Type"::Menu, Menu."Menu ID");
            if tmpImg = '' then
                tmpImg := ControlLibServer.GetImg(Menu.RecordId, CONTROLLIB);
            MenuEntity.Img := tmpImg;
            MenuEntity.Insert();
            CONTROLLIB.UploadMenuHeaderRec(MenuEntity);
            CONTROLLIB.SetMenuPosition(pMenuID, tmpPosition);

            UploadMenuLineRec(MenuLine, pMenuProfileID, pMenuID, '');
        end;

        CONTROLLIB.RefreshMenu(pMenuID);
    end;

    procedure RefreshMenuButton(pMenuProfileID: Code[10]; pMenuID: Code[20]; pButtonNo: Integer)
    var
        MenuLineRec: Record "LSC POS Menu Line";
        MenuButtonEntityRec: Record "LSC POS Menu Button Entity" temporary;
        ControlLibServer: Codeunit "LSC Control Lib. Server";
        PosCtrlUtils: Codeunit "LSC Pos Control Utils";
        tmpImg: Text;
    begin
        if MenuLineRec.Get(pMenuProfileID, pMenuID, pButtonNo) then begin
            ControlLibServer.UpdateMenuLine(MenuLineRec);
            MenuButtonEntityRec.TransferFields(MenuLineRec, true);
            tmpImg := CONTROLLIB.GetPosImage(Enum::"LSC POS Control Type"::MenuButton, PosCtrlUtils.GetTextAndNumberControlID(MenuLineRec."Menu ID", MenuLineRec."Key No."));
            if tmpImg = '' then
                tmpImg := ControlLibServer.GetImg(MenuLineRec.RecordId, CONTROLLIB);
            MenuButtonEntityRec.Img := tmpImg;
            MenuButtonEntityRec.Insert();
            CONTROLLIB.UploadMenuLineRec(MenuButtonEntityRec);
        end;
        CONTROLLIB.RefreshMenuButton(pMenuID, pButtonNo);
    end;

    procedure RefreshPosInput(pInterfaceProfileID: Code[10]; pInputID: Code[20])
    begin
        CONTROLLIB.RefreshControl("LSC POS Control Type"::Input, pInputID, true);
    end;

    procedure RefreshPosPanel(pInterfaceProfileID: Text; pPanelID: Text; pMenuProfileID: Text)
    begin
        CONTROLLIB.RefreshPanel(pPanelID);
    end;

    procedure RefreshHardwareProfile(pHardwareProfileID: Code[10])
    begin
        LoadHardwareProfile(pHardwareProfileID);
    end;

    procedure RefreshDataGridControl(pInterfaceProfileID: Code[10]; pGridID: Code[20])
    begin
        CONTROLLIB.RefreshDataGrid(pGridID);
    end;

    procedure RefreshPosPanels(pInterfaceProfileIDFilter: Text; pPanelIDFilter: Text)
    var
        Panel: Record "LSC POS Panel";
    begin
        Panel.SetFilter("Interface Profile ID", pInterfaceProfileIDFilter);
        Panel.SetFilter("Control ID", pPanelIDFilter);
        if Panel.Find('-') then
            repeat
                RefreshPosPanel(Panel."Interface Profile ID", Panel."Control ID", POSSession.MenuProfileID);
            until Panel.Next = 0;
    end;

    procedure RefreshInterfaceProfile(InterfaceProfileID: Text)
    begin
        CONTROLLIB.RefreshInterfaceProfile();
        CONTROLLIB.LoadPosContextMenus();
    end;

    procedure RefreshMenuProfile(MenuProfileID: Text)
    begin
        if not CONTROLLIB.PosIsActive then
            exit;
        CONTROLLIB.RefreshMenuProfile();
    end;

    procedure RefreshStyleProfile(StyleProfileID: Text)
    begin
        if not CONTROLLIB.PosIsActive then
            exit;

        CONTROLLIB.RefreshStyleProfile();
    end;

    procedure RefreshProfiles()
    begin
        POSSession.SetStore(POSSession.StoreNo);
        POSSession.SetTerminal(POSSession.TerminalNo);
        POSSession.SetStaff(POSSession.StaffID);

        RefreshStyleProfile(POSSession.PosStyleID);
        RefreshInterfaceProfile(POSSession.InterfaceProfileID);
        //RefreshMenuProfile(POSSession.MenuProfileID);
    end;

    procedure DeleteMenuButton(pMenuProfileID: Code[10]; pMenuID: Code[20]; pButtonNo: Integer)
    begin
        if not CONTROLLIB.PosIsActive then
            exit;

        CONTROLLIB.DeleteMenuButton(pMenuID, pButtonNo, true);
    end;

    procedure WriteToSerialPortDevice(deviceID: Text[20]; stringToWrite: Text): Boolean
    var
        jArr: JsonArray;
    begin
        jArr.Add(deviceID);
        jArr.Add(stringToWrite);
        CONTROLLIB.SendPOSCommandEvent('_DM_SR_WRITE', Format(jArr));
        exit(true);
    end;

    procedure CheckPrinterHealth(): Boolean
    begin
        exit(POSSession.HardwareProfile().DeviceIsActive("LSC Hardware Profile Devices"::Printer));
    end;

    procedure Sound(numberOfCycles: Integer; interSoundWait: Integer): Boolean
    begin
        CONTROLLIB.SendPosCommandEvent('PLAY_SOUND', StrSubstNo('%1|%2', numberOfCycles, interSoundWait));
        exit(true);
    end;

    procedure SoundImmediate(): Boolean
    begin
        exit(Sound(0, 0));
    end;

    procedure GetActiveLookupID(): Code[20]
    begin
        if LookupStackIndex > 0 then
            exit(LookupFunctions[LookupStack[LookupStackIndex]].GetLookupID);
    end;

    procedure GetActiveOrLastLookupID(): Code[20]
    begin
        if LookupStackIndex > 0 then
            exit(LookupFunctions[LookupStack[LookupStackIndex]].GetLookupID);
        if LastLookupIndex > 0 then
            exit(LookupFunctions[LastLookupIndex].GetLookupID);
    end;

    procedure GetActiveLookupKeyValue(): Code[60]
    begin
        if LookupStackIndex > 0 then
            exit(LookupFunctions[LookupStack[LookupStackIndex]].GetActiveKeyValue());
        if LastLookupIndex > 0 then
            exit(LookupFunctions[LastLookupIndex].GetActiveKeyValue());
    end;

    procedure GetActiveLookupRecordID(var pRecordID: RecordID): Boolean
    begin
        if LookupStackIndex > 0 then
            exit(LookupFunctions[LookupStack[LookupStackIndex]].GetActiveRecordID(pRecordID));
        if LastLookupIndex > 0 then
            exit(LookupFunctions[LastLookupIndex].GetActiveRecordID(pRecordID));
    end;

    procedure GetLastLookupRecordID(var pRecordID: RecordID): Boolean
    begin
        if LastLookupIndex > 0 then
            exit(LookupFunctions[LastLookupIndex].GetActiveRecordID(pRecordID));
    end;

    procedure RefreshActiveLookup()
    begin
        if LookupStackIndex > 0 then
            LookupFunctions[LookupStack[LookupStackIndex]].RefreshDataGrid();
    end;

    procedure SetActiveLookupInfoText(pMessage: Text)
    begin
        if LookupStackIndex > 0 then
            LookupFunctions[LookupStack[LookupStackIndex]].SetInfoText(pMessage);
    end;

    procedure SetActiveLookupMarkedRecords(var pRecordIDStringArray: JsonArray)
    begin
        if LookupStackIndex > 0 then
            LookupFunctions[LookupStack[LookupStackIndex]].SetMarkedRecords(pRecordIDStringArray);
    end;

    procedure GetActiveLookupMarkedRecords(var pRecordIDStringArray: JsonArray; pRemoveMarks: Boolean)
    begin
        if LookupStackIndex > 0 then
            LookupFunctions[LookupStack[LookupStackIndex]].GetMarkedRecords(pRecordIDStringArray, pRemoveMarks)
        else
            if LastLookupIndex > 0 then
                LookupFunctions[LastLookupIndex].GetMarkedRecords(pRecordIDStringArray, pRemoveMarks);
    end;

    procedure ClearActiveLookupMarkedRecords()
    begin
        if LookupStackIndex > 0 then
            LookupFunctions[LookupStack[LookupStackIndex]].ClearMarkedRecords();
    end;

    procedure SetActiveDataGrid(pControlID: Text)
    begin
        CONTROLLIB.SetActiveDataGrid(pControlID);
    end;

    procedure GetDataGridKeyValue(pGridID: Code[20]): Code[30]
    begin
        if (pGridID = Format("LSC POS Data Grid Id"::"#LOOKUPGRID")) and (LookupStackIndex > 0) then begin
            exit(LookupFunctions[LookupStack[LookupStackIndex]].GetDataGridFunctions.GetActiveKeyValue());
        end;

        TmpDataGridIndexes.SetRange(Description, pGridID);
        if not TmpDataGridIndexes.FindFirst then begin
            PosMessage(StrSubstNo(DgFnUninitializedErr, pGridID));
            exit;
        end;

        TmpIndex := TmpDataGridIndexes."Integer Value";  //Use the existing (initialized) codeunit

        exit(DataGridFunctions[TmpIndex].GetActiveKeyValue());
    end;

    procedure GetDataGridRecordID(pGridID: Code[20]; var pRecordID: RecordID): Boolean
    var
        RecordIDText: Text;
    begin
        if (pGridID = Format("LSC POS Data Grid Id"::"#LOOKUPGRID")) and (LookupStackIndex > 0) then begin
            exit(LookupFunctions[LookupStack[LookupStackIndex]].GetDataGridFunctions.GetActiveRecordID(pRecordID));
        end;

        TmpDataGridIndexes.SetRange(Description, pGridID);
        if not TmpDataGridIndexes.FindFirst then begin
            RecordIDText := CONTROLLIB.GetDataGridActiveRecord(pGridID);
            if RecordIDText = '' then
                exit(false);
            if not Evaluate(pRecordID, RecordIDText) then
                exit(false);

            exit(true);
        end;

        TmpIndex := TmpDataGridIndexes."Integer Value";  //Use the existing (initialized) codeunit

        exit(DataGridFunctions[TmpIndex].GetActiveRecordID(pRecordID));
    end;

    procedure RefreshDataGrid(pGridID: Code[20])
    begin
        if pGridID <> Format("LSC POS Data Grid Id"::"#LOOKUPGRID") then
            ClearDataGridCount(pGridID);

        CONTROLLIB.RefreshDataGrid(pGridID);
    end;

    procedure SetDataGridMarkedRecords(pGridID: Code[20]; pRecordIDStringArray: JsonArray)
    begin
        CONTROLLIB.SetDataGridMarkedRecords(pGridID, pRecordIDStringArray);
    end;

    procedure GetDataGridMarkedRecords(pGridID: Code[20]; var pRecordIDStringArray: JsonArray; pRemoveMarks: Boolean)
    begin
        CONTROLLIB.GetDataGridMarkedRecords(pGridID, pRecordIDStringArray, pRemoveMarks);
    end;

    procedure GetDataGridMarkedRecord(pGridID: Code[20]; pIndex: Integer; pRemoveMark: Boolean): Text
    begin
        exit(CONTROLLIB.GetDataGridMarkedRecord(pGridID, pIndex, pRemoveMark));
    end;

    procedure GetDataGridMarkedRecordCount(pGridID: Code[20]): Integer
    begin
        exit(CONTROLLIB.GetDataGridMarkedRecordCount(pGridID));
    end;

    procedure ClearDataGridMarkedRecords(pGridID: Code[20])
    begin
        CONTROLLIB.ClearMarkedRecords(pGridID);
    end;

    procedure GetDataGridActiveRecord(pGridID: Code[20]): Text
    begin
        exit(CONTROLLIB.GetDataGridActiveRecord(pGridID));
    end;

    procedure EditDataGridRecord(pGridID: Code[20]; pDataTableID: Code[20]): Code[10]
    begin
        if (pGridID = Format("LSC POS Data Grid Id"::"#LOOKUPGRID")) and (LookupStackIndex > 0) then begin
            LookupFunctions[LookupStack[LookupStackIndex]].GetDataGridFunctions.EditActiveRecord(pDataTableID);
            exit;
        end;

        TmpDataGridIndexes.SetRange(Description, pGridID);
        if not TmpDataGridIndexes.FindFirst then begin
            PosMessage(StrSubstNo(DgFnUninitializedErr, pGridID));
            exit;
        end;

        TmpIndex := TmpDataGridIndexes."Integer Value";  //Use the existing (initialized) codeunit

        DataGridFunctions[TmpIndex].EditActiveRecord(pDataTableID);
    end;

    procedure EditActiveLookupRecord(pDataTableID: Code[20]): Code[10]
    begin
        if LookupStackIndex > 0 then
            LookupFunctions[LookupStack[LookupStackIndex]].EditActiveRecord(pDataTableID);
    end;

    procedure DeleteActiveLookupRecords()
    begin
        if LookupStackIndex > 0 then
            LookupFunctions[LookupStack[LookupStackIndex]].DeleteMarkedRecords();
    end;

    procedure ZoomDataGridRecord(pGridID: Code[20]; pDataTableID: Code[20]): Code[10]
    begin
        if (pGridID = Format("LSC POS Data Grid Id"::"#LOOKUPGRID")) and (LookupStackIndex > 0) then begin
            LookupFunctions[LookupStack[LookupStackIndex]].GetDataGridFunctions.ZoomActiveRecord(pDataTableID);
            exit;
        end;

        TmpDataGridIndexes.SetRange(Description, pGridID);
        if not TmpDataGridIndexes.FindFirst then begin
            PosMessage(StrSubstNo(DgFnUninitializedErr, pGridID));
            exit;
        end;

        TmpIndex := TmpDataGridIndexes."Integer Value";  //Use the existing (initialized) codeunit
        DataGridFunctions[TmpIndex].ZoomActiveRecord(pDataTableID);
    end;

    procedure ZoomActiveLookupRecord(pDataTableID: Code[20]): Code[10]
    begin
        if LookupStackIndex > 0 then
            LookupFunctions[LookupStack[LookupStackIndex]].ZoomActiveRecord(pDataTableID);
    end;

    procedure NewDataGridRecord(pGridID: Code[20]; pDataTableID: Code[20]): Code[10]
    begin
        if (pGridID = Format("LSC POS Data Grid Id"::"#LOOKUPGRID")) and (LookupStackIndex > 0) then begin
            LookupFunctions[LookupStack[LookupStackIndex]].GetDataGridFunctions.InsertNewRecord(pDataTableID);
            exit;
        end;

        TmpDataGridIndexes.SetRange(Description, pGridID);
        if not TmpDataGridIndexes.FindFirst then begin
            PosMessage(StrSubstNo(DgFnUninitializedErr, pGridID));
            exit;
        end;

        TmpIndex := TmpDataGridIndexes."Integer Value";  //Use the existing (initialized) codeunit
        DataGridFunctions[TmpIndex].InsertNewRecord(pDataTableID);
    end;

    procedure NewActiveLookupRecord(pDataTableID: Code[20]): Code[10]
    begin
        if LookupStackIndex > 0 then
            LookupFunctions[LookupStack[LookupStackIndex]].InsertNewRecord(pDataTableID);
    end;

    procedure DeleteDataGridRecords(pGridID: Code[20]): Code[10]
    begin
        if (pGridID = Format("LSC POS Data Grid Id"::"#LOOKUPGRID")) and (LookupStackIndex > 0) then begin
            LookupFunctions[LookupStack[LookupStackIndex]].GetDataGridFunctions.DeleteMarkedRecords();
            CONTROLLIB.ClearMarkedRecords(pGridID);
            exit;
        end;

        TmpDataGridIndexes.SetRange(Description, pGridID);
        if not TmpDataGridIndexes.FindFirst then begin
            PosMessage(StrSubstNo(DgFnUninitializedErr, pGridID));
            exit;
        end;

        TmpIndex := TmpDataGridIndexes."Integer Value";  //Use the existing (initialized) codeunit
        DataGridFunctions[TmpIndex].DeleteMarkedRecords();
        CONTROLLIB.ClearMarkedRecords(pGridID);
    end;

    procedure ShowDataTable(pDataGridControlID: Code[20]; pDataTableID: Code[20])
    begin
        CONTROLLIB.ShowDataTable(pDataGridControlID, pDataTableID);
    end;

    procedure SetDataGridFixedFilter(pDataGridControlID: Code[20]; pFieldNo: Integer; pFilterText: Text)
    begin
        if (pDataGridControlID = Format("LSC POS Data Grid Id"::"#LOOKUPGRID")) and (LookupStackIndex > 0) then begin
            LookupFunctions[LookupStack[LookupStackIndex]].GetDataGridFunctions.SetFixedFilter(pFieldNo, pFilterText);
            RefreshDataGrid(pDataGridControlID);
            exit;
        end;

        TmpDataGridIndexes.SetRange(Description, pDataGridControlID);
        if not TmpDataGridIndexes.FindFirst then begin
            PosMessage(StrSubstNo(DgFnUninitializedErr, pDataGridControlID));
            exit;
        end;

        TmpIndex := TmpDataGridIndexes."Integer Value";  //Use the existing (initialized) codeunit

        DataGridFunctions[TmpIndex].SetFixedFilter(pFieldNo, pFilterText);
        RefreshDataGrid(pDataGridControlID);
    end;

    procedure ResetDataGridFixedFilters(pDataGridControlID: Code[20])
    begin
        if (pDataGridControlID = Format("LSC POS Data Grid Id"::"#LOOKUPGRID")) and (LookupStackIndex > 0) then begin
            LookupFunctions[LookupStack[LookupStackIndex]].GetDataGridFunctions.ResetFixedFilters();
            RefreshDataGrid(pDataGridControlID);
            exit;
        end;

        TmpDataGridIndexes.SetRange(Description, pDataGridControlID);
        if not TmpDataGridIndexes.FindFirst then begin
            PosMessage(StrSubstNo(DgFnUninitializedErr, pDataGridControlID));
            exit;
        end;

        TmpIndex := TmpDataGridIndexes."Integer Value";  //Use the existing (initialized) codeunit

        DataGridFunctions[TmpIndex].ResetFixedFilters;
        RefreshDataGrid(pDataGridControlID);
    end;

    procedure GetDataGridFixedFilter(pDataGridControlID: Code[20]): Text
    begin
        if (pDataGridControlID = Format("LSC POS Data Grid Id"::"#LOOKUPGRID")) and (LookupStackIndex > 0) then begin
            exit(LookupFunctions[LookupStack[LookupStackIndex]].GetDataGridFunctions.GetFixedFilter());
        end;

        TmpDataGridIndexes.SetRange(Description, pDataGridControlID);
        if not TmpDataGridIndexes.FindFirst then begin
            PosMessage(StrSubstNo(DgFnUninitializedErr, pDataGridControlID));
            exit;
        end;

        TmpIndex := TmpDataGridIndexes."Integer Value";  //Use the existing (initialized) codeunit

        exit(DataGridFunctions[TmpIndex].GetFixedFilter);
    end;

    procedure GetDataGridRecCount(pDataGridControlID: Code[20]): Text
    begin
        if (pDataGridControlID = Format("LSC POS Data Grid Id"::"#LOOKUPGRID")) and (LookupStackIndex > 0) then begin
            exit(Format(LookupFunctions[LookupStack[LookupStackIndex]].GetDataGridFunctions.GetCount));
        end;

        TmpDataGridIndexes.SetRange(Description, pDataGridControlID);
        if not TmpDataGridIndexes.FindFirst then begin
            PosMessage(StrSubstNo(DgFnUninitializedErr, pDataGridControlID));
            exit;
        end;

        TmpIndex := TmpDataGridIndexes."Integer Value";  //Use the existing (initialized) codeunit

        exit(Format(DataGridFunctions[TmpIndex].GetCount));
    end;

    procedure ClearDataGridCount(pDataGridControlID: Code[20])
    begin
        if (pDataGridControlID = Format("LSC POS Data Grid Id"::"#LOOKUPGRID")) and (LookupStackIndex > 0) then begin
            LookupFunctions[LookupStack[LookupStackIndex]].GetDataGridFunctions.ClearCount();
            exit;
        end;

        TmpDataGridIndexes.SetRange(Description, pDataGridControlID);
        if not TmpDataGridIndexes.FindFirst then begin
            PosMessage(StrSubstNo(DgFnUninitializedErr, pDataGridControlID));
            exit;
        end;

        TmpIndex := TmpDataGridIndexes."Integer Value";  //Use the existing (initialized) codeunit

        DataGridFunctions[TmpIndex].ClearCount();
    end;

    procedure SetDataTag(pDataTag: Text)
    begin
        CONTROLLIB.SetDataTag(pDataTag);
    end;

    procedure DeleteDataByTag(pDataTag: Text): Integer
    begin
        exit(CONTROLLIB.RemovePOSDataByTag(pDataTag));
    end;

    procedure InitGridData(pDataGridID: Code[20]; var pLSDataSet: Codeunit "LSC DataSet")
    begin
        LogDebug(STRSUBSTNO('**InitGridData: ID=%1, Table=%2, Rows=%3, pagecount=%4' +
                    'StartPageNo=%5, filter=%6, PageSize=%7, DBTableRows=%8, GoToRowIndex=%9',
          pLSDataSet.GetId, pLSDataSet.GetTableNo, pLSDataSet.GetRows, pLSDataSet.GetPageCount,
          pLSDataSet.GetStartPageNo, pLSDataSet.GetFilterString, pLSDataSet.GetDBTablePageSize,
          pLSDataSet.GetDBTableRowCount, pLSDataSet.GetGoToRowIndex));

        CONTROLLIB.InitGridDataSet(pDataGridID, pLSDataSet.GetId(), pLSDataSet.ToJSONObject(false));
    end;

    procedure AddGridData(pDataGridID: Code[20]; var pLSDataSet: Codeunit "LSC DataSet")
    begin
        LogDebug(STRSUBSTNO('**AddGridData: ID=%1, Table=%2, Rows=%3, pagecount=%4, ' +
                    'StartPageNo=%5, filter=%6, PageSize=%7, DBTableRows=%8, GoToRowIndex=%9',
          pLSDataSet.GetId, pLSDataSet.GetTableNo, pLSDataSet.GetRows, pLSDataSet.GetPageCount,
          pLSDataSet.GetStartPageNo, pLSDataSet.GetFilterString, pLSDataSet.GetDBTablePageSize,
          pLSDataSet.GetDBTableRowCount, pLSDataSet.GetGoToRowIndex));
        CONTROLLIB.AddGridDataSet(pDataGridID, pLSDataSet.GetId(), pLSDataSet.ToJSONObject(false), pLSDataSet.GetStartPageNo);
    end;

    procedure AddGridData(pDataGridID: Code[20]; pLSDataSetJson: text)
    var
        lsds: Codeunit "LSC DataSet";
    begin
        LogDebug('**AddGridData-TEXT');
        lsds.FromJSON(pLSDataSetJson);
        AddGridData(pDataGridID, lsds);
    end;

    procedure PopupGridData(pDataGridID: Code[20]; var pLSDataSet: Codeunit "LSC DataSet"; pInputID: Code[20]; pHeight: Integer; pHideColumnHeader: Boolean)
    begin
        CONTROLLIB.PopupGridData(pDataGridID, pLSDataSet.ToJSONObject(false), pInputID, pHeight, pHideColumnHeader);
    end;

    procedure HidePopupGrid()
    begin
        CONTROLLIB.HidePopupGrid();
    end;

    procedure ShowRecordZoom(var recRef: RecordRef; recordZoomControlID: Code[20]; dataTableID: Code[20]; allowEdit: Boolean)
    begin
        ZoomFunctions.ShowRecordZoom(recRef, recordZoomControlID, dataTableID, '', allowEdit, false);
    end;

    procedure ShowRecordZoomJson(dataSetJson: Text; recordZoomControlID: Code[20]; allowEdit: Boolean)
    begin
        CONTROLLIB.ShowRecordZoomJSON(dataSetJson, recordZoomControlID, allowEdit);
    end;

    procedure GetRecordZoomData(var recRef: RecordRef; recordZoomControlID: Code[20])
    begin
        ZoomFunctions.GetRecordZoomData(recRef, recordZoomControlID);
    end;

    procedure GetRecordZoomDataXML(ControlID: Text): Text
    begin
        exit(CONTROLLIB.GetRecordZoomDataXML(ControlID));
    end;

    procedure RefreshZoomControl(pInterfaceProfileID: Code[10]; pControlID: Code[20])
    begin
        if not CONTROLLIB.PosIsActive then
            exit;
        CONTROLLIB.RefreshControl("LSC POS Control Type"::RecordZoom, pControlID, true);
    end;

    procedure ShowCustomRecordZoomData(var TempPairValue: Record "LSC POS Pair Value" temporary; RecordZoomControlID: Code[20]; AllowEdit: Boolean)
    begin
        ZoomFunctions.ShowCustomRecordZoom(TempPairValue, RecordZoomControlID, AllowEdit);
    end;

    procedure GetCustomRecordZoomData(var TempPairValue: Record "LSC POS Pair Value" temporary; RecordZoomControlID: Code[20])
    begin
        ZoomFunctions.GetCustomRecordZoomData(TempPairValue, RecordZoomControlID);
    end;

    procedure SelectOption(OptionCaption: Text; OptionString: Text; OptionAlignment: Integer; ShowCancel: Boolean): Integer
    begin
        if ShouldPreventDialogs() then
            exit(_DefaultStrMenuValue);
        if OptionCaption <> '' then
            exit(Dialog.StrMenu(OptionString, 1, OptionCaption));
        exit(Dialog.StrMenu(OptionString));
    end;

    procedure GoToNextRow(pGridID: Code[20])
    begin
        CONTROLLIB.GoToNextRow(pGridID);
    end;

    procedure GoToPreviousRow(pGridID: Code[20])
    begin
        CONTROLLIB.GoToPreviousRow(pGridID);
    end;

    procedure GoToRow(pGridID: Code[20]; pRowIndex: Integer)
    begin
        CONTROLLIB.GoToRow(pGridID, pRowIndex);
    end;

    procedure GoToRecord(pGridID: Code[20]; pRecordID: RecordID)
    var
        pos: Integer;
    begin
        if (pGridID = Format("LSC POS Data Grid Id"::"#LOOKUPGRID")) and (LookupStackIndex > 0) then begin
            pos := LookupFunctions[LookupStack[LookupStackIndex]].GetDataGridFunctions.FindRecordPosition(pRecordID);
        end
        else begin
            TmpDataGridIndexes.SetRange(Description, pGridID);
            if not TmpDataGridIndexes.FindFirst then begin
                PosMessage(StrSubstNo(DgFnUninitializedErr, pGridID));
                exit;
            end;
            TmpIndex := TmpDataGridIndexes."Integer Value";  //Use the existing (initialized) codeunit
            pos := DataGridFunctions[TmpIndex].FindRecordPosition(pRecordID);
        end;

        if pos >= 0 then
            CONTROLLIB.GoToRow(pGridID, pos);
    end;

    procedure SetPosCtrlActiveInteraceProfile(pPrimaryProfileID: Text; pSecondaryProfileID: Text)
    begin
        //LoadInterfaceProfile(pPrimaryProfileID);
        CONTROLLIB.SetPosCtrlActiveInteraceProfile(pPrimaryProfileID, pSecondaryProfileID);
    end;

    procedure SetPosCtrlActiveMenuProfile(pPrimaryProfileID: Text; pSecondaryProfileID: Text)
    begin
        CONTROLLIB.SetPosCtrlActiveMenuProfile(pPrimaryProfileID, pSecondaryProfileID);
    end;

    procedure SetPosCtrlActiveStyle(pPrimaryProfileID: Text; pSecondaryProfileID: Text)
    begin
        CONTROLLIB.SetPosCtrlActiveStyle(pPrimaryProfileID, pSecondaryProfileID);
    end;

    procedure DenyPanelClose()
    begin
        CONTROLLIB.DenyPanelClose();
    end;

    procedure SelectGridColumn(controlID: Code[20]; columnNo: Integer; sortOrder: Integer)
    begin
        CONTROLLIB.SelectGridColumn(controlID, columnNo, sortOrder);
    end;

    procedure GetGridSelectedColumn(controlID: Code[20]): Integer
    begin
        exit(CONTROLLIB.GetGridSelectedColumn(controlID));
    end;

    procedure GetDataGridColumnFieldNo(pDataGridControlID: Code[20]; pColumnNo: Integer): Integer
    begin
        if (pDataGridControlID = Format("LSC POS Data Grid Id"::"#LOOKUPGRID")) and (LookupStackIndex > 0) then begin
            exit(LookupFunctions[LookupStack[LookupStackIndex]].GetDataGridFunctions.GetColumnFieldNo(pColumnNo));
        end;

        TmpDataGridIndexes.SetRange(Description, pDataGridControlID);
        if not TmpDataGridIndexes.FindFirst then begin
            PosMessage(StrSubstNo(DgFnUninitializedErr, pDataGridControlID));
            exit;
        end;

        TmpIndex := TmpDataGridIndexes."Integer Value";  //Use the existing (initialized) codeunit

        exit(DataGridFunctions[TmpIndex].GetColumnFieldNo(pColumnNo));
    end;

    procedure ValidateZoomInput(var pPosEvent: Codeunit "LSC POS Event")
    begin
        if true in [
            pPosEvent.EventType <> pPosEvent.EventType::ZOOMFIELDVALIDATION,
            pPosEvent.StrData4 <> '', // Custom error message, already validated
            ZoomFunctions.ValidateInput(pPosEvent) // No error
        ] then
            exit;
        pPosEvent.StrData4(ZoomFunctions.GetValidationError());
        if pPosEvent.StrData4 = '' then
            pPosEvent.StrData4('*'); // Error but no message, mark it as a non-blank value
    end;

    procedure RegisterPanelClosedEvent(pPanelID: Code[20])
    begin
        CONTROLLIB.RegisterPanelClosedEvent(pPanelID);
    end;

    procedure ResetDataGrid(pGridID: Code[20])
    begin
        CONTROLLIB.ResetDataGrid(pGridID);
    end;

    procedure Playlist(pControlID: Code[20]; pPlaylistID: Code[20])
    var
        PosImageUtils: Codeunit "LSC POS Image Utils";
    begin
        PosImageUtils.GetPlaylist(pPlaylistID, CONTROLLIB);
        if pControlID <> '' then
            CONTROLLIB.Playlist(pControlID, pPlaylistID);
    end;

    procedure SetHtml(pControlID: Code[20]; pHtml: Text)
    begin
        _POSWebTemplateHandler.SetHtml(pControlID, pHtml);
    end;

    procedure InvokeScript(pControlID: Code[20]; pJavaScript: Text)
    begin
        _POSWebTemplateHandler.InvokeScript(pControlID, pJavaScript);
    end;

    procedure SetPosDesignMode(pDesignMode: Boolean)
    begin
        CONTROLLIB.SetPosDesignMode(pDesignMode);
    end;

    procedure SetMenuDesignMode(pMenuID: Code[20]; pDesignMode: Boolean)
    begin
        CONTROLLIB.SetMenuDesignMode(pMenuID, pDesignMode);
    end;

    procedure SetMenuLayoutStyle(pMenuID: Code[20]; pLayoutStyle: Integer)
    begin
        CONTROLLIB.SetMenuLayoutStyle(pMenuID, pLayoutStyle);
    end;

    procedure SetMenuDragDropEnabled(pMenuID: Code[20]; pEnabled: Boolean)
    begin
        CONTROLLIB.SetMenuDragDropEnabled(pMenuID, pEnabled);
    end;

    procedure SaveMenuModifications(pMenuID: Code[20])
    var
        tmpPosmenuline: Record "LSC POS Menu Line" temporary;
        PosMenu: Record "LSC POS Menu Header";
        PosMenuLine: Record "LSC POS Menu Line";
    begin
        if not POSSession.GetPosMenuRec(pMenuID, PosMenu) then
            exit;

        SaveMenuModificationsEx(pMenuID, tmpPosmenuline, true, true);
        if tmpPosmenuline.FindSet() then
            repeat
                if PosMenuLine.Get(PosMenu."Profile ID", PosMenu."Menu ID", tmpPosmenuline."Key No.") then begin
                    PosMenuLine.XPos := tmpPosmenuline.XPos;
                    PosMenuLine.YPos := tmpPosmenuline.YPos;
                    PosMenuLine.Width := tmpPosmenuline.Width;
                    PosMenuLine.Height := tmpPosmenuline.Height;
                    PosMenuLine.Modify;
                end;
            until tmpPosmenuline.Next = 0;
    end;

    procedure SaveMenuModificationsEx(pMenuID: Code[20]; var posmenuline: Record "LSC POS Menu Line"; allowInsert: Boolean; clearModifications: Boolean)
    var
        Counted, i, btnIdx : Integer;
        ButtonProperties, btns : List of [Integer];
    begin
        btns := CONTROLLIB.GetMenuModifiedButtons(pMenuID);
        Counted := btns.Count;
        if Counted = 0 then begin
            if clearModifications then
                CONTROLLIB.ClearMenuModifications(pMenuID);
            exit;
        end;
        for i := 1 to Counted do begin
            btnIdx := btns.Get(i);
            ButtonProperties := CONTROLLIB.GetMenuModifiedButtonValues(pMenuID, btnIdx);
            if posmenuline.Get(POSSession.MenuProfileID, pMenuID, btnIdx) then begin
                posmenuline.XPos := ButtonProperties.Get(1); // ButtonProperties.XPos;
                posmenuline.YPos := ButtonProperties.Get(2); //ButtonProperties.YPos;
                posmenuline.Width := ButtonProperties.Get(3); // ButtonProperties.Width;
                posmenuline.Height := ButtonProperties.Get(4); // ButtonProperties.Height;
                posmenuline.Modify;
            end else
                if allowInsert then begin
                    posmenuline.Init;
                    posmenuline."Profile ID" := POSSession.MenuProfileID; // ButtonProperties.ProfileID;
                    posmenuline."Menu ID" := pMenuID; // ButtonProperties.MenuID;
                    posmenuline."Key No." := btnIdx; // ButtonProperties.KeyNo;
                    posmenuline.XPos := ButtonProperties.Get(1); // ButtonProperties.XPos;
                    posmenuline.YPos := ButtonProperties.Get(2); // ButtonProperties.YPos;
                    posmenuline.Width := ButtonProperties.Get(3); // ButtonProperties.Width;
                    posmenuline.Height := ButtonProperties.Get(4); // ButtonProperties.Height;
                    posmenuline.Insert;
                end;
        end;

        Commit;
        if clearModifications then
            CONTROLLIB.ClearMenuModifications(pMenuID);
    end;

    procedure GetMenuLineModifications(var pPosMenuLine: Record "LSC POS Menu Line")
    var
        i, Counted : Integer;
        ButtonProperties, btns : List of [Integer];
    begin
        btns := CONTROLLIB.GetMenuModifiedButtons(pPosMenuLine."Menu ID");
        Counted := btns.Count;
        if Counted = 0 then
            exit;
        if btns.IndexOf(pPosMenuLine."Key No.") < 1 then
            exit;
        ButtonProperties := CONTROLLIB.GetMenuModifiedButtonValues(pPosMenuLine."Menu ID", i);
        pPosMenuLine.XPos := ButtonProperties.Get(1); // ButtonProperties.XPos;
        pPosMenuLine.YPos := ButtonProperties.Get(2); // ButtonProperties.YPos;
        pPosMenuLine.Width := ButtonProperties.Get(3); // ButtonProperties.Width;
        pPosMenuLine.Height := ButtonProperties.Get(4); // ButtonProperties.Height;
        // Commit;
        CONTROLLIB.ClearMenuModifications(pPosMenuLine."Menu ID");
    end;

    procedure SetSelectedButton(pMenuID: Code[20]; i: Integer)
    begin
        CONTROLLIB.SetSelectedButton(pMenuID, i);
    end;

    procedure GetSelectedButton(pMenuID: Code[20]): Integer
    begin
        exit(CONTROLLIB.GetSelectedButton(pMenuID));
    end;

    procedure JoinButtons(menuID: Code[20]; slaveButtonNo: Integer; masterButtonNo: Integer)
    begin
        CONTROLLIB.JoinButtons(menuID, slaveButtonNo, masterButtonNo)
    end;

    procedure DisJoinButtons(menuID: Code[20]; slaveButtonNo: Integer; masterButtonNo: Integer)
    begin
        CONTROLLIB.DisJoinButtons(menuID, slaveButtonNo, masterButtonNo);
    end;

    procedure IgnorePostCommand()
    begin
        CONTROLLIB.IgnorePostCommand();
    end;

    procedure UploadTranslations()
    begin
        CONTROLLIB.SetLanguage(POSSession.GetLanguageCode());
    end;

    procedure UpdateButtonSkin(ProfileID: Code[20]; MenuID: Code[20]; ButtonNo: Integer; var Skin: Record "LSC POS Button Skin"; FieldList: List of [Integer])
    var
        SkinEntity: Record "LSC POS Button Skin Entity";
    begin
        if Skin."Custom Css".HasValue then
            Skin.CalcFields("Custom Css");
        SkinEntity.TransferFields(Skin);
        SkinEntity.Insert;
        CONTROLLIB.UpdateButtonSkin(MenuID, ButtonNo, SkinEntity, FieldList);
    end;

    procedure SetAutoLogoffTimeout(Timeout: Integer)
    begin
        CONTROLLIB.SetAutoLogoffTimeout(Timeout);
    end;

    procedure AddJavaScript(script: Text)
    begin
        CONTROLLIB.AddJavaScript(script);
    end;

    procedure LookupClosed(resultOK: Boolean)
    begin
        LookupFunctions[LookupStack[LookupStackIndex]].SaveState();

        if resultOK then
            LookupFunctions[LookupStack[LookupStackIndex]].ProcessLookupResult();

        LookupStackIndex -= 1;

        if LookupStackIndex > 0 then begin
            LookupFunctions[LookupStack[LookupStackIndex]].RestoreState();
            LastLookupIndex := LookupStack[LookupStackIndex];
        end
        else
            LastLookupIndex := LookupStack[1]; //LookupIndex;
    end;

    procedure SetIdleTimerInterval(pSeconds: Integer)
    begin
        CONTROLLIB.SetIdleTimerInterval(pSeconds);
    end;

    procedure SetPanelColumns(pPanelID: Text; pNewValue: Integer)
    begin
        CONTROLLIB.SetPanelColumns(pPanelID, pNewValue);
    end;

    procedure SetPanelRows(pPanelID: Text; pNewValue: Integer)
    begin
        CONTROLLIB.SetPanelRows(pPanelID, pNewValue);
    end;

    procedure PosMessageBanner(Msg: Text; Level: enum "LSC POS Message Banner Level"; Timeout: Integer)
    begin
        CONTROLLIB.PosMessageBanner(Msg, Level.AsInteger(), Timeout);
        if Level = Level::Error then
            LogDebug(StrSubstNo('**PosMessageBanner: Text: %1, Level: %2, Timeout: %3', Msg, Level.AsInteger(), Timeout));
    end;

    procedure EnableDualDisplayMirroring()
    begin
        CONTROLLIB.EnableDualDisplayMirroring();
    end;
}

