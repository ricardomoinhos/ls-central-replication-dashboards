codeunit 99001572 "LSC POS View" implements "LSC IDeviceView", "LSC IPosView"
{
    SingleInstance = true;
    TableNo = "LSC POS Menu Line";

    trigger OnRun()
    begin
        RunCommand(Rec);
    end;

    var
        POSTerminalInUse: Record "LSC POS Terminal In Use";
        POSTRANS: Codeunit "LSC POS Transaction Impl";
        POSSESSION: Codeunit "LSC POS Session";
        POSExchangerateConversion: Codeunit "LSC POS Exch. rate conversion";
        POSFunctions: Codeunit "LSC POS Functions";
        TSUtil: Codeunit "LSC POS Trans. Server Utility";
        ServiceLocator: Codeunit "LSC Service Locator";

        // previously in POS GUI, temporarily moved to POS View:
        _CurrMenu: array[5] of Code[20];
        _LastMenu: Code[20];
        _SelectMenuID: Code[20];
        _CurrPopupMenu: Code[20];
        _RefreshMenuFlag: array[4] of Boolean;

    // POS - Internal in 18.4
    procedure Init(): Boolean
    begin
        exit(POSTRANS.Init);
    end;

    // POS - Internal in 18.4
    procedure SetOfflineTenderDeclState(pCommand: Text)
    begin
        POSTRANS.SetOfflineTenderDeclState(pCommand);
    end;

    // POS - Internal in 18.4
    procedure Close(): Boolean
    begin
        exit(POSTRANS.Close(false));
    end;

    // POS - Internal in 18.4
    procedure InfocodeTestOnClose(): Boolean
    begin
        exit(POSTRANS.InfocodeTestOnClose);
    end;

    // POS - Internal in 18.4
    procedure GetCommandRetVal(): Boolean
    begin
        exit(POSTRANS.GetCommandRetVal);
    end;

    // POS - Internal in 18.4
    procedure OkNewInput(): Boolean
    begin
        exit(POSTRANS.OkNewInput);
    end;

    // POS - Internal in 18.4
    procedure ValidateInput()
    begin
        POSTRANS.ValidateInput();
    end;

    // POS - Internal in 18.4
    procedure ProcessScannerInput(pScanInput: Text)
    begin
        POSTRANS.ProcessScannerInput(pScanInput);
    end;

    internal procedure ProcessRfidInput(var TagTemp: Record "LSC EPC Data Buffer")
    begin
        TransactionRfid().ProcessRfidInput(TagTemp);
    end;

    // POS - Internal in 18.4
    procedure ProcessMSRInput(var pMSRInput: Text)
    begin
        POSTRANS.ProcessMSRInput(pMSRInput);
    end;

    procedure ProcessMSRStaffLogin(pMSRTrack: Text; var pStaffID: Text): Boolean
    begin
        exit(POSFunctions.ProcessMSRStaffLogin(pMSRTrack, pStaffID));
    end;

    // POS - Internal in 18.4
    procedure CheckMSRCards(): Boolean
    begin
        exit(POSTRANS.CheckMSRcards);
    end;

    procedure SetManagerID(ManagerID: Code[20]): Boolean
    begin
        exit(POSTRANS.SetManagerID(ManagerID));
    end;

    procedure ProcessStaffCardLogin(StaffID: Code[20]): Boolean
    begin
        exit(POSTRANS.ProcessStaffCardLogin(StaffID));
    end;

    // POS - Internal in 18.4
    procedure InitCommand()
    begin
        POSTRANS.InitCommand;
    end;

    // POS - Internal in 18.4
    procedure RunCommand(var MenuLine: Record "LSC POS Menu Line"): Boolean
    begin

        POSTRANS.Run(MenuLine);
        exit(POSTRANS.GetCommandRetVal);
    end;

    // POS - Internal in 18.4
    procedure TotalPressed(): Boolean
    begin
        if not POSTRANS.TotalPressed(true) then
            exit(false);

        Commit;

        exit(true);
    end;

    // POS - Internal in 18.4
    procedure CalcTotals()
    begin
        POSTRANS.CalcTotals;
    end;

    procedure CalcPrices(var r: Record "LSC POS Trans. Line")
    begin
        POSTRANS.CalcPrices(r);
    end;

    procedure InsertLine(var r: Record "LSC POS Trans. Line")
    begin
        InsertLine(r, -1);
    end;

    procedure InsertLine(var r: Record "LSC POS Trans. Line"; UseLineNo: Integer)
    begin
        POSTRANS.InsertLine(r, UseLineNo);
    end;

    // POS - Internal in 18.4
    procedure SetFunctionMode(FunctionCode: Code[10])
    begin
        POSTRANS.SetFunctionMode(FunctionCode);
    end;

    // POS - Internal in 18.4
    procedure GetFunctionMode(): Code[20]
    begin
        exit(POSTRANS.GetFunctionMode);
    end;

    // POS - Internal in 18.4
    procedure RunMacro(MacroID: Code[10]): Boolean
    var
        MacroRec: Record "LSC POS Macro Line";
        MenuLine: Record "LSC POS Menu Line";
    begin
        //RunMacro
        MacroRec.SetRange(MacroRec."Profile ID", POSSESSION.MenuProfileID);
        MacroRec.SetRange(MacroRec."Macro ID", MacroID);
        if MacroRec.Find('-') then
            repeat
                MenuLine.Command := MacroRec.Command;
                MenuLine.Parameter := MacroRec.Parameter;
                if not RunCommand(MenuLine) then
                    exit(false);
            until MacroRec.Next = 0;
        exit(true);
    end;

    // POS - Internal in 18.4
    procedure TSCheckError(): Boolean
    begin
        exit(POSTRANS.TSCheckError);
    end;

    // POS - Internal in 18.4
    procedure CancelPressed(Hard: Boolean; Requested: Enum "LSC POS Trans. Request Infoc.")
    begin
        POSTRANS.CancelPressed(Hard, Requested);
    end;

    // POS - Internal in 18.4
    procedure AppendCurrInput("Key": Text[30])
    begin
        POSTRANS.AppendInput(Key);
    end;

    // POS - Internal in 18.4
    procedure SetInputPrompt(var prompt: Text[30])
    begin
        POSTRANS.SetInputPrompt(prompt);
    end;

    // POS - Internal in 18.4
    procedure DefaultMenuSelectFlagged(): Boolean
    begin
        exit(POSTRANS.GetDefaultMenuSelectedFlag());
    end;

    // POS - Internal in 18.4
    procedure PosInfoText1(): Text
    begin
        exit(POSTRANS.GetPosInfoText1());
    end;

    // POS - Internal in 18.4
    procedure PosInfoText2(): Text
    begin
        exit(POSTRANS.GetPosInfoText2());
    end;

    // POS - Internal in 18.4
    procedure SetPosInfoText1(pText: Text)
    begin
        POSTRANS.SetPosInfoText1(pText);
    end;

    // POS - Internal in 18.4
    procedure SetPosInfoText2(pText: Text)
    begin
        POSTRANS.SetPosInfoText2(pText);
    end;

    // POS - Internal in 18.4
    procedure InputPrompt(): Text[30]
    begin
        exit(POSTRANS.GetInputPrompt());
    end;

    // POS - Internal in 18.4
    procedure SetCurrInput(var pCurrInput: Text)
    begin
        POSTRANS.SetCurrInput(pCurrInput);
    end;

    // POS - Internal in 18.4
    procedure GetCurrInput(): Text
    begin
        exit(POSTRANS.GetCurrInput);
    end;

    // POS - Internal in 18.4
    procedure IsNewTransaction(): Boolean
    begin
        exit(POSTRANS.IsNewTransaction);
    end;

    procedure SaleIsReturnSale(): Boolean
    begin
        exit(POSTRANS.SaleIsReturnSale);
    end;

    procedure GetStoreNo(): Code[10]
    begin
        exit(POSTRANS.GetStoreNo);
    end;

    procedure GetPOSTerminalNo(): Code[10]
    begin
        exit(POSTRANS.GetPOSTerminalNo);
    end;

    // POS - Internal in 18.4
    procedure GetReceiptNo(): Code[20]
    begin
        exit(POSTRANS.GetReceiptNo);
    end;

    // POS - Internal in 18.4
    procedure GetSalesStaff(): Code[20]
    begin
        exit(POSTRANS.GetSalesStaff);
    end;

    // POS - Internal in 18.4
    procedure GetDocumentNo(): Code[20]
    begin
        exit(POSTRANS.GetDocumentNo);
    end;

    // POS - Internal in 18.4
    procedure GetCustomerNo(): Code[20]
    begin
        exit(POSTRANS.GetCustomerNo);
    end;

    // POS - Internal in 18.4
    procedure GetDiscount(): Decimal
    begin
        exit(POSTRANS.GetDiscount);
    end;

    [Obsolete('Not used, use POS Formatting to FormatAmount', '26.0')]
    procedure GetDiscountTxt(): Text[30]
    var
        Formatting: Codeunit "LSC POS Formatting";
    begin
        exit(Formatting.FormatAmount(GetDiscount));
    end;

    // POS - Internal in 18.4
    procedure GetAmount(): Decimal
    begin
        exit(POSTRANS.GetAmount);
    end;

    [Obsolete('Not used, use POS Formatting to FormatAmount', '26.0')]
    procedure GetAmountTxt(): Text[30]
    var
        Formatting: Codeunit "LSC POS Formatting";
    begin
        exit(Formatting.FormatAmount(GetAmount));
    end;

    // POS - Internal in 18.4
    procedure GetPayment(): Decimal
    begin
        exit(POSTRANS.GetPayment);
    end;

    [Obsolete('Not used, use POS Formatting to FormatAmount', '26.0')]
    procedure GetPaymentTxt(): Text[30]
    var
        Formatting: Codeunit "LSC POS Formatting";
    begin
        exit(Formatting.FormatAmount(GetPayment));
    end;

    // POS - Internal in 18.4
    procedure GetOutstandingBalance(): Decimal
    begin
        exit(POSTRANS.GetOutstandingBalance);
    end;

    [Obsolete('Not used, use POS Formatting to FormatAmount', '26.0')]
    procedure GetOutstandingBalanceTxt(): Text[30]
    var
        Formatting: Codeunit "LSC POS Formatting";
    begin
        exit(Formatting.FormatAmount(GetOutstandingBalance));
    end;

    // POS - Internal in 18.4
    procedure GetPrepaymentAmount(): Decimal
    begin
        exit(POSTRANS.GetPrepaymentAmount);
    end;

    [Obsolete('Not used, use POS Formatting to FormatAmount', '26.0')]
    procedure GetPrepaymentAmountTxt(): Text[30]
    var
        Formatting: Codeunit "LSC POS Formatting";
    begin
        exit(Formatting.FormatAmount(POSTRANS.GetPrepaymentAmount));
    end;

    // POS - Internal in 18.4
    procedure GetPrepaymentBalance(): Decimal
    begin
        exit(POSTRANS.GetPrepaymentBalance);
    end;

    [Obsolete('Not used, use POS Formatting to FormatAmount', '26.0')]
    procedure GetPrepaymentBalanceTxt(): Text[30]
    var
        Formatting: Codeunit "LSC POS Formatting";
    begin
        exit(Formatting.FormatAmount(GetPrepaymentBalance));
    end;

    // POS - Internal in 18.4
    procedure GetShiftNo(): Code[1]
    begin
        exit(POSTRANS.GetShiftNo);
    end;

    procedure GetStaffID(): Code[20]
    begin
        exit(POSTRANS.GetStaffID);
    end;

    // POS - Internal in 18.4
    procedure GetSalesType(): Code[20]
    begin
        exit(POSTRANS.GetSalesType);
    end;

    // POS - Internal in 18.4
    procedure GetGuests(): Integer
    begin
        exit(POSTRANS.GetGuests);
    end;

    // POS - Internal in 18.4
    procedure GetCovers(): Integer
    begin
        exit(POSTRANS.GetCovers);
    end;

    // POS - Internal in 18.4
    procedure GetTableNo(): Text
    begin
        exit(POSTRANS.GetTableDescr);
    end;

    // POS - Internal in 18.4
    procedure GetPosState(): Code[10]
    begin
        exit(POSTRANS.GetPosState);
    end;

    procedure IsInitialized(): Boolean
    begin
        exit(POSTRANS.IsInitialized);
    end;

    procedure GetPosStateEnum(): Enum "LSC POS Transaction State"
    begin
        exit(POSTRANS.GetPOSStateEnum(POSTRANS.GetPosState));
    end;

    // POS - Internal in 18.4
    procedure GetGlobalSalesType(): Code[20]
    begin
        exit(POSTRANS.GetGlobalSalesType);
    end;

    // POS - Internal in 18.4
    procedure Login(Manager: Boolean; SetNewStaffID: Code[20]): Boolean
    begin
        exit(LoginEx(Manager, SetNewStaffID, true, '', '', ''));
    end;

    // POS - Internal in 18.4
    procedure LoginEx(Manager: Boolean; SetNewStaffID: Code[20]; UpdateTransactionStaffID: Boolean; StaffID: Text; Password: Text; Workshift: Text): Boolean
    var
        TmpStaff: Record "LSC Staff";
        POSLog: Record "LSC POS Log";
        POSTerminalInUse_l: Record "LSC POS Terminal In Use";
        EPOSControlInterface: Codeunit "LSC POS Control Interface";
        PayloadUtil: Codeunit "LSC POS Payload Util";
        CurrentInterfaceProfile: Code[10];
        MessageTxt: Text[80];
        MessageText2: Text;
        OtherSessionID: Integer;
        OtherSessionServiceInstance: Integer;
        Ok: Boolean;
        RetVal, ContinueOpeningPOS : Boolean;
        IsHandled: Boolean;
        DoYouWantToCloseQuest: Label 'Do you  want to close the other session?';
        UserWasNotLogedOn: Label 'User %1 on Computer %2 was NOT logged on.';
        StaffPasswrdUpdateConfrmMsg: Label 'Your password is expired. Do you want to set a new password?';
        NotPossibleToLogOtherOut: Label 'The other session can NOT be closed because it is on a different Service Tier.';
        DoYouWantToProceed: Label '\Are you sure there is no other user running this POS Terminal? \do you want to proceed?';
        StaffLoginOnlyAllowedUsingCardMsg: Label 'Staff login only allowed using card';
    begin
        POSSESSION.SetValue("LSC POS Tag"::"MU_Heading1", ''); //Heading

        Commit;
        POSTRANS.TriggerOnBeforeLogin();

        Commit;

        if POSSESSION.FunctionalityProfile."Only Card Logon" then
            if SetNewStaffID = '' then begin
                EPOSControlInterface.PosMessage(StaffLoginOnlyAllowedUsingCardMsg);
                exit(false);
            end;

        POSSESSION.SetValue("LSC POS Tag"::ManagerLogin, Format(Manager)); //we need to know if the login is for a Manager Override.  Use when we get MSR swipe, ElectronicKeyValue, Biometrics, etc. in Login Panel

        if SetNewStaffID <> '' then begin
            Ok := true;
            StaffID := SetNewStaffID;
            TmpStaff.Get(StaffID);
            Password := TmpStaff.Password;
            Workshift := '';
        end
        else
            if StaffID = '' then begin
                // EPOSControlInterface.SetInputEnabled(Format("LSC POS Input Control Id"::"#WORKSHIFT"), POSSESSION.Store."Closing Method" = 1);
                EPOSControlInterface.SetInputText(Format("LSC POS Input Control Id"::"#STAFFID"), '');  //Clear previous input
                EPOSControlInterface.SetInputText(Format("LSC POS Input Control Id"::"#PASSWORD"), '');  //Clear previous input
                EPOSControlInterface.ShowPanelModal(Format("LSC POS Panel Id"::"#LOGIN"), Format(Manager) + ',' + SetNewStaffID);
                exit(false);
            end;

        RetVal := POSSESSION.Login(Manager, StaffID, Password, Workshift, MessageTxt);

        if RetVal then begin
            //CHECK IF PASSWORD NEEDS TO CHANGE
            TmpStaff.Get(StaffID);
            if TmpStaff."Change Password" then begin
                IF NOT EPOSControlInterface.PosConfirm(StaffPasswrdUpdateConfrmMsg, TRUE) THEN
                    EXIT(FALSE);
                MessageBeep('');
                PayloadUtil.CreatePayload(Format("LSC POS Panel Id"::"#PASSWORDCHANGE"));
                PayloadUtil.AddKeyValue('STAFFID', StaffID);
                PayloadUtil.AddKeyValue('WORKSHIFT', Workshift);
                PayloadUtil.AddKeyValue('ORGPASS', TmpStaff.ScramblePassWord(Password));

                POSSESSION.SetValue("LSC POS Tag"::"MU_Heading1", TmpStaff.ID); //Heading
                EPOSControlInterface.SetInputText(Format("LSC POS Input Control Id"::"#PASSWORDNEW"), '');
                EPOSControlInterface.SetInputText(Format("LSC POS Input Control Id"::"#PASSWORDCONFIRM"), '');
                EPOSControlInterface.ShowPanelModal(Format("LSC POS Panel Id"::"#PASSWORDCHANGE"), PayloadUtil.GetPayloadText());
                exit(false);
            end;

            if Manager then begin
                if not POSSESSION.SetManagerID(TmpStaff, MessageTxt) then begin
                    MessageBeep(MessageTxt);
                    exit(false);
                end;
            end
            else begin
                OnBeforeSetStaffID(Manager, TmpStaff, IsHandled);
                if IsHandled then
                    exit(false);
                SetStaffID(TmpStaff, Workshift, UpdateTransactionStaffID);
            end;

            if (POSTRANS.GetReceiptNo() <> '') then
                POSTRANS.LoadPosTrans(POSTRANS.GetReceiptNo(), true);
            RefreshMgrStatus;

            Commit;
            POSTRANS.TriggerOnAfterLogin();
        end;

        if MessageTxt <> '' then
            ServiceLocator.TransactionGUI.PosMessage(MessageTxt);

        if RetVal then begin
            ContinueOpeningPOS := POSSESSION.GetValue("LSC POS Tag"::TEST_MODE) <> '';
            POSTerminalInUse.ProcessLoginLogout(POSSESSION.TerminalNo, SessionId, UserId, true, ContinueOpeningPOS, MessageText2, OtherSessionID, OtherSessionServiceInstance);
            if MessageText2 <> '' then begin
                CurrentInterfaceProfile := POSSESSION.InterfaceProfileID;
                POSSESSION.SetInterfaceProfile(Format("LSC POS Profile ID"::DefaultInterface));
                if ServiceLocator.TransactionGUI.PosConfirm(MessageText2 + '\' + DoYouWantToCloseQuest, false) then begin
                    POSSESSION.SetInterfaceProfile(CurrentInterfaceProfile);
                    if OtherSessionServiceInstance = ServiceInstanceId then begin
                        StopSession(OtherSessionID);
                        POSTerminalInUse.ProcessLoginLogout(POSSESSION.TerminalNo, SessionId, UserId, true, true, MessageText2, OtherSessionID, OtherSessionServiceInstance)
                    end
                    else begin
                        if ServiceLocator.TransactionGUI.PosConfirm(NotPossibleToLogOtherOut + DoYouWantToProceed, false) then begin
                            POSTerminalInUse_l.Reset();
                            POSTerminalInUse_l.SetRange("POS Terminal No.", POSSESSION.TerminalNo());
                            POSTerminalInUse_l.DeleteAll();
                            POSTerminalInUse.ProcessLoginLogout(POSSESSION.TerminalNo, SessionId, UserId, true, true, MessageText2, OtherSessionID, OtherSessionServiceInstance)
                        end else begin
                            POSLog.InsertLogLine(SYSTEM.Today, SYSTEM.Time, POSSESSION.StoreNo, POSSESSION.TerminalNo, POSTRANS.GetStaffID, POSTRANS.GetReceiptNo,
                              'LOGON', '1', StrSubstNo(UserWasNotLogedOn, UserId, POSTerminalInUse."Computer Name"), 0, MessageText2);
                            exit(false);
                        end;
                    end
                end
                else begin
                    POSSESSION.SetInterfaceProfile(CurrentInterfaceProfile);
                    POSLog.InsertLogLine(SYSTEM.Today, SYSTEM.Time, POSSESSION.StoreNo, POSSESSION.TerminalNo, POSTRANS.GetStaffID, POSTRANS.GetReceiptNo,
                      'LOGON', '1', StrSubstNo(UserWasNotLogedOn, UserId, POSTerminalInUse."Computer Name"), 0, MessageText2);
                    exit(false);
                end;
            end;
            if POSSESSION.FunctionalityProfile.RegisterLogonLogoff then begin
                POSTRANS.GetStoreSetup;
                POSTRANS.InsertLogonLogoffTrans(1);
            end;
        end;

        OnAfterLoginEx;
        exit(RetVal);
    end;

    // POS - Internal in 18.4
    procedure SetStaffID(Staff: Record "LSC Staff"; ShiftNo: Code[1]; UpdateTransaction: Boolean)
    var
        WorkshiftSetup: Record "LSC Work Shift Setup";
    begin
        POSSESSION.SetStaff(Staff);
        if WorkshiftSetup.Get(POSSESSION.Store."No.", ShiftNo) then
            POSSESSION.SetValue("LSC POS Tag"::SHIFT_NO, ShiftNo)
        else
            POSSESSION.SetValue("LSC POS Tag"::SHIFT_NO, '');
        POSSESSION.SetValue("LSC POS Tag"::WORKSHIFT_NO, POSSESSION.GetValue("LSC POS Tag"::SHIFT_NO)); // legacy
        if UpdateTransaction then
            POSTRANS.SetStaffID(POSSESSION.StaffID);
        if TSUtil.Initialize then
            if TSUtil.UpdateStaffStatus(POSSESSION.StaffID, POSSESSION.TerminalNo, true) then;
    end;

    // POS - Internal in 18.4
    procedure GetErrorMessageFlag(): Boolean
    begin
        exit(ServiceLocator.TransactionGUI.GetAndResetErrorMessageFlag());
    end;

    // POS - Internal in 18.4
    procedure GetClosePosFlag(): Boolean
    begin
        exit(POSTRANS.GetClosePosFlag());
    end;

    // POS - Internal in 18.4
    procedure SetCurrMenu(pMenuNo: Integer; pMenuID: Code[20])
    begin
        _CurrMenu[pMenuNo + 1] := pMenuID;
    end;

    // POS - Internal in 18.4
    procedure GetCurrMenu(pMenuNo: Integer): Code[20]
    begin
        exit(_CurrMenu[pMenuNo + 1]);
    end;

    // POS - Internal in 18.4
    procedure SetLastMenu(pMenuID: Code[20])
    begin
        _LastMenu := pMenuID;
    end;

    // POS - Internal in 18.4
    procedure GetLastMenu(): Code[20]
    begin
        exit(_LastMenu);
    end;

    // POS - Internal in 18.4
    procedure SetSelectedMenu(pMenuID: Code[20])
    begin
        _SelectMenuID := pMenuID;
    end;

    // POS - Internal in 18.4
    procedure GetSelectedMenu() RetVal: Code[20]
    begin
        RetVal := _SelectMenuID;
        _SelectMenuID := '';
    end;

    internal procedure SetRefreshMenuFlag(pMenuNo: Integer)
    begin
        _RefreshMenuFlag[pMenuNo + 1] := true;
    end;

    internal procedure GetRefreshMenuFlag(pMenuNo: Integer) retval: Boolean
    begin
        retval := _RefreshMenuFlag[pMenuNo + 1];
        _RefreshMenuFlag[pMenuNo + 1] := false;
    end;

    // POS - Internal in 18.4
    procedure GetNewLineNo(): Integer
    begin
        exit(POSTRANS.GetNewLineNo);
    end;

    // POS - Internal in 18.4
    procedure MessageBeep(Txt: Text)
    begin
        ServiceLocator.TransactionGUI.MessageBeep(Txt);
    end;

    // POS - Internal in 18.4
    procedure ErrorBeep(Txt: Text)
    begin
        ServiceLocator.TransactionGUI.ErrorBeep(Txt);
    end;

    // POS - Internal in 18.4
    procedure PrintXReport(DoCheck: Boolean)
    begin
        POSTRANS.PrintXReport(DoCheck);
    end;

    // POS - Internal in 18.4
    procedure PrintZReport(DoChecks: Boolean; AskUser: Boolean)
    begin
        POSTRANS.PrintZReport(DoChecks, AskUser);
    end;

    // POS - Internal in 18.4
    procedure SetTrainingMode(TrainingMode: Boolean)
    begin
        POSTRANS.SetTrainingMode(TrainingMode);
    end;

    // POS - Internal in 18.4
    procedure GetTrainingMode(): Boolean
    begin
        exit(POSTRANS.GetTrainingMode);
    end;

    // POS - Internal in 18.4
    procedure GetLastTransNo(): Integer
    begin
        exit(POSTRANS.GetLastTransNo);
    end;

    // POS - Internal in 18.4
    procedure ProcessFuelMessage(): Integer
    begin
        exit(POSTRANS.ProcessFuelMessage());
    end;

    // POS - Internal in 18.4
    procedure GetContactNo(): Code[20]
    begin
        exit(POSTRANS.GetContactID);
    end;

    // POS - Internal in 18.4
    procedure GetPosStateTxt(): Code[30]
    begin
        exit(POSTRANS.GetStateTxt());
    end;

    [Obsolete('Not used, use POSSESSION.GetValue("LSC POS Tag"::"StateTxt2")) instead', '26.0')]
    procedure GetPosStateTxt2(): Text[30]
    var
        POSSESSION: Codeunit "LSC POS Session";
    begin
        exit(POSSESSION.GetValue("LSC POS Tag"::"StateTxt2"));
    end;

    // POS - Internal in 18.4
    procedure GetLastItemNo(): Code[20]
    begin
        exit(POSTRANS.GetLastItemNo);
    end;

    // POS - Internal in 18.4
    procedure ClearLastItemNo()
    begin
        POSTRANS.ClearLastItemNo;
    end;

    // POS - Internal in 18.4
    procedure ChangeBackAmount(): Decimal
    begin
        exit(POSTRANS.ChangeBackAmount);
    end;

    // POS - Internal in 18.4
    procedure ChangeBackAmoungFCY(): Decimal
    begin
        exit(POSTRANS.ChangeBackAmoungFCY);
    end;

    // POS - Internal in 18.4
    procedure PrintTransaction()
    begin
        POSTRANS.InventoryLookupPressed;
    end;

    // POS - Internal in 18.4
    procedure GetMenuType(): Code[20]
    begin
        exit(POSTRANS.GetMenuType);
    end;

    // POS - Internal in 18.4
    procedure GetBalanceWithTenderOffer(pTenderTypeCode: Code[10]): Decimal
    begin
        exit(POSTRANS.GetNewBalanceTenderOffer(pTenderTypeCode));
    end;

    // POS - Internal in 18.4
    procedure GetMaxSeatingCapacity(): Integer
    begin
        exit(POSTRANS.GetSeatingCapacity);
    end;

    // POS - Internal in 18.4
    procedure GetGuestStatus(): Text[30]
    begin
        if GetMaxSeatingCapacity <> 0 then
            exit(Format(GetGuests) + '/' + Format(GetMaxSeatingCapacity) + ' (' + Format(GetCovers) + ')');
        exit(Format(GetGuests) + '/' + Format(GetCovers));
    end;

    // POS - Internal in 18.4
    procedure GetContactID(): Code[20]
    begin
        exit(POSTRANS.GetContactID);
    end;

    // POS - Internal in 18.4
    procedure SetCurrentLine(var NewRec: Record "LSC POS Trans. Line")
    begin
        POSTRANS.SetCurrentLine(NewRec);
    end;

    // POS - Internal in 18.4
    procedure SetCurrentLineNo(pLineNo: Integer)
    begin
        POSTRANS.SetCurrentLineNo(pLineNo);
    end;

    // POS - Internal in 18.4
    procedure LogoffPressed(closePos: Boolean)
    var
        MessageText2: Text;
        OtherSessionID: Integer;
        OtherServiceTierInstance: Integer;
    begin
        POSTRANS.LogoffPressed(closePos);
        POSTRANS.InsertLogonLogoffTrans(0);
        POSTerminalInUse.ProcessLoginLogout(POSSESSION.TerminalNo, SessionId, UserId, false, false, MessageText2, OtherSessionID, OtherServiceTierInstance);
        OnAfterLogOffPressed;
    end;

    // POS - Internal in 18.4
    procedure SetPOSState(pSTATE: Code[10])
    begin
        POSTRANS.SetPOSState(pSTATE);
    end;

    // POS - Internal in 18.4
    procedure ValidateRecordIDInput(pRecordID: RecordID; pConfirmSelection: Boolean): Boolean
    begin
        exit(POSTRANS.ValidateRecordIDInput(pRecordID, pConfirmSelection));
    end;

    // POS - Internal in 18.4
    procedure ProcessBarcode(): Boolean
    begin
        exit(POSTRANS.ProcessBarcode);
    end;

    // POS - Internal in 18.4
    procedure SetHardwareProfile(ProfileID: Code[10])
    begin
        POSTRANS.SetHardwareProfile(ProfileID);
    end;

    // POS - Internal in 18.4
    procedure RefreshMgrStatus()
    begin
        OnBeforeRefreshMgrStatus();
        POSTRANS.WriteMgrStatus;
    end;

    // POS - Internal in 18.4
    procedure IsInfocodeAllowMSR(): Boolean
    begin
        exit(POSTRANS.IsInfocodeAllowMSR);
    end;

    // POS - Internal in 18.4
    procedure ProcessLookupResult(LookupID: Text)
    begin
        POSTRANS.ProcessLookupResult(LookupID);
    end;

    // POS - Internal in 18.4
    procedure ProcessNumpadResult(InputID: Text; Value: Text; ResultOK: Boolean)
    begin
        POSTRANS.ProcessNumpadResult(InputID, Value, ResultOK);
    end;

    // POS - Internal in 18.4
    procedure ProcessKeyboardResult(InputID: Text; Value: Text; ResultOK: Boolean)
    begin
        POSTRANS.ProcessKeyboardResult(InputID, Value, ResultOK);
    end;

    // POS - Internal in 18.4
    procedure ProcessCalendarResult(Payload: Text; InputValue: DateTime; ResultOK: Boolean)
    begin
        POSTRANS.ProcessCalendarResult(Payload, InputValue, ResultOK);
    end;

    // POS - Internal in 18.4
    procedure ProcessItemFinderResult()
    begin
        POSTRANS.ProcessItemFinderResult();
    end;

    // POS - Internal in 18.4
    procedure EditMemberContactOK(pCloseCommand: Text; pMemberCardNo: Text)
    begin
        POSTRANS.EditMemberContactOK(pCloseCommand, pMemberCardNo);
    end;

    // POS - Internal in 20.4
    procedure GetOrderPressed(SalesType: Code[20])
    begin
        POSTRANS.GetOrderPressed(SalesType);
    end;

    // POS - Internal in 20.4
    procedure AfterGetRecord()
    begin
        POSTRANS.AfterGetRecord();
    end;

    // POS - Internal in 20.4
    procedure Lookup(ExecuteCommand: Boolean; FormID: Code[20]; "Filter": Code[29])
    begin
        POSTRANS.LookUp(ExecuteCommand, FormID, "Filter");
    end;

    // POS - Internal in 18.4
    procedure ProcessPasswordChangeInput(payloadText: Text; var pStaffID: Text; var pPassword: Text; var pWorkshift: Text): Boolean
    var
        Staff: Record "LSC Staff";
        PayloadUtil: Codeunit "LSC POS Payload Util";
        TSUtil: Codeunit "LSC POS Trans. Server Utility";
        PosCtrl: Codeunit "LSC POS Control Interface";
        NewPassword: array[2] of Text;
        Handled: Boolean;
        PasswordsDoNotMatchMsg: Label 'Passwords do not match';
        PleaseSelectNewPwsMsg: Label 'Please select a NEW password.';
    begin
        PayloadUtil.LoadPayloadFromText(payloadText);
        if PayloadUtil.GetIdentity() <> Format("LSC POS Panel Id"::"#PASSWORDCHANGE") then
            exit(true); //? something unexpected...

        if not Staff.Get(PayloadUtil.GetValue('STAFFID')) then
            exit(true); //? something unexpected...

        NewPassword[1] := PosCtrl.GetInputText(Format("LSC POS Input Control Id"::"#PASSWORDNEW"));
        NewPassword[2] := PosCtrl.GetInputText(Format("LSC POS Input Control Id"::"#PASSWORDCONFIRM"));

        //Make sure password is confirmed correctly
        if NewPassword[1] <> NewPassword[2] then begin
            PosCtrl.PosMessage(PasswordsDoNotMatchMsg);
            exit(false);
        end;

        //Make sure password was changed
        if Staff.ScramblePassWord(NewPassword[1]) = PayloadUtil.GetValue('ORGPASS') then begin //SAME AS BEFORE
            PosCtrl.PosMessage(PleaseSelectNewPwsMsg);
            exit(false);
        end;

        OnBeforeValidateNewPassword(NewPassword[1], Handled, Staff.ID);
        if Handled then
            exit;
        Staff.Validate(Password, NewPassword[1]);
        Staff."Change Password" := false;
        if not Staff.Modify(true) then begin
            MessageBeep(GetLastErrorText);
            exit(false);
        end;

        OnAfterStaffPasswordChange(Staff);

        if POSSESSION.FunctionalityProfile."TS Staff" then begin
            Commit;
            if not (TSUtil.UpdateStaff(Staff)) then;
        end;

        pStaffID := PayloadUtil.GetValue('STAFFID');
        pWorkshift := PayloadUtil.GetValue('WORKSHIFT');
        pPassword := NewPassword[1];
        exit(true);
    end;

    // POS - Internal in 18.4
    procedure GetNetAmount(): Decimal
    begin
        exit(POSTRANS.GetTotalNetAmount);
    end;

    // POS - Internal in 18.4
    procedure ItemLine(ToSalesMenu: Boolean; ExtPrice: Boolean; FixedQty: Decimal; ParentLineIn: Integer; VarCodeIn: Code[10]; FixMixMatch: Code[20]; FromInfocode: Code[20]; FromSubcode: Code[20]; FromEntryNo: Integer; FromSelQty: Decimal)
    begin
        POSTRANS.ItemLine(ToSalesMenu, ExtPrice, FixedQty, ParentLineIn, VarCodeIn, FixMixMatch, FromInfocode, FromSubcode, FromEntryNo, FromSelQty);
    end;

    procedure TD_DuFloatEntryV2(): Boolean
    begin
        exit(POSTRANS.TD_DuFloatEntry);
    end;

    procedure TransactionTendered()
    begin
        POSTRANS.TransactionTendered();
    end;

    procedure DiscPrPressed(Value: Text[30])
    begin
        POSTRANS.DiscPrPressed(Value);
    end;

    procedure DiscAmPressed(Value: Text[30]; PayAmount: Boolean)
    begin
        POSTRANS.DiscAmPressed(Value, PayAmount);
    end;

    procedure TotDiscAmPressed(Value: Text[30]; TotAmount: Boolean; InfocodeCheck: Boolean)
    begin
        POSTRANS.TotDiscAmPressed(Value, TotAmount, InfocodeCheck);
    end;

    procedure TotDiscPrPressed(Value: Text[30]; InfocodeCheck: Boolean)
    begin
        POSTRANS.TotDiscPrPressed(Value, InfocodeCheck);
    end;

    procedure ChangeQtyPressed(Value: Text[30])
    begin
        POSTRANS.ChangeQtyPressed(Value);
    end;

    procedure UpdateQty(UpdLineRec: Record "LSC POS Trans. Line"; UpdFactor: Decimal)
    begin
        POSTRANS.UpdateQty(UpdLineRec, UpdFactor);
    end;

    procedure ValidateQuantity(NewQuantity: Decimal; Line: Record "LSC POS Trans. Line"): Boolean
    begin
        exit(POSTRANS.ValidateQuantity(NewQuantity, Line));
    end;

    procedure CheckInfoCode(Module: Code[10]): Boolean
    begin
        exit(POSTRANS.CheckInfoCode(Module));
    end;

    procedure ValidateInfocode(Requested: Enum "LSC POS Trans. Request Infoc."; InfocodeOnHeader: Boolean; OneSubcode: Boolean): Boolean
    begin
        exit(POSTRANS.ValidateInfocode(Requested, InfocodeOnHeader, OneSubcode));
    end;

    procedure RemoveCouponDiscount(var POSTransLine: Record "LSC POS Trans. Line"): Boolean
    begin
        exit(POSTRANS.RemoveCouponDiscount(POSTransLine));
    end;

    procedure CheckBillPrinted(): Boolean
    begin
        exit(POSTRANS.CheckBillPrinted());
    end;

    procedure VoidTransaction()
    begin
        POSTRANS.VoidTransaction();
    end;

    procedure InitTransPostingState(ReceiptNo: Code[20]; PostingSource: Integer)
    var
        POSTransPostingState: Record "LSC POS Trans. Posting State";
    begin
        POSTransPostingState.Init;
        POSTransPostingState."Receipt No." := ReceiptNo;
        POSTransPostingState."Posting Source" := PostingSource;
        POSTransPostingState."Posting State" := POSTransPostingState."Posting State"::"Error Checking";
        POSTransPostingState.Insert(true);
    end;

    procedure SetTransPostingState(ReceiptNo: Code[20]; PostingSource: Integer)
    var
        POSTransPostingState: Record "LSC POS Trans. Posting State";
    begin
        if not POSTransPostingState.Get(ReceiptNo) then begin
            InitTransPostingState(ReceiptNo, PostingSource);
            exit;
        end;
        POSTransPostingState."Posting Source" := PostingSource;
        POSTransPostingState."Posting State" := POSTransPostingState."Posting State"::"Error Checking";
        POSTransPostingState.Modify(true);
    end;

    procedure POSExchangeFCYToLCY(Date: Date; POSCurrencyCode: Code[10]; Amount: Decimal): Decimal
    begin
        exit(POSExchangerateConversion.POSExchangeFCYToLCY(Date, POSCurrencyCode, Amount));
    end;

    procedure POSExchangeLCYToFCY(Date: Date; POSCurrencyCode: Code[10]; Amount: Decimal): Decimal
    begin
        exit(POSExchangerateConversion.POSExchangeLCYToFCY(Date, POSCurrencyCode, Amount));
    end;

    procedure ClearOfferBuffer()
    begin
        POSFunctions.ClearOfferBuffer();
    end;

    procedure InitTrackingInstanceID(var pPOSTrans: Record "LSC POS Transaction")
    begin
        POSFunctions.InitTrackingInstanceID(pPOSTrans);
    end;

    procedure InitReusedTrans(var ExistingPosTrans: Record "LSC POS Transaction"; ShiftNo: Code[1]; SetSalesType: Code[20]; TableNo: Integer; TrainingActive: Boolean; TableDescr: Text) NewSlipNo: Code[20]
    begin
        exit(POSFunctions.InitReusedTrans(ExistingPosTrans, ShiftNo, SetSalesType, TableNo, TrainingActive, TableDescr));
    end;

    procedure InsertTransInUseOnPos(ReceiptNo: Code[20]; InUseOnPos: Code[10]; CommitOk: Boolean; Lock: Boolean): Boolean
    begin
        exit(POSFunctions.InsertTransInUseOnPos(ReceiptNo, InUseOnPos, CommitOk, Lock));
    end;

    procedure FindVariant(var PosVariant: Record "Item Variant"; var ItemNo: Code[20]): Integer
    begin
        exit(POSFunctions.FindVariant(PosVariant, ItemNo));
    end;

    procedure GetSuggestedQty(var Item: Record Item): Decimal
    begin
        exit(POSFunctions.GetSuggestedQty(Item));
    end;

    [Obsolete('Not used, use LSC POS Formatting instead', '26.0')]
    procedure AdjustAmount(var Value: Decimal)
    var
        Formatting: Codeunit "LSC POS Formatting";
    begin
        Formatting.AdjustAmount(Value);
    end;

    procedure UseBackgroundSession(): Boolean
    begin
        exit(POSFunctions.UseBackgroundSession());
    end;

    procedure ValidateTender(TenderType: Record "LSC Tender Type"; Total: Decimal; Balance: Decimal; Payment: Decimal; RefundSale: Boolean; ManualInput: Boolean; var MessageTxt: Text): Boolean
    begin
        exit(POSFunctions.ValidateTender(TenderType, Total, Balance, Payment, RefundSale, ManualInput, MessageTxt));
    end;

    procedure PadCardNo(pText: Text[30]): Text[22]
    begin
        exit(POSFunctions.PadCardNo(pText));
    end;

    procedure GetMemberPointBalance(): Decimal
    begin
        exit(POSFunctions.GetMemberPointBalance());
    end;

    procedure PointsUsedInTransaction(ExcludeLineNo: Integer): Decimal
    begin
        exit(POSFunctions.PointsUsedInTransaction(ExcludeLineNo));
    end;

    procedure GetMemberCustomerDiscountGroup(): Code[10]
    begin
        exit(POSFunctions.GetMemberCustomerDiscountGroup());
    end;

    procedure GetMemberPriceGroup(): Code[10]
    begin
        exit(POSFunctions.GetMemberPriceGroup());
    end;

    procedure ClearPosTransLineOffers(var pPosTransLine: Record "LSC POS Trans. Line")
    begin
        POSFunctions.ClearPosTransLineOffers(pPosTransLine);
    end;

    procedure AddPosTransLineOffers(var pPosTransLine: Record "LSC POS Trans. Line")
    begin
        POSFunctions.AddPosTransLineOffers(pPosTransLine);
    end;

    procedure IsInPaymentState(): Boolean
    begin
        exit(POSFunctions.IsInPaymentState());
    end;

    procedure POSSalesTransExistInStore(StoreNo: Code[10]): Integer
    begin
        exit(POSFunctions.POSSalesTransExistInStore(StoreNo));
    end;

    procedure ChangeGenBusPostingGroup(POSTransaction: Record "LSC POS Transaction")
    begin
        POSFunctions.ChangeGenBusPostingGroup(POSTransaction);
    end;

    procedure GetCustomerOrderAmountFromPOSTransaction(var POSTransaction_p: Record "LSC POS Transaction" temporary): Decimal
    begin
        exit(POSFunctions.GetCustomerOrderAmountFromPOSTransaction(POSTransaction_p));
    end;

    procedure GetStatementCode(): Code[20]
    begin
        exit(POSFunctions.GetStatementCode());
    end;

    procedure UpdateSerialLotInvLookup(var pPOSTransLine: Record "LSC POS Trans. Line"; pItemTrackingCode: Code[10]; var pErrorText: Text[250]): Boolean
    begin
        exit(POSFunctions.UpdateSerialLotInvLookup(pPOSTransLine, pItemTrackingCode, pErrorText));
    end;

    procedure ViewCustomerEx(pCustomerNoInp: Text; OkPressed: Boolean)
    begin
        POSTRANS.ViewCustomerEx(pCustomerNoInp, OkPressed);
    end;

    procedure ChangeStaff(KeyValue: Text[30])
    begin
        POSTRANS.ChangeStaff(KeyValue);
    end;

    procedure MultiplyPressed(Value: text[30])
    begin
        POSTRANS.MultiplyPressed(Value);
    end;

    procedure MultiplyQty()
    begin
        POSTRANS.MultiplyQty();
    end;

    local procedure TransactionRfid(): Interface "LSC ITransactionRFID"
    begin
        exit(ServiceLocator.TransactionRfid());
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterLoginEx()
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterLogOffPressed()
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeValidateNewPassword(newPassword: Text; var Handled: Boolean; StaffID: Code[20])
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeRefreshMgrStatus()
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterStaffPasswordChange(Staff: Record "LSC Staff")
    begin
    end;

    [IntegrationEvent(false, false)]
    internal procedure OnBeforeShowItemInfo(var Item: Record Item; var ItemFound: Boolean; var POSTransLine: Record "LSC POS Trans. Line"; var IsHandled: Boolean);
    begin
    end;

    [IntegrationEvent(false, false)]
    internal procedure OnBeforeSetStaffID(Manager: Boolean; TmpStaff: Record "LSC Staff" temporary; var IsHandled: Boolean)
    begin
    end;
}
