codeunit 10015808 "LSC Activity Integrations"
{
    trigger OnRun()
    var
        StaffManagementEmployee: Record "LSC STAFF Employee";
        ActivityLocation: Record "LSC Activity Location";
    begin

        ActivityLocation.GET(LSActivitiesFunctions.ReturnUserLocation());
        StaffManagementEmployee.SETRANGE("Work Location", ActivityLocation."Work Location");
        PAGE.RUNMODAL(10015097, StaffManagementEmployee);
    end;

    var
        LSActivitiesFunctions: Codeunit "LSC Activities Functions";
        Txt1: Label 'Do you want to post consumption ?';
        Txt2: Label 'Do you want to create ';
        Txt3: Label 'Cancelled activity';
        Txt4: Label 'You must confirm (or cancel) reservation: %1 %2  before you can post this invoice';
        Txt5: Label '- Total deposits';
        LSActivitySupportFunctions: Codeunit "LSC ACT Support Functions";
        Txt6: Label '+ Additional POS Sales';

    [EventSubscriber(ObjectType::Table, Database::"LSC STAFF Employee", OnAfterModifyEvent, '', true, false)]
    local procedure UpdateResourceFromEmployee(var Rec: Record "LSC STAFF Employee"; var xRec: Record "LSC STAFF Employee"; RunTrigger: Boolean)
    var
        ActivityResource: Record "LSC Activity Resource";
        ActivityResourceGroup: Record "LSC Activity Resource Group";
    begin
        if ActivityResource.Get(Rec."No.") then
            if ActivityResourceGroup.Get(ActivityResource."Resource Group") then
                if ActivityResourceGroup.Type = ActivityResourceGroup.Type::Human then begin
                    ActivityResource.Description := Rec."First Name" + ' ' + Rec."Last Name";
                    ActivityResource.Gender := Rec.Gender;
                    ActivityResource."Phone No." := Rec."Mobile Phone No.";
                    ActivityResource."E-Mail" := Rec."E-Mail";
                    ActivityResource.Modify(true);
                end;
    end;

    internal procedure CreateEmployees(ResourceGroup: Code[20])
    var
        StaffEmployees: Record "LSC STAFF Employee";
        ActivityResources: Record "LSC Activity Resource";
        ConfirmTxt: Label 'Are you sure you want to create new employees based on resource group: ';
        ActivityLocation: Record "LSC Activity Location";
        Counter: Integer;
        FinishTxt: Label '%1 number of employee(s) created';
    begin
        if not Confirm(ConfirmTxt + ResourceGroup) then
            exit;

        ActivityResources.SetRange("Resource Group", ResourceGroup);
        if ActivityResources.FindSet() then
            repeat
                if not StaffEmployees.Get(ActivityResources."Resource No.") then begin

                    StaffEmployees.Init();
                    StaffEmployees."No." := ActivityResources."Resource No.";
                    Name2FirstNameLastName(ActivityResources.Description, StaffEmployees."First Name", StaffEmployees."Last Name");
                    StaffEmployees.Validate("First Name");
                    if ActivityLocation.Get(ActivityResources."Fixed Location") then
                        if ActivityLocation."Work Location" <> '' then
                            StaffEmployees.Validate("Work Location", ActivityLocation."Work Location");

                    StaffEmployees.Gender := ActivityResources.Gender;
                    StaffEmployees."Mobile Phone No." := ActivityResources."Phone No.";
                    StaffEmployees."E-Mail" := ActivityResources."E-Mail";
                    StaffEmployees.Insert(true);
                    Counter := Counter + 1;
                end;
            until ActivityResources.Next() = 0;

        Message(StrSubstNo(FinishTxt, Counter));
    end;

    internal procedure Name2FirstNameLastName(FullName: Text; var FirstName: Text[30]; var LastName: Text[30]);
    var
        PosOfSpace: Integer;
    begin
        FirstName := '';
        LastName := '';
        PosOfSpace := StrPos(FullName, ',');
        if PosOfSpace > 1 then begin
            if CopyStr(FullName, PosOfSpace - 1, 1) = ',' then begin
                FirstName := CopyStr(FullName, PosOfSpace + 1, MaxStrLen(FirstName));
                LastName := CopyStr(FullName, 1, PosOfSpace - 2);
            end
            else begin
                FirstName := CopyStr(FullName, 1, PosOfSpace - 1);
                LastName := CopyStr(FullName, PosOfSpace + 1, MaxStrLen(LastName));
            end;
        end
        else
            FirstName := CopyStr(FullName, 1, MaxStrLen(FirstName));
    end;

    internal procedure CreateItem(var ActivityProduct: Record "LSC Activity Product"): Code[20]
    var
        DefRec: Record "LSC Item Default Settings";
        NewRec: Record Item;
        ActivityType: Record "LSC Activity Type";
        ItemCreation: Codeunit "LSC Item Creation";
        ItemDefRec: Record Item;
        LSActivitiesSetup: Record "LSC Activity Setup";
    begin
        LSActivitiesSetup.Get();

        ActivityProduct.TestField("Activity Type");
        ActivityType.Get(ActivityProduct."Activity Type");
        ActivityType.TestField("New Posting Item (Template)");

        if ActivityType."New Posting Item (Template)" <> '' then begin

            NewRec.Init();
            ItemDefRec.Get(ActivityType."New Posting Item (Template)");

            NewRec := ItemDefRec;
            NewRec.Validate(Description, ActivityProduct.Description);
            NewRec."No." := '';
            NewRec."Unit Cost" := 0;
            NewRec."Standard Cost" := 0;
            NewRec."Last Direct Cost" := 0;
            NewRec."Indirect Cost %" := 0;

            if LSActivitiesSetup."Retail Item Creation" = LSActivitiesSetup."Retail Item Creation"::"Same Item no./Product No." then
                NewRec."No." := ActivityProduct."No."
            else
                NewRec."No. Series" := DefRec."Create Items No. Series";

            NewRec.Insert(true);

            if ItemDefRec."Item Category Code" <> '' then
                NewRec.Validate("Item Category Code", ItemDefRec."Item Category Code");

            if ItemDefRec."LSC Retail Product Code" <> '' then
                NewRec.Validate("LSC Retail Product Code", ItemDefRec."LSC Retail Product Code");

            NewRec.Modify(true);

            DefRec.Init();
            DefRec."Default Item" := ActivityType."New Posting Item (Template)";
            DefRec."Use Default Distribution" := false;
            DefRec."Use Default Attributes" := true;

            ItemCreation.CreateExtraTables(DefRec, NewRec, false);

            ActivityProduct.Validate("Posting Item", NewRec."No.");
            ActivityProduct.Modify();

            exit(NewRec."No.");
        end;
    end;

    procedure ReturnEmployeeAvailability(ResourceNo: Code[20]; FromDate: Date; ToDate: Date; FromTime: Time; ToTime: Time; ActivityLocation: Code[20]): Integer
    var
        StaffManagementEmployee: Record "LSC STAFF Employee";
        ActivityResource: Record "LSC Activity Resource";
        ActivityLocationRec: Record "LSC Activity Location";
        i: Integer;
        Schedule: Record "LSC Employee Roster Schedule";
        Available: Boolean;
        StaffManagementFunctions: Codeunit "LSC STAFF Functions";
        MsgText: Text;
        UnavailableSign: Text;
    begin
        if ToDate = 0D then
            ToDate := FromDate;

        if (ToDate <> 0D) and (FromDate <> 0D) then
            if ActivityLocationRec.Get(ActivityLocation) then
                if ActivityLocationRec."Work Location" <> '' then
                    if ActivityResource.Get(ResourceNo) then
                        if StaffManagementEmployee.Get(ResourceNo) then begin

                            for i := 0 to (ToDate - FromDate) do begin

                                Schedule.SetCurrentkey("Employee No.", "Schedule Date", "Work Location", "Entry Type", "Schedule Status");
                                Schedule.SetRange("Employee No.", StaffManagementEmployee."No.");
                                Schedule.SetRange("Schedule Date", FromDate + i);
                                Schedule.SetRange("Work Location", ActivityLocationRec."Work Location");
                                Schedule.SetRange("Entry Type", Schedule."Entry Type"::"In Schedule");
                                Schedule.SetRange("Schedule Status", Schedule."Schedule Status"::Confirmed);

                                Available := false;

                                if Schedule.FindSet() then
                                    repeat
                                        if (Schedule."From Time" <= FromTime) and (Schedule."To Time" >= ToTime) then
                                            Available := true;
                                    until (Schedule.Next() = 0) or (Available);

                                if not Available then
                                    exit(0)

                                else
                                    if NOT StaffManagementFunctions.CheckAvailableByTime(StaffManagementEmployee."No.", FromDate + i, ActivityLocationRec."Work Location", '', '', MsgText, UnavailableSign, FromTime, ToTime) then
                                        exit(0);
                            end;
                            exit(1);
                        end;
        exit(0);
    end;

    procedure ReturnEmployeeWorkingTime(ResourceNo: Code[20]; Location: Code[20]; WorkingDate: Date; var WorkingTimeFrom: Time; var WorkingTimeTo: Time): Boolean
    var
        StaffManagementEmployee: Record "LSC STAFF Employee";
        Schedule: Record "LSC Employee Roster Schedule";
        ActivityLocationRec: Record "LSC Activity Location";
    begin
        WorkingTimeFrom := 0T;
        WorkingTimeTo := 0T;

        if not StaffManagementEmployee.Get(ResourceNo) then
            exit(false);

        if ActivityLocationRec.Get(Location) then
            if ActivityLocationRec."Work Location" <> '' then begin

                Schedule.SetCurrentkey("Employee No.", "Schedule Date", "Work Location", "Entry Type", "Schedule Status");
                Schedule.SetRange("Employee No.", StaffManagementEmployee."No.");
                Schedule.SetRange("Schedule Date", WorkingDate);
                Schedule.SetRange("Work Location", ActivityLocationRec."Work Location");
                Schedule.SetRange("Entry Type", Schedule."Entry Type"::"In Schedule");
                Schedule.SetRange("Schedule Status", Schedule."Schedule Status"::Confirmed);

                if Schedule.FindFirst() then begin
                    WorkingTimeFrom := Schedule."From Time";
                    WorkingTimeTo := Schedule."To Time";
                    exit(true);
                end;
            end;
        exit(false);
    end;

    procedure PostConsumption(ReservationNo: Code[20]; ReservationLine: Integer; Dialog: Boolean; PostingType: Option Posting,Crediting)
    var
        ItemJnlPostLine: Codeunit "Item Jnl.-Post Line";
        Store: Record "LSC Store";
        ActivityLocation: Record "LSC Activity Location";
        ItemJournalLine: Record "Item Journal Line";
        ActivityAdditionalItem: Record "LSC Activity Additional Item";
        ActivityReservation: Record "LSC Activity Reservation";
    begin
        if Dialog then
            if not Confirm(Txt1) then
                exit;

        ActivityReservation.SetRange("Reservation No.", ReservationNo);
        ActivityReservation.SetRange("Line No.", ReservationLine);

        if ActivityReservation.FindFirst() then begin

            ActivityLocation.Get(LSActivitiesFunctions.ReturnUserLocation());
            ActivityLocation.TestField(Store);
            Store.Get(ActivityLocation.Store);

            ActivityAdditionalItem.SetCurrentKey("Reservation No.", "Reservation Line No.");
            ActivityAdditionalItem.SetRange("Reservation No.", ActivityReservation."Reservation No.");
            ActivityAdditionalItem.SetRange("Reservation Line No.", ActivityReservation."Line No.");
            ActivityAdditionalItem.SetRange("Entry Type", ActivityAdditionalItem."Entry Type"::Consumption);

            if ActivityAdditionalItem.FindSet() then
                repeat
                    if ((PostingType = 0) and (ActivityAdditionalItem.Status = ActivityAdditionalItem.Status::Entry)) or
                       (PostingType = 1) and (ActivityAdditionalItem.Status = ActivityAdditionalItem.Status::"Consumption Posted") then begin
                        if (ActivityAdditionalItem."Product No." <> '') and (ActivityAdditionalItem.Quantity <> 0) then begin
                            ItemJournalLine.Init();
                            ItemJournalLine.Validate("Item No.", ActivityAdditionalItem."Product No.");
                            ItemJournalLine.Validate("Posting Date", Today);

                            if ActivityAdditionalItem.Quantity > 0 then
                                case PostingType of
                                    0:
                                        ItemJournalLine.Validate("Entry Type", ItemJournalLine."Entry Type"::"Negative Adjmt.");
                                    1:
                                        ItemJournalLine.Validate("Entry Type", ItemJournalLine."Entry Type"::"Positive Adjmt.");
                                end
                            else
                                case PostingType of
                                    1:
                                        ItemJournalLine.Validate("Entry Type", ItemJournalLine."Entry Type"::"Negative Adjmt.");
                                    0:
                                        ItemJournalLine.Validate("Entry Type", ItemJournalLine."Entry Type"::"Positive Adjmt.");
                                end;

                            ItemJournalLine."Document No." := ActivityReservation."Activity No.";
                            if ActivityAdditionalItem."Variant Code" <> '' then
                                ItemJournalLine.Validate("Variant Code", ActivityAdditionalItem."Variant Code");
                            ItemJournalLine.Validate("Location Code", Store."Location Code");
                            if ActivityAdditionalItem."Unit of Measure Code" <> '' then
                                ItemJournalLine.Validate("Unit of Measure Code", ActivityAdditionalItem."Unit of Measure Code");

                            ItemJournalLine.Validate(Quantity, Abs(ActivityAdditionalItem.Quantity));
                            ItemJnlPostLine.Run(ItemJournalLine);

                            if PostingType = 0 then
                                ActivityAdditionalItem.Status := ActivityAdditionalItem.Status::"Consumption Posted"
                            else
                                ActivityAdditionalItem.Status := ActivityAdditionalItem.Status::Entry;
                            ActivityAdditionalItem."Stock Location" := Store."Location Code";
                            ActivityAdditionalItem.Modify();
                        end;
                    end;
                until ActivityAdditionalItem.Next() = 0;
        end;
    end;

    procedure PostRoleBudgetAdjustments(ActivityNo: Code[20]; PostingType: Option Confirm,Cancel)
    var
        ActivityRoleBudgetAdjustm: Record "LSC ACT Role Budget Adjustm.";
        RoleBudgetAdjustments: Record "LSC Role Budget Adjustments";
    begin
        if PostingType = PostingType::Cancel then begin
            RoleBudgetAdjustments.SetRange(Code, ActivityNo);
            if RoleBudgetAdjustments.FindSet() then
                repeat
                    if RoleBudgetAdjustments.Done then begin
                        RoleBudgetAdjustments."Resource Adjustment" := -RoleBudgetAdjustments."Resource Adjustment";
                        RoleBudgetAdjustments.Done := false;
                        RoleBudgetAdjustments.Description := Txt3;
                        RoleBudgetAdjustments.Modify();
                    end else
                        RoleBudgetAdjustments.Delete();

                until RoleBudgetAdjustments.Next() = 0;
        end
        else begin
            ActivityRoleBudgetAdjustm.SetRange("Activity No.", ActivityNo);
            if ActivityRoleBudgetAdjustm.FindSet() then
                repeat
                    if ActivityRoleBudgetAdjustm."Work Date" >= Today then begin
                        RoleBudgetAdjustments.SetRange(Code, ActivityNo);
                        RoleBudgetAdjustments.SetRange("Work Location", ActivityRoleBudgetAdjustm."Work Location");
                        RoleBudgetAdjustments.SetRange("Work Role", ActivityRoleBudgetAdjustm."Work Role");
                        RoleBudgetAdjustments.SetRange("Work Shift", ActivityRoleBudgetAdjustm."Work Shift");
                        RoleBudgetAdjustments.SetRange("Work Date", ActivityRoleBudgetAdjustm."Work Date");
                        if RoleBudgetAdjustments.FindFirst() then begin
                            if not RoleBudgetAdjustments.Done then
                                RoleBudgetAdjustments."Resource Adjustment" := ActivityRoleBudgetAdjustm."Employees Requested"
                            else begin
                                RoleBudgetAdjustments."Resource Adjustment" := ActivityRoleBudgetAdjustm."Employees Requested" - RoleBudgetAdjustments."Resource Adjustment";
                                RoleBudgetAdjustments.Done := false;
                            end;

                            RoleBudgetAdjustments.Description := CopyStr(ActivityRoleBudgetAdjustm.Comment, 1, 30);
                            RoleBudgetAdjustments.Modify();
                        end else begin
                            RoleBudgetAdjustments.Init();
                            RoleBudgetAdjustments.Code := ActivityNo;
                            RoleBudgetAdjustments."Work Location" := ActivityRoleBudgetAdjustm."Work Location";
                            RoleBudgetAdjustments."Work Role" := ActivityRoleBudgetAdjustm."Work Role";
                            RoleBudgetAdjustments."Work Shift" := ActivityRoleBudgetAdjustm."Work Shift";
                            RoleBudgetAdjustments."Work Date" := ActivityRoleBudgetAdjustm."Work Date";
                            RoleBudgetAdjustments."Resource Adjustment" := ActivityRoleBudgetAdjustm."Employees Requested";
                            RoleBudgetAdjustments.Description := CopyStr(ActivityRoleBudgetAdjustm.Comment, 1, 30);
                            RoleBudgetAdjustments.Insert();
                        end;
                    end;
                until ActivityRoleBudgetAdjustm.Next() = 0;
        end;
    end;

    internal procedure CreateMembershipItem(var MembershipType: Record "LSC Membership Type"): Code[20]
    var
        DefRec: Record "LSC Item Default Settings";
        NewRec: Record Item;
        ItemCreation: Codeunit "LSC Item Creation";
        ItemDefRec: Record Item;
        MembershipSetup: Record "LSC Membership Setup";
    begin
        MembershipSetup.Get();
        MembershipSetup.TestField("New Posting Item (Template)");

        NewRec.Init();
        ItemDefRec.Get(MembershipSetup."New Posting Item (Template)");

        NewRec := ItemDefRec;
        NewRec.Validate(Description, MembershipType.Description);
        NewRec."No." := '';
        NewRec."Unit Cost" := 0;
        NewRec."Standard Cost" := 0;
        NewRec."Last Direct Cost" := 0;
        NewRec."Indirect Cost %" := 0;
        NewRec."No. Series" := DefRec."Create Items No. Series";

        NewRec.Insert(true);

        if ItemDefRec."Item Category Code" <> '' then
            NewRec.Validate("Item Category Code", ItemDefRec."Item Category Code");

        if ItemDefRec."LSC Retail Product Code" <> '' then
            NewRec.Validate("LSC Retail Product Code", ItemDefRec."LSC Retail Product Code");

        NewRec.Modify(true);

        DefRec.Init();
        DefRec."Default Item" := MembershipSetup."New Posting Item (Template)";
        DefRec."Use Default Distribution" := false;
        DefRec."Use Default Attributes" := true;

        ItemCreation.CreateExtraTables(DefRec, NewRec, false);

        MembershipType.Validate("Posting Item", NewRec."No.");
        MembershipType.Modify();

        exit(NewRec."No.");
    end;

    internal procedure ClearScheduleEntriesByRoster(RosterNo: Code[20])
    var
        Capacity: Record "LSC Activity Resource Capacity";
        Unavailability: Record "LSC Resource Unavailability";
    begin
        if RosterNo = '' then
            exit;

        Capacity.SetRange("Roster No.", RosterNo);
        Capacity.DeleteAll();
        Unavailability.SetRange("Roster No.", RosterNo);
        Unavailability.DeleteAll();
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC Staff Functions", OnBeforeConfirmSchedule, '', true, false)]
    internal procedure OnBeforeConfirmSchedule(var Schedule: Record "LSC STAFF Schedule"; var IsHandled: Boolean);
    begin
        ClearScheduleEntriesByRoster(Schedule."No.");
    end;

    internal procedure CreateEmployeeAvailability(RosterNo: Code[20]; EmployeeNo: Code[20]; ScheduleDate: Date)
    var
        ActResources: Record "LSC Activity Resource";
        Capacity: Record "LSC Activity Resource Capacity";
        Unavailability: Record "LSC Resource Unavailability";
        RosterSchedule: Record "LSC Employee Roster Schedule";
        Rosters: Record "LSC STAFF Schedule";
        ActivityLocation: Record "LSC Activity Location";
    begin
        if RosterNo = '' then
            RosterNo := LookupRosters();

        Rosters.Get(RosterNo);
        if Rosters.Status <> Rosters.Status::Confirmed then
            exit;

        ActivityLocation.SetRange("Work Location", Rosters."Work Location");
        if not ActivityLocation.FindFirst() then
            exit;

        ResetCapacity(Capacity, RosterNo, EmployeeNo, ScheduleDate);
        ResetUnavailability(Unavailability, RosterNo, EmployeeNo, ScheduleDate);
        SetRosterFilters(RosterSchedule, RosterNo, EmployeeNo, ScheduleDate);

        if RosterSchedule.FindSet() then
            repeat
                if ActResources.Get(RosterSchedule."Employee No.") then
                    CreateCapacityEntry(ActResources, RosterSchedule, ActivityLocation.Code, RosterNo, Capacity, Unavailability);
            until RosterSchedule.Next() = 0;
    end;

    internal procedure LookupRosters(): Code[20]
    var
        Rosters: Record "LSC STAFF Schedule";
    begin
        Rosters.Setrange("Work Location", LSActivitiesFunctions.ReturnUserLocation());
        Rosters.Setrange(Status, Rosters.Status::Confirmed);
        if Page.RunModal(0, Rosters) = Action::LookupOK then
            exit(Rosters."No.");
    end;

    internal procedure SetRosterFilters(var RosterSchedule: Record "LSC Employee Roster Schedule"; RosterNo: Code[20]; EmployeeNo: Code[20]; ScheduleDate: Date)
    begin
        RosterSchedule.SetCurrentKey("Plan No.", "Employee No.", "Schedule Date");
        RosterSchedule.SetRange("Plan No.", RosterNo);
        if ScheduleDate <> 0D then
            RosterSchedule.SetRange("Schedule Date", ScheduleDate);
        if EmployeeNo <> '' then
            RosterSchedule.SetRange("Employee No.", EmployeeNo);

        RosterSchedule.SetRange("Entry Type", RosterSchedule."Entry Type"::"In Schedule");
        RosterSchedule.SetRange("Unavailability Type", '');
    end;

    internal procedure CreateCapacityEntry(var ActResources: Record "LSC Activity Resource"; var RosterSchedule: Record "LSC Employee Roster Schedule"; LocationCode: Code[20]; RosterNo: Code[20]; var Capacity: Record "LSC Activity Resource Capacity"; var Unavailability: Record "LSC Resource Unavailability")
    begin
        if ActResources."Resource Type" <> ActResources."Resource Type"::Human then
            exit;

        if ActResources."Capacity Based On" <> ActResources."Capacity Based On"::"Resource Schedule" then
            exit;

        Capacity.Init();
        Capacity."Resource No." := ActResources."Resource No.";
        Capacity."Availability Date" := RosterSchedule."Schedule Date";
        Capacity."Availability Time (From)" := RosterSchedule."From Time";
        Capacity."Availability Time (To)" := RosterSchedule."To Time";
        Capacity.Weekday := Date2DWY(RosterSchedule."Schedule Date", 1);
        Capacity.Location := LocationCode;
        Capacity."Roster No." := RosterNo;
        Capacity.Insert(true);

        CreateUnavailabilityEntry(ActResources, RosterSchedule, Unavailability, RosterNo);
    end;

    internal procedure ResetCapacity(var Capacity: Record "LSC Activity Resource Capacity"; RosterNo: Code[20]; EmployeeNo: Code[20]; ScheduleDate: Date)
    begin
        Capacity.SetRange("Roster No.", RosterNo);
        if ScheduleDate <> 0D then
            Capacity.SetRange("Availability Date", ScheduleDate);

        if EmployeeNo <> '' then
            Capacity.SetRange("Resource No.", EmployeeNo);

        Capacity.DeleteAll();
    end;

    internal procedure ResetUnavailability(var Unavailability: Record "LSC Resource Unavailability"; RosterNo: Code[20]; EmployeeNo: Code[20]; ScheduleDate: Date);
    begin
        Unavailability.SetRange("Roster No.", RosterNo);
        if ScheduleDate <> 0D then
            Unavailability.SetRange("Date From", ScheduleDate);

        if EmployeeNo <> '' then
            Unavailability.Setrange("Resource No.", EmployeeNo);

        Unavailability.DeleteAll();
    end;

    internal procedure CreateUnavailabilityEntry(var ActResources: Record "LSC Activity Resource"; var RosterSchedule: Record "LSC Employee Roster Schedule"; var Unavailability: Record "LSC Resource Unavailability"; RosterNo: Code[20])
    var
        BreakEntries: Record "LSC Shift Break Settings";
        BreakTxt: Label 'Break';
    begin
        BreakEntries.Setrange("Work Shift", RosterSchedule."Work Shift");
        BreakEntries.Setrange(Day, Date2DWY(RosterSchedule."Schedule Date", 1) - 1);
        BreakEntries.SetRange("Work Role", RosterSchedule."Work Role");

        if BreakEntries.IsEmpty then
            BreakEntries.SetRange("Work Role", '');

        if BreakEntries.FindSet() then
            repeat
                Unavailability.Init();
                Unavailability."Date From" := RosterSchedule."Schedule Date";
                Unavailability."Date To" := RosterSchedule."Schedule Date";
                Unavailability."Resource No." := ActResources."Resource No.";
                Unavailability."Time From" := BreakEntries."From Time";
                Unavailability."Time To" := BreakEntries."To Time";
                Unavailability."Roster No." := RosterNo;
                if BreakEntries.Description = '' then
                    Unavailability.Comment := BreakTxt
                else
                    Unavailability.Comment := BreakEntries.Description;
                Unavailability.Insert(true);
            until BreakEntries.Next() = 0;
    end;

    [EventSubscriber(ObjectType::Table, Database::"Sales Line", OnAfterDeleteEvent, '', true, false)]
    local procedure OnAfterDeleteSalesLine(var Rec: Record "Sales Line"; RunTrigger: Boolean)
    var
        DepositSchedule: Record "LSC Act Deposit Due";
    begin
        if Rec."Document No." = '' then
            exit;

        if Rec."Document Type" <> Rec."Document Type"::Invoice then
            exit;

        if not RunTrigger then
            exit;

        if not FindDepositScheduleBasedOnSalesLine(Rec, DepositSchedule) then
            exit;

        ClearDepositSchedule(DepositSchedule);
        RemoveDepositTransactionBasedOnSalesLine(Rec, DepositSchedule."Reservation No.");
    end;

    internal procedure FindDepositScheduleBasedOnSalesLine(var Rec: Record "Sales Line"; var DepositSchedule: Record "LSC Act Deposit Due"): Boolean
    begin
        if DepositSchedule.IsEmpty then
            exit;

        if Rec.Amount < 0 then begin
            DepositSchedule.SetRange("Transaction Type", DepositSchedule."Transaction Type"::Invoice);
            DepositSchedule.SetRange("Refund Transaction Type", DepositSchedule."Refund Transaction Type"::Invoice);
            DepositSchedule.SetRange("Transaction Refund", Rec."Document No.");
            DepositSchedule.SetRange("Deposit Amount", Rec."Amount Including VAT");
            if not DepositSchedule.FindFirst() then
                exit;
        end else begin
            DepositSchedule.SetRange("Transaction Type", DepositSchedule."Transaction Type"::Invoice);
            DepositSchedule.SetRange("Transaction", Rec."Document No.");
            DepositSchedule.SetRange("Transaction Line", Rec."Line No.");
            DepositSchedule.SetRange("Deposit Amount", Rec."Amount Including VAT");
            if not DepositSchedule.FindFirst() then
                exit;
        end;

        exit(true);
    end;

    internal procedure ClearDepositSchedule(var DepositSchedule: Record "LSC Act Deposit Due")
    begin
        DepositSchedule.Transaction := '';
        DepositSchedule."Transaction Line" := 0;
        DepositSchedule."Transaction Type" := DepositSchedule."Transaction Type"::POS;
        DepositSchedule.Paid := false;
        DepositSchedule.Modify(false);
    end;

    internal procedure RemoveDepositTransactionBasedOnSalesLine(var Rec: Record "Sales Line"; ReservationNo: Code[20])
    var
        ReservationTransaction: Record "LSC Reservation Transaction";
    begin
        ReservationTransaction.SetRange("Transaction Type", ReservationTransaction."Transaction Type"::Invoice);
        ReservationTransaction.SetRange("Transaction", Rec."Document No.");
        ReservationTransaction.SetRange("Transaction Line No.", Rec."Line No.");
        ReservationTransaction.SetRange("Reservation No.", ReservationNo);
        ReservationTransaction.SetRange("Entry Type", 0);
        if ReservationTransaction.FindFirst() then
            ReservationTransaction.Delete();
    end;

    procedure DoMemberContactSave(Name: Text; MobilePhone: Text; Email: Text; var AccountID: Code[20]): Code[20]
    var
        ContactCreateParametersTemp: Record "LSC Contact Create Parameters" temporary;
        ContactId: Code[20];
        ErrorText: Text;
        LSActivitySetup: Record "LSC Activity Setup";
        i: integer;
    begin
        Name := DelChr(Name, '<', ' ');
        Name := DelChr(Name, '>', ' ');

        if (Name = '') or (Email = '') then
            exit;

        LSActivitySetup.Get();

        ContactCreateParametersTemp.Init();

        ContactCreateParametersTemp.FirstName := Name;
        i := StrPos(Name, ' ');
        if i > 0 then begin
            ContactCreateParametersTemp.FirstName := CopyStr(Name, 1, i - 1);
            ContactCreateParametersTemp.LastName := DelChr(CopyStr(Name, i + 1, 100), '<', ' ');
        end;

        if ContactCreateParametersTemp.LastName <> '' then begin
            for i := 1 to StrLen(ContactCreateParametersTemp.LastName) do
                if CopyStr(ContactCreateParametersTemp.LastName, i, 1) = ' ' then
                    ContactCreateParametersTemp.MiddleName := Copystr(ContactCreateParametersTemp.LastName, 1, i - 1);

            if ContactCreateParametersTemp.MiddleName <> '' then
                ContactCreateParametersTemp.LastName := Copystr(ContactCreateParametersTemp.LastName, StrLen(ContactCreateParametersTemp.MiddleName) + 1, 100);
        end;

        ContactCreateParametersTemp.MobilePhoneNo := MobilePhone;
        ContactCreateParametersTemp.Email := CopyStr(Email, 1, 80);
        ContactCreateParametersTemp.ClubID := LSActivitySetup."Default Member Club";
        ContactCreateParametersTemp.SchemeID := LSActivitySetup."Default Scheme Code";

        MemberContactSave(ContactCreateParametersTemp, AccountID, ContactId, ErrorText);
        if ErrorText = '' then
            exit(ContactId)
        else
            Message(ErrorText);
    end;

    internal procedure MemberContactSave(ContactCreateParametersTemp: Record "LSC Contact Create Parameters" temporary; var AccountID: Code[20]; var ContactId: Code[20]; var ErrorText: Text)
    var
        ResponseCode: Code[30];
        CardID: Text;
        TotalRemainingPoints: Decimal;
        MemberAttributeValueTemp: Record "LSC Member Attribute Value" temporary;
        MemberContactCreateUtils: Codeunit LSCMemberContactCreateUtils;
        MemberContact: Record "LSC Member Contact";
    begin
        ErrorText := '';
        MemberContact.SetRange("Search E-Mail", UpperCase(ContactCreateParametersTemp.EMail));
        if MemberContact.FindFirst() then begin
            AccountID := MemberContact."Account No.";
            ContactId := MemberContact."Contact No.";
            exit;
        End;

        if ContactCreateParametersTemp.DeviceID = '' then
            ContactCreateParametersTemp.DeviceID := 'Activity';

        if ContactCreateParametersTemp."Login ID" = '' then
            ContactCreateParametersTemp."Login ID" := ContactCreateParametersTemp.Email;

        if ContactCreateParametersTemp.Password = '' then
            ContactCreateParametersTemp.Password := 'Not Set';
        ContactCreateParametersTemp.Insert();
        MemberAttributeValueTemp.Init();
        MemberContactCreateUtils.SendRequest(ResponseCode, ErrorText, ContactCreateParametersTemp, MemberAttributeValueTemp, ContactCreateParametersTemp.ClubID, ContactCreateParametersTemp.SchemeID, AccountID, ContactId, CardID, TotalRemainingPoints);
    end;

    internal procedure DoSearchName(SetName: Text): Code[20]
    var
        MemberContact: Record "LSC Member Contact";
        CheckVariable: Integer;
        DidCheck: Boolean;
        ErrorString: Label 'Did not find member as either email or mobile phone - Enter Name to continue';
    begin
        if (StrPos(SetName, '@') <> 0) and (StrPos(SetName, '.') <> 0) then begin
            MemberContact.SetRange("E-Mail", CopyStr(SetName, 1, 80));
            if MemberContact.FindFirst() then
                exit(MemberContact."Contact No.");

            DidCheck := True;
            MemberContact.SetRange("E-Mail");
        end;
        if (CopyStr(SetName, 1, 1) = '+') or (Evaluate(CheckVariable, SetName)) then begin
            MemberContact.SetRange("Mobile Phone No.", CopyStr(SetName, 1, 30));
            if MemberContact.FindFirst() then
                exit(MemberContact."Contact No.");

            DidCheck := True;
        end;
        if DidCheck then
            Error(ErrorString);
    end;

    internal procedure CheckResourceLocation(var Resource: Record "LSC Activity Resource"; CheckLocation: Code[20]): Boolean
    var
        StaffManLocations: Record "LSC STAFF Work Location/Empl.";
        StaffManEmployee: record "LSC STAFF Employee";
        ActivityLocation: Record "LSC Activity Location";
    begin
        // This function minimizes the number of resources calculated when the human resource is not assigned
        // to a specific activity location, but has setup in the staff management deciding where to be scheduled
        // So in that case, the staff management setup can be used to decide if the resource should be included or not
        // Otherwise could be problem in large implementations where all human resources have blank fixed location
        if Resource."Resource Type" <> Resource."Resource Type"::Human then
            exit(true);

        if Resource."Fixed Location" <> '' then
            exit(true);

        if not StaffManEmployee.ReadPermission then
            exit(true);

        if not StaffManEmployee.Get(Resource."Resource No.") then
            exit(true);

        if ActivityLocation.Get(CheckLocation) then begin

            if ActivityLocation."Work Location" = '' then
                exit(true);

            if StaffManEmployee."Work Location" = ActivityLocation."Work Location" then
                exit(true);

            StaffManLocations.SetRange("Staff Management Employee ID", Resource."Resource No.");
            StaffManLocations.SetRange("Work Location", ActivityLocation."Work Location");
            if not StaffManLocations.IsEmpty then
                exit(true);
        end;
    end;

    [EventSubscriber(ObjectType::Table, Database::"LSC Employee Roster Schedule", OnAfterModifyEvent, '', true, false)]
    local procedure ScheduleUpdate(var Rec: Record "LSC Employee Roster Schedule"; var xRec: Record "LSC Employee Roster Schedule"; RunTrigger: Boolean)
    begin
        if Rec.IsTemporary then
            exit;

        if (Rec."Plan No." <> '') and (Rec."Employee No." <> '') and (Rec."Schedule Date" <> 0D) then
            if Rec."Schedule Status" = Rec."Schedule Status"::Confirmed then
                CreateEmployeeAvailability(Rec."Plan No.", Rec."Employee No.", Rec."Schedule Date");
    end;

    [EventSubscriber(ObjectType::Table, Database::"LSC Employee Roster Schedule", OnAfterInsertEvent, '', true, false)]
    local procedure ScheduleInsert(var Rec: Record "LSC Employee Roster Schedule"; RunTrigger: Boolean)
    begin
        if Rec.IsTemporary then
            exit;

        if (Rec."Plan No." <> '') and (Rec."Employee No." <> '') and (Rec."Schedule Date" <> 0D) then
            if Rec."Schedule Status" = Rec."Schedule Status"::Confirmed then
                CreateEmployeeAvailability(Rec."Plan No.", Rec."Employee No.", Rec."Schedule Date");
    end;

    [EventSubscriber(ObjectType::Table, Database::"LSC Employee Roster Schedule", OnAfterDeleteEvent, '', true, false)]
    local procedure ScheduleDelete(var Rec: Record "LSC Employee Roster Schedule"; RunTrigger: Boolean)
    begin
        if Rec.IsTemporary then
            exit;

        if (Rec."Plan No." <> '') and (Rec."Employee No." <> '') and (Rec."Schedule Date" <> 0D) then
            if Rec."Schedule Status" = Rec."Schedule Status"::Confirmed then
                CreateEmployeeAvailability(Rec."Plan No.", Rec."Employee No.", Rec."Schedule Date");
    end;

    [EventSubscriber(ObjectType::Table, Database::"LSC STAFF Schedule", OnAfterDeleteEvent, '', true, false)]
    local procedure RosterDelete(var Rec: Record "LSC STAFF Schedule"; RunTrigger: Boolean)
    begin
        if RunTrigger then
            if not Rec.IsTemporary then
                ClearScheduleEntriesByRoster(Rec."No.");
    end;

    [EventSubscriber(ObjectType::Page, Page::"Doc. Attachment List Factbox", OnAfterGetRecRefFail, '', true, false)]
    local procedure DrillDown(DocumentAttachment: Record "Document Attachment"; var RecRef: RecordRef)
    var
        ActivityRes: Record "LSC Reservation";
        ActivityGroup: Record "LSC Activity Group";
    begin
        case DocumentAttachMent."Table ID" of
            Database::"LSC Reservation":
                begin
                    RecRef.Open(Database::"LSC Reservation");
                    if ActivityRes.Get(DocumentAttachMent."No.") then
                        RecRef.GetTable(ActivityRes);
                end;

            Database::"LSC Activity Group":
                begin
                    RecRef.Open(Database::"LSC Activity Group");
                    if ActivityGroup.Get(DocumentAttachMent."No.") then
                        RecRef.GetTable(ActivityGroup);
                end;
        end;
    end;

    [EventSubscriber(ObjectType::Page, Page::"Document Attachment Details", OnAfterOpenForRecRef, '', true, false)]
    local procedure OnAfterOpenForRecRef(var DocumentAttachment: Record "Document Attachment"; var RecRef: RecordRef; var FlowFieldsEditable: Boolean)
    var
        RecNo: Code[20];
        FieldRef: FieldRef;
    begin
        case RecRef.Number of
            Database::"LSC Activity Group",
            Database::"LSC Reservation":
                begin
                    FieldRef := RecRef.Field(1);
                    RecNo := FieldRef.Value;
                    DocumentAttachment.SetRange("No.", RecNo);
                    FlowFieldsEditable := false;
                end;
        end;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Data Classification Mgt.", OnGetDataPrivacyEntities, '', true, false)]
    local procedure OnGetDataPrivacyEntities(var DataPrivacyEntities: Record "Data Privacy Entities")
    begin
        if not DataPrivacyEntities.Get(10015806) then begin
            DataPrivacyEntities.Init();
            DataPrivacyEntities."Table No." := 10015806;
            DataPrivacyEntities."Key Field No." := 1;

            DataPrivacyEntities."Default Data Sensitivity" := DataPrivacyEntities."Default Data Sensitivity"::Normal;
            DataPrivacyEntities.Include := True;
            DataPrivacyEntities."Page No." := 10015809;
            DataPrivacyEntities.Insert(true);
        end;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Data Privacy Mgmt", OnCreateData, '', true, false)]
    local procedure CreateData(EntityTypeTableNo: Integer; EntityNo: Code[50]; var PackageCode: Code[20]; ActionType: Option "Export a data subject's data","Create a data privacy configuration package"; DataSensitivityOption: Option Sensitive,Personal,"Company Confidential",Normal,Unclassified)
    var

        RecRef: RecordRef;
        ActivityResource: Record "LSC Activity Resource";
        DataPrivacy: Codeunit "Data Privacy Mgmt";
    begin

        if EntityTypeTableNo = Database::"LSC Activity Resource" then begin
            RecRef.GetTable(ActivityResource);
            DataPrivacy.CreateRelatedData(RecRef, EntityTypeTableNo, EntityNo, PackageCode, ActionType, DataSensitivityOption);
        end;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Data Privacy Mgmt", OnAfterGetPackageCode, '', true, false)]
    local procedure GetPackageCode(EntityTypeTableNo: Integer; EntityNo: Code[50]; ActionType: Option "Export a data subject's data","Create a data privacy configuration package"; var PackageCodeTemp: Code[20]; var PackageCodeKeep: Code[20])
    var
        TempEntityNumber: Code[17];
    begin

        if StrLen(EntityNo) >= 18 then
            TempEntityNumber := CopyStr(EntityNo, (StrLen(EntityNo) mod 17) + 1, (StrLen(EntityNo) - (StrLen(EntityNo) mod 17)))
        else
            TempEntityNumber := CopyStr(EntityNo, 1, StrLen(EntityNo));

        if EntityTypeTableNo = Database::"LSC Activity Resource" then begin
            PackageCodeTemp := 'AR*' + TempEntityNumber;
            PackageCodeKeep := 'ACR' + TempEntityNumber;
        end;
    end;

    [EventSubscriber(ObjectType::Page, Codeunit::"Data Privacy Mgmt", OnDrillDownForEntityNumber, '', true, false)]
    local procedure DrilldownForEntityNumber(EntityTypeTableNo: Integer; var EntityNo: Code[50])
    var
        ActivityResource: Record "LSC Activity Resource";
        DataPrivacyEntities: Record "Data Privacy Entities";
        ResourceList: Page "LSC Activity Resource List";
        Instream: InStream;
        FilterAsText: Text;
        DataSubjectBlockedMsg: Label 'This data subject is already marked as inactive. You can export the related data.';
    begin

        if EntityTypeTableNo = Database::"LSC Activity Resource" then begin
            if DataPrivacyEntities.Get(Database::"LSC Activity Resource") then begin
                DataPrivacyEntities.CalcFields("Entity Filter");
                DataPrivacyEntities."Entity Filter".CreateInStream(Instream);
                Instream.ReadText(FilterAsText);
            end;

            ResourceList.LookupMode := true;
            ActivityResource.SetRange("Resource Type", ActivityResource."Resource Type"::Human);
            ResourceList.SetTableView(ActivityResource);
            if ResourceList.RunModal() = ACTION::LookupOK then begin
                ResourceList.GetRecord(ActivityResource);
                if ActivityResource.Status = ActivityResource.Status::Inactive then
                    Message(DataSubjectBlockedMsg);
                EntityNo := ActivityResource."Resource No.";
            end;
        end;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Controller", OnBeforeClosePOSPanelInLogoffPressed, '', true, true)]
    local procedure BeforePOSPanelInLogoffPressed(ActivePanelID: text; StartupControllerCodeunit: integer; var CancelClosing: Boolean)
    begin
        IF ((ActivePanelID = Format("LSC POS Panel Id"::"#POS")) AND (StartupControllerCodeunit = Codeunit::"LSC Activity Front Desk")) THEN
            CancelClosing := true;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Controller", OnBeforeClosePOSPanelInPostCommandProcessingWhenCloseFlagSet, '', true, true)]
    local procedure BeforeClosePOSPanelInPostCommandProcessingWhenCloseFlagSet(StartupControllerCodeunit: integer; var CancelClosing: Boolean)
    begin
        if StartupControllerCodeunit = Codeunit::"LSC Activity Front Desk" then
            CancelClosing := true;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnInit_OnAfterGetPOSTransaction, '', true, true)]
    local procedure OnInit_OnAfterGetPOSTransaction(var POSTransaction: Record "LSC POS Transaction"; CurrTableNo: Integer; CurrTableDescr: text; CurrDinResNo: code[20])
    var
        ActivitiesPOSCommWeb: Codeunit "LSC ACT POS Commands WEB";
        POSSession: Codeunit "LSC POS Session";
    begin
        if not POSTransaction."New Transaction" then
            exit;
        CurrDinResNo := POSSession.GetValue("LSC POS Tag"::"SELECTEDRES");
        POSSESSION.SetValue("LSC POS Tag"::"SELECTEDRES", '');
        if CurrDinResNo = '' then
            exit;
        ActivitiesPOSCommWeb.ProcessSelectedReservation(CurrDinResNo, POSTransaction);
    end;

    //[EventSubscriber(ObjectType::Table, Database::"LSC Member Contact", OnAfterModifyEvent, '', true, false)]
    [Obsolete('Not used', '25.1')]
    local procedure OnAfterModifyContact(var Rec: Record "LSC Member Contact"; var xRec: Record "LSC Member Contact"; RunTrigger: Boolean)
    var
        LSReservation: Record "LSC Reservation";
        ActivityGroup: Record "LSC Activity Group";
        Activity: Record "LSC Activity Reservation";
        GroupMembers: Record "LSC Activity Group Member";
        WasEmail: Text[200];
        WasMobile: Text[80];
        UpdateMsg: Label 'Do you want to update email and/or mobile number in future reservations ?';
    begin
        if Rec."Contact No." = '' then
            exit;

        if (xRec."E-Mail" <> Rec."E-Mail") or (xRec."Mobile Phone No." <> Rec."Mobile Phone No.") then begin
            GroupMembers.SetRange(Contact, Rec."Contact No.");
            GroupMembers.SetRange("Member Account No.", Rec."Account No.");
            if GroupMembers.FindSet() then
                repeat
                    WasEmail := GroupMembers.Email;
                    WasMobile := GroupMembers.Phone;

                    if ActivityGroup.Get(GroupMembers."Group No.") then
                        if (ActivityGroup."Group Reservation From" >= Today) or (ActivityGroup."Group Reservation From" = 0D) then begin

                            GroupMembers."Phone" := Rec."Mobile Phone No.";
                            GroupMembers.Email := Rec."E-Mail";

                            if (WasEmail <> GroupMembers.EMail) or (WasMobile <> GroupMembers.Phone) then
                                GroupMembers.Modify(false);
                        end;
                until GroupMembers.Next() = 0;

            LSReservation.SetRange("Contact No.", Rec."Contact No.");
            LSReservation.SetFilter("Reservation From", '>=%1', Today);
            if LSReservation.FindSet() then
                repeat
                    WasEmail := LSReservation."E-Mail";
                    WasMobile := LSReservation."Mobile Phone No.";

                    if LSReservation."Reservation From" >= Today then begin

                        LSReservation."Mobile Phone No." := Rec."Mobile Phone No.";
                        LSReservation."E-Mail" := Rec."E-Mail";

                        if (Copystr(WasEmail, 1, 80) <> LSReservation."E-Mail") or (WasMobile <> LSReservation."Mobile Phone No.") then
                            LSReservation.Modify(false);
                    end;
                until LSReservation.Next() = 0;

            Activity.SetRange("Client No.", Rec."Contact No.");
            Activity.SetFilter("Date From", '>=%1', Today);
            if Activity.FindSet() then
                repeat
                    WasEmail := Activity."E-Mail";
                    WasMobile := Activity."Mobile Phone No.";
                    if Activity."Date From" >= Today then begin

                        Activity."Mobile Phone No." := Rec."Mobile Phone No.";
                        Activity."E-Mail" := Rec."E-Mail";

                        if (WasEmail <> Activity."E-Mail") or (WasMobile <> Activity."Mobile Phone No.") then
                            Activity.Modify(false);
                    end;
                until Activity.Next() = 0;
        end;
    end;

    internal procedure OnBeforeSetRelatedComments(RecID: recordID; var LSCCommentTemp: Record "LSC Comment" temporary)
    begin
        ProcessComments(RecID, LSCCommentTemp);
    end;

    internal procedure OnBeforeGetRelatedCommentCount(RecID: RecordId; var RelatedCommentCount: Integer)
    begin
        if not GetCommentCountForRelatedRecords(RecID, RelatedCommentCount) then
            exit;
    end;

    procedure ProcessComments(RecID: recordID; var LSCCommentTemp: Record "LSC Comment" temporary): Boolean
    var
        RecRef: RecordRef;
    begin
        RecRef := RecID.GetRecord();
        case RecRef.Number of

            Database::"LSC Member Contact":
                ProcessRelatedCommentsForMemberContact(RecID, LSCCommentTemp);
            Database::"LSC Activity Group":
                ProcessRelatedCommentsForActivityGroup(RecID, LSCCommentTemp);
            Database::"LSC Reservation":
                ProcessRelatedCommentsForReservation(RecID, LSCCommentTemp);
            Database::"LSC Activity Reservation":
                ProcessRelatedCommentsForActivityReservation(Recid, LSCCommentTemp);
            Database::"LSC Activity Group Line":
                ProcessRelatedCommentsForActivityGroupLine(Recid, LSCCommentTemp);
            Database::"LSC Activity Group Member":
                ProcessRelatedCommentsForActivityGroupMember(Recid, LSCCommentTemp);
            else
                exit(false);
        end;
        exit(true);
    end;

    local procedure ProcessRelatedCommentsForMemberContact(RecID: recordID; var LSCCommentTemp: Record "LSC Comment" temporary)
    var
        RecRef: RecordRef;
        MemberContact: Record "LSC Member Contact";
        RelatedLineNo: Integer;
        LSCReservation: Record "LSC Reservation";
    begin
        if not RecRef.Get(RecID) then
            exit;

        RecRef.SetTable(MemberContact);
        RelatedLineNo := 10000;

        LSCReservation.SetRange("Member Account No.", MemberContact."Account No.");
        LSCReservation.SetRange("Contact No.", MemberContact."Contact No.");
        LSCReservation.SetFilter("Reservation From", '>=%1', Today);
        if LSCReservation.FindSet() then
            repeat
                InsertRelatedReservationComments(LSCReservation, LSCCommentTemp, RecID, RelatedLineNo);
            until LSCReservation.Next() = 0;
    end;

    procedure InsertRelatedMemberComments(Member: Record "LSC Member Contact"; var LSCCommentTemp: Record "LSC Comment" temporary; OriginalRecID: RecordId; var RelatedLineNo: Integer)
    var
        LSCComment: Record "LSC Comment";
        SourceRef: Label 'Member';
    begin
        if OriginalRecID <> Member.RecordId then begin
            LSCComment.SetRange("Linked Record Id Text", format(Member.RecordId));
            if LSCComment.InsertRelatedComments(LSCComment, LSCCommentTemp, RelatedLineNo, Member."Contact No.", Member.Name, SourceRef) then
                RelatedLineNo := RelatedLineNo + 10000;
        end;
    end;

    local procedure ProcessRelatedCommentsForActivityGroup(RecID: recordID; var LSCCommentTemp: Record "LSC Comment" temporary)
    var
        RecRef: RecordRef;
        ActivityGroup: Record "LSC Activity Group";
        RelatedLineNo: Integer;
    begin
        if not RecRef.Get(RecID) then
            exit;
        RecRef.SetTable(ActivityGroup);

        RelatedLineNo := 10000;
        InsertRelatedActivityGroupComments(ActivityGroup, LSCCommentTemp, RecID, RelatedLineNo);
    end;

    local procedure ProcessRelatedCommentsForReservation(RecID: recordID; var LSCCommentTemp: Record "LSC Comment" temporary)
    var
        RecRef: RecordRef;
        ActivityGroup: Record "LSC Activity Group";
        LSCReservation: Record "LSC Reservation";
        RelatedLineNo: Integer;
    begin
        if not RecRef.Get(RecID) then
            exit;
        RecRef.SetTable(LSCReservation);

        RelatedLineNo := 10000;

        if LSCReservation."Activity Group No." <> '' then begin
            if ActivityGroup.get(LSCReservation."Activity Group No.") then
                InsertRelatedActivityGroupComments(ActivityGroup, LSCCommentTemp, RecID, RelatedLineNo);
            exit;
        end;

        InsertRelatedReservationComments(LSCReservation, LSCCommentTemp, RecID, RelatedLineNo);
    end;

    local procedure ProcessRelatedCommentsForActivityReservation(RecID: recordID; var LSCCommentTemp: Record "LSC Comment" temporary)
    var
        RecRef: RecordRef;
        ActivityGroup: Record "LSC Activity Group";
        LSCReservation: Record "LSC Reservation";
        ActivityReservation: Record "LSC Activity Reservation";
        RelatedLineNo: Integer;
        ActivityAdditionalCharges: Record "LSC Activity Additional Item";
        LSCComment: Record "LSC Comment";
        ActCharges: Label 'Activity Charges';
    begin
        if not RecRef.Get(RecID) then
            exit;
        RecRef.SetTable(ActivityReservation);

        RelatedLineNo := 10000;

        ActivityAdditionalCharges.SetRange("Reservation No.", ActivityReservation."Reservation No.");
        ActivityAdditionalCharges.SetRange("Reservation Line No.", ActivityReservation."Line No.");
        if ActivityAdditionalCharges.FindSet() then
            repeat
                LSCComment.SetRange("Linked Record Id Text", format(ActivityAdditionalCharges.RecordId));
                LSCComment.InsertRelatedComments(LSCComment, LSCCommentTemp, RelatedLineNo, ActivityReservation."Activity No.", ActivityAdditionalCharges.Description, ActCharges);
            until ActivityAdditionalCharges.Next() = 0;

        if ActivityReservation."Activity Group No." <> '' then begin
            if ActivityGroup.get(ActivityReservation."Activity Group No.") then
                InsertRelatedActivityGroupComments(ActivityGroup, LSCCommentTemp, RecID, RelatedLineNo);
            exit;
        end;

        if LSCReservation.get(ActivityReservation."Reservation No.") then
            InsertRelatedReservationComments(LSCReservation, LSCCommentTemp, RecID, RelatedLineNo);
    end;

    local procedure ProcessRelatedCommentsForActivityGroupLine(RecID: recordID; var LSCCommentTemp: Record "LSC Comment" temporary)
    var
        RecRef: RecordRef;
        ActivityGroup: Record "LSC Activity Group";
        ActivityGroupLine: Record "LSC Activity Group Line";
        RelatedLineNo: Integer;
    begin
        if not RecRef.Get(RecID) then
            exit;
        RecRef.SetTable(ActivityGroupLine);

        RelatedLineNo := 10000;

        if ActivityGroup.get(ActivityGroupLine."Group No.") then
            InsertRelatedActivityGroupComments(ActivityGroup, LSCCommentTemp, RecID, RelatedLineNo);
    end;

    local procedure ProcessRelatedCommentsForActivityGroupMember(RecID: recordID; var LSCCommentTemp: Record "LSC Comment" temporary)
    var
        RecRef: RecordRef;
        ActivityGroup: Record "LSC Activity Group";
        ActivityGroupMember: Record "LSC Activity Group Member";
        RelatedLineNo: Integer;
    begin
        if not RecRef.Get(RecID) then
            exit;
        RecRef.SetTable(ActivityGroupMember);

        RelatedLineNo := 10000;

        if ActivityGroup.get(ActivityGroupMember."Group No.") then
            InsertRelatedActivityGroupComments(ActivityGroup, LSCCommentTemp, RecID, RelatedLineNo);
    end;

    procedure InsertRelatedActivityGroupComments(ActivityGroup: Record "LSC Activity Group"; var LSCCommentTemp: Record "LSC Comment" temporary; OriginalRecID: RecordId; var RelatedLineNo: Integer)
    var
        LSCComment: Record "LSC Comment";
        ActivityGroupLbl: Label 'Activity Group';
        LSCReservation: Record "LSC Reservation";
        ReservNos: array[300] of code[20];
        NoOfReserv: Integer;
    begin
        if OriginalRecID <> ActivityGroup.RecordId then begin
            LSCComment.SetRange("Linked Record Id Text", format(ActivityGroup.RecordId));
            if LSCComment.InsertRelatedComments(LSCComment, LSCCommentTemp, RelatedLineNo, ActivityGroup."No.", ActivityGroup.Name, ActivityGroupLbl) then
                RelatedLineNo := RelatedLineNo + 10000;
        end;

        InsertCommentsForActivityGroupLines(ActivityGroup."No.", LSCCommentTemp, RelatedLineNo, OriginalRecID);

        InsertCommentsForActivityGroupMembers(ActivityGroup."No.", LSCCommentTemp, RelatedLineNo, OriginalRecID);

        NoOfReserv := 0;
        LSCReservation.SetRange("Activity Group No.", ActivityGroup."No.");
        if LSCReservation.FindSet() then
            repeat
                NoOfReserv += 1;
                ReservNos[NoOfReserv] := LSCReservation."No.";
            until LSCReservation.Next() = 0;

        if NoOfReserv > 0 then
            InsertGroupRelatedReservationComments(ReservNos, NoOfReserv, LSCCommentTemp, OriginalRecID, RelatedLineNo);
    end;

    local procedure InsertCommentsForActivityGroupLines(GroupNo: code[20]; var LSCCommentTemp: Record "LSC Comment" temporary; var RelatedLineNo: Integer; OriginalRecID: RecordId)
    var
        LSCComment: Record "LSC Comment";
        ActivityGroupLine: Record "LSC Activity Group Line";
        HeaderRecID: RecordId;
        GroupLineLbl: Label 'Group Line';
        CommentsInserted: Boolean;
        CommentsFound: Boolean;
    begin
        ActivityGroupLine.SetRange("Group No.", GroupNo);
        if ActivityGroupLine.FindSet() then
            repeat
                if OriginalRecID <> ActivityGroupLine.RecordId then begin
                    LSCComment.SetRange("Linked Record Id Text", format(ActivityGroupLine.RecordId));
                    CommentsInserted := LSCComment.InsertRelatedComments(LSCComment, LSCCommentTemp, RelatedLineNo, ActivityGroupLine."No.", ActivityGroupLine.Description, GroupLineLbl);
                    if CommentsInserted then begin
                        HeaderRecID := ActivityGroupLine.RecordId;
                        CommentsFound := true;
                    end;
                end;
            until ActivityGroupLine.Next() = 0;
        if CommentsFound then
            RelatedLineNo := RelatedLineNo + 10000;
    end;

    local procedure InsertCommentsForActivityGroupMembers(GroupNo: code[20]; var LSCCommentTemp: Record "LSC Comment" temporary; var RelatedLineNo: Integer; OriginalRecID: RecordId)
    var
        LSCComment: Record "LSC Comment";
        ActivityGroupMember: Record "LSC Activity Group Member";
        HeaderRecID: RecordId;
        GroupMemberLbl: Label 'Group Member';
        CommentsInserted: Boolean;
        CommentsFound: Boolean;
    begin
        ActivityGroupMember.SetRange("Group No.", GroupNo);
        if ActivityGroupMember.FindSet() then
            repeat
                if OriginalRecID <> ActivityGroupMember.RecordId then begin
                    LSCComment.SetRange("Linked Record Id Text", format(ActivityGroupMember.RecordId));
                    CommentsInserted := LSCComment.InsertRelatedComments(LSCComment, LSCCommentTemp, RelatedLineNo, ActivityGroupMember.Name, ActivityGroupMember."Group No.", GroupMemberLbl);
                    if CommentsInserted then begin
                        HeaderRecID := ActivityGroupMember.RecordId;
                        CommentsFound := true;
                    end;
                end;
            until ActivityGroupMember.Next() = 0;
        if CommentsFound then
            RelatedLineNo := RelatedLineNo + 10000;
    end;

    local procedure InsertGroupRelatedReservationComments(ReservNos: array[300] of code[20]; NoOfReserv: Integer; var LSCCommentTemp: Record "LSC Comment" temporary; OriginalRecID: RecordId; var RelatedLineNo: Integer)
    var
        LSCComment: Record "LSC Comment";
        LSCReservation: Record "LSC Reservation";
        HeaderRecID: RecordId;
        ActivityTableMgmtSync: Codeunit "LSC Activity Table Mgmt Sync";
        ActivityResLbl: Label 'Activity Reservation';
        ActivityResNumbers: array[300] of code[20];
        i: Integer;
        CommentsInserted: Boolean;
        CommentsFound: Boolean;
        ActivityDinResList: List of [code[20]];
        ActivityDinResHistoryList: List of [code[20]];
    begin
        for i := 1 to NoOfReserv do begin
            if LSCReservation.get(ReservNos[i]) then begin
                if OriginalRecID <> LSCReservation.RecordId then begin
                    LSCComment.SetRange("Linked Record Id Text", format(LSCReservation.RecordId));
                    CommentsInserted := LSCComment.InsertRelatedComments(LSCComment, LSCCommentTemp, RelatedLineNo, LSCReservation."No.", LSCReservation.Name, ActivityResLbl);
                    if CommentsInserted then begin
                        HeaderRecID := LSCReservation.RecordId;
                        CommentsFound := true;
                    end;
                end;
            end;
        end;
        if CommentsFound then
            RelatedLineNo := RelatedLineNo + 10000;

        clear(ActivityResNumbers);

        InsertCommentsForReservationActivities(ReservNos, NoOfReserv, LSCCommentTemp, RelatedLineNo, OriginalRecID, ActivityDinResList, ActivityDinResHistoryList);
        ActivityTableMgmtSync.ActivityReservation_InsertCommentsForDiningReservations(ActivityDinResList, LSCCommentTemp, RelatedLineNo, OriginalRecID);
        ActivityTableMgmtSync.ActivityReservation_InsertCommentsForDinReservHistoryEntries(ActivityDinResHistoryList, LSCCommentTemp, RelatedLineNo, OriginalRecID);
    end;

    procedure InsertRelatedReservationComments(LSCReservation: Record "LSC Reservation"; var LSCCommentTemp: Record "LSC Comment" temporary; OriginalRecID: RecordId; var RelatedLineNo: Integer)
    var
        LSCComment: Record "LSC Comment";
        MemberContact: Record "LSC Member Contact";
        ActivityTableMgmtSync: Codeunit "LSC Activity Table Mgmt Sync";
        ActivityResLbl: Label 'Activity Reservation';
        ReservNos: array[300] of code[20];
        ActivityResNumbers: array[300] of code[20];
        ActivityDinResList: List of [code[20]];
        ActivityDinResHistoryList: List of [code[20]];
    begin
        if OriginalRecID <> LSCReservation.RecordId then begin
            LSCComment.SetRange("Linked Record Id Text", format(LSCReservation.RecordId));
            if LSCComment.InsertRelatedComments(LSCComment, LSCCommentTemp, RelatedLineNo, LSCReservation."No.", LSCReservation.Name, ActivityResLbl) then
                RelatedLineNo := RelatedLineNo + 10000;
        end;
        ReservNos[1] := LSCReservation."No.";
        clear(ActivityResNumbers);

        if LSCReservation."Contact No." <> '' then
            if MemberContact.Get(LSCReservation."Member Account No.", LSCReservation."Contact No.") then
                MemberContact.InsertRelatedMemberContactComments(MemberContact, LSCCommentTemp, OriginalRecID, RelatedLineNo);
        InsertCommentsForReservationActivities(ReservNos, 1, LSCCommentTemp, RelatedLineNo, OriginalRecID, ActivityDinResList, ActivityDinResHistoryList);
        ActivityTableMgmtSync.ActivityReservation_InsertCommentsForDiningReservations(ActivityDinResList, LSCCommentTemp, RelatedLineNo, OriginalRecID);
        ActivityTableMgmtSync.ActivityReservation_InsertCommentsForDinReservHistoryEntries(ActivityDinResHistoryList, LSCCommentTemp, RelatedLineNo, OriginalRecID);
    end;

    local procedure InsertCommentsForReservationActivities(ReservNos: array[300] of code[20]; NoOfReserv: Integer; var LSCCommentTemp: Record "LSC Comment" temporary; var RelatedLineNo: Integer; OriginalRecID: RecordId; var ActivityDinResList: List of [code[20]]; var ActivityDinResHistoryList: List of [code[20]])
    var
        LSCComment: Record "LSC Comment";
        ActivityReservation: Record "LSC Activity Reservation";
        MemberContact: Record "LSC Member Contact";
        ActivityTableMgmtSync: Codeunit "LSC Activity Table Mgmt Sync";
        ActivityLbl: Label 'Activity';
        ResNo: Integer;
        CommentsInserted: Boolean;
        CommentsFound: Boolean;
        ActivityAdditionalCharges: Record "LSC Activity Additional Item";
        ChargesTbl: Label 'Activity Charges';
    begin
        for ResNo := 1 to NoOfReserv do begin
            ActivityReservation.SetRange("Reservation No.", ReservNos[ResNo]);
            if ActivityReservation.FindSet() then
                repeat
                    ActivityTableMgmtSync.ActivityReservation_CheckForDiningReservationsComments(ActivityReservation, ActivityDinResList, ActivityDinResHistoryList);
                    if GetOtherMemberContactFromActivityReservation(ActivityReservation, MemberContact) then
                        MemberContact.InsertRelatedMemberContactComments(MemberContact, LSCCommentTemp, OriginalRecID, RelatedLineNo);
                    if OriginalRecID <> ActivityReservation.RecordId then begin
                        LSCComment.SetRange("Linked Record Id Text", format(ActivityReservation.RecordId));
                        CommentsInserted := LSCComment.InsertRelatedComments(LSCComment, LSCCommentTemp, RelatedLineNo, ActivityReservation."Activity No.", ActivityReservation."Product No.", ActivityLbl);
                        if CommentsInserted then
                            CommentsFound := true;

                        ActivityAdditionalCharges.SetRange("Reservation No.", ActivityReservation."Reservation No.");
                        ActivityAdditionalCharges.SetRange("Reservation Line No.", ActivityReservation."Line No.");
                        if ActivityAdditionalCharges.FindSet() then
                            repeat
                                LSCComment.SetRange("Linked Record Id Text", format(ActivityAdditionalCharges.RecordId));
                                CommentsInserted := LSCComment.InsertRelatedComments(LSCComment, LSCCommentTemp, RelatedLineNo, ActivityReservation."Activity No.", ActivityAdditionalCharges.Description, ChargesTbl);
                                if CommentsInserted then
                                    CommentsFound := true;
                            until ActivityAdditionalCharges.Next() = 0;
                    end;
                until ActivityReservation.Next() = 0;
        end;
        if CommentsFound then
            RelatedLineNo := RelatedLineNo + 10000;
    end;

    procedure CommentsExistForRelatedRecords(RecID: recordID; var CommentsExist: Boolean)
    var
        RecRef: RecordRef;
    begin
        if CommentsExist then
            exit;
        RecRef := RecID.GetRecord();
        case RecRef.Number of
            database::"LSC Activity Group":
                CommentsExist := GroupCommentsExist(RecID, true);
            Database::"LSC Reservation":
                CommentsExist := ReservationCommentsExist(RecID, true);
            database::"LSC Activity Reservation":
                CommentsExist := ActivityCommentsExist(RecID, true);
            database::"LSC Activity Group Line":
                CommentsExist := GroupLineCommentsExist(RecID, true);
            database::"LSC Activity Group Member":
                CommentsExist := GroupMemberCommentsExist(RecID, true);
            Database::"LSC Member Contact":
                CommentsExist := MemberContactCommentsExist(RecID, true);
        end;
    end;

    procedure MemberContactCommentsExist(RecID: RecordId; MemberRecord: Boolean): Boolean
    var
        RecRef: RecordRef;
        LSCComment: Record "LSC Comment";
        MemberContact: Record "LSC Member Contact";
        LSCReservation: Record "LSC Reservation";
    begin
        RecRef.Get(RecID);
        RecRef.SetTable(MemberContact);

        LSCComment.SetRange("Linked Record Id Text", format(MemberContact.RecordId));
        if not LSCComment.IsEmpty then
            exit(true);

        if MemberRecord then begin
            LSCReservation.SetRange("Member Account No.", MemberContact."Account No.");
            LSCReservation.SetRange("Contact No.", MemberContact."Contact No.");
            LSCReservation.SetFilter("Reservation From", '>=%1', Today);
            if LSCReservation.FindSet() then
                repeat
                    if ReservationCommentsExist(LSCReservation.RecordId, true) then
                        exit(true);
                until LSCReservation.Next() = 0;
        end;
        exit(false);
    end;

    procedure GroupCommentsExist(RecID: RecordId; GroupRecord: Boolean): Boolean
    var
        ActivityGroup: Record "LSC Activity Group";
        RecRef: RecordRef;
        LSCComment: Record "LSC Comment";
        LSCReservation: Record "LSC Reservation";
        ActivityGroupLine: Record "LSC Activity Group Line";
        ActivityGroupMember: Record "LSC Activity Group Member";
        CommentFound: Boolean;
    begin
        RecRef.Get(RecID);
        RecRef.SetTable(ActivityGroup);

        LSCComment.SetRange("Linked Record Id Text", format(ActivityGroup.RecordId));
        if not LSCComment.IsEmpty then
            exit(true);

        LSCReservation.SetRange("Activity Group No.", ActivityGroup."No.");
        if LSCReservation.FindSet() then
            repeat
                CommentFound := ReservationCommentsExist(LSCReservation.RecordId, false);
            until CommentFound or (LSCReservation.Next() = 0);
        if CommentFound then
            exit(true);

        ActivityGroupLine.SetRange("Group No.", ActivityGroup."No.");
        if ActivityGroupLine.FindSet() then
            repeat
                CommentFound := GroupLineCommentsExist(ActivityGroupLine.RecordId, false);
            until CommentFound or (ActivityGroupLine.Next() = 0);
        if CommentFound then
            exit(true);

        ActivityGroupMember.SetRange("Group No.", ActivityGroup."No.");
        if ActivityGroupMember.FindSet() then
            repeat
                CommentFound := GroupMemberCommentsExist(ActivityGroupMember.RecordId, false);
            until CommentFound or (ActivityGroupMember.Next() = 0);

        exit(CommentFound);
    end;

    procedure ReservationCommentsExist(RecID: RecordId; ReservationRecord: Boolean): Boolean
    var
        RecRef: RecordRef;
        LSCComment: Record "LSC Comment";
        LSCReservation: Record "LSC Reservation";
        ActivityReservation: Record "LSC Activity Reservation";
        ActivityGroup: Record "LSC Activity Group";
        MemberContact: Record "LSC Member Contact";
        ActivityTableMgmtSync: Codeunit "LSC Activity Table Mgmt Sync";
        CommentFound: Boolean;
    begin
        if not RecRef.Get(RecID) then
            exit;
        RecRef.SetTable(LSCReservation);

        LSCComment.SetRange("Linked Record Id Text", format(LSCReservation.RecordId));
        if not LSCComment.IsEmpty then
            exit(true);

        if ReservationRecord then begin
            if LSCReservation."Activity Group No." <> '' then begin
                if ActivityGroup.get(LSCReservation."Activity Group No.") then
                    CommentFound := GroupCommentsExist(ActivityGroup.RecordId, false);
                exit(CommentFound);
            end;
        end;

        if LSCReservation."Contact No." <> '' then
            if MemberContact.Get(LSCReservation."Member Account No.", LSCReservation."Contact No.") then begin
                if MemberContact.MemberContactCommentsExist(MemberContact) then
                    exit(true);
            end;

        ActivityReservation.SetRange("Reservation No.", LSCReservation."No.");
        if ActivityReservation.FindSet() then
            repeat
                CommentFound := ActivityCommentsExist(ActivityReservation.RecordId, false);

                if not CommentFound then
                    CommentFound := ActivityTableMgmtSync.ActivityReservation_DinResCommentsExist(ActivityReservation);
            until CommentFound or (ActivityReservation.Next() = 0);

        exit(CommentFound);
    end;

    local procedure ActivityCommentsExist(RecID: RecordId; ActivityRecord: Boolean): Boolean
    var
        RecRef: RecordRef;
        LSCComment: Record "LSC Comment";
        LSCReservation: Record "LSC Reservation";
        ActivityReservation: Record "LSC Activity Reservation";
        ActivityGroup: Record "LSC Activity Group";
        MemberContact: Record "LSC Member Contact";
        CommentFound: Boolean;
        ActivityAdditionalCharges: Record "LSC Activity Additional Item";
    begin
        if ActivityRecord then begin
            RecRef.Get(RecID);
            RecRef.SetTable(ActivityReservation);
            LSCComment.SetRange("Linked Record Id Text", format(ActivityReservation.RecordId));
            if not LSCComment.IsEmpty then
                exit(true);

            LSCReservation.Get(ActivityReservation."Reservation No.");
            if LSCReservation."Activity Group No." <> '' then begin
                if ActivityGroup.get(LSCReservation."Activity Group No.") then
                    CommentFound := GroupCommentsExist(ActivityGroup.RecordId, false);
            end else
                CommentFound := ReservationCommentsExist(LSCReservation.RecordId, false);
            exit(CommentFound);
        end;
        LSCComment.SetRange("Linked Record Id Text", format(RecID));
        if not LSCComment.IsEmpty then
            exit(true);

        RecRef.Get(RecID);
        RecRef.SetTable(ActivityReservation);
        if GetOtherMemberContactFromActivityReservation(ActivityReservation, MemberContact) then
            exit(MemberContact.MemberContactCommentsExist(MemberContact));

        ActivityAdditionalCharges.SetRange("Reservation No.", ActivityReservation."Reservation No.");
        ActivityAdditionalCharges.SetRange("Reservation Line No.", ActivityReservation."Line No.");
        if ActivityAdditionalCharges.FindSet() then
            repeat
                LSCComment.SetRange("Linked Record Id Text", format(ActivityAdditionalCharges.RecordId));
                if not LSCComment.IsEmpty then
                    exit(true);

            until ActivityAdditionalCharges.Next() = 0;

        exit(false);
    end;

    local procedure GroupLineCommentsExist(RecID: RecordId; GroupLineRecord: Boolean): Boolean
    var
        RecRef: RecordRef;
        LSCComment: Record "LSC Comment";
        ActivityGroupLine: Record "LSC Activity Group Line";
        ActivityGroup: Record "LSC Activity Group";
        CommentFound: Boolean;
    begin
        if GroupLineRecord then begin
            RecRef.Get(RecID);
            RecRef.SetTable(ActivityGroupLine);
            LSCComment.SetRange("Linked Record Id Text", format(ActivityGroupLine.RecordId));
            if not LSCComment.IsEmpty then
                exit(true);
            if ActivityGroup.Get(ActivityGroupLine."Group No.") then
                CommentFound := GroupCommentsExist(ActivityGroup.RecordId, false);
            exit(CommentFound);
        end;
        LSCComment.SetRange("Linked Record Id Text", format(RecID));
        exit(not LSCComment.IsEmpty);
    end;

    local procedure GroupMemberCommentsExist(RecID: RecordId; GroupMemberRecord: Boolean): Boolean
    var
        RecRef: RecordRef;
        LSCComment: Record "LSC Comment";
        ActivityGroupMember: Record "LSC Activity Group Member";
        ActivityGroup: Record "LSC Activity Group";
        CommentFound: Boolean;
    begin
        if GroupMemberRecord then begin
            RecRef.Get(RecID);
            RecRef.SetTable(ActivityGroupMember);
            LSCComment.SetRange("Linked Record Id Text", format(ActivityGroupMember.RecordId));
            if not LSCComment.IsEmpty then
                exit(true);
            if ActivityGroup.Get(ActivityGroupMember."Group No.") then
                CommentFound := GroupCommentsExist(ActivityGroup.RecordId, false);
            exit(CommentFound);
        end;
        LSCComment.SetRange("Linked Record Id Text", format(RecID));
        exit(not LSCComment.IsEmpty);
    end;

    procedure GetCommentCountForRelatedRecords(RecID: recordID; var CommentCount: Integer): Boolean
    var
        RecRef: RecordRef;
    begin
        RecRef := RecID.GetRecord();
        case RecRef.Number of
            database::"LSC Activity Group":
                CommentCount := GetGroupCommentsCount(RecID, true, RecID);
            Database::"LSC Reservation":
                CommentCount := GetReservationCommentsCount(RecID, true, RecID);
            database::"LSC Activity Reservation":
                CommentCount := GetActivityCommentsCount(RecID, true, RecID);
            database::"LSC Activity Group Line":
                CommentCount := GetGroupLineCommentsCount(RecID, true, RecID);
            database::"LSC Activity Group Member":
                CommentCount := GetGroupMemberCommentsCount(RecID, true, RecID);
            database::"LSC Member Contact":
                CommentCount := GetMemberContactCommentsCount(RecID, true, RecID);
            else
                exit(False);
        end;
        exit(true);
    end;

    procedure GetMemberContactCommentsCount(RecID: RecordId; MemberRecord: Boolean; OriginalRecID: RecordId): Integer
    var
        RecRef: RecordRef;
        MemberContact: Record "LSC Member Contact";
        LSCComment: Record "LSC Comment";
        LSCReservation: Record "LSC Reservation";
        CommentCount: Integer;
    begin
        RecRef.Get(RecID);
        RecRef.SetTable(MemberContact);
        if not MemberRecord then begin
            if OriginalRecID = MemberContact.RecordId then
                exit(0);
            LSCComment.SetRange("Linked Record Id Text", format(MemberContact.RecordId));
            CommentCount := LSCComment.Count;
            exit(CommentCount);
        end;
        LSCReservation.SetRange("Member Account No.", MemberContact."Account No.");
        LSCReservation.SetRange("Contact No.", MemberContact."Contact No.");
        LSCReservation.SetFilter("Reservation From", '>=%1', Today);
        if LSCReservation.FindSet() then
            repeat
                CommentCount += GetReservationCommentsCount(LSCReservation.RecordId, false, RecID);
            until LSCReservation.Next() = 0;
        exit(CommentCount);
    end;

    procedure GetGroupCommentsCount(RecID: RecordId; GroupRecord: Boolean): Integer
    begin
        exit(GetGroupCommentsCount(RecID, GroupRecord, RecID));
    end;

    procedure GetGroupCommentsCount(RecID: RecordId; GroupRecord: Boolean; OriginalRecID: RecordId): Integer
    var
        ActivityGroup: Record "LSC Activity Group";
        RecRef: RecordRef;
        LSCComment: Record "LSC Comment";
        LSCReservation: Record "LSC Reservation";
        ActivityGroupLine: Record "LSC Activity Group Line";
        ActivityGroupMember: Record "LSC Activity Group Member";
        CommentCount: Integer;
    begin
        RecRef.Get(RecID);
        RecRef.SetTable(ActivityGroup);
        if not GroupRecord then begin
            LSCComment.SetRange("Linked Record Id Text", format(ActivityGroup.RecordId));
            CommentCount := LSCComment.Count;
        end;

        LSCReservation.SetRange("Activity Group No.", ActivityGroup."No.");
        if LSCReservation.FindSet() then
            repeat
                CommentCount += GetReservationCommentsCount(LSCReservation.RecordId, false, OriginalRecID);
            until LSCReservation.Next() = 0;

        ActivityGroupLine.SetRange("Group No.", ActivityGroup."No.");
        if ActivityGroupLine.FindSet() then
            repeat
                CommentCount += GetGroupLineCommentsCount(ActivityGroupLine.RecordId, false, OriginalRecID);
            until ActivityGroupLine.Next() = 0;

        ActivityGroupMember.SetRange("Group No.", ActivityGroup."No.");
        if ActivityGroupMember.FindSet() then
            repeat
                CommentCount += GetGroupMemberCommentsCount(ActivityGroupMember.RecordId, false, OriginalRecID);
            until ActivityGroupMember.Next() = 0;
        exit(CommentCount);
    end;

    procedure GetReservationCommentsCount(RecID: RecordId; ReservationRecord: Boolean): Integer
    begin
        exit(GetReservationCommentsCount(RecID, ReservationRecord, RecID));
    end;

    procedure GetReservationCommentsCount(RecID: RecordId; ReservationRecord: Boolean; OriginalRecID: RecordId): Integer
    var
        RecRef: RecordRef;
        LSCComment: Record "LSC Comment";
        LSCReservation: Record "LSC Reservation";
        ActivityReservation: Record "LSC Activity Reservation";
        ActivityGroup: Record "LSC Activity Group";
        MemberContact: Record "LSC Member Contact";
        ActivityTableMgmtSync: Codeunit "LSC Activity Table Mgmt Sync";
        CommentCount: Integer;
    begin
        if not RecRef.Get(RecID) then
            exit;

        RecRef.SetTable(LSCReservation);
        if ReservationRecord then begin
            if LSCReservation."Activity Group No." <> '' then begin
                if ActivityGroup.get(LSCReservation."Activity Group No.") then begin
                    CommentCount := GetGroupCommentsCount(ActivityGroup.RecordId, false, OriginalRecID);
                    LSCComment.SetRange("Linked Record Id Text", format(LSCReservation.RecordId));
                    CommentCount -= LSCComment.Count;
                end;
                exit(CommentCount);
            end;
        end else begin
            LSCComment.SetRange("Linked Record Id Text", format(LSCReservation.RecordId));
            CommentCount := LSCComment.Count;
        end;

        if LSCReservation."Contact No." <> '' then
            if MemberContact.Get(LSCReservation."Member Account No.", LSCReservation."Contact No.") then
                CommentCount += GetMemberContactCommentsCount(MemberContact.RecordId, false, OriginalRecID);

        ActivityReservation.SetRange("Reservation No.", LSCReservation."No.");
        if ActivityReservation.FindSet() then
            repeat
                CommentCount += GetActivityCommentsCount(ActivityReservation.RecordId, false, OriginalRecID);
                CommentCount += ActivityTableMgmtSync.ActivityReservation_GetDinResCommentsCount(ActivityReservation);
            until ActivityReservation.Next() = 0;

        exit(CommentCount);
    end;

    local procedure GetActivityCommentsCount(RecID: RecordId; ActivityRecord: Boolean; OriginalRecID: RecordId): Integer
    var
        RecRef: RecordRef;
        LSCComment: Record "LSC Comment";
        LSCReservation: Record "LSC Reservation";
        ActivityReservation: Record "LSC Activity Reservation";
        ActivityGroup: Record "LSC Activity Group";
        MemberContact: Record "LSC Member Contact";
        CommentCount: Integer;
        ActivityAdditionalCharges: Record "LSC Activity Additional Item";
    begin
        if ActivityRecord then begin
            RecRef.Get(RecID);
            RecRef.SetTable(ActivityReservation);

            LSCReservation.Get(ActivityReservation."Reservation No.");
            if LSCReservation."Activity Group No." <> '' then begin
                if ActivityGroup.get(LSCReservation."Activity Group No.") then
                    CommentCount := GetGroupCommentsCount(ActivityGroup.RecordId, false, OriginalRecID);
            end else
                CommentCount := GetReservationCommentsCount(LSCReservation.RecordId, false, OriginalRecID);
            LSCComment.SetRange("Linked Record Id Text", format(ActivityReservation.RecordId));
            CommentCount -= LSCComment.Count;
        end else begin
            RecRef.Get(RecID);
            RecRef.SetTable(ActivityReservation);
            if GetOtherMemberContactFromActivityReservation(ActivityReservation, MemberContact) then
                CommentCount := GetMemberContactCommentsCount(MemberContact.RecordId, false, OriginalRecID);
            LSCComment.SetRange("Linked Record Id Text", format(RecID));
            CommentCount += LSCComment.Count;
        end;

        ActivityAdditionalCharges.SetRange("Reservation No.", ActivityReservation."Reservation No.");
        ActivityAdditionalCharges.SetRange("Reservation Line No.", ActivityReservation."Line No.");
        if ActivityAdditionalCharges.FindSet() then
            repeat
                LSCComment.SetRange("Linked Record Id Text", format(ActivityAdditionalCharges.RecordId));
                if not LSCComment.IsEmpty then
                    CommentCount += LSCComment.Count;

            until ActivityAdditionalCharges.Next() = 0;

        exit(CommentCount);
    end;

    local procedure GetGroupLineCommentsCount(RecID: RecordId; GroupLineRecord: Boolean; OriginalRecID: RecordId): integer
    var
        RecRef: RecordRef;
        LSCComment: Record "LSC Comment";
        ActivityGroupLine: Record "LSC Activity Group Line";
        ActivityGroup: Record "LSC Activity Group";
        CommentCount: Integer;
    begin
        if GroupLineRecord then begin
            RecRef.Get(RecID);
            RecRef.SetTable(ActivityGroupLine);

            if ActivityGroup.get(ActivityGroupLine."Group No.") then begin
                CommentCount := GetGroupCommentsCount(ActivityGroup.RecordId, false, OriginalRecID);
                LSCComment.SetRange("Linked Record Id Text", format(ActivityGroupLine.RecordId));
                CommentCount -= LSCComment.Count;
            end;
        end else begin
            LSCComment.SetRange("Linked Record Id Text", format(RecID));
            CommentCount := LSCComment.Count;
        end;
        exit(CommentCount);
    end;

    local procedure GetGroupMemberCommentsCount(RecID: RecordId; GroupMemberRecord: Boolean; OriginalRecID: RecordId): Integer
    var
        RecRef: RecordRef;
        LSCComment: Record "LSC Comment";
        ActivityGroupMember: Record "LSC Activity Group Member";
        ActivityGroup: Record "LSC Activity Group";
        CommentCount: Integer;
    begin
        if GroupMemberRecord then begin
            RecRef.Get(RecID);
            RecRef.SetTable(ActivityGroupMember);

            if ActivityGroup.Get(ActivityGroupMember."Group No.") then begin
                CommentCount := GetGroupCommentsCount(ActivityGroup.RecordId, false, OriginalRecID);
                LSCComment.SetRange("Linked Record Id Text", format(ActivityGroupMember.RecordId));
                CommentCount -= LSCComment.Count;
            end;
        end else begin
            LSCComment.SetRange("Linked Record Id Text", format(RecID));
            CommentCount := LSCComment.Count;
        end;
        exit(CommentCount);
    end;

    internal procedure OnBeforeLSCCommentReferenceDrillDown(LSCComment: Record "LSC Comment"; var LookupPageFound: Boolean)
    var
        DatabaseTableNo: Integer;
        ActivityReservation: Record "LSC Activity Reservation";
    begin
        if LookupPageFound then
            exit;
        DatabaseTableNo := LSCComment."Linked Record Id".TableNo;

        LookupPageFound := true;

        case DatabaseTableNo of

            Database::"LSC Member Contact":
                begin
                    if ActivityReservation.ReadPermission then
                        OpenMemberCard(LSCComment."Linked Record Id")
                    else
                        LookupPageFound := false;
                end;
            Database::"LSC Reservation":
                OpenLSReservationCard(LSCComment."Linked Record Id");
            Database::"LSC Activity Group":
                OpenActivityGroupCard(LSCComment."Linked Record Id");
            Database::"LSC Activity Reservation":
                OpenActivityCard(LSCComment."Linked Record Id");
            Database::"LSC Activity Group Line":
                OpenGroupLineCard(LSCComment."Linked Record Id");
            Database::"LSC Activity Group Member":
                OpenGroupMemberCard(LSCComment."Linked Record Id");
            else
                LookupPageFound := false;
        end;
    end;

    internal procedure OpenMemberCard(RecID: RecordId)
    var
        MemberContact: Record "LSC Member Contact";
        MemberContactCard: Page "LSC Activity Contact Card";
        RecRef: recordref;
    begin
        if not RecRef.Get(RecID) then
            exit;
        RecRef.SetTable(MemberContact);

        MemberContactCard.SetRecord(MemberContact);
        MemberContactCard.RunModal();
    end;

    internal procedure LSCCommentsLoadInPOS(RecID: RecordId; var POSTransaction: Record "LSC POS Transaction")
    var
        LSCComment: Record "LSC Comment";
        LSCCommentPanelControler: Codeunit "LSC Comment Panel Controller";
        POSSession: Codeunit "LSC POS Session";
        RecIDText: text;
    begin
        RecIDText := format(RecID);
        POSSession.SetValue("LSC POS Tag"::"SHOWCOMMFORRECID", RecIDText);
        LSCComment.CopyCommentLines(POSTransaction.RecordId, RecID, true);
        LSCCommentPanelControler.OnAfterLSCCommentSalesPOSPanelCloseUpdateLSCCommentsInDataGrid();
    end;

    internal procedure LSCCommentsLoadInPOSOnAfterRetSuspended(var CurrInput: Text; var POSTransaction: Record "LSC POS Transaction"; var POSTransLine: Record "LSC POS Trans. Line")
    var
        ActivityFunctionsWeb: Codeunit "LSC Activity POS Functions WEB";
        ActivityReservation: Record "LSC Activity Reservation";
        LSCReservation: Record "LSC Reservation";
    begin
        if ActivityFunctionsWeb.GetActivityReservationFromPOSTransaction(POSTransaction, ActivityReservation) then
            if LSCReservation.get(ActivityReservation."Reservation No.") then
                LSCCommentsLoadInPOS(LSCReservation.RecordId, POSTransaction);
    end;

    internal procedure OnBeforeGetCommentPageCaption(LSCComment: Record "LSC Comment"; var CaptionText: Text; var IsHandled: Boolean)
    var
        LinkedTableRecordID: RecordId;
        Caption1: Text;
        Caption2: Text;
    begin
        if IsHandled then
            exit;

        if not Evaluate(LinkedTableRecordID, LSCComment."Linked Record Id Text") then
            exit;

        OnBeforeSetCommentPanelHeader(LinkedTableRecordID, Caption2, IsHandled, Caption1);
        if IsHandled then
            CaptionText := Caption1 + ' ' + Caption2;
    end;

    internal procedure OnBeforeSetCommentPanelHeader(LinkedTableRecordID: RecordId; var EntityID: Text; var IsHandled: Boolean; var PanelName: Text)
    var
        DatabaseTableNo: Integer;
    begin
        if IsHandled then
            exit;

        DatabaseTableNo := LinkedTableRecordID.TableNo;

        IsHandled := True;
        case DatabaseTableNo of
            database::"LSC Activity Reservation":
                SetCommentPanelHeaderForActivityReservation(LinkedTableRecordID, EntityID, PanelName);
            database::"LSC Reservation":
                SetCommentPanelHeaderForLSCReservation(LinkedTableRecordID, EntityID, PanelName);
            else
                IsHandled := false;
        end;
    end;

    local procedure SetCommentPanelHeaderForActivityReservation(RecID: RecordId; var EntityID: text; var PanelName: text)
    var
        ActivityReservation: Record "LSC Activity Reservation";
        RecRef: recordref;
        ActResLbl: Label 'Activity %1:';
        EntityLbl: Label '%1 - %2';
    begin
        if not RecRef.Get(RecID) then
            exit;
        RecRef.SetTable(ActivityReservation);
        PanelName := StrSubstNo(ActResLbl, ActivityReservation."Activity No.");
        if ActivityReservation."Client Name" = '' then
            EntityID := ActivityReservation.Description
        else
            EntityID := StrSubstNo(EntityLbl, ActivityReservation.Description, ActivityReservation."Client Name");
    end;

    local procedure SetCommentPanelHeaderForLSCReservation(RecID: RecordId; var EntityID: text; var PanelName: text)
    var
        LSCReservation: Record "LSC Reservation";
        RecRef: recordref;
        ResLbl: Label 'Activity Reservation %1:';
    begin
        if not RecRef.Get(RecID) then
            exit;
        RecRef.SetTable(LSCReservation);
        PanelName := StrSubstNo(ResLbl, LSCReservation."No.");
        EntityID := LSCReservation.Name;
        if EntityID = '' then
            EntityID := LSCReservation.Description;
    end;

    local procedure OpenLSReservationCard(RecID: RecordId)
    var
        LSCReservation: Record "LSC Reservation";
        LSReservationCard: Page "LSC Reservation Card";
        RecRef: recordref;
    begin
        if not RecRef.Get(RecID) then
            exit;
        RecRef.SetTable(LSCReservation);

        LSReservationCard.SetRecord(LSCReservation);
        LSReservationCard.RunModal();
    end;

    local procedure OpenActivityGroupCard(RecID: RecordId)
    var
        ActivityGroup: Record "LSC Activity Group";
        ActivityGroupCard: Page "LSC Activity Group Card";
        RecRef: recordref;
    begin
        if not RecRef.Get(RecID) then
            exit;
        RecRef.SetTable(ActivityGroup);

        ActivityGroupCard.SetRecord(ActivityGroup);
        ActivityGroupCard.RunModal();
    end;

    local procedure OpenActivityCard(RecID: RecordId)
    var
        Activity: Record "LSC Activity Reservation";
        RecRef: recordref;
    begin
        if not RecRef.Get(RecID) then
            exit;
        RecRef.SetTable(Activity);
        CODEUNIT.Run(10015828, Activity);
    end;

    local procedure OpenGroupLineCard(RecID: RecordId)
    var
        ActivityGroupLine: Record "LSC Activity Group Line";
        ActivityGroup: Record "LSC Activity Group";
        RecRef: recordref;
        ActivityGroupCard: Page "LSC Activity Group Card";
    begin
        if not RecRef.Get(RecID) then
            exit;

        RecRef.SetTable(ActivityGroupLine);
        ActivityGroup.Get(ActivityGroupLine."Group No.");
        ActivityGroupCard.SetRecord(ActivityGroup);
        ActivityGroupCard.RunModal();
    end;

    local procedure OpenGroupMemberCard(RecID: RecordId)
    var
        ActivityGroupMember: Record "LSC Activity Group Member";
        ActivityGroup: Record "LSC Activity Group";
        RecRef: recordref;
        ActivityGroupCard: Page "LSC Activity Group Card";
    begin
        if not RecRef.Get(RecID) then
            exit;

        RecRef.SetTable(ActivityGroupMember);
        ActivityGroup.Get(ActivityGroupMember."Group No.");
        ActivityGroupCard.SetRecord(ActivityGroup);
        ActivityGroupCard.RunModal();
    end;

    local procedure GetOtherMemberContactFromActivityReservation(ActivityReservation: Record "LSC Activity Reservation"; var MemberContact: Record "LSC Member Contact"): Boolean
    var
        LSCReservation: Record "LSC Reservation";
    begin
        clear(MemberContact);
        if ActivityReservation."Client No." = '' then
            exit(false);
        if not LSCReservation.get(ActivityReservation."Reservation No.") then
            exit(false);
        if (LSCReservation."Contact No." = ActivityReservation."Client No.") and (LSCReservation."Member Account No." = ActivityReservation."Member Account No.") then
            exit(false);
        if MemberContact.Get(ActivityReservation."Member Account No.", ActivityReservation."Client No.") then
            exit(true);
        exit(False);
    end;

    [Obsolete('Moved to codeunit 10015931', '27.0')]
    procedure InsertFees(ReservationNo: Code[20]; ActivityNo: Code[20]; var NxtLine: Integer; var Sh: Record "Sales Header"; var Sl: Record "Sales Line")
    begin
    end;

    [Obsolete('Moved to codeunit 10015932', '27.0')]
    [IntegrationEvent(false, false)]
    internal procedure OnActivityPaymentUpdate(var ActivityReservation: Record "LSC Activity Reservation")
    begin
    end;

    [Obsolete('Moved to codeunit 10015932', '27.0')]
    [IntegrationEvent(false, false)]
    internal procedure OnActivityAdditionalItemPaymentUpdate(var ActivityAdditionalItem: Record "LSC Activity Additional Item")
    begin
    end;

    [Obsolete('Moved to codeunit 10015931', '27.0')]
    [IntegrationEvent(false, false)]
    internal procedure OnValidToCharge(ActivityReservation: Record "LSC Activity Reservation"; var IsValidToCharge: Boolean)
    begin
    end;

    [Obsolete('Moved to codeunit 10015931', '27.0')]
    [IntegrationEvent(false, false)]
    internal procedure OnBeforeInsertAdditionalDealLines(var ActivityAdditionalItem: Record "LSC Activity Additional Item"; Activities: Record "LSC Activity Reservation"; var Sh: Record "Sales Header"; var Sl: Record "Sales Line"; Multiplier: Integer; var NxtLine: Integer; RefLine: Integer; var IsHandled: Boolean)
    begin
    end;

    [Obsolete('Moved to codeunit 10015931', '27.0')]
    [IntegrationEvent(false, false)]
    internal procedure OnBeforeInsertActivitySalesLine(var Sl: Record "Sales Line"; var NxtLine: Integer; var IsHandled: Boolean)
    begin
    end;
}

