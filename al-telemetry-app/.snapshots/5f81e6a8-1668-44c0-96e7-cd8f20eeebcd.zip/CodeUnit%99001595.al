codeunit 99001595 "LSC Safe Denom. Panel Commands"
{
    //Some procedures have been made public through the "LSC Safe Management Public" codeunit.
    Access = Internal;
    SingleInstance = true;
    TableNo = "LSC POS Menu Line";

    trigger OnRun()
    var
        PosCommandRec: Record "LSC POS Command";
        PosCommand: Enum "LSC POS Command";
        IsHandled: Boolean;
    begin
        if Rec."Pos Event Type" = Rec."Pos Event Type"::PANELCLOSED then
            exit;

        Rec.Processed := true;
        GlobalRec := Rec;
        case GlobalRec."Pos Event Type" of
            GlobalRec."Pos Event Type"::POSCOMMAND,
            GlobalRec."Pos Event Type"::BUTTONPRESS,
            GlobalRec."Pos Event Type"::DATAROWSELECTED,
            GlobalRec."Pos Event Type"::ENTERPRESSED:
                ;
            GlobalRec."Pos Event Type"::PANELCLOSED:
                begin
                    Rec.Processed := false;
                    exit;
                end
            else begin
                ClosingFromEsc_g := true;
                exit;
            end;
        end;

        SafeManagementPublic.OnBeforeAssignActivePanelID(GlobalRec, Rec, PosCommandRec, Ishandled);
        if IsHandled then
            exit;

        ActivePanelID := LastPosEvent.ActivePanelID;
        case ActivePanelID of
            Format("LSC POS Panel Id"::"#SAF-TENDER"):
                HandleSafTenderPanel;
            Format("LSC POS Panel Id"::"#SAF-TENDERCOUNT"):
                HandleSafTenderCountPanel;
            Format("LSC POS Panel Id"::"#OFFLINE"):
                InitSafTenderPanel;
            else begin
                PosCommand := POSCommandRec.CommandToEnum(GlobalRec.Command);
                case PosCommand of
                    PosCommand::FLOAT_ENT,
                    PosCommand::REM_TENDER,
                    PosCommand::TENDER_D,
                    PosCommand::TD_ENDDAY:
                        InitSafTenderPanel;
                end;
            end;
        end;
        Rec := GlobalRec;
    end;

    var
        GlobalRec: Record "LSC POS Menu Line";
        PosTransGlobal: Record "LSC POS Transaction";
        PosCashDecl: Record "LSC POS Cash Declaration";
        PosDataTable: Record "LSC POS Data Table";
        PosPanel: Record "LSC POS Panel";
        PosPanelControl: Record "LSC POS Panel Control Line";
        SafTenderMenuHeader: Record "LSC POS Menu Header";
        MenuLine: Record "LSC POS Menu Line";
        TenderType: Record "LSC Tender Type";
        NoSeries: Record "No. Series";
        POSCashDeclLineTemp: Record "LSC POS Cash Decl. Line" temporary;
        MenuHeaderTmp: Record "LSC POS Menu Header" temporary;
        PosMenuLineTmp: Record "LSC POS Menu Line" temporary;
        PosCashDeclRecordId_g: RecordID;
        LastPosEvent: Codeunit "LSC POS Control Event";
        PosSession: Codeunit "LSC POS Session";
        EPosContext: Codeunit "LSC POS Context";
        EPosCtrl: Codeunit "LSC POS Control Interface";
        TenderDeclaration: Codeunit "LSC Tender Declaration";
        TenderDeclLine: Codeunit "LSC Tender Declaration Line";
        Utils: Codeunit "LSC Tender Decl. Utils";
        POSTransaction: Codeunit "LSC POS Transaction Impl";
        SafeManagementPublic: Codeunit "LSC Safe Management Public";
        PosCashDeclRecRef_g: RecordRef;
        PosCashDeclLineRecRef: RecordRef;
        SafTenderLookup: array[4] of Code[20];
        CurrentReceipt: Code[20];
        PanelID_g: Code[20];
        QuantityID_g: Code[20];
        ActivePanelID: Code[20];
        SafTenderDataTable: Code[20];
        ActiveDataGrid: Text;
        CurrInText: Text;
        Amount_g: Decimal;
        i: Integer;
        bManualBags: Boolean;
        Updated_g: Boolean;
        ShowManualSafeBagNo_g: Boolean;
        ShowManualBankBagNo_g: Boolean;
        FlexibleStartAmountMethod_g: Boolean;
        ClosingFromEsc_g: Boolean;
        Text001: Label '%1 having ID %2 can not be found.';

    procedure InitPanel(Type: Text)
    begin
        PanelID_g := Format("LSC POS Panel Id"::"#SAF-TENDERCOUNT");
        QuantityID_g := '#SAF-INPUT';
        PosSession.SetValue("LSC POS Tag"::TOTALENTERED, '');
        PosSession.SetValue("LSC POS Tag"::"TENDERDECLARATION", TenderDeclaration.GetInfoText);
        PopulateTempCashDeclLine;
        if (GlobalRec.Command = '') and (GlobalRec.Parameter in ['FIXEDFLOAT', 'BANK', 'SAFE']) then
            GlobalRec.Command := Format(Enum::"LSC POS Command"::CUSTOM);
        if LinkCashDeclLineToDataGrid then
            EPosCtrl.ShowPanelModal(PosPanel."Control ID", 'SAFEMANAGEMENTTENDEROPERATIONS,' + GlobalRec.Command + ',' + GlobalRec.Parameter)
        else begin
            EPosCtrl.ResetDataGrid(Format("LSC POS Data Grid Id"::"#SAF-TENDERCOUNTGRID"));
            HandleModalCallback(Type, false);
        end;
        UpdateInfo(true);
    end;

    procedure PopulateTempCashDeclLine()
    var
        POSCashDeclLine: Record "LSC POS Cash Decl. Line";
    begin
        TenderDeclLine.GetCurrRecord(PosCashDecl);
        POSCashDeclLine.SetRange("Receipt No.", PosCashDecl."Receipt No.");
        case TenderDeclaration.GetCurrDeclType of
            1:
                POSCashDeclLine.SetRange("Decl. Type", POSCashDeclLine."Decl. Type"::"Counted Amount");
            2:
                POSCashDeclLine.SetRange("Decl. Type", POSCashDeclLine."Decl. Type"::"Safe Amount");
            3:
                begin
                    POSCashDeclLine.SetRange("Decl. Type", POSCashDeclLine."Decl. Type"::"Bank Amount");
                    if TenderType."Exclude Coins to Bank" then
                        POSCashDeclLine.SetFilter(Type, '<>%1', POSCashDeclLine.Type::Coin);
                end;
            4:
                POSCashDeclLine.SetRange("Decl. Type", POSCashDeclLine."Decl. Type"::"Fixed Float");
        end;
        POSCashDeclLine.SetRange("Tender Type", PosCashDecl."Tender Type");
        POSCashDeclLine.SetRange("Currency Code", PosCashDecl."Currency Code");
        if POSCashDeclLine.FindSet() then begin
            Clear(POSCashDeclLineTemp);
            POSCashDeclLineTemp.DeleteAll;
            repeat
                POSCashDeclLineTemp := POSCashDeclLine;
                POSCashDeclLineTemp.Insert;
            until POSCashDeclLine.Next = 0;
        end;
    end;

    procedure LinkCashDeclLineToDataGrid(): Boolean
    begin
        if not PosSession.GetPosPanelRec(PanelID_g, PosPanel) then begin
            EPosCtrl.PosMessage(StrSubstNo(Text001, PosPanel.TableName, PanelID_g));
            exit(false);
        end;
        if not PosSession.GetDataTableInDataGrid(PosPanel, Format("LSC POS Data Grid Id"::"#SAF-TENDERCOUNTGRID"), PosDataTable) then begin
            EPosCtrl.PosMessage(StrSubstNo(Text001, PosDataTable.TableName, PanelID_g));
            exit(false);
        end;
        PosCashDeclLineRecRef.GetTable(POSCashDeclLineTemp);
        EPosCtrl.InitDataGridControlEx(Format("LSC POS Data Grid Id"::"#SAF-TENDERCOUNTGRID"), PosDataTable."Data Table ID", PosCashDeclLineRecRef);
        exit(true);
    end;

    procedure GetInputQty(): Integer
    var
        InputText: Text;
        InputQty: Integer;
        Text002: Label 'Not a valid input';
    begin
        InputQty := 0;
        InputText := EPosCtrl.GetInputText(QuantityID_g);
        if InputText <> '' then
            if not Evaluate(InputQty, InputText) then begin
                EPosCtrl.PosMessage(Text002);
                exit(0);
            end;
        exit(InputQty);
    end;

    procedure ClearInputValue()
    begin
        EPosCtrl.SetInputText(QuantityID_g, '');
    end;

    procedure EnterQty()
    var
        PosCashDeclLineRecID: RecordID;
        InputQty_l: Integer;
    begin
        InputQty_l := GetInputQty;
        if not EPosCtrl.GetDataGridRecordID(Format("LSC POS Data Grid Id"::"#SAF-TENDERCOUNTGRID"), PosCashDeclLineRecID) then
            exit;
        PosCashDeclLineRecRef.Get(PosCashDeclLineRecID);
        PosCashDeclLineRecRef.SetTable(POSCashDeclLineTemp);
        POSCashDeclLineTemp.Validate("Qty.", InputQty_l);
        POSCashDeclLineTemp.Modify;
        UpdateInfo(true);
        EPosCtrl.GoToNextRow(Format("LSC POS Data Grid Id"::"#SAF-TENDERCOUNTGRID"));
    end;

    procedure ClearQty()
    var
        Text003: Label 'Do you want to set Qty. to zero for all lines?';
    begin
        if Amount_g = 0 then
            exit;

        if not (EPosCtrl.PosConfirm(Text003, true)) then
            exit;

        ClearCashDeclLineTemp;
        UpdateInfo(true);
    end;

    procedure UpdateInfo(Updated_p: Boolean)
    var
        Formatting: Codeunit "LSC POS Formatting";
    begin
        POSCashDeclLineTemp.CalcSums(Total);
        Amount_g := POSCashDeclLineTemp.Total;
        PosSession.SetValue("LSC POS Tag"::TOTALENTERED, Formatting.FormatAmount(Amount_g));
        EPosCtrl.RefreshDataGrid(Format("LSC POS Data Grid Id"::"#SAF-TENDERCOUNTGRID"));
        ClearInputValue;
        Updated_g := Updated_p
    end;

    procedure SaveCashDecl()
    var
        POSCashDeclLine_l: Record "LSC POS Cash Decl. Line";
    begin
        if not (POSCashDeclLineTemp.FindSet) then
            exit;

        repeat
            if POSCashDeclLine_l.Get(POSCashDeclLineTemp."Receipt No.",
                                  POSCashDeclLineTemp."Decl. Type",
                                  POSCashDeclLineTemp."Tender Type",
                                  POSCashDeclLineTemp."Currency Code",
                                  POSCashDeclLineTemp.Type,
                                  POSCashDeclLineTemp.Amount) then begin
                POSCashDeclLine_l.Validate("Qty.", POSCashDeclLineTemp."Qty.");
                POSCashDeclLine_l.Modify;
            end;
        until POSCashDeclLineTemp.Next = 0;
        Commit;
        TenderDeclaration.UpdateCashDecl(PosCashDecl);
    end;

    procedure CancelCashDecl()
    var
        POSCashDeclLine_l: Record "LSC POS Cash Decl. Line";
    begin
        case TenderDeclaration.GetCurrDeclType of
            2:
                PosCashDecl."Safe Amount" := 0;
            3:
                PosCashDecl."Bank Amount" := 0;
            4:
                PosCashDecl."Fixed Float Amount" := 0;
        end;
        if ActivePanelID = Format("LSC POS Panel Id"::"#SAF-TENDER") then
            if POSCashDeclLineTemp.FindSet then
                repeat
                    POSCashDeclLine_l.Get(POSCashDeclLineTemp."Receipt No.",
                      POSCashDeclLineTemp."Decl. Type",
                      POSCashDeclLineTemp."Tender Type",
                      POSCashDeclLineTemp."Currency Code",
                      POSCashDeclLineTemp.Type,
                      POSCashDeclLineTemp.Amount);
                    POSCashDeclLine_l.Delete;
                until POSCashDeclLineTemp.Next = 0;
        TenderDeclaration.UpdateCashDecl(PosCashDecl);
    end;

    procedure CancelAll()
    var
        Text004: Label 'Discard changes?';
    begin
        CancelCashDecl;
        if not Updated_g then begin
            ClosingFromEsc_g := false;
            EPosCtrl.HidePanel(PanelID_g, false);
            exit;
        end;
        if EPosCtrl.PosConfirm(Text004, true) then begin
            ClosingFromEsc_g := false;
            EPosCtrl.HidePanel(PanelID_g, false);
            exit;
        end;
    end;

    procedure ShowPanelWithFilter(PanelID: Code[20]; FilterDataGrid: Option First,Second; FilterFieldNo: array[10] of Integer; FilterText: array[10] of Text; FilterOnly: Boolean)
    var
        PosDataTable: Record "LSC POS Data Table";
    begin
        if not PosSession.GetPosPanelRec(PanelID, PosPanel) then begin
            EPosCtrl.PosMessage(StrSubstNo(Text001, PosPanel.TableName, PanelID));
            exit;
        end;

        PosPanelControl.SetRange("Interface Profile ID", PosPanel."Interface Profile ID");
        PosPanelControl.SetRange("Panel Control ID", PosPanel."Control ID");
        PosPanelControl.SetRange("Control Type", PosPanelControl."Control Type"::"Data Grid");
        case FilterDataGrid of
            FilterDataGrid::First:
                begin
                    if not PosPanelControl.FindFirst then
                        exit;
                end;
            FilterDataGrid::Second:
                begin
                    if not PosPanelControl.FindLast then
                        exit;
                end;
        end;

        if not PosSession.GetDataTableInDataGrid(PosPanel, PosPanelControl."Control ID", PosDataTable) then begin
            exit
        end;

        if SafTenderDataTable = '' then
            SafTenderDataTable := PosDataTable."Data Table ID";
        EPosCtrl.InitDataGridControl(PosPanelControl."Control ID", SafTenderDataTable);
        i := 1;
        while FilterFieldNo[i] <> 0 do begin
            EPosCtrl.SetDataGridFixedFilter(PosPanelControl."Control ID", FilterFieldNo[i], FilterText[i]);
            i += 1;
        end;

        if not FilterOnly then begin
            EPosCtrl.ShowPanelModal(PosPanel."Control ID", 'SAFEMANAGEMENTTENDEROPERATIONS,' + GlobalRec.Command + ',' + GlobalRec.Parameter);
        end;
    end;

    procedure SplitString(pString: Text; Delimiter: Code[10]; var pFilterText: array[10] of Text)
    var
        i: Integer;
        Stop: Boolean;
    begin
        while not Stop do begin
            i += 1;
            if StrPos(pString, Delimiter) > 0 then begin
                pFilterText[i] := CopyStr(pString, 1, StrPos(pString, Delimiter) - 1);
                pString := CopyStr(pString, StrPos(pString, Delimiter) + 1);
            end else begin
                pFilterText[i] := pString;
                Stop := true;
            end;
        end;
    end;

    procedure HandleSafTenderCountPanel()
    begin
        if GlobalRec.Command = Format(Enum::"LSC POS Command"::CUSTOM) then begin
            case GlobalRec.Parameter of
                'CLEAR':
                    ClearQty;
                'CANCELPANEL':
                    CancelAll;
                else
                    GlobalRec.Processed := false
            end;
        end;

        if GlobalRec."Pos Event Type" = GlobalRec."Pos Event Type"::ENTERPRESSED then
            EnterQty;
    end;

    procedure InitSafTenderPanel()
    var
        FilterText: array[10] of Text;
        SafTenderPanelID: Code[20];
        SafTenderMenu1: Code[20];
        FilterFieldNo: array[10] of Integer;
        IsHandled: Boolean;
        Text012: Label 'No current record in POS Transaction. Receipt No.: ';
    begin
        SafTenderPanelID := Format("LSC POS Panel Id"::"#SAF-TENDER");
        SafTenderMenu1 := '#SAF-TENDERMENU1';
        SafTenderLookup[1] := '#SAF-TENDERLOOKUP1';
        SafTenderLookup[2] := '#SAF-TENDERLOOKUP2';
        SafTenderLookup[3] := '#SAF-TENDERLOOKUP3';
        SafTenderLookup[4] := '#SAF-TENDERLOOKUP';
        SafTenderDataTable := '';
        CurrentReceipt := GlobalRec."Current-RECEIPT";
        if not PosTransGlobal.Get(CurrentReceipt) then begin
            Utils.ErrorBeep(Text012 + CurrentReceipt);
            exit;
        end;
        PosSession.GetPosMenuRec(SafTenderMenu1, SafTenderMenuHeader);
        PosCashDecl.SetRange("Receipt No.", GlobalRec."Current-RECEIPT");
        PosCashDecl.FindFirst;
        FilterFieldNo[1] := PosCashDecl.FieldNo("Receipt No.");
        FilterText[1] := GlobalRec."Current-RECEIPT";
        ActiveDataGrid := Format("LSC POS Data Grid Id"::"#SAF-TENDERGRID");
        FlexibleStartAmountMethod(PosCashDecl);
#pragma warning disable AL0432
        SafeManagementPublic.OnBeforeInitMenuOnInitSafTenderPanel(PosCashDecl, PosTransGlobal, TenderDeclaration, IsHandled, SafTenderDataTable);
#pragma warning restore AL0432
        SafeManagementPublic.OnBeforeInitMenuOnInitSafTenderPanel2(PosCashDecl, PosTransGlobal, TenderDeclaration, IsHandled, SafTenderDataTable);
        if IsHandled then
            exit;

        if TenderDeclaration.IsEndOfDay then begin
            if FlexibleStartAmountMethod_g then begin
                SafTenderDataTable := SafTenderLookup[2]
            end;
            MenuTenderShow('ENDDAY');
        end else
            if TenderDeclaration.IsRemoveTender then begin
                SafTenderDataTable := SafTenderLookup[2];
                MenuTenderShow('REMTENDER');
            end else
                if TenderDeclaration.IsFloatEntry then begin
                    if PosTransGlobal."Start Float Entry" then begin
                        SafTenderDataTable := SafTenderLookup[1];
                        MenuTenderShow('FLOATSTART');
                    end else begin
                        SafTenderDataTable := SafTenderLookup[3];
                        MenuTenderShow('FLOATENTRY');
                    end;
                end else begin
                    SafTenderDataTable := SafTenderLookup[1];
                    MenuTenderShow('FLOATSTART');
                end;
        MenuTenderTop(true, PosCashDecl);
        ShowPanelWithFilter(SafTenderPanelID, 0, FilterFieldNo, FilterText, false);

        EPosCtrl.ResetDataGrid(ActiveDataGrid);
    end;

    procedure MenuTenderTop(FirstLoad: Boolean; PosCashDecl: Record "LSC POS Cash Declaration")
    var
        Text015: Label 'Bank Bag No.:';
        Text016: Label 'Safe Bag No.:';
        Text017: Label 'Fixed Float No.:';
    begin
        EPosContext.Clear;
        EPosContext.Create(Format("LSC POS Panel Id"::"#SAF-TENDER"));
        EPosContext.SetKeyValue('<#AMOUNTTYPE>', TenderDeclaration.GetInfoText);
        EPosContext.SetKeyValue('<#TENDERTYPE>', PosCashDecl.Description);
        if ShowBankBagNo then begin
            EPosContext.SetKeyValue('<#BANKBAGTEXT>', Text015);
            EPosContext.SetKeyValue('<#BANKBAGNO>', Format(PosCashDecl."Bank Bag No."));
        end else begin
            EPosContext.SetKeyValue('<#BANKBAGTEXT>', '');
            EPosContext.SetKeyValue('<#BANKBAGNO>', '');
        end;
        if ShowSafeBagNo then begin
            EPosContext.SetKeyValue('<#SAFEBAGTEXT>', Text016);
#pragma warning disable AL0432
            EPosContext.SetKeyValue('<#SAFEBAGNO>', Format(PosCashDecl."Safe Bag No."));
#pragma warning restore AL0432
        end else begin
            EPosContext.SetKeyValue('<#SAFEBAGTEXT>', '');
            EPosContext.SetKeyValue('<#SAFEBAGNO>', '');
        end;
        if ShowFixedBagNo then begin
            EPosContext.SetKeyValue('<#FIXEDBAGTEXT>', Text017);
#pragma warning disable AL0432
            EPosContext.SetKeyValue('<#FIXEDFLOATBAGNO>', PosCashDecl."Fixed Float Bag No.");
#pragma warning restore AL0432
        end else begin
            EPosContext.SetKeyValue('<#FIXEDBAGTEXT>', '');
            EPosContext.SetKeyValue('<#FIXEDFLOATBAGNO>', '');
        end;
#pragma warning disable AL0432
        EPosContext.SetKeyValue('<#FIXEDFLOATBAGNO>', PosCashDecl."Fixed Float Bag No.");
#pragma warning restore AL0432
        if PosSession.StaffShowTransAmt then begin
            if ShowTransAmount then begin
                EPosContext.SetKeyValue('<#TransAmountVisible>', 'Transaction Amount: ');
                EPosContext.SetKeyValue('<#TRANSAMOUNT>', Format(PosCashDecl."Trans. Amount"));
            end else begin
                EPosContext.SetKeyValue('<#TransAmountVisible>', '');
                EPosContext.SetKeyValue('<#TRANSAMOUNT>', '');
            end;
        end else begin
            EPosContext.SetKeyValue('<#TransAmountVisible>', '');
            EPosContext.SetKeyValue('<#TRANSAMOUNT>', '');
        end;
        SafeManagementPublic.OnBeforeSendContextOnMenuTenderTop(EPosContext);
        EPosCtrl.SendContext(EPosContext);
    end;

    procedure HandleSafTenderPanel()
    var
        IsHandled: Boolean;
        Text007: Label 'Do you want to cancel the Tender Declaration?';
        Text011: Label 'You must select Bank or Safe column first';
        Text014: Label 'Do you want to proceed to post uncounted End of Day Declaration?';
    begin
        SafeManagementPublic.OnBeforeHandleSafTenderPanel(PosTransGlobal, GlobalRec.Parameter, PosSession);
        ActiveDataGrid := Format("LSC POS Data Grid Id"::"#SAF-TENDERGRID");
        if not EPosCtrl.GetDataGridRecordID(ActiveDataGrid, PosCashDeclRecordId_g) then
            exit;
        if PosCashDeclRecRef_g.Get(PosCashDeclRecordId_g) then
            PosCashDeclRecRef_g.SetTable(PosCashDecl);
        SetFormID('TD_DECLARE');
        PosSession.SetValue("LSC POS Tag"::"SAF-CANCEL-SOD", '');
        case GlobalRec."Pos Event Type" of
            GlobalRec."Pos Event Type"::DATAROWSELECTED:
                MenuTenderTop(false, PosCashDecl);
            GlobalRec."Pos Event Type"::ENTERPRESSED:
                GetSelectedColumn;
        end;
        if GlobalRec."Pos Event Type" in [
            GlobalRec."Pos Event Type"::BUTTONPRESS,
            GlobalRec."Pos Event Type"::POSCOMMAND,
            GlobalRec."Pos Event Type"::ENTERPRESSED
        ] then begin
            TenderDeclLine.SetCurrRecord(PosCashDecl);

            IsHandled := false;
            SafeManagementPublic.OnBeforeGlobalRecParametersSafTenderPanel(PosTransGlobal, GlobalRec, PosSession, PosCashDecl, IsHandled);
            if IsHandled then
                exit;

            case GlobalRec.Parameter of
                'FIXEDFLOAT':
                    begin
                        GetCurrInput;
                        FixedFloatPressed;
                        if TenderDeclaration.GetFormID = 'TD_DENOM' then begin
                            InitPanel(GlobalRec.Parameter);
                            exit;
                        end
                        else
                            HandleModalCallback(GlobalRec.Parameter, false);
                    end;
                'BANK':
                    begin
                        GetCurrInput;
                        BankPressed;
                        if TenderDeclaration.GetFormID = 'TD_DENOM' then begin
                            InitPanel(GlobalRec.Parameter);
                            exit;
                        end
                        else
                            HandleModalCallback(GlobalRec.Parameter, false);
                    end;
                'SAFE':
                    begin
                        GetCurrInput;
                        SafePressed;
                        if TenderDeclaration.GetFormID = 'TD_DENOM' then begin
                            InitPanel(GlobalRec.Parameter);
                            exit;
                        end
                        else
                            HandleModalCallback(GlobalRec.Parameter, false);
                    end;
                'BAGNO':
                    begin
                        GetSelectedColumn;
                        if (GlobalRec.Parameter = 'BANK') or (GlobalRec.Parameter = 'SAFE') then begin
                            BagNoPressed;
                        end else
                            Utils.ErrorBeep(Text011);
                    end;
                'PRINT':
                    begin
                        PrintSlip;
                    end;
                'CLEAR':
                    begin
                        ClearPressed;
                    end;
                'POST':
                    begin
                        if PostPressed then begin
                            SafeManagementPublic.OnHandleSafTenderPanel_OnPost_OnOfflinePlanelCheck(IsHandled);
                            if PosTransGlobal."Start Float Entry" and (PosSession.GetValue("LSC POS Tag"::TD_OFFLPANEL) <> '') or IsHandled then begin
                                PosSession.SetValue("LSC POS Tag"::"SAF-CANCEL-SOD", 'LOGOFF');
                                EPosCtrl.PostCommand("LSC POS Command"::LOGOFF, '');
                                POSTransaction.Close(true);
                            end;
                            ClosingFromEsc_g := false;
                            EPosCtrl.HidePanel(ActivePanelID, true);
                        end;
                    end;
                'POSTUNCOUNT':
                    begin
                        if not (EPosCtrl.PosConfirm(Text014, false)) then
                            exit;
                        if PostUncountedPressed then begin
                            ClosingFromEsc_g := false;
                            EPosCtrl.HidePanel(ActivePanelID, true);
                        end;
                    end;
                'CANCELPANEL':
                    begin
                        if not EPosCtrl.PosConfirm(Text007, false) then
                            exit;

                        PosSession.SetValue("LSC POS Tag"::"SAF-VOIDEDPANEL", ActivePanelID);
                        PosSession.SetValue("LSC POS Tag"::"CANCELBUTTONPRESSED", 'YES');
                        POSTransaction.VoidPressed;
                        if PosTransGlobal."Start Float Entry" or (PosSession.GetValue("LSC POS Tag"::TD_OFFLPANEL) <> '') then begin
                            PosSession.SetValue("LSC POS Tag"::"SAF-CANCEL-SOD", 'LOGOFF');
                            EPosCtrl.PostCommand("LSC POS Command"::LOGOFF, '');
                            POSTransaction.Close(true);
                        end
                        else
                            CancelPressed;
                        ClosingFromEsc_g := false;
                        EPosCtrl.HidePanel(ActivePanelID, true);
                        PosSession.SetValue("LSC POS Tag"::"SAF-VOIDEDPANEL", '');
                    end
                else
                    GlobalRec.Processed := false;
            end;
            EPosCtrl.RefreshDataGrid(ActiveDataGrid);
            MenuTenderTop(true, PosCashDecl);
            EPosCtrl.SetInputText('#SAF-AMOUNT', '');
        end;
    end;

    procedure SetPosTransaction(PosTrans: Record "LSC POS Transaction")
    begin
        TenderDeclaration.SetTransaction(PosTrans);
    end;

    procedure SetWarningOk(WarnOk: Boolean)
    begin
        TenderDeclaration.SetWarningOk(WarnOk);
    end;

    procedure CreateTenderDeclTable()
    begin
        TenderDeclaration.CreateTenderDeclTable;
    end;

    procedure GetTenderDeclState(): Code[20]
    begin
        exit(TenderDeclaration.GetTenderDeclState);
    end;

    procedure GetLastReceiptNo(): Code[20]
    begin
        exit(TenderDeclaration.GetLastReceiptNo);
    end;

    procedure GetLastTransaction(var Trans: Record "LSC Transaction Header")
    begin
        TenderDeclaration.GetLastTransaction(Trans);
    end;

    procedure Init()
    begin
        TenderDeclaration.Init;
    end;

    procedure SetFormID(ID: Code[20])
    begin
        TenderDeclaration.SetFormID(ID);
    end;

    procedure GetFormID(): Code[20]
    begin
        exit(TenderDeclaration.GetFormID);
    end;

    procedure BankPressed()
    begin
        TenderDeclaration.BankPressed(CurrInText);
    end;

    procedure BagNoPressed()
    var
        Text008: Label 'Not allowed to enter Bag No. manually.';
        Text009: Label 'No. Series %1 not found';
        Text010: Label 'No. Series %1 does not allow Manual Numbers';
    begin
        Commit;
        TenderDeclLine.GetCurrRecord(PosCashDecl);
        if not TenderType.Get(PosCashDecl."Store No.", PosCashDecl."Tender Type") then begin
            Utils.ErrorBeep('');
            exit;
        end;
        if GlobalRec.Parameter = 'BANK' then begin
            if TenderType."Bank Bags No. Type" <> TenderType."Bank Bags No. Type"::"Manual Numbers" then begin
                if TenderType."Bank Bags No. Type" <> TenderType."Bank Bags No. Type"::"No. Series" then begin
                    Utils.ErrorBeep(Text008);
                    exit;
                end
                else begin
                    if not NoSeries.Get(TenderType."Bank Bags Nos.") then begin
                        Utils.ErrorBeep(StrSubstNo(Text009, TenderType."Bank Bags Nos."));
                        exit;
                    end;
                    if not NoSeries."Manual Nos." then begin
                        Utils.ErrorBeep(StrSubstNo(Text010, TenderType."Bank Bags Nos."));
                        exit;
                    end;
                end;
            end;
            EPosCtrl.OpenAlphabeticKeyboard(PosCashDecl.FieldCaption("Bank Bag No."), '', false, BankBagPayload, MaxStrLen(PosCashDecl."Bank Bag No."));
        end else begin
            if TenderType."Safe Bags No. Type" <> TenderType."Safe Bags No. Type"::"Manual Numbers" then begin
                if TenderType."Safe Bags No. Type" <> TenderType."Safe Bags No. Type"::"No. Series" then begin
                    Utils.ErrorBeep(Text008);
                    exit;
                end
                else begin
                    if not NoSeries.Get(TenderType."Safe Bags Nos.") then begin
                        Utils.ErrorBeep(StrSubstNo(Text009, TenderType."Safe Bags Nos."));
                        exit;
                    end;
                    if not NoSeries."Manual Nos." then begin
                        Utils.ErrorBeep(StrSubstNo(Text010, TenderType."Safe Bags Nos."));
                        exit;
                    end;
                end;
            end;
#pragma warning disable AL0432
            EPosCtrl.openAlphabetickeyboard(PosCashDecl.FieldCaption("Safe Bag No."), '', false, SafeBagPayload, MaxStrLen(PosCashDecl."Safe Bag No."));
#pragma warning restore AL0432
        end;
    end;

    procedure SafePressed()
    begin
        TenderDeclaration.SafePressed(CurrInText);
    end;

    procedure BagOrSafeNoPressedOnClosePanel(pBagNo: Text; pPayload: Text)
    var
        POSTransactionEventsPub: Codeunit "LSC POS Transaction";
    begin
        if pPayload = SafeBagPayload then
#pragma warning disable AL0432
            PosCashDecl."Safe Bag No." := CopyStr(pBagNo, 1, MaxStrLen(PosCashDecl."Safe Bag No."))
#pragma warning restore AL0432
        else
            PosCashDecl."Bank Bag No." := CopyStr(pBagNo, 1, MaxStrLen(PosCashDecl."Bank Bag No."));
        PosCashDecl.Modify;
        TenderDeclLine.GetCurrRecord(PosCashDecl);
        Commit;
        POSTransactionEventsPub.OnAfterBagorSafeNoPressedOnClosePanel(GlobalRec.Parameter, PosCashDecl);
    end;

    procedure BankBagPayload(): Text
    begin
        exit('#SAFEDENOM-BANKBAGNO');
    end;

    procedure SafeBagPayload(): Text
    begin
        exit('#SAFEDENOM-SAFEBAGNO');
    end;

    procedure FixedFloatPressed()
    begin
        TenderDeclaration.FixedFloatPressed(CurrInText);
    end;

    procedure ClearPressed(): Boolean
    var
        Text006: Label 'Do you want to clear this form?';
    begin
        if not EPosCtrl.PosConfirm(Text006, false) then
            exit(false);
        ClearForm;

        CurrInText := '';
        exit(true);
    end;

    procedure ClearForm()
    begin
        PosCashDecl.SetRange("Receipt No.", CurrentReceipt);
        if PosCashDecl.FindSet() then begin
            repeat
                PosCashDecl.Validate(Amount, 0);
                Utils.CreateDenomTable(PosCashDecl, 0, 0);

                PosCashDecl.Validate("Safe Amount", 0);
                Utils.CreateDenomTable(PosCashDecl, 1, 0);
#pragma warning disable AL0432                
                PosCashDecl."Safe Bag No." := '';
#pragma warning restore AL0432               

                PosCashDecl.Validate("Bank Amount", 0);
                Utils.CreateDenomTable(PosCashDecl, 2, 0);
                PosCashDecl."Bank Bag No." := '';

                PosCashDecl.Validate("Fixed Float Amount", 0);
                Utils.CreateDenomTable(PosCashDecl, 3, 0);
#pragma warning disable AL0432
                PosCashDecl."Fixed Float Bag No." := '';
#pragma warning restore AL0432

                PosCashDecl.Modify;
            until PosCashDecl.Next = 0;

            PosCashDecl.FindFirst;
            POSCashDeclLineTemp.Reset;
            ClearCashDeclLineTemp;
            MenuTenderTop(false, PosCashDecl);
        end;

        EPosCtrl.ResetDataGrid(ActiveDataGrid);
    end;

    procedure PostPressed(): Boolean
    begin
        exit(TenderDeclaration.PostPressed);
    end;

    procedure PostUncountedPressed(): Boolean
    begin
        exit(TenderDeclaration.PostUnCountedTrans);
    end;

    procedure CancelPressed()
    begin
        TenderDeclaration.SetTenderDeclState('CANCEL')
    end;

    procedure GetCurrInput()
    begin
        Clear(CurrInText);
        CurrInText := EPosCtrl.GetInputText('#SAF-AMOUNT');
    end;

    procedure PrintSlip()
    begin
        TenderDeclaration.PrintSlip;
    end;

    procedure CheckManualBags()
    var
        PosCashDeclTmp: Record "LSC POS Cash Declaration";
    begin
        bManualBags := false;
        PosCashDeclTmp.Init;
        PosCashDeclTmp.SetRange("Receipt No.", CurrentReceipt);
        if PosCashDeclTmp.FindSet() then begin
            repeat
                if not TenderType.Get(PosCashDeclTmp."Store No.", PosCashDeclTmp."Tender Type") then
                    exit;

                if not FlexibleStartAndManualBags(PosCashDeclTmp, TenderType) then begin
                    if TenderType."Bank Bags No. Type" = TenderType."Bank Bags No. Type"::"Manual Numbers" then begin
                        bManualBags := true;
                    end;
                    if TenderType."Bank Bags No. Type" = TenderType."Bank Bags No. Type"::"No. Series" then begin
                        if not NoSeries.Get(TenderType."Bank Bags Nos.") then begin
                            bManualBags := true;
                        end else begin
                            if NoSeries."Manual Nos." then
                                bManualBags := true;
                        end;
                    end;
                    if TenderType."Safe Bags No. Type" = TenderType."Safe Bags No. Type"::"Manual Numbers" then begin
                        bManualBags := true;
                    end;
                    if TenderType."Safe Bags No. Type" = TenderType."Safe Bags No. Type"::"No. Series" then begin
                        if not NoSeries.Get(TenderType."Safe Bags Nos.") then begin
                            bManualBags := true;
                        end else begin
                            if NoSeries."Manual Nos." then
                                bManualBags := true;
                        end;
                    end;
                end;
            until (PosCashDeclTmp.Next = 0) or bManualBags;
        end;
    end;

    procedure MenuTenderShow(MenuName: Code[10])
    var
        bMoveLine: Boolean;
        IsHandled: Boolean;
    begin
        SafeManagementPublic.OnBeforeMenuTenderShow(IsHandled);
        if IsHandled then
            exit;
        Clear(MenuHeaderTmp);
        MenuHeaderTmp.DeleteAll;
        Clear(PosMenuLineTmp);
        PosMenuLineTmp.DeleteAll;
        MenuHeaderTmp := SafTenderMenuHeader;
        CheckManualBags;
        case MenuName of
            'FLOATSTART':
                MenuHeaderTmp.Rows := 5;
            'FLOATENTRY':
                begin
                    MenuHeaderTmp.Rows := 9;
                end;
            'REMTENDER':
                if bManualBags then
                    MenuHeaderTmp.Rows := 7 else
                    MenuHeaderTmp.Rows := 6;
            'ENDDAY':
                begin
                    if bManualBags and not (FlexibleStartAmountMethod_g) then
                        MenuHeaderTmp.Rows := 9
                    else
                        if FlexibleStartAmountMethod_g and not (bManualBags) then
                            MenuHeaderTmp.Rows := 7
                        else
                            MenuHeaderTmp.Rows := 8;
                end;
        end;
        MenuHeaderTmp.Insert;
        SafeManagementPublic.OnBeforeUploadMenuHeaderRec(MenuHeaderTmp, SafTenderMenuHeader."Profile ID", SafTenderMenuHeader."Menu ID", MenuName);
        EPosCtrl.UploadMenuHeaderRec(MenuHeaderTmp, SafTenderMenuHeader."Profile ID", SafTenderMenuHeader."Menu ID");

        i := 1;
        MenuLine.Init;
        MenuLine.SetRange("Profile ID", SafTenderMenuHeader."Profile ID");
        MenuLine.SetRange("Menu ID", SafTenderMenuHeader."Menu ID");
        if MenuLine.FindSet then
            repeat
                bMoveLine := true;
#Pragma warning disable AL0432
                SafeManagementPublic.OnBeforeSetMoveLine(MenuName, MenuLine, bMoveLine, IsHandled);
#Pragma warning restore AL0432
                SafeManagementPublic.OnBeforeSetMoveMenuLine(MenuName, MenuLine, bMoveLine, IsHandled);
                if not IsHandled then begin
                    if MenuName = 'FLOATSTART' then
                        if (MenuLine.Parameter = 'SAFE') or (MenuLine.Parameter = 'BANK') or (MenuLine.Parameter = 'BAGNO') or
                        (MenuLine.Parameter = 'POSTUNCOUNT') then
                            bMoveLine := false;
                    if MenuName = 'REMTENDER' then
                        if (MenuLine.Parameter = 'FIXEDFLOAT') or (MenuLine.Parameter = 'POSTUNCOUNT') or ((MenuLine.Parameter = 'BAGNO') and (not bManualBags)) then
                            bMoveLine := false;

                    if (MenuName = 'ENDDAY') then
                        if ((MenuLine.Parameter = 'FIXEDFLOAT') and FlexibleStartAmountMethod_g) or ((MenuLine.Parameter = 'BAGNO') and (not bManualBags)) then
                            bMoveLine := false;
                end;

                if bMoveLine then begin
                    PosMenuLineTmp := MenuLine;
                    PosMenuLineTmp."Key No." := i;
                    i := i + 1;
                    PosMenuLineTmp.Insert;
                    EPosCtrl.UploadMenuLineRec(PosMenuLineTmp, SafTenderMenuHeader."Profile ID", SafTenderMenuHeader."Menu ID", Format(PosMenuLineTmp."Key No."));
                end;
            until MenuLine.Next = 0;
    end;

    procedure GetSelectedColumn()
    var
        IsHandled: boolean;
    begin
        SafeManagementPublic.OnBeforeGetSelectedColumn(GlobalRec.Parameter, IsHandled);
        if IsHandled then
            exit;

        i := EPosCtrl.GetGridSelectedColumn(ActiveDataGrid);
        if TenderDeclaration.IsEndOfDay then begin
            if FlexibleStartAmountMethod_g then
                case i of
                    3:
                        GlobalRec.Parameter := 'BANK';
                    4:
                        GlobalRec.Parameter := 'SAFE';
                end
            else
                case i of
                    3:
                        GlobalRec.Parameter := 'FIXEDFLOAT';
                    4:
                        GlobalRec.Parameter := 'BANK';
                    5:
                        GlobalRec.Parameter := 'SAFE';
                end;
        end else
            if TenderDeclaration.IsRemoveTender then begin
                case i of
                    3:
                        GlobalRec.Parameter := 'BANK';
                    4:
                        GlobalRec.Parameter := 'SAFE';
                end;
            end else
                if TenderDeclaration.IsFloatEntry then begin
                    if PosTransGlobal."Start Float Entry" then begin
                        GlobalRec.Parameter := 'FIXEDFLOAT';
                    end else begin
                        GlobalRec.Parameter := 'SAFE';
                    end;
                end else begin
                    GlobalRec.Parameter := 'FIXEDFLOAT';
                end;
        TenderDeclLine.SetActiveColumn(GlobalRec.Parameter);
    end;

    procedure ShowBankBagNo() ShowBankBagNo_l: Boolean
    var
        ReturnValue: Boolean;
        IsHandled: Boolean;
    begin
        SafeManagementPublic.OnBeforeShowBankBagNo(IsHandled, ReturnValue);
        if IsHandled then
            exit(ReturnValue);

        if FlexibleStartAmountMethod_g and ShowManualBankBagNo_g then begin
            if not (TenderDeclaration.IsFloatEntry) then
                ShowBankBagNo_l := true;
        end else
            if (SafTenderDataTable = '') or (SafTenderDataTable = SafTenderLookup[4]) or (SafTenderDataTable = SafTenderLookup[2]) then
                ShowBankBagNo_l := true
            else
                ShowBankBagNo_l := false;
    end;

    procedure ShowSafeBagNo() ShowSafeBagNo_l: Boolean
    var
        ReturnValue: Boolean;
        IsHandled: Boolean;
    begin
        SafeManagementPublic.OnBeforeShowSafeBagNo(IsHandled, ReturnValue);
        if IsHandled then
            exit(ReturnValue);

        if FlexibleStartAmountMethod_g and ShowManualSafeBagNo_g then begin
            ShowSafeBagNo_l := true;
        end else
            if (SafTenderDataTable = '') or (SafTenderDataTable = SafTenderLookup[4]) or (SafTenderDataTable = SafTenderLookup[2]) then
                ShowSafeBagNo_l := true
            else
                ShowSafeBagNo_l := false;
    end;

    procedure ShowFixedBagNo() ShowFixedBagNo_l: Boolean
    var
        ReturnValue: Boolean;
        IsHandled: Boolean;
    begin
        SafeManagementPublic.OnBeforeShowFixedBagNo(IsHandled, ReturnValue);
        if IsHandled then
            exit(ReturnValue);

        if FlexibleStartAmountMethod_g then begin
            ShowFixedBagNo_l := false;
        end else
            if (SafTenderDataTable = '') or (SafTenderDataTable = SafTenderLookup[4]) or (SafTenderDataTable = SafTenderLookup[1]) then
                ShowFixedBagNo_l := true
            else
                ShowFixedBagNo_l := false;
    end;

    procedure ShowTransAmount(): Boolean
    var
        bShowAmt: Boolean;
    begin
        bShowAmt := true;
        if (TenderDeclaration.IsRemoveTender) or (TenderDeclaration.GetTenderDeclState() = 'CANCEL') then
            bShowAmt := false
        else
            if TenderDeclaration.IsFloatEntry then
                if not PosTransGlobal."Start Float Entry" then
                    bShowAmt := false;
        exit(bShowAmt);
    end;

    procedure IsSafeManagementPanel(pPanelId: Code[20]): Boolean
    begin
        case pPanelId of
            Format("LSC POS Panel Id"::"#SAF-TENDER"), Format("LSC POS Panel Id"::"#SAF-TENDERCOUNT"):
                exit(true);
        end;

        exit(false);
    end;

    procedure ClearCashDeclLineTemp()
    begin
        if POSCashDeclLineTemp.FindSet then
            repeat
                POSCashDeclLineTemp.Validate("Qty.", 0);
                POSCashDeclLineTemp.Modify;
            until POSCashDeclLineTemp.Next = 0;
    end;

    procedure FlexibleStartAmountMethod(POSCashDeclaration_p: Record "LSC POS Cash Declaration") FlexibleStartAmountMethod: Boolean
    var
        Store_l: Record "LSC Store";
    begin
        Store_l.Get(POSCashDeclaration_p."Store No.");
        if (Store_l."POS Start Amount Method" = Store_l."POS Start Amount Method"::Flexible) then begin
            FlexibleStartAmountMethod_g := true;
            exit(true);
        end else begin
            FlexibleStartAmountMethod_g := false;
            exit(false);
        end
    end;

    procedure FlexibleStartAndManualBags(POSCashDeclaration_p: Record "LSC POS Cash Declaration"; TenderType_p: Record "LSC Tender Type") FlexibleAndManualbags: Boolean
    begin
        FlexibleAndManualbags := false;
        if TenderType."Float Allowed" then
            if FlexibleStartAmountMethod(POSCashDeclaration_p) then begin
                ShowManualBagNos(TenderType);
                FlexibleAndManualbags := true;
            end;
    end;

    procedure ShowManualBagNos(TenderType_p: Record "LSC Tender Type")
    begin
        ShowManualBankBagNo_g := false;
        ShowManualSafeBagNo_g := false;

        if TenderType_p."Use Bags for Bank" and (TenderType_p."Bank Bags No. Type" = TenderType_p."Bank Bags No. Type"::"Manual Numbers") then
            ShowManualBankBagNo_g := true;
        if TenderType_p."Use Bags for Safe" and (TenderType_p."Safe Bags No. Type" = TenderType_p."Safe Bags No. Type"::"Manual Numbers") then
            ShowManualSafeBagNo_g := true;

        if ShowManualSafeBagNo_g or ShowManualBankBagNo_g then
            bManualBags := true;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Controller", OnAfterNotGetInitialized, '', true, true)]
    local procedure OnAfterNotGetInitialized()
    begin
        EPosCtrl.RegisterPanelClosedEvent(Format("LSC POS Panel Id"::"#SAF-TENDER"));
        EPosCtrl.RegisterPanelClosedEvent(Format("LSC POS Panel Id"::"#SAF-TENDERCOUNT"));
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Controller", OnModalPanelResult, '', true, true)]
    local procedure OnModalPanelResult(panelID: Text; resultOK: Boolean; payload: Text; var processed: Boolean)
    begin
        if true in [
            processed,
            not resultOK,
            not payload.StartsWith('SAFEMANAGEMENT')
        ] then
            exit;
        case SelectStr(2, payload) of
            '', 'CUSTOM':
                HandleModalCallback(SelectStr(2, payload), true);
            'REM_TENDER', 'FLOAT_ENT', 'TENDER_D', 'MENUUPDATE':
                TD_CommandPressedCallback(false);
            'TD_ENDDAY':
                TD_CommandPressedCallback(true);
        end;
        processed := true;
    end;

    procedure HandleModalCallback(Type: Text; pSaveCashDecl: Boolean)
    begin
        if pSaveCashDecl then
            SaveCashDecl;

        case Type of
            'FIXEDFLOAT':
                begin
                    if TenderDeclaration.IsEndOfDay then begin
                        EPosCtrl.SelectGridColumn(ActiveDataGrid, 3, 1);
                    end;
                end;
            'BANK':
                begin
                    if TenderDeclaration.IsEndOfDay then begin
                        if FlexibleStartAmountMethod_g then
                            EPosCtrl.SelectGridColumn(ActiveDataGrid, 3, 1)
                        else
                            EPosCtrl.SelectGridColumn(ActiveDataGrid, 4, 1);
                    end else begin
                        if TenderDeclaration.IsRemoveTender then begin
                            EPosCtrl.SelectGridColumn(ActiveDataGrid, 3, 1);
                        end else begin
                            if TenderDeclaration.IsFloatEntry then begin
                                if not PosTransGlobal."Start Float Entry" then begin
                                    EPosCtrl.SelectGridColumn(ActiveDataGrid, 3, 1);
                                end;
                            end;
                        end;
                    end;
                end;
            'SAFE':
                begin
                    if TenderDeclaration.IsEndOfDay then begin
                        EPosCtrl.SelectGridColumn(ActiveDataGrid, 5, 1);
                    end else begin
                        if TenderDeclaration.IsRemoveTender then begin
                            EPosCtrl.SelectGridColumn(ActiveDataGrid, 4, 1);
                        end else begin
                            if TenderDeclaration.IsFloatEntry then begin
                                if not PosTransGlobal."Start Float Entry" then begin
                                    EPosCtrl.SelectGridColumn(ActiveDataGrid, 3, 1);
                                end;
                            end;
                        end;
                    end;
                end;
            '':
                begin
                    POSTransaction.Init();
                    POSTransaction.SetPOSState("LSC POS Transaction State"::SALES);
                    POSTransaction.SetFunctionMode("LSC POS Command"::ITEM);
                    POSTransaction.SelectDefaultMenu;
                    POSTransaction.NewSalePressed();
                end;
        end;

        TenderDeclLine.GetCurrRecord(PosCashDecl);
        EPosCtrl.RefreshDataGrid(ActiveDataGrid);
        MenuTenderTop(true, PosCashDecl);
        EPosCtrl.SetInputText('#SAF-AMOUNT', '');
    end;

    procedure TD_CommandPressedCallback(EndOfDay: Boolean)
    var
        ServiceLocator: Codeunit "LSC Service Locator";
        POSTransactionEventsPub: Codeunit "LSC POS Transaction";
        POSTransactionEvents: Codeunit "LSC POS Transaction Events";
        Transaction: Record "LSC Transaction Header";
        TransactionRec: Record "LSC POS Transaction";
        PosCashDecl: Record "LSC POS Cash Declaration";
        TendDeclState: Code[20];
        LastReceiptNo, LastSlipNo : Code[20];
        LogOffOk: Boolean;
        LineWithAmount: Boolean;
        IsHandled: Boolean;
        NoSuspPOSTransactionsVoided: Integer;
    begin
        TendDeclState := GetTenderDeclState;
        POSTransactionEvents.OnBeforeTD_CommandPressedCallback(TendDeclState);
        LastReceiptNo := GetLastReceiptNo;
        if TendDeclState = 'POSTED' then begin
            if StrLen(LastReceiptNo) > 9 then
                LastReceiptNo := DelStr(LastReceiptNo, 1, StrLen(LastReceiptNo) - 9);
            LastReceiptNo := DelChr(LastReceiptNo, '<', '0');
            ServiceLocator.POSFunctions.ReadLocalVar(LastSlipNo);
            if (LastReceiptNo <> '') and (LastReceiptNo <> LastSlipNo) then
                LastSlipNo := LastReceiptNo;

            GetLastTransaction(Transaction);
            POSTransactionEventsPub.OnAfterTDPressedPOSTEDState(Transaction);
            POSTransaction.TSUtil.SendAtEndOfTransaction(Transaction);
            Commit;

            PosTransaction.GetPOSTransaction(TransactionRec);
            if TransactionRec."Start Float Entry" then
                POSTransaction.InsertTmpTransaction(true)
            else
                POSTransaction.InsertTmpTransaction(false);

            POSTransaction.ClearGlobs();
            LogOffOk := EndOfDay;
            POSTransaction.PickUpWarning(Transaction);
        end;

        if TendDeclState = 'CANCEL' then begin
            LineWithAmount := false;
            Clear(PosCashDecl);
            PosTransaction.GetPOSTransaction(TransactionRec);
            PosCashDecl.SetRange("Receipt No.", TransactionRec."Receipt No.");
            if PosCashDecl.FindSet then begin
                repeat
                    if (PosCashDecl.Amount <> 0) or (PosCashDecl."Bank Amount" <> 0) then
                        LineWithAmount := true;
                until (PosCashDecl.Next = 0) or LineWithAmount;
            end;
        end;
        if TendDeclState = 'UNCOUNTED' then begin
            GetLastTransaction(Transaction);
            POSTransaction.TSUtil.SendAtEndOfTransaction(Transaction);
            Commit;
            LogOffOk := true;
        end;

        POSTransaction.TSSendUnsentTransactions;
        POSTransaction.TSCheckError;
        POSSESSION.SetValue("LSC POS Tag"::"TD_PARAM", '');

        if LogOffOk then begin

            if EndOfDay then begin
                if PosSession.FunctionalityProfile."Z-Rep Autopr. after T.Dec EOD" then begin
                    if POSTransaction.POSTransPrint.IsPrinterActive() then
                        POSTransaction.PrintZReport(false, false)
                    else
                        if (PosSession.FunctionalityProfile."Z-Report Suspend Trans.Process" = PosSession.FunctionalityProfile."Z-Report Suspend Trans.Process"::"Delete older than") or (PosSession.FunctionalityProfile."Z-Report Suspend Trans.Process" = PosSession.FunctionalityProfile."Z-Report Suspend Trans.Process"::Delete) then
                            POSTransaction.ZReportSuspendProcess(NoSuspPOSTransactionsVoided);
                end;
            end;

            POSTransactionEvents.OnBeforeTendDeclareLogOff(EndOfDay, IsHandled);
            if IsHandled then
                exit;

            if POSTransaction.GetPosState() = 'TENDOP' then
                POSTransaction.SetPOSState("LSC POS Transaction State"::SALES);
            EPosCtrl.PostCommand("LSC POS Command"::LOGOFF, '');

            POSTransactionEvents.OnAfterTendDeclareLogOff(EndOfDay);
        end;
    end;

    procedure CheckOfflineLogoffOnRunningReportPrinting()
    begin
        if PosSession.GetValue("LSC POS Tag"::TD_OFFLPANEL) <> '' then begin
            PosSession.SetValue("LSC POS Tag"::"SAF-CANCEL-SOD", 'LOGOFF');
            EPosCtrl.PostCommand("LSC POS Command"::LOGOFF, '');
            POSTransaction.Close(true);
        end;
    end;
}