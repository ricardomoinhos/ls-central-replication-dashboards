codeunit 50106 "AAA - Customization"
{
    SingleInstance = true;
    TableNo = "LSC POS Menu Line";

    trigger OnRun()
    begin
        GlobalRecPOSMenuLine := Rec;

        if Rec."Registration Mode" then begin
            Register(Rec);
            Exit;
        end;

        case Rec.Command of
            'MEMBERVOUCHER_LU':
                begin
                    if POSSession.MgrKey() then begin
                        MemberVoucherLookup();
                    end else begin
                        POSTransactionCU.ErrorBeep('Manager Login Required');
                        Error('');
                    end;
                end;

        end;

        GlobalRecPOSMenuLine.Processed := true;
        Rec := GlobalRecPOSMenuLine;
    end;

    /// <summary>
    /// Register.
    /// </summary>
    /// <param name="POSMenuLine">VAR Record "POS Menu Line".</param>
    procedure Register(var POSMenuLine: Record "LSC POS Menu Line")
    var
        Module: Code[20];
    begin
        Module := 'AAA - Customization';
        POSCommandRegistration.RegisterModule(Module, 'AAA - Customization', Codeunit::"AAA - Customization");
        POSCommandRegistration.RegisterExtCommand('MEMBERVOUCHER_LU', 'Member voucher listing', Codeunit::"AAA - Customization", LSCPOSCommandParameterType::" ", Module, false);
        POSMenuLine."Registration Mode" := false;

        InitRequest('CheckMemberTobaccoLicense', 'CheckMemberTobaccoLicense', 1);
    end;

    local procedure InitRequest(RequestID: Text; ServiceName: Text; InitServerClient: Option Publisher,Subscriber)
    var
        WebServiceAggregate: Record "Web Service Aggregate";
        "Object": Record AllObjWithCaption;
        WebRequest: Record "LSC Web Request";
        WSRequest: Record "LSC WS Request";
        WebServiceMgt: Codeunit "Web Service Management";
        RequestParser: Codeunit "LSC Request Parser";
        WebReplFunc: Codeunit "LSC Web Repl. Functions";
        WebClientType: Enum "Client Type";
        "Object Type": Option ,,,,,Codeunit,,,Page,Query;
    begin
        if InitServerClient = 0 then
            RemovePublisherExt(RequestID, ServiceName)
        else
            RemoveSubscriber(RequestID);

        Object.SetRange("Object Type", Object."Object Type"::Codeunit);
        Object.SetRange("Object Name", RequestID);
        if Object.IsEmpty then
            Object.SetRange("Object Name", RequestID);
        if not Object.FindFirst() then
            exit;
        if InitServerClient in [InitServerClient::Publisher] then begin
            if ServiceName = '' then
                WebServiceMgt.CreateTenantWebService("Object Type"::Codeunit, Object."Object ID", DelChr(RequestID, '=', ' '), true)
            else
                WebServiceMgt.CreateTenantWebService("Object Type"::Codeunit, Object."Object ID", ServiceName, true);

        end;
        if InitServerClient in [InitServerClient::Subscriber] then begin
            WebRequest.Init;
            WebRequest."Request Id" := RequestID;
            if InitServerClient = InitServerClient::Subscriber then
                WebRequest."Definition Url" := CreateRequestUrl(RequestID)
            else begin
                WebServiceAggregate.Init();
                WebServiceAggregate."Object Type" := WebServiceAggregate."Object Type"::Codeunit;
                WebServiceAggregate."Object ID" := Object."Object ID";
                WebRequest."Definition Url" := WebServiceMgt.GetWebServiceUrl(WebServiceAggregate, WebClientType::SOAP);
            end;
            WebRequest.Description := RequestID;
            WebRequest.Namespace := 'urn:microsoft-dynamics-schemas/codeunit/CheckMemberTobaccoLicense';
            WebRequest.Insert(true);
            if SOAPBasedRequest(WebRequest."Request Id") then
                RequestParser.RegisterRequest(WebRequest."Request Id", WebRequest."Definition Url")
            else begin
                WebRequest.Namespace := 'microsoft-dynamics-schemas';
                WebRequest."Definition Url" := WebRequest."Definition Url";
                WebRequest."Definition Url" := StrSubstNo(WebRequest."Definition Url", WebRequest."Request Id", 'GetRequestDef');
                WebRequest.Modify();
            end;
        end;

        WSRequest.Init;
        WSRequest."Request ID" := RequestID;
        WSRequest."Web Service V2.0" := true;
        WSRequest.Description := RequestID;
        WSRequest."Web Request is Active" := true;
        WSRequest."Request Type" := WSRequest."Request Type"::WebPOS;
        WSRequest.Insert(true);
    end;


    local procedure SOAPBasedRequest(RequestID: Text): Boolean
    var
        OData4Req: Dictionary of [Text, Boolean];
        SOAPReq: Boolean;
    begin
        SOAPReq := true;
        if OData4Req.ContainsKey(RequestID) then
            SOAPReq := false;
        exit(SOAPReq);
    end;

    local procedure CreateRequestUrl(RequestID: Text): Text
    var
        BaseNewUrl: Text;
        NewUrl: Text;
        PosTenant: Integer;
    begin
        NewUrl := '';
        BaseNewUrl := GetBaseNewUrl;
        PosTenant := StrPos(BaseNewUrl, '?Tenant=');
        if PosTenant > 0 then
            NewUrl := CopyStr(BaseNewUrl, 1, PosTenant - 1) + '/Codeunit/' + RequestID + CopyStr(BaseNewUrl, PosTenant)
        else
            NewUrl := BaseNewUrl + '/Codeunit/' + RequestID;
        exit(NewUrl);
    end;

    local procedure GetBaseNewUrl(): Text
    var
        OldUri: Text[1000];
    begin
        OldUri := GetBaseOldUrl;
        exit(ConvertToNewUrl(OldUri));
    end;

    local procedure GetBaseOldUrl(): Text
    var
        WebServiceSetup: Record "LSC Web Service Setup";
    begin
        WebServiceSetup.Get;
        exit(WebServiceSetup."Extended Web Service URI");
    end;

    local procedure ConvertToNewUrl(Url: Text): Text
    var
        NewUrl: Text[1000];
        PosCodeunit: Integer;
        PosTenant: Integer;
    begin
        NewUrl := '';
        PosCodeunit := StrPos(Url, '/Codeunit/');
        if PosCodeunit > 0 then
            NewUrl := CopyStr(Url, 1, PosCodeunit - 1);
        PosTenant := StrPos(Url, '?Tenant=');
        if PosTenant > 0 then
            NewUrl := NewUrl + CopyStr(Url, PosTenant);
        exit(NewUrl);
    end;

    local procedure RemovePublisherExt(RequestID: Text; ServiceName: Text)
    var
        TenantWebService: Record "Tenant Web Service";
        WebServiceAggregate: Record "Web Service Aggregate";
        WebRequest: Record "LSC Web Request";
        WSRequest: Record "LSC WS Request";
    begin
        if WSRequest.Get(RequestID) then
            WSRequest.Delete(true);
        if ServiceName <> '' then
            RequestID := ServiceName;

        if TenantWebService.Get(TenantWebService."Object Type"::Codeunit, RequestID) then
            TenantWebService.Delete(true);
    end;

    local procedure RemoveSubscriber(RequestID: Text)
    var
        WSRequest: Record "LSC WS Request";
        WebRequest: Record "LSC Web Request";
    begin
        if WebRequest.Get(RequestID) then
            WebRequest.Delete(true);
        if WSRequest.Get(RequestID) then
            WSRequest.Delete(true);
    end;

    procedure GetMemberVoucherBalance(Var POSTransaction: Record "LSC POS Transaction"): Text
    Var
        VoucherAmt: Decimal;
    Begin
        if POSTransaction."Account No. AAA" = '' THEN
            exit('0.00');
        if (POSTransaction."Member Voucher Balance AAA" <> 0) then
            exit(Format(POSTransaction."Member Voucher Balance AAA"));

        Clear(VoucherAmt);

        POSDataEntry.Reset();
        POSDataEntry.SetRange("Account No. AAA", POSTransaction."Account No. AAA");
        POSDataEntry.SetFilter("Reserverd By POS No.", '%1', '');
        POSDataEntry.SetAutoCalcFields("Voucher Remaining Amount");
        if POSDataEntry.FindSet() then
            repeat
                VoucherAmt := VoucherAmt + POSDataEntry."Voucher Remaining Amount";
            until POSDataEntry.Next() = 0;
        exit(Format(VoucherAmt));
    end;

    local PROCEDURE MemberVoucherLookup();
    VAR
        POSTransaction: Record "LSC POS Transaction";
        ResponseCode: Code[10];
        ErrorText: Text;
        LookupRec: Record "LSC POS Lookup";
        CurrlineTemp: Record "LSC POS Trans. Line";
        DataTable: Record "LSC POS Data Table";
        LookupRecRef: RecordRef;
        NewFormID: Code[10];
        Filter: Code[29];
        Command: Code[20];
        KeyValue: Code[50];
        Balance: Decimal;
        RealBalance: Decimal;
    BEGIN
        POSTransactionCU.GetPOSTransaction(POSTransaction);
        IF POSTransaction."Member Card No." = '' THEN BEGIN
            POSTransactionCU.PosMessage('Please select the Member.');
            EXIT;
        END;

        POSDataEntry.Reset();
        POSDataEntry.SetRange("Account No. AAA", POSTransaction."Account No. AAA");
        POSDataEntry.SetFilter("Reserverd By POS No.", '%1', '');
        NewFormID := 'DATAENTRY';

        LookupRecRef.GetTable(POSDataEntry);
        POSTransactionCU.LookUpEx(true, NewFormID, Filter, LookupRecRef);
    end;

    var
        POSDataEntry: Record "LSC POS Data Entry";
        GlobalRecPOSMenuLine: Record "LSC POS Menu Line";
        POSCommandRegistration: Codeunit "LSC POS Command Registration";
        POSTransactionCU: Codeunit "LSC POS Transaction";
        POSSession: Codeunit "LSC POS Session";
        LSCPOSCommandParameterType: Enum "LSC POS Command Parameter Type";

}