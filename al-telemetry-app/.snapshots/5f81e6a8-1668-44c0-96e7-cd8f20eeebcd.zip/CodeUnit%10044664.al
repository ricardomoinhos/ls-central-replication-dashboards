codeunit 10044664 "LSCNA POS Transaction Events"
{
    var
        CustomerOrderMgt: Codeunit "LSCNA Customer Order Mgt.";
        NA_ServiceLocator: Codeunit "LSCNA ServiceLocator";

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnBeforeCustomerOrderCreated, '', false, false)]
    local procedure OnBeforeCustomerOrderCreated(var REC: Record "LSC POS Transaction"; var Databuffer: Record "LSC Customer Order Header" temporary; var Datalinesbuffer: Record "LSC Customer Order Line" temporary; var DataDiscountLineBuffer: Record "LSC CO Discount Line" temporary; var IsHandled: Boolean);
    begin
        CustomerOrderMgt.ChangeTaxAreaBeforeCreateCustomerOrder(REC, Databuffer, Datalinesbuffer, DataDiscountLineBuffer, IsHandled);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnAfterMarkPressed, '', false, false)]
    local procedure OnAfterMarkPressed(POSTransaction: Record "LSC POS Transaction"; POSTransLine: Record "LSC POS Trans. Line");
    begin
        CustomerOrderMgt.RecalculateSalesTaxAfterMarkPressed(POSTransaction, POSTransLine);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnAfterCalcTotals, '', false, false)]
    local procedure OnAfterCalcTotals(var Rec: Record "LSC POS Transaction"; var Balance: Decimal; var RealBalance: Decimal);
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        CustomerOrderMgt.RecalculateSalesTax(Rec);
        POSTransactionMgt.UpdateAmountInDealLines(Rec);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnAfterInsertNewTransaction, '', false, false)]
    local procedure OnAfterInsertNewTransaction(var POSTransaction: Record "LSC POS Transaction"; var POSTransLine: Record "LSC POS Trans. Line"; var CurrInput: Text)
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.InitTaxOnNewTransactionFromStore(POSTransaction);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnProcessOtherInfoTrigger, '', false, false)]
    local procedure OnProcessOtherInfoTrigger(SubInfo: Record "LSC Information Subcode"; Info: Record "LSC Infocode"; var POSTr: Record "LSC POS Transaction"; POSTerminal: Record "LSC POS Terminal"; CurrInput: Text; var IsHandled: Boolean)
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.OnProcessOtherInfoTrigger(SubInfo, Info, POSTr, POSTerminal);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnBeforeGetContext, '', false, false)]
    local procedure OnBeforeGetContext(var POSTransaction: Record "LSC POS Transaction"; var POSTransLine: Record "LSC POS Trans. Line"; var CurrInput: Text)
    var
        POSTransactionMgt: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        POSTransactionMgt.CalcFieldsOnBeforeGetCotext(POSTransaction);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnAfterTenderKeyPressedEx, '', false, false)]
    local procedure "LSC POS Transaction Events_OnAfterTenderKeyPressedEx"(var POSTransaction: Record "LSC POS Transaction"; var POSTransLine: Record "LSC POS Trans. Line"; var CurrInput: Text; var TenderTypeCode: Code[10]; var TenderAmountText: Text; var IsHandled: Boolean)
    begin
        IsHandled := not GetEBTEFTUtility().CheckSufficientEBTAmount(POSTransaction, TenderTypeCode);
    end;

    internal procedure GetEBTEFTUtility(): Interface "LSCNA IEBTEFTUtility"
    begin
        exit(NA_ServiceLocator.EBTEFTUtility());
    end;
}
