codeunit 10036987 "LSC AutoFormatMgt Ext."
{

    var
        Globals: Codeunit "LSC POS Session";
        UIHelperTriggers: Codeunit "UI Helper Triggers";

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Auto Format", OnResolveAutoFormat, '', false, false)]
    local procedure AutoFormatTranslateOnAfterAutoFormatTranslate(AutoFormatType: Enum "Auto Format"; AutoFormatExpr: Text[80]; var Result: Text[80]; var Resolved: Boolean)
    var
        AutoFormatTranslationTemp: Text[80];
    begin
        AutoFormatTranslationTemp := AutoFormatTranslateExt(AutoFormatType, AutoFormatExpr);
        if AutoFormatTranslationTemp <> '' then begin
            Result := AutoFormatTranslationTemp;
            Resolved := true;
        end;
    end;

    local procedure AutoFormatTranslateExt(AutoFormatType: Enum "Auto Format"; AutoFormatExpr: Text[80]): Text[80]
    var
        Store: Record "LSC Store";
        PosFuncProfile: Record "LSC POS Func. Profile";
        UOM: Record "Unit of Measure";
        bFuncProfileFound: Boolean;
    begin
        case AutoFormatType of
            "Auto Format"::DefaultFormat:
                exit('');
            "Auto Format"::"LSC Pos Qty":  // -LSPos Qty
                if (AutoFormatExpr <> '') and UOM.Get(AutoFormatExpr) and (UOM."LSC Weight Unit Of Measure") then
                    exit('<Precision,3:3><Standard format,0>')
                else
                    exit('<Precision,0:3><Standard format,0>');
            "Auto Format"::"LSC Pos Amount": // -LSPos Amount
                begin
                    if PosFuncProfile.Get(Globals.GetValue("LSC POS Tag"::"LSFUNCPROFILE")) then
                        bFuncProfileFound := true
                    else
                        if (AutoFormatExpr <> '') and Store.Get(AutoFormatExpr) then begin
                            if PosFuncProfile.Get(Store."Functionality Profile") then
                                bFuncProfileFound := true;
                        end;

                    if bFuncProfileFound then
                        exit(StrSubstNo('<Precision,%1><Standard format,0>', Format(PosFuncProfile."Amount Decimal Places")))
                    else
                        exit('<Precision,2:2><Standard format,0>');
                end;
            "Auto Format"::"LSC Pos Price":// -LSPos Price
                begin
                    if PosFuncProfile.Get(Globals.GetValue("LSC POS Tag"::"LSFUNCPROFILE")) then
                        bFuncProfileFound := true
                    else
                        if (AutoFormatExpr <> '') and Store.Get(AutoFormatExpr) then begin
                            if PosFuncProfile.Get(Store."Functionality Profile") then
                                bFuncProfileFound := true;
                        end;

                    if bFuncProfileFound then
                        exit(StrSubstNo('<Precision,%1><Standard format,0>', Format(PosFuncProfile."Price Decimal Places")))
                    else
                        exit('<Precision,2:2><Standard format,0>');
                end;
        end;
    end;

    procedure DoAutoFormatTranslateExt(AutoFormatType: Enum "Auto Format"; AutoFormatExpr: Text[80]): Text[80]
    begin
        exit(DoAutoFormatTranslateExt(AutoFormatType.AsInteger(), AutoFormatExpr));
    end;

    procedure DoAutoFormatTranslateExt(AutoFormatType: Integer; AutoFormatExpr: Text[80]): Text[80]
    var
        AutoFormatTranslation: Text[80];
    begin
        AutoFormatTranslation := '';
        UIHelperTriggers.AutoFormatTranslate(AutoFormatType, AutoFormatExpr, AutoFormatTranslation);
        exit(AutoFormatTranslation);
    end;
}

