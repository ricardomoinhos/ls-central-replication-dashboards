codeunit 99001567 "LSCLog"
{
    SingleInstance = true;

    var
        _Open: Boolean;
        _LogFile: Text;
        _LogLevel: Integer;

    procedure LogFile(newValue: Text)
    begin
        if newValue <> _LogFile then begin
            _LogFile := newValue;
            _Open := false;
        end;
    end;

    procedure GetLogFile(): Text
    begin
        exit(_LogFile);
    end;

    procedure LogLevel(newValue: Integer)
    begin
        if newValue <> _LogLevel then begin
            _LogLevel := newValue;
            _Open := false;
        end;
    end;

    procedure GetLogLevel(): Integer
    begin
        exit(_LogLevel);
    end;

    procedure Error(message: Text)
    begin
        Error(message, false);
    end;

    procedure Error(message: Text; dualdisp: Boolean)
    begin
        if not Open() then
            exit;

        if dualdisp then
            OnLog(enum::"LSC POS Log Level"::Error.AsInteger(), 'DD: ' + message)
        else
            OnLog(enum::"LSC POS Log Level"::Error.AsInteger(), message);
    end;

    procedure LogEvent(var pPosEvent: Codeunit "LSC POS Event")
    begin
        LogEvent(pPosEvent, pPosEvent.Ticks = -999999999);
    end;

    procedure LogEvent(var pPosEvent: Codeunit "LSC POS Event"; dualdisp: Boolean)
    var
        jsontxt: Text;
    begin

        if not Open() then
            exit;

        pPosEvent.ToJSON(true).WriteTo(jsontxt);

        if dualDisp then
            OnLog(enum::"LSC POS Log Level"::None.AsInteger(), 'DD_POSEvent: ' + jsontxt)
        else
            OnLog(enum::"LSC POS Log Level"::None.AsInteger(), 'POSEvent: ' + jsontxt);
    end;

    procedure Trace(message: Text)
    begin
        Trace(message, false);
    end;

    procedure Trace(message: Text; dualdisp: Boolean)
    begin
        if not Open() then
            exit;

        if dualdisp then
            OnLog(enum::"LSC POS Log Level"::Trace.AsInteger(), 'DD: ' + message)
        else
            OnLog(enum::"LSC POS Log Level"::Trace.AsInteger(), message)
    end;

    procedure Debug(message: Text)
    begin
        Debug(message, false);
    end;

    procedure Debug(message: Text; dualdisp: Boolean)
    begin
        if not Open() then
            exit;

        if dualdisp then
            OnLog(enum::"LSC POS Log Level"::Debug.AsInteger(), 'DD: ' + message)
        else
            OnLog(enum::"LSC POS Log Level"::Debug.AsInteger(), message)
    end;

    procedure Warning(message: Text)
    begin
        Warning(message, false);
    end;

    procedure Warning(message: Text; dualdisp: Boolean)
    begin
        if not Open() then
            exit;

        if dualdisp then
            OnLog(enum::"LSC POS Log Level"::Warning.AsInteger(), 'DD: ' + message)
        else
            OnLog(enum::"LSC POS Log Level"::Warning.AsInteger(), message)
    end;

    procedure Information(message: Text; dualdisp: Boolean)
    begin
        if not Open() then
            exit;

        if dualdisp then
            OnLog(enum::"LSC POS Log Level"::None.AsInteger(), 'DD: ' + message)
        else
            OnLog(enum::"LSC POS Log Level"::None.AsInteger(), message)
    end;

    local procedure Open(): Boolean
    begin
        if _Open then
            exit(true);

        if _LogFile = '' then
            exit(false);

        OnOpen(_LogLevel, _LogFile, _Open);
        exit(_Open);
    end;

    procedure Close()
    begin
        OnClose();
        _Open := false;
    end;

    procedure IsAvailable(): Boolean
    var
        loggerAvailable: Boolean;
        loggerInfo: Text;
    begin
        OnLoggerAvailable(loggerAvailable, loggerInfo);
        exit(loggerAvailable);
    end;

    [IntegrationEvent(false, false)]
    local procedure OnLoggerAvailable(var pIsAvailable: Boolean; var pLoggerInfo: Text)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnOpen(pLogLevel: Integer; pLogFile: Text; var pSuccess: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnClose()
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnLog(pLogLevel: Integer; pMessage: Text)
    begin
    end;
}