codeunit 10000744 "LSC Self Service Subscribers"
{
    Access = Internal;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Controller", OnAutologoffPOSEvent, '', true, true)]
    local procedure VoidTransactionOnAutoLogoffPOSEvent(var PosEvent: Codeunit "LSC POS Event"; NewTransaction: Boolean; AllowAutoLogoffInSalesMode: Boolean; PanelControlCodeunit: integer; var SuppressEvent: Boolean)
    var
        SelfServiceFunctions: Codeunit "LSC Self Service Functions";
    begin
        SelfServiceFunctions.VoidTransactionOnAutoLogoffPOSEvent(PosEvent, NewTransaction, AllowAutoLogoffInSalesMode, PanelControlCodeunit, SuppressEvent);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Session", OnBeforeUpdateLanguageCode, '', false, false)]
    local procedure PosSessionOnBeforeUpdateLanguageCode(var LanguageCode: Code[10])
    var
        SelfServiceFunctions: Codeunit "LSC Self Service Functions";
    begin
        SelfServiceFunctions.PosSessionOnBeforeUpdateLanguageCode(LanguageCode);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Controller", OnBeforeProcessModalResult, '', false, false)]
    local procedure OnBeforeProcessModalResult(panelID: Text; resultOK: Boolean; payload: Text; var processed: Boolean)
    var
        SelfServiceFunctions: Codeunit "LSC Self Service Functions";
    begin
        SelfServiceFunctions.OnBeforeProcessModalResult(panelID, resultOK, payload, processed);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Controller", OnPOSCommand, '', false, false)]
    local procedure OnPOSCommand(var ActivePanel: Record "LSC POS Panel"; var PosMenuLine: Record "LSC POS Menu Line")
    var
        SelfServiceFunctions: Codeunit "LSC Self Service Functions";
    begin
        SelfServiceFunctions.OnPOSCommand(ActivePanel, PosMenuLine);
    end;
}

