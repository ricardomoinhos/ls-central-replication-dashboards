codeunit 99008939 "LSC POS Addin Wrapper"
{
    Access = Internal;

    procedure AddInReady(var metadata: JsonObject; var r: Record "Company") SendRequest: JsonArray
    var
        jTok: JsonToken;
    begin
        if r.Name = testClientLbl then  // RUNNING PAGE 99008870
            if not metadata.Get('Terminal', jTok) then
                metadata.Add('Terminal', testCliLbl);
        exit(AddInReady(metadata));
    end;

    procedure AddInReady(var metadata: JsonObject) SendRequest: JsonArray
    var
        token: JsonToken;
        jObj, jObj2, jObj3 : JsonObject;
        TermRec: Record "LSC POS Terminal";
        Posterminaltext: Text;
        Posstoretext: Text;
        Possuperbool: Boolean;
        tokenTxt: Text;
        LoggerTerminal: Text;
        NoTerminalSelectedErr: Label 'No terminal selected in Retail Users table or LS Central App';
        InvalidTerminalInParamMsg: Label 'Could not find terminal %1. Using terminal from Retail User setup instead. %2';
        SetupRetailUserQst: Label 'Would you like to setup a Retail User now?';
        PANELID: Label '###PANELID', Locked = true;
        MENUID: Label '###MENUID', Locked = true;
        BUTTONPADID: Label '###BTNPAD', Locked = true;
    begin
        if metadata.Get('CheckPageReady', token) then begin
            if PageReady then
                exit;
            PageReady := true;
            jObj.Add('Type', 'AlPageReady');
            GetSessionInfo(jObj3);
            GetBaseAppInfo(jObj3);
            CONTROLLIB.GetSystemAppInfo(jObj3);
            jObj2.Add('String', jObj3);
            jObj.Add('Content', jObj2);
            SendRequest.Add(jObj);
            exit;
        end;

        if metadata.Get('Slowdown', token) then
            SlowdownMs := token.AsValue.AsInteger; // SLOW ALL EVENTS DOWN (for debugging)

        POSSESSION.SetValue("LSC POS Tag"::TEST_MODE, '');
        if metadata.Get('TestMode', token) then
            POSSESSION.SetValue("LSC POS Tag"::TEST_MODE, '1');

        IsSimple := metadata.Get('___simple', token);
        if IsSimple then begin
            Clear(CONTROLLIB);

            if token.IsValue then
                tokenTxt := token.AsValue.AsText;

            if tokenTxt.EndsWith('PREVIEW') then begin
                CONTROLLIB.InitControl(tokenTxt);
                CONTROLLIB.SetInitialized(true);
                CONTROLLIB.SetLanguage(PosSession.GetLanguageCode());
                CONTROLLIB.CreatePanel(PANELID, 1, 1);
                CONTROLLIB.SetPanelRowHeight(PANELID, 1, 1, 100);
                CONTROLLIB.CreateMenu(MENUID, 1, 1, 0);
                CONTROLLIB.CreateButtonPad(BUTTONPADID, MENUID);
                CONTROLLIB.ShowPanel(PANELID);
                CONTROLLIB.ShowControl(PANELID, 1, 1, 1, 1, Enum::"LSC POS Control Type"::ButtonPad, BUTTONPADID);
                UpdatePosAddIn(SendRequest);
                exit;
            end;
            if tokenTxt = 'INPUTDIALOG' then begin
                CONTROLLIB.InitControl('', PosController);
                CONTROLLIB.SetPosCtrlActiveInteraceProfile(POSSESSION.InterfaceProfile.ID, POSSESSION.Store."Interface Profile");
                CONTROLLIB.SetPosCtrlActiveMenuProfile(POSSESSION.MenuProfile.ID, POSSESSION.Store."Menu Profile");
                CONTROLLIB.SetPosCtrlActiveStyle(POSSESSION.StyleProfile.ID, POSSESSION.Store."Style Profile");
                CONTROLLIB.SendPosCommandEvent('_FORMLOAD', '');
                UpdatePosAddIn(SendRequest);
                exit;
            end;

            exit(SimpleAddInReady(token.AsObject()))
        end;

        if metadata.Get('AlProfiler', token) then
            PosController.AlProfiler('');

        GlobalLanguage(POSSESSION.GetLanguageID);

        Posterminaltext := RetailUser."POS Terminal";
        Posstoretext := RetailUser."Store No.";
        Possuperbool := RetailUser."POS Super User";

        if metadata.Get('Terminal', token) then begin
            tokenTxt := token.AsValue.AsText();
            if tokenTxt = testCliLbl then begin
                Posterminaltext := testCliLbl;
                Posstoretext := '';
                Possuperbool := true;
            end else begin
                TermRec.SetRange("No.", tokenTxt);
                if not TermRec.IsEmpty() then begin
                    Posterminaltext := tokenTxt;
                    Posstoretext := '';
                end else
                    Message(InvalidTerminalInParamMsg, tokenTxt, Posterminaltext);
            end;
        end;

        if Posterminaltext = testCliLbl then
            LoggerTerminal := RetailUser."POS Terminal"
        else
            LoggerTerminal := Posterminaltext;
        if metadata.Get('DebugLog', token) then
            ForceEnableLogger(LoggerTerminal);
        InitLogger(LoggerTerminal);

        PosController.InitDualDisplayControl2(DDCONTROLLIB);
        CONTROLLIB.InitControl('', PosController);
        CONTROLLIB.SetLogLevel(Logger.ActiveLogLevel());

        if Posterminaltext = '' then
            if RetailUser.WritePermission then
                if Confirm(StrSubstNo('%1 \ %2', NoTerminalSelectedErr, SetupRetailUserQst)) then begin
                    PAGE.RunModal(PAGE::"LSC Retail Users");
                    if RetailUser.Get(UserId) then;
                    Posterminaltext := RetailUser."POS Terminal";
                    Posstoretext := RetailUser."Store No.";
                    Possuperbool := RetailUser."POS Super User";
                end;

        if Posterminaltext = '' then begin
            PosController.InitControl(CONTROLLIB, Posstoretext, Posterminaltext, Possuperbool);
            CONTROLLIB.CloseWindow(); // could also trigger CurrPage.Close from Addin
            UpdatePosAddIn(SendRequest);
            exit;
        end;

        if Posterminaltext <> testCliLbl then
            StartDualDisplay(Posterminaltext, SendRequest);

        PosController.InitControl(CONTROLLIB, Posstoretext, Posterminaltext, Possuperbool);
        PosCtrlInterface.SetIdleTimerInterval(15);
        UpdatePosAddIn(SendRequest);
    end;

    procedure GetSessionInfo(j: JsonObject)
    var
        ActiveSession: Record "Active Session";
        PosTerminalsInUse: Record "LSC POS Terminal In Use";
        InstalledExtensions: Record "NAV App Installed App";
        ImageUtils: Codeunit "LSC POS Image Utils";
        EnvironmentInformation: Codeunit "Environment Information";
        tmpTxt: Text;
        tmpInt, tmpInt2 : Integer;
    begin
        j.Add('ISO', Format(CurrentDateTime, 0, 9)); // Server DateTime (could have offset)
        j.Add('UID', UserId);
        j.Add('SID', SessionId);
        j.Add('CN', CompanyName);
        j.Add('TID', TenantId);
        j.Add('SNO', SerialNumber);
        j.Add('SIID', ServiceInstanceId);
        j.Add('RVL', Format(LastUsedRowVersion));
        j.Add('RVM', Format(MinimumActiveRowVersion));

        j.Add('ImgGuid', ImageUtils.Add1PxTenantImage());

        tmpTxt := ApplicationIdentifier;
        if tmpTxt <> 'NAV' then
            j.Add('AID', ApplicationIdentifier);
        tmpTxt := EnvironmentInformation.GetEnvironmentName();
        if tmpTxt <> 'Production' then
            j.Add('ENV', EnvironmentInformation.GetEnvironmentName);
        if EnvironmentInformation.IsSaaS then
            j.Add('SAAS', 1);
        if EnvironmentInformation.IsSaaSInfrastructure then
            j.Add('SINF', 1);
        if EnvironmentInformation.IsProduction then
            j.Add('PROD', 1);

        if not TryGetExtraTenantInfo(j) then
            j.Add('TERR', 1);

        if not IsNullGuid(UserSecurityId) then
            if Format(UserSecurityId, 0, 4) <> '00000000-0000-0000-0000-000000000001' then
                j.Add('USID', Format(UserSecurityId, 0, 4));

        // Get info about the active session:
        ActiveSession.ReadIsolation := IsolationLevel::ReadCommitted;
        if ActiveSession.Get(ServiceInstanceId, SessionId) then begin
            j.Add('LIDT', Format(ActiveSession."Login Datetime", 0, 9));
            if not IsNullGuid(ActiveSession."Session Unique ID") then
                j.Add('SUID', Format(ActiveSession."Session Unique ID", 0, 4));
            if ActiveSession."Client Type" <> ActiveSession."Client Type"::"Web Client" then
                j.Add('CT', ActiveSession."Client Type");
            if ActiveSession."Database Name" <> '' then
                j.Add('DBN', ActiveSession."Database Name");
            if ActiveSession."Server Instance Name" <> '' then
                j.Add('SIN', ActiveSession."Server Instance Name");
            if ActiveSession."Client Computer Name" <> '' then
                j.Add('CCN', ActiveSession."Client Computer Name");
            if ActiveSession."Server Computer Name" <> '' then
                if ActiveSession."Server Computer Name" <> ActiveSession."Client Computer Name" then
                    j.Add('SCN', ActiveSession."Server Computer Name");

            // Get info about other sessions in BC:
            tmpInt := ActiveSession.Count;
            if tmpInt > 1 then begin
                j.Add('ASC', tmpInt);
                ActiveSession.SetRange("Client Type", ActiveSession."Client Type"::"Web Client");
                tmpInt2 := ActiveSession.Count;
                if tmpInt <> tmpInt2 then
                    j.Add('ASCW', tmpInt2);
            end;
        end;

        // Get info about other POSes in use:
        PosTerminalsInUse.ReadIsolation := IsolationLevel::ReadCommitted;
        tmpInt := PosTerminalsInUse.Count;
        if tmpInt > 0 then
            j.Add('PTU', tmpInt);

        // Get info about Installed Extensions:
        InstalledExtensions.ReadIsolation := IsolationLevel::ReadCommitted;
        tmpInt := InstalledExtensions.Count;
        if tmpInt > 0 then
            j.Add('EXC', tmpInt);
        InstalledExtensions.SetRange(Publisher, 'Microsoft');
        tmpInt := InstalledExtensions.Count;
        if tmpInt > 0 then
            j.Add('EXMS', tmpInt);
        InstalledExtensions.SetRange(Publisher, 'LS Retail');
        tmpInt := InstalledExtensions.Count;
        if tmpInt > 0 then
            j.Add('EXLS', tmpInt);
    end;

    procedure GetBaseAppInfo(j: JsonObject)
    var
        mi: ModuleInfo;
    begin
        if not NavApp.GetCurrentModuleInfo(mi) then
            exit;
        j.Add('B_ID', Format(mi.Id, 0, 4));
        j.Add('B_PkgID', Format(mi.PackageId, 0, 4));
        j.Add('B_AppVersion', Format(mi.AppVersion));
        if mi.DataVersion <> mi.AppVersion then
            j.Add('B_DataVersion', Format(mi.DataVersion));
    end;

    [TryFunction]
    local procedure TryGetExtraTenantInfo(j: JsonObject)
    var
        EnvironmentInformation: Codeunit "Environment Information";
        TenantInformation: Codeunit "Tenant Information";
        ADTenantInformation: Codeunit "Azure AD Tenant";
        tmpTxt: Text;
    begin
        tmpTxt := TenantInformation.GetTenantId;
        if tmpTxt <> '' then
            if tmpTxt <> TenantId then
                j.Add('TII', tmpTxt);
        tmpTxt := TenantInformation.GetTenantDisplayName;
        if tmpTxt <> '' then
            if tmpTxt <> TenantId then
                j.Add('TIN', tmpTxt);
        tmpTxt := ADTenantInformation.GetAadTenantId;
        if tmpTxt <> '' then begin
            if tmpTxt <> TenantId then
                j.Add('ATI', tmpTxt);
            if EnvironmentInformation.IsSaaS then begin
                tmpTxt := ADTenantInformation.GetAadTenantDomainName; // Throws Error if IsNull
                if tmpTxt <> '' then
                    j.Add('ATN', tmpTxt);
            end;
        end;
    end;

    procedure SetSimpleController(var pSimpleController: Codeunit "LSC Simple EPOS Controller")
    begin
        SimplePosController := pSimpleController;
    end;

    procedure SimpleAddInReady(simpleSettings: JsonObject) SendRequest: JsonArray
    var
        jt: JsonToken;
        StyleProfileID: Text;
        InterfaceProfileID: Text;
        MenuProfileID: Text;
        PanelID: Text;
        IdleTimeout: Integer;
        EventCodeunit: Integer;
        PageID: Text;
    begin
        simpleSettings.Get('PageID', jt);
        PageID := jt.AsValue().AsText();
        simpleSettings.Get('StyleProfileID', jt);
        StyleProfileID := jt.AsValue.AsText;
        simpleSettings.Get('InterfaceProfileID', jt);
        InterfaceProfileID := jt.AsValue.AsText;
        simpleSettings.Get('MenuProfileID', jt);
        MenuProfileID := jt.AsValue.AsText;
        simpleSettings.Get('PanelID', jt);
        PanelID := jt.AsValue.AsText;
        simpleSettings.Get('IdleTimerInterval', jt);
        IdleTimeout := jt.AsValue.AsInteger();
        simpleSettings.Get('EventCodeunit', jt);
        EventCodeunit := jt.AsValue.AsInteger();

        CONTROLLIB.InitControl(PageID, SimplePosController);
        SimplePosController.InitControl(CONTROLLIB, StyleProfileID, InterfaceProfileID, MenuProfileID, EventCodeunit, PanelID);
        PosCtrlInterface.SetIdleTimerInterval(IdleTimeout);
        CONTROLLIB.SendPosCommandEvent('_FORMLOAD', '');
        UpdatePosAddIn(SendRequest);
    end;

    procedure PosEvent(evtObj: JsonObject) SendRequest: JsonArray
    var
        processed: Boolean;
        evnt: Codeunit "LSC POS Event";
        shouldUpdateAddin: Boolean;
    begin
        Timer := CurrentDateTime; // First line to calculate Ping from client

        if SlowdownMs > 0 then
            Sleep(SlowdownMs);

        evnt.FromJSON(evtObj);

        if IsSimple then begin
            if PosCtrlInterface.PreProcessEvent(evnt) then
                processed := true;
            if not processed then begin
                ProcessEvent(evnt);
                shouldUpdateAddin := true;
            end;
            if evnt.EventType = "LSC POS Event Type"::BUTTONPRESS then
                if PosCtrlInterface.PostProcessEvent(evnt) then
                    shouldUpdateAddin := true;
            UpdatePosAddIn(SendRequest);
            exit;
        end;

        PosCtrlInterface.SetClientTypeEnum("LSC POS Client Type"::Pos);

        if evnt.Ticks = -999999999 then begin
            if not CONTROLLIB.IsDualDisplayMirrored() then
                PosCtrlInterface.SetClientTypeEnum("LSC POS Client Type"::DualDisplay);
        end;

        if LogDuration then begin
            SqlRowsRead := SessionInformation.SqlRowsRead;
            SqlStatements := SessionInformation.SqlStatementsExecuted;
        end;

        if GetLastErrorText <> '' then begin //ERROR from last call
            Logger.LogError(GetLastErrorText, GetLastErrorCallStack);
            ClearLastError();
        end;

        if PosCtrlInterface.PreProcessEvent(evnt) then begin
            processed := true;
            shouldUpdateAddin := true;
        end;

        if not processed then begin
            ProcessEvent(evnt);
            shouldUpdateAddin := true;
        end;

        if PosCtrlInterface.PostProcessEvent(evnt) then
            shouldUpdateAddin := true;

        if shouldUpdateAddin then
            UpdatePosAddIn(SendRequest);

        TimerEnd := CurrentDateTime;
        if LogDuration then
            Logger.LogPerformance(evnt.ActivePanel, Format(evnt.EventType), evnt.StrData, TimerEnd - Timer, SessionInformation.SqlRowsRead - SqlRowsRead, SessionInformation.SqlStatementsExecuted - SqlStatements);
        if GetLastErrorText <> '' then
            Logger.LogError(GetLastErrorText, GetLastErrorCallStack);
        Logger.FlushLog();
        ClearLastError();

        HandleLoggerCommand(evnt);

        TimerEnd := CurrentDateTime; // Don't include time it takes to FlushLog
        HandlePing(evnt, SendRequest);
    end;

    local procedure HandlePing(var evnt: Codeunit "LSC POS Event"; var SendRequest: JsonArray)
    var
        cmd, TimerStartISO, TimerEndISO, ClientTimerStartISO : Text;
        ClientTimerStart: DateTime;
        c2sDiff, s2sDiff : Integer; // can't do s2c (client needs to calc that, using PING2)
    begin
        cmd := evnt.StrData;
        if not cmd.StartsWith(Format("LSC POS Command"::PING)) then
            exit;
        ClientTimerStartISO := evnt.StrData2;
        if ClientTimerStartISO = '' then
            exit;
        TimerStartISO := Format(Timer, 0, 9);
        TimerEndISO := Format(TimerEnd, 0, 9);
        if not Evaluate(ClientTimerStart, ClientTimerStartISO, 9) then
            exit;
        // Also test w. WAIT ?
        case cmd of
            Format("LSC POS Command"::PING):
                Message(
                    'PING: \[%1] (Client->Server)\[%2] (Server Start)\[%3] (Server End)\Diffs: ([%4], [%5]) ms',
                    ClientTimerStartISO,
                    TimerStartISO,
                    TimerEndISO,
                    c2sDiff,
                    s2sDiff
                );
            Format("LSC POS Command"::PING2):
                begin
                    // PosCtrlInterface.SetValue('_ping_js_start', ClientTimerStartISO); // can be done in client
                    PosCtrlInterface.SetValue('_ping_al_start', TimerStartISO);
                    PosCtrlInterface.SetValue('_ping_al_end', TimerEndISO);
                    UpdatePosAddIn(SendRequest); // Should only update context
                end;
        end;
    end;

    local procedure HandleLoggerCommand(var evnt: Codeunit "LSC POS Event")
    var
        LogSetup: Record "LSC POS Debug Setup";
        LogSetupLine: Record "LSC POS Debug Setup Line";
        Log: Record "LSC POS Debug Log";
        TempBlob: Codeunit "Temp Blob";
        Mode: Enum "LSC POS StartStopDownload";
        inStr: InStream;
        outStr: OutStream;
        foundSetup, foundSetupLine, enabledSetup, enabledSetupLine, downloaded : Boolean;
        fileName, terminalNo : Text;
    begin
        if evnt.StrData <> Format("LSC POS Command"::DEBUGLOG) then
            exit;
        if not PosController.GetStartStopModeFromParameter(evnt.StrData2, Mode) then
            exit;

        terminalNo := POSSESSION.TerminalNo;
        ForceEnableLogger(terminalNo, not (Mode in [Mode::Default, Mode::Start]), LogSetup, LogSetupLine, foundSetup, foundSetupLine, enabledSetup, enabledSetupLine);

        // Stop + Download:
        if foundSetup and foundSetupLine and enabledSetup and enabledSetupLine then begin
            Log.Reset;
            Log.SetRange("Terminal No.", terminalNo);
            if not Log.IsEmpty then begin
                if Mode in [Mode::Default, Mode::Download, Mode::StopAndDownload] then begin
                    TempBlob.CreateOutStream(outStr, TextEncoding::Windows);
                    Log.WriteToStream(outStr, true);
                    fileName := StrSubstNo('LSC_POS_%1_%2.poslog.txt', terminalNo, PosController.GetTimestampStr);
                    TempBlob.CreateInStream(inStr);
                    downloaded := DownloadFromStream(inStr, 'POS Debug Log', '', '*.txt', filename);
                end;
                // Cleanup
                if Mode in [Mode::Default, Mode::Stop, Mode::StopAndDownload] then begin
                    LogSetupLine."Log Level" := LogSetupLine."Log Level"::"None";
                    LogSetupLine.Modify();
                end;
                if downloaded then
                    Log.DeleteAll(); // PurgeLog if already downloaded
            end else
                if GuiAllowed then
                    Message('No POS Debug Log Lines found for Terminal [%1]', terminalNo);
        end;

        // Init/Reset:
        InitLogger(terminalNo);
    end;

    local procedure ForceEnableLogger(terminalNo: Code[10])
    var
        LogSetup: Record "LSC POS Debug Setup";
        LogSetupLine: Record "LSC POS Debug Setup Line";
        foundSetup, foundSetupLine, enabledSetup, enabledSetupLine : Boolean;
    begin
        ForceEnableLogger(terminalNo, false, LogSetup, LogSetupLine, foundSetup, foundSetupLine, enabledSetup, enabledSetupLine);
    end;

    local procedure ForceEnableLogger(terminalNo: Code[10]; onlyGetStatus: Boolean; var LogSetup: Record "LSC POS Debug Setup"; var LogSetupLine: Record "LSC POS Debug Setup Line"; var foundSetup: boolean; var foundSetupLine: boolean; var enabledSetup: boolean; var enabledSetupLine: boolean)
    begin
        // General Setup:
        foundSetup := LogSetup.FindFirst;
        if not onlyGetStatus then begin
            if not foundSetup then
                LogSetup.Init;
        end;
        enabledSetup := LogSetup."Debug Log Enabled";
        if not onlyGetStatus then begin
            LogSetup."Debug Log Enabled" := true; // enable logging in general
            if not foundSetup then
                LogSetup.Insert
            else
                LogSetup.Modify;
        end;

        // Terminal:
        foundSetupLine := LogSetupLine.Get(LogSetupLine."Log Type"::Terminal, terminalNo);
        enabledSetupLine := LogSetupLine."Log Level" <> LogSetupLine."Log Level"::"None";
        if not onlyGetStatus then begin
            if not foundSetupLine then begin
                LogSetupLine.Init;
                LogSetupLine."Log Type" := LogSetupLine."Log Type"::Terminal;
                LogSetupLine."Store/Terminal" := terminalNo;
            end;
            LogSetupLine."Log Level" := LogSetupLine."Log Level"::Trace; // enable logging for terminal
            LogSetupLine."Log Events" := true;
            LogSetupLine."Log Dual Display" := true;
            LogSetupLine."Log Performance" := LogSetupLine."Log Performance"::"All Data";
            if not foundSetupLine then
                LogSetupLine.Insert
            else
                LogSetupLine.Modify;
        end;
    end;

    local procedure InitLogger(pLoggerTerminal: Text)
    begin
        Logger.Init;
        if pLoggerTerminal = testCliLbl then
            Logger.SetTerminal(RetailUser."POS Terminal")
        else
            Logger.SetTerminal(pLoggerTerminal);
        Logger.LogStartInfo();
        LogDuration := Logger.LogDuration;
        LogDataSize := Logger.LogDataSize;
        LogData := Logger.LogData;
        CONTROLLIB.SetLogLevel(Logger.ActiveLogLevel());
    end;

    procedure OnClosePage()
    begin
        if POSSESSION.GetOriginalLanguageID > 0 then
            GlobalLanguage(POSSESSION.GetOriginalLanguageID);
        Logger.Close();
    end;

    procedure OnInit()
    begin
        SelectLatestVersion;
        if RetailUser.Get(UserId) then;
        Clear(CONTROLLIB);
        Clear(DDCONTROLLIB);
        SelectLatestVersion();
    end;

    procedure GetControlLib(var c: Codeunit "LSC POS Control Library")
    begin
        c := CONTROLLIB;
    end;

    procedure StartDualDisplay(terminal: Text; var SendRequest: JsonArray)
    var
        TermRec: Record "LSC POS Terminal";
        DualConfig: JsonObject;
    begin
        if not TermRec.Get(terminal) then
            exit;
        if not TermRec."Dual Disp. Enabled" then
            exit;
        DDCONTROLLIB.InitControl('DualDisp', PosController);
        DualConfig.Add('Terminal', TermRec."No.");
        DualConfig.Add('IsDualDisplay', TermRec."Dual Disp. Enabled");
        DualConfig.Add('DisplayNumber', TermRec."Dual Disp. Screen");
        DualDisplayRequest(SendRequest, "LSC POS String Request Type"::" ", DualConfig);
    end;

    local procedure DualDisplayRequest(var SendRequest: JsonArray; k: Enum "LSC POS String Request Type"; inJson: JsonObject)
    begin
        CreateRequest('', SendRequest, Format(k).Trim(), inJson, 'DualDisplayRequest');
    end;

    local procedure StringRequest(msg: Text; var SendRequest: JsonArray; k: Enum "LSC POS String Request Type"; inJson: JsonObject)
    begin
        CreateRequest(msg, SendRequest, Format(k).Trim(), inJson, 'StringRequest');
    end;

    local procedure CreateRequest(msg: Text; var SendRequest: JsonArray; k: Text; inJson: JsonObject; t: Text)
    var
        finalJson: JsonObject;
        contentJson: JsonObject;
        wrapJson: JsonObject;
    begin
        if inJson.Keys.Count = 0 then
            exit;
        LogRequest(msg, inJson);
        if k <> '' then begin
            wrapJson.Add(k, inJson);
            contentJson.Add('String', wrapJson);
        end else
            contentJson.Add('String', inJson);
        finalJson.Add('Type', t);
        finalJson.Add('Content', contentJson);
        SendRequest.Add(finalJson);
    end;

    procedure UpdatePosAddIn(var SendRequest: JsonArray)
    var
        t: Text;
        j: JsonObject;
        RequestType: Enum "LSC POS String Request Type";
    begin
        PosController.UpdatePosContext(); // should only happen in the end of OnAddinReady and OnPosEvent
        CONTROLLIB.BeforeUpdatePosAddin();

        if DDCONTROLLIB.GetInitialized() then begin
            DDCONTROLLIB.BeforeUpdatePosAddin();
            StringRequest('-->DDCONTEXT: %1 B', SendRequest, RequestType::Context, DDCONTROLLIB.GetModifiedContext());
            DualDisplayRequest(SendRequest, RequestType::DataSets, DDCONTROLLIB.GetPendingDataSets());
            DDCONTROLLIB.ClearPendingDataSets();
            j.ReadFrom(DDCONTROLLIB.GetModifiedControlsJSON());
            DualDisplayRequest(SendRequest, RequestType::" ", j);
            Clear(j);
            AddImagesToJsonObject(j, DDCONTROLLIB);
            StringRequest('-->DDIMAGES: %1 B', SendRequest, RequestType::" ", j);
        end;

        StringRequest('-->CONTEXT: %1 B', SendRequest, RequestType::Context, CONTROLLIB.GetModifiedContext());
        CONTROLLIB.ClearModifiedContext(); // UpdateContext triggers AddWebJS which causes recursion

        StringRequest('-->DATASETS: %1 B', SendRequest, RequestType::DataSets, CONTROLLIB.GetPendingDataSets());
        CONTROLLIB.ClearPendingDataSets();

        t := CONTROLLIB.GetModifiedControlsJSON();
        if t <> '' then begin
            j.ReadFrom(t);
            AddImagesToJsonObject(j, CONTROLLIB); // GetModifiedControlsJSON causes side-effects (GetControl->GetImg)
            StringRequest('-->CONTROLS: %1 B', SendRequest, RequestType::" ", j);
        end else begin
            AddImagesToJsonObject(j, CONTROLLIB); // No controls available, only send image properties
            StringRequest('-->IMAGES: %1 B', SendRequest, RequestType::" ", j);
        end;

        foreach t in CONTROLLIB.GetPendingRequests do begin
            LogRequest('-->REQUESTS: %1 B', t);
            j.ReadFrom('{ "Type" : "JsonRequest", "Content" : ' + t + ' }');
            SendRequest.Add(j);
        end;
        CONTROLLIB.ClearPendingRequests();
    end;

    local procedure AddImagesToJsonObject(j: JsonObject; CL: Codeunit "LSC POS Control Library")
    var
        PosImgUtils: Codeunit "LSC POS Image Utils";
    begin
        AddToJsonIfNonEmpty(j, Format("LSC POS String Request Type"::TemplateImages), PosImgUtils.HandleWebTemplateImages(CL)); // Should happen before Images, only for explicit Web Template ImageIDs
        AddToJsonIfNonEmpty(j, Format("LSC POS String Request Type"::Images), CL.GetPendingImages());
        CL.ClearPendingImages();
        AddToJsonIfNonEmpty(j, Format("LSC POS String Request Type"::Playlists), CL.GetPendingPlaylists());
        CL.ClearPendingPlaylists();
    end;

    local procedure AddToJsonIfNonEmpty(toJson: JsonObject; k: Text; fromJson: JsonObject)
    begin
        if fromJson.Keys.Count <= 0 then
            exit;
        toJson.Add(k, fromJson);
    end;

    local procedure LogRequest(msg: Text; var j: JsonObject)
    var
        t: Text;
    begin
        if msg = '' then
            exit;
        if not LogDataSize then
            exit;
        j.WriteTo(t);
        LogRequest(msg, t);
    end;

    local procedure LogRequest(msg: Text; var t: Text)
    begin
        if not LogDataSize then
            exit;
        Logger.LogInfo(StrSubstNo(msg, StrLen(t)));
        if LogData then
            Logger.LogInfo(t);
    end;

    procedure ProcessEvent(var pPosEvent: Codeunit "LSC POS Event"): Boolean
    var
        shouldClose: Boolean;
    begin
        if IsSimple then
            shouldClose := SimplePosController.ProcessEvent(pPosEvent)
        else
            shouldClose := PosController.ProcessEvent(pPosEvent);

        LastPOSEvent.Pop();
        if shouldClose then
            exit(ClosePos(false));
    end;

    procedure ClosePos(fromQueryClosePage: Boolean): Boolean
    var
        CloseMsg: Label 'Do you want to close the POS?';
        shouldSkipClosing, shouldSkipConfirm : Boolean;
    begin
        if PosCtrlInterface.ActivePanel <> Format("LSC POS Panel Id"::"#OFFLINE") then
            if PosCtrlInterface.ActivePanel <> '' then
                exit(false);

        PosController.OnBeforeClosePos(shouldSkipClosing, shouldSkipConfirm);

        if shouldSkipClosing then
            exit(false);

        if PosController.Run() then;

        GlobalLanguage(POSSESSION.GetLanguageID);

        if not shouldSkipConfirm then
            if not Confirm(CloseMsg) then
                exit(false);

        PosController.CleanUp();

        if not fromQueryClosePage then
            CONTROLLIB.CloseWindow();
    end;

    procedure Handle(jArr: JsonArray; c: ControlAddIn "LSC_POS")
    var
        jTok: JsonToken;
    begin
        foreach jTok in jArr do
            c.SendRequest(jTok.AsObject);
    end;

    procedure HandleWrapper(jArr: JsonArray; c: ControlAddIn "LSC_WrapperAddin")
    var
        jTok: JsonToken;
    begin
        foreach jTok in jArr do
            c.SendRequest(jTok.AsObject);
    end;

    procedure IsPageReady(): Boolean
    begin
        exit(PageReady);
    end;

    var
        POSSESSION: Codeunit "LSC POS Session";
        LastPOSEvent: Codeunit "LSC POS Control Event";
        PosController: Codeunit "LSC POS Controller";
        SimplePosController: Codeunit "LSC Simple EPOS Controller";
        RetailUser: Record "LSC Retail User";
        PosCtrlInterface: Codeunit "LSC POS Control Interface";
        CONTROLLIB: Codeunit "LSC POS Control Library";
        DDCONTROLLIB: Codeunit "LSC POS Control Library"; //Dual Display
        PageReady: Boolean;
        Logger: Codeunit "LSC Debug Log";
        Timer, TimerEnd : DateTime;
        SlowdownMs: Integer;
        SqlRowsRead: BigInteger;
        SqlStatements: BigInteger;
        LogDuration: Boolean;
        LogDataSize: Boolean;
        LogData: Boolean;
        IsSimple: Boolean;
        testClientLbl: Label '##TEST_CLIENT##', Locked = true;
        testCliLbl: Label '#TEST_CLI#', Locked = true;

}
