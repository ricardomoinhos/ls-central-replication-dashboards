codeunit 10036985 "LSC ApplicationMgt Ext."
{

    var
        SelectionFilterMgt: Codeunit SelectionFilterManagement;

    procedure GetSelectionFilterForPurchaseHeader(var PurchaseHeader: Record "Purchase Header")
    var
        RecRef: RecordRef;
    begin
        RecRef.GetTable(PurchaseHeader);
        SelectionFilterMgt.GetSelectionFilter(RecRef, PurchaseHeader.FieldNo("Document Type"));
    end;

    procedure GetSelectionFilterForPurchaseInvoiceHeader(var PurchaseInvoiceHeader: Record "Purch. Inv. Header")
    var
        RecRef: RecordRef;
    begin
        RecRef.GetTable(PurchaseInvoiceHeader);
        SelectionFilterMgt.GetSelectionFilter(RecRef, PurchaseInvoiceHeader.FieldNo("No."));
    end;

    procedure GetSelectionFilterForItemDistribution(var ItemDistr: Record "LSC Item Distribution"): Text
    var
        RecRef: RecordRef;
    begin
        RecRef.GetTable(ItemDistr);
        exit(SelectionFilterMgt.GetSelectionFilter(RecRef, ItemDistr.FieldNo("Item No.")));
    end;

    procedure GetSelectionFilterForProductGroup(var ProductGroup: Record "LSC Retail Product Group"): Text
    var
        RecRef: RecordRef;
    begin
        RecRef.GetTable(ProductGroup);
        exit(SelectionFilterMgt.GetSelectionFilter(RecRef, ProductGroup.FieldNo(Code)));
    end;

    procedure LookupUserFullName(UserName: Code[50]; var FullName: Text)
    var
        UserRec: Record User;
    begin
        UserRec.Reset;
        UserRec.SetRange("User Name", UserName);
        if UserRec.FindFirst then
            FullName := UserRec."Full Name";
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Company Triggers", OnCompanyOpenCompleted, '', false, false)]
    local procedure OnOpenCompany()
    begin
        RegisterLSTools;
    end;

    [TryFunction]
    local procedure RegisterLSTools()
    begin
        //RegisterLSTools.. Dll's removed
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::ReportManagement, OnAfterSubstituteReport, '', false, false)]
    local procedure OnAfterSubstituteReport(ReportId: Integer; var NewReportId: Integer)
    begin
        case ReportId of
            Report::"Calculate Plan - Req. Wksh.":
                NewReportId := Report::"LSC Rtl Calc. Plan Req. Wksh.";
        end;
    end;

#pragma warning disable AL0432
    [EventSubscriber(ObjectType::Report, Report::"Implement Price Change", OnAfterCopyToSalesPrice, '', false, false)]
    local procedure OnAfterCopyToSalesPrice(var SalesPrice: Record "Sales Price"; SalesPriceWorksheet: Record "Sales Price Worksheet")
    begin
        SalesPrice."LSC Unit Price Including VAT" := SalesPriceWorksheet."LSC New Unit Price Incl. VAT";
#pragma warning restore AL0432
    end;
}

