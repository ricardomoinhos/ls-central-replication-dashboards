codeunit 10012718 "LSC POS Controller" implements "LSC IEPOSController", "LSC ILogin", "LSC IDeviceController"
{
    trigger OnRun()
    begin
        LogoffPressed(POSCtrl.ActivePanel);
    end;

    var
        MenuHeader: Record "LSC POS Menu Header";
        ActivePanel: Record "LSC POS Panel";
        ButtonPropertiesLine: Record "LSC POS Menu Line";
        PanelControlClipboardLine: Record "LSC POS Panel Control Line";
        MenuLineClipBoard: Record "LSC POS Menu Line";
        CONTROLLIB: Codeunit "LSC POS Control Library"; // CtrlLib instance per POS/SimplePOS, updated on AddinReady and every ProcessEvent
        DDCONTROLLIB: Codeunit "LSC POS Control Library";
        POSCtrl: Codeunit "LSC POS Control Interface";
        POSView: Codeunit "LSC POS View";
        POSLines: Codeunit "LSC POS Trans. Lines";
        POSSession: Codeunit "LSC POS Session";
        POSFunctions: Codeunit "LSC POS Functions";
        POSEvent: Codeunit "LSC POS Control Event";
        OposUtil: Codeunit "LSC POS OPOS Utility";
        SearchFunc: Codeunit "LSC POS Search Functions";
        POSTransactionCu: Codeunit "LSC POS Transaction Impl";
        LSCLog: Codeunit "LSC Debug Log";
        ServiceLocator: Codeunit "LSC Service Locator";
        CurrInput: Text;
        ButtonKeyBuffer: Text;
        OfflineTenderDeclLoginCommand: Text; // *
        DummyTxt: Text[50];
        LASTRECEIPT: Code[20];
        LASTPOSTerminalNo: Code[10];
        RetailUserStoreNo: Code[10];
        RetailUserTerminalNo: Code[10];
        ControlIDClipboard, ControlProfileClipboard : Code[20];
        ControlTypeClipboard: Integer;
        PosControlCodeunit: Integer;
        CurrJournalPage: Integer;
        EventNo: Integer;
        PosControlAction: Option ,LogoffPOS,LogoffStartup,RunPOS;
        HelpKeyActive: Boolean;
        GUIMgrKeyState: Boolean;
        DualDisplayJournalActive: Boolean;
        OnlyCardLogon: Boolean;

    internal procedure InitDualDisplayControl(var pDDCONTROLLIB: Codeunit "LSC POS Control Library")
    begin
        InitDualDisplayControl2(pDDCONTROLLIB);
    end;

    internal procedure InitDualDisplayControl2(var pDDCONTROLLIB: Codeunit "LSC POS Control Library")
    begin
        DDCONTROLLIB := pDDCONTROLLIB;
    end;

    internal procedure InitControl(var pCONTROLLIB: Codeunit "LSC POS Control Library"; pStoreNo: Code[10]; pTerminalNo: Code[10]; pSuperUser: Boolean): Boolean
    begin
        Clear(POSCtrl);
        CONTROLLIB := pCONTROLLIB;
        POSCtrl.SetClientTypeEnum("LSC POS Client Type"::Pos);

        if not POSCtrl.InitControl(pCONTROLLIB) then
            exit(false);

        POSCtrl.SetPosMenuDesignMode(pSuperUser);
        RetailUserStoreNo := pStoreNo;
        RetailUserTerminalNo := pTerminalNo;

        if RetailUserTerminalNo = '' then
            exit(true);

        if RetailUserTerminalNo = '#TEST_CLI#' then begin
            LoadPOSTerminalsMenu();
            exit(true);
        end;

        LoadPos();
        POSCtrl.ShowPanel(Format("LSC POS Panel Id"::"#OFFLINE"));
        exit(true);
    end;

    procedure RegisterStartupController(RetailModuleCode: Code[20]; ControllerID: Code[20]; Descr: Text[60]; CodeunitNo: Integer; StartupPanelID: Code[20]; GridPanelID: Code[20]; DataGridCtrlID: Code[20]; MainSectionMenuID: Code[20]; FuncMenuID: Code[20]; Func2MenuID: Code[20]; StatusBarMenuID: Code[20]; DataGridCtrl2ID: Code[20])
    var
        POSStartupController: Record "LSC POS Startup Controller";
    begin
        if not POSStartupController.get(ControllerID) then begin
            POSStartupController.init;
            POSStartupController."Controller ID" := ControllerID;
            POSStartupController.insert(true);
        end;
        POSStartupController.Description := Descr;
        POSStartupController."Controller Codeunit" := CodeunitNo;
        POSStartupController."Retail Module Code" := RetailModuleCode;
        POSStartupController."Startup Panel ID" := StartupPanelID;
        POSStartupController."Grid Panel ID" := GridPanelID;
        POSStartupController."Data Grid Ctrl. ID" := DataGridCtrlID;
        POSStartupController."Main Section Menu ID" := MainSectionMenuID;
        POSStartupController."Functions Menu ID" := FuncMenuID;
        POSStartupController."Statusbar Menu ID" := StatusBarMenuID;
        POSStartupController."Functions 2 Menu ID" := Func2MenuID;
        POSStartupController."Data Grid Ctrl. 2 ID" := DataGridCtrl2ID;
        POSStartupController.Modify(true);
    end;

    local procedure LoadPos()
    var
        POSStartupController: Record "LSC POS Startup Controller";
        HospitalityFunctions: Codeunit "LSC Hospitality Functions";
        OposUtil: Codeunit "LSC POS OPOS Utility";
    begin
        if not LoadBaseTables('', '') then
            Error('Failed to load Base tables');

        OposUtil.InitOpos();

        POSCtrl.SetWsInfo;

        POSFunctions.InitPosFunctions;

        if POSView.IsInitialized then begin //not properly closed..(probably refresh F5 .. will close it now)
            HospitalityFunctions.ReleasePosTerminalLocking(POSSession.TerminalNo()); //hospitality needs to unlock dining table and pos transaction plus more things
            POSView.Close();
        end;

        POSLines.InitJournalDataSet(1);

        if not POSCtrl.GetInitialized() then begin
            POSCtrl.SetInitialized(true);
            UpdatePosContext();
            LoadDualDisp;
            POSCtrl.LoadPOS;
            POSCtrl.RegisterPanelClosedEvent(Format("LSC POS Panel Id"::"#POS"));
            UpdateSessionPermissions;
            OnAfterNotGetInitialized;
        end;

        if POSStartupController.Get(POSSession.InterfaceProfile."POS Startup Controller ID") then
            PosControlCodeunit := POSStartupController."Controller Codeunit";

        LogBaseTables();
    end;

    local procedure LoadDualDisp()
    var
        PanelIDFilter: Text;
        InterfaceProfileID: Text;
        MenuProfileID: Text;
        StyleProfileID: Text;
        InterfaceProfileIDFilter: Text;
        MenuProfileIDFilter: Text;
        StyleProfileIDFilter: Text;
    begin
        if not PosSession.Terminal."Dual Disp. Enabled" then
            exit;

        PanelIDFilter := StrSubstNo('%1|%2|%3', Format("LSC POS Panel ID"::"#DD-OFFLINE"), Format("LSC POS Panel ID"::"#DD-SALES"), Format("LSC POS Panel ID"::"#DD-PAYMENT"));
        InterfaceProfileIDFilter := Format("LSC POS Profile ID"::DefaultInterface);
        InterfaceProfileID := PosSession.Terminal."Dual Disp. Interface Profile";
        if not (PosSession.Store."Interface Profile" in ['', Format("LSC POS Profile ID"::DefaultInterface)]) then
            InterfaceProfileIDFilter += '|' + PosSession.Store."Interface Profile";
        if not (PosSession.Terminal."Dual Disp. Interface Profile" in ['', PosSession.Store."Interface Profile", Format("LSC POS Profile ID"::DefaultInterface)]) then
            InterfaceProfileIDFilter += '|' + PosSession.Terminal."Dual Disp. Interface Profile";

        MenuProfileIDFilter := Format("LSC POS Profile ID"::DefaultMenu);
        MenuProfileID := PosSession.Terminal."Dual Disp. Menu Profile";
        if not (PosSession.Store."Menu Profile" in ['', Format("LSC POS Profile ID"::DefaultMenu)]) then
            MenuProfileIDFilter += '|' + PosSession.Store."Menu Profile";
        if not (PosSession.Terminal."Dual Disp. Menu Profile" in ['', PosSession.Store."Menu Profile", Format("LSC POS Profile ID"::DefaultMenu)]) then
            MenuProfileIDFilter += '|' + PosSession.Terminal."Dual Disp. Menu Profile";

        StyleProfileIDFilter := Format("LSC POS Profile ID"::DefaultStyle);
        StyleProfileID := PosSession.Terminal."Dual Disp. Style Profile";
        if not (PosSession.Store."Style Profile" in ['', Format("LSC POS Profile ID"::DefaultStyle)]) then
            StyleProfileIDFilter += '|' + PosSession.Store."Style Profile";
        if not (PosSession.Terminal."Dual Disp. Style Profile" in ['', PosSession.Store."Style Profile", Format("LSC POS Profile ID"::DefaultStyle)]) then
            StyleProfileIDFilter += '|' + PosSession.Terminal."Dual Disp. Style Profile";

        POSCtrl.SetClientTypeEnum("LSC POS Client Type"::DualDisplay);
        POSCtrl.SetControlLibrary(DDCONTROLLIB);

        POSCtrl.SetPosCtrlActiveMenuProfile(MenuProfileID, Format("LSC POS Profile ID"::DefaultMenu));
        POSCtrl.SetPosCtrlActiveInterfaceProfile(InterfaceProfileID, Format("LSC POS Profile ID"::DefaultInterface));
        POSCtrl.SetPosCtrlActiveStyle(StyleProfileID, Format("LSC POS Profile ID"::DefaultStyle));

        POSCtrl.SetInitialized(true);
        POSCtrl.ShowPanel(Format("LSC POS Panel ID"::"#DD-OFFLINE"));
        if PosSession.Terminal."Dual Disp. Slideshow" <> '' then
            POSCtrl.Playlist('#DD-SLIDESHOW', PosSession.Terminal."Dual Disp. Slideshow");
        POSCtrl.SetClientTypeEnum("LSC POS Client Type"::Pos);
    end;

    procedure PosIsActive(): Boolean
    begin
        exit(POSCtrl.PosIsActive);
    end;

    internal procedure CleanUp()
    var
        BackgroundMgt: Codeunit "LSC Background Mgt";
    begin
        BackgroundMgt.StopAllBackgroundSession;
    end;

    local procedure LookupResult(panelID: Text; resultOK: Boolean; payload: Text): Boolean
    var
        LookupRec: Record "LSC POS Lookup";
        LookupID, LookupFilter, LookupAssistValue : Text;
        IsHandled: Boolean;
    begin
        // Make sure we only handle #LOOKUP or ActiveLookup.PanelID when closing:
        if panelID <> Format("LSC POS Panel Id"::"#LOOKUP") then
            if true in [
                not PosSession.GetPosLookupRec(PosCtrl.GetActiveLookupID(), LookupRec),
                panelID <> LookupRec."Panel Control ID"
            ] then
                exit(false);

        if StrPos(payload, ',') > 0 then begin
            Evaluate(LookupID, SelectStr(1, payload));
            Evaluate(LookupFilter, SelectStr(2, payload));
        end;

        POSCtrl.LookupClosed(resultOK); // Lookup must always be met with a LookupClosed to update the stack index
        OnLookupResult(LookupID, LookupFilter, resultOK, IsHandled, LookupAssistValue, panelID);

        if LookupFilter = '##ASSIST' then begin
            if LookupAssistValue = '' then
                LookupAssistValue := POSCtrl.GetLookupKeyValue(LookupID);
            POSCtrl.SetLookupAssistValue(LookupAssistValue);
        end;

        if IsHandled then
            exit(true);

        POSView.ProcessLookupResult(payload);
        exit(true);
    end;

    local procedure ProcessModalResult(panelID: Text; resultOK: Boolean; payload: Text)
    var
        CalDateTime: DateTime;
        TmpTxt: Text;
        SetNewStaffID: Text;
        StaffID: Text;
        Password: Text;
        Workshift: Text;
        Manager: Boolean;
        IsHandled: Boolean;
    begin
        OnBeforeProcessModalResult(panelID, resultOK, payload, IsHandled);
        if IsHandled then
            exit;

        case panelID of
            Format("LSC POS Panel Id"::"#LOGIN"):
                begin
                    if resultOK then begin
                        if StrPos(payload, ',') > 0 then begin
                            Evaluate(Manager, SelectStr(1, payload));
                            Evaluate(SetNewStaffID, SelectStr(2, payload));
                        end;

                        StaffID := POSCtrl.GetInputText(Format("LSC POS Input Control Id"::"#STAFFID"));
                        Password := POSCtrl.GetInputText(Format("LSC POS Input Control Id"::"#PASSWORD"));
                        Workshift := CopyStr(POSCtrl.GetInputText(Format("LSC POS Input Control Id"::"#WORKSHIFT")), 1, 1);
                        if StaffID = '' then
                            exit;

                        OnLoginPanelIDOnProcessModalResult(Manager, SetNewStaffID, StaffID, Password, Workshift);
                        if not POSView.LoginEx(Manager, SetNewStaffID, false, StaffID, Password, Workshift) then
                            exit;

                        if Manager then begin //MGRKEY
                            SetRefreshMenuFlags();
                            UpdateSessionPermissions;
                        end else begin
                            if OfflineTenderDeclLoginCommand <> '' then begin
                                TmpTxt := OfflineTenderDeclLoginCommand;
                                OfflineTenderDeclLoginCommand := '';
                                ProcessTenderOpLogin(TmpTxt);
                            end else
                                RunPos();
                        end;
                    end;
                    exit;
                end;
            Format("LSC POS Panel Id"::"#PASSWORDCHANGE"):
                begin
                    if resultOK then begin
                        if not POSView.ProcessPasswordChangeInput(payload, StaffID, Password, Workshift) then begin //TRY AGAIN
                            POSCtrl.SetInputText(Format("LSC POS Input Control Id"::"#PASSWORDNEW"), '');
                            POSCtrl.SetInputText(Format("LSC POS Input Control Id"::"#PASSWORDCONFIRM"), '');
                            POSCtrl.ShowPanelModal(Format("LSC POS Panel Id"::"#PASSWORDCHANGE"), payload);
                        end
                        else begin
                            if POSView.LoginEx(false, '', false, StaffID, Password, Workshift) then
                                RunPos();
                        end;
                    end;
                end;
            Format("LSC POS Panel Id"::"#NUMPAD"):
                begin
                    OnNumpadResult(payload, POSCtrl.GetInputText(Format("LSC POS Input Control Id"::"#NUMPADINPUT")), resultOK, IsHandled);
                    if IsHandled then
                        exit;
                    POSView.ProcessNumpadResult(payload, POSCtrl.GetInputText(Format("LSC POS Input Control Id"::"#NUMPADINPUT")), resultOK);
                    exit;
                end;
            Format("LSC POS Panel Id"::"#KEYBOARD"):
                begin
                    OnKeyboardResult(payload, POSCtrl.GetInputText(Format("LSC POS Input Control Id"::"#KEYBOARDINPUT")), resultOK, IsHandled);
                    if IsHandled then
                        exit;
                    POSView.ProcessKeyboardResult(payload, POSCtrl.GetInputText(Format("LSC POS Input Control Id"::"#KEYBOARDINPUT")), resultOK);
                    exit;
                end;
            Format("LSC POS Panel Id"::"#CALENDAR"):
                begin
                    if not Evaluate(CalDateTime, POSEvent.StrData4, 9) then
                        CalDateTime := 0DT;
                    OnCalendarResult(payload, CalDateTime, resultOK, IsHandled);
                    if IsHandled then
                        exit;
                    POSView.ProcessCalendarResult(payload, CalDateTime, resultOK);
                    exit;
                end;
            else begin
                OnModalPanelResult(panelID, resultOK, payload, IsHandled); // GENERAL MODAL PANEL CLOSED
                if IsHandled then
                    exit;
            end;
        end;

        if LookupResult(panelID, resultOK, payload) then
            exit;

        if (payload = 'SEARCH') and resultOK then begin
            SearchFunc.SearchItemSelected();
            exit;
        end;
    end;

    internal procedure ProcessEvent(var pPosEvent: Codeunit "LSC POS Event"): Boolean
    var
        POSMenuLine: Record "LSC POS Menu Line";
        PosCommandRec: Record "LSC POS Command";
        TransLine: Record "LSC POS Trans. Line";
        PosCommand: Enum "LSC POS Command";
        EventType: Enum "LSC POS Event Type";
        IInputDevice: Interface "LSC IDevice Process Input Event";
        GridID: Text;
        DataID: Text;
        Sender: Text;
        lProfileID: Code[20];
        lMenuID: Code[20];
        lButtonPadID: Code[20];
        lButtonNo: Integer;
        SortColumn: Integer;
        IsHandled: Boolean;
        RunPostCommandProcessing: Boolean;
        SortAscending: Boolean;
    begin
        OnBeforeProcessEvent(pPosEvent, IsHandled);
        if IsHandled then
            exit;
        if pPosEvent.Ticks = -999999999 then begin
            OnDualDisplayPOSEvent(pPosEvent, IsHandled);
            if IsHandled then
                exit;
        end;

        POSCtrl.LogEvent(pPosEvent);
        CurrJournalPage := pPosEvent.Ticks;

        POSMenuLine.Processed := false;

        EventType := pPosEvent.EventType;
        POSMenuLine."Pos Event Type" := EventType.AsInteger();

        EventNo += 1;
        if EventNo > 999999999 then
            EventNo := 1;

        POSMenuLine."POS Event No." := EventNo;
        POSEvent.Push(pPosEvent);

        if RetailUserTerminalNo = '#TEST_CLI#' then begin
            if EventType = EventType::IDLETIMERTICK then
                exit;
            if EventType = EventType::PANELCLOSED then
                if pPosEvent.StrData = Format("LSC POS Panel Id"::"###POPUP_PANEL") then
                    exit;
        end;

        if pPosEvent.StrData() = Format("LSC POS Command"::"#SELECT_TERMINAL") then begin
            ProcessPOSTerminalSelect(pPosEvent.StrData2());
            exit;
        end;

        OnPOSEvent(pPosEvent, IsHandled, RunPostCommandProcessing);
        if IsHandled then begin
            if RunPostCommandProcessing then begin
                PostCommandProcessing();
                exit;
            end;
            UpdateMenuAreas();
            exit;
        end;

        case EventType of
            EventType::AUTOLOGOFF:
                begin
                    OnAutoLogoffPOSEvent(pPosEvent, POSView.IsNewTransaction(), PosSession.Terminal."Allow AutoLogoff in Sales Mode", PosControlCodeunit, IsHandled);
                    if IsHandled then
                        exit;
                    if true in [
                        pPosEvent.ActivePanel = Format("LSC POS Panel Id"::"#OFFLINE"),
                        POSView.IsNewTransaction(),
                        PosSession.Terminal."Allow AutoLogoff in Sales Mode"
                     ] then begin
                        LogoffPressed(pPosEvent.ActivePanel);
                        exit;
                    end;
                end;
            EventType::IDLETIMERTICK:
                POSTransactionCu.TriggerOnBeforeOnTimer();
            EventType::PANELCLOSED: // PANELCLOSED 11
                if pPosEvent.IntData1 = 1 then // MODAL PANEL RESULT
                    ProcessModalResult(pPosEvent.StrData, (pPosEvent.IntData2 = 1), pPosEvent.StrData2);
            EventType::BUTTONPRESS,
            EventType::POSCOMMAND,
            EventType::CONTEXTMENU:
                begin
                    Sender := pPosEvent.Sender;
                    if Sender = '' then
                        exit;

                    lProfileID := SelectStr(1, Sender);
                    lMenuID := SelectStr(2, Sender);
                    lButtonPadID := SelectStr(3, Sender);
                    lButtonNo := pPosEvent.IntData1;

                    PosCtrl.SetSelectedButton(lMenuID, pPOSEvent.IntData1);

                    if lProfileID = '' then
                        lProfileID := Format("LSC POS Profile Id"::DefaultMenu);

                    if not POSMenuLine.Get(lProfileID, lMenuID, pPosEvent.IntData1) then begin
                        if pPosEvent.StrData = '' then
                            exit;
                        POSMenuLine.Init;
                        POSMenuLine."Profile ID" := lProfileID;
                        POSMenuLine."Menu ID" := lMenuID;
                        POSMenuLine."Key No." := pPosEvent.IntData1;
                        POSMenuLine.Command := pPosEvent.StrData; // SOME COMMAND
                        POSMenuLine.Parameter := CopyStr(pPosEvent.StrData2, 1, MaxStrLen(POSMenuLine.Parameter));
                        POSMenuLine."POS Event No." := EventNo;
                    end else begin
                        POSMenuLine.Processed := false;
                        if pPosEvent.StrData <> '' then begin // POS COMMAND from control overrides database data (might be set specifcally)
                            POSMenuLine.Command := pPosEvent.StrData;
                            POSMenuLine.Parameter := CopyStr(pPosEvent.StrData2, 1, MaxStrLen(POSMenuLine.Parameter));
                        end;
                        POSMenuLine."POS Event No." := EventNo;
                    end;

                    POSMenuLine."Pos Event Control ID" := lButtonPadID;

                    OnButtonPressed(POSMenuLine, IsHandled);
                    if IsHandled then begin
                        UpdateMenuAreas();
                        exit;
                    end;

                    if ProcessButtonHelp(POSMenuLine) then
                        exit;

                    if RunDesignCommand(POSMenuLine) then
                        exit;
                end;
        end;

        if EventType in [
            EventType::INPUTCHANGE, // 1
            EventType::ENTERPRESSED, // 4
            EventType::DATAROWSELECTED, // 7
            EventType::DEVICEINPUT, // 8
            EventType::MARKEDCOUNTCHANGED, // 10
            EventType::PANELCLOSED, // 11
            EventType::IDLETIMERTICK, // 13
            EventType::QUERYPANELCLOSE, // 14
            EventType::ZOOMFIELDVALIDATION, // 15
            EventType::DATAROWDOUBLECLICK, // 16
            EventType::MENULAYOUTMODIFIED, // 17
            EventType::MENUBUTTONMOVED, // 18
            EventType::MENUBUTTONRESIZED, // 19
            EventType::GRIDCOLUMNSELECTED, // 20
            EventType::PANELSHOWN, // 24
            EventType::CONTEXTMENU, // 30
            EventType::DRAGDROP // 31
        ] then begin
            if POSSession.GetPosPanelRec(pPosEvent.ActivePanel, ActivePanel) then begin
                if ActivePanel.Codeunit > 0 then begin
                    if EventType = EventType::DEVICEINPUT then
                        POSMenuLine."Current-Message" := CopyStr(pPosEvent.StrData(), 1, MaxStrLen(POSMenuLine."Current-Message"));
                    CODEUNIT.Run(ActivePanel.Codeunit, POSMenuLine);
                    if POSMenuLine.Processed then begin
                        if EventType = EventType::ZOOMFIELDVALIDATION then
                            POSCtrl.ValidateZoomInput(pPosEvent); // Note: ZOOMFIELDVALIDATION always triggers ValidateZoomInput (use OnPOSEvent and mark the ZOOMFIELDVALIDATION type as processed to skip it, set StrData4 to set a custom error message)
                        PostCommandProcessing();
                        exit;
                    end;
                end;
            end;
        end;

        case EventType of
            EventType::MENUMISSING,
            EventType::IDLETIMERTICK:
                exit;
            EventType::INPUTCHANGE:
                begin
                    if SearchFunc.ProcessInputChanged(POSMenuLine) then
                        exit;
                end;
            EventType::ASSISTEDIT:
                begin
                    if SearchFunc.ProcessAssistEdit(POSMenuLine) then
                        exit;
                end;
            EventType::DATAROWDOUBLECLICK:
                begin
                    Sender := pPosEvent.Sender;
                    if StrPos(Sender, ',') <= 0 then
                        exit;
                    DummyTxt := SelectStr(1, Sender);
                    if DummyTxt = SearchFunc.GridID then begin
                        if SearchFunc.SearchItemSelected then
                            PostCommandProcessing();
                        exit;
                    end else
                        if PosSession.Terminal."Show Item Html" or PosSession.Terminal."Show Offer Html" then begin
                            if DummyTxt = Format("LSC POS Data Grid Id"::"#JOURNALGRID") then begin
                                if TransLine.Get(LASTRECEIPT, POSLines.GetCurrentLineNo()) then begin
                                    if POSSession.SetPosHtml(TransLine) then begin
                                        POSCtrl.Navigate(Format("LSC POS Panel Id"::"#POSHTML"), POSSession.GetPosHtml);
                                        POSCtrl.ShowPanelModal(Format("LSC POS Panel Id"::"#POSHTML"));
                                    end;
                                    exit;
                                end;
                            end
                        end
                end;
            EventType::ZOOMFIELDVALIDATION:
                begin
                    POSCtrl.ValidateZoomInput(pPosEvent);
                    exit;
                end;
            EventType::QUERYPANELCLOSE:
                begin
                    if pPosEvent.ActivePanel = Format("LSC POS Panel Id"::"#POS") then
                        if not POSView.InfocodeTestOnClose() then begin
                            POSCtrl.DenyPanelClose;
                            PostCommandProcessing();
                            exit;
                        end;
                end;
            EventType::INPUTLOOKUPASSIST:
                ProcessPosLookupRequest(pPosEvent.StrData2);
            EventType::PANELCLOSED:
                begin
                    if pPosEvent.IntData1 = 1 then //MODAL PANEL RESULT
                        PostCommandProcessing();
                    exit;
                end;
            EventType::MARKEDCOUNTCHANGED:
                begin
                    RunCommandFromColumn(ActivePanel, POSMenuLine);
                    DummyTxt := SelectStr(1, pPosEvent.Sender);
                    POSCtrl.DataGridMarkedCountChanged(DummyTxt, pPosEvent.IntData1);
                end;
            EventType::DEVICEINPUT:
                begin
                    IInputDevice := "LSC Device Process Input Type".FromInteger(pPosEvent.IntData1);
                    IInputDevice.ProcessInputData(pPosEvent, POSMenuLine);
                    PostCommandProcessing();
                end;
            EventType::DATAFIND:
                POSCtrl.LookupDataFind(SelectStr(1, pPosEvent.Sender), SelectStr(2, pPosEvent.Sender), pPosEvent.StrData);
            EventType::DATAREQUEST:
                begin
                    Evaluate(SortColumn, SelectStr(1, pPosEvent.StrData));
                    Evaluate(SortAscending, SelectStr(2, pPosEvent.StrData));
                    GridID := SelectStr(1, pPosEvent.Sender);
                    DataID := SelectStr(2, pPosEvent.Sender);
                    case GridID of
                        Format("LSC POS Data Grid Id"::"#JOURNALGRID"):
                            LoadJournalLinesByRequest(pPosEvent.IntData1, pPosEvent.IntData2, pPosEvent.IntData3, SortColumn, SortAscending, pPosEvent.StrData2);
                        Format("LSC POS Data Grid Id"::"#LOOKUPGRID"):
                            POSCtrl.LookupDataRequest(GridID, DataID, pPosEvent.IntData1, pPosEvent.IntData2, pPosEvent.IntData3, SortColumn, SortAscending, pPosEvent.StrData2);
                        SearchFunc.GridID:
                            ;
                        else
                            POSCtrl.DataRequest(GridID, DataID, pPosEvent.IntData1, pPosEvent.IntData2, pPosEvent.IntData3, SortColumn, SortAscending, pPosEvent.StrData2);
                    end;
                    if STRPOS(pPosEvent.Sender, 'REFUND') <> 0 then
                        if pPosEvent.StrData2 <> '' then
                            RefundScannedItem(pPosEvent.StrData2);
                end;
            EventType::POSFORMLOAD:
                begin
                    case pPosEvent.IntData1 of
                        0:
                            LoadPos();
                        1:
                            POSCtrl.ShowPanel(Format("LSC POS Panel Id"::"#OFFLINE"));
                        3:
                            begin
                                POSCtrl.LoadHardware();
                                POSCtrl.PostEvent('RUNCOMMAND', '_FORMLOAD', '4', '');
                            end;
                        4:
                            DisplayPosClosedText();
                    end;
                end;
            EventType::ENTERPRESSED:
                begin
                    case pPosEvent.IntData1 of
                        0: // INPUT
                            begin
                                if SearchFunc.ProcessEnterPressed(POSMenuLine) then begin
                                    PostCommandProcessing;
                                    exit;
                                end;

                                if pPosEvent.Sender = Format("LSC POS Input Control Id"::"#CURRINPUT") then begin
                                    CurrInput := pPosEvent.StrData;
                                    EnterPressed();
                                end
                            end;
                        1: // PANEL
                            begin
                                if pPosEvent.Sender = Format("LSC POS Panel Id"::"#OFFLINE") then begin
                                    if pPosEvent.StrData <> '' then begin
                                        if POSFunctions.ProcessMSRStaffLogin(pPosEvent.StrData, CurrInput) then
                                            StaffPressed(CurrInput);
                                    end else
                                        LoginPressed('');
                                end;
                            end;
                    end;
                    PostCommandProcessing();
                end;
            EventType::BUTTONPRESS,
            EventType::POSCOMMAND,
            EventType::CONTEXTMENU:
                begin
                    if TrackPOSCommandsUsage(POSMenuLine) then
                        if EventType = EventType::BUTTONPRESS then begin
                            POSFunctions.POSlog(POSMenuLine, POSView.GetReceiptNo);
                            Commit;
                        end;
                    if PosMenuLine."Show on Dual Disp." then
                        POSCtrl.EnableDualDisplayMirroring();

                    OnPOSCommand(ActivePanel, POSMenuLine);
                    if POSMenuLine.Processed then begin
                        PostCommandProcessing();
                        exit;
                    end;

                    PosCommand := PosCommandRec.CommandToEnum(POSMenuLine.Command);
                    case PosCommand of
                        PosCommand::LOGOFF:
                            begin
                                if not LogoffPressed(POSCtrl.ActivePanel) then begin
                                    PostCommandProcessing();
                                    exit;
                                end;
                                exit(true);
                            end;
                        PosCommand::LOGON,
                        PosCommand::LOGIN:
                            begin
                                LoginPressed(POSMenuLine.Parameter);
                                PostCommandProcessing();
                                exit;
                            end;
                        PosCommand::TD_OFFLINE:
                            begin
                                TenderOpPressed(POSMenuLine.Command, PosSession.FunctionalityProfile."Automatic Logon Staff ID"); // Tender Declaration
                                exit;
                            end;
                    end;

                    POSMenuLine."Current-SALESTYPE" := POSView.GetSalesType;
                    if POSMenuLine."Current-SALESTYPE" = '' then
                        POSMenuLine."Current-SALESTYPE" := POSView.GetGlobalSalesType;

                    if not POSSession.MenuPermission(POSMenuLine, POSMenuLine.Command, DummyTxt) or
                        not POSSession.MenuPermission(POSMenuLine, POSMenuLine."Post Command", DummyTxt) then begin
                        POSView.MessageBeep(DummyTxt);
                        PostCommandProcessing();
                        exit;
                    end;
                    POSMenuLine."Post Command" := '';
                    POSMenuLine."Post Parameter" := '';

                    if MenuHeader.Get(POSMenuLine."Profile ID", POSMenuLine."Menu ID") then
                        if MenuHeader."Pre-Execute Total" and (POSMenuLine."Pos Event Type" <> EventType::ContextMenu.AsInteger()) then begin
                            if not PreExecuteTotal() then
                                exit;
                            POSCtrl.PostEvent('RUNCOMMAND', POSMenuLine.Command, POSMenuLine.Parameter, '');
                            exit;
                        end;

                    if MenuHeader.Codeunit > 0 then begin
                        POSMenuLine."Pos Event Type" := EventType.AsInteger();
                        CODEUNIT.Run(MenuHeader.Codeunit, POSMenuLine);
                        if POSMenuLine.Processed then begin
                            PostCommandProcessing();
                            exit;
                        end;
                    end;

                    if POSSession.GetPosPanelRec(pPosEvent.ActivePanel, ActivePanel) then begin
                        // Tender Declaration
                        if POSSession.GetValue("LSC POS Tag"::TD_OFFLMENU) <> '' then begin
                            POSSession.SetValue("LSC POS Tag"::TD_OFFLMENU, '');
                            POSSession.SetValue("LSC POS Tag"::"SAF-CANCEL-SOD", 'INIT');
                            UpdateSessionProfiles();
                            MainRun();
                            POSView.SetOfflineTenderDeclState(POSMenuLine.Command);
                            POSSession.SetValue("LSC POS Tag"::"SAF-CANCEL-SOD", '');
                            RunCommand(PosMenuLine);
                            exit;
                        end;
                        if ActivePanel.Codeunit > 0 then begin
                            POSMenuLine."Pos Event Type" := EventType.AsInteger();
                            CODEUNIT.Run(ActivePanel.Codeunit, POSMenuLine);
                            if POSMenuLine.Processed then begin
                                UpdateMenuAreas();
                                exit;
                            end;
                        end;
                    end;
                    RunCommand(POSMenuLine);
                end;
            else //Unknow EVENT TYPE
                POSCtrl.LogDebug('Event Type (' + Format(EventType) + ') is unknown.');
        end;
    end;

    local procedure ProcessButtonHelp(var pMenuLine: Record "LSC POS Menu Line"): Boolean
    var
        POSCommand: Record "LSC POS Command";
        POSHelpTexts: Record "LSC POS Help Text";
        HtmlURL: Text;
        HelpID: Code[10];
        NoHelpAvailableErr: Label 'No Help is available for this item';
    begin
        if not HelpKeyActive then
            exit(false);
        HelpID := '';
        if pMenuLine."POS Help ID" <> '' then
            HelpID := pMenuLine."POS Help ID"
        else
            if POSCommand.Get(pMenuLine.Command) and (POSCommand."POS Help ID" <> '') then
                HelpID := POSCommand."POS Help ID";

        if (HelpID <> '') and POSHelpTexts.Get(HelpID) then begin
            if POSHelpTexts.URL <> '' then
                HtmlURL := POSHelpTexts.URL
            else
                HtmlURL := POSSession.GetHtmlURL(POSHelpTexts.RecordId, POSHelpTexts.FieldNo("Help Text"));
            POSCtrl.Navigate(Format("LSC POS Panel Id"::"#POSHTMLHELP"), HtmlURL);
            POSCtrl.ShowPanelModal(Format("LSC POS Panel Id"::"#POSHTMLHELP"));
            POSView.SetPosInfoText1(' ');
        end else
            POSView.ErrorBeep(NoHelpAvailableErr);
        HelpKeyActive := false;
        exit(true);
    end;

    local procedure LoadBaseTables(pStore: Code[10]; pTerminal: Code[10]): Boolean
    var
        POSSearch: Codeunit "LSC Search Index";
        StoreSetup: Record "LSC Store";
        PosTerminal: Record "LSC POS Terminal";
        NoTerminal: Label 'No terminal selected';
        MissingDecimalPlacesInfoMsg: Label 'Missing decimal places information in %1 for store %2';
        MissingRoundingInfoMsg: Label 'Missing rounding information in %1 for store %2';
    begin
        PosSession.Init;
        PosSession.SetValue("LSC POS Tag"::"SALESTYPE", '');
        PosSession.SetValue("LSC POS Tag"::"TABLENO", '');

        if pStore = '' then
            pStore := RetailUserStoreNo;

        if pTerminal = '' then
            pTerminal := RetailUserTerminalNo;

        if not PosTerminal.Get(pTerminal) then
            Error(NoTerminal);
        if PosTerminal."Store No." <> '' then
            pStore := PosTerminal."Store No.";

        StoreSetup.Get(pStore);
        PosSession.SetStore(StoreSetup);
        PosSession.SetTerminal(PosTerminal);
        PosSession.SetValue("LSC POS Tag"::"REC_TGL", '');

        if PosSession.FunctionalityProfile."Update Search Index" then begin
            POSSearch.Init();
            POSSearch.IndexFromActionsBackground();
        end;

        if (PosSession.FunctionalityProfile."Amount Rounding to" = 0) or (PosSession.FunctionalityProfile."Price Rounding to" = 0) then begin
            Message(StrSubstNo(MissingRoundingInfoMsg, PosSession.FunctionalityProfile.TableCaption, StoreSetup."No."));
            exit(false);
        end;
        if (PosSession.FunctionalityProfile."Amount Decimal Places" = '') or (PosSession.FunctionalityProfile."Price Decimal Places" = '') then begin
            Message(StrSubstNo(MissingDecimalPlacesInfoMsg, PosSession.FunctionalityProfile.TableCaption, StoreSetup."No."));
            exit(false);
        end;
        GetCurrencySymbol();

        exit(true);
    end;

    local procedure LogBaseTables()
    var
        HdwrProfileDevices: Record "LSC POS Hardware Profile Dev.";
        Recref: RecordRef;
        POSUTILS: Codeunit "LSC POS Control Utils";
    begin
        if LSCLog.GetLogLevel < 3 then
            exit;

        Recref.GetTable(PosSession.Store);
        LSCLog.SetMaxRecsPerLog(25); //25*256 //To Log All Profiles/Store/Terminal etc.
        LSCLog.LogDebug(POSUTILS.RecRefToJSONTxt(Recref.Name, Recref));
        Recref.GetTable(PosSession.Terminal);
        LSCLog.LogDebug(POSUTILS.RecRefToJSONTxt(Recref.Name, Recref));
        Recref.GetTable(PosSession.FunctionalityProfile);
        LSCLog.LogDebug(POSUTILS.RecRefToJSONTxt(Recref.Name, Recref));
        Recref.GetTable(PosSession.InterfaceProfile);
        LSCLog.LogDebug(POSUTILS.RecRefToJSONTxt(Recref.Name, Recref));

        Recref.GetTable(PosSession.MenuProfile);
        LSCLog.LogDebug(POSUTILS.RecRefToJSONTxt(Recref.Name, Recref));

        Recref.GetTable(PosSession.HardwareProfile);
        LSCLog.LogDebug(POSUTILS.RecRefToJSONTxt(Recref.Name, Recref));

        HdwrProfileDevices.SetRange("Profile ID", PosSession.HardwareProfile."Profile ID");
        if HdwrProfileDevices.FindSet() then begin
            repeat
                Recref := HdwrProfileDevices.GetDeviceRecordRef();
                LSCLog.LogDebug(POSUTILS.RecRefToJSONTxt(Recref.Name, Recref));
            until HdwrProfileDevices.Next = 0;
        end;

        LSCLog.SetMaxRecsPerLog(3); //back to Default
    end;

    local procedure GetCurrencySymbol()
    var
        Currency: Record Currency;
        Store: Record "LSC Store";
        CurrencySymbol: Text[10];
        LcyCurrencyTkn: Label 'LCY';
    begin
        if PosSession.FunctionalityProfile."POS Currency Symbol" <> '' then
            CurrencySymbol := PosSession.FunctionalityProfile."POS Currency Symbol"
        else
            if Currency.Get(Store."Currency Code") then
                if Currency."LSC POS Currency Symbol" <> '' then
                    CurrencySymbol := Currency."LSC POS Currency Symbol"
                else
                    CurrencySymbol := Store."Currency Code";

        if CurrencySymbol = '' then
            CurrencySymbol := LcyCurrencyTkn;

        POSSession.SetValue("LSC POS Tag"::"CURRSYM", CurrencySymbol);
    end;

    local procedure EnterPressed()
    var
        MenuHead: Record "LSC POS Menu Header";
        MenuLine2: Record "LSC POS Menu Line";
    begin
        POSView.SetCurrInput(CurrInput);

        if ContainsQRCode() then begin
            PostCommandProcessing;
            exit;
        end;

        if ContainsMemberCard() then begin
            PostCommandProcessing();
            exit;
        end;

        if not POSView.OkNewInput then begin
            if not POSView.ProcessBarcode then
                POSView.ValidateInput;
            PostCommandProcessing();
        end
        else begin
            if POSSession.GetPosMenuRec(POSView.GetCurrMenu(0), MenuHead) then
                MenuHeader := MenuHead;
            if MenuHeader."Map Enter To" <> '' then begin
                MenuLine2.Command := MenuHeader."Map Enter To";
                MenuLine2.Parameter := MenuHeader."Map Parameter";
                if MenuHead."Map Enter To" = Format("LSC POS Command"::ITEMNO) then
                    if MenuHeader."Map Parameter" = '' then
                        MenuLine2.Parameter := POSTransactionCu.GetLastItemNo();
                RunCommand(MenuLine2);
            end
            else
                POSView.MessageBeep('');
        end;
    end;

    local procedure LoginPressed(pStaffID: Code[20])
    begin
        POSSession.SetValue("LSC POS Tag"::TD_OFFLPANEL, '');
        POSSession.SetValue("LSC POS Tag"::TD_OFFLMENU, '');
        POSSession.SetValue("LSC POS Tag"::"SAF-CANCEL-SOD", '');

        case true of
            PosSession.FunctionalityProfile."Automatic Logon Staff ID" <> '':
                POSSession.SetStaff(PosSession.FunctionalityProfile."Automatic Logon Staff ID");
            not POSView.LoginEx(false, pStaffID, false, '', '', ''),
            pStaffID = '':
                exit;
        end;

        RunPos();
    end;

    internal procedure RunPos()
    var
        ErrorText: Text;
        Handled: Boolean;
    begin
        OnBeforeRunPos(POSSession.StaffID(), POSSession.TerminalNo(), Handled);
        if Handled then
            exit;
        if not CheckActiveLicense(ErrorText) then
            Error(ErrorText);
        UpdateSessionProfiles();
        if (PosControlCodeunit <> 0) and (OfflineTenderDeclLoginCommand = '') then begin
            if SODTenderDeclIsNeeded then
                exit;
            RunAction(PosControlCodeunit, PosControlAction::RunPOS);
            exit;
        end;
        if MainRun then
            HandlePanel;
    end;

    internal procedure LogoffPressed(pActivePanel: Text): Boolean
    var
        POSEventType: Enum "LSC POS Event Type";
        CancelPanelClosing: Boolean;
    begin
        if POSView.GetPosState = format("LSC POS Transaction State"::TENDOP) then
            exit;

        OnBeforeLogoffPressed(CancelPanelClosing);
        if CancelPanelClosing then
            exit;

        POSSession.SetValue("LSC POS Tag"::TD_OFFLMENU, '');

        if pActivePanel <> Format("LSC POS Panel Id"::"#OFFLINE") then begin
            if not POSView.InfocodeTestOnClose() then begin
                exit;
            end;
            POSView.LogoffPressed(false);

            if not POSView.Close then
                exit;

            if pActivePanel = Format("LSC POS Panel Id"::"#SAF-OFFLINE") then begin
                POSSession.SetStaff('');
                UpdateSessionProfiles();
            end else
                if PosControlCodeunit = 0 then begin
                    POSSession.SetStaff('');  //Close Session
                    UpdateSessionProfiles();
                end else
                    RunAction(PosControlCodeunit, PosControlAction::LogoffPOS);

            OnBeforeClosePOSPanelInLogoffPressed(pActivePanel, PosControlCodeunit, CancelPanelClosing);
            if not CancelPanelClosing then
                POSCtrl.ShowPanel(Format("LSC POS Panel Id"::"#OFFLINE"));

            if (POSEvent.EventType() = POSEventType::AUTOLOGOFF) and (PosControlCodeunit <> 0) then
                RunAction(PosControlCodeunit, PosControlAction::LogoffStartup);
            exit;
        end;
        // In Offline Panel:
        if POSSession.StaffID <> '' then begin
            POSSession.SetStaff('');  //Close Session
            UpdateSessionProfiles();

            if PosControlCodeunit <> 0 then
                RunAction(PosControlCodeunit, PosControlAction::LogoffStartup);
            exit;
        end;
        exit(true); // Return TRUE To indicate the EPOS Main (PAGE) can close
    end;

    local procedure TooltipRequested(HelpID: Code[20])
    var
        POSHelpTexts: Record "LSC POS Help Text";
        WS: Codeunit "LSC Web Services";
        UrlParts: List of [Text];
        HtmlURL: Text;
        RecID: Text;
        Txt: Text;
        FieldNo: Integer;
        UrlScheme: Label 'lshtml://';
        InvalidUrlErr: Label 'Html URL for Help ID [$1] is not valid: [%2]';
    begin
        if HelpID = '' then
            exit;
        if not POSHelpTexts.Get(HelpID) then
            exit;

        if POSHelpTexts.URL <> '' then begin
            HtmlURL := POSHelpTexts.URL;
            if HtmlURL.StartsWith(UrlScheme) then begin
                HtmlURL := HtmlURL.Substring(StrLen(UrlScheme));
                UrlParts := HtmlURL.Split('/');
                if UrlParts.Count = 2 then begin
                    RecID := UrlParts.Get(0);
                    Evaluate(FieldNo, UrlParts.Get(1));
                end else begin
                    Error(InvalidUrlErr, HelpId, POSHelpTexts.URL);
                    exit;
                end;
            end else begin
                POSCtrl.ShowTooltip(HtmlURL, 2); // url
                exit;
            end;
        end
        else begin
            RecID := Format(POSHelpTexts.RecordId);
            FieldNo := POSHelpTexts.FieldNo("Help Text");
        end;

        if RecID <> '' then
            if FieldNo >= 0 then
                if WS.GetPosHtml(RecID, FieldNo, Txt) then
                    POSCtrl.ShowTooltip(Txt, 1); // html
    end;

    local procedure HelpKeyPressed()
    var
        PressKeyForHelpMsg: Label 'Press key to see help text.';
    begin
        HelpKeyActive := true;
        POSView.SetPosInfoText1(PressKeyForHelpMsg);
    end;

    local procedure ValidateMgrKey(MenuParm: Code[20]): Boolean
    var
        PrePOSMenuHeader: Record "LSC POS Menu Header";
        MgrKeyRequiredErr: Label 'Manager key is required for this function';
    begin
        PrePOSMenuHeader := MenuHeader;
        if POSSession.GetPosMenuRec(MenuParm, MenuHeader) then
            if MenuHeader."Manager Key" then
                if not POSSession.MgrKey then begin
                    MenuHeader.Get(PrePOSMenuHeader."Profile ID", PrePOSMenuHeader."Menu ID");
                    POSView.ErrorBeep(MgrKeyRequiredErr);
                    exit(true);
                end;
    end;

    local procedure MenuPressed(MenuParm: Code[20])
    begin
        if ValidateMgrKey(MenuParm) then
            exit;
        SelectMenu(MenuParm);
    end;

    internal procedure BarcodeStaffLogin(StaffBarcode: Text)
    var
        BarcodeMask: Record "LSC Barcode Mask";
        PosFuncProfile: Record "LSC POS Func. Profile";
        PosSession: Codeunit "LSC POS Session";
        BcUtil: Codeunit "LSC Barcode Management";
        PosCtrl: Codeunit "LSC POS Control Interface";
        PosFunctions: Codeunit "LSC POS Functions";
        InvalidStaffInfoMsg: Label 'Invalid Staff information';
        StaffBarcodeNotAllowedMsg: Label '%1 is not allowed';
    begin
        if not BcUtil.FindBarcodeMask(StaffBarcode, BarcodeMask) then begin
            PosCtrl.PosMessage(InvalidStaffInfoMsg);
            exit;
        end;
        if BarcodeMask.Type <> BarcodeMask.Type::Employee then
            exit;
        PosFuncProfile.Get(PosSession.GetValue("LSC POS Tag"::"LSFUNCPROFILE"));
        if not PosFuncProfile."Staff Barcode Logon" then begin
            PosCtrl.PosMessage((StrSubstNo(StaffBarcodeNotAllowedMsg, PosFuncProfile.FieldCaption("Staff Barcode Logon"))));
            exit;
        end;
        StaffBarcode := PosFunctions.GetBarcStaff(CopyStr(StaffBarcode, 1, 22), BarcodeMask);
        StaffPressed(StaffBarcode);
    end;

    internal procedure DallasKeyLogin(CardNumber: Text[250])
    var
        MsrCardLinkSetup: Record "LSC MSR Card Link Setup";
    begin
        if MsrCardLinkSetup.Get(CardNumber) then
            if MsrCardLinkSetup."Link Type" = MsrCardLinkSetup."Link Type"::Cashier then
                CardNumber := MsrCardLinkSetup."Link No.";

        StaffPressed(CardNumber);
    end;

    internal procedure StaffPressed(StaffId: Text)
    var
        Staff: Record "LSC Staff";
        StaffStoreLink: Record "LSC STAFF Store Link";
        UnknownStaffIdMsg: Label 'Unknown Staff ID!';
        StaffNotRegisteredMsg: Label '%1 %2 is not registered in this store.';
        StaffIsBlockedMsg: Label '%1 %2 is blocked.';
    begin
        Commit;
        POSTransactionCu.TriggerOnBeforeStaffLogon(Staff);
        Commit;

        if true in [
            StaffId = '',
            StrLen(StaffId) > 20,
            not Staff.Get(StaffId)
        ] then begin
            POSCtrl.PosMessage(UnknownStaffIdMsg);
            exit;
        end;

        POSSession.SetStaff(Staff);
        POSSession.SetValue("LSC POS Tag"::SHIFT_NO, '');

        if SODTenderDeclIsNeeded then
            exit;

        if Staff.Blocked then begin
            PosCtrl.PosMessage((StrSubstNo(StaffIsBlockedMsg, Staff.TableCaption, Staff.ID)));
            exit;
        end;

        if not (true in [
            Staff."Store No." = '',
            Staff."Store No." = PosSession.Store."No.",
            StaffStoreLink.Get(Staff.ID, PosSession.Store."No.")
        ]) then begin
            PosCtrl.PosMessage(StrSubstNo(StaffNotRegisteredMsg, Staff.TableCaption, Staff.ID));
            exit;
        end;

        POSSession.SetStaff(Staff);
        POSSession.SetValue("LSC POS Tag"::SHIFT_NO, '');
        UpdateSessionProfiles();

        Commit;
        POSTransactionCu.TriggerOnAfterStaffLogon(Staff);
        Commit;

        if PosControlCodeunit <> 0 then begin
            if POSSession.FunctionalityProfile."Only Card Logon" and OnlyCardLogon then begin
                OnlyCardLogon := false;
                POSCtrl.HidePanel(Format("LSC POS Panel Id"::"#LOGIN"), true);
                ProcessTenderOpLogin(Format("LSC POS Command"::TD_OFFLINE));
            end else
                RunAction(PosControlCodeunit, PosControlAction::RunPOS);
            exit;
        end;

        if MainRun then
            HandlePanel;
    end;

    local procedure ShowDualDisplay(var pPOSMenuLine: Record "LSC POS Menu Line")
    begin
        if pPOSMenuLine.Parameter = '' then begin
            PosCtrl.PostCommand("LSC POS Command"::SHOWDUALDISPLAY, '2'); //get callback to show dual display
            exit;
        end;

        if PosSession.Terminal."Dual Disp. Enabled" then
            DDCONTROLLIB.ShowDualDisplay(PosSession.Terminal."Dual Disp. Screen");
    end;

    local procedure ShowPanelPressed(var pPOSMenuLine: Record "LSC POS Menu Line"; pModal: Boolean)
    begin
        if POSSession.GetPosPanelRec(pPOSMenuLine.Parameter, ActivePanel) then
            if ActivePanel.Codeunit > 0 then
                CODEUNIT.Run(ActivePanel.Codeunit, pPOSMenuLine); //Run 'SHOWPANEL' Command through codeunit (to initialize)

        if pPOSMenuLine.Parameter = Format("LSC POS Panel Id"::"#POS") then begin
            MainRun;
            HandlePanel;
            exit;
        end;

        if pModal then
            POSCtrl.ShowPanelModal(pPOSMenuLine.Parameter)
        else
            POSCtrl.ShowPanel(pPOSMenuLine.Parameter);
    end;

    local procedure DualDisplayJournalDataTableID(): Code[20]
    var
        DualDispInterfaceProfile: Record "LSC POS Interface Profile";
    begin
        if not DualDispInterfaceProfile.Get(PosSession.Terminal."Dual Disp. Interface Profile") then
            exit('');
        exit(DualDispInterfaceProfile."Journal Data Table ID");
    end;

    local procedure UpdateSessionProfiles()
    begin
        UpdateSessionPermissions();
        POSLines.InitJournalDataSet(1);
        if PosSession.Terminal."Dual Disp. Enabled" then begin
            if not (DualDisplayJournalDataTableID in ['', POSSession.InterfaceProfile."Journal Data Table ID"]) then begin
                POSLines.InitJournalDataSet(2);
                DualDisplayJournalActive := true;
            end else
                DualDisplayJournalActive := false;
        end;

        POSCtrl.SetPosCtrlActiveInterfaceProfile(POSSession.InterfaceProfile.ID, POSSession.Store."Interface Profile");
        POSCtrl.SetPosCtrlActiveMenuProfile(POSSession.MenuProfile.ID, POSSession.Store."Menu Profile");
        POSCtrl.SetPosCtrlActiveStyle(POSSession.StyleProfile.ID, POSSession.Store."Style Profile");
    end;

    internal procedure UpdateSessionPermissions()
    begin
        POSCtrl.UpdateSessionPermissions();
        GUIMgrKeyState := POSSession.MgrKey;
    end;

    local procedure MainRun(): Boolean
    var
        PosTransLine: Record "LSC POS Trans. Line";
    begin
        SetRefreshMenuFlags();

        if not CheckComputerName() then
            exit(false);

        if not POSView.Init() then
            exit(false);

        POSView.CalcTotals();
        LASTRECEIPT := POSView.GetReceiptNo();
        LASTPOSTerminalNo := POSView.GetPOSTerminalNo();
        PosTransLine.SetRange(PosTransLine."Receipt No.", LASTRECEIPT);
        if not PosTransLine.FindLast() then begin
            PosTransLine."Receipt No." := LASTRECEIPT;
            PosTransLine."Line No." := 0;
            PosTransLine."POS Terminal No." := LASTPOSTerminalNo;
        end;
        POSLines.SetCurrentLine(PosTransLine);
        POSView.SetCurrentLine(PosTransLine);

        LoadJournalLines(false);
        UpdateLineInfo();

        exit(true);
    end;

    local procedure HandlePanel()
    begin
        POSCtrl.ShowPanel(Format("LSC POS Panel Id"::"#POS"));
        SelectDefaultMenu();

        if PosView.GetRefreshMenuFlag(1) then
            LoadAddMenu(1, ServiceLocator.PosSessionMenu.GetAdd1Menu());
        if PosView.GetRefreshMenuFlag(2) then
            LoadAddMenu(2, ServiceLocator.PosSessionMenu.GetAdd2Menu());
        if PosView.GetRefreshMenuFlag(3) then
            LoadAddMenu(3, ServiceLocator.PosSessionMenu.GetAdd3Menu());

        OnAfterHandlePanel(Format("LSC POS Panel Id"::"#POS"));
    end;

    local procedure ConditionalEcho(Msg: Text)
    var
        TagValue: Text;
    begin
        // For testing, can set internal pos tag to echo results of debug commands (if we obsolete Get+SetValue(Text) we can add these to the public Enum if this feature is used)
        TagValue := PosSession.GetValue('_ls_echo');
        if TagValue = '' then
            exit;
        Msg := PosSession.GetValue('_ls_echo_pre') + Msg + PosSession.GetValue('_ls_echo_post'); // optionally add prefix/postfix
        case TagValue of
            '1':
                Dialog.Message(Msg);
            '2':
                PosSession.SetValue('_ls_echo_latest', Msg);
            '3':
                PosCtrl.PostCommand("LSC POS Command"::NOOP_CLIENT, Msg); // triggers StringRequest of Commands tuple where the value/response can be seen
        end;
    end;

    local procedure DialogCustom(ParameterLongAsJArr: JsonArray)
    var
        WinDialog: Dialog;
        Caption: Text;
        FirstMs: Integer;
        JTok: JsonToken;
    begin
        // Parameter: [SleepMs: number, Caption: string, UpdateNr: number][]
        // Example: [[2000, 'Please wait... #1#'], [3000, '500', 1]] will do Dialog.Open('Please wait... #1#'), wait for 2s, Dialog.Update(1, '500') so it says 'Please wait... 500', then it waits for 3s before closing the dialog.
        if ParameterLongAsJArr.Count() > 0 then begin
            FirstMs := ParameterLongAsJArr.GetArray(0).GetInteger(0);
            Caption := ParameterLongAsJArr.GetArray(0).GetText(1);
            ParameterLongAsJArr.RemoveAt(0);
        end;
        WinDialog.Open(Caption);
        if FirstMs > 0 then
            System.Sleep(FirstMs);
        foreach JTok in ParameterLongAsJArr do begin
            WinDialog.Update(JTok.AsArray().GetInteger(2), JTok.AsArray().GetText(1));
            System.Sleep(JTok.AsArray().GetInteger(0));
        end;
        WinDialog.Close();
    end;

    local procedure RunCommand(MenuLine: Record "LSC POS Menu Line"): Boolean
    var
        MenuLine2: Record "LSC POS Menu Line";
        PosCommandRec: Record "LSC POS Command";
        PosCommand: Enum "LSC POS Command";
        DynMenuAndLookup: Codeunit "LSC POS Dynamic MenuAndLookup";
        BOUtil: Codeunit "LSC BO Utils";
        HttpUtils: Codeunit "LSC Http Utils";
        ParameterLong: Text;
        ParameterLongAsJArr: JsonArray;
        ZeroForDivisionError: Integer;
        ConfirmRetValue: Boolean;
    begin
        POSCtrl.LogDebug('EPOSControler.RunCommand: ' + MenuLine.Command + ' Prameter: ' + MenuLine.Parameter);

        PosCommand := POSCommandRec.CommandToEnum(MenuLine.Command);
        if PosCommand = PosCommand::CANCEL then
            if MenuLine.Parameter = 'Escape' then
                exit;

        POSView.InitCommand;
        CurrInput := POSCtrl.GetInputText(Format("LSC POS Input Control Id"::"#CURRINPUT"));
        POSView.SetCurrInput(CurrInput);

        SetVisibility(MenuLine);

        ParameterLong := POSEvent.StrData2().StartsWith(MenuLine.Parameter) ? POSEvent.StrData2() : MenuLine.Parameter; // MenuLine.Parameter is cut to 100 chars max
        if ParameterLongAsJArr.ReadFrom(ParameterLong) then; // It's ok if it's not an Array, ignore the Error

        case PosCommand of
            PosCommand::HELP:
                HelpKeyPressed();
            PosCommand::TOOLTIP_TOGGLE:
                POSSession.SetTooltipActive((MenuLine.Parameter = '1') or ((MenuLine.Parameter <> '0') and not POSSession.GetTooltipActive())); // 1: Force ON, 0: Force OFF, Else: Toggle
            PosCommand::TOOLTIP:
                TooltipRequested(MenuLine.Parameter);
            PosCommand::HYPERLINK:
                System.Hyperlink(ParameterLong);
            PosCommand::ERROR:
                Dialog.Error(ParameterLong);
            PosCommand::ERROR_CUSTOM:
                Dialog.Error(HttpUtils.ErrorInfoFromJsonText(ParameterLong));
            PosCommand::ERROR_DIVZERO:
                Dialog.Message(Format(1 / ZeroForDivisionError)); // Intentionally divide by zero to trigger a runtime error
            PosCommand::DIALOG_CUSTOM:
                DialogCustom(ParameterLongAsJArr);
            PosCommand::MESSAGE:
                Dialog.Message(ParameterLong);
            PosCommand::CONFIRM:
                ConditionalEcho(Format(ParameterLongAsJArr.Count() = 2 ? Dialog.Confirm(ParameterLongAsJArr.GetText(0), ParameterLongAsJArr.GetInteger(1) = 1) : Dialog.Confirm(ParameterLong)));
            PosCommand::STRMENU:
                ConditionalEcho(Format(ParameterLongAsJArr.Count() = 3 ? Dialog.StrMenu(ParameterLongAsJArr.GetText(0), ParameterLongAsJArr.GetInteger(1), ParameterLongAsJArr.GetText(2)) : Dialog.StrMenu(ParameterLong)));
            PosCommand::SLEEP:
                System.Sleep(BOUtil.StrToInt(MenuLine.Parameter, 0));
            PosCommand::LASTMENU:
                SelectLastMenu();
            PosCommand::DEFMENU:
                SelectDefaultMenu();
            PosCommand::MACRO:
                RunMacro(ParameterLong);
            PosCommand::MENU, PosCommand::IMENU:
                MenuPressed(MenuLine.Parameter);
            PosCommand::MENU1:
                LoadAddMenu(1, MenuLine.Parameter);
            PosCommand::MENU2:
                LoadAddMenu(2, MenuLine.Parameter);
            PosCommand::MENU3:
                LoadAddMenu(3, MenuLine.Parameter);
            PosCommand::POPUP:
                PopupMenu(MenuLine.Parameter);
            PosCommand::DYNMENU:
                DynMenuAndLookup.DynMenuPressed(MenuLine);
            PosCommand::DYNLOOKUP:
                DynMenuAndLookup.DynLookupPressed(MenuLine);
            PosCommand::SEARCH:
                SearchFunc.OpenSearchPanel(MenuLine.Parameter);
            PosCommand::HARDWAREPROFILE:
                SetHardwareProfile(MenuLine.Parameter);
            PosCommand::MOBILESCAN:
                PAGE.RunModal(Page::"LSC POS Scanner Dialog");
            PosCommand::HARDWAREINFO:
                ProcessHardwareInfo(MenuLine);
            PosCommand::ZOOM_GRID_REC:
                POSCtrl.ZoomDataGridRecord(POSCtrl.ActiveDataGrid, MenuLine.Parameter);
            PosCommand::ZOOM_LOOKUP_REC:
                POSCtrl.ZoomActiveLookupRecord(MenuLine.Parameter);
            PosCommand::EDIT_GRID_REC:
                POSCtrl.EditDataGridRecord(POSCtrl.ActiveDataGrid, MenuLine.Parameter);
            PosCommand::EDIT_LOOKUP_REC:
                POSCtrl.EditActiveLookupRecord(MenuLine.Parameter);
            PosCommand::NEW_GRID_REC:
                POSCtrl.NewDataGridRecord(POSCtrl.ActiveDataGrid, MenuLine.Parameter);
            PosCommand::NEW_LOOKUP_REC:
                POSCtrl.NewActiveLookupRecord(MenuLine.Parameter);
            PosCommand::DEL_GRID_REC:
                POSCtrl.DeleteDataGridRecords(POSCtrl.ActiveDataGrid);
            PosCommand::DEL_LOOKUP_REC:
                POSCtrl.DeleteActiveLookupRecords();
            PosCommand::SHOWDATATABLE:
                POSCtrl.InitDataGridControl(POSCtrl.ActiveDataGrid, MenuLine.Parameter);
            PosCommand::SHOWPANEL:
                ShowPanelPressed(MenuLine, false);
            PosCommand::SHOWPANELMODAL:
                ShowPanelPressed(MenuLine, true);
            PosCommand::SHOWDUALDISPLAY:
                ShowDualDisplay(MenuLine);
            PosCommand::SWIPE_LEFT:
                begin
                    MenuLine.Parameter := ActivePanel."Left Panel ID";
                    ShowPanelPressed(MenuLine, false);
                end;
            PosCommand::SWIPE_RIGHT:
                begin
                    MenuLine.Parameter := ActivePanel."Right Panel ID";
                    ShowPanelPressed(MenuLine, false);
                end;
            PosCommand::ALPROFILER:
                AlProfiler(MenuLine.Parameter);
            PosCommand::ALPROFILER_OPEN:
                Page.RunModal(Page::"Performance Profiler");
            PosCommand::DEBUGLOG_OPEN:
                Page.RunModal(Page::"LSC POS Debug Setup");
            PosCommand::MGRKEY:
                begin
                    if POSSession.ManagerID <> '' then begin
                        POSSession.ClearManagerID();
                        SetRefreshMenuFlags();
                        UpdateSessionPermissions();
                    end else
                        POSView.Login(true, '');
                end;
            PosCommand::EFT_DEVICE:
                SetEftDeviceRole(MenuLine.Parameter);
            else begin
                if MenuLine.Command <> '' then begin
                    ClearLastError;
                    POSView.Run(MenuLine);
                    Commit;
                end;
            end;
        end;

        if not MenuLine."Not Post Command" then begin
            if MenuLine."Post Command" <> '' then begin
                PostCommandProcessing();
                MenuLine2.Command := MenuLine."Post Command";
                MenuLine2.Parameter := MenuLine."Post Parameter";
                MenuLine2."Current-LINE" := MenuLine."Current-LINE";
                MenuLine2."POS Event No." := POSView.GetNewLineNo;
                MenuLine2."Key No." := MenuLine."Key No.";
                MenuLine2."Profile ID" := MenuLine."Profile ID";
                MenuLine2."Menu ID" := MenuLine."Menu ID";
                MenuLine2."Current-DynLookup" := MenuLine."Current-DynLookup";
                MenuLine2."From Post Command" := true;
                exit(RunCommand(MenuLine2));
            end;
        end;

        PostCommandProcessing();
    end;

    internal procedure RunDesignCommand(MenuLine: Record "LSC POS Menu Line"): Boolean
    var
        ButtonMenuLine: Record "LSC POS Menu Line";
        ClipboardMenuLine: Record "LSC POS Menu Line";
        StyleProfile: Record "LSC POS Style Profile";
        FunctionalityProfile: Record "LSC POS Func. Profile";
        InterfaceProfile: Record "LSC POS Interface Profile";
        Terminal: Record "LSC POS Terminal";
        Store: Record "LSC Store";
        DataTable: Record "LSC POS Data Table";
        PosLookup: Record "LSC POS Lookup";
        HardwareProfileRec: Record "LSC POS Hardware Profile";
        MenuProfile: Record "LSC POS Menu Profile";
        Staff: Record "LSC Staff";
        Tmpl: Record "LSC POS Web Template";
        BrowserCtrl: Record "LSC POS Browser Control";
        PosCommandRec: Record "LSC POS Command";
        BOUtil: Codeunit "LSC BO Utils";
        PosCommand: Enum "LSC POS Command";
        TmplId: Text;
        ProfileID: Code[20];
        MenuId: Code[20];
        ButtonNo: Integer;
        NoLookupActiveMsg: Label 'No lookup is active.';
        NoStaffIdMsg: Label 'Staff ID not set.';
        PasteAllBtnsMsg: Label 'Paste attributes to all buttons in menu';
        SrcBtnNotFoundMsg: Label 'Source button can not be found';
    begin
        if not POSCommandRec.CommandExists(MenuLine.Command, PosCommand) then
            exit(false);

        case PosCommand of
            PosCommand::CONTROL_ADD:
                AddControl(
                  SelectStr(1, MenuLine.Parameter),
                  SelectStr(2, MenuLine.Parameter),
                  BOUtil.StrToInt(SelectStr(3, MenuLine.Parameter), 0),
                  BOUtil.StrToInt(SelectStr(4, MenuLine.Parameter), 0),
                  BOUtil.StrToInt(SelectStr(5, MenuLine.Parameter), 0)
                );
            PosCommand::CONTROL_CUT:
                CutControl(
                  SelectStr(1, MenuLine.Parameter),
                  SelectStr(2, MenuLine.Parameter),
                  BOUtil.StrToInt(SelectStr(3, MenuLine.Parameter), 0),
                  BOUtil.StrToInt(SelectStr(4, MenuLine.Parameter), 0),
                  SelectStr(5, MenuLine.Parameter)
                );
            PosCommand::CONTROL_COPY:
                CopyControl(
                  SelectStr(1, MenuLine.Parameter),
                  SelectStr(2, MenuLine.Parameter),
                  BOUtil.StrToInt(SelectStr(3, MenuLine.Parameter), 0),
                  BOUtil.StrToInt(SelectStr(4, MenuLine.Parameter), 0),
                  SelectStr(5, MenuLine.Parameter),
                  SelectStr(6, MenuLine.Parameter)
                );
            PosCommand::CONTROL_PASTE:
                PasteControl(
                  SelectStr(1, MenuLine.Parameter),
                  SelectStr(2, MenuLine.Parameter),
                  BOUtil.StrToInt(SelectStr(3, MenuLine.Parameter), 0),
                  BOUtil.StrToInt(SelectStr(4, MenuLine.Parameter), 0)
                );
            PosCommand::CONTROL_REMOVE:
                RemoveControl(
                  SelectStr(1, MenuLine.Parameter),
                  SelectStr(2, MenuLine.Parameter),
                  BOUtil.StrToInt(SelectStr(3, MenuLine.Parameter), 0),
                  BOUtil.StrToInt(SelectStr(4, MenuLine.Parameter), 0),
                  SelectStr(5, MenuLine.Parameter)
                );
            PosCommand::CONTROL_SPAN_ROW:
                ChangeControlSpan(
                  SelectStr(1, MenuLine.Parameter),
                  SelectStr(2, MenuLine.Parameter),
                  BOUtil.StrToInt(SelectStr(3, MenuLine.Parameter), 0),
                  BOUtil.StrToInt(SelectStr(4, MenuLine.Parameter), 0),
                  SelectStr(5, MenuLine.Parameter),
                  SelectStr(6, MenuLine.Parameter),
                  true
                );
            PosCommand::CONTROL_SPAN_COLUMN:
                ChangeControlSpan(
                  SelectStr(1, MenuLine.Parameter),
                  SelectStr(2, MenuLine.Parameter),
                  BOUtil.StrToInt(SelectStr(3, MenuLine.Parameter), 0),
                  BOUtil.StrToInt(SelectStr(4, MenuLine.Parameter), 0),
                  SelectStr(5, MenuLine.Parameter),
                  SelectStr(6, MenuLine.Parameter),
                  false
                );
            PosCommand::CONTROL_PROPERTIES:
                ControlProperties(
                  SelectStr(1, MenuLine.Parameter),
                  SelectStr(2, MenuLine.Parameter),
                  BOUtil.StrToInt(SelectStr(3, MenuLine.Parameter), 0),
                  BOUtil.StrToInt(SelectStr(4, MenuLine.Parameter), 0),
                  SelectStr(5, MenuLine.Parameter),
                  SelectStr(6, MenuLine.Parameter)
                );
            PosCommand::DT_UPDATE_COL_SIZES:
                UpdateDataTableColumnSizes(MenuLine.Parameter);
            PosCommand::PANEL_UPDATE_SIZES:
                UpdatePosPanelSizes(MenuLine.Parameter);
            PosCommand::PANEL_PROPERTIES:
                EditActivePosPanel(MenuLine.Parameter);
            PosCommand::BUTTON_PROPERTIES:
                ButtonProperties(MenuLine."Profile ID", MenuLine."Menu ID", MenuLine."Key No.");
            PosCommand::MENU_PROPERTIES:
                begin
                    if MenuHeader.Get(MenuLine."Profile ID", MenuLine."Menu ID") then begin
                        PAGE.RunModal(Page::"LSC POS Menu", MenuHeader);
                        POSCtrl.SetPosCtrlActiveStyle(POSSession.PosStyleID, POSSession.Store."Style Profile");
                    end;
                    POSCtrl.RefreshMenu(MenuLine."Profile ID", MenuLine."Menu ID");
                    SetRefreshMenuFlags();
                end;
            PosCommand::BUTTON_COPY:
                begin
                    // BUTTON_CUT removed at some point
                    if ButtonMenuLine.Get(MenuLine."Profile ID", MenuLine."Menu ID", MenuLine."Key No.") then begin
                        ButtonKeyBuffer := BOUtil.CombineTableKey(3, MenuLine."Profile ID", MenuLine."Menu ID", Format(MenuLine."Key No."), '', '');
                        MenuLineClipBoard.TransferFields(MenuLine, false);
                    end else
                        ButtonKeyBuffer := '';
                end;
            PosCommand::BUTTON_PASTE:
                begin
                    if ButtonKeyBuffer = '' then
                        exit(true);
                    if not ButtonMenuLine.Get(MenuLine."Profile ID", MenuLine."Menu ID", MenuLine."Key No.") then begin
                        ButtonMenuLine.Init;
                        ButtonMenuLine."Profile ID" := MenuLine."Profile ID";
                        ButtonMenuLine."Menu ID" := MenuLine."Menu ID";
                        ButtonMenuLine."Key No." := MenuLine."Key No."
                    end;
                    ProfileID := BOUtil.SeparateTableKey(1, ButtonKeyBuffer);
                    MenuId := BOUtil.SeparateTableKey(2, ButtonKeyBuffer);
                    Evaluate(ButtonNo, BOUtil.SeparateTableKey(3, ButtonKeyBuffer));
                    if not ClipboardMenuLine.Get(ProfileID, MenuId, ButtonNo) then
                        Error(SrcBtnNotFoundMsg);

                    BOUtil.Paste(ClipboardMenuLine, ButtonMenuLine, MenuLine."Key No.");

                    if not ButtonMenuLine.Insert then
                        ButtonMenuLine.Modify;
                    POSCtrl.RefreshMenuButton(MenuLine."Profile ID", MenuLine."Menu ID", MenuLine."Key No.");
                end;
            PosCommand::BUTTON_PASTE_SWAP:
                begin
                    if ButtonKeyBuffer = '' then
                        exit(true);
                    if not ButtonMenuLine.Get(MenuLine."Profile ID", MenuLine."Menu ID", MenuLine."Key No.") then begin
                        ButtonMenuLine.Init;
                        ButtonMenuLine."Profile ID" := MenuLine."Profile ID";
                        ButtonMenuLine."Menu ID" := MenuLine."Menu ID";
                        ButtonMenuLine."Key No." := MenuLine."Key No."
                    end;
                    ProfileID := BOUtil.SeparateTableKey(1, ButtonKeyBuffer);
                    MenuId := BOUtil.SeparateTableKey(2, ButtonKeyBuffer);
                    Evaluate(ButtonNo, BOUtil.SeparateTableKey(3, ButtonKeyBuffer));
                    if not ClipboardMenuLine.Get(ProfileID, MenuId, ButtonNo) then
                        Error(SrcBtnNotFoundMsg);

                    MenuLine.SwapLines(ClipboardMenuLine."Key No." - MenuLine."Key No.", MenuLine);
                    POSCtrl.RefreshMenuButton(MenuLine."Profile ID", MenuLine."Menu ID", MenuLine."Key No.");
                    POSCtrl.RefreshMenuButton(ClipboardMenuLine."Profile ID", ClipboardMenuLine."Menu ID", ClipboardMenuLine."Key No.");
                end;
            PosCommand::BUTTON_PASTE_ATTR:
                begin
                    if true in [
                        ButtonKeyBuffer = '',
                        not ButtonMenuLine.Get(MenuLine."Profile ID", MenuLine."Menu ID", MenuLine."Key No.")
                    ] then
                        exit(true);
                    ProfileID := BOUtil.SeparateTableKey(1, ButtonKeyBuffer);
                    MenuId := BOUtil.SeparateTableKey(2, ButtonKeyBuffer);
                    if Evaluate(ButtonNo, BOUtil.SeparateTableKey(3, ButtonKeyBuffer)) then;
                    if not ClipboardMenuLine.Get(ProfileID, MenuId, ButtonNo) then
                        Error(SrcBtnNotFoundMsg);
                    BOUtil.PasteAttributes(ClipboardMenuLine, ButtonMenuLine);
                    ButtonMenuLine.Modify;
                    POSCtrl.RefreshMenuButton(MenuLine."Profile ID", MenuLine."Menu ID", MenuLine."Key No.");
                end;
            PosCommand::BUTTON_DELETE:
                begin
                    if not ButtonMenuLine.Get(MenuLine."Profile ID", MenuLine."Menu ID", MenuLine."Key No.") then
                        exit(true);
                    ButtonMenuLine.Command := '';
                    ButtonMenuLine.Modify;
                    POSCtrl.RefreshMenuButton(MenuLine."Profile ID", MenuLine."Menu ID", MenuLine."Key No.");
                    ButtonMenuLine.Delete(true);
                    POSCtrl.DeleteMenuButton(MenuLine."Profile ID", MenuLine."Menu ID", MenuLine."Key No.");
                end;
            PosCommand::BUTTON_PASTE_ATTRALL:
                begin
                    if not POSCtrl.PosConfirm(PasteAllBtnsMsg, true) then
                        exit(true);

                    if true in [
                        ButtonKeyBuffer = '',
                        not ButtonMenuLine.Get(MenuLine."Profile ID", MenuLine."Menu ID", MenuLine."Key No.")
                    ] then
                        exit(true);
                    ProfileID := BOUtil.SeparateTableKey(1, ButtonKeyBuffer);
                    MenuId := BOUtil.SeparateTableKey(2, ButtonKeyBuffer);
                    Evaluate(ButtonNo, BOUtil.SeparateTableKey(3, ButtonKeyBuffer));
                    if not ClipboardMenuLine.Get(ProfileID, MenuId, ButtonNo) then
                        Error(SrcBtnNotFoundMsg);
                    BOUtil.PasteAttributesToAll(ClipboardMenuLine, ButtonMenuLine);
                    POSCtrl.RefreshMenu(MenuLine."Profile ID", MenuLine."Menu ID");
                end;
            PosCommand::DATATABLE_PROPERTIES:
                begin
                    if true in [
                        MenuLine.Parameter = '',
                        not DataTable.Get(MenuLine.Parameter)
                    ] then
                        exit(true);
                    PAGE.Run(Page::"LSC POS Data Table Card", DataTable);
                end;
            PosCommand::LOOKUP_PROPERTIES:
                begin
                    if POSCtrl.GetActiveLookupID() <> '' then
                        if true in [
                            PosLookup.Get(POSSession.InterfaceProfile.ID, POSCtrl.GetActiveLookupID()),
                            PosLookup.Get(POSSession.Store."Interface Profile", POSCtrl.GetActiveLookupID()),
                            PosLookup.Get(Format("LSC POS Profile ID"::DefaultInterface), POSCtrl.GetActiveLookupID())
                        ] then begin
                            PAGE.Run(Page::"LSC POS Lookup Card", PosLookup);
                            exit(true);
                        end;
                    POSCtrl.PosMessage(NoLookupActiveMsg);
                end;
            PosCommand::STORE_PROPERTIES:
                begin
                    if Store.Get(POSSession.StoreNo) then begin
                        PAGE.RunModal(Page::"LSC Store Card", Store);
                        POSCtrl.RefreshProfiles();
                        SelectDefaultMenu();
                    end else
                        OposUtil.Beeper;
                end;
            PosCommand::TERMINAL_PROPERTIES:
                begin
                    if Terminal.Get(POSSession.TerminalNo) then begin
                        PAGE.RunModal(Page::"LSC POS Terminal Card", Terminal);
                        POSCtrl.RefreshProfiles();
                        SelectDefaultMenu();
                    end else
                        OposUtil.Beeper;
                end;
            PosCommand::INTERFACE_PROFILE:
                begin
                    if InterfaceProfile.Get(POSSession.InterfaceProfileID) then begin
                        PAGE.RunModal(Page::"LSC POS Interface Profile Card", InterfaceProfile);
                        POSCtrl.RefreshInterfaceProfile(POSSession.CreateFilter(
                          InterfaceProfile.ID,
                          POSSession.Store."Interface Profile",
                          Format("LSC POS Profile ID"::DefaultInterface)
                        ));
                    end else
                        OposUtil.Beeper;
                end;
            PosCommand::HARDWARE_PROFILE,
            PosCommand::HARDWARECARD:
                begin
                    if HardwareProfileRec.Get(POSSession.HardwareProfileID) then begin
                        PAGE.RunModal(Page::"LSC POS Hardware Profile Card", HardwareProfileRec);
                        SetHardwareProfile(HardwareProfileRec."Profile ID");
                    end else
                        OposUtil.Beeper;
                end;
            PosCommand::FUNCTIONAL_PROFILE:
                begin
                    if FunctionalityProfile.Get(POSSession.FunctionalityProfileID) then begin
                        PAGE.RunModal(Page::"LSC POS Func. Profile Card", FunctionalityProfile);
                        POSCtrl.RefreshProfiles();
                    end else
                        OposUtil.Beeper;
                end;
            PosCommand::STYLE_PROFILE:
                begin
                    if StyleProfile.Get(POSSession.PosStyleID) then begin
                        PAGE.RunModal(Page::"LSC POS Style Profile Card", StyleProfile);
                        POSCtrl.RefreshStyleProfile(StyleProfile.ID);
                        POSCtrl.RefreshPosPanels(POSSession.CreateFilter(
                          POSSession.InterfaceProfileID,
                          POSSession.Store."Interface Profile",
                          ''
                        ), POSCtrl.ActivePanel);
                    end else
                        OposUtil.Beeper;
                end;
            PosCommand::MENU_PROFILE:
                begin
                    if MenuProfile.Get(POSSession.MenuProfileID) then begin
                        PAGE.RunModal(Page::"LSC POS Menu Profile Card", MenuProfile);
                        SelectDefaultMenu();
                    end else
                        OposUtil.Beeper;
                end;
            PosCommand::STAFF_PROPERTIES:
                begin
                    if Staff.Get(POSSession.StaffID) then begin
                        PAGE.RunModal(Page::"LSC STAFF Staff Card", Staff);
                        POSCtrl.RefreshProfiles();
                        SelectDefaultMenu();
                    end else begin
                        OposUtil.Beeper;
                        POSCtrl.PosMessage(NoStaffIdMsg);
                    end;
                end;
            PosCommand::TEMPLATE_PROPERTIES:
                begin
                    TmplId := BrowserCtrl.GetTemplateIdFromUrl(MenuLine.Parameter);
                    if TmplId = '' then
                        TmplId := MenuLine.Parameter;

                    if Tmpl.Get(TmplId) then begin
                        Page.RunModal(Page::"LSC POS Web Template", Tmpl);
                        POSCtrl.Refresh('');
                    end else begin
                        OposUtil.Beeper;
                        POSCtrl.PosMessage(StrSubstNo('Template ID [%1] not found', MenuLine.Parameter));
                    end;
                end;
            PosCommand::CLEAR_MEDIA_CACHE:
                ClearMediaCache(MenuLine.Parameter); // Use with caution, only intended for debugging/diagnosing issues
            PosCommand::PLAYLIST:
                POSCtrl.Playlist('', MenuLine.Parameter);
            PosCommand::DIST_LOCATION:
                OpenDistributionLocation(MenuLine.Parameter);
            PosCommand::SCALE_DIALOG:
                ShowScaleDialog();
            else
                exit(false);
        end;

        exit(true);
    end;

    internal procedure PostCommandProcessing()
    var
        TmpMenuID: Code[20];
        CancelPanelClosing: Boolean;
    begin
        if GUIMgrKeyState <> POSSession.MgrKey then
            UpdateSessionPermissions();

        UpdateMenuAreas();

        TmpMenuID := POSView.GetSelectedMenu;
        if TmpMenuID <> '' then
            SelectMenu(TmpMenuID)
        else
            if POSView.DefaultMenuSelectFlagged then
                SelectDefaultMenu;

        if POSView.IsNewTransaction() then
            posctrl.ClearMarkedRecords(Format("LSC POS Data Grid Id"::"#JOURNALGRID"));

        LASTRECEIPT := POSView.GetReceiptNo;
        LoadJournalLines(false);

        CurrInput := POSView.GetCurrInput();
        POSCtrl.SetInputText(Format("LSC POS Input Control Id"::"#CURRINPUT"), CurrInput);

        if POSView.GetClosePosFlag() then begin
            OnBeforeClosePOSPanelInPostCommandProcessingWhenCloseFlagSet(PosControlCodeunit, CancelPanelClosing);
            if not CancelPanelClosing then
                POSCtrl.ShowPanel(Format("LSC POS Panel Id"::"#OFFLINE"));
        end;

        POSFunctions.PosTransDiscFlush;
    end;

    local procedure SelectLastMenu()
    begin
        if MenuHeader."LASTMENU jump to menu" <> '' then begin
            SelectMenu(MenuHeader."LASTMENU jump to menu");
            exit;
        end;
        if POSView.GetLastMenu <> '' then
            SelectMenu(POSView.GetLastMenu);
    end;

    local procedure SelectDefaultMenu(): Boolean
    var
        SelectedMenu: Code[20];
        MenuMissingMsg: Label '%1 is missing';
    begin
        OnBeforeSelectDefaultMenu(SelectedMenu);
        If SelectedMenu <> '' then
            exit(SelectMenu(SelectedMenu));

        case POSView.GetPosStateEnum of
            "LSC POS Transaction State"::SALES:
                begin
                    if POSView.IsNewTransaction then begin
                        if ServiceLocator.PosSessionMenu().GetStartMenu() = '' then
                            PosCtrl.PosMessage(StrSubstNo(MenuMissingMsg, PosSession.MenuProfile.FieldCaption("Start Menu")));
                        exit(SelectMenu(ServiceLocator.PosSessionMenu().GetStartMenu()));
                    end
                    else begin
                        if ServiceLocator.PosSessionMenu.GetSalesMenu() = '' then
                            PosCtrl.PosMessage(StrSubstNo(MenuMissingMsg, PosSession.MenuProfile.FieldCaption("Sales Menu")));
                        exit(SelectMenu(ServiceLocator.PosSessionMenu.GetSalesMenu()));
                    end;
                end;
            "LSC POS Transaction State"::PAYMENT:
                begin
                    if POSView.SaleIsReturnSale then begin
                        if ServiceLocator.PosSessionMenu().GetRefundMenu() = '' then begin
                            if ServiceLocator.PosSessionMenu().GetPaymentMenu() = '' then
                                PosCtrl.PosMessage(StrSubstNo(MenuMissingMsg, PosSession.MenuProfile.FieldCaption("Payment Menu")));
                            exit(SelectMenu(ServiceLocator.PosSessionMenu().GetPaymentMenu()));
                        end;
                        exit(SelectMenu(ServiceLocator.PosSessionMenu().GetRefundMenu()));
                    end
                    else begin
                        if ServiceLocator.PosSessionMenu().GetPaymentMenu() = '' then
                            PosCtrl.PosMessage(StrSubstNo(MenuMissingMsg, PosSession.MenuProfile.FieldCaption("Payment Menu")));
                        exit(SelectMenu(ServiceLocator.PosSessionMenu().GetPaymentMenu()));
                    end;
                end;
            "LSC POS Transaction State"::TENDOP:
                begin
                    if ServiceLocator.PosSessionMenu().GetTenderMenu() = '' then
                        PosCtrl.PosMessage(StrSubstNo(MenuMissingMsg, PosSession.MenuProfile.FieldCaption("Tender Op. Menu")));
                    exit(SelectMenu(ServiceLocator.PosSessionMenu().GetTenderMenu()));
                end;
            "LSC POS Transaction State"::NEG_ADJ:
                begin
                    if ServiceLocator.PosSessionMenu().GetNegAdjMenu() = '' then
                        PosCtrl.PosMessage(StrSubstNo(MenuMissingMsg, PosSession.MenuProfile.FieldCaption("Neg. Adj. Menu")));
                    exit(SelectMenu(ServiceLocator.PosSessionMenu().GetNegAdjMenu()));
                end;
            "LSC POS Transaction State"::PHYS_INV:
                begin
                    if ServiceLocator.PosSessionMenu().GetPhysInvMenu() = '' then
                        PosCtrl.PosMessage(StrSubstNo(MenuMissingMsg, PosSession.MenuProfile.FieldCaption("Phys. Inv. Menu")));
                    exit(SelectMenu(ServiceLocator.PosSessionMenu().GetPhysInvMenu()));
                end;
        end;
        exit(false);
    end;

    local procedure SelectMenu(MenuID: Code[20]): Boolean
    var
        MenuNotFoundMsg: Label 'POS Menu Not found!\ProfileID=%1, MenuID=%2';
    begin
        if not PosSession.GetPosMenuRec(MenuID, MenuHeader) then begin
            PosCtrl.PosMessage(StrSubstNo(MenuNotFoundMsg, PosSession.MenuProfileID, MenuID));
            exit(false);
        end;

        if POSView.GetCurrMenu(0) <> MenuID then
            POSView.SetLastMenu(POSView.GetCurrMenu(0));
        POSView.SetCurrMenu(0, MenuID);

        LoadMenu(MenuID);

        if (MenuHeader."Menu Caption" <> '') and (MenuHeader."Menu Caption" <> POSView.PosInfoText1) then begin
            if (POSView.PosInfoText2 <> '') and (POSView.PosInfoText2 <> POSView.PosInfoText1) then
                POSView.SetPosInfoText2(POSView.PosInfoText1 + ' - ' + POSView.PosInfoText2)
            else
                POSView.SetPosInfoText2(POSView.PosInfoText1);
            POSView.SetPosInfoText1(MenuHeader."Menu Caption");
        end;

        exit(true);
    end;

    internal procedure GetStartStopModeFromParameter(Parameter: Text; var Mode: Enum "LSC POS StartStopDownload"): Boolean
    begin
        exit(true in [
            Parameter = '',
            Evaluate(Mode, Parameter)
        ]);
    end;

    internal procedure AlProfiler(Parameter: Text)
    var
        SamplingPerformanceProfiler: Codeunit "Sampling Performance Profiler";
        FileName: Text;
        Mode: Enum "LSC POS StartStopDownload";
    begin
        if not GetStartStopModeFromParameter(Parameter, Mode) then
            exit;
        if Mode in [Mode::Default, Mode::Start] then begin
            if not SamplingPerformanceProfiler.IsRecordingInProgress then begin
                SamplingPerformanceProfiler.Start();
                exit;
            end;
            if Mode = Mode::Start then
                exit;
        end;
        if Mode in [Mode::Default, Mode::Stop, Mode::StopAndDownload] then begin
            if not SamplingPerformanceProfiler.IsRecordingInProgress then
                exit;
            SamplingPerformanceProfiler.Stop();
        end;
        if Mode in [Mode::Default, Mode::StopAndDownload, Mode::Download] then begin
            FileName := StrSubstNo('LSC_AL_Profiler_%1.pos.alcpuprofile', GetTimestampStr);
            if not DownloadFromStream(SamplingPerformanceProfiler.GetData(), '', '', '', FileName) then
                exit;
        end;
    end;

    internal procedure GetTimestampStr(): Text
    begin
        exit(Format(CurrentDateTime, 0, 9).Substring(1, 19).Replace(':', '').Replace('T', '')); // '2023-12-24T18:05:07.090Z' -> '2023-12-24_180507'
    end;

    local procedure SetVisibility(var MenuLine: Record "LSC POS Menu Line")
    begin
        if not MenuLine."Use Visible Settings" then
            exit;

        // Note: Can only use POSCtrl.HideControl, SetButtonPadVisible hasn't been supported since WinPOS in BC 14 (needs to store the previous position to show it again)
        if MenuLine."Visible Main Menu" = MenuLine."Visible Main Menu"::"Non-Visible" then
            POSCtrl.HideControl("LSC POS Control Type"::ButtonPad.AsInteger(), Format("LSC POS Button Pad Id"::"#MAIN"));

        if MenuLine."Visible Add. Menu 1" = MenuLine."Visible Add. Menu 1"::"Non-Visible" then
            POSCtrl.HideControl("LSC POS Control Type"::ButtonPad.AsInteger(), Format("LSC POS Button Pad Id"::"#ADDMENU1"));

        if MenuLine."Visible Add. Menu 2" = MenuLine."Visible Add. Menu 2"::"Non-Visible" then
            POSCtrl.HideControl("LSC POS Control Type"::ButtonPad.AsInteger(), Format("LSC POS Button Pad Id"::"#ADDMENU2"));

        if MenuLine."Visible Add. Menu 3" = MenuLine."Visible Add. Menu 3"::"Non-Visible" then
            POSCtrl.HideControl("LSC POS Control Type"::ButtonPad.AsInteger(), Format("LSC POS Button Pad Id"::"#ADDMENU3"));

        if MenuLine."Visible Journal" = MenuLine."Visible Journal"::"Non-Visible" then
            POSCtrl.HideControl("LSC POS Control Type"::ButtonPad.AsInteger(), Format("LSC POS Panel Id"::"#JOURNAL"));

        if MenuLine."Visible Numeric Pad" = MenuLine."Visible Numeric Pad"::"Non-Visible" then
            POSCtrl.HideControl("LSC POS Control Type"::ButtonPad.AsInteger(), Format("LSC POS Button Pad Id"::"#NUMPAD"));

        if MenuLine."VisibleTotal Area" = MenuLine."VisibleTotal Area"::"Non-Visible" then
            POSCtrl.HideControl("LSC POS Control Type"::ButtonPad.AsInteger(), Format("LSC POS Button Pad Id"::"#TOTALS"));

        if MenuLine."Visible Description Area" = MenuLine."Visible Description Area"::"Non-Visible" then
            POSCtrl.HideControl("LSC POS Control Type"::ButtonPad.AsInteger(), Format("LSC POS Button Pad Id"::"#INFO"));
    end;

    local procedure RunMacro(MacroIdOrJson: Text)
    var
        MacroRec: Record "LSC POS Macro Line";
        MenuLine: Record "LSC POS Menu Line";
        JObj: JsonObject;
        JArr, JArrInner : JsonArray;
        JTok: JsonToken;
        Mode: Integer;
    begin
        // Object -> Array -> Code[10]
        if not JObj.ReadFrom(MacroIdOrJson) then begin
            if not JArr.ReadFrom(MacroIdOrJson) then begin
                MacroRec.SetRange(MacroRec."Profile ID", POSSession.MenuProfileID);
                MacroRec.SetRange(MacroRec."Macro ID", MacroIdOrJson);
                if not MacroRec.FindSet then
                    exit;
                repeat
                    if MacroRec.Command = '' then
                        continue;
                    Clear(JArrInner);
                    JArrInner.Add(MacroRec.Command);
                    if MacroRec.Parameter <> '' then
                        JArrInner.Add(MacroRec.Parameter);
                    JArr.Add(JArrInner);
                until MacroRec.Next = 0;
            end;
        end else begin
            JArr := JObj.GetArray('c', true);
            Mode := JObj.GetInteger('m', true);
        end;
        foreach JTok in JArr do begin
            if true in [
                not JTok.IsArray(),
                JTok.AsArray().Count() <= 0
            ] then
                continue;
            JArrInner := JTok.AsArray();
            MenuLine.Command := JArrInner.GetText(0).Trim().ToUpper();
            MenuLine.Parameter := JArrInner.Count() > 1 ? JArrInner.GetText(1) : '';
            if Mode = 1 then
                RunCommand(MenuLine)
            else
                PosCtrl.PostEvent('RUNCOMMAND', MenuLine.Command, MenuLine.Parameter, '');
        end;
    end;

    local procedure LoadMenu(pMenuID: Code[20])
    var
        Handled: Boolean;
    begin
        OnLoadMenu(pMenuID, Handled);
        if Handled then
            exit;
        if pMenuID = ServiceLocator.PosSessionMenu().GetQuickCashMenu() then
            UpdateQuickCashMenu();

        POSCtrl.ShowMenu(pMenuID, Format("LSC POS Button Pad Id"::"#MAIN"));
    end;

    local procedure LoadAddMenu(MenuNo: Integer; SelectMenu: Code[20])
    var
        IsHandled: Boolean;
        ButtonPadID: Code[20];
    begin
        if ValidateMgrKey(SelectMenu) then
            exit;
        case MenuNo of
            1:
                ButtonPadID := Format("LSC POS Button Pad Id"::"#ADDMENU1");
            2:
                ButtonPadID := Format("LSC POS Button Pad Id"::"#ADDMENU2");
            3:
                ButtonPadID := Format("LSC POS Button Pad Id"::"#ADDMENU3");
        end;
        OnBeforeLoadAddMenu(MenuNo, SelectMenu, ButtonPadID, IsHandled);
        if IsHandled then
            exit;
        POSCtrl.ShowMenu(SelectMenu, ButtonPadID);
    end;

    local procedure PopupMenu(p_Menu: Code[20])
    begin
        POSView.SetLastMenu(POSView.GetCurrMenu(0));
        POSCtrl.PopupMenu(p_Menu);
    end;

    local procedure UpdateLineInfo()
    var
        LineRec: Record "LSC POS Trans. Line";
        ItemVariant: Record "Item Variant";
        Handled: Boolean;
    begin
        POSLines.GetCurrentLine(LineRec);
        OnBeforeUpdateLineInfo(LineRec, Handled);
        if Handled then
            exit;
        if LineRec.Number <> '' then begin
            POSView.SetPosInfoText1(LineRec.Description);
            POSView.SetPosInfoText2('');

            if LineRec."Variant Code" <> '' then begin
                if ItemVariant.Get(LineRec.Number, LineRec."Variant Code") then
                    POSView.SetPosInfoText2(ItemVariant."Description 2");
            end;
        end;

        POSSession.UpdatePosPicture(LineRec);

        OnAfterUpdateLineInfo(LineRec);
    end;

    local procedure UpdateQuickCashMenu()
    var
        QCMenuHeader: Record "LSC POS Menu Header";
        QCMenuLine: Record "LSC POS Menu Line";
        QuickCashFunc: Codeunit "LSC POS Quick Cash Functions";
        TempQCMenuLine: Record "LSC POS Menu Line" temporary;
        TenderTypeCode: Code[10];
    begin
        if not POSSession.GetPosMenuRec(ServiceLocator.PosSessionMenu().GetQuickCashMenu(), QCMenuHeader) then
            exit;

        TenderTypeCode := '';
        QCMenuLine.SetRange("Profile ID", QCMenuHeader."Profile ID");
        QCMenuLine.SetRange("Menu ID", QCMenuHeader."Menu ID");
        QCMenuLine.SetRange("Post Command", Format(Enum::"LSC POS Command"::TENDER_K));
        QCMenuLine.SetFilter("Post Parameter", '>%1', '');
        if QCMenuLine.FindFirst() then
            TenderTypeCode := QCMenuLine."Post Parameter";

        QuickCashFunc.BuildCashMenu(QCMenuHeader, POSView.GetBalanceWithTenderOffer(TenderTypeCode), TempQCMenuLine);

        POSCtrl.UploadMenuLineRec(TempQCMenuLine, QCMenuHeader."Profile ID", QCMenuHeader."Menu ID", '');
    end;

    local procedure PreExecuteTotal(): Boolean
    begin
        if not POSView.OkNewInput then begin
            POSView.MessageBeep('');
            exit(false);
        end;
        if not POSView.TotalPressed then
            exit(false);
        POSView.DefaultMenuSelectFlagged; //remove flag
        PostCommandProcessing();

        exit(true);
    end;

    local procedure ClearMediaCache(pParameter: Text)
    var
        PosImageUtils: Codeunit "LSC POS Image Utils";
        Dict: Dictionary of [Text, Text];
        KeyText: Text;
        JObj: JsonObject;
        JTok: JsonToken;
        ShouldResend, ShouldSkipWT : Boolean;
    begin
        ShouldResend := pParameter.StartsWith('RESEND');
        ShouldSkipWT := pParameter.Contains('_SKIPWT');
        if not ShouldSkipWT then begin
            Dict := PosCtrl.GetWebTemplateHandler.ClearImageCache(ShouldResend);
        end;
        JObj := CONTROLLIB.ClearImageCache(ShouldResend);
        if ShouldResend then begin
            foreach KeyText in Dict.Keys do
                PosCtrl.GetWebTemplateHandler.AddWebTemplateImage(KeyText, Dict.Get(KeyText));
            if JObj.Get('img', JTok) then begin
                foreach KeyText in JTok.AsObject.Keys do
                    PosImageUtils.GetImg(KeyText, CONTROLLIB);
            end;
            if JObj.Get('pl', JTok) then begin
                foreach KeyText in JTok.AsObject.Keys do
                    PosImageUtils.GetPlaylist(KeyText, CONTROLLIB);
            end;
        end;
    end;

    local procedure ButtonProperties(pMenuProfileID: Code[10]; pMenuID: Code[20]; pButtonNo: Integer)
    var
        ButtonPropertiespage: Page "LSC POS Button Properties";
        Result: Action;
    begin
        if not ButtonPropertiesLine.Get(pMenuProfileID, pMenuID, pButtonNo) then begin
            if not MenuHeader.Get(pMenuProfileID, pMenuID) then
                exit;

            ButtonPropertiesLine.Init;
            ButtonPropertiesLine."Profile ID" := pMenuProfileID;
            ButtonPropertiesLine."Menu ID" := pMenuID;
        end;

        ButtonPropertiesLine."Key No." := pButtonNo;
        Clear(ButtonPropertiespage);
        ButtonPropertiespage.SetMenuLine(ButtonPropertiesLine);
        ButtonPropertiespage.LookupMode := true;
        Result := ButtonPropertiespage.RunModal;
        if Result = ACTION::LookupOK then begin
            ButtonPropertiespage.GetMenuLine(ButtonPropertiesLine);
            UpdateButton(ButtonPropertiesLine."Profile ID", ButtonPropertiesLine."Menu ID", pButtonNo);
            Commit;
        end;
    end;

    local procedure UpdateButton(pMenuProfileID: Code[10]; pMenuID: Code[20]; pButtonNo: Integer)
    var
        InvalidButtonNoMsg: Label 'Invalid button number'; // Label 'No %1 has been specified for this %2';
    begin
        if pButtonNo = 0 then begin
            Message(InvalidButtonNoMsg);
            exit;
        end;
        ButtonPropertiesLine."Profile ID" := pMenuProfileID;
        ButtonPropertiesLine."Menu ID" := pMenuID;
        ButtonPropertiesLine."Key No." := pButtonNo;
        if not ButtonPropertiesLine.Insert(true) then
            ButtonPropertiesLine.Modify(true);

        POSCtrl.RefreshMenuButton(pMenuProfileID, pMenuID, pButtonNo);
    end;

    local procedure UpdateDataTableColumnSizes(JsonStr: Text)
    var
        Cols: Record "LSC POS Data Table Columns";
        JArr: JsonArray;
        JTok: JsonToken;
        Id: Text;
        Tno: Integer;
        C: Integer;
        W: Integer;
        InvalidColSizesErr: Label 'Datatable Column Resize: JSON could not be parsed';
        ColumnNotFoundErr: Label 'Datatable Column Resize: Column %1 wasn''t found for datatable %2|%3';
    begin
        if (JsonStr = '') or (not JArr.ReadFrom(JsonStr)) or (JArr.Count <> 5) then
            Error(InvalidColSizesErr);

        JArr.Get(0, JTok);
        Id := JTok.AsValue().AsText();
        JArr.Get(1, JTok); // why is tableno part of PK??
        Tno := JTok.AsValue().AsInteger();
        JArr.Get(2, JTok);
        C := JTok.AsValue().AsInteger();
        JArr.Get(3, JTok);
        W := JTok.AsValue().AsInteger();

        if not Cols.Get(Id, Tno, C) then
            Error(ColumnNotFoundErr, C, Id, Tno);
        Cols."Preferred Width %" := W;
        Cols.Modify();

        C += 1;
        JArr.Get(4, JTok);
        W := JTok.AsValue().AsInteger();

        if not Cols.Get(Id, Tno, C) then
            Error(ColumnNotFoundErr, C, Id, Tno);
        Cols."Preferred Width %" := W;
        Cols.Modify();
    end;

    local procedure UpdatePosPanelSizes(JsonStr: Text)
    var
        PosPanelRec: Record "LSC POS Panel";
        PosSizes: Record "LSC POS Panel Row/Column";
        JArr: JsonArray;
        JTok: JsonToken;
        RObj: JsonObject;
        CObj: JsonObject;
        K: Text;
        S: Integer;
        PanelNotFoundErr: Label 'PosPanel Size: No Active Panel was found';
        InvalidPanelSizesErr: Label 'PosPanel Size: JSON could not be parsed';
    begin
        if (JsonStr = '') or (not JArr.ReadFrom(JsonStr)) or (JArr.Count <> 2) then
            Error(InvalidPanelSizesErr);
        JArr.Get(0, JTok);
        CObj := JTok.AsObject();
        JArr.Get(1, JTok);
        RObj := JTok.AsObject();
        if not POSSession.GetPosPanelRec(POSCtrl.ActivePanel, PosPanelRec) then
            Error(PanelNotFoundErr);
        foreach K in CObj.Keys do begin
            CObj.Get(K, JTok);
            S := JTok.AsValue().AsInteger();
            if not PosSizes.Get(PosPanelRec."Interface Profile ID", PosPanelRec."Control ID", PosSizes.Type::Column, K) then
                Error(InvalidPanelSizesErr, PosPanelRec."Control ID", 'Column', K);
            PosSizes.Size := S;
            PosSizes.Modify();
        end;
        foreach K in RObj.Keys do begin
            RObj.Get(K, JTok);
            S := JTok.AsValue().AsInteger();
            if not PosSizes.Get(PosPanelRec."Interface Profile ID", PosPanelRec."Control ID", PosSizes.Type::Row, K) then
                Error(InvalidPanelSizesErr, PosPanelRec."Control ID", 'Row', K);
            PosSizes.Size := S;
            PosSizes.Modify();
        end;
    end;

    local procedure EditActivePosPanel(pPanelID: Text)
    var
        PosPanelRec: Record "LSC POS Panel";
    begin
        if pPanelID = '' then
            pPanelID := POSCtrl.ActivePanel;
        POSSession.GetPosPanelRec(pPanelID, PosPanelRec);
        PAGE.RunModal(Page::"LSC POS Panel Card", PosPanelRec);
        POSCtrl.SetPosCtrlActiveStyle(POSSession.PosStyleID, POSSession.Store."Style Profile");
        POSCtrl.RefreshPosPanel(PosPanelRec."Interface Profile ID", PosPanelRec."Control ID", POSSession.MenuProfileID);
    end;

    local procedure ShowScaleDialog()
    var
        ScaleRec: Record "LSC POS Scale";
        ScaleDialog: Page "LSC POS Scale Dialog";
        DeviceId: Code[20];
        TextScaleNotFound: Label 'The hardware profile has no scale configured.';
    begin
        DeviceId := PosSession.HardwareProfile().GetHardwareProfileDeviceId("LSC Hardware Profile Devices"::Scale);
        if ScaleRec.Get(DeviceId) then begin
            ScaleDialog.SetGetChecksums(ScaleRec."Scale Server HTTPS", ScaleRec."Scale Server Host", ScaleRec.ID);
            ScaleDialog.RunModal();
        end else begin
            Error(TextScaleNotFound);
        end;
    end;

    local procedure GetHwstHost(): text
    var
        HwstRec: Record "LSC POS Hardware Profile";
        Host: text;
    begin
        HwstRec.Get(POSSession.HardwareProfileID);
        if HwstRec."HWST Host" = '' then begin
            if HwstRec."HWST Port" > 0 then
                Host := 'localhost' + Format(HwstRec."HWST Port")
            else
                Host := 'localhost:8082'
        end
        else
            if StrPos(HwstRec."HWST Host", ':') > 0 then
                Host := HwstRec."HWST Host"
            else
                if HwstRec."HWST Port" > 0 then
                    Host := HwstRec."HWST Host" + ':' + Format(HwstRec."HWST Port")
                else
                    Host := HwstRec."HWST Host" + ':8082';

        exit(Host);
    end;

    local procedure DisplayPosClosedText()
    var
        DeviceID: Code[20];
        DisplayDevice: Record "LSC POS Display";
        OposUtil: Codeunit "LSC POS OPOS Utility";
    begin
        if true in [
           not PosSession.Terminal."Display Terminal Closed",
           not PosSession.HardwareProfile.GetDevice("LSC Hardware Profile Devices"::Display, '', '', 0, DeviceID),
           not DisplayDevice.Get(deviceID)
        ] then
            exit;
        if PosSession.Terminal."Customer Display Text 1" = '' then
            OposUtil.Display(DisplayDevice."Display Closed Line1", DisplayDevice."Display Closed Line2")
        else
            OposUtil.Display(PosSession.Terminal."Customer Display Text 1", PosSession.Terminal."Customer Display Text 2");

    end;

    local procedure StartStatusIsEOD(): Boolean
    var
        PosStartStatus: Record "LSC POS Start Status";
        ID_l: Code[20];
        IsHandled, ReturnValue : Boolean;
    begin
        OnBeforeStartStatusIsEOD(IsHandled, ReturnValue);
        If IsHandled then
            exit(ReturnValue);

        POSSession.SetValue("LSC POS Tag"::TD_OFFLPANEL, '');

        if not PosSession.Store."Safe Mgnt. in Use" then
            exit(false);

        if PosSession.Terminal."Exclude from Cash Mgnt." then
            exit(false);

        case PosSession.Store."Statement Method" OF
            PosSession.Store."Statement Method"::Staff:
                ID_l := POSSession.StaffID;
            PosSession.Store."Statement Method"::"POS Terminal":
                ID_l := POSSession.TerminalNo;
        end;
        if PosStartStatus.Get(PosSession.Store."No.", PosSession.Store."Statement Method", ID_l) then begin
            if PosStartStatus.Status = PosStartStatus.Status::"End of Day" then begin
                POSSession.SetValue("LSC POS Tag"::TD_OFFLMENU, '1');
                exit(true);
            end;

            exit(false);
        end;
        POSSession.SetValue("LSC POS Tag"::TD_OFFLPANEL, '1');
        exit(true);
    end;

    local procedure SODTenderDeclIsNeeded(): Boolean
    var
        SODLoginMsg: Label 'You need to log into Tender Operation and do a Start Of Day Tender Declaration';
    begin
        if not StartStatusIsEOD then
            exit(false);
        PosCtrl.PosMessage(SODLoginMsg);
        exit(true);
    end;

    local procedure TenderOpPressed(pCommand: Text; pAutoLoginStaffID: Text)
    var
        MSRCardText: Label 'Swipe the MSR Card. Staff login is only allowed using card.';
    begin
        if pAutoLoginStaffID <> '' then begin
            POSSession.SetStaff(pAutoLoginStaffID);
            ProcessTenderOpLogin(pCommand);
            exit;
        end;

        OfflineTenderDeclLoginCommand := pCommand; //Flag :/
        if POSSession.FunctionalityProfile."Only Card Logon" then begin
            OnlyCardLogon := true;
            POSSession.SetValue("LSC POS Tag"::"MU_InfoText1", MSRCardText);
            POSCtrl.ShowPanel(Format("LSC POS Panel Id"::"#LOGIN"))
        end else
            POSView.Login(false, '');
    end;

    local procedure ProcessTenderOpLogin(pCommand: Text)
    var
        DoStartOfDayOp: Boolean;
    begin
        POSSession.SetValue("LSC POS Tag"::TD_OFFLMENU, '');
        DoStartOfDayOp := StartStatusIsEOD();
        POSSession.SetValue("LSC POS Tag"::"SAF-CANCEL-SOD", 'INIT');
        POSSESSION.DeleteValue("LSC POS Tag"::"SHOWSALESMENU");
        POSSESSION.DeleteValue("LSC POS Tag"::"HOSTYPSEQ");
        POSSESSION.DeleteValue("LSC POS Tag"::"SALESTYPE");
        UpdateSessionProfiles();
        if DoStartOfDayOp then begin
            MainRun();
            HandlePanel();
        end else begin
            POSSession.SetValue("LSC POS Tag"::TD_OFFLMENU, '1');
            POSSession.SetValue("LSC POS Tag"::TD_OFFLPANEL, '1');
            POSView.SetOfflineTenderDeclState(pCommand);
            POSSession.SetValue("LSC POS Tag"::"SAF-CANCEL-SOD", '');

            POSCtrl.PopupMenu(Format("LSC POS Menu Id"::"#SAF-OFFLINEMENU"));
        end;
    end;

    local procedure ContainsQRCode(): Boolean
    var
        PrefixFound: boolean;
    begin
        OnBeforeQRCodeProcessCurrInput(CurrInput, PrefixFound);
        if CurrInput.Contains('<mobiledevice>') or
           CurrInput.Contains('<mobilehosploy>') or
           CurrInput.Contains('<CustomerOrder>') or
           CurrInput.Contains('<ScanPayGo>') or
           PrefixFound
        then begin
            POSView.ProcessScannerInput(CurrInput);
            CurrInput := '';
            POSTransactionCu.ClearInput();
            exit(true);
        end;
        if CurrInput.Contains('##HardwareProfile##') then begin
            SetHardwareProfile(CurrInput.Replace('##HardwareProfile##', '').Trim());
            exit(true);
        end;
        exit(false);
    end;

    local procedure ContainsMemberCard(): Boolean
    var
        BarcodeMask: Record "LSC Barcode Mask";
        BarcodeManagement: Codeunit "LSC Barcode Management";
    begin
        if POSTransactionCu.GetFunctionModeEnum() <> "LSC POS Command"::ITEM then
            exit;
        if BarcodeManagement.FindBarcodeMask(CopyStr(CurrInput, 1, 22), BarcodeMask) then
            if BarcodeMask.Type = BarcodeMask.Type::"Member Card" then begin
                POSView.ProcessScannerInput(CurrInput);
                CurrInput := '';
                POSTransactionCu.ClearInput();
                exit(true);
            end;
        exit(false);
    end;

    local procedure AddControl(pProfileID: Code[10]; pPanelID: Code[20]; pColumn: Integer; pRow: Integer; pControlType: Integer)
    var
        Panel: Record "LSC POS Panel";
        PanelControlLine: Record "LSC POS Panel Control Line";
        ControlID: Text;
        NewControl: Boolean;
    begin
        POSCtrl.LogDebug('AddControl: ' + pProfileID + ' ' + pPanelID + ' ' + Format(pColumn) + ' ' + Format(pRow) + ' ' + Format(pControlType));
        if not PanelPositionOccupied(pProfileID, pPanelID, pColumn, pRow)
           and Panel.Get(pProfileID, pPanelID)
        then begin
            ControlID := ShowSelectControlIDDialog(pControlType, pProfileID, NewControl);
            if (pControlType = PanelControlLine."Control Type"::Panel) and (ControlID = pPanelID) then begin
                OposUtil.Beeper;
                exit;
            end;
            if (ControlID <> '') and
              not PanelContainsControl(pProfileID, pPanelID, pControlType, ControlID)
            then begin
                PanelControlLine.Init;
                PanelControlLine."Interface Profile ID" := pProfileID;
                PanelControlLine."Panel Control ID" := pPanelID;
                PanelControlLine."Line No." := GetNextControlLineNo(pProfileID, pPanelID);
                if pRow > 1000 then
                    PanelControlLine."Row (Portrait)" := pRow - 1000
                else
                    PanelControlLine.Row := pRow;
                if pColumn > 1000 then
                    PanelControlLine."Column (Portrait)" := pColumn - 1000
                else
                    PanelControlLine.Column := pColumn;
                PanelControlLine."Control Type" := pControlType;
                PanelControlLine."Control ID" := ControlID;
                PanelControlLine.Insert;
                if NewControl then begin
                    Commit;
                    ControlProperties(pProfileID, pPanelID, pColumn, pRow, ControlID, pProfileID);
                end
                else begin
                    POSCtrl.UploadPosPanelControlsEx(pProfileID, pPanelID, '');
                end
            end
            else
                OposUtil.Beeper;
        end
        else begin
            OposUtil.Beeper;
        end
    end;

    local procedure CutControl(pProfileID: Code[10]; pPanelID: Code[20]; pColumn: Integer; pRow: Integer; pControlID: Code[20])
    var
        PanelControlLine: Record "LSC POS Panel Control Line";
    begin
        POSCtrl.LogDebug('CutControl: ' + pProfileID + ', ' + pPanelID + ', ' + Format(pColumn) + ', ' + Format(pRow) + ', ' + Format(pControlID));
        if GetPanelControlLine(PanelControlLine, pProfileID, pPanelID, pColumn, pRow, pControlID) then begin
            ControlIDClipboard := pControlID;
            ControlTypeClipboard := PanelControlLine."Control Type";
            PanelControlClipboardLine.TransferFields(PanelControlLine);
            PanelControlLine.Delete();
            POSCtrl.RefreshPosPanels(pProfileID, pPanelID);
        end
        else begin
            OposUtil.Beeper;
        end
    end;

    local procedure CopyControl(pProfileID: Code[10]; pPanelID: Code[20]; pColumn: Integer; pRow: Integer; pControlID: Code[20]; pControlProfileID: Code[20])
    var
        PanelControlLine: Record "LSC POS Panel Control Line";
    begin
        POSCtrl.LogDebug('CopyControl: ' + pProfileID + ', ' + pPanelID + ', ' + Format(pColumn) + ', ' + Format(pRow) + ', ' + Format(pControlID));
        if GetPanelControlLine(PanelControlLine, pProfileID, pPanelID, pColumn, pRow, pControlID) then begin
            ControlIDClipboard := pControlID;
            ControlTypeClipboard := PanelControlLine."Control Type";
            ControlProfileClipboard := pControlProfileID;
            PanelControlClipboardLine.TransferFields(PanelControlLine);
        end
        else begin
            ControlIDClipboard := '';
            ControlTypeClipboard := 0;
            ControlProfileClipboard := '';
            OposUtil.Beeper;
        end
    end;

    local procedure PasteControl(pProfileID: Code[10]; pPanelID: Code[20]; pColumn: Integer; pRow: Integer)
    var
        PanelControlLine: Record "LSC POS Panel Control Line";
        R, C : Integer;
        SpanWillCollide: Boolean;
        ProfileIDFilter: Text;
        NewControlID: Code[20];
        DuplQst: Label 'Control already exists on panel, do you want to duplicate existing control?';
    begin
        POSCtrl.LogDebug('PasteControl: ' + pProfileID + ', ' + pPanelID + ', ' + Format(pColumn) + ', ' + Format(pRow));
        if (not PanelPositionOccupied(pProfileID, pPanelID, pColumn, pRow))
          and (ControlIDClipboard <> '')
        then begin
            NewControlID := ControlIDClipboard;
            if PanelContainsControl(pProfileID, pPanelID, ControlTypeClipboard, ControlIDClipboard) then begin
                if POSCtrl.PosConfirm(DuplQst, true) then begin
                    NewControlID := DuplicateControl(ControlProfileClipboard, ControlIDClipboard, ControlTypeClipboard);
                end
                else
                    exit;
            end;

            PanelControlLine.Init;
            PanelControlLine."Interface Profile ID" := pProfileID;
            PanelControlLine."Panel Control ID" := pPanelID;
            PanelControlLine."Line No." := GetNextControlLineNo(pProfileID, pPanelID);
            if pRow > 1000 then begin
                PanelControlLine."Row (Portrait)" := pRow - 1000;
                PanelControlLine.Row := PanelControlClipboardLine.Row;
                PanelControlLine."Row Span" := PanelControlClipboardLine."Row Span";
                PanelControlLine."Row Span (Portrait)" := 1;
            end
            else begin
                PanelControlLine."Row (Portrait)" := PanelControlClipboardLine."Row (Portrait)";
                PanelControlLine."Row Span (Portrait)" := PanelControlClipboardLine."Row Span (Portrait)";
                PanelControlLine.Row := pRow;
            end;
            if pColumn > 1000 then begin
                PanelControlLine."Column (Portrait)" := pColumn - 1000;
                PanelControlLine.Column := PanelControlClipboardLine.Column;
                PanelControlLine."Column Span" := PanelControlClipboardLine."Column Span";
                PanelControlLine."Column Span (Portrait)" := 1;
            end
            else begin
                PanelControlLine."Column (Portrait)" := PanelControlClipboardLine."Column (Portrait)";
                PanelControlLine."Column Span (Portrait)" := PanelControlClipboardLine."Column Span (Portrait)";
                PanelControlLine.Column := pColumn;
            end;

            if (PanelControlClipboardLine."Column Span" > 1) or (PanelControlClipboardLine."Row Span" > 1) then begin
                for R := 1 to PanelControlClipboardLine."Row Span" do
                    for C := 1 to PanelControlClipboardLine."Column Span" do begin
                        if PanelPositionOccupied(pProfileID, pPanelID, pColumn + C - 1, pRow + R - 1) then begin
                            SpanWillCollide := true;
                            break;
                        end;
                    end;
                if not SpanWillCollide then begin
                    PanelControlLine."Row Span" := PanelControlClipboardLine."Row Span";
                    PanelControlLine."Column Span" := PanelControlClipboardLine."Column Span";
                end;
            end;

            PanelControlLine."Control Type" := ControlTypeClipboard;
            PanelControlLine."Control ID" := NewControlID;
            PanelControlLine.Insert;

            ProfileIDFilter := pProfileID;
            if (ControlProfileClipboard <> '') and (ControlProfileClipboard <> ProfileIDFilter) then
                ProfileIDFilter := ProfileIDFilter + '|' + ControlProfileClipboard;

            POSCtrl.UploadPosPanelControlsEx(ProfileIDFilter, pPanelID, '');
        end
        else begin
            OposUtil.Beeper;
        end
    end;

    local procedure DuplicatePanel(ProfileID: Code[10]; OriginalPanelID: Code[20]; NewPanelID: Code[20]): Code[20]
    var
        ControlLines: Record "LSC POS Panel Control Line";
        NewControlLine: Record "LSC POS Panel Control Line";
        NewControlID: Code[20];
    begin
        ControlLines.SetRange("Interface Profile ID", ProfileID);
        ControlLines.SetRange("Panel Control ID", OriginalPanelID);
        if ControlLines.FindSet then
            repeat
                NewControlID := DuplicateControl('', ControlLines."Control ID", ControlLines."Control Type");
                if NewControlID = '' then
                    exit('');
                NewControlLine.Init;
                NewControlLine.TransferFields(ControlLines);
                NewControlLine."Panel Control ID" := NewPanelID;
                NewControlLine."Control ID" := NewControlID;
                NewControlLine.Insert;
            until ControlLines.Next = 0;
        Commit;
        POSCtrl.RefreshPosPanels(ProfileID, NewPanelID);
    end;

    local procedure DuplicateControl(ProfileID: Code[10]; ControlID: Code[20]; ControlType: Integer): Code[20]
    var
        PanelControlLine: Record "LSC POS Panel Control Line";
        ButtonControl: Record "LSC POS ButtonPad Control";
        MenuHeader_l: Record "LSC POS Menu Header";
        RecRef: RecordRef;
        RecID: RecordID;
        NewRecRef: RecordRef;
        FldRef: FieldRef;
        NewControlID: Code[20];
        NewControlIDBase: Code[20];
        NewMenuID: Code[20];
        ControlTable: Integer;
        i: Integer;
    begin
        if ProfileID = '' then begin
            ProfileID := GetControlInterfaceProfile(ControlID, ControlType);
            if ProfileID = '' then
                exit('')
        end;
        ControlTable := GetControlTable(ControlType);
        RecRef.Open(ControlTable);
        Evaluate(RecID, Format(ControlTable) + ':' + ProfileID + ',' + ControlID);
        RecRef.Get(RecID);
        NewRecRef := RecRef.Duplicate;
        FldRef := NewRecRef.Field(2);
        NewControlIDBase := CopyStr(POSSession.GetValue("LSC POS Tag"::Ctrl_Id_Base), 1, 17);
        if NewControlIDBase = '' then
            NewControlIDBase := CopyStr(Format(FldRef.Value), 1, 13) + 'COPY';
        NewControlID := NewControlIDBase;

        i := 0;
        while ControlExists('', ControlType, NewControlID) do begin
            i := i + 1;
            NewControlID := NewControlIDBase + Format(i);
        end;
        FldRef.Value := NewControlID;
        NewRecRef.Insert(true);

        if (ControlType = PanelControlLine."Control Type"::"Button Pad") and
          ButtonControl.Get(ProfileID, NewControlID) and
          GetMenuHeader(ButtonControl."Menu ID", MenuHeader_l)
        then begin
            NewMenuID := DuplicateMenu(MenuHeader_l."Profile ID", MenuHeader_l."Menu ID");
            if NewMenuID <> '' then begin
                ButtonControl."Menu ID" := NewMenuID;
                ButtonControl.Modify;
            end;
        end
        else
            if (ControlType = PanelControlLine."Control Type"::Panel) then begin
                DuplicatePanel(ProfileID, ControlID, NewControlID);
            end;

        exit(NewControlID);
    end;

    local procedure DuplicateMenu(ProfileID: Code[10]; MenuID: Code[20]): Code[20]
    var
        HeaderSource: Record "LSC POS Menu Header";
        HeaderDest: Record "LSC POS Menu Header";
        LineSource: Record "LSC POS Menu Line";
        LineDest: Record "LSC POS Menu Line";
        TranslateSource: Record "LSC POS Button Translation";
        TranslateDest: Record "LSC POS Button Translation";
        ParameterSource: Record "LSC POS Button Parameters";
        ParameterDest: Record "LSC POS Button Parameters";
        NewMenuIDBase: Code[20];
        NewMenuID: Code[20];
        i: Integer;
    begin
        if (MenuID = '') or not HeaderSource.Get(ProfileID, MenuID) then
            exit('');

        NewMenuIDBase := CopyStr(Format(HeaderSource."Menu ID"), 1, 13) + 'COPY';
        NewMenuID := NewMenuIDBase;

        i := 0;
        while HeaderDest.Get(ProfileID, NewMenuID) do begin
            i := i + 1;
            NewMenuID := NewMenuIDBase + Format(i);
        end;

        HeaderDest.Init;
        HeaderDest.TransferFields(HeaderSource);
        HeaderDest."Menu ID" := NewMenuID;
        HeaderDest.Insert(true);

        LineSource.SetRange("Profile ID", ProfileID);
        LineSource.SetRange("Menu ID", MenuID);
        if LineSource.FindSet then
            repeat
                LineDest.Init;
                LineDest.TransferFields(LineSource, true);
                LineDest."Menu ID" := NewMenuID;
                LineDest.Insert(true);

                TranslateSource.Reset;
                TranslateSource.SetRange("Profile ID", ProfileID);
                TranslateSource.SetRange("Menu ID", MenuID);
                TranslateSource.SetRange("Button No.", LineSource."Key No.");
                if TranslateSource.FindSet then
                    repeat
                        TranslateDest.Init;
                        TranslateDest.TransferFields(TranslateSource, true);
                        TranslateDest."Menu ID" := NewMenuID;
                        TranslateDest.Insert(true);
                    until TranslateSource.Next = 0;

                ParameterSource.Reset();
                ParameterSource.SetRange("POS Menu Profile ID", ProfileID);
                ParameterSource.SetRange("Menu ID", MenuID);
                ParameterSource.SetRange("Key No.", LineSource."Key No.");
                if ParameterSource.FindSet then
                    repeat
                        ParameterDest.Init;
                        ParameterDest.TransferFields(TranslateSource, true);
                        ParameterDest."Menu ID" := NewMenuID;
                        ParameterDest.Insert(true);
                    until ParameterSource.Next = 0;
            until LineSource.Next = 0;
        exit(NewMenuID);
    end;

    local procedure RemoveControl(pProfileID: Code[10]; pPanelID: Code[20]; pColumn: Integer; pRow: Integer; pControlID: Code[20])
    var
        PanelControlLine: Record "LSC POS Panel Control Line";
        RemoveCtrlQst: Label 'Do you want to remove control?';
    begin
        POSCtrl.LogDebug('RemoveControl: ' + pProfileID + ', ' + pPanelID + ', ' + Format(pColumn) + ', ' + Format(pRow) + ', ' + Format(pControlID));
        if GetPanelControlLine(PanelControlLine, pProfileID, pPanelID, pColumn, pRow, pControlID) and POSCtrl.PosConfirm(RemoveCtrlQst, true) then begin
            PanelControlLine.Delete();
            POSCtrl.RefreshPosPanels(pProfileID, pPanelID);
        end
    end;

    local procedure ChangeControlSpan(pProfileID: Code[10]; pPanelID: Code[20]; pColumn: Integer; pRow: Integer; pControlID: Code[20]; pSpan: Text; pIsRow: Boolean)
    var
        PanelControlLine: Record "LSC POS Panel Control Line";
        Span, ExistingSpan, AddToSpan : Integer;
        FirstChar: Char;
    begin
        if pSpan = '' then
            exit;
        FirstChar := pSpan[1];
        if FirstChar in ['+', '-'] then begin
            pSpan := CopyStr(pSpan, 2); // '+1' -> '1'
            if pSpan = '' then
                pSpan := '1'; // '+' or '-' -> '1'
            if not Evaluate(Span, pSpan) then
                exit;
            if GetPanelControlLine(PanelControlLine, pProfileID, pPanelID, pColumn, pRow, pControlID) then
                ExistingSpan := pIsRow ? PanelControlLine."Row Span" : PanelControlLine."Column Span";
            if ExistingSpan < 1 then
                ExistingSpan := 1;
            AddToSpan := FirstChar = '+' ? Span : -Span;
            Span := ExistingSpan + AddToSpan;
            if Span < 1 then
                Span := 1;
            if Span = ExistingSpan then
                exit; // no change
        end else
            if not Evaluate(Span, pSpan) then
                exit;
        if pIsRow then
            ChangeControlRowSpan(pProfileID, pPanelID, pColumn, pRow, pControlID, Span)
        else
            ChangeControlColumnSpan(pProfileID, pPanelID, pColumn, pRow, pControlID, Span);
    end;

    local procedure ChangeControlRowSpan(pProfileID: Code[10]; pPanelID: Code[20]; pColumn: Integer; pRow: Integer; pControlID: Code[20]; pSpan: Integer)
    var
        PanelControlLine: Record "LSC POS Panel Control Line";
    begin
        if GetPanelControlLine(PanelControlLine, pProfileID, pPanelID, pColumn, pRow, pControlID) then begin
            if pRow > 1000 then
                PanelControlLine."Row Span (Portrait)" := pSpan
            else
                PanelControlLine."Row Span" := pSpan;
            PanelControlLine.Modify;
            POSCtrl.UploadPosPanelControlsEx(pProfileID, pPanelID, '');
        end
    end;

    local procedure ChangeControlColumnSpan(pProfileID: Code[10]; pPanelID: Code[20]; pColumn: Integer; pRow: Integer; pControlID: Code[20]; pSpan: Integer)
    var
        PanelControlLine: Record "LSC POS Panel Control Line";
    begin
        if GetPanelControlLine(PanelControlLine, pProfileID, pPanelID, pColumn, pRow, pControlID) then begin
            if pColumn > 1000 then
                PanelControlLine."Column Span (Portrait)" := pSpan
            else
                PanelControlLine."Column Span" := pSpan;
            PanelControlLine.Modify;
            POSCtrl.UploadPosPanelControlsEx(pProfileID, pPanelID, '');
        end
    end;

    local procedure ControlProperties(pProfileID: Code[10]; pPanelID: Code[20]; pColumn: Integer; pRow: Integer; pControlID: Code[20]; pControlProfileID: Code[20])
    var
        PanelControlLine: Record "LSC POS Panel Control Line";
        RecRef: RecordRef;
        RecID: RecordID;
        VariantVar: Variant;
        ControlTable: Integer;
        ControlCard: Integer;
    begin
        if GetPanelControlLine(PanelControlLine, pProfileID, pPanelID, pColumn, pRow, pControlID) then begin
            ControlTable := GetControlTable(PanelControlLine."Control Type");
            ControlCard := GetControlCard(PanelControlLine."Control Type");

            Evaluate(RecID, Format(ControlTable) + ':' + pControlProfileID + ',' + pControlID);
            RecRef.Open(ControlTable);
            if RecRef.Get(RecID) then begin
                VariantVar := RecRef;
                PAGE.RunModal(ControlCard, VariantVar);
                POSCtrl.RefreshPosPanels(pProfileID + '|' + pControlProfileID, pPanelID);
                if PanelControlLine."Control Type" = PanelControlLine."Control Type"::Browser then
                    CONTROLLIB.RefreshControl(Enum::"LSC POS Control Type"::Browser, PanelControlLine."Control ID", true);
            end
        end
        else begin
            OposUtil.Beeper;
        end
    end;

    local procedure GetPanelControlLine(var pPanelControl: Record "LSC POS Panel Control Line"; pProfileID: Code[10]; pPanelID: Code[20]; pColumn: Integer; pRow: Integer; pControlID: Code[20]): Boolean
    var
        PortraitMode: Boolean;
    begin
        Clear(pPanelControl);

        if (pColumn = -1) or (pRow = -1) then
            exit(false);

        //OFFSET for Portrait Column/Row
        if pColumn > 1000 then begin
            pColumn -= 1000;
            pRow -= 1000;
            PortraitMode := true;
        end;

        pPanelControl.SetRange("Interface Profile ID", pProfileID);
        pPanelControl.SetRange("Panel Control ID", pPanelID);
        pPanelControl.SetRange("Control ID", pControlID);

        if PortraitMode then begin
            if (pColumn = 1) then
                pPanelControl.SetRange("Column (Portrait)", 0, 1)
            else
                pPanelControl.SetRange("Column (Portrait)", pColumn);

            if (pRow = 1) then
                pPanelControl.SetRange("Row (Portrait)", 0, 1)
            else
                pPanelControl.SetRange("Row (Portrait)", pRow);
        end else begin
            if (pColumn = 1) then
                pPanelControl.SetRange(Column, 0, 1)
            else
                pPanelControl.SetRange(Column, pColumn);

            if (pRow = 1) then
                pPanelControl.SetRange(Row, 0, 1)
            else
                pPanelControl.SetRange(Row, pRow);
        end;

        exit(pPanelControl.FindFirst);
    end;

    local procedure PanelPositionOccupied(pProfileID: Code[10]; pPanelID: Code[20]; pColumn: Integer; pRow: Integer): Boolean
    var
        ControlLine: Record "LSC POS Panel Control Line";
        PortraitMode: Boolean;
    begin
        if (pColumn = -1) or (pRow = -1) then
            exit(true);

        //OFFSET for Portrait Column/Row
        if pColumn > 1000 then begin
            pColumn -= 1000;
            pRow -= 1000;
            PortraitMode := true;
        end;

        ControlLine.SetRange("Interface Profile ID", pProfileID);
        ControlLine.SetRange("Panel Control ID", pPanelID);
        if PortraitMode then begin
            ControlLine.SetRange("Column (Portrait)", pColumn);
            ControlLine.SetRange("Row (Portrait)", pRow);
        end
        else begin
            ControlLine.SetRange(Column, pColumn);
            ControlLine.SetRange(Row, pRow);
        end;
        exit(not ControlLine.IsEmpty());
    end;

    local procedure PanelContainsControl(pProfileID: Code[10]; pPanelID: Code[20]; pControlType: Integer; pControlID: Code[20]): Boolean
    var
        ControlLine: Record "LSC POS Panel Control Line";
    begin
        ControlLine.SetRange("Interface Profile ID", pProfileID);
        ControlLine.SetRange("Panel Control ID", pPanelID);
        ControlLine.SetRange("Control ID", pControlID);
        ControlLine.SetRange("Control Type", pControlType);
        exit(not ControlLine.IsEmpty());
    end;

    local procedure ShowSelectControlIDDialog(ControlType: Integer; PanelProfileID: Code[20]; var New: Boolean): Text
    var
        RecRef: RecordRef;
        RecRef_l: RecordRef;
        FldRef: FieldRef;
        Options: Text;
        ControlID: Text;
        ProfileID: Text;
        Result: Integer;
        Counter: Integer;
        ControlTable: Integer;
        Text119: Label 'New Control';
    begin
        New := false;
        ControlTable := GetControlTable(ControlType);
        if ControlTable = 0 then
            exit('');
        RecRef.Open(ControlTable);
        RecRef_l.Open(ControlTable, true);

        RecRef_l.Init;
        FldRef := RecRef_l.Field(2);
        FldRef.Value := Text119;
        RecRef_l.Insert;

        FldRef := RecRef.Field(1);
        FldRef.SetRange(POSSession.InterfaceProfileID);
        CopyControlIDIfNotExists(RecRef, RecRef_l);

        if POSSession.Store."Interface Profile" <> '' then begin
            Clear(RecRef);
            RecRef.Open(ControlTable);
            FldRef := RecRef.Field(1);
            FldRef.SetRange(POSSession.Store."Interface Profile");
            CopyControlIDIfNotExists(RecRef, RecRef_l);
        end;

        Clear(RecRef);
        RecRef.Open(ControlTable);
        FldRef := RecRef.Field(1);
        FldRef.SetRange(Format("LSC POS Profile ID"::DefaultInterface));
        CopyControlIDIfNotExists(RecRef, RecRef_l);

        FldRef := RecRef_l.Field(2);
        FldRef.SetRange;

        Options := '';
        if RecRef_l.FindSet then
            repeat
                FldRef := RecRef_l.Field(1);
                ProfileID := FldRef.Value;
                FldRef := RecRef_l.Field(2);
                ControlID := FldRef.Value;

                if Options <> '' then begin
                    Options := Options + ',';
                end;
                if ProfileID <> '' then
                    Options := Options + ControlID + ' (' + ProfileID + ')'
                else
                    Options := Options + ControlID
            until RecRef_l.Next = 0;

        // Show available options
        Result := POSCtrl.SelectOption('', Options, 0, true);

        if Result = 1 then begin // New control
            New := true;
            exit(NewControl(PanelProfileID, ControlType));
        end;

        // Get ControlID from selected index.
        Counter := 0;
        if (Result > 1) and RecRef_l.FindSet then
            repeat
                Counter := Counter + 1;
                if Counter = Result then begin
                    FldRef := RecRef_l.Field(2);
                    exit(FldRef.Value);
                end
            until RecRef_l.Next = 0;

        exit('');
    end;

    local procedure CopyControlIDIfNotExists(var fromRecRef: RecordRef; var toRecRef: RecordRef)
    var
        FieldRefTmp: FieldRef;
        FldRef: FieldRef;
        ProfileID: Text;
        ControlID: Text;
    begin
        if fromRecRef.FindSet then
            repeat
                FldRef := fromRecRef.Field(1);
                ProfileID := FldRef.Value;

                FldRef := fromRecRef.Field(2);
                ControlID := FldRef.Value;

                FieldRefTmp := toRecRef.Field(2);
                FieldRefTmp.SetRange(ControlID);

                if toRecRef.IsEmpty then begin
                    toRecRef.Init;

                    FieldRefTmp := toRecRef.Field(1);
                    FieldRefTmp.Value := ProfileID;

                    FieldRefTmp := toRecRef.Field(2);
                    FieldRefTmp.Value := ControlID;

                    toRecRef.Insert;
                end
            until fromRecRef.Next = 0;
    end;

    local procedure ControlExists(ProfileID: Code[20]; ControlType: Integer; ControlID: Code[20]): Boolean
    var
        RecRef: RecordRef;
        RecID: RecordID;
        FldRef: FieldRef;
        ControlTable: Integer;
    begin
        ControlTable := GetControlTable(ControlType);
        RecRef.Open(ControlTable);
        if ProfileID <> '' then begin
            Evaluate(RecID, Format(ControlTable) + ':' + ProfileID + ',' + ControlID);
            exit(RecRef.Get(RecID));
        end
        else begin
            FldRef := RecRef.Field(2);
            FldRef.SetRange(ControlID);
            exit(RecRef.FindFirst);
        end
    end;

    local procedure NewControl(ProfileID: Code[20]; ControlType: Integer): Text
    var
        RecRef: RecordRef;
        FldRef: FieldRef;
        NewControlID, NewControlIDBase : Text;
        ControlTable: Integer;
        i: Integer;
    begin
        ControlTable := GetControlTable(ControlType);
        RecRef.Open(ControlTable);
        RecRef.Init;
        FldRef := RecRef.Field(1);
        FldRef.Value := ProfileID;
        NewControlIDBase := CopyStr(POSSession.GetValue("LSC POS Tag"::Ctrl_Id_Base), 1, 17);
        if NewControlIDBase = '' then
            NewControlIDBase := 'NEWCONTROL';
        NewControlID := NewControlIDBase;
        i := 0;
        while ControlExists('', ControlType, NewControlID) do begin
            i := i + 1;
            NewControlID := NewControlIDBase + Format(i);
        end;
        FldRef := RecRef.Field(2);
        FldRef.Value := NewControlID;
        RecRef.Insert;
        exit(NewControlID);
    end;

    local procedure GetMenuHeader(MenuID: Code[20]; var MenuHeader: Record "LSC POS Menu Header"): Boolean
    begin
        exit(true in [
            MenuHeader.Get(POSSession.InterfaceProfileID, MenuID) or
            MenuHeader.Get(POSSession.Store."Interface Profile", MenuID) or
            MenuHeader.Get(Format("LSC POS Profile ID"::DefaultInterface), MenuID)
        ]);
    end;

    local procedure GetControlInterfaceProfile(ControlID: Code[20]; ControlType: Integer): Code[10]
    var
        RecRef: RecordRef;
        RecID: RecordID;
        ControlTable: Integer;
    begin
        ControlTable := GetControlTable(ControlType);
        RecRef.Open(ControlTable);
        Evaluate(RecID, Format(ControlTable) + ':' + POSSession.InterfaceProfileID + ',' + ControlID);
        if RecRef.Get(RecID) then
            exit(POSSession.InterfaceProfileID);

        Evaluate(RecID, Format(ControlTable) + ':' + POSSession.Store."Interface Profile" + ',' + ControlID);
        if RecRef.Get(RecID) then
            exit(POSSession.Store."Interface Profile");

        Evaluate(RecID, Format(ControlTable) + ':' + Format("LSC POS Profile ID"::DefaultInterface) + ',' + ControlID);
        if RecRef.Get(RecID) then
            exit(Format("LSC POS Profile ID"::DefaultInterface))
    end;

    local procedure GetControlTable(ControlOption: Integer): Integer
    var
        ControlLines: Record "LSC POS Panel Control Line";
    begin
        case ControlOption of
            ControlLines."Control Type"::"Button Pad":
                exit(Database::"LSC POS ButtonPad Control");
            ControlLines."Control Type"::Input:
                exit(Database::"LSC POS Input Control");
            ControlLines."Control Type"::Panel:
                exit(Database::"LSC POS Panel");
            ControlLines."Control Type"::"Data Grid":
                exit(Database::"LSC POS Data Grid Control");
            ControlLines."Control Type"::"Record Zoom":
                exit(Database::"LSC POS Record Zoom Control");
            ControlLines."Control Type"::Browser:
                exit(Database::"LSC POS Browser Control");
            ControlLines."Control Type"::Media:
                exit(Database::"LSC POS Media Control");
        end;

        exit(0);
    end;

    local procedure GetControlCard(ControlOption: Integer): Integer
    var
        ControlLines: Record "LSC POS Panel Control Line";
    begin
        case ControlOption of
            ControlLines."Control Type"::"Button Pad":
                exit(Page::"LSC POS ButtonPad Control Card");
            ControlLines."Control Type"::Input:
                exit(Page::"LSC POS Input Control Card");
            ControlLines."Control Type"::Panel:
                exit(Page::"LSC POS Panel Card");
            ControlLines."Control Type"::"Data Grid":
                exit(Page::"LSC POS Data Grid Control Card");
            ControlLines."Control Type"::"Record Zoom":
                exit(Page::"LSC POS Record Zoom Ctrl Card");
            ControlLines."Control Type"::Browser:
                exit(Page::"LSC POS Browser Control Card");
            ControlLines."Control Type"::Media:
                exit(Page::"LSC POS Media Control Card");
        end;

        exit(0);
    end;

    local procedure GetNextControlLineNo(pProfileID: Code[10]; pPanelID: Code[20]): Integer
    var
        PanelControlLine: Record "LSC POS Panel Control Line";
    begin
        PanelControlLine.SetRange("Interface Profile ID", pProfileID);
        PanelControlLine.SetRange("Panel Control ID", pPanelID);
        if PanelControlLine.FindLast then begin
            exit(PanelControlLine."Line No." + 1);
        end;
        exit(0);
    end;

    local procedure OpenDistributionLocation(TerminalNo: Code[10])
    var
        DistributionLocation: Record "LSC Distribution Location";
    begin
        if TerminalNo = '' then begin
            TerminalNo := POSSession.TerminalNo;
            if TerminalNo = '' then
                exit;
        end;
        if not DistributionLocation.Get(TerminalNo) then begin
            DistributionLocation.Init;
            DistributionLocation.Code := TerminalNo;
            DistributionLocation.Insert(true);
            Commit;
        end;
        if DistributionLocation.Get(TerminalNo) then begin
            PAGE.RunModal(Page::"LSC Distribution Location Card", DistributionLocation);
        end;
        POSCtrl.SetWsInfo();
    end;

    local procedure RunAction(pCodeunitNo: Integer; pPosControlAction: Integer)
    var
        lPosMenuLine: Record "LSC POS Menu Line";
    begin
        lPosMenuLine."Pos Event Type" := -1 * pPosControlAction; //SET TO NEGATIVE VALUE (-1 = Logoff, -2 = Logon, -3 = SetStaff)
        CODEUNIT.Run(pCodeunitNo, lPosMenuLine);
    end;

    local procedure CheckComputerName(): Boolean
    var
        TerminalRec: Record "LSC POS Terminal";
        ActiveSession: Record "Active Session";
        ComputerName: Text;
        TerminalComputerName: Text;
        TerminalCanNotRunMsg: Label 'Terminal %1 cannot run on this computer (%2)\It''s configured to run only on computer %3';
        KeyLockPermissionGroupMissing: Label 'Warning: This POS Terminal does not have a [%1] defined.';
    begin
        if not TerminalRec.Get(POSSession.TerminalNo) then
            exit(true);

        if POSSession.HardwareProfile().DeviceIsActive("LSC Hardware Profile Devices"::Authentication) then
            if TerminalRec."KeyLock Staff Perm. Group" = '' then
                POSCtrl.PosMessage(StrSubstNo(KeyLockPermissionGroupMissing, TerminalRec.FieldName(TerminalRec."KeyLock Staff Perm. Group")));

        if TerminalRec."Computer Name" = '' then
            exit(true);

        if not ActiveSession.Get(ServiceInstanceId, SessionId) then
            exit(true);
        if ActiveSession."Client Computer Name" = '' then
            exit(true);

        TerminalComputerName := UpperCase(TerminalRec."Computer Name");
        ComputerName := UpperCase(ActiveSession."Client Computer Name");
        if ComputerName <> TerminalComputerName then begin
            POSCtrl.PosMessage(StrSubstNo(TerminalCanNotRunMsg, POSSession.TerminalNo, ComputerName, TerminalComputerName));
            exit(false);
        end;

        exit(true);
    end;

    local procedure ProcessPosLookupRequest(pLookupID: Code[20])
    var
        LookupRec: Record "LSC POS Lookup";
        PosTransLine: Record "LSC POS Trans. Line";
        DummyFlowFieldBuffer: Record "LSC FlowField Buffer" temporary;
        DummyRecRef: RecordRef;
    begin
        if not POSSession.GetPosLookupRec(pLookupID, LookupRec) then
            exit;

        POSLines.GetCurrentLine(PosTransLine);
        POSCtrl.Lookup(LookupRec, '##ASSIST', PosTransLine, POSSession.MgrKey, POSView.GetCustomerNo, DummyRecRef, DummyFlowFieldBuffer);
    end;

    procedure UpdateSelectedJournalLine()
    begin
        UpdateSelectedJournalLine(true);
    end;

    procedure UpdateSelectedJournalLine(updateTransactionNewLine: Boolean)
    begin
        POSLines.UpdateSelectedJournalLine(POSCtrl.GetDataGridRowIndex(Format("LSC POS Data Grid Id"::"#JOURNALGRID")), 1);
        if updateTransactionNewLine then begin //dont want to do this after processing command
            POSView.SetCurrentLineNo(POSLines.GetCurrentLineNo());
            UpdateLineInfo();
        end;
    end;

    local procedure LoadJournalLines(force: Boolean): Boolean
    var
        LSDataSetRef: Codeunit "LSC DataSet";
    begin
        if not force then
            if not POSLines.IsModified() then
                exit(false);

        if LASTRECEIPT = '' then
            exit(false);

        POSLines.LoadJournalLines(LASTRECEIPT, LSDataSetRef, 1, CurrJournalPage);
        POSCtrl.AddGridData(Format("LSC POS Data Grid Id"::"#JOURNALGRID"), LSDataSetRef);
        if PosSession.Terminal."Dual Disp. Enabled" then begin
            if DualDisplayJournalActive then begin
                POSLines.LoadJournalLines(LASTRECEIPT, LSDataSetRef, 2, CurrJournalPage);
            end;
            if DDCONTROLLIB.GetInitialized() then
                DDCONTROLLIB.AddGridDataSet(Format("LSC POS Data Grid Id"::"#JOURNALGRID"), LSDataSetRef.GetId(),
                    LSDataSetRef.ToJSONObject(false), LSDataSetRef.GetStartPageNo);
        end;

        UpdateBasketSizePosTag();

        exit(true);
    end;

    local procedure LoadJournalLinesByRequest(fromPage: Integer; pageCount: Integer; pageSize: Integer; sortColumn: Integer; sortAscending: Boolean; filterString: Text)
    var
        LSDataSetRef: Codeunit "LSC DataSet";
    begin
        POSLines.DataRequest(fromPage, pageCount, pageSize, sortColumn, sortAscending, filterString, 1, LSDataSetRef);
        POSCtrl.AddGridData(Format("LSC POS Data Grid Id"::"#JOURNALGRID"), LSDataSetRef);
        if DualDisplayJournalActive then begin
            POSLines.LoadJournalLines(LASTRECEIPT, LSDataSetRef, 2, CurrJournalPage);
        end;
    end;

    local procedure ProcessHardwareInfo(var pMenuLine: Record "LSC POS Menu Line")
    var
        HardwareProfileDevice: Record "LSC POS Hardware Profile Dev.";
        RecId_l: RecordID;
    begin
        case pMenuLine.Parameter of
            '':
                begin
                    pMenuLine.Parameter := '#HARDWAREINFO';
                    ShowPanelPressed(pMenuLine, true);
                end;
            'POSCONTEXT':
                begin
                    POSCtrl.InitDataGridControl(Format("LSC POS Data Grid Id"::"#HARDWAREINFO"), 'CONTEXT');
                end;
            'EDIT_DEVICE':
                begin
                    POSCtrl.GetDataGridRecordID(Format("LSC POS Data Grid Id"::"#HARDWAREINFO"), RecId_l);
                    if HardwareProfileDevice.Get(RecId_l) then begin
                        if HardwareProfileDevice."Device Type" = HardwareProfileDevice."Device Type"::PRINTER then begin
                        end;
                    end;
                end;
            else begin
                POSSession.SetValue("LSC POS Tag"::"CURRDEVICETYPE", pMenuLine.Parameter); //PRINTER,DRAWER,DISPLAY,MSR,SCANNER,SCALE
                POSCtrl.InitDataGridControl(Format("LSC POS Data Grid Id"::"#HARDWAREINFO"), '#HARDWAREINFO');
                POSCtrl.GoToRow(Format("LSC POS Data Grid Id"::"#HARDWAREINFO"), 0);
            end;
        end;
    end;

    internal procedure SetRefreshMenuFlags()
    begin
        PosView.SetRefreshMenuFlag(0);
        PosView.SetRefreshMenuFlag(1);
        PosView.SetRefreshMenuFlag(2);
        PosView.SetRefreshMenuFlag(3);
    end;

    local procedure TrackPOSCommandsUsage(POSMenuLine_p: Record "LSC POS Menu Line"): Boolean
    var
        POSCommand: Record "LSC POS Command";
    begin
        if POSCommand.Get(POSMenuLine_p.Command) then
            if POSCommand."Outbound Code" <> '' then
                exit(true);

        exit(POSMenuLine_p."Track Usage in POS Log");
    end;

    local procedure UpdateMenuAreas()
    begin
        if PosView.GetRefreshMenuFlag(0) then
            LoadMenu(PosView.GetCurrMenu(0));
        if PosView.GetRefreshMenuFlag(1) then
            LoadAddMenu(1, ServiceLocator.PosSessionMenu.GetAdd1Menu());
        if PosView.GetRefreshMenuFlag(2) then
            LoadAddMenu(2, ServiceLocator.PosSessionMenu.GetAdd2Menu());
        if PosView.GetRefreshMenuFlag(3) then
            LoadAddMenu(3, ServiceLocator.PosSessionMenu.GetAdd3Menu());
    end;

    local procedure UpdateBasketSizePosTag()
    var
        TransLines: Record "LSC POS Trans. Line";
    begin
        TransLines.SetCurrentKey("Receipt No.", "Entry Type", Number, "Variant Code", "Unit of Measure", "Entry Status");
        TransLines.SetRange("Receipt No.", LASTRECEIPT);
        TransLines.SetRange("Entry Status", TransLines."Entry Status"::" ");
        TransLines.SetRange("Entry Type", TransLines."Entry Type"::Item);
        TransLines.CalcSums(Quantity);
        POSSession.SetValue("LSC POS Tag"::"BasketSize", Format(Round(TransLines.Quantity, 1, '>')));
    end;

    local procedure RunCommandFromColumn(ActivePanel: Record "LSC POS Panel"; PosMenuLine: Record "LSC POS Menu Line"): Boolean
    var
        POSDataTable: Record "LSC POS Data Table";
        ActiveGridID, DataTableID : Text;
    begin
        ActiveGridID := POSCtrl.ActiveDataGrid;
        if ActiveGridID = Format("LSC POS Data Grid Id"::"#JOURNALGRID") then begin
            if not POSDataTable.Get(POSSession.InterfaceProfile."Journal Data Table ID") then
                exit(false);
        end else begin
            DataTableID := POSCtrl.GetGridDataTableID(ActiveGridID); // get from control lib.
            if not POSDataTable.Get(DataTableID) then
                if not POSSession.GetDataTableInDataGrid(ActivePanel, POSCtrl.ActiveDataGrid, POSDataTable) then // get from DB
                    exit(false);
        end;
        POSDataTable.CalcFields("Columns with Commands");
        if not POSDataTable."Columns with Commands" then
            exit(false);
        if not POSDataTable.GetCommandAndPOSMenuInColumn(POSEvent.IntData2 + 1, PosMenuLine.Command, PosMenuLine.Parameter) then
            exit(false);
        PosCtrl.PostEvent('RUNCOMMAND', PosMenuLine.Command, PosMenuLine.Parameter, '');
        exit(true);
    end;

    internal procedure UpdatePosContext()
    begin
        if not POSCtrl.PosIsActive() then
            exit;
        OnBeforeContextUpdate();
        // TODO: these shouldn't need update for each cycle, reverse the handling instead
        POSTransactionCu.UpdateContext();
    end;

    internal procedure SetHardwareProfile(ProfileID: Text)
    var
        POSView: Codeunit "LSC POS View";
    begin
        if StrLen(ProfileID) > 10 then
            ProfileID := CopyStr(ProfileID, 1, 10); // HardwareProfile.ID is Code[10]
        POSSession.SetHardwareProfile(ProfileID);
        POSCtrl.RefreshHardwareProfile(ProfileID);
        OposUtil.InitOpos();
        POSView.SetHardwareProfile(ProfileID);
    end;

    internal procedure SetEFTDeviceRole(EFTDeviceRole: Text)
    var
        HwProfileDevice: Record "LSC POS Hardware Profile Dev.";
        NoDeviceRoleErr: Label 'No EFT Device with Role %1 found in Hardware Profile %2';
    begin
        HwProfileDevice.SetRange("Profile ID", POSSession.HardwareProfileID);
        HwProfileDevice.SetRange("Device Type", HwProfileDevice."Device Type"::EFT);
        HwProfileDevice.SetRange("Device Role", EFTDeviceRole);
        if not HwProfileDevice.FindFirst then begin
            POSView.ErrorBeep(StrSubstNo(NoDeviceRoleErr, EFTDeviceRole, POSSession.HardwareProfileID));
            exit;
        end;

        POSSession.SetValue("LSC POS Tag"::"EFTDeviceRole", EFTDeviceRole);
    end;

    [Obsolete('Use SetHardwareProfile instead', '26.0')]
    procedure SetHardwareProfileFromQRCodeData(QRCodeData: Text)
    begin
        SetHardwareProfile(QRCodeData.Replace('##HardwareProfile##', '').Trim());
    end;

    local procedure CreateTerminalMenuLines(var pMenuLineTemp: Record "LSC POS Menu Line" temporary; pProfileID: Text; pMenuID: Text): Integer
    var
        Terminals: Record "LSC POS Terminal";
        i: Integer;
    begin
        if not pMenuLineTemp.IsTemporary then begin
            Message('Expecting a Temporary Record in CreateTerminalMenuLines');
            exit;
        end;

        i := 1;
        if Terminals.FindSet then
            repeat
                pMenuLineTemp.Init;
                pMenuLineTemp."Profile ID" := pProfileID;
                pMenuLineTemp."Menu ID" := pMenuID;
                pMenuLineTemp."Key No." := i;
                pMenuLineTemp.Description := Terminals."No.";
                pMenuLineTemp.Command := Format("LSC POS Command"::"#SELECT_TERMINAL");
                pMenuLineTemp.Parameter := Terminals."No.";

                pMenuLineTemp.Insert;
                i += 1;
            until Terminals.Next = 0;

        exit(i - 1);
    end;

    local procedure CreateTerminalMenuHeader(var pMenuHeaderTemp: Record "LSC POS Menu Header" temporary; pProfileID: Text; pMenuID: Text; pRows: Integer; pColumns: Integer; pPages: Integer): Integer
    begin
        if not pMenuHeaderTemp.IsTemporary then begin
            Message('Expecting a Temporary Record in CreateTerminalMenuHeader');
            exit;
        end;

        pMenuHeaderTemp.Init;
        pMenuHeaderTemp."Profile ID" := pProfileID;
        pMenuHeaderTemp.Description := Format(GlobalLanguage);
        pMenuHeaderTemp."Menu ID" := pMenuID;
        pMenuHeaderTemp.Rows := pRows;
        pMenuHeaderTemp.Columns := pColumns;
        pMenuHeaderTemp.Pages := pPages;
        pMenuHeaderTemp."Popup Height" := 500;
        pMenuHeaderTemp."Popup Width" := 700;
        pMenuHeaderTemp."Paging Orientation" := pMenuHeaderTemp."Paging Orientation"::Vertical;
        pMenuHeaderTemp."Button Spacing" := 2;
        pMenuHeaderTemp.Insert;
    end;

    local procedure LoadPOSTerminalsMenu()
    var
        MenuHeaderTemp: Record "LSC POS Menu Header" temporary;
        MenuLinesTemp: Record "LSC POS Menu Line" temporary;
        _MENUID: Text;
        _ROWS: Integer;
        _COLUMNS: Integer;
        Counter: Integer;
    begin
        _MENUID := '###POSTERMINALS';
        _ROWS := 12;
        _COLUMNS := 10;

        Counter := CreateTerminalMenuLines(MenuLinesTemp, Format("LSC POS Profile ID"::DefaultMenu), _MENUID);
        CreateTerminalMenuHeader(MenuHeaderTemp, Format("LSC POS Profile ID"::DefaultMenu), _MENUID, _ROWS, _COLUMNS, Round(Counter / (_COLUMNS * _ROWS), 1, '>'));
        POSCtrl.UploadMenuHeaderRec(MenuHeaderTemp, '', '');
        POSCtrl.UploadMenuLineRec(MenuLinesTemp, '', '', '');
        POSCtrl.PopupMenu(_MENUID);
    end;

    local procedure ProcessPOSTerminalSelect(pTerminalNo: Text)
    var
        PosTerminal: Record "LSC POS Terminal";
    begin
        PosTerminal.Get(pTerminalNo);
        RetailUserStoreNo := PosTerminal."Store No.";
        RetailUserTerminalNo := PosTerminal."No.";
        LoadPos();
        POSCtrl.ShowPanel(Format("LSC POS Panel Id"::"#OFFLINE"));
        DisplayPosClosedText();
    end;

    local procedure RefundScannedItem(InputData: Text)
    var
        POSMenuLine: Record "LSC POS Menu Line";
        RefundItemNo: Text;
        RefundItemPosition: Integer;
        WildCard: Integer;
        Int: Integer;
        CurrentChar: Char;
    begin
        RefundItemNo := InputData;
        WildCard := 167;

        for Int := 1 to StrLen(InputData) do begin
            CurrentChar := RefundItemNo[Int];
            if (CurrentChar = WildCard) and (RefundItemPosition = 0) then
                RefundItemPosition := Int;
        end;

        if RefundItemPosition <= 1 then
            exit;

        RefundItemNo := CopyStr(RefundItemNo, 1, RefundItemPosition - 1);
        POSMenuLine.Parameter := RefundItemNo;
        POSMenuLine.Command := Format(Enum::"LSC POS Command"::REFUND_ITEM);
        POSTransactionCu.RunCommand(POSMenuLine);
    end;

    local procedure CheckActiveLicense(var ErrorText: Text): Boolean
    var
        LicMan: Codeunit "LSC License Manager Usage Log";
    begin
        LicMan.CheckLicenseKey(PosSession.Terminal.RecordId, ErrorText);
        exit(ErrorText = '');
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeContextUpdate()
    begin
    end;

    [Obsolete('Never triggered', '26.0')]
    [IntegrationEvent(false, false)]
    local procedure OnContextUpdateReady(ModifiedContextJson: Text)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnPOSCommand(var ActivePanel: Record "LSC POS Panel"; var PosMenuLine: Record "LSC POS Menu Line")
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnPOSEvent(var PosEvent: Codeunit "LSC POS Event"; var SuppressEvent: Boolean; var RunPostCommandProcessing: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnDualDisplayPOSEvent(var PosEvent: Codeunit "LSC POS Event"; var SuppressEvent: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAutoLogoffPOSEvent(var PosEvent: Codeunit "LSC POS Event"; NewTransaction: Boolean; AllowAutoLogoffInSalesMode: Boolean; PanelControlCodeunit: integer; var SuppressEvent: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeProcessModalResult(panelID: Text; resultOK: Boolean; payload: Text; var processed: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnModalPanelResult(panelID: Text; resultOK: Boolean; payload: Text; var processed: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnNumpadResult(payload: Text; inputValue: Text; resultOK: Boolean; var processed: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnKeyboardResult(payload: Text; inputValue: Text; resultOK: Boolean; var processed: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnLookupResult(LookupID: Text; FilterText: Text; resultOK: Boolean; var processed: Boolean; var LookupAssistValue: Text; panelID: Text)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnCalendarResult(payload: Text; inputValue: DateTime; resultOK: Boolean; var processed: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnLoadMenu(var MenuID: Code[20]; var Handled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeRunPos(StaffID: code[20]; PosTerminal: code[10]; var Handled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeLogoffPressed(var CancelPanelClosing: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeClosePOSPanelInLogoffPressed(ActivePanelID: text; StartupControllerCodeunit: integer; var CancelClosing: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeClosePOSPanelInPostCommandProcessingWhenCloseFlagSet(StartupControllerCodeunit: integer; var CancelClosing: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterHandlePanel(SalesPanelID: code[20])
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeUpdateLineInfo(var LineRec: Record "LSC POS trans. line"; var handled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterUpdateLineInfo(var LineRec: Record "LSC POS Trans. Line")
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnButtonPressed(var POSMenuLine: Record "LSC POS Menu Line"; var handled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeSelectDefaultMenu(var SelectedMenu: Code[20])
    begin
    end;

    [IntegrationEvent(false, false)]
    internal procedure OnBeforeClosePos(var shouldSkipClosing: Boolean; var shouldSkipConfirm: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeProcessEvent(var PosEvent: Codeunit "LSC POS Event"; var IsHandled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnLoginPanelIDOnProcessModalResult(var Manager: Boolean; var SetNewStaffID: text; var StaffID: Text; var Password: Text; var Workshift: Text)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeStartStatusIsEOD(var IsHandled: Boolean; var ReturnValue: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeLoadAddMenu(MenuNo: Integer; var SelectMenu: Code[20]; var ButtonPadID: Code[20]; var IsHandled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeQRCodeProcessCurrInput(CurrInput: Text; var PrefixFound: Boolean);
    begin
    end;

    [IntegrationEvent(true, false)]
    local procedure OnAfterNotGetInitialized()
    begin
    end;
}

