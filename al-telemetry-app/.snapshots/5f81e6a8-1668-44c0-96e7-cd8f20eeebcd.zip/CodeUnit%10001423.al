codeunit 10001423 "LSC Posting Exception Utility"
{
    var
        PostingException_g: Record "LSC Posting Exception" temporary;
        PostExStoreGroup_g: Code[20];
        NextEntryNo_g: Integer;

    internal procedure InitPostException()
    begin
        PostingException_g.Reset();
        PostingException_g.DeleteAll();
    end;

    internal procedure FindPostExStoreGroup(StoreNo_p: Code[20]; var StoreGroup_p: Code[20]): Boolean
    var
        StoreGroupSetup: Record "LSC Store Group Setup";
        PostingException: Record "LSC Posting Exception";
    begin
        StoreGroup_p := '';
        StoreGroupSetup.Reset();
        StoreGroupSetup.Ascending(true);
        StoreGroupSetup.SetRange("Store Code", StoreNo_p);
        if StoreGroupSetup.FindSet() then
            repeat
                PostingException.SetRange("Store Group", StoreGroupSetup."Store Group");
                if not PostingException.IsEmpty then
                    StoreGroup_p := StoreGroupSetup."Store Group";
            until (StoreGroupSetup.Next() = 0) or (StoreGroup_p <> '');

        exit(StoreGroup_p <> '');
    end;

    internal procedure FindItemPostException(StoreGroup_p: Code[20]; ItemNo_p: Code[20]; var PostingException_p: Record "LSC Posting Exception" temporary): Boolean
    var
        PostingException: Record "LSC Posting Exception" temporary;
    begin
        PostingException_g.Reset();
        PostingException_g.SetRange(PostingException_g."Item No.", ItemNo_p);
        if not PostingException_g.FindFirst() then begin
            if FindItemPostExSetup(StoreGroup_p, ItemNo_p, PostingException) then begin
                PostingException_g.Init();
                PostingException_g := PostingException;
                PostingException_g."Store Group" := '';
                PostingException_g."Item Category Code" := '';
                PostingException_g."Retail Product Code" := '';
                PostingException_g."Special Group Code" := '';
                PostingException_g."Item No." := ItemNo_p;
                PostingException_g.Active := true;
                PostingException_g.Insert();
            end else begin
                PostingException_g.Init();
                PostingException_g."Item No." := ItemNo_p;
                PostingException_g.Active := false;
                PostingException_g.Insert();
            end;
        end;

        PostingException_p := PostingException_g;
        exit(PostingException_g.Active);
    end;

    local procedure FindItemPostExSetup(StoreGroup_p: Code[20]; ItemNo_p: Code[20]; var PostingException_p: Record "LSC Posting Exception" temporary): Boolean
    var
        PostingException: Record "LSC Posting Exception";
        Item: Record Item;
        ItemSpecialGroupLink: Record "LSC Item/Special Group Link";
        ReturnValue, IsHandled : Boolean;
    begin
        OnBeforeFindItemPostExSetup(StoreGroup_p, ItemNo_p, PostingException_p, ReturnValue, IsHandled);
        if IsHandled then
            exit(ReturnValue);

        if not Item.Get(ItemNo_p) then
            exit(false);

        PostingException.Reset();
        PostingException.SetRange("Store Group", StoreGroup_p);

        PostingException.SetRange("Item No.", Item."No.");
        if PostingException.FindFirst() then begin
            PostingException_p := PostingException;
            exit(true);
        end;
        PostingException.SetRange("Item No.", '');

        ItemSpecialGroupLink.SetRange("Item No.", Item."No.");
        if ItemSpecialGroupLink.FindSet() then
            repeat
                PostingException.SetRange("Special Group Code", ItemSpecialGroupLink."Special Group Code");
                if PostingException.FindFirst() then begin
                    PostingException_p := PostingException;
                    exit(true);
                end;
            until ItemSpecialGroupLink.Next() = 0;
        PostingException.SetRange("Special Group Code", '');

        if Item."LSC Retail Product Code" <> '' then begin
            PostingException.SetRange("Retail Product Code", Item."LSC Retail Product Code");
            if PostingException.FindFirst() then begin
                PostingException_p := PostingException;
                exit(true);
            end;
        end;
        PostingException.SetRange("Retail Product Code", '');

        if Item."Item Category Code" <> '' then begin
            PostingException.SetRange(PostingException."Item Category Code", Item."Item Category Code");
            if PostingException.FindFirst() then begin
                PostingException_p := PostingException;
                exit(true);
            end;
        end;
        PostingException.SetRange("Item Category Code", '');

        exit(false);
    end;

    internal procedure GetPreactionKeyFromRecID(var pRecID: RecordID; var pKey: Text[250])
    var
        BOUtils: Codeunit "LSC BO Utils";
        RecRef: RecordRef;
        RecFieldRef: FieldRef;
        RecKeyRef: KeyRef;
        tmpDateTime: DateTime;
        tmpDate: Date;
        tmpTime: Time;
        addValue: Text[250];
        tmpDec: Decimal;
        i: Integer;
        tmpInt: Integer;
        tmpBool: Boolean;
    begin
        pKey := '';
        RecRef := pRecID.GetRecord();
        RecKeyRef := RecRef.KeyIndex(1);
        for i := 1 to RecKeyRef.FieldCount do begin
            RecFieldRef := RecKeyRef.FieldIndex(i);
            case Format(RecFieldRef.Type) of
                'Decimal':
                    begin
                        Evaluate(tmpDec, Format(RecFieldRef.Value));
                        addValue := BOUtils.DecToStr(tmpDec);
                    end;
                'Time':
                    begin
                        tmpTime := RecFieldRef.Value;
                        addValue := BOUtils.STDTimeToString(tmpTime);
                    end;
                'Date':
                    begin
                        Evaluate(tmpDate, Format(RecFieldRef.Value));
                        addValue := BOUtils.STDDateToString(tmpDate);
                    end;
                'Boolean':
                    begin
                        Evaluate(tmpBool, Format(RecFieldRef.Value));
                        addValue := BOUtils.BoolToStr(tmpBool);
                    end;
                'DateTime':
                    begin
                        tmpDateTime := RecFieldRef.Value;
                        addValue := BOUtils.STDDateTimeToString(tmpDateTime);
                    end;
                'Option':
                    begin
                        tmpInt := RecFieldRef.Value;
                        addValue := BOUtils.OptToStr(tmpInt);
                    end;
                else
                    addValue := Format(RecFieldRef.Value);
            end;
            pKey += ';' + addValue;
        end;
        pKey := CopyStr(pKey, 2);
    end;

    internal procedure GetRecIdFromPreactionKey(pTableNo: Integer; pKey: Text; var pRecID: RecordID)
    var
        BOUtils: Codeunit "LSC BO Utils";
        RecRef: RecordRef;
        RecFieldRef: FieldRef;
        RecKeyRef: KeyRef;
        ValueText: Text;
        i: Integer;
        ValueInt: Integer;
    begin
        Clear(pRecID);
        RecRef.Open(pTableNo);
        RecKeyRef := RecRef.KeyIndex(1);
        for i := 1 to RecKeyRef.FieldCount do begin
            RecFieldRef := RecKeyRef.FieldIndex(i);
            ValueText := BOUtils.SeparateActKey(i, pKey);
            case Format(RecFieldRef.Type) of
                'Decimal':
                    begin
                        RecFieldRef.Value := BOUtils.StrToDec(ValueText);
                    end;
                'Time':
                    begin
                        RecFieldRef.Value := BOUtils.STDStringToTime(ValueText);
                    end;
                'Date':
                    begin
                        RecFieldRef.Value := BOUtils.STDStringToDate(ValueText);
                    end;
                'Boolean':
                    begin
                        if ValueText = '1' then
                            RecFieldRef.Value := true
                        else
                            RecFieldRef.Value := false;
                    end;
                'DateTime':
                    begin
                        RecFieldRef.Value := BOUtils.STDStringToDateTime(ValueText);
                    end;
                'Integer', 'Option':
                    begin
                        Evaluate(ValueInt, ValueText);
                        RecFieldRef.Value := ValueInt;
                    end;
                else begin
                    RecFieldRef.Value := ValueText;
                end;
            end;
        end;
        pRecID := RecRef.RecordId;
        RecRef.Close();
    end;

    internal procedure SetPostExStoreGroup(PostExStoreGroup_p: Code[20])
    begin
        PostExStoreGroup_g := PostExStoreGroup_p;
    end;

    internal procedure PostExStoreGroup(): Code[20]
    begin
        exit(PostExStoreGroup_g);
    end;

    procedure GetNextEntryNo(): Integer
    begin
        NextEntryNo_g := NextEntryNo_g + 1;

        exit(NextEntryNo_g);
    end;

    internal procedure SetInvCostAdjust(var ValueEntry_p: Record "Value Entry")
    var
        TransInvAdjustEntry: Record "LSC Inventory Adjustment Entry";
    begin
        TransInvAdjustEntry.Reset();
        TransInvAdjustEntry.SetRange("Outbound Item ledger Entry No.", ValueEntry_p."Item Ledger Entry No.");
        if not TransInvAdjustEntry.IsEmpty then
            if TransInvAdjustEntry.FindSet() then
                repeat
                    if not TransInvAdjustEntry."Adjust Cost" then begin
                        TransInvAdjustEntry."Adjust Cost" := true;
                        TransInvAdjustEntry.Modify();
                    end;
                until TransInvAdjustEntry.Next() = 0;
    end;

    procedure FindItremPostExSetupByKey(PostingExceptionKey_p: Text[75]; var PostingException_p: Record "LSC Posting Exception" temporary): Boolean
    var
        PostingException: Record "LSC Posting Exception";
        RecRef: RecordRef;
        RecID: RecordID;
        RecFound: Boolean;
    begin
        RecRef.GetTable(PostingException);
        GetRecIdFromPreactionKey(RecRef.Number, PostingExceptionKey_p, RecID);
        if RecRef.Get(RecID) then begin
            RecFound := true;
            RecRef.SetTable(PostingException)
        end else begin
            RecFound := false;
            Clear(PostingException);
        end;

        PostingException_p := PostingException;
        exit(RecFound);
    end;

    internal procedure CreateDateFilter(MinDate_p: Date; DateFilter_p: Text[250]): Text[250]
    var
        DateFilter: Text[250];
    begin
        if MinDate_p <> 0D then
            if DateFilter_p <> '' then
                DateFilter := StrSubstNo('%1&%2..', DateFilter_p, MinDate_p)
            else
                DateFilter := StrSubstNo('%1..', MinDate_p)
        else
            DateFilter := DateFilter_p;

        exit(DateFilter);
    end;

    internal procedure FindUnPostedTransMinDate(StoreFilter_p: Code[250]): Date
    var
        Store: Record "LSC Store";
        TransSalesEntryStatus: Record "LSC Trans. Sales Entry Status";
        MinDate: Date;
    begin
        MinDate := CalcDate('<-1D>', Today);
        Store.Reset();
        if StoreFilter_p <> '' then
            Store.SetFilter("No.", StoreFilter_p);
        Store.SetRange("Store Type", Store."Store Type"::Store);
        if Store.FindSet() then
            repeat
                TransSalesEntryStatus.Reset();
                TransSalesEntryStatus.SetCurrentKey("Store No.", Date, Status);
                TransSalesEntryStatus.SetRange("Store No.", Store."No.");
                TransSalesEntryStatus.SetRange(Status, TransSalesEntryStatus.Status::"Items Posted", TransSalesEntryStatus.Status::Posted);
                if TransSalesEntryStatus.FindLast() then
                    if TransSalesEntryStatus.Date < MinDate then
                        MinDate := TransSalesEntryStatus.Date;
            until Store.Next() = 0;

        exit(MinDate);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Item Jnl.-Post Line", OnAfterInsertValueEntry, '', false, false)]
    local procedure SetInvCostAdjustOnAfterInsertValueEntry(var ValueEntry: Record "Value Entry"; ItemJournalLine: Record "Item Journal Line"; var ItemLedgerEntry: Record "Item Ledger Entry"; var ValueEntryNo: Integer)
    var
        TransInvAdjustEntry: Record "LSC Inventory Adjustment Entry";
    begin
        if (ValueEntry.Adjustment) and (ValueEntry."Item Ledger Entry No." <> 0) and (ValueEntry."Cost Amount (Actual)" <> 0) then begin
            TransInvAdjustEntry.Reset();
            TransInvAdjustEntry.SetRange("Outbound Item ledger Entry No.", ValueEntry."Item Ledger Entry No.");
            if not TransInvAdjustEntry.IsEmpty then
                if TransInvAdjustEntry.FindSet() then
                    repeat
                        if not TransInvAdjustEntry."Adjust Cost" then begin
                            TransInvAdjustEntry."Adjust Cost" := true;
                            TransInvAdjustEntry.Modify();
                        end;
                    until TransInvAdjustEntry.Next() = 0;
        end;
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeFindItemPostExSetup(StoreGroup_p: Code[20]; ItemNo_p: Code[20]; var TmpPostingException_p: Record "LSC Posting Exception" temporary; var ReturnValue: Boolean; var IsHandled: Boolean)
    begin
    end;
}
