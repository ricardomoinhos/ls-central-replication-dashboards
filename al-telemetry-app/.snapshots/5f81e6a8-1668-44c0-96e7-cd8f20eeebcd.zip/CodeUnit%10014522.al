codeunit 10014522 "LSC Store Logic" implements "LSC IStore", "LSC IStoreController"
{
    Access = Internal;

    procedure FindStoreFromLocation(var Rec: Record "LSC Store"; var NewStore: Record "LSC Store"; LocationCode: Code[20]): Boolean
    begin
        exit(FindStoreFromLocation(Rec, NewStore, LocationCode, this));
    end;

    procedure FindStoreFromLocation(var Rec: Record "LSC Store"; var NewStore: Record "LSC Store"; LocationCode: Code[20]; COntroller: interface "LSC IStoreController"): Boolean
    var
        StoreLocation: Record "LSC Store Location";
    begin
        if COntroller.FindStoreLocation(NewStore, StoreLocation, LocationCode) then
            exit(true);

        exit(COntroller.FindStore(NewStore, LocationCode));
    end;

    procedure FindStoreLocation(var Store: Record "LSC Store"; var StoreLocation: Record "LSC Store Location"; LocationCode: Code[20]): Boolean
    begin
        StoreLocation.SetRange("Location Code", LocationCode);
        if not StoreLocation.FindFirst() then
            exit(false);

        Store.Get(StoreLocation."Store No.");
        exit(true);
    end;

    procedure FindStore(var Store: Record "LSC Store"; LocationCode: Code[10]): Boolean
    var
    begin
        Store.SetRange("Location Code", LocationCode);
        exit(Store.FindFirst());
    end;

    procedure VerifyPostingSetup(var Rec: Record "LSC Store")
    var
        VATBusPostGrp: Record "VAT Business Posting Group";
        IsHandled: Boolean;
        MissingFieldForStoreErr: Label 'No %1 has been specified for this %2';
        InvalidFieldForValueErr: Label '%1 is not a valid %2';
    begin
        Rec.OnBeforeVerifyPostingSetup(Rec, IsHandled);
        if IsHandled then
            exit;

        if Rec."Store VAT Bus. Post. Gr." = '' then
            Error(StrSubstNo(MissingFieldForStoreErr, Rec.FieldCaption("Store VAT Bus. Post. Gr."), Rec.TableCaption));

        if not VATBusPostGrp.Get(Rec."Store VAT Bus. Post. Gr.") then
            Error(StrSubstNo(InvalidFieldForValueErr, Rec."Store VAT Bus. Post. Gr.", VATBusPostGrp.TableCaption));
    end;

    procedure Trigger_OnValidate_StoreKDSinUse(var Rec: Record "LSC Store"; var xRec: Record "LSC Store")
    begin
        if Rec."Store KDS in Use" = xRec."Store KDS in Use" then
            exit;
        case Rec."Store KDS in Use" of
            "LSC KDS ActiveKitchenService"::"Standard KDS":
                Rec."KDS Service Usage" := "LSC KDS Service Usage"::"Standard KDS";
            "LSC KDS ActiveKitchenService"::"Web KDS":
                Rec."KDS Service Usage" := "LSC KDS Service Usage"::"Web KDS - Push";
        end;
    end;

    procedure Trigger_OnValidate_KDSServiceUsage(var Rec: Record "LSC Store"; var xRec: Record "LSC Store")
    var
        NotAllowedErr: Label '%1 is not allowed when %2 is in use.';
        EndPointLink: Record "LSC WKS Rest.ToEndpointLink";
        RememberToAddKSConnectionMsg: Label 'Remember to add a Kitchen Service Connection for restaurant %1.\Choose Action "Web KDS" and then "Kitchen Connection".';
    begin
        if Rec."Store KDS in Use" = "LSC KDS ActiveKitchenService"::"Web KDS" then
            if (Rec."KDS Service Usage" = "LSC KDS Service Usage"::"Standard KDS") then
                Error(NotAllowedErr, Format(Rec."KDS Service Usage"), Format(Rec."Store KDS in Use"));

        if Rec."Store KDS in Use" = "LSC KDS ActiveKitchenService"::"Standard KDS" then
            if (Rec."KDS Service Usage" <> "LSC KDS Service Usage"::"Standard KDS") then
                Error(NotAllowedErr, Format(Rec."KDS Service Usage"), Format(Rec."Store KDS in Use"));

        if (Rec."KDS Service Usage" = "LSC KDS Service Usage"::"Web KDS - Push") and (xRec."KDS Service Usage" <> "LSC KDS Service Usage"::"Web KDS - Push") then begin
            EndPointLink.SetRange("Store No.", Rec."No.");
            if EndPointLink.Count() = 0 then
                Message(RememberToAddKSConnectionMsg, Rec."No.");
        end;
    end;
}