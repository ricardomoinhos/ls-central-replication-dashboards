codeunit 10016604 "LSC Retail Message Management"
{
    Access = Internal;
    SingleInstance = false;

    var
        RetailMessageSetup: Record "LSC Retail Message Setup";
        RetailMessageUtils: Codeunit "LSC Retail Message Utils";
        NewMessageExists: Boolean;
        NextCheckAt: DateTime;
        InitDone: Boolean;
        SetupExists: Boolean;
        NewMessage: Text;
        NoNewMessages: Text;

    local procedure GetSetup(): Boolean
    begin
        if not InitDone then begin
            if RetailMessageSetup.Get() then begin
                GenerateGlyphTokens();
                SetupExists := true;
            end;
            InitDone := true;
        end;
        exit(SetupExists);
    end;

    procedure OkToCheck(): Boolean
    begin
        exit(CurrentDateTime > NextCheckAt);
    end;

    local procedure NewRetailMessageExists(var RetailMessageHeaderTemp_p: Record "LSC Retail Message Header" temporary): Boolean
    var
        POSSession: Codeunit "LSC POS Session";
        ErrorText_p: Text[1024];
    begin
        if OkToCheck() then begin
            if GetNewRetailMessagesList(UserId, POSSession.StoreNo(),
              POSSession.TerminalNo(),
              POSSession.StaffID(),
              RetailMessageHeaderTemp_p,
              ErrorText_p) then
                NewMessageExists := true
            else
                NewMessageExists := false;

            NextCheckAt := CurrentDateTime + (1000 * 60 * RetailMessageSetup."Check frequency (minutes)");
        end;
        exit(NewMessageExists);
    end;

    local procedure GetNewRetailMessagesList(UserName_p: Code[50]; StoreNo_p: Code[10]; PosTerminalNo_p: Code[10]; StaffNo_p: Code[20]; var RetailMessageHeaderTemp_p: Record "LSC Retail Message Header" temporary; var ErrorText_p: Text): Boolean
    var
        POSSession: Codeunit "LSC POS Session";
        RetailMessageGetActiveListUtil: Codeunit LSCRetailMSGGetActiveListUtil;
        PosFuncProfile: Record "LSC POS Func. Profile";
        ProcessCode: Code[30];
        ErrorText: Text;
    begin
        ErrorText_p := '';
        POSSession.SetValue("LSC POS Tag"::"TS_ERROR", '');
        if POSSession.FunctionalityProfileID() = '' then
            exit;
        PosFuncProfile.Get(POSSession.FunctionalityProfileID());
        RetailMessageGetActiveListUtil.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
        RetailMessageGetActiveListUtil.SendRequest(UserName_p, StoreNo_p, PosTerminalNo_p, StaffNo_p, RetailMessageHeaderTemp_p, ProcessCode, ErrorText);
        if ErrorText = '' then begin
            RetailMessageHeaderTemp_p.SetRange("Recipient Status (Internal)", 0, RetailMessageHeaderTemp_p."Recipient Status (Internal)"::"Received by Recipient");
            RetailMessageUtils.OnAfterRetailMessageHeaderTemp_pFilter(RetailMessageHeaderTemp_p);
            if not RetailMessageHeaderTemp_p.IsEmpty then begin
                RetailMessageHeaderTemp_p.FindFirst();
                if RetailMessageHeaderTemp_p."No." <> '' then
                    exit(true);
            end;
        end;

        exit(false);
    end;

    procedure GetTagText(): Text
    var
        RetailMessageHeaderTemp: Record "LSC Retail Message Header" temporary;
    begin
        if GetSetup() then begin
            if RetailMessageSetup."Check frequency (minutes)" = 0 then
                exit('');
            if not RetailMessageSetup."Retail Message in use" then
                exit('');
            if NewRetailMessageExists(RetailMessageHeaderTemp) then begin
                RetailMessageUtils.OnBeforeGetTagTextNewMessage(RetailMessageHeaderTemp, NewMessage);
                exit(NewMessage);
            end;

            RetailMessageUtils.OnBeforeGetTagTextNoNewMessage(RetailMessageHeaderTemp, NoNewMessages);
            exit(NoNewMessages);
        end;
        exit('');
    end;

    procedure GetCurrentTagText(): Text
    var
        POSSession: Codeunit "LSC POS Session";
        RetailMessageHeaderTemp_p: Record "LSC Retail Message Header" temporary;
        ErrorText_p: Text[1024];
    begin
        //Get TagText without doing timerinterval-check first
        if GetSetup() then begin
            if not RetailMessageSetup."Retail Message in use" then
                exit('');
            if GetNewRetailMessagesList(UserId, POSSession.StoreNo(), POSSession.TerminalNo(), POSSession.StaffID(), RetailMessageHeaderTemp_p, ErrorText_p) then begin
                RetailMessageUtils.OnBeforeNewMessageExit(RetailMessageHeaderTemp_p, NewMessage);
                exit(NewMessage)
            end else begin
                RetailMessageUtils.OnBeforeNoNewMessageExit(RetailMessageHeaderTemp_p, NoNewMessages);
                exit(NoNewMessages);
            end;
        end;
        exit('');
    end;

    local procedure GenerateGlyphTokens()
    begin
        // Creates the two symbols for 'New messages' and 'No new messages'
        // Envelope       = Unicode 2709 in hex
        // Heavy ballot X = Unicode 2718 in hex
        NewMessage := '✉'; // byteValue := 655894281;   // Hex: 2718 2709 will fill up the integer variable (4 bytes)
        NoNewMessages := '';  //For the time being we will not show any symbol for 'No new messages'
    end;
}
