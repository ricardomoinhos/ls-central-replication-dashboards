codeunit 10000749 "LSC Search Index"
{
    SingleInstance = True;
    TableNo = "LSC Scheduler Job Header";

    trigger OnRun()
    var
        SearchIndex: Record "LSC Search Index Table";
        l_RecordID: RecordID;
    begin
        if not Initialized then //Run from Task Scheduler
            Init();

        SelectLatestVersion;
        if Rec.Code = 'UPDATE' then begin
            IndexFromActions();
        end
        else
            if Rec.Code = 'INDEX' then begin
                if Rec.Text = '' then
                    IndexAll()
                else begin
                    if SearchIndex.Get(Rec.Text) then
                        IndexAll(SearchIndex);
                end;
            end
            else
                if Rec.Code = 'UPDATE-ENTRY' then begin
                    if Evaluate(l_RecordID, Rec.Text) then begin
                        IndexFromRecordID(l_RecordID);
                    end;
                end;
    end;

    var
        Initialized: Boolean;
        ISearchEngine: Interface "LSC ISearchEngine";
        ActiveSearchEngine: Enum "LSC Search Engine";
        DatabaseUniqueName: Text;
        POSSession: Codeunit "LSC POS Session";
        Log: Codeunit "LSC Debug Log";
        Text000: Label 'Indexing';
        Text001: Label 'Total:';
        Text002: Label 'Started at:';
        Text003: Label 'Progress:';
        Text004: Label 'Duration:';
        Text005: Label 'Estimated:';

    procedure Init()
    var
        Terminal: Record "LSC POS Terminal";
    begin
        if POSSession.TerminalNo <> '' then begin
            if Terminal.Get(POSSession.TerminalNo()) then
                if Terminal."POS Search Engine".AsInteger() > 0 then begin
                    Init(Terminal."POS Search Engine");
                    exit;
                end;
        end;

        Init(true);
    end;

    procedure Init(RetailSetupOnly: Boolean)
    var
        RetailSetup: Record "LSC Retail Setup";
    begin
        if not Initialized then begin
            if RetailSetupOnly then begin
                if not RetailSetup.Get() then
                    exit;
                Init(RetailSetup."POS Search Engine");
            end
            else
                Init();
        end;
    end;

    procedure Init(pSearchEngine: Enum "LSC Search Engine")
    begin
        ISearchEngine := pSearchEngine;
        ActiveSearchEngine := pSearchEngine;
        Initialized := true;
        ISearchEngine.init();
    end;

    procedure GetActiveSearchEngine(): Enum "LSC Search Engine"
    var
    begin
        exit(ActiveSearchEngine);
    end;

    procedure IndexAll()
    var
        SearchIndex: Record "LSC Search Index Table";
    begin
        Init(false);

        IF not UseIndexing then
            exit;

        ExternalActionsToLocal();
        ISearchEngine.CreateIndex();
        SearchIndex.SetFilter("Parent Code", '%1', '');
        if SearchIndex.FindSet then
            repeat
                IndexAll(SearchIndex);
            until SearchIndex.Next = 0;

        ISearchEngine.CloseIndex(GetDatabaseUniqueName());
    end;

    procedure DeleteSearchIndex(pSearchIndex: Text)
    begin
        ISearchEngine.DeleteSearchIndex(pSearchIndex);
    end;

    procedure IndexAll(SearchIndex: Record "LSC Search Index Table")
    var
        EntryRecRef: RecordRef;
        ProgressWindow: Dialog;
        i: Integer;
        startTime: DateTime;
        total: Integer;
        duration: Duration;
    begin
        if SearchIndex."Parent Code" <> '' then
            exit;

        DeleteSearchIndex(SearchIndex.Code);

        EntryRecRef.Open(SearchIndex."Table No.");
        SetFixedFilter(SearchIndex, EntryRecRef);
        SearchIndex.CalcFields("Table Name");
        if GuiAllowed then begin
            ProgressWindow.Open(Text000 + ' ' + SearchIndex."Table Name" + ' (' + Format(SearchIndex."Table No.") + ')\' +
                            Text001 + ' #1################\' +
                            Text002 + ' #2################\' +
                            Text003 + ' #3################\' +
                            Text004 + ' #4################\' +
                            Text005 + ' #5################\');

            total := EntryRecRef.Count;
            ProgressWindow.Update(1, Format(total));

            startTime := CurrentDateTime;
            ProgressWindow.Update(2, Format(startTime));
        end;

        if EntryRecRef.FindSet then
            repeat
                if GuiAllowed then begin
                    i += 1;
                    if ((i - 1) mod 100) = 0 then begin
                        ProgressWindow.Update(3, Format(i));
                        duration := CurrentDateTime - startTime; //duration
                        ProgressWindow.Update(4, Format(duration));
                        duration *= Round(total / i, 1);
                        ProgressWindow.Update(5, Format(duration));
                    end;
                end;

                ISearchEngine.IndexEntry(EntryRecRef, SearchIndex);

            until EntryRecRef.Next = 0;

        if GuiAllowed then
            ProgressWindow.Close();
    end;

    procedure UpdatesPendingFromActions(): Boolean
    var
        LastSyncTime: DateTime;
    begin
        if not UseIndexing() then
            exit(false);

        LastSyncTime := GetLastSyncTime();
        exit(UpdatesPendingFromActions(LastSyncTime));
    end;

    procedure UpdatesPendingFromActions(pLastSync: DateTime): Boolean
    var
        "Action": Record "LSC Search Index Action";
    begin
        Action.SetFilter("Executed On", '<>%1', GetDatabaseUniqueName);
        if not Action.IsEmpty then
            exit(true);

        Action.Reset;
        Action.SetFilter(DateTime, '>%1', pLastSync);
        if not Action.IsEmpty then
            exit(true);
    end;

    procedure IndexFromActions()
    var
        "Action": Record "LSC Search Index Action";
        LastSync: DateTime;
        SearchIndex: Record "LSC Search Index Table";
        RecID: RecordID;
    begin
        Init(false);

        IF not UseIndexing then
            exit;

        if ISearchEngine.IsIndexAllRequired(GetDatabaseUniqueName()) then begin
            IndexAll();
            exit;
        end;

        LastSync := GetLastSyncTime();
        if (LastSync = 0DT) then begin
            IndexAll();
            exit;
        end;

        if not UpdatesPendingFromActions(LastSync) then begin
            //IndexAll();
            exit;
        end;

        ExternalActionsToLocal();

        Action.Reset;
        Action.SetFilter(DateTime, '>%1', LastSync);
        Action.SetCurrentKey(DateTime);
        Action.Ascending(false);
        if Action.FindSet then
            repeat
                if Action.Action = Action.Action::"Update Record" then begin
                    if Evaluate(RecID, Action.Parameter) then begin
                        IndexFromRecordID(RecID);
                    end;
                end
                else
                    if Action.Action = Action.Action::"Update Search" then begin
                        if SearchIndex.Get(Action.Parameter) then begin
                            ClearActionsForIndex(SearchIndex, Action.DateTime);
                            IndexAll(SearchIndex);
                        end
                        else begin
                            DeleteSearchIndex(Action.Parameter);
                        end;
                    end
                    else
                        if Action.Action = Action.Action::"Re-Index" then begin
                            IndexAll();
                        end;
            until Action.Next = 0;
        ISearchEngine.CloseIndex(GetDatabaseUniqueName());
    end;

    procedure IndexFromActionsBackground()
    var
        NewSessionID: Integer;
        Job: Record "LSC Scheduler Job Header" temporary;
    begin
        if not Initialized then
            Init();

        if not UseIndexing() then
            exit;

        Job.Init;
        Job.Code := 'UPDATE';
        StartSession(NewSessionID, Codeunit::"LSC Search Index", CompanyName, Job);
    end;

    procedure ExternalActionsToLocal()
    var
        "Action": Record "LSC Search Index Action";
        ActionTemp: Record "LSC Search Index Action" temporary;
    begin
        if GetDatabaseUniqueName = '' then
            exit;
        Action.SetFilter("Executed On", '<>%1', GetDatabaseUniqueName);
        Action.SetCurrentKey(DateTime);
        if Action.FindSet(false) then
            repeat
                ActionTemp.Init;
                ActionTemp.ID := Action.ID;
                ActionTemp."Executed On" := GetDatabaseUniqueName;
                ActionTemp.DateTime := CurrentDateTime;
                ActionTemp.Insert;
            until Action.Next = 0;

        if ActionTemp.FindSet then
            repeat
                if Action.Get(ActionTemp.ID) then begin
                    Action.DateTime := ActionTemp.DateTime;
                    Action."Executed On" := ActionTemp."Executed On";
                    Action.Modify(true);
                end;
            until ActionTemp.Next = 0;
    end;

    local procedure IndexFromRecordID(pRecordID: RecordID)
    var
        RecRef: RecordRef;
        SearchTable: Record "LSC Search Index Table";
        RecRef2: RecordRef;
    begin
        Init(false);

        IF not UseIndexing then
            exit;

        if not RecRef.Get(pRecordID) then begin
            ISearchEngine.DeleteEntry(pRecordID);
            exit;
        end;
        SearchTable.SetCurrentKey("Table No.", "Parent Code");
        SearchTable.SetRange("Table No.", RecRef.Number);
        SearchTable.SetFilter("Parent Code", '%1', '');
        if SearchTable.FindSet then
            repeat
                RecRef2.Open(RecRef.Number);
                RecRef2.Get(pRecordID);
                RecRef2.SetRecFilter;
                SetFixedFilter(SearchTable, RecRef2);
                if RecRef2.FindSet then
                    ISearchEngine.IndexEntry(RecRef, SearchTable)
                else
                    ISearchEngine.DeleteEntry(pRecordID);
            until SearchTable.Next = 0;
    end;

    local procedure IndexFromRecordIDBackground(RecordID: RecordID)
    var
        NewSessionID: Integer;
        Job: Record "LSC Scheduler Job Header" temporary;
    begin
        Job.Init;
        Job.Code := 'UPDATE-ENTRY';
        Job.Text := Format(RecordID);
        StartSession(NewSessionID, Codeunit::"LSC Search Index", CompanyName, Job);
    end;

    procedure MarkForIndexUpdate(var RecRef: RecordRef; var xRecRef: RecordRef; Type: Integer)
    begin
        Init(true);

        IF not UseIndexing then
            exit;

        //Type: 0 = INSERT, 1 = MODIFY, 2 = DELETE, 3 = RENAME
        if Type in [0, 1, 3] then
            MarkForIndexUpdateLocal(RecRef)
        else
            if Type = 2 then
                MarkForIndexUpdateLocal(RecRef);
        if Type = 3 then
            MarkForIndexUpdateLocal(xRecRef);
    end;

    local procedure MarkForIndexUpdateLocal(EntryRecRef: RecordRef)
    var
        SearchIndex: Record "LSC Search Index Table";
        ParentRecRef: RecordRef;
        ParentSearchIndex: Record "LSC Search Index Table";
    begin
        SearchIndex.SetCurrentKey("Table No.", "Parent Code");
        SearchIndex.SetRange("Table No.", EntryRecRef.Number);
        if not SearchIndex.IsEmpty then begin
            SearchIndex.FindSet(false);
            repeat
                if SearchIndex."Parent Code" <> '' then begin
                    if not ParentSearchIndex.Get(SearchIndex."Parent Code") then begin
                        Warning('Could not find parent ID: ' + SearchIndex."Parent Code");
                        exit;
                    end;
                    if ParentSearchIndex."Table No." <> 0 then begin
                        ParentRecRef.Open(ParentSearchIndex."Table No.");
                        SetNestedFilter(ParentRecRef, EntryRecRef, SearchIndex."Parent Filter Key", SearchIndex."Filter Key");
                        if ParentRecRef.FindSet then
                            repeat
                                MarkForIndexUpdateLocal(ParentRecRef);
                            until ParentRecRef.Next = 0;
                    end;
                end
                else begin
                    MarkEntryForUpdate(EntryRecRef.RecordId);
                    //if not SuppressSearchIndexBuild() then
                    //    IndexFromRecordIDBackground(EntryRecRef.RecordId);
                end;
            until SearchIndex.Next = 0;
        end;
    end;

    local procedure MarkEntryForUpdate(pRecordID: RecordID)
    var
        "Action": Record "LSC Search Index Action";
    begin
        MarkForUpdate(Action.Action::"Update Record", Format(pRecordID), pRecordID.TableNo);
    end;

    procedure MarkSearchForUpdate(SearchID: Code[20])
    var
        "Action": Record "LSC Search Index Action";
    begin
        MarkForUpdate(Action.Action::"Update Search", SearchID, 0);
    end;

    local procedure MarkForUpdate(_Action: Integer; Parameter: Text[250]; TableNo: Integer)
    var
        ActionRecord: Record "LSC Search Index Action";
    begin
        ActionRecord.SetCurrentKey(Action, "Table No.", Parameter);
        ActionRecord.SetRange(Action, _Action);
        ActionRecord.SetRange("Table No.", TableNo);
        ActionRecord.SetRange(Parameter, Parameter);

        if ActionRecord.FindFirst then begin
            if CurrentDateTime - 10000 < ActionRecord.DateTime then  // 10 seconds
                exit;
            ActionRecord.DateTime := CurrentDateTime;
            ActionRecord."Executed On" := GetDatabaseUniqueName;
            ActionRecord.User := UserId;
            ActionRecord.Modify(true);
        end
        else begin
            ActionRecord.Init;
            ActionRecord.ID := CreateGuid;
            ActionRecord.Action := _Action;
            ActionRecord.Parameter := Parameter;
            ActionRecord."Executed On" := GetDatabaseUniqueName;
            ActionRecord.DateTime := CurrentDateTime;
            ActionRecord.User := UserId;
            ActionRecord."Table No." := TableNo;
            ActionRecord.Insert(true);
        end;
    end;

    local procedure ClearActionsForIndex(SearchIndex: Record "LSC Search Index Table"; DateTime: DateTime)
    var
        "Action": Record "LSC Search Index Action";
    begin
        if SearchIndex."Parent Code" <> '' then
            exit;
        Action.SetFilter("Table No.", '%1', SearchIndex."Table No.");
        Action.SetFilter(Action, '%1', Action.Action::"Update Record");
        Action.SetFilter(DateTime, '<%1', DateTime);
        Action.DeleteAll;
    end;

    procedure Warning(Value: Text)
    begin
        Log.LogWarning(Value);
    end;

    procedure Error(Value: Text)
    begin
        Log.LogError(Value);
    end;

    local procedure SetNestedFilter(var SetFilterRecRef: RecordRef; var GetFilterRecRef: RecordRef; SetFilterFields: Text; GetFilterFields: Text)
    var
        Idx: Integer;
        SetFilterFieldStr: Text;
        GetFilterFieldStr: Text;
        SetFieldNo: Integer;
        GetFieldNo: Integer;
        Variant: Variant;
        SetFieldRef: FieldRef;
        GetFieldRef: FieldRef;
        OptionVar: Option;
    begin
        Idx := 0;

        if (SetFilterFields = '') or (GetFilterFields = '') then
            exit;

        repeat
            SetFilterFieldStr := GetInParts(SetFilterFields, ',');
            GetFilterFieldStr := GetInParts(GetFilterFields, ',');
            Idx := Idx + 1;
            if (SetFilterFieldStr <> '') and (GetFilterFieldStr <> '') then begin
                Clear(Variant);
                Evaluate(SetFieldNo, SetFilterFieldStr);
                Evaluate(GetFieldNo, GetFilterFieldStr);
                SetFieldRef := SetFilterRecRef.Field(SetFieldNo);
                GetFieldRef := GetFilterRecRef.Field(GetFieldNo);
                if Format(GetFieldRef.Type) = 'Option' then begin
                    OptionVar := GetFieldRef.Value;
                    SetFieldRef.SetFilter(Format(OptionVar, 0, 2));
                end
                else
                    if Format(GetFieldRef.Type) in ['Text', 'Code'] then begin
                        Variant := GetFieldRef.Value;
                        SetFieldRef.SetFilter('%1', Variant);
                    end
                    else begin
                        Variant := GetFieldRef.Value;
                        SetFieldRef.SetFilter(Format(Variant));
                    end;
            end;
        until SetFilterFieldStr = '';
    end;

    local procedure SetFixedFilter(SearchIndex: Record "LSC Search Index Table"; var RecRef: RecordRef)
    var
        SearchField: Record "LSC Search Index Field";
        FieldRef: FieldRef;
        IntegerVar: Integer;
        BooleanVar: Boolean;
        TextVar: Text;
    begin
        SearchField.SetFilter("Search Index Code", SearchIndex.Code);
        if SearchField.FindSet then
            repeat
                if SearchField."Fixed Filter" <> '' then begin
                    FieldRef := RecRef.Field(SearchField."Field No.");
                    TextVar := SearchField."Fixed Filter";
                    if (Format(FieldRef.Type)) = 'Integer' then begin
                        Evaluate(IntegerVar, TextVar);
                        FieldRef.SetFilter('%1', IntegerVar);
                    end
                    else
                        if (Format(FieldRef.Type)) = 'Boolean' then begin
                            Evaluate(BooleanVar, TextVar);
                            FieldRef.SetFilter('%1', BooleanVar);
                        end
                        else begin
                            FieldRef.SetFilter('%1', TextVar)
                        end;
                end;
            until SearchField.Next = 0;
    end;

    internal procedure HitToRec(var pSearchHits: Record "LSC Search Index Result" temporary; var pRecRef: RecordRef): Boolean
    var
        Recid: RecordID;
        RecRef_l: RecordRef;
        RetVal: Boolean;
        KeyIdx: Integer;
    begin
        if not Evaluate(Recid, pSearchHits.ID) then
            exit(false);

        if not RecRef_l.Get(Recid) then //record has been deleted
            exit(false);

        pRecRef.SetPosition(RecRef_l.GetPosition()); //Doing this to respect the filter(s) set in the pRecRef
        KeyIdx := pRecRef.CurrentKeyIndex;
        if KeyIdx > 1 then
            pRecRef.CurrentKeyIndex(1); //set to primary key to find the record
        RetVal := pRecRef.Find('=');
        if KeyIdx > 1 then
            pRecRef.CurrentKeyIndex(KeyIdx);
        exit(RetVal);
    end;

    procedure Search(pSearchIndexCode: Text; pQuery: Text; pFilter: Text; CountPerPage: Integer; pPages: Integer; var pHits: Record "LSC Search Index Result" temporary; UseWildcard: Boolean; UseFuzzy: Boolean): Integer
    var
        SearchTable: Record "LSC Search Index Table";
        PosImgUtils: Codeunit "LSC POS Image Utils";
        ImgId, TypeImgId : Text;
        lRecID: RecordId;
        lMod: Boolean;
    begin
        if not Initialized then
            Init();

        Clear(pHits);
        ISearchEngine.Search(pSearchIndexCode, pQuery, pFilter, CountPerPage * pPages, pHits, UseWildcard, UseFuzzy);

        //parse for images
        if pHits.FindSet(true) then
            repeat
                lMod := false;
                if SearchTable.Code <> pHits.Type then begin
                    TypeImgId := '';
                    if SearchTable.Get(pHits.Type) then begin
                        TypeImgId := PosImgUtils.GetImgCode(SearchTable.RecordId);
                        PosImgUtils.AddSpecialImage(TypeImgId);
                    end;
                end;

                if TypeImgId <> '' then
                    lMod := true;

                if SearchTable."Use Retail Image" then
                    if Evaluate(lRecID, pHits.ID) then
                        lMod := true;

                if lMod then begin
                    ImgId := PosImgUtils.GetImgCode(lRecID);
                    PosImgUtils.AddSpecialImage(ImgId);
                    pHits.Image := ImgId;
                    pHits."Type Image" := TypeImgId;
                    pHits.Modify;
                end;
            until pHits.Next = 0;
    end;

    procedure GetDatabaseUniqueName(): Text
    var
        ActiveSession: Record "Active Session";
        Server: Text;
    begin
        IF DatabaseUniqueName = '' then begin
            ActiveSession.SETRANGE("Server Instance ID", SERVICEINSTANCEID);
            ActiveSession.SETRANGE("Session ID", SESSIONID);
            if not ActiveSession.FINDFIRST then
                exit('');
            Server := ActiveSession."Server Computer Name";
            if StrPos(Server, '.') > 0 then
                Server := Server.Split('.').Get(1);
            DatabaseUniqueName := Server.ToUpper() + '\' + ActiveSession."Database Name".ToUpper();
        end;

        exit(DatabaseUniqueName);
    end;

    procedure GetInParts(var Value: Text; Delimiter: Text): Text
    var
        Pos: Integer;
        DelimiterLength: Integer;
        Result: Text;
    begin
        if Value = '' then
            exit('');
        DelimiterLength := StrLen(Delimiter);
        Pos := StrPos(Value, Delimiter);
        if Pos = 0 then begin
            Result := Value;
            Value := '';
        end
        else begin
            Result := CopyStr(Value, 1, Pos - 1);
            Value := DelStr(Value, 1, StrLen(Result) + StrLen(Delimiter));
        end;

        exit(Result);
    end;

    procedure SearchEngineName(): Text
    begin
        exit(ISearchEngine.SearchEngineName());
    end;

    procedure GetLastSyncTime(): DateTime
    begin
        exit(ISearchEngine.GetLastSyncTime());
    end;

    procedure UseIndexing(): Boolean
    begin
        exit(ISearchEngine.UseIndexing());
    end;
}

