codeunit 10012720 "LSC POS Control Interface"
{
    SingleInstance = true;

    var
        iPOS: Interface "LSC IEPOSControl";
        initialized: Boolean;
        TestPOS: Codeunit "LSC POS Control Interface TEST";
        NoDllPOS: Codeunit "LSC POS Ctrl Interface NODLL";
        DualDisplay: Codeunit "LSC POS Ctrl Interface NODLL";
        PosType: Enum "LSC POS Client Type";

    var
        _oldIPos: Interface "LSC IEPOSControl";
        _oldInitialized: Boolean;

    /// <summary>
    /// This function is a temporary entry point for unit tests (not auto tests!) to inject a mock POS instance. Unit tests
    /// cannot use the Codeunit "LSC POS Control Interface TEST" codeunit (as it doesn't support full stubbing/spying needed,
    /// and involves a lot of concrete dependencies itself))
    /// </summary>
    /// <param name="iPosInstance"></param>
    internal procedure TestsOnly_InjectIPos(iPosInstance: Interface "LSC IEPOSControl")
    begin
        if initialized then begin
            _oldIPos := iPOS;
            _oldInitialized := initialized;
        end;
        iPOS := iPosInstance;
        initialized := true;
    end;

    internal procedure TestsOnly_Cleanup()
    begin
        if _oldInitialized and (_oldIPos is "LSC IEPOSControl") then
            iPOS := _oldIPos;
        Clear(_oldIPos);
        Clear(_oldInitialized);
    end;

    #Region POS Functions

    /// <summary>
    /// Sets the Active Client Type. API calls are routed to specific codeunits/implementations accordingly.
    /// </summary>
    /// <param name="pClientType">Set to AutoTest when running POS AutoTests, DualDisplay when controlling the DualDisplay. Otherwise the Default WebClient is used.</param>
    procedure SetClientTypeEnum(pClientType: Enum "LSC POS Client Type")
    var
        HardwareInterface: Codeunit "LSC POS Hardware Interface";
        EmptyControlLib: Codeunit "LSC POS Control Library";
    begin
        PosType := pClientType;
        case pClientType of
            PosType::Default:
                iPOS := NoDLLPOS; // Note: GetClientTypeDefault can be used to know what Default points to
            PosType::Mock:
                begin
                    iPOS := TestPOS;
                    iPOS.InitControl(EmptyControlLib); // Note: InitControl(EmptyControlLib) causes recursion
                end;
            PosType::Pos:
                iPOS := NoDllPOS;
            PosType::DualDisplay:
                iPOS := DualDisplay;
        end;

        HardwareInterface.SetClient(iPOS);
        initialized := true;
    end;

    /// <summary>
    /// Returns the Active Client Type. Note that Default and Pos are two values pointing to the same thing, so make sure to check for both ("PosType::Default or GetClientTypeDefault")
    /// </summary>
    procedure GetClientTypeEnum(): Enum "LSC POS Client Type"
    begin
        exit(PosType);
    end;

    /// <summary>
    /// Returns what is interpreted as the Default Client Type Enum Value
    /// </summary>
    procedure GetClientTypeDefault(): Enum "LSC POS Client Type"
    begin
        exit(PosType::Pos);
    end;

    /// <summary>
    /// Sets how many seconds are between Idle Timer Events. An Event that fires when POS is not in use. 
    /// </summary>
    /// <param name="pSeconds">The Interval in seconds between events</param>
    procedure SetIdleTimerInterval(pSeconds: Integer)
    begin
        iPOS.SetIdleTimerInterval(pSeconds);
    end;

    /// <summary>
    /// Adds a text message to the POS Debug Log
    /// </summary>
    /// <param name="msg">The text to log</param>
    procedure LogDebug(msg: Text)
    begin
        if not initialized then
            exit;

        iPOS.LogDebug(msg)
    end;

    /// <summary>
    /// Return true if the POS has been started.
    /// </summary>
    procedure PosIsActive(): Boolean
    begin
        if not initialized then
            exit(false);

        exit(iPOS.PosIsActive())
    end;

    /// <summary>
    /// Refreshes the POS UI and Controls. All previously loaded Panel, Controls and Context Menus will be Refreshed.
    /// </summary>
    /// <param name="InterfaceProfileID">Not used. Active (Primary and Secondary) Interface Profiles will be used.</param>
    procedure RefreshInterfaceProfile(InterfaceProfileID: Text)
    begin
        iPOS.RefreshInterfaceProfile(InterfaceProfileID);
    end;

    /// <summary>
    /// Refreshes all Menus on the POS.
    /// </summary>
    /// <param name="MenuProfileID">Not Used: All menus regardless of profile will be refreshed.</param>
    procedure RefreshMenuProfile(MenuProfileID: Text)
    begin
        iPOS.RefreshMenuProfile(MenuProfileID);
    end;

    /// <summary>
    /// Refreshes all styles (Skins, Fonts and Colors) on the POS UI. Setup of the Style Profiles (Primary and Secondary) will be read from the Database and sent to the Client.
    /// </summary>
    /// <param name="StyleProfileID">Not Used: Active (Primary and Secondary) Style Profiles will be used.</param>
    procedure RefreshStyleProfile(StyleProfileID: Text)
    begin
        iPOS.RefreshStyleProfile(StyleProfileID);
    end;

    /// <summary>
    /// Refreshes Style and Interface Profiles. (see RefreshStyleProfile and RefreshInterfaceProfile functions)
    /// </summary>
    procedure RefreshProfiles()
    begin
        iPOS.RefreshProfiles();
    end;

    /// <summary>
    /// Evaluates and Executes the specified javascript code in the POS Client. Can be used for workarounds etc. by developers of LS Central.
    /// </summary>
    /// <param name="script">The javacript code.</param>
    procedure AddJavaScript(script: Text)
    begin
        iPOS.AddJavaScript(script);
    end;

    /// <summary>
    /// Signals back to the POS Client when it requests a Tooltip via the PosCommand::TOOLTIP. Note that Tooltips must be globally Active (use PosCommand::TOOLTIP_TOGGLE or PosSession.SetTooltipActive to enable it)
    /// </summary>
    /// <param name="txt">The content to show in the Tooltip</param>
    /// <param name="contentType">How to interprate the text content. String: Show raw text (fastest), Html: Show web content (more flexible), Url: Show external Url (good if content, like documentation, is available through a web address)</param>
    procedure ShowTooltip(txt: Text; contentType: Option String,Html,Url)
    begin
        iPOS.ShowTooltip(txt, contentType);
    end;

    /// <summary>
    /// (Re)loads all configured Context Menus to the UI.
    /// </summary>
    procedure LoadPosContextMenus()
    begin
        iPOS.LoadPosContextMenus();
    end;

    /// <summary>
    /// Shows a Control on the specified Panel in the Specified position (Row/Column) with the given width and height (RowSpan/ColumnSpan). Note that the Control instance will be temporarely removed from its location if it was being used on another Panel until that Panel will be shown again.
    /// </summary>
    /// <param name="pPanelID">The destination Panel ID.</param>
    /// <param name="pColumn">The destination Column number. (starting with 1)</param>
    /// <param name="pRow">The destination Row number. (starting with 1)</param>
    /// <param name="pColumnSpan">The destination width in Panel Columns</param>
    /// <param name="pRowSpan">The destination height in Panel Rows</param>
    /// <param name="pControlType">The Type of the Control to show.</param>
    /// <param name="pControlID">The ID of the Control to show.</param>
    procedure ShowControl(pPanelID: Code[20]; pColumn: Integer; pRow: Integer; pColumnSpan: Integer; pRowSpan: Integer; pControlType: Integer; pControlID: Text)
    begin
        iPOS.ShowControl(pPanelID, pColumn, pRow, pColumnSpan, pRowSpan, Enum::"LSC POS Control Type".FromInteger(pControlType), pControlID);
    end;

    /// <summary>
    /// Removes and hides a Control from it's Panel position.
    /// </summary>
    /// <param name="pControlType">The type of the Control to hide.</param>
    /// <param name="pControlID">The ID of the Control to hide.</param>
    procedure HideControl(pControlType: Integer; pControlID: Text)
    begin
        iPOS.HideControl(Enum::"LSC POS Control Type".FromInteger(pControlType), pControlID);
    end;

    /// <summary>
    /// Prompts the User with a Confirm Dialog containing a Question (Message) and returns the Selected Answer (Yes=True, No=False).
    /// </summary>
    /// <param name="Txt">The Message/Question to show in the Confirm Dialog.</param>
    /// <param name="YesDefault">The Default (Focused) button on the Confirm Dialog.</param>
    /// <returns>True if Yes is selected. False if No.</returns>
    procedure PosConfirm(Txt: Text; YesDefault: Boolean): Boolean
    begin
        exit(PosConfirm(Txt, YesDefault, 0));
    end;

    /// <summary>
    /// Prompts the User with a Confirm Dialog containing a Question (Message) and returns the Selected Answer (Yes=True, No=False).
    /// </summary>
    /// <param name="Txt">The Message/Question to show in the Confirm Dialog.</param>
    /// <param name="YesDefault">The Default (Focused) button on the Confirm Dialog.</param>
    /// <param name="TimeoutSeconds">If no activity is detected for the number of seconds, while the dialog is open, the POS will automatically close it after that period. 0 = no timeout. Note that a timeout is not supported for Legacy/Native dialogs.</param>
    /// <returns>True if Yes is selected. False if No.</returns>
    procedure PosConfirm(Txt: Text; YesDefault: Boolean; TimeoutSeconds: Integer): Boolean
    begin
        if not initialized then
            exit;
        exit(iPOS.PosConfirm(AddTimeoutPrefix(Txt, TimeoutSeconds, YesDefault ? 1 : 0), YesDefault));
    end;


    /// <summary>
    /// Prompts the User with a Message Dialog that can be closed by pressing a OK button or using the Enter or Escape Key.
    /// </summary>
    /// <param name="Txt">The Message to show in the Dialog.</param>
    procedure PosMessage(Txt: Text): Boolean
    begin
        exit(PosMessage(Txt, 0));
    end;

    /// <summary>
    /// Prompts the User with a Message Dialog that can be closed by pressing a OK button or using the Enter or Escape Key.
    /// </summary>
    /// <param name="Txt">The Message to show in the Dialog.</param>
    /// <param name="TimeoutSeconds">If no activity is detected for the number of seconds, while the dialog is open, the POS will automatically close it after that period. 0 = no timeout. Note that a timeout is not supported for Legacy/Native dialogs.</param>
    /// <returns>True if Yes is selected. False if No.</returns>
    procedure PosMessage(Txt: Text; TimeoutSeconds: Integer): Boolean
    begin
        if not initialized then
            exit;
        exit(iPOS.PosMessage(AddTimeoutPrefix(Txt, TimeoutSeconds, 0)));
    end;

    local procedure AddTimeoutPrefix(Txt: Text; TimeoutSeconds: Integer; SelectedOption: Integer): Text
    var
        PosCtrlUtils: Codeunit "LSC POS Control Utils";
    begin
        if TimeoutSeconds > 0 then
            Txt := StrSubstNo('<##lstimeout,%1,%2>%3', PosCtrlUtils.IntToTextOfLength(TimeoutSeconds, 5), PosCtrlUtils.IntToTextOfLength(SelectedOption, 1), Txt); // if length parameters are changed, like SelectedOption for StrMenu support, we need to update char offset in CSS
        exit(Txt);
    end;

    /// <summary>
    /// Shows a Message Banner on the POS of the Type specified in the Level parameter. Message will close after the Timeout milliseconds if set greater than 0.
    /// </summary>
    /// <param name="Msg">The Message to show in the Banner</param>
    /// <param name="Level">Type of Banner to show. Error, Warning, Success or Info.</param>
    /// <param name="Timeout">Timeout in milliseconds until Banner automatically closes. If 0 then it shows until User closes it.</param>
    procedure PosMessageBanner(Msg: Text; Level: Enum "LSC POS Message Banner Level"; Timeout: Integer)
    begin
        if not initialized then
            exit;
        iPOS.PosMessageBanner(Msg, Level, Timeout);
    end;

    /// <summary>
    /// Opens the #NUMPAD panel modally to prompt the User for Text Input. "LSC POS Controller".OnNumpadResult Event will return the Input value and result when the Panel Closes.
    /// </summary>
    /// <param name="Caption">The Caption of the Numpad Panel</param>
    /// <param name="DefaultValue">The Default/Start text in the Input Control. Pressing Cancel or Escape will reset the Value to this before closing the Panel.</param>
    /// <param name="Payload">The Payload that will be returned in the OnNumpadResult Event</param>
    procedure OpenNumericKeyboard(Caption: Text; DefaultValue: Text; Payload: Text)
    begin
        iPOS.OpenNumericKeyboard(Caption, DefaultValue, Payload);
    end;

    /// <summary>
    /// Opens the #KEYBOARD panel modally to prompt the User for Text Input. "LSC POS Controller".OnKeyboardResult Event will return the Input value and result when the Panel Closes.
    /// </summary>
    /// <param name="Caption">The Prompt of the Input Control on the Keybaord Panel</param>
    /// <param name="DefaultValue">The Default/Start text in the Input Control. Pressing Cancel or Escape will reset the Value to this before closing the Panel.</param>
    /// <param name="UsePasswordChar">Set to true to have the input masked with asterisk character.</param>
    /// <param name="Payload">The Payload that will be returned in the OnKeyboardResult Event</param>
    /// <param name="MaxLength">Maximum length of the input.</param>
    procedure OpenAlphabeticKeyboard(Caption: Text; DefaultValue: Text; UsePasswordChar: Boolean; Payload: Text; Maxlength: Integer)
    begin
        iPOS.OpenAlphabeticKeyboard(Caption, DefaultValue, UsePasswordChar, Payload, Maxlength);
    end;

    /// <summary>
    /// Opens the #CALENDAR panel modally to prompt the User for Date Selection. "LSC POS Controller".OnCalendarResult Event will return the Input value and result when the Panel Closes.
    /// </summary>
    /// <param name="Caption">Will replace the "DTPCaption" POS Tag on a Button if used.</param>
    /// <param name="DefaultValue">The Default/Start Date in the Calendar Menu.</param>
    /// <param name="Payload">The Payload that will be returned in the OnCalendarResult Event</param>
    procedure OpenCalendar(Caption: Text[50]; DefaultValue: DateTime; Payload: Text)
    begin
        iPOS.OpenCalendar(Caption, DefaultValue, Payload);
    end;

    /// <summary>
    /// Returns the Selected Date in the #CALENDAR Menu on the POS.
    /// </summary>
    procedure GetSelectedDate(): DateTime
    begin
        exit(iPOS.GetSelectedDate);
    end;

    /// <summary>
    /// Sets the Selected Date in the #CALENDAR Menu on the POS.
    /// </summary>
    /// <param name="DateTimeIn">The Date to select</param>
    procedure SetSelectedDate(DateTimeIn: DateTime)
    begin
        iPOS.SetSelectedDate(DateTimeIn);
    end;

    /// <summary>
    /// Not Used (Would Display a temporary "working on it" Message, hasn't been available/requested since WinPOS)
    /// </summary>
    /// <param name="pText">The message to show in the dialog</param>
    procedure ScreenDisplay(pText: Text)
    begin
        //TODO CEN-4397 -- this works.. need to test and add option to turn it off in Func.or Interface Profile
        // if (pText = '') and ScreenDisplayOpen then begin
        //     ScreenDisplayDialog.Close();
        //     ScreenDisplayOpen := false;
        // end else begin
        //     ScreenDisplayDialog.Open(pText);
        //     ScreenDisplayOpen := true;
        // end;
    end;

    /// <summary>
    /// Posts (Runs) a POS Command with the specified Parameter on the POS Client. It will run as soon as the Client gets a change to Run it.
    /// </summary>
    /// <param name="pCommand">The POS Command to Run</param>
    /// <param name="pParameter">The Parameter of the POS Command</param>
    procedure PostCommand(pCommand: Enum "LSC POS Command"; pParameter: Text)
    begin
        PostCommand(pCommand, pParameter, '');
    end;

    /// <summary>
    /// Posts (Runs) a POS Command with the specified Parameter on the POS Client. It will run as soon as the Client gets a change to Run it.
    /// </summary>
    /// <param name="pCommand">The POS Command to Run</param>
    /// <param name="pParameter">The Parameter of the POS Command</param>
    /// <param name="pControlID">The target ControlID (uses active Control if empty)</param>
    procedure PostCommand(pCommand: Enum "LSC POS Command"; pParameter: Text; pControlID: Text)
    begin
        PostCommand(pCommand, pParameter, pControlID, '');
    end;

    /// <summary>
    /// Posts (Runs) a POS Command with the specified Parameter on the POS Client. It will run as soon as the Client gets a change to Run it.
    /// </summary>
    /// <param name="pCommand">The POS Command to Run</param>
    /// <param name="pParameter">The Parameter of the POS Command</param>
    /// <param name="pControlID">The target ControlID (uses active Control if empty)</param>
    /// <param name="pPanelID">The ID of the  POS Panel that needs to be Active for the POS Command event to trigger</param>
    procedure PostCommand(pCommand: Enum "LSC POS Command"; pParameter: Text; pControlID: Text; pPanelID: Text)
    begin
        if pControlID <> '' then
            pParameter := StrSubstNo('[%1]%2', pControlID, pParameter);
        PostEvent('RUNCOMMAND', Format(pCommand), pParameter, pPanelID);
    end;

    /// <summary>
    /// A generic function to execute commands on the POS.
    /// Basically only used to run POS Commands with 'RUNCOMMAND' as pValue1, the "POS Command" as pValue2 and "POS Parameter" as pValue3.
    /// pValue4 can also be used to specify the "POS Panel" that needs to be Active for the POS Command to Trigger.
    /// </summary>
    procedure PostEvent(pValue1: Text; pValue2: Text; pValue3: Text; pValue4: Text)
    begin
        if not initialized then
            exit;

        iPOS.PostEvent(pValue1, pValue2, pValue3, pValue4);
    end;

    /// <summary>
    /// If set to true Menus on the POS can be Designed at Runtime. Basically is set true if user is SuperUser.
    /// </summary>
    /// <param name="pDesignMode">Set True if POS Menus should be Designed at Runtime</param>
    procedure SetPosMenuDesignMode(pDesignMode: Boolean)
    begin
        iPOS.SetPosDesignMode(pDesignMode);
    end;

    /// <summary>
    /// Menus uploaded with UploadMenuHeaderRec and UploadMenuLineRec will be tagged with this Tag and can be removed with the DeleteDataByTag function accordingly.
    /// </summary>
    /// <param name="pDataTag">The Tag text</param>
    procedure SetDataTag(pDataTag: Text)
    begin
        iPOS.SetDataTag(pDataTag);
    end;

    /// <summary>
    /// Deletes all uploaded Menus that have the corresponding Tag.
    /// </summary>
    /// <param name="pDataTag">The Tag text</param>
    procedure DeleteDataByTag(pDataTag: Text): Integer
    begin
        exit(iPOS.DeleteDataByTag(pDataTag));
    end;

    /// <summary>
    /// Prompts user to select one of the Options in the OptionString. Currently calls the StrMenu AL Function, if GUI is allowed.
    /// </summary>
    /// <param name="OptionCaption">Uses AL Dialog.StrMenu InstructionText if not empty.</param>
    /// <param name="OptionString">The OptionString that will be used in StrMenu.</param>
    /// <param name="OptionAlignment">Legacy: Not supported by StrMenu.</param>
    /// <param name="ShowCancel">Legacy: Not supported by StrMenu.</param>
    procedure SelectOption(OptionCaption: Text; OptionString: Text; OptionAlignment: Integer; ShowCancel: Boolean): Integer
    begin
        exit(iPOS.SelectOption(OptionCaption, OptionString, OptionAlignment, ShowCancel));
    end;

    /// <summary>
    /// Sets the Primary and Secondary Interface Profiles on the Control Library (Runtime change for the Active Client). Does not change the Session Profiles.
    /// </summary>
    /// <param name="pPrimaryProfileID">The ID of the Primary Profile</param>
    /// <param name="pSecondaryProfileID">The ID of the Secondary Profile</param>
    procedure SetPosCtrlActiveInterfaceProfile(pPrimaryProfileID: Text; pSecondaryProfileID: Text)
    begin
        iPOS.SetPosCtrlActiveInteraceProfile(pPrimaryProfileID, pSecondaryProfileID);
    end;

    /// <summary>
    /// Sets the Primary and Secondary Menu Profiles on the Control Library (Runtime change for the Active Client). Does not change the Session Profiles.
    /// </summary>
    /// <param name="pPrimaryProfileID">The ID of the Primary Profile</param>
    /// <param name="pSecondaryProfileID">The ID of the Secondary Profile</param>
    procedure SetPosCtrlActiveMenuProfile(pPrimaryProfileID: Text; pSecondaryProfileID: Text)
    begin
        iPOS.SetPosCtrlActiveMenuProfile(pPrimaryProfileID, pSecondaryProfileID);
    end;

    /// <summary>
    /// Sets the Primary and Secondary Style Profiles on the Control Library (Runtime change for the Active Client). Does not change the Session Profiles.
    /// </summary>
    /// <param name="pPrimaryProfileID">The ID of the Primary Profile</param>
    /// <param name="pSecondaryProfileID">The ID of the Secondary Profile</param>
    procedure SetPosCtrlActiveStyle(pPrimaryProfileID: Text; pSecondaryProfileID: Text)
    begin
        iPOS.SetPosCtrlActiveStyle(pPrimaryProfileID, pSecondaryProfileID);
    end;

    /// <summary>
    /// Sets the Auto Logoff Timeout in minutes. If the POS is idle for the specified timeout it will invoke a LOGOFF if a Staff is logged on.
    /// </summary>
    /// <param name="Timeout">The Timout in minutes.</param>
    procedure SetAutoLogoffTimeout(Timeout: Integer)
    begin
        if not initialized then
            exit;
        iPOS.SetAutoLogoffTimeout(Timeout);
    end;

    #EndRegion POS Functions

    #Region Hardware //Move to "LSC POS Hardware Interface"?

    /// <summary>
    /// Uploads the specified Hardware Profile's devices and settings to the POS client.
    /// </summary>
    /// <param name="pHardwareProfileID">The Hardware Profile to upload.</param>
    procedure UploadHardwareProfile(pHardwareProfileID: Code[10])
    begin
        iPOS.UploadHardwareProfile(pHardwareProfileID);
    end;

    /// <summary>
    /// Uploads the specified Hardware Profile's devices and settings to the POS client.
    /// </summary>
    /// <param name="pHardwareProfileID">The Hardware Profile to upload.</param>
    procedure RefreshHardwareProfile(pHardwareProfileID: Code[10])
    begin
        iPOS.RefreshHardwareProfile(pHardwareProfileID);
    end;

    /// <summary>
    /// Calls the Write function of the specified SerialDevice (on Hardware Station).
    /// </summary>
    /// <param name="pDevice">The ID of the Serial Device.</param>
    /// <param name="pValue">The Text to Write.</param>
    procedure SerialDeviceWrite(pDeviceID: Text; pValue: Text): Boolean
    begin
        exit(iPOS.WriteToSerialPortDevice(pDeviceID, pValue));
    end;

    #EndRegion Hardware

    #Region Menu

    /// <summary>
    /// Refreshes the specified Menu on the POS. Setup of the Menu will be read from Database and sent to the Client. This will remove all runtime changes that have been done to the Menu.
    /// </summary>
    /// <param name="pMenuProfileID">The Menu Profile of the Menu</param>
    /// <param name="pMenuID">The Menu to refresh.</param>
    procedure RefreshMenu(pMenuProfileID: Code[10]; pMenuID: Code[20])
    begin
        iPOS.RefreshMenu(pMenuProfileID, pMenuID);
    end;

    /// <summary>
    /// Refreshes the specified Menu Button on the POS. Setup of the Menu Button will be read from Database and sent to the Client. This will remove all runtime changes that have been done to the Menu Button.
    /// </summary>
    /// <param name="pMenuProfileID">The Menu Profile of the Menu</param>
    /// <param name="pMenuID">The Menu of the Button.</param>
    /// <param name="pButtonNo">The Menu Button to Refresh. ("Key No." of the "POS Menu Line" Record)</param>
    procedure RefreshMenuButton(pMenuProfileID: Code[10]; pMenuID: Code[20]; pButtonNo: Integer)
    begin
        iPOS.RefreshMenuButton(pMenuProfileID, pMenuID, pButtonNo);
    end;

    /// <summary>
    /// Uploads (adds and replaces) a set of "LSC POS Menu Header" Records (temporary or not) to the POS Control Library.
    /// </summary>
    /// <param name="pTempMenuHeader">The "LSC POS Menu Header" Records to upload.</param>
    /// <param name="pProfileIDFilter">The Menu Profile ID Filter to apply before processing the Records.</param>
    /// <param name="pMenuIDFilter">The Menu ID Filter to apply before processing the Records.</param>
    procedure UploadMenuHeaderRec(var pTempMenuHeader: Record "LSC POS Menu Header"; pProfileIDFilter: Text; pMenuIDFilter: Text)
    begin
        iPOS.UploadMenuHeaderRec(pTempMenuHeader, pProfileIDFilter, pMenuIDFilter);
    end;

    /// <summary>
    /// Uploads (adds and replaces) a set of "LSC POS Menu Line" Records (temporary or not) to the POS Control Library.
    /// </summary>
    /// <param name="pTempMenuLines">The "LSC POS Menu Line" Records to upload.</param>
    /// <param name="pProfileIDFilter">The Menu Profile ID Filter to apply before processing the Records.</param>
    /// <param name="pMenuIDFilter">The Menu ID Filter to apply before processing the Records.</param>
    /// <param name="pButtonKeyFilter">The Menu Line Key (Button Number) Filter to apply before processing the Records.</param>
    procedure UploadMenuLineRec(var pTempMenuLines: Record "LSC POS Menu Line"; pProfileIDFilter: Text; pMenuIDFilter: Text; pButtonKeyFilter: Text)
    begin
        iPOS.UploadMenuLineRec(pTempMenuLines, pProfileIDFilter, pMenuIDFilter, pButtonKeyFilter);
    end;

    /// <summary>
    /// Shows a Menu on the specified Button Pad Control. Existing Menu(s) will be replaced.
    /// </summary>
    /// <param name="pMenuID">The Menu to show.</param>
    /// <param name="pButtonPadID">The ButtonPad to show the Menu on.</param>
    procedure ShowMenu(pMenuID: Code[20]; pButtonPadID: Code[20])
    begin
        iPOS.ShowMenu(pMenuID, pButtonPadID);
        OnAfterShowMenu(pMenuID);
    end;

    /// <summary>
    /// Stacks a Menu on the specified Button Pad Control (Same as IMENU POS Command). Existing Menu will exist under the stacked Menu and will show again when the stacked menu is Closed. (CANCEL POS Command needed on the Stacked Menu).
    /// </summary>
    /// <param name="pMenuID">The Menu to stack/show.</param>
    /// <param name="pButtonPadID">The ButtonPad to stack the Menu on.</param>
    procedure StackMenu(pMenuID: Code[20]; pButtonPadID: Code[20])
    begin
        iPOS.StackMenu(pMenuID, pButtonPadID);
    end;

    /// <summary>
    /// Pops a stacked Menu of a Button Pad (same as CANCEL POS Command on the Menu).
    /// </summary>
    /// <param name="pButtonPadID">The ButtonPad Control to pop a menu of.</param>
    procedure PopMenu(pButtonPadID: Code[20])
    begin
        iPOS.PopMenu(pButtonPadID);
    end;

    /// <summary>
    /// Shows a Menu in a POPUP Panel that will be closed automatically after processing the first Button Press. (Same as POPUP POS Command)
    /// </summary>
    /// <param name="pMenu">The Menu to Pop-up</param>
    procedure PopupMenu(pMenu: Code[20])
    begin
        iPOS.PopupMenu(pMenu);
    end;

    /// <summary>
    /// Sets the Main Caption or Glyph Text of a Menu Button.
    /// </summary>
    /// <param name="menuID">The ID of the Menu.</param>
    /// <param name="buttonNo">The Number (Key) of the Button (LSC POS Menu Line).</param>
    /// <param name="captionNo">The Caption Number (0 = Main Caption, 1 = Glyph1, 2 = Glyph2, 3 = Glyph3 and 4 = Glyph4.</param>
    /// <param name="newValue">The Caption/Text to set.</param>
    procedure SetButtonCaption(menuID: Code[20]; buttonNo: Integer; captionNo: Integer; newValue: Text)
    begin
        iPOS.SetButtonCaption(menuID, buttonNo, "LSC Button Caption Type".FromInteger(captionNo), newValue);
    end;

    /// <summary>
    /// Gets the Caption text of a Menu Button.
    /// </summary>
    /// <param name="menuID">The ID of the Menu.</param>
    /// <param name="buttonNo">The Number (Key) of the Button (LSC POS Menu Line).</param>
    /// <param name="captionNo">The Caption Number (0 = Main Caption, 1 = Glyph1, 2 = Glyph2, 3 = Glyph3 and 4 = Glyph4.</param>
    procedure GetButtonCaption(menuID: Code[20]; buttonNo: Integer; captionNo: Integer): Text
    begin
        exit(iPOS.GetButtonCaption(menuID, buttonNo, "LSC Button Caption Type".FromInteger(captionNo)));
    end;

    /// <summary>
    /// Enables or Disables a Menu Button.
    /// </summary>
    /// <param name="menuID">The ID of the Menu.</param>
    /// <param name="buttonNo">The Number (Key) of the Button (LSC POS Menu Line).</param>
    /// <param name="newValue">Set True to Enable, False to Disable.</param>
    procedure SetButtonEnabled(menuID: Code[20]; buttonNo: Integer; newValue: Boolean)
    begin
        iPOS.SetButtonEnabled(menuID, buttonNo, newValue);
    end;

    /// <summary>
    /// Toggles the Highlighted state of a Menu Button (Gives it a Darkened/Pressed state).
    /// </summary>
    /// <param name="menuID">The ID of the Menu.</param>
    /// <param name="buttonNo">The Number (Key) of the Button (LSC POS Menu Line).</param>
    /// <param name="newValue">Set True to toggle ON, False to toggle OFF.</param>
    procedure SetButtonHighlighted(menuID: Code[20]; buttonNo: Integer; newValue: Boolean)
    begin
        iPOS.SetButtonHighlighted(menuID, buttonNo, newValue);
    end;

    /// <summary>
    /// Deletes a Menu Button on the POS and from the Control Library (Runtime State). Does NOT Delete the "LSC POS Menu Line" Record.
    /// </summary>
    /// <param name="pMenuProfileID">Not Used</param>
    /// <param name="pMenuID">The ID of the Menu.</param>
    /// <param name="pButtonNo">The Number of the Button.</param>
    procedure DeleteMenuButton(pMenuProfileID: Code[10]; pMenuID: Code[20]; pButtonNo: Integer)
    begin
        if not initialized then
            exit;
        iPOS.DeleteMenuButton(pMenuProfileID, pMenuID, pButtonNo);
    end;

    /// <summary>
    /// Puts the specified Menu in design Mode. If the layout type is XY buttons can be moved and resized on the Menu. 
    /// </summary>
    /// <param name="pMenuID">The ID of the Menu.</param>
    /// <param name="pDesignMode">Set True to enable design, false to disable it.</param>
    procedure SetMenuDesignMode(pMenuID: Code[20]; pDesignMode: Boolean)
    begin
        iPOS.SetMenuDesignMode(pMenuID, pDesignMode);
    end;

    /// <summary>
    /// Sets the Layout of a Menu. Grid (Default) arranges Buttons in a Grid (Rows and Columns). In XY Layout each button has its own Position in pixels.
    /// </summary>
    /// <param name="pMenuID">The ID of the Menu.</param>
    /// <param name="pLayoutStyle">Grid or XY.</param>
    procedure SetMenuLayoutStyle(pMenuID: Code[20]; pLayoutStyle: Option "Grid",XY)
    begin
        iPOS.SetMenuLayoutStyle(pMenuID, pLayoutStyle);
    end;

    /// <summary>
    /// Puts the Menu into DragDrop Mode. POSEvent (DRAGDROP) is sent on Drop of Button (IntData1 = From Button, IntData3 = To Button).
    /// </summary>
    /// <param name="pMenuID">The ID of the Menu.</param>
    /// <param name="pEnabled">True to Enable DragDrop. False to Disable it.</param>
    procedure SetMenuDragDropEnabled(pMenuID: Code[20]; pEnabled: Boolean)
    begin
        iPOS.SetMenuDragDropEnabled(pMenuID, pEnabled);
    end;

    /// <summary>
    /// Saves changes Size and Position of Buttons in a Menu (XY Layout). Updates the XPos, YPos, Width and Height fields. NOTE that Layout of Menu must be XY and "Notify Button Coords Changed" must be true for this to work.
    /// </summary>
    /// <param name="pMenuID">The ID of the Menu.</param>
    procedure SaveMenuModifications(pMenuID: Code[20])
    begin
        // TODO: LSC-37169 When using Layout XY .. only first Button seems to get loaded when POS Starts. Go into Menu Properties and Back gets all Buttons visible. (Completed this function to actually Save the modifications to the Menu in the DataBase.)
        iPOS.SaveMenuModifications(pMenuID);
    end;

    /// <summary>
    /// Writes Size and Position changes of Buttons in Menu (XY Layout) to the specified posmenuline Record (XPos, YPos, Width and Height fields). NOTE that Layout of Menu must be XY and "Notify Button Coords Changed" must be true for this to work.
    /// </summary>
    /// <param name="pMenuID">The ID of the Menu.</param>
    /// <param name="pPosMenuLine">The "LSC Pos Menu Line" Record variable to write to.</param>
    /// <param name="pAllowInsert">If true then Buttons (POS Menu Line) will be added to the pPosMenuLine RecordSet if they dont exist.</param>
    /// <param name="pClearModifications">If true then all "saved" modifications are cleared from the Control Library afterwards.</param>
    procedure SaveMenuModificationsEx(pMenuID: Code[20]; var pPosMenuLine: Record "LSC POS Menu Line"; pAllowInsert: Boolean; pClearModifications: Boolean)
    begin
        iPOS.SaveMenuModificationsEx(pMenuID, pPosMenuLine, pAllowInsert, pClearModifications);
    end;

    /// <summary>
    /// Writes Size and Position changes of a single Button in Menu (XY Layout) to the specified posmenuline Record (XPos, YPos, Width and Height fields).
    /// </summary>
    /// <param name="pPosMenuLine">The "LSC Pos Menu Line" Record variable to write to.</param>
    procedure GetMenuLineModifications(var pPosMenuLine: Record "LSC POS Menu Line")
    begin
        iPOS.GetMenuLineModifications(pPosMenuLine);
    end;

    /// <summary>
    /// Sets (overwrites) what button is the Selected Button in a Menu. Like it was the last Button Pressed in that Menu.
    /// </summary>
    /// <param name="pMenuID">The ID of the Menu.</param>
    /// <param name="pButtonNo">The Number of the Button (Key Field of the "LSC POS Menu Line" Record).</param>
    procedure SetSelectedButton(pMenuID: Code[20]; pButtonNo: Integer)
    begin
        iPOS.SetSelectedButton(pMenuID, pButtonNo);
    end;

    /// <summary>
    /// Gets the Selected Button in a Menu. Last Button Pressed or Button Selected with SetSelectedButton function.
    /// </summary>
    /// <param name="pMenuID">The ID of the Menu.</param>
    procedure GetSelectedButton(pMenuID: Code[20]): Integer
    begin
        exit(iPOS.GetSelectedButton(pMenuID));
    end;

    /// <summary>
    /// Joins 2 Buttons by drawing a Line Between them.
    /// </summary>
    /// <param name="pMenuID">The ID of the Menu.</param>
    /// <param name="pSlaveButtonNo"></param>
    /// <param name="pMasterButtonNo"></param>
    procedure JoinButtons(pMenuID: Code[20]; pSlaveButtonNo: Integer; pMasterButtonNo: Integer)
    begin
        // TODO: LSC-37170 JoinButtons works first time. If I go to Menu Design the Joins are gone?.. and dont come back and cannot get them back.. must restart POS and add join again.
        // Check if this is working correctly also. I think in Windows Client if you dragged the Master button the Slave buttons would be dragged with them?
        // Also when Designing (Resize and Move) the Joins (connections) are maintained and line is drawn etc.
        iPOS.JoinButtons(pMenuID, pSlaveButtonNo, pMasterButtonNo);
    end;

    /// <summary>
    /// DisJoins 2 Buttons. Removes the line/connection between the Master and Slave Button.
    /// </summary>
    /// <param name="pMenuID">The ID of the Menu.</param>
    /// <param name="pSlaveButtonNo"></param>
    /// <param name="pMasterButtonNo"></param>
    procedure DisJoinButtons(pMenuID: Code[20]; pSlaveButtonNo: Integer; pMasterButtonNo: Integer)
    begin
        iPOS.DisJoinButtons(pMenuID, pSlaveButtonNo, pMasterButtonNo);
    end;

    /// <summary>
    /// If called while processing a Command of a Button (POS Menu Line) the Post Command of the Button will not be invoked.
    /// </summary>
    procedure IgnorePostCommand()
    begin
        iPOS.IgnorePostCommand();
    end;

    /// <summary>
    /// Updates a Menu Button with the specified Button Skin.
    /// </summary>
    /// <param name="ProfileID">Not used.</param>
    /// <param name="MenuID">The ID of the Menu.</param>
    /// <param name="ButtonNo">The Button Number.</param>
    /// <param name="FieldList">A List of the Field Nos to update.</param>
    procedure UpdateButtonSkin(ProfileID: Code[20]; MenuID: Code[20]; ButtonNo: Integer; var Skin: Record "LSC POS Button Skin"; FieldList: List of [Integer])
    begin
        iPOS.UpdateButtonSkin(ProfileID, MenuID, ButtonNo, Skin, FieldList);
    end;

    /// <summary>
    /// Updates a Menu Button with the Border and/or Shape of a Button Skin.
    /// </summary>
    /// <param name="ProfileID">Not used.</param>
    /// <param name="MenuID">The ID of the Menu.</param>
    /// <param name="ButtonNo">The Button Number.</param>
    /// <param name="UpdateShape">Will update the Button Shape.</param>
    /// <param name="UpdateBorder">Will update the Button Border Color and Border Width.</param>
    procedure UpdateButtonShapeAndBorder(ProfileID: Code[20]; MenuID: Code[20]; ButtonNo: Integer; var Skin: Record "LSC POS Button Skin"; UpdateShape: Boolean; UpdateBorder: Boolean)
    var
        FieldsList: List of [Integer];
    begin
        if UpdateShape then
            FieldsList.Add(Skin.FieldNo("Shape")); // 3
        if UpdateBorder then
            FieldsList.AddRange(
                Skin.FieldNo("Border Color"), // 7
                Skin.FieldNo("Border Width") // 31
            );
        UpdateButtonSkin(ProfileID, MenuID, ButtonNo, Skin, FieldsList);
    end;

    #EndRegion Menu

    #Region Panel

    /// <summary>
    /// Refreshes the Panels with the specified Panel ID Filter. Any runtime changes to these Panels Layout and Control Positions will be lost.
    /// </summary>
    /// <param name="pInterfaceProfileIDFilter">Not Used.</param>
    /// <param name="pPanelIDFilter">The Panels within this filter will be Re-loaded.</param>
    procedure RefreshPosPanels(pInterfaceProfileIDFilter: Text; pPanelIDFilter: Text)
    begin
        iPOS.RefreshPosPanels(pInterfaceProfileIDFilter, pPanelIDFilter);
    end;

    /// <summary>
    /// Refreshes the specified POS Panel in the POS UI.
    /// </summary>
    /// <param name="pInterfaceProfileID">Not Used.</param>
    /// <param name="pPanelID">The POS Panel to refresh.</param>
    /// <param name="pMenuProfileID">Not Used.</param>
    procedure RefreshPosPanel(pInterfaceProfileID: Text; pPanelID: Text; pMenuProfileID: Text)
    begin
        iPOS.RefreshPosPanel(pInterfaceProfileID, pPanelID, pMenuProfileID);
    end;

    /// <summary>
    /// Uploads (adds and replaces) a set POS Panels with Layout and Controls to the POS Control Library.
    /// </summary>
    /// <param name="pPosPanelRec">The "LSC POS Panel" Records to upload.</param>
    /// <param name="pPosPanelRowColumnRec">The "LSC POS Panel Row/Column" Records to upload. These Records control the layout of the Panel</param>
    /// <param name="pPosPanelControlRec">The "LSC POS Panel Control Line" Records to upload. These Records specify the Controls and their Locations on the Panel</param>
    /// <param name="pProfileIDFilter">The Interface Profile ID Filter to apply before processing the Records.</param>
    /// <param name="pPanelFilter">The Panel ID Filter to apply before processing the Records.</param>
    procedure UploadPosPanel(var pPosPanelRec: Record "LSC POS Panel"; var pPosPanelRowColumnRec: Record "LSC POS Panel Row/Column"; var pPosPanelControlRec: Record "LSC POS Panel Control Line"; pProfileIDFilter: Text; pPanelFilter: Text)
    begin
        iPOS.UploadPosPanel(pPosPanelRec, pPosPanelRowColumnRec, pPosPanelControlRec, pProfileIDFilter, pPanelFilter);
    end;

    /// <summary>
    /// Refreshes the POS Panel specified in the pPanelID variable.
    /// </summary>
    /// <param name="pInterfaceProfileIDFilter">Not used.</param>
    /// <param name="pPanelID">The Panel to refresh.</param>
    /// <param name="pMenuProfileIDFilter">Not used.</param>
    procedure UploadPosPanelControlsEx(pInterfaceProfileIDFilter: Text; pPanelID: Text; pMenuProfileIDFilter: Text)
    begin
        iPOS.UploadPosPanelControlsEx(pInterfaceProfileIDFilter, pPanelID, pMenuProfileIDFilter);
    end;

    /// <summary>
    /// Uploads (adds and replaces) a set of "LSC POS Panel" Records to the POS Control Library.
    /// </summary>
    /// <param name="pPosPanelRec">The "LSC POS Panel" Records to upload.</param>
    /// <param name="pProfileIDFilter">The Interface Profile ID Filter to apply before processing the Records.</param>
    /// <param name="pPanelFilter">The Panel ID Filter to apply before processing the Records.</param>
    procedure UploadPosPanelRec(var pPosPanelRec: Record "LSC POS Panel"; pProfileIDFilter: Text; pPanelFilter: Text)
    begin
        iPOS.UploadPosPanelRec(pPosPanelRec, pProfileIDFilter, pPanelFilter);
    end;

    /// <summary>
    /// Updates the Layout of a POS Panel by uploading a set of "LSC POS Panel Row/Column" Records to the POS Control Library.
    /// </summary>
    /// <param name="pPosPanelRowColumnRec">The "LSC POS Panel Row/Column" Records to upload.</param>
    /// <param name="pProfileIDFilter">The Interface Profile ID Filter to apply before processing the Records.</param>
    /// <param name="pPanelFilter">The Panel ID Filter to apply before processing the Records.</param>
    procedure UploadPosPanelRowColumnsRec(var pPosPanelRowColumnRec: Record "LSC POS Panel Row/Column"; pProfileIDFilter: Text; pPanelFilter: Text)
    begin
        iPOS.UploadPosPanelRowColumnsRec(pPosPanelRowColumnRec, pProfileIDFilter, pPanelFilter);
    end;

    /// <summary>
    /// Updates the Layout of a POS Panel by uploading a set of "LSC POS Panel Row/Column" Records to the POS Control Library.
    /// </summary>
    /// <param name="pPosPanelRowColumnRec">The "LSC POS Panel Row/Column" Records to upload.</param>
    /// <param name="pProfileIDFilter">The Interface Profile ID Filter to apply before processing the Records.</param>
    /// <param name="pPanelFilter">The Panel ID Filter to apply before processing the Records.</param>
    procedure UploadPosPanelControlsRec(var pPosPanelControlRec: Record "LSC POS Panel Control Line"; pProfileIDFilter: Text; pPanelFilter: Text; pMerge: Boolean)
    begin
        iPOS.UploadPosPanelControlsRec(pPosPanelControlRec, pProfileIDFilter, pPanelFilter, pMerge);
    end;

    /// <summary>
    /// Shows a Panel on the POS.
    /// </summary>
    /// <param name="pPanelID">The Panel to show.</param>
    procedure ShowPanel(pPanelID: Code[20])
    begin
        iPOS.ShowPanel(pPanelID);
    end;

    /// <summary>
    /// Shows a Modal Panel on the POS.
    /// </summary>
    /// <param name="pPanelID">The Panel to show.</param>
    procedure ShowPanelModal(pPanelID: Code[20])
    begin
        ShowPanelModal(pPanelID, '');
    end;

    /// <summary>
    /// Shows a Modal Panel on the POS with specified payload that will be return in the "LSC POS Controller".OnModalPanelResult Event when the Panel is closed.
    /// </summary>
    /// <param name="pPanelID">The Panel to show.</param>
    /// <param name="pPayload">The Payload that will be returned in the OnModalPanelResult event</param>
    procedure ShowPanelModal(pPanelID: Code[20]; pPayload: Text)
    begin
        iPOS.ShowPanelModal(pPanelID, pPayload);
    end;

    /// <summary>
    /// Hides or Closes a POS Panel.
    /// </summary>
    /// <param name="pPanelID">The ID of the Panel.</param>
    /// <param name="pDialogResultOK">If the Panel is running Modal this will set the Dialog Result when the Panel is Closed.</param>
    procedure HidePanel(pPanelID: Code[20]; pDialogResultOK: Boolean)
    begin
        iPOS.HidePanel(pPanelID, pDialogResultOK);
    end;

    /// <summary>
    /// Returns the ID of the Active Panel on the POS
    /// </summary>
    procedure ActivePanel(): Code[20]
    begin
        if not initialized then
            exit('');

        exit(iPOS.ActivePanel());
    end;

    /// <summary>
    /// Register a Panel to send a QUERYPANELCLOSE POS Event when it is trying to Close. DenyPanelClose can then be used to prevent that from happening.
    /// </summary>
    /// <param name="pPanelID">The ID of the Panel to register.</param>
    procedure RegisterPanelClosedEvent(pPanelID: Code[20])
    begin
        iPOS.RegisterPanelClosedEvent(pPanelID);
    end;

    /// <summary>
    /// This function can be called in response to a QUERYPANELCLOSE POS Event to Prevent the Active Panel from closing. Panel needs to be Registered with the RegisterPanelClosedEvent for it to send the QUERYPANELCLOSE Event when trying to Close.
    /// </summary>
    procedure DenyPanelClose()
    begin
        iPOS.DenyPanelClose();
    end;

    /// <summary>
    /// Updates the number of Columns on the specified Panel.
    /// </summary>
    /// <param name="pPanelID">The ID of the Panel.</param>
    /// <param name="pNewValue">The new number of Columns.</param>
    procedure SetPanelColumns(pPanelID: Text; pNewValue: Integer)
    begin
        iPOS.SetPanelColumns(pPanelID, pNewValue);
    end;

    /// <summary>
    /// Updates the number of Rows on the specified Panel.
    /// </summary>
    /// <param name="pPanelID">The ID of the Panel.</param>
    /// <param name="pNewValue">The new number of Rows.</param>
    procedure SetPanelRows(pPanelID: Text; pNewValue: Integer)
    begin
        iPOS.SetPanelRows(pPanelID, pNewValue);
    end;

    #EndRegion Panel

    #Region Input

    /// <summary>
    /// Refreshes the specified Input Control in the POS UI.
    /// </summary>
    /// <param name="pInterfaceProfileID">Not Used.</param>
    /// <param name="pInputID">The Input Control to refresh.</param>
    procedure RefreshPosInput(pInterfaceProfileID: Code[10]; pInputID: Code[20])
    begin
        iPOS.RefreshPosInput(pInterfaceProfileID, pInputID);
    end;

    /// <summary>
    /// Displays a Text in a Input Control (Textbox).
    /// </summary>
    /// <param name="pInputID">The ID of the Input Control.</param>
    /// <param name="pInputText">The Text to be displayed in the Control</param>
    procedure SetInputText(pInputID: Code[20]; pInputText: Text)
    begin
        iPOS.SetInputText(pInputID, pInputText);
    end;

    /// <summary>
    /// Returns the Text being displayed in an Input Control.
    /// </summary>
    /// <param name="pInputID">The ID of the Input Control.</param>
    procedure GetInputText(pInputID: Code[20]): Text
    begin
        exit(iPOS.GetInputText(pInputID));
    end;

    /// <summary>
    /// Activates (focuses) an Input Control.
    /// </summary>
    /// <param name="pInputID">The ID of the Input Control</param>
    procedure ActivateInput(pInputID: Code[20])
    begin
        iPOS.ActivateInput(pInputID);
    end;

    #EndRegion Input

    #Region DataGrid

    /// <summary>
    /// Refreshes the specified POS Data Grid Control in the POS UI. Filters and sorting should remain intact.
    /// </summary>
    /// <param name="pInterfaceProfileID">Not used.</param>
    /// <param name="pGridID">The Data Grid to Refresh</param>
    procedure RefreshDataGridControl(pInterfaceProfileID: Code[10]; pGridID: Code[20])
    begin
        iPOS.RefreshDataGridControl(pInterfaceProfileID, pGridID);
    end;

    /// <summary>
    /// Same as GetDataGridMarkedRecords. Gets the Marked (Selected) RecordIDs of a DataGrid Control.
    /// </summary>
    /// <param name="pDataGridID">The ID of the DataGrid Control.</param>
    /// <param name="pRemoveMarks">Set true to clear the Marked Records after they are added to the JsonArray.</param>
    /// <param name="pMarkedRecordIDs">The JsonArray that will contain the Marked RecordIDs.</param>
    procedure GetMarkedRecords(pDataGridID: Code[20]; pRemoveMarks: Boolean; var pMarkedRecordIDs: JsonArray)
    begin
        GetDataGridMarkedRecords(pDataGridID, pMarkedRecordIDs, pRemoveMarks);
    end;

    /// <summary>
    /// Returns the Number of Marked Records in the specified DataGrid Control.
    /// </summary>
    /// <param name="pDataGridID">The ID of the DataGrid Control.</param>
    procedure GetMarkedRecordCount(pDataGridID: Code[20]): Integer
    begin
        exit(iPOS.GetDataGridMarkedRecordCount(pDataGridID));
    end;

    /// <summary>
    /// Gets the RecordID of the specified Marked (Selected) Record in a DataGrid Control.
    /// </summary>
    /// <param name="pDataGridID">The ID of the DataGrid Control.</param>
    /// <param name="pIndex">The index within the Marked Records JsonArray to get.</param>
    /// <param name="pRemoveMark">Set true to Unmark the fetched RecordID.</param>
    /// <returns>The RecordID of the specified Marked Record in Text format.</returns>
    procedure GetMarkedRecord(pDataGridID: Code[20]; pIndex: Integer; pRemoveMark: Boolean): Text
    begin
        exit(iPOS.GetDataGridMarkedRecord(pDataGridID, pIndex, pRemoveMark));
    end;

    /// <summary>
    /// Returns the RecordID of the Active (Focused) Record in the specified DataGrid Control.
    /// </summary>
    /// <param name="pDataGridID">The ID of the Data Grid Control</param>
    /// <returns>The RecordID in Text format</returns>
    procedure GetActiveRecord(pDataGridID: Code[20]): Text
    begin
        exit(iPOS.GetDataGridActiveRecord(pDataGridID));
    end;

    /// <summary>
    /// Sets the Marked (Selected) Records of the specified DataGrid Control
    /// </summary>
    /// <param name="pDataGridID">The ID of the DataGrid Control</param>
    /// <param name="pRecordIDs">A JsonArray of RecordIDs which will become Marked (Selected)</param>
    procedure SetDataGridMarkedRecords(pDataGridID: Code[20]; pRecordIDs: JsonArray)
    begin
        iPOS.SetDataGridMarkedRecords(pDataGridID, pRecordIDs);
    end;

    /// <summary>
    /// Returns the ID of the Active DataGrid if a DataGrid is visible on the POS.
    /// </summary>
    procedure ActiveDataGrid(): Code[20]
    begin
        exit(iPOS.ActiveDataGrid());
    end;

    /// <summary>
    /// Returns the the (Zero Based) Index of the Active (Focused) Row in a DataGrid Control.
    /// </summary>
    /// <param name="pDataGridID">The ID of the DataGrid Control.</param>
    procedure GetDataGridRowIndex(pDataGridID: Text): Integer
    begin
        exit(iPOS.GetDataGridRowIndex(pDataGridID));
    end;

    /// <summary>
    /// Returns the (Zero Based) Index of the Active (Selected) Column in a DataGrid Control.
    /// </summary>
    /// <param name="pDataGridID">The ID of the DataGrid Control.</param>
    procedure GetDataGridColumnIndex(pDataGridID: Text): Integer
    begin
        exit(iPOS.GetDataGridColumnIndex(pDataGridID));
    end;

    /// <summary>
    /// Returns the ID of the DataTable being shown in a DataGrid Control.
    /// </summary>
    /// <param name="pDataGridID">The ID of the DataGrid Control.</param>
    procedure GetGridDataTableID(pDataGridID: Text): Text
    begin
        exit(iPOS.GetGridDataTableID(pDataGridID));
    end;

    /// <summary>
    /// Initializes a DataGrid Control with the specified DataTable.
    /// </summary>
    /// <param name="pDataGridID">The ID of the DataGrid Control.</param>
    /// <param name="pDataTableID">The ID of the DataTable to show in the DataGrid Control.</param>
    procedure InitDataGridControl(pDataGridID: Text; pDataTableID: Text)
    begin
        iPOS.InitDataGridControl(pDataGridID, pDataTableID);
    end;

    /// <summary>
    /// Initializes a DataGrid Control with the specified DataTable and RecordRef.
    /// </summary>
    /// <param name="pDataGridID">The ID of the DataGrid Control.</param>
    /// <param name="pDataTableID">The ID of the DataTable to show in the DataGrid Control.</param>
    /// <param name="pRecRef">A RecordRef pointing to a Record with the data from the Table specified in the DataTable.</param>
    procedure InitDataGridControlEx(pDataGridID: Text; pDataTableID: Text; var pRecRef: RecordRef)
    begin
        iPOS.InitDataGridControlEx(pDataGridID, pDataTableID, pRecRef);
    end;

    /// <summary>
    /// Initializes a DataGrid Control with the specified DataTable and DataTableColumns and RecordRef.
    /// </summary>
    /// <param name="pDataGridID">The ID of the DataGrid Control.</param>
    /// <param name="pDataTable">A DataTable Record to show in the DataGrid Control.</param>
    /// <param name="pDataTableColumns">A DataTableColumns Record that specifies the Columns to show in the DataGrid Control.</param>
    /// <param name="pRecRef">A RecordRef pointing to a Record with the data from the Table specified in the DataTable.</param>
    procedure InitDataGridControlDyn(pDataGridID: Text; var pDataTable: Record "LSC POS Data Table"; var pDataTableColumns: Record "LSC POS Data Table Columns"; var pRecRef: RecordRef)
    begin
        iPOS.InitDataGridControlDyn(pDataGridID, pDataTable, pDataTableColumns, pRecRef);
    end;

    /// <summary>
    /// Activates the specified DataGrid Control. If more than one DataGrid Control is on the Active Panel this function can switch "focus" between them.
    /// </summary>
    /// <param name="pControlID">The ID of the DataGrid Control to make Active.</param>
    procedure SetActiveDataGrid(pControlID: Text)
    begin
        iPOS.SetActiveDataGrid(pControlID);
    end;

    /// <summary>
    /// Returns the Key Value of the Active Record in a DataGrid Control.
    /// </summary>
    /// <param name="pGridID">The ID of the DataGrid Control.</param>
    procedure GetDataGridKeyValue(pGridID: Code[20]): Code[30]
    begin
        exit(iPOS.GetDataGridKeyValue(pGridID));
    end;

    /// <summary>
    /// Gets the RecordID of the the Active Record in a DataGrid Control.
    /// </summary>
    /// <param name="pGridID">The ID of the DataGrid Control.</param>
    procedure GetDataGridRecordID(pGridID: Code[20]; var pRecordID: RecordID): Boolean
    begin
        exit(iPOS.GetDataGridRecordID(pGridID, pRecordID));
    end;

    /// <summary>
    /// Refreshes the Data in a DataGrid Control.
    /// </summary>
    /// <param name="pGridID">The ID of the DataGrid Control.</param>
    procedure RefreshDataGrid(pGridID: Code[20])
    begin
        iPOS.RefreshDataGrid(pGridID);
    end;

    /// <summary>
    /// Gets the Marked (Selected) RecordIDs in a DataGrid Control.
    /// </summary>
    /// <param name="pGridID">The ID of the DataGrid Control.</param>
    /// <param name="pRecordIDs">JsonArray of the RecordIds to change the Marking</param>
    /// <param name="pRemoveMarks">Removes the Marks if set to True</param>
    procedure GetDataGridMarkedRecords(pGridID: Code[20]; var pRecordIDs: JsonArray; pRemoveMarks: Boolean)
    begin
        iPOS.GetDataGridMarkedRecords(pGridID, pRecordIDs, pRemoveMarks);
    end;

    /// <summary>
    /// Unmarkes all marked records in a DataGrid Control.
    /// </summary>
    /// <param name="pGridID">The ID of the DataGrid Control.</param>
    procedure ClearMarkedRecords(pGridID: Code[20])
    begin
        iPOS.ClearDataGridMarkedRecords(pGridID);
    end;

    /// <summary>
    /// Opens a Zoom Control to edit the Active Record in a DataGrid Control.
    /// </summary>
    /// <param name="pGridID">The ID of the DataGrid Control.</param>
    /// <param name="pDataTableID">The ID of the DataTable Setup to use in the Zoom Control.</param>
    procedure EditDataGridRecord(pGridID: Code[20]; pDataTableID: Code[20]): Code[10]
    begin
        exit(iPOS.EditDataGridRecord(pGridID, pDataTableID));
    end;

    /// <summary>
    /// Opens a Zoom Control to view the Active Record in the specified DataGrid Control.
    /// </summary>
    /// <param name="pGridID">The ID of the DataGrid Control.</param>
    /// <param name="pDataTableID">The ID of the DataTable Setup to use in the Zoom Control.</param>
    procedure ZoomDataGridRecord(pGridID: Code[20]; pDataTableID: Code[20]): Code[10]
    begin
        exit(iPOS.ZoomDataGridRecord(pGridID, pDataTableID));
    end;

    /// <summary>
    /// Opens a Zoom Control to Add a new Record to the specified DataGrid Control.
    /// </summary>
    /// <param name="pGridID">The ID of the DataGrid Control.</param>
    /// <param name="pDataTableID">The ID of the DataTable Setup to use in the Zoom Control.</param>
    procedure NewDataGridRecord(pGridID: Code[20]; pDataTableID: Code[20]): Code[10]
    begin
        exit(iPOS.NewDataGridRecord(pGridID, pDataTableID));
    end;

    /// <summary>
    /// Deletes all marked (selected) Records in the specified DataGrid Control.
    /// </summary>
    /// <param name="pGridID">The ID of the DataGrid Control.</param>
    procedure DeleteDataGridRecords(pGridID: Code[20]): Code[10]
    begin
        exit(iPOS.DeleteDataGridRecords(pGridID));
    end;

    /// <summary>
    /// Sets the Server Side Fixed Filters for the specified DataGrid Control.
    /// </summary>
    /// <param name="pGridID">The ID of the DataGrid Control.</param>
    /// <param name="pFieldNo">The Field to filter.</param>
    /// <param name="pFilterText">The filter text.</param>
    procedure SetDataGridFixedFilter(pGridID: Code[20]; pFieldNo: Integer; pFilterText: Text)
    begin
        iPOS.SetDataGridFixedFilter(pGridID, pFieldNo, pFilterText);
    end;

    /// <summary>
    /// Resets the Server Side Fixed Filters for the specified POS Data Grid Control.
    /// </summary>
    /// <param name="pGridID">The ID of the DataGrid to Reset Fixed Filters on.</param>
    procedure ResetDataGridFixedFilters(pGridID: Code[20])
    begin
        iPOS.ResetDataGridFixedFilters(pGridID);
    end;

    /// <summary>
    /// Returns the active Server Side Filters on the Record behind the DataGrid Control.
    /// </summary>
    /// <param name="pGridID">The ID of the DataGrid Control.</param>
    procedure GetDataGridFixedFilter(pGridID: Code[20]): Text
    begin
        exit(iPOS.GetDataGridFixedFilter(pGridID));
    end;

    /// <summary>
    /// Gets the current Record Count of the DataGrid Control. Filters (fixed or not) could apply.
    /// </summary>
    /// <param name="pGridID">The ID of the DataGrid Control.</param>
    procedure GetDataGridRecCount(pGridID: Code[20]): Text
    begin
        exit(iPOS.GetDataGridRecCount(pGridID));
    end;

    /// <summary>
    /// Internally used to force a refresh on the Server Side DataSet behind a DataGrid Control.
    /// </summary>
    /// <param name="pGridID">The ID of the DataGrid Control.</param>
    procedure ClearDataGridCount(pGridID: Code[20])
    begin
        iPOS.ClearDataGridCount(pGridID);
    end;

    /// <summary>
    /// Initializes a DataGrid Control with a "Config DataSet". A DataSet with Schema (Column specification, Counters etc.) but without any Data.
    /// </summary>
    /// <param name="pGridID">The ID of the DataGrid Control.</param>
    /// <param name="pLSDataSet">The "Config DataSet".</param>
    procedure InitGridData(pGridID: Code[20]; var pLSDataSet: Codeunit "LSC DataSet")
    begin
        iPOS.InitGridData(pGridID, pLSDataSet);
    end;

    /// <summary>
    /// Adds Data to a DataGrid Control. This might be used in response to a DataRequest Event from the POS but can also be called independantly.
    /// </summary>
    /// <param name="pGridID">The ID of the DataGrid Control.</param>
    /// <param name="pLSDataSet">The DataSet containg Data for the DataGrid Control.</param>
    procedure AddGridData(pGridID: Code[20]; var pLSDataSet: Codeunit "LSC DataSet")
    begin
        iPOS.AddGridData(pGridID, pLSDataSet);
    end;

    /// <summary>
    /// Hides the Popup DataGrid (show with PopupGridData functions) if necessary.
    /// </summary>
    internal procedure HidePopupGrid()
    begin
        iPOS.HidePopupGrid(); // Note: also handled in-client if something outside of the popup is pressed
    end;

    /// <summary>
    /// Moves the Active Row (Focus) of a DataGrid to the Next Row in the Grid if available. Note that LINE_DN Pos Command works the same for the Active DataGrid.
    /// </summary>
    /// <param name="pGridID">The ID of the DataGrid Control.</param>
    procedure GoToNextRow(pGridID: Code[20])
    begin
        // TODO: LSC-27724 Doesn't seem to always work (Focus is removed from the Grid, No Row is Focused). Should do same as LINE_DN Pos Command 
        iPOS.GoToNextRow(pGridID);
    end;

    /// <summary>
    /// Moves the Active Row (Focus) of a DataGrid to the Previous Row in the Grid if available. Note that LINE_UP Pos Command works the same for the Active DataGrid.
    /// </summary>
    /// <param name="pGridID">The ID of the DataGrid Control.</param>
    procedure GoToPreviousRow(pGridID: Code[20])
    begin
        // TODO: LSC-27724 Doesn't seem to always work (Focus is removed from the Grid, No Row is Focused). Should do same as LINE_UP Pos Command
        iPOS.GoToPreviousRow(pGridID);
    end;

    /// <summary>
    /// Moves the Active Row (Focus) of a DataGrid to the specified Row Index.
    /// </summary>
    /// <param name="pGridID">The ID of the DataGrid Control.</param>
    /// <param name="pRowIndex">The zero based Index of the Row to Focus.</param>
    procedure GoToRow(pGridID: Code[20]; pRowIndex: Integer)
    begin
        // TODO: LSC-27724 Doesn't seem to always work (Focus is removed from the Grid, No Row is Focused)
        iPOS.GoToRow(pGridID, pRowIndex);
    end;

    /// <summary>
    /// Move the Active Row (Focus) to the Record with the given RecordID if found in the Data.
    /// </summary>
    /// <param name="pGridID">The ID of the DataGrid Control.</param>
    /// <param name="pRecordID">The RecordID of the Record to Focus.</param>
    procedure GoToRecord(pGridID: Code[20]; pRecordID: RecordID)
    begin
        // TODO: LSC-27724 Doesn't seem to always work (Focus is removed from the Grid, No Row is Focused)
        iPOS.GoToRecord(pGridID, pRecordID);
    end;

    /// <summary>
    /// Selects a Column in a DataGrid with the specified sortOrder.
    /// </summary>
    /// <param name="pGridID">The ID of the DataGrid Control.</param>
    /// <param name="pColumnNo">The Column to Select</param>
    /// <param name="pSortOrder">The SortOrder of the Selected Column.</param>
    procedure SelectGridColumn(pGridID: Code[20]; pColumnNo: Integer; pSortOrder: Option "None","Ascending","Descending")
    begin
        iPOS.SelectGridColumn(pGridID, pColumnNo, pSortOrder);
    end;

    /// <summary>
    /// Return the Number of the Selcted Column in a DataGrid Control.
    /// </summary>
    /// <param name="pGridID">The ID of the DataGrid Control.</param>
    procedure GetGridSelectedColumn(pGridID: Code[20]): Integer
    begin
        exit(iPOS.GetGridSelectedColumn(pGridID));
    end;

    /// <summary>
    /// Return the Field Number of the specified Column in a DataGrid Control.
    /// </summary>
    /// <param name="pGridID">The ID of the DataGrid Control.</param>
    /// <param name="pColumnNo">The number of the Column to get the FieldNo for.</param>
    procedure GetDataGridColumnFieldNo(pGridID: Code[20]; pColumnNo: Integer): Integer
    begin
        exit(iPOS.GetDataGridColumnFieldNo(pGridID, pColumnNo));
    end;

    /// <summary>
    /// Resets the specified POS Data Grid Control in the POS UI. Data, Filters, Sorting and Selected Column etc. should be reset.
    /// </summary>
    /// <param name="pGridID">The Data Grid to Reset</param>
    procedure ResetDataGrid(pGridID: Code[20])
    begin
        iPOS.ResetDataGrid(pGridID);
    end;

    /// <summary>
    /// Pops Up (or Down) a DataGrid containg the DataSet passed to it. By Default this DataGrid will hide when it loses focus.
    /// </summary>
    /// <param name="pGridID">The ID of the DataGrid Control.</param>
    /// <param name="pLSDataSet">The DataSet containg Data for the DataGrid Control.</param>
    /// <param name="pInputID">The ID of the Input Control below which the DataGrid will be placed (like a curtain).</param>
    /// <param name="pHeight">The height in pixels for the DataGrid Control.</param>
    /// <param name="pHideColumnHeader">If true the Column Headers of the DataGrid will not be shown.</param>
    internal procedure PopupGridData(pGridID: Code[20]; var pLSDataSet: Codeunit "LSC DataSet"; pInputID: Code[20]; pHeight: Integer; pHideColumnHeader: Boolean)
    begin
        // Making this internal because it seems to only work specifically for the Search DropDown on POS
        iPOS.PopupGridData(pGridID, pLSDataSet, pInputID, pHeight, pHideColumnHeader);
    end;

    /// <summary>
    /// Internally called to validate input in a Record Zoom Control.
    /// </summary>
    /// <param name="pPosEvent">The POS Event with info on the input.</param>
    internal procedure ValidateZoomInput(var pPosEvent: Codeunit "LSC POS Event")
    begin
        iPOS.ValidateZoomInput(pPosEvent);
    end;

    #EndRegion DataGrid

    #Region Lookup

    /// <summary>
    /// Prepares and opens a Lookup
    /// </summary>
    /// <param name="pLookupSetup">The Lookup Setup</param>
    /// <param name="pLookupFilter">The Lookup Filter</param>
    /// <param name="pPosTransLine">The Lookup POS Transaction Lines</param>
    /// <param name="pMgrKey">Specifies if MgrKey is active</param>
    /// <param name="pCustomerNo">Customer number</param>
    /// <param name="pRecRef">The Lookup RecordRef</param>
    /// <param name="pFlowFieldBuffer">The Lookup FlowField buffer</param>
    procedure Lookup(var pLookupSetup: Record "LSC POS Lookup"; pLookupFilter: Text; var pPosTransLine: Record "LSC POS Trans. Line"; pMgrKey: Boolean; pCustomerNo: Code[20]; var pRecRef: RecordRef; var pFlowFieldBuffer: Record "LSC FlowField Buffer" temporary)
    begin
        iPOS.Lookup(pLookupSetup, pLookupFilter, pPosTransLine, pMgrKey, pCustomerNo, pRecRef, pFlowFieldBuffer);
    end;

    /// <summary>
    /// Gets the Return Command of the specified Lookup
    /// </summary>
    /// <param name="pLookupID">The ID of the Lookup Setup</param>
    procedure GetLookupCommand(pLookupID: Code[20]): Code[20]
    begin
        //not tested
        exit(iPOS.GetLookupCommand(pLookupID));
    end;

    /// <summary>
    /// Returns the Key Value (Specified in the DataTable Setup) of the Active Records in the specified Lookup.
    /// </summary>
    /// <param name="pLookupID">The ID of the Lookup Setup</param>
    procedure GetLookupKeyValue(pLookupID: Code[20]): Code[60]
    begin
        //not tested
        exit(iPOS.GetLookupKeyValue(pLookupID));
    end;

    /// <summary>
    /// Gets the RecordID of the Active (Focused) Record (Row) of the specified Lookup.
    /// </summary>
    /// <param name="pLookupID">The ID of the Lookup</param>
    /// <param name="pRecordID">The RecordID of the Active Row</param>
    procedure GetLookupActiveRecordID(pLookupID: Code[20]; var pRecordID: RecordID): Boolean
    begin
        exit(iPOS.GetLookupActiveRecordID(pLookupID, pRecordID));
    end;

    /// <summary>
    /// Gets the RecordIDs of the Marked (Selected) Records in a Lookup.
    /// </summary>
    /// <param name="pLookupID">The ID of the Lookup Setup.</param>
    /// <param name="pRecordIDJsonArray">JsonArray for the RecordID's.</param>
    /// <param name="pRemoveMarks">Set True to remove the Marked records.</param>
    procedure GetLookupMarkedRecords(pLookupID: Code[20]; var pRecordIDJsonArray: JsonArray; pRemoveMarks: Boolean)
    begin
        iPOS.GetLookupMarkedRecords(pLookupID, pRecordIDJsonArray, pRemoveMarks);
    end;

    /// <summary>
    /// Returns the ID of the Active Lookup on the POS.
    /// </summary>
    procedure GetActiveLookupID(): Code[20]
    begin
        exit(iPOS.GetActiveLookupID());
    end;

    /// <summary>
    /// Returns the ID of the Active Lookup on the POS or the last Active Lookup if no Lookup is currently active.
    /// </summary>
    procedure GetActiveOrLastLookupID(): Code[20]
    begin
        exit(iPOS.GetActiveOrLastLookupID());
    end;

    /// <summary>
    /// Gets the Key Value of the Active Record of the Active Lookup on the POS.
    /// </summary>
    procedure GetActiveLookupKeyValue(): Code[60]
    begin
        exit(iPOS.GetActiveLookupKeyValue());
    end;

    /// <summary>
    /// Gets the Active RecordID of the Active Lookup on the POS.
    /// </summary>
    /// <param name="pRecordID">Will contain the RecordID if the function returns true.</param>
    procedure GetActiveLookupRecordID(var pRecordID: RecordID): Boolean
    begin
        exit(iPOS.GetActiveLookupRecordID(pRecordID));
    end;

    /// <summary>
    /// Gets the Active RecordID of the Last Active Lookup on the POS.
    /// </summary>
    /// <param name="pRecordID">Will contain the RecordID if the function returns true.</param>
    procedure GetLastLookupRecordID(var pRecordID: RecordID): Boolean
    begin
        exit(iPOS.GetLastLookupRecordID(pRecordID));
    end;

    /// <summary>
    /// Refreshes the Data in the active Lookup on the POS.
    /// </summary>
    procedure RefreshActiveLookup()
    begin
        iPOS.RefreshActiveLookup();
    end;

    /// <summary>
    /// Sets the Info Text on the Active Lookup.
    /// </summary>
    /// <param name="pMessage">The message to set as Info Text</param>
    procedure SetActiveLookupInfoText(pMessage: Text)
    begin
        iPOS.SetActiveLookupInfoText(pMessage);
    end;

    /// <summary>
    /// Sets the Marked (Selected) Records in the Active Lookup.
    /// </summary>
    /// <param name="pRecordIDJsonArray">JsonArray containing the RecordIDs to Mark.</param>
    procedure SetActiveLookupMarkedRecords(var pRecordIDJsonArray: JsonArray)
    begin
        iPOS.SetActiveLookupMarkedRecords(pRecordIDJsonArray);
    end;

    /// <summary>
    /// Gets the Marked (Selected) Records in the Active Lookup.
    /// </summary>
    /// <param name="pRecordIDJsonArray">A JsonArray for the Marked RecordIDs.</param>
    /// <param name="pRemoveMarks">Set True to have the Records/Rows Unmarked afterwards.</param>
    procedure GetActiveLookupMarkedRecords(var pRecordIDJsonArray: JsonArray; pRemoveMarks: Boolean)
    begin
        iPOS.GetActiveLookupMarkedRecords(pRecordIDJsonArray, pRemoveMarks);
    end;

    /// <summary>
    /// Unmarkes all marked records/rows in the Active Lookup.
    /// </summary>
    procedure ClearActiveLookupMarkedRecords()
    begin
        iPOS.ClearActiveLookupMarkedRecords();
    end;

    /// <summary>
    /// Opens a Zoom Control to edit the Active Record in the Active Lookup.
    /// </summary>
    /// <param name="pDataTableID">The ID of the DataTable Setup to use in the Zoom Control.</param>
    procedure EditActiveLookupRecord(pDataTableID: Code[20]): Code[10]
    begin
        exit(iPOS.EditActiveLookupRecord(pDataTableID));
    end;

    /// <summary>
    /// Opens a Zoom Control to view the Active Record in the Active Lookup.
    /// </summary>
    /// <param name="pDataTableID">The ID of the DataTable Setup to use in the Zoom Control.</param>
    procedure ZoomActiveLookupRecord(pDataTableID: Code[20]): Code[10]
    begin
        exit(iPOS.ZoomActiveLookupRecord(pDataTableID));
    end;

    /// <summary>
    /// Opens a Zoom Control to Add a new Record to the active Lookup.
    /// </summary>
    /// <param name="pDataTableID">The ID of the DataTable Setup to use in the Zoom Control.</param>
    procedure NewActiveLookupRecord(pDataTableID: Code[20]): Code[10]
    begin
        exit(iPOS.NewActiveLookupRecord(pDataTableID));
    end;

    /// <summary>
    /// Deletes all marked (selected) Records in the active Lookup.
    /// </summary>
    procedure DeleteActiveLookupRecords()
    begin
        iPOS.DeleteActiveLookupRecords();
    end;

    #EndRegion Lookup

    #Region Context

    /// <summary>
    /// Updates the Global POS Context with the context variables in the Dictionary and marks them with the DataTag.
    /// </summary>
    /// <param name="pContextModel">Dictionary of Name Value pairs.</param>
    /// <param name="pTag">The DataTag to mark Name Value pairs with.</param>
    procedure UpdatePOSContext(var pContextModel: Dictionary of [Text, Text]; pTag: Text)
    begin
        iPOS.UpdatePOSContext(pContextModel, pTag);
    end;

    /// <summary>
    /// Updates the Global POS Context with the context variables in the PosContext codeunit.
    /// </summary>
    /// <param name="pPosContext">The Context Codeunit.</param>
    procedure UpdatePOSContext(var pContextModel: Codeunit "LSC POS Context")
    var
        model: Dictionary of [Text, Text];
    begin
        if not initialized then
            exit;

        // If Context has been cleared after it has been sent at least once,
        // it should remove the old keys before sending the new ones.
        if pContextModel.BeforeSendToPOS() then
            DeleteContextByTag(pContextModel.Tag);

        pContextModel.GetContextModel(model);
        UpdatePOSContext(model, pContextModel.Tag);

        pContextModel.AfterSendToPOS();
    end;

    /// <summary>
    /// Updates the Global POS Context with the context variables in the PosContext codeunit.
    /// </summary>
    /// <param name="pPosContext">The Context Codeunit.</param>
    procedure AddContext(var pPosContext: Codeunit "LSC POS Context")
    begin
        // Deprecated, use UpdatePOSContext instead, these all do the same thing now
        UpdatePOSContext(pPosContext);
    end;

    /// <summary>
    /// Updates the Global POS Context with the context variables in the PosContext codeunit.
    /// </summary>
    /// <param name="pPosContext">The Context Codeunit.</param>
    procedure SendContext(var pPosContext: Codeunit "LSC POS Context")
    begin
        // Deprecated, use UpdatePOSContext instead, these all do the same thing now
        UpdatePOSContext(pPosContext);
    end;

    /// <summary>
    /// Deletes Context variables by DataTag.
    /// </summary>
    /// <param name="pDataTag">All Context variables added with this DataTag will be deleted.</param>
    procedure DeleteContextByTag(pDataTag: Text)
    begin
        iPOS.DeleteContextByTag(pDataTag);
    end;

    /// <summary>
    /// Sets the Value of a Context variable.
    /// </summary>
    /// <param name="pKey">The Name of the Context variable.</param>
    /// <param name="pValue">The new Value.</param>
    /// <returns>The old Value.</returns>
    procedure SetValue(pKey: Text; pValue: Text) oldValue: Text
    begin
        if not initialized then
            exit(NoDLLPOS.SetValue(pKey, pValue));

        oldValue := iPOS.SetValue(pKey, pValue);
    end;

    procedure SetValue(pKey: Enum "LSC POS Tag"; pValue: Text) oldValue: Text
    begin
        exit(SetValue(Format(pKey), pValue));
    end;

    /// <summary>
    /// Return the Value of a Context variable.
    /// </summary>
    /// <param name="pKey">The Name of the Context variable.</param>
    procedure GetValue(pKey: Text): Text
    begin
        if not initialized then
            exit(NoDLLPOS.GetValue(pKey));

        exit(iPOS.GetValue(pKey));
    end;

    procedure GetValue(pKey: Enum "LSC POS Tag"): Text
    begin
        exit(GetValue(Format(pKey)));
    end;

    /// <summary>
    /// Clears the Value of a Context variable.
    /// </summary>
    /// <param name="pKey">The Name of the Context variable.</param>
    procedure ClearValue(pKey: Text): Boolean
    begin
        exit(SetValue(pKey, '') <> '');
    end;

    procedure ClearValue(pKey: Enum "LSC POS Tag"): Boolean
    begin
        exit(ClearValue(Format(pKey)));
    end;

    #EndRegion Context

    #Region RecordZoom

    /// <summary>
    /// Show a Record in a Record Zoom Control using the Specified DataTable. Fields specified in the DataTable will be shown in the Zoom Control.
    /// </summary>
    /// <param name="recRef">A RecordRef pointing to the Record to show.</param>
    /// <param name="recordZoomControlID">The ID of the Record Zoom Control.</param>
    /// <param name="dataTableID">The ID of the DataTable to use.</param>
    /// <param name="allowEdit">Can be set False to make the Zoom Read Only. Otherwise editable fields in the DataTable will be editable.</param>
    procedure ShowRecordZoom(var recRef: RecordRef; recordZoomControlID: Code[20]; dataTableID: Code[20]; allowEdit: Boolean)
    begin
        iPOS.ShowRecordZoom(recRef, recordZoomControlID, dataTableID, allowEdit);
    end;

    /// <summary>
    /// Internally used to show a Record in a Record Zoom Control using the Specified Dataset in a text format (JSON, but used to be XML).
    /// </summary>
    /// <param name="dataSetJson">A RecordZoom specific Json from a "LSC POS Pair Value" Record.</param>
    /// <param name="recordZoomControlID">The ID of the Record Zoom Control.</param>
    /// <param name="allowEdit">Can be set False to make the Zoom Read Only. Otherwise editable settings in the Json will be used.</param>
    procedure ShowRecordZoomXML(dataSetJson: Text; recordZoomControlID: Code[20]; allowEdit: Boolean)
    begin
        iPOS.ShowRecordZoomJson(dataSetJson, recordZoomControlID, allowEdit);
    end;

    /// <summary>
    /// Gets a Record from a Zoom Control into the recRef variable.
    /// </summary>
    /// <param name="recRef">The RecordRef to contain the Record from the Zoom Control.</param>
    /// <param name="recordZoomControlID">The ID of the Record Zoom Control.</param>
    procedure GetRecordZoomData(var recRef: RecordRef; recordZoomControlID: Code[20])
    begin
        iPOS.GetRecordZoomData(recRef, recordZoomControlID);
    end;

    /// <summary>
    /// Internally used to get the Record from a Zoom Control in a Json Format. Json should contain a "LSC POS Pair Value" record per line in the Zoom.
    /// </summary>
    /// <param name="recordZoomControlID">The ID of the Record Zoom Control.</param>
    procedure GetRecordZoomDataXML(recordZoomControlID: Code[20]): Text
    begin
        exit(iPOS.GetRecordZoomDataXML(recordZoomControlID));
    end;

    /// <summary>
    /// Resets a Zoom Control by removing any unsaved input. Setting it to intial state.
    /// </summary>
    /// <param name="interfaceProfileID">Not used.</param>
    /// <param name="recordZoomControlID">The ID of the Record Zoom Control.</param>
    procedure RefreshZoomControl(interfaceProfileID: Code[10]; recordZoomControlID: Code[20])
    begin
        iPOS.RefreshZoomControl(interfaceProfileID, recordZoomControlID);
    end;

    /// <summary>
    /// Internally used to show custom Data in a Record Zoom Control. Data that does not need to have an actual Record behind it.
    /// </summary>
    /// <param name="dataSetJson">A RecordZoom specific Json from a "LSC POS Pair Value" Record.</param>
    /// <param name="tempPairValue">Record Zoom specific settings are contained in this Pair Value Record. One Record per line/field in the Zoom Control.</param>
    /// <param name="recordZoomControlID">The ID of the Record Zoom Control.</param>
    /// <param name="allowEdit">Can be set False to make the Zoom Read Only. Otherwise editable settings in the Pair Value Record will be used.</param>
    procedure ShowCustomRecordZoomData(var tempPairValue: Record "LSC POS Pair Value" temporary; recordZoomControlID: Code[20]; allowEdit: Boolean)
    begin
        iPOS.ShowCustomRecordZoomData(tempPairValue, recordZoomControlID, allowEdit);
    end;

    /// <summary>
    /// Internally used to get custom Data in a Record Zoom Control. Data that does not need to have an actual Record behind it.
    /// </summary>
    /// <param name="tempPairValue">Record Zoom specific settings are contained in this Pair Value Record. One Record per line/field in the Zoom Control.</param>
    /// <param name="recordZoomControlID">The ID of the Record Zoom Control.</param>
    procedure GetCustomRecordZoomData(var TempPairValue: Record "LSC POS Pair Value" temporary; RecordZoomControlID: Code[20])
    begin
        iPOS.GetCustomRecordZoomData(TempPairValue, RecordZoomControlID);
    end;

    #EndRegion RecordZoom

    #Region Media

    /// <summary>
    /// Invokes the Play function of a Media Control (Url or Playlist will be played.)
    /// </summary>
    /// <param name="pControlID">The ID of the Media Control.</param>
    procedure Play(pControlID: Code[20])
    begin
        PostCommand("LSC POS Command"::PLAY, '', pControlID);
    end;

    /// <summary>
    /// Plays the specified Playlist on the Media Control
    /// </summary>
    /// <param name="pControlID">The ID of the Media Control.</param>
    /// <param name="pPlaylistID">The ID of the Playlist.</param>
    procedure Playlist(pControlID: Code[20]; pPlaylistID: Code[20])
    begin
        iPOS.Playlist(pControlID, pPlaylistID);
    end;

    /// <summary>
    /// Stops the active Playlist on the specified Media Control.
    /// </summary>
    /// <param name="pControlID">The ID of the Media Control.</param>
    procedure ClearPlaylist(pControlID: Code[20])
    begin
        Playlist(pControlID, '');
    end;

    /// <summary>
    /// Pauses the active Video or Playlist on the Media Control.
    /// </summary>
    /// <param name="pControlID">The ID of the Media Control.</param>
    procedure Pause(pControlID: Code[20])
    begin
        PostCommand("LSC POS Command"::PAUSE, '', pControlID);
    end;

    /// <summary>
    /// Stops a Video or Playlist in the specified Media Control.
    /// </summary>
    /// <param name="pControlID">The ID of the Media Control.</param>
    procedure Stop(pControlID: Code[20])
    begin
        PostCommand("LSC POS Command"::STOP, '', pControlID);
    end;

    /// <summary>
    /// Plays the Next Item in a Playlist on the specified Media Control.
    /// </summary>
    /// <param name="pControlID">The ID of the Media Control.</param>
    procedure Next(pControlID: Code[20])
    begin
        PostCommand("LSC POS Command"::NEXT, '', pControlID);
    end;

    /// <summary>
    /// Plays the Previous Item in a Playlist on the specified Media Control.
    /// </summary>
    /// <param name="pControlID">The ID of the Media Control.</param>
    procedure Previous(pControlID: Code[20])
    begin
        PostCommand("LSC POS Command"::PREV, '', pControlID);
    end;

    #EndRegion Media

    #Region Browser

    /// <summary>
    /// Navigates a Browser Control to the specified URL
    /// </summary>
    /// <param name="pControlID">The ID of the Browser Control.</param>
    /// <param name="pURL">The URL to open.</param>
    procedure Navigate(pControlID: Code[20]; pURL: Text)
    begin
        PostCommand("LSC POS Command"::NAVIGATE, pURL, pControlID);
    end;

    /// <summary>
    /// Refreshes a Browser Control. Reloads the URL.
    /// </summary>
    /// <param name="pControlID">The ID of the Browser Control.</param>
    procedure Refresh(pControlID: Code[20])
    begin
        PostCommand("LSC POS Command"::REFRESH, '', pControlID);
    end;

    /// <summary>
    /// Sets (replaces) the HTML in a Browser Control.
    /// </summary>
    /// <param name="pControlID">The ID of the Browser Control.</param>
    /// <param name="pHtml">The Html in text format.</param>
    procedure SetHtml(pControlID: Code[20]; pHtml: Text)
    begin
        iPOS.SetHtml(pControlID, pHtml);
    end;

    /// <summary>
    /// Sets (replaces) the HTML in a Browser Control.
    /// </summary>
    /// <param name="pControlID">The ID of the Browser Control.</param>
    /// <param name="pHtml">The Html in byte (stream) format.</param>
    procedure SetHtmlBytes(pControlID: Code[20]; pHtml: OutStream)
    var
        iStr: InStream;
        txt: Text;
    begin
        CopyStream(pHtml, iStr);
        iStr.ReadText(txt);
        SetHtml(pControlID, txt);
    end;

    /// <summary>
    /// Invokes (eval) javascript code in a Browser Control.
    /// </summary>
    /// <param name="pControlID">The ID of the Browser Control.</param>
    /// <param name="pJavaScript">The Javascript to invoke.</param>
    procedure InvokeScript(pControlID: Code[20]; pJavaScript: Text)
    begin
        iPOS.InvokeScript(pControlID, pJavaScript);
    end;

    /// <summary>
    /// Internally used to pass information about the WebService Connection to the POS Client (WebTemplates basically) that will be used to Invoke DoWebApiCall.
    /// </summary>
    procedure SetWsInfo()
    begin
        GetWebTemplateHandler().SetWsInfo();
    end;

    /// <summary>
    /// Internally used to pass information about the WebService Connection to the POS Client (WebTemplates basically) that will be used to Invoke DoWebApiCall.
    /// </summary>
    /// <param name="wsURL">Connection string to the WebService</param>
    /// <param name="wsUserName">The UserName</param>
    /// <param name="wsPassword">The Password</param>
    /// <param name="wsDomain">The Domain</param>
    [NonDebuggable]
    procedure SetWsCredentials(wsURL: Text; wsUserName: Text; wsPassword: Text; wsDomain: Text)
    var
        wsPwd: SecretText;
    begin
        wsPwd := wsPassword; // Text->SecretText
        GetWebTemplateHandler().SetWsCredentials(wsURL, wsUserName, wsPwd, wsDomain);
    end;

    #EndRegion Browser

    #Region Internal Functions

    /// <summary>
    /// Use to add ##WRAPPER_DD to PanelStack to indicate rest of the panelstack should be forwarded to Dual Display
    /// </summary>
    internal procedure EnableDualDisplayMirroring()
    begin
        iPOS.EnableDualDisplayMirroring();
    end;

    /// <summary>
    /// Sets the POS Control Library codeunit behind this API. 
    /// </summary>
    /// <param name="pCONTROLLIB">The Control Library Codeunit the POS Control Implementation will use.</param>    
    internal procedure SetControlLibrary(var pCONTROLLIB: Codeunit "LSC POS Control Library"): Boolean
    begin
        if not initialized then
            exit(false);

        iPOS.SetControlLibrary(pCONTROLLIB);
        exit(true);
    end;

    /// <summary>
    /// Gets the POS Control Library codeunit behind this API. 
    /// </summary>
    internal procedure GetControlLibrary() cl: Codeunit "LSC POS Control Library"
    begin
        if not initialized then
            exit;
        cl := iPos.GetControlLibrary();
    end;

    internal procedure GetWebTemplateHandler() WTH: Codeunit "LSC POS Web Template Handler"
    begin
        if not initialized then
            exit;
        WTH := iPos.GetWebTemplateHandler();
    end;

    /// <summary>
    /// Initialized the POS Control and passes a Control Library to use. Should be called when POS or Page Using the POS Control is starting up.
    /// </summary>
    /// <param name="pCONTROLLIB">The Control Library Codeunit the POS Control Implementation will use.</param>
    internal procedure InitControl(var pCONTROLLIB: Codeunit "LSC POS Control Library"): Boolean
    begin
        case PosType of
            PosType::Default:
                Clear(NoDllPOS);
            PosType::Mock:
                Clear(TestPOS);
            PosType::Pos:
                Clear(NoDllPOS);
            PosType::DualDisplay:
                Clear(DualDisplay);
        end;
        SetClientTypeEnum(PosType); // Note: Need to set iPos again because of Clear
        exit(iPOS.InitControl(pCONTROLLIB));
    end;

    /// <summary>
    /// Set the behavior of dialog methods like Confirm, StrMenu.
    /// Note: this is internal for mocking handlers in integration tests
    /// </summary>
    /// <param name="ShouldUseDefaults">Turn the feature on/off</param>
    /// <param name="DefaultConfirmValue">What should the return value be for Confirm</param>
    /// <param name="DefaultStrMenuValue">What should the return value be for StrMenu</param>
    internal procedure SetDialogHandlerValues(ShouldUseDefaults: Boolean; DefaultConfirmValue: Boolean; DefaultStrMenuValue: Integer)
    begin
        iPOS.SetDialogHandlerValues(ShouldUseDefaults, DefaultConfirmValue, DefaultStrMenuValue);
    end;

    /// <summary>
    /// Returns the Active Input Control ID.
    /// Note: internal since currently only ActivePanel is exposed, not other active control types
    /// </summary>
    /// <returns></returns>
    internal procedure GetActiveInput(): Text
    begin
        exit(GetControlLibrary().GetActiveInput());
    end;

    /// <summary>
    /// Use by EPOS Controller to flag that the POS Control has been initialized
    /// </summary>
    /// <param name="pInitialzed">The Initalized state to set</param>
    internal procedure SetInitialized(pInitalized: Boolean)
    begin
        iPOS.SetInitialized(pInitalized);
    end;

    /// <summary>
    /// Use by EPOS Controller to check if the POS Control has been initialized
    /// </summary>
    internal procedure GetInitialized(): Boolean
    begin
        exit(iPOS.GetInitialized());
    end;

    /// <summary>
    /// Internally called by the POS Page when loading the POS Configuration
    /// </summary>
    internal procedure LoadPOS()
    begin
        iPOS.LoadPOS();
    end;

    /// <summary>
    /// Internally called by the POS Page when loading the POS Hardware connections
    /// </summary>
    internal procedure LoadHardware()
    begin
        iPOS.LoadHardware();
    end;

    /// <summary>
    /// Internally called by the POS Pages (throug Addin Wrapper) to pass the incoming POS Event to the POS Control Library Implementation for initial processing (sync state etc)
    /// </summary>
    /// <param name="pPOSEvent">The incoming POS Event</param>
    internal procedure PreProcessEvent(var pPOSEvent: Codeunit "LSC POS Event"): Boolean
    begin
        if not initialized then
            exit;
        exit(iPOS.PreProcessEvent(pPOSEvent));
    end;

    /// <summary>
    /// Internally called by the POS Pages (through Addin Wrapper) to pass the incoming POS Event to the POS Control Library Implementation after it has been processed by the main LS Central Logic
    /// </summary>
    /// <param name="">The "outgoing" POS Event</param>
    internal procedure PostProcessEvent(var pPOSEvent: Codeunit "LSC POS Event"): Boolean
    begin
        if not initialized then
            exit;
        exit(iPOS.PostProcessEvent(pPOSEvent));
    end;

    /// <summary>
    /// Logs a POS Event in the POS Debug Log
    /// </summary>
    /// <param name="pPosEvent">The POSEvent to log</param>
    internal procedure LogEvent(var pPosEvent: Codeunit "LSC POS Event")
    begin
        if not initialized then
            exit;

        iPOS.LogEvent(pPosEvent);
    end;

    internal procedure LookupClosed(resultOK: Boolean)
    begin
        iPOS.LookupClosed(resultOK);
    end;

    internal procedure LookupDataRequest(gridID: Text; lookupID: Text; fromPage: Integer; pageCount: Integer; pageSize: Integer; sortColumn: Integer; sortAscending: Boolean; filterString: Text): Boolean
    begin
        exit(iPOS.LookupDataRequest(gridID, lookupID, fromPage, pageCount, pageSize, sortColumn, sortAscending, filterString));
    end;

    internal procedure LookupDataFind(pGridId: Code[20]; pLookupID: Code[20]; pFindText: Text): Boolean
    begin
        exit(iPOS.LookupDataFind(pGridId, pLookupID, pFindText));
    end;

    internal procedure SetLookupAssistValue(value: Text)
    begin
        iPOS.SetLookupAssistValue(value);
    end;

    internal procedure DataRequest(gridID: Code[20]; dataTableID: Code[20]; fromPage: Integer; pageCount: Integer; pageSize: Integer; sortColumn: Integer; sortAscending: Boolean; filterString: Text): Boolean
    begin
        exit(iPOS.DataRequest(gridID, dataTableID, fromPage, pageCount, pageSize, sortColumn, sortAscending, filterString));
    end;

    internal procedure DataFind(pGridId: Code[20]; pDataTableID: Code[10]; pFindText: Text): Boolean
    begin
        exit(iPOS.DataFind(pGridId, pDataTableID, pFindText));
    end;

    /// <summary>
    /// Internally called by the POS Page when DataGrid Rows are being marked if the "Notify Marked Count Changed" on the Grid is true.
    /// </summary>
    /// <param name="pDataGridID">The DataGrid Control where marked rows changed.</param>
    /// <param name="pMarkedCount">The new marked row count.</param>
    internal procedure DataGridMarkedCountChanged(pDataGridID: Code[20]; pMarkedCount: Integer)
    begin
        iPOS.DataGridMarkedCountChanged(pDataGridID, pMarkedCount);
    end;

    /// <summary>
    /// Inernally called to updates Menu Buttons Permission state (Disable/Enabled).
    /// </summary>
    internal procedure UpdateSessionPermissions()
    begin
        iPOS.UpdateSessionPermissions();
    end;

    /// <summary>
    /// Internally called language changes to upload Translations to the POS.
    /// </summary>
    internal procedure UploadTranslations()
    begin
        if not initialized then
            exit;
        iPOS.UploadTranslations();
    end;

    internal procedure UpdateTagExpressions(var dict: Dictionary of [Text, Text])
    begin
        iPOS.UpdateTagExpressions(dict);
    end;

    #EndRegion Internal Functions

    #Region Events

    [IntegrationEvent(false, false)]
    internal procedure OnBeforeSetWSInfo(var navComputerName: Text; var navInstanceName: Text; var navCompanyName: Text; var navPort: Integer; var wsProtocol: Text; var wsPort: Integer; var wsURL: Text)
    begin
    end;

    [IntegrationEvent(false, false)]
    internal procedure OnBeforeSetWsCredentials(wsURL: Text; var wsUserName: Text; var wsPassword: Text; var wsDomain: Text)
    begin
    end;

    [IntegrationEvent(false, false)]
    internal procedure OnLocalRequest(ctrlID: Text; tmplID: Text; serviceName: Text; methodName: Text; paramsJson: Text; var resultText: Text; var handled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    internal procedure OnAfterShowMenu(var pMenuID: Code[20])
    begin
    end;

    #EndRegion Events

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnStateChanged, '', false, false)]
    local procedure OnStateChanged(var POSTransaction: Record "LSC POS Transaction"; fromState: Text; toState: Text)
    var
        PosTransactionCu: Codeunit "LSC POS View";
    begin
        if not DualDisplay.GetInitialized then
            exit;
        if (not PosTransactionCu.IsInitialized) or (toState = '') then begin
            DualDisplay.ShowPanel(Format("LSC POS Panel ID"::"#DD-OFFLINE"));
            exit;
        end;
        case toState of
            Format("LSC POS Transaction State"::SALES):
                DualDisplay.ShowPanel(Format("LSC POS Panel ID"::"#DD-SALES"));
            Format("LSC POS Transaction State"::PAYMENT):
                DualDisplay.ShowPanel(Format("LSC POS Panel ID"::"#DD-PAYMENT"));
        end;
    end;

}

