codeunit 10001428 "LSC Self Service Functions"
{
    SingleInstance = true;
    TableNo = "LSC POS Menu Line";

    trigger OnRun()
    var
        PosTrans: Record "LSC POS Transaction";
        EposCtrlEvent: Codeunit "LSC POS Control Event";
    begin
        IF Rec."Pos Event Type" = -3 THEN  //LogonPos
            PosCtrlInterface.PostCommand("LSC POS Command"::SHOWPANEL, '#POS');

        if Rec."Pos Event Type" = Rec."Pos Event Type"::PANELCLOSED then begin
            if EposCtrlEvent.ClosingPanelID() = Format("LSC POS Panel Id"::"#POS") then begin
                PosCtrlInterface.SetAutoLogoffTimeout(0);
                ResetManagerProfiles();

                if PosTrans.Get(POSSession().GetValue("LSC POS Tag"::"LASTPOSTRANS")) then
                    if POSSession().GetValue("LSC POS Tag"::SSK_PAYATCOUNTER) <> '' then begin
                        PosCtrlInterface.Navigate('#SELFSERV', 'lstmpl://#SELFSERVICE/RetailWebAPI/###URLDATA/?data=clearCart'); //Paid or Voided, if autologoff, trans already voided
                        POSSession().DeleteValue("LSC POS Tag"::SSK_PAYATCOUNTER);
                    end else
                        PosCtrlInterface.Navigate('#SELFSERV', 'lstmpl://#SELFSERVICE/RetailWebAPI/###URLDATA/?data=notclearCart') //Back
                else
                    PosCtrlInterface.Navigate('#SELFSERV', 'lstmpl://#SELFSERVICE/RetailWebAPI/###URLDATA/?data=clearCart'); //Paid or Voided, if autologoff, trans already voided
            end;
        end;

        if Rec."Pos Event Type" in [Rec."Pos Event Type"::POSCOMMAND, Rec."Pos Event Type"::BUTTONPRESS] then begin
            case Rec.Command of
                Format("LSC POS Command"::SSK_PAYATCOUNTER):
                    begin
                        POSSession().SetValue("LSC POS Tag"::SSK_PAYATCOUNTER, '1');
                        PosCtrlInterface.PostCommand("LSC POS Command"::PRINTBILL, '');
                        PosCtrlInterface.PostCommand("LSC POS Command"::LOGOFF, '');
                        Rec.Processed := true;
                    end;
                Format("LSC POS Command"::SSK_CHGTERMSTATUS):
                    begin
                        ChangeTerminalStatus();
                        Rec.Processed := true;
                    end;
            end;
        end;
    end;

    var
        ServiceLocator: Codeunit "LSC Service Locator";
        PosCtrlInterface: Codeunit "LSC POS Control Interface";
        DynContHierBuffer: Record "LSC Dyn. Cont. Hier. Buffer";
        DynContTranslBuffer: Record "LSC Dyn. Cont. Transl. Buffer" temporary;
        DynContCurrAvailBuffer: Record "LSC Dyn Cont Curr Avail Buffer" temporary;
        NoOfHierarchies: Integer;
        LastHierarchyCode: Code[20];
        LastLanguageCode: Code[10];
        SessionLanguageCode: Code[10];
        HierarchiesInStore: List of [Code[20]];
        SystemLanguageCode: Code[10];
        DefaultLanguageCode: Code[10];

    internal procedure GetInitialSettings(BrowserControlId: Text; pTerminalID: Text; LanguageCode: Text; LoadHierarchies: Boolean): Text
    var
        Store: Record "LSC Store";
        POSTerminal: Record "LSC POS Terminal";
        SSKProfile: Record "LSC SSK Profile";
        PosFunctionalityProfile: Record "LSC POS Func. Profile";
        POSPanelControlLine: Record "LSC POS Panel Control Line";
        JsonUtil: Codeunit "LSC POS JSON Util";
        LangCu: Codeunit "Language";
        ErrorText: Text;
        GetSettingsErrorOriginErr: Label 'GetSettings', Locked = true;
    begin
        if pTerminalID = '' then
            pTerminalID := POSSession().TerminalNo();
        if LoadHierarchies then begin
            clear(DynContCurrAvailBuffer);
            DynContCurrAvailBuffer.DeleteAll();
            clear(DynContTranslBuffer);
            DynContTranslBuffer.DeleteAll();
            clear(DynContHierBuffer);
            DynContHierBuffer.DeleteAll();

            NoOfHierarchies := 0;
            LastHierarchyCode := '';
            LastLanguageCode := '';
            SystemLanguageCode := '';
            DefaultLanguageCode := '';
        end;

        PosCtrlInterface.SetAutoLogoffTimeout(0);

        if POSTerminal.get(pTerminalID) then;
        if not GetPosTerminalStoreAndPosFuncProfileV2(POSTerminal, Store, PosFunctionalityProfile, ErrorText, SSKProfile) then
            exit(ReturnErrorToKiosk(GetSettingsErrorOriginErr, '', ErrorText, '', pTerminalID));

        if BrowserControlId = '' then begin
            POSPanelControlLine.SetRange("Interface Profile ID", POSTerminal."Interface Profile");
            POSPanelControlLine.SetRange("Panel Control ID", Format("LSC POS Panel Id"::"#OFFLINE"));
            POSPanelControlLine.SetRange("Control Type", POSPanelControlLine."Control Type"::Browser);
            if POSPanelControlLine.FindFirst() then
                BrowserControlId := POSPanelControlLine."Control ID";
        end;

        JsonUtil.StartJSon();
        JsonUtil.AddToJSon('HTTPErrorCode', '200');
        JsonUtil.StartJSon('Settings');

        OnBeforeGetInitialSettings(JsonUtil, SSKProfile, PosFunctionalityProfile, Store, POSTerminal);

        GetSSKProfileSettings(JsonUtil, SSKProfile);

        JsonUtil.AddToJSon('StoreNo', Store."No.");
        JsonUtil.AddToJSon('StoreImage', POSSession().AddWebTemplateImage(Store.RecordId, '', Enum::"LSC Retail Image Link Type"::Logo));
        JsonUtil.AddToJSon('TerminalId', POSTerminal."No.");
        JsonUtil.AddToJSon('BrowserControlId', BrowserControlId);

        JsonUtil.AddToJSon('IdleTimeout', POSTerminal."AutoLogoff After (Min.)");

        GetSystemAndDefaultLanguage(SSKProfile);
        SetLanguageForSession(Store, PosFunctionalityProfile, LanguageCode);
        JsonUtil.AddToJSon('LanguageCode', LanguageCode);

        if POSTerminal."SSK Terminal Enabled" and KioskCalendarScheduleOpen(Store."No.") then begin
            if POSTerminal."Sales Type Filter" <> '' then
                GetSalesTypes(JsonUtil, POSTerminal, LanguageCode);
        end;

        JsonUtil.AddToJSon('CurrencySymbol', PosFunctionalityProfile."POS Currency Symbol");
        JsonUtil.AddToJSon('CurrencySymbolPlacem', PosFunctionalityProfile."Placement of LCY in Weight"); // 0=After, 1=Before
        JsonUtil.AddToJSon('Locale', LangCu.GetCultureName(LangCu.GetLanguageIdOrDefault(store."Language Code")));
        JsonUtil.AddToJSon('CrossSellingInfocode', SSKProfile."Checkout Cross-Sell. InfoCode");
        JsonUtil.EndJSon();

        if LoadHierarchies then begin
            NoOfHierarchies := GetHierarchiesInStore(Store, ErrorText);
            if ErrorText <> '' then
                exit(ReturnErrorToKiosk('GetSettings', '', ErrorText, '', pTerminalID));

            if not LoadHierarchiesInStore(POSTerminal, Store, SSKProfile, ErrorText) then
                exit(ReturnErrorToKiosk('GetSettings', '', ErrorText, '', pTerminalID));
            LastLanguageCode := LanguageCode;
        end;

        GetSSKProfileImages(JsonUtil, SSKProfile);
        GetLanguages(JsonUtil, SSKProfile, Store, LoadHierarchies, LanguageCode);
        GetSSKProfileTexts(JsonUtil, SSKProfile, LanguageCode);
        GetSSKColors(JsonUtil, SSKProfile);

        JsonUtil.EndJSon();
        exit(JsonUtil.GetJSon());
    end;

    internal procedure GetSalesTypesAndSSKProfileTextsInLanguage(BrowserControlId: Text; pTerminalID: Text; LanguageCode: Text): Text
    begin
        exit(GetInitialSettings(BrowserControlId, pTerminalID, LanguageCode, false));
    end;

    local procedure GetHierarchiesInStore(Store: Record "LSC Store"; var ErrorText: Text): Integer
    var
        HierarchyDate: Record "LSC Hierar. Date";
        HierarchyNo: Integer;
        ErrorNoHierarchies: Label 'There is no %1 defined for %2 %3.';
        ErrorTooManyHierarchies: Label 'There are %1 %2 records for %3 %4. There can only be %5.';
    begin
        ErrorText := '';
        HierarchyNo := HierarchyDate.GetHierarchyCodesInStore(Store."No.", HierarchiesInStore);
        if HierarchyNo = 0 then
            ErrorText := StrSubstNo(ErrorNoHierarchies, HierarchyDate.TableCaption, Store.TableCaption, Store."No.");
        if HierarchyNo > 20 then
            ErrorText := StrSubstNo(ErrorTooManyHierarchies, HierarchyNo, HierarchyDate.TableCaption, Store.TableCaption, Store."No.", 20);
        exit(HierarchyNo);
    end;

    local procedure LoadHierarchiesInStore(POSTerminal: Record "LSC POS Terminal"; Store: Record "LSC Store"; SSKProfile: Record "LSC SSK Profile"; var ErrorText: Text): Boolean
    var
        DynContBuffer: Record "LSC Dynamic Content Buffer" temporary;
        i: Integer;
        HierarchyCode: Code[20];
    begin
        for i := 1 to NoOfHierarchies do begin
            if HierarchiesInStore.Get(i, HierarchyCode) then begin
                if not GetDynamicContentBuffer(DynContBuffer, DynContTranslBuffer, DynContCurrAvailBuffer, POSTerminal, HierarchyCode, Store, SSKProfile, ErrorText) then
                    exit(false);
                DynContHierBuffer.LoadDynContBufferIntoHierarchyBuffer(DynContBuffer, DynContHierBuffer, HierarchyCode);
            end;
        end;
        exit(true);
    end;

    internal procedure POSMenuHierarchy2JSONV2(pTerminalID: Text; SelectedSalesType: Text; SelectedLanguage: Text): Text
    var
        HierarchyDateTmp: Record "LSC Hierar. Date" temporary;
        Store: Record "LSC Store";
        POSTerminal: Record "LSC POS Terminal";
        PosFunctionalityProfile: Record "LSC POS Func. Profile";
        DynamicContentBuffer: Record "LSC Dynamic Content Buffer" temporary;
        DynamicContentBufferTmp: Record "LSC Dynamic Content Buffer" temporary;
        DynamicContentBufferTmp2: Record "LSC Dynamic Content Buffer" temporary;
        DynamicContentBufferTmp3: Record "LSC Dynamic Content Buffer" temporary;
        DynamicContentBufferTmp4: Record "LSC Dynamic Content Buffer" temporary;
        JsonUtil: Codeunit "LSC POS JSON Util";
        HierarchyCode: Text;
        HierarchyNotFoundErr: Label '%1 %2 not found';
        ErrorText: Text;
        MenuDescription: Text;
        PopulateWithLanguage: Boolean;
        HierarchyLoadStartDateTime: DateTime;
        HierarchyLoadMin: Duration;
    begin
        PosCtrlInterface.SetAutoLogoffTimeout(0);

        if POSTerminal.get(pTerminalID) then;
        if not GetPosTerminalStoreAndPosFuncProfileV2(POSTerminal, Store, PosFunctionalityProfile, ErrorText) then
            exit(ReturnErrorToKiosk('GetHierarchy', '', ErrorText, '', pTerminalID));

        if (SelectedSalesType <> '') and (POSTerminal."Sales Type Filter" <> '') then
            POSTerminal."Sales Type Filter" := SelectedSalesType;

        HierarchyCode := HierarchyDateTmp.GetActiveHierarchyCode(HierarchyDateTmp, Store."No.", System.CurrentDateTime, POSTerminal."Sales Type Filter");

        if not HierarchiesInStore.Contains(HierarchyCode) then begin
            ErrorText := StrSubstNo(HierarchyNotFoundErr, HierarchyDateTmp."Hierarchy Code", HierarchyCode);
            exit(ReturnErrorToKiosk('GetHierarchy', '', ErrorText, '', pTerminalID));
        end;

        JsonUtil.StartJSon();
        JsonUtil.AddToJSon('HTTPErrorCode', '200');
        JsonUtil.AddToJSon('HierarcyCode', HierarchyCode);
        JsonUtil.AddToJSon('SalesType', SelectedSalesType);

        SetLanguageForSession(Store, PosFunctionalityProfile, SelectedLanguage);

        PopulateWithLanguage := true;
        if (LastHierarchyCode = '') and (SelectedLanguage = '') then
            PopulateWithLanguage := false;

        if (LastHierarchyCode = HierarchyCode) and (LastLanguageCode = SelectedLanguage) then
            PopulateWithLanguage := false;

        LastHierarchyCode := HierarchyCode;
        LastLanguageCode := SelectedLanguage;

        HierarchyLoadStartDateTime := CurrentDateTime;

        if PopulateWithLanguage then
            DynContTranslBuffer.TranslationBuffer_PopulateDynamicContentWithTranslations(DynContHierBuffer, DynContTranslBuffer, SelectedLanguage, HierarchyCode);

        DynContCurrAvailBuffer.AvailabilityBuffer_PopulateDynamicContentWithAvailability(Store."No.", DynContHierBuffer, DynContCurrAvailBuffer, HierarchyCode);

        DynContHierBuffer.LoadHierarchyBufferIntoDynContBuffer(DynContHierBuffer, DynamicContentBuffer, DynamicContentBufferTmp, DynamicContentBufferTmp2, DynamicContentBufferTmp3, DynamicContentBufferTmp4, HierarchyCode);

        DynamicContentBuffer.FindFirst(); //Level 0
        MenuDescription := DynamicContentBuffer.Description;

        JsonUtil.StartJSonArray('DynamicContentMenu');
        JsonUtil.StartJSon();
        JsonUtil.AddToJSon('NodeType', 'Title');
        JsonUtil.AddToJSon('NodeID', DynamicContentBuffer.DynamicContentId);
        JsonUtil.AddToJSon('Description', MenuDescription);
        JsonUtil.AddToJSon('Level', DynamicContentBuffer.Level);
        JsonUtil.EndJSon();

        DynamicContentBuffer.Reset();

        AddHierarchyChildren(JsonUtil, DynamicContentBuffer, DynamicContentBufferTmp, DynamicContentBufferTmp2, DynamicContentBufferTmp3, DynamicContentBufferTmp4, MenuDescription);

        JsonUtil.EndJSonArray();
        HierarchyLoadMin := CurrentDateTime - HierarchyLoadStartDateTime;
        JsonUtil.AddToJSon('HierarchyLoadMin', format(HierarchyLoadMin));
        JsonUtil.EndJSon();
        exit(JsonUtil.GetJSon());
    end;

    /// <summary>
    /// Payment/Void of current transaction
    /// </summary>
    internal procedure FinaliseSelfServiceTransaction(): Text
    var
        RetailUser: Record "LSC Retail User";
        POSTerminal: Record "LSC POS Terminal";
        MobileReceiptNo: Record "LSC Mobile Receipt No.";
        POSTransaction: Record "LSC POS Transaction";
        HospitalityType: Record "LSC Hospitality Type";
        JsonUtil: Codeunit "LSC POS JSON Util";
        TableRecNotFoundErr: Label 'No %1 found for %2 %3';
        POSTermNotFoundErr: Label 'No %1 found for %2 %3 %4';
    begin
        if not RetailUser.Get(UserId) then
            exit(ReturnErrorToKiosk('Finalize', '', StrSubstNo(TableRecNotFoundErr, RetailUser.TableCaption, UserId, ''), '', ''));

        if not POSTerminal.Get(RetailUser."POS Terminal") then
            exit(ReturnErrorToKiosk('Finalize', '', StrSubstNo(POSTermNotFoundErr, POSTerminal.TableCaption, RetailUser.TableCaption, RetailUser.FieldCaption("POS Terminal"), RetailUser."POS Terminal"), '', RetailUser."POS Terminal"));

        if not MobileReceiptNo.Get(POSTerminal."No.") then
            exit(ReturnErrorToKiosk('Finalize', '', StrSubstNo(TableRecNotFoundErr, MobileReceiptNo.TableCaption, POSTerminal.TableCaption, POSTerminal."No."), '', POSTerminal."No."));

        if not POSTransaction.get(MobileReceiptNo."Last Receipt No.") then
            exit(ReturnErrorToKiosk('Finalize', '', StrSubstNo(TableRecNotFoundErr, POSTransaction.TableCaption, MobileReceiptNo.TableCaption, MobileReceiptNo."Last Receipt No."), MobileReceiptNo."Last Receipt No.", POSTerminal."No."));

        HospitalityType.SetRange("Restaurant No.", POSTransaction."Store No.");
        HospitalityType.SetRange("Sales Type", POSTransaction."Sales Type");
        IF HospitalityType.FindFirst() then
            POSSession().SetValue("LSC POS Tag"::"HOSTYPSEQ", Format(HospitalityType.Sequence));

        //Set more possession values
        POSSession().SetValue("LSC POS Tag"::"CURRORDER", POSTransaction."Receipt No.");
        POSSession().SetValue("LSC POS Tag"::"SALESTYPE", POSTransaction."Sales Type");
        POSSession().SetValue("LSC POS Tag"::"SKIPVOIDCONFIRM", 'TRUE');
        PosCtrlInterface.SetAutoLogoffTimeout(POSTerminal."AutoLogoff After (Min.)");

        PosCtrlInterface.PostCommand("LSC POS Command"::LOGIN, ''); //Runs the POS to take payment

        JsonUtil.StartJSon();
        JsonUtil.AddToJSon('HTTPErrorCode', '200');
        JsonUtil.EndJSon();

        exit(JsonUtil.GetJSon());
    end;

    local procedure GetDynamicContentBuffer(
        var DynamicContentBufferTmp: Record "LSC Dynamic Content Buffer" temporary;
        var DynContTranslBufferIn: Record "LSC Dyn. Cont. Transl. Buffer" temporary;
        var DynContCurrAvailBufferIn: Record "LSC Dyn Cont Curr Avail Buffer" temporary;
        POSTerminal: Record "LSC POS Terminal";
        HierarchyCode: Text;
        Store: Record "LSC Store";
        SSKProfile: Record "LSC SSK Profile";
        var ErrorText: Text): Boolean
    var
        DynamicContentMgt: Codeunit "LSC Dynamic Content Mgt.";
        Hierarchy: Record "LSC Hierarchy";
        NoHierarchyCodeErr: Label 'No %1 found that matches the %2 of the %3';
        CreateTranslBuffer: Boolean;
        ImageSize: Integer;
    begin
        if not Hierarchy.Get(HierarchyCode) then begin
            ErrorText := StrSubstNo(NoHierarchyCodeErr, Hierarchy.TableCaption, POSTerminal.FieldCaption("Sales Type Filter"), POSTerminal.TableCaption);
            exit(false);
        end;

        CreateTranslBuffer := (SSKProfile."Language Profile ID" <> '');
        if not CreateTranslBuffer then
            if store."Language Code" <> '' then
                CreateTranslBuffer := true;

        ImageSize := 350;
        DynamicContentBufferTmp.DeleteAll();

        OnBeforeCreateDynamicContentBufferFromHierarchy(Hierarchy, POSTerminal."Default Sales Type", Store."No.", CreateTranslBuffer, ImageSize);
        DynamicContentMgt.CreateDynamicContentBufferFromHierarchyNodesWithTotalLanguageAndCurrAvailbilityMapping(Hierarchy, DynamicContentBufferTmp, DynContTranslBufferIn, DynContCurrAvailBufferIn, POSTerminal."Default Sales Type", Store."No.", '', CreateTranslBuffer, ImageSize);

        exit(true);
    end;

    procedure POSMenuHierarchy2JSON(var JsonUtil: Codeunit "LSC POS JSON Util"; var HierarcyCode: Text; var HierarchyFilter: Text; BrowserControlId: Text; pTerminalID: Text)
    begin
        POSMenuHierarchy2JSONV2(BrowserControlId, pTerminalID, '');
    end;

    internal procedure SetLanguageAndGetSettings(pTerminalID: Text; LanguageCode: Code[10]): Text
    begin
        exit(GetSalesTypesAndSSKProfileTextsInLanguage('', pTerminalID, LanguageCode))
    end;

    local procedure GetSystemAndDefaultLanguage(SSKProfile: Record "LSC SSK Profile")
    var
        LanguageProfileLine: Record "LSC Language Profile Line";
    begin
        if SSKProfile."Language Profile ID" = '' then begin
            DefaultLanguageCode := '';
            SystemLanguageCode := '';
            exit;
        end;
        LanguageProfileLine.SetRange(ID, SSKProfile."Language Profile ID");
        LanguageProfileLine.SetRange("Default Language", true);
        if LanguageProfileLine.FindFirst() then
            DefaultLanguageCode := LanguageProfileLine."Language Code";

        LanguageProfileLine.SetRange("Default Language");
        LanguageProfileLine.SetRange("System Language", true);

        if LanguageProfileLine.FindFirst() then
            SystemLanguageCode := LanguageProfileLine."Language Code";
    end;

    local procedure SetLanguageForSession(Store: Record "LSC Store"; POSFuncProfile: Record "LSC POS Func. Profile"; var LanguageCode: Text)
    begin
        if LanguageCode = '' then begin
            LanguageCode := GetStoreLanguageCodeWhenLanguageNotSpecified(Store, POSFuncProfile);
            if LanguageCode = '' then
                LanguageCode := DefaultLanguageCode;
        end;
        if SystemLanguageCode = LanguageCode then
            LanguageCode := '';

        SessionLanguageCode := LanguageCode;

        if (SessionLanguageCode = '') and (Store."Language Code" <> '') and (Store."Language Code" <> SystemLanguageCode) then
            SessionLanguageCode := SystemLanguageCode; //otherwise, the store.language code is going to be set as language code in the POS
    end;

    local procedure GetStoreLanguageCodeWhenLanguageNotSpecified(Store: Record "LSC Store"; POSFuncProfile: Record "LSC POS Func. Profile"): Code[10]
    var
        Staff: Record "LSC Staff";
    begin
        if Staff.Get(POSFuncProfile."Automatic Logon Staff ID") then
            if Staff.Language <> '' then
                exit(Staff.Language);

        if Store."Language Code" <> '' then
            exit(Store."Language Code");

        exit('');
    end;

    /// <summary>
    /// Returns initial data (Items etc.)
    /// </summary>
    /// <param name="JsonUtil"></param>
    /// <param name="HierarchyFilter"></param>
    /// <param name="BrowserControlId"></param>
    /// <param name="pTerminalID"></param>

    internal procedure AddHierarchyChildren(var JsonUtil: Codeunit "LSC POS JSON Util"; var ChildDynamicContentBufferTmp: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferTmp: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferTmp2: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferTmp3: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferTmp4: Record "LSC Dynamic Content Buffer" temporary; MenuDescription: Text)
    var
        Item: Record Item;
        Deal: Record "LSC Offer";
        CurrentMenuLevel: Integer;
        CurrentMenuDescription: array[100] of Text;
    begin
        clear(CurrentMenuDescription);
        CurrentMenuLevel := 0;
        CurrentMenuDescription[CurrentMenuLevel + 1] := MenuDescription;

        ChildDynamicContentBufferTmp.Setfilter(EntryType, '<>%1', '');
        if ChildDynamicContentBufferTmp.FindSet() then
            repeat
                case ChildDynamicContentBufferTmp.EntryType of
                    'Text':
                        begin
                            if CurrentMenuLevel = ChildDynamicContentBufferTmp.level then begin
                                JsonUtil.EndJSonArray(); //end same level menu
                                JsonUtil.EndJSon();
                            end else
                                if CurrentMenuLevel > ChildDynamicContentBufferTmp.level then begin
                                    while CurrentMenuLevel <> ChildDynamicContentBufferTmp.level do begin
                                        JsonUtil.EndJSonArray();
                                        JsonUtil.EndJSon();
                                        CurrentMenuLevel -= 1;
                                    end;
                                    JsonUtil.EndJSonArray(); //end same level menu
                                    JsonUtil.EndJSon();
                                end;
                            CurrentMenuLevel := ChildDynamicContentBufferTmp.Level;
                            POSMenuTextNode2JSON_brick(JsonUtil, ChildDynamicContentBufferTmp, DynamicContentBufferTmp, DynamicContentBufferTmp2, DynamicContentBufferTmp3, DynamicContentBufferTmp4, CurrentMenuDescription[CurrentMenuLevel]);
                            JsonUtil.StartJSonArray('MenuItems');
                            CurrentMenuDescription[CurrentMenuLevel + 1] := ChildDynamicContentBufferTmp.Description;
                        end;
                    'Offer':
                        begin
                            if ChildDynamicContentBufferTmp.Level - 1 < CurrentMenuLevel then begin  //belongs to previous menu
                                while CurrentMenuLevel <> ChildDynamicContentBufferTmp.level - 1 do begin
                                    JsonUtil.EndJSonArray();
                                    JsonUtil.EndJSon();
                                    CurrentMenuLevel -= 1;
                                end;
                            end;
                            if Deal.Get(ChildDynamicContentBufferTmp.EntryId) then begin
                                if deal.status = "LSC Toggle Status"::Enabled then
                                    POSMenuOffer2JSON_brick(JsonUtil, ChildDynamicContentBufferTmp, DynamicContentBufferTmp, DynamicContentBufferTmp2, DynamicContentBufferTmp3, DynamicContentBufferTmp4, Deal, CurrentMenuDescription[CurrentMenuLevel + 1]);
                            end;
                        end;
                    'Item', 'Recipe':
                        begin
                            if ChildDynamicContentBufferTmp.Level - 1 < CurrentMenuLevel then begin  //belongs to previous menu
                                while CurrentMenuLevel <> ChildDynamicContentBufferTmp.level - 1 do begin
                                    JsonUtil.EndJSonArray();
                                    JsonUtil.EndJSon();
                                    CurrentMenuLevel -= 1;
                                end;
                            end;
                            if Item.Get(ChildDynamicContentBufferTmp.EntryId) then begin
                                if not Item.Blocked then
                                    POSMenuRecipe2JSON_brick(JsonUtil, ChildDynamicContentBufferTmp, DynamicContentBufferTmp, DynamicContentBufferTmp2, DynamicContentBufferTmp3, DynamicContentBufferTmp4, CurrentMenuDescription[CurrentMenuLevel + 1]);
                            end;
                        end;
                end;
            until ChildDynamicContentBufferTmp.Next() = 0;

        while CurrentMenuLevel <> 1 do begin
            JsonUtil.EndJSonArray();
            JsonUtil.EndJSon();
            CurrentMenuLevel -= 1;
        end;
        JsonUtil.EndJSonArray();
        JsonUtil.EndJSon();
    end;

    local procedure GetSSKProfileSettings(var JsonUtil: Codeunit "LSC POS JSON Util"; SSKProfile: Record "LSC SSK Profile")
    begin
        JsonUtil.AddToJSon('AllowMemberScanning', SSKProfile."Scan Member");
        JsonUtil.AddToJSon('AllowItemScanning', SSKProfile."Item Scanning Enabled");
        JsonUtil.AddToJSon('AllowQueueCounter', SSKProfile."Display Queue Counter");
        JsonUtil.AddToJSon('CurrencyCode', SSKProfile."Currency Code");
        JsonUtil.AddToJSon('DisplayHTML', SSKProfile."Display Item HTML");
        JsonUtil.AddToJSon('LanguageProfileID', SSKProfile."Language Profile ID");
        JsonUtil.StartJSon('Accessibility');
        JsonUtil.AddToJSon('AllowAccessibility', SSKProfile."Enable Accessibility");
        if SSKProfile."Enable Accessibility" then begin
            JsonUtil.AddToJSon('AccessibilityHeight', SSKProfile."Accessibility Height");
            JsonUtil.AddToJSon('AccessibilityWidth', SSKProfile."Accessibility Width");
            JsonUtil.AddToJSon('HorizontalAlignment', SSKProfile."Horizontal Alignment".AsInteger());
            JsonUtil.AddToJSon('VerticalAlignment', SSKProfile."Vertical Alignment".AsInteger());
        end;
        JsonUtil.EndJSon();
    end;

    internal procedure GetHierarchySchedule(POSTerminalNo: Code[10]; StoreNo: Code[10]; LanguageCode: Code[10]): Text
    var
        POSTerminal: Record "LSC POS Terminal";
        JsonUtil: Codeunit "LSC POS JSON Util";
    begin
        if not POSTerminal.Get(POSTerminalNo) then
            exit('');
        if not POSTerminal."SSK Terminal Enabled" then
            exit('');
        if KioskCalendarScheduleOpen(StoreNo) then begin
            JsonUtil.StartJSonArray('HierarchySchedule');
            GetSalesTypes(JsonUtil, POSTerminal, LanguageCode);
            JsonUtil.EndJSonArray();
            exit(JsonUtil.GetJSon());
        end;
        exit('');
    end;

    internal procedure KioskCalendarScheduleOpen(StoreNo: Code[10]): Boolean
    begin
        exit(KioskCalendarScheduleOpen(StoreNo, System.CurrentDateTime.Date, System.CurrentDateTime.Time))
    end;

    internal procedure KioskCalendarScheduleOpen(StoreNo: Code[10]; CheckDate: Date; CheckTime: Time): Boolean
    var
        RetailCalMgt: Codeunit "LSC Retail Calendar Management";
        CalendarRec: Record "LSC Retail Calendar";
    begin
        if RetailCalMgt.FindCalendarRec(StoreNo, "LSC Retail Calendar Type"::"Self Service Kiosk", CalendarRec) then
            exit(RetailCalMgt.StoreOpenAtTime(StoreNo, "LSC Retail Calendar Type"::"Self Service Kiosk", CheckDate, CheckTime));
        if RetailCalMgt.FindCalendarRec(StoreNo, "LSC Retail Calendar Type"::"Opening Hours", CalendarRec) then
            exit(RetailCalMgt.StoreOpenAtTime(StoreNo, "LSC Retail Calendar Type"::"Opening Hours", CheckDate, CheckTime));
        exit(true);
    end;

    local procedure GetSSKProfileImages(var JsonUtil: Codeunit "LSC POS JSON Util"; SSKProfile: Record "LSC SSK Profile")
    var
        SSKProfileImage: Record "LSC SSK Profile Image";
    begin
        JsonUtil.StartJSonArray('Images');
        SSKProfileImage.SetRange("SSK Profile ID", SSKProfile."Profile ID");
        if SSKProfileImage.FindSet() then
            repeat
                JsonUtil.StartJSon();
                JsonUtil.AddToJSon('ImageType', Format(SSKProfileImage."Type"));
                JsonUtil.AddToJSon('Image', POSSession().AddWebTemplateImage(SSKProfileImage.RecordId, ''));
                JsonUtil.AddToJSon('VideoFilePath', SSKProfileImage."Video URI");
                JsonUtil.EndJSon();
            until SSKProfileImage.Next() = 0;
        JsonUtil.EndJSonArray();
    end;

    local procedure GetSalesTypes(var JsonUtil: Codeunit "LSC POS JSON Util"; POSTerminal: Record "LSC POS Terminal"; LanguageCode: Code[10])
    var
        SalesType: Record "LSC Sales Type";
        HierarchyDateTmp: Record "LSC Hierar. Date" temporary;
        SalesTypeFilterList: List of [Text];
        SalesTypeCode: Text;
        SalesTypeFilterText: Text;
        HierarchyCode: Code[20];
    begin
        SalesTypeFilterText := CopyStr(POSTerminal."Sales Type Filter", 1);
        SalesTypeFilterList := SalesTypeFilterText.Split('|');
        IF SalesTypeFilterList.Count <> 0 then begin
            JsonUtil.StartJSonArray('SalesTypes');
            foreach SalesTypeCode in SalesTypeFilterList do

                if SalesType.Get(SalesTypeCode) then begin
                    HierarchyCode := HierarchyDateTmp.GetActiveHierarchyCode(HierarchyDateTmp, POSTerminal."Store No.", System.CurrentDateTime, SalesType.Code);
                    if HierarchyCode <> '' then begin
                        JsonUtil.StartJSon();
                        JsonUtil.AddToJSon('SalesType', SalesType.Code);
                        JsonUtil.AddToJSon('SalesTypeDescription', GetSSKProfileSalesTypeTranslation(SalesType, LanguageCode));
                        JsonUtil.AddToJSon('Image', POSSession().AddWebTemplateImage(SalesType.RecordId, ''));
                        JsonUtil.AddToJSon('HierarchyCode', HierarchyCode);
                        JsonUtil.EndJSon();
                    end;
                end;
            JsonUtil.EndJSonArray();
        end;
    end;

    local procedure GetLanguages(var JsonUtil: Codeunit "LSC POS JSON Util"; SSKProfile: Record "LSC SSK Profile"; Store: Record "LSC Store"; GetTranslations: Boolean; SelectedLanguageCode: Code[10])
    var
        LanguageProfileLine: Record "LSC Language Profile Line";
        i: Integer;
        HierCode: Code[20];
    begin
        JsonUtil.StartJSonArray('Languages');
        LanguageProfileLine.SetCurrentKey(Order);
        LanguageProfileLine.SetRange(ID, SSKProfile."Language Profile ID");
        if LanguageProfileLine.FindSet() then
            repeat
                JsonUtil.StartJSon();
                JsonUtil.AddToJSon('LanguageCode', LanguageProfileLine."Language Code");
                JsonUtil.AddToJSon('LanguageName', LanguageProfileLine."Language Description");
                JsonUtil.AddToJSon('DefaultLanguage', LanguageProfileLine."Default Language");
                JsonUtil.AddToJSon('Image', POSSession().AddWebTemplateImage(LanguageProfileLine.RecordId, ''));

                if GetTranslations then
                    if not LanguageProfileLine."System Language" then
                        for i := 1 to NoOfHierarchies do begin
                            HierarchiesInStore.get(i, HierCode);
                            DynContTranslBuffer.TranslationBuffer_Translate(DynContTranslBuffer, LanguageProfileLine."Language Code", HierCode);
                        end;
                JsonUtil.EndJSon();
            until LanguageProfileLine.Next() = 0
        else
            if GetTranslations then
                if store."Language Code" <> '' then
                    for i := 1 to NoOfHierarchies do begin
                        HierarchiesInStore.get(i, HierCode);
                        DynContTranslBuffer.TranslationBuffer_Translate(DynContTranslBuffer, SelectedLanguageCode, HierCode);
                    end;
        Jsonutil.EndJSonArray();
    end;

    local procedure GetSSKProfileTexts(var JsonUtil: Codeunit "LSC POS JSON Util"; SSKProfile: Record "LSC SSK Profile"; LanguageCode: Code[10])
    var
        SSKProfileText: Record "LSC SSK Profile Text";
    begin
        JsonUtil.StartJSonArray('textConstants');
        SSKProfileText.SetRange("SSK Profile ID", SSKProfile."Profile ID");
        if SSKProfileText.FindSet() then begin
            repeat
                JsonUtil.StartJSon();
                JsonUtil.AddToJSon('type', Format(SSKProfileText."Type"));
                JsonUtil.AddToJSon('textValue', GetSSKProfileTextConstantTranslation(SSKProfileText, LanguageCode));
                JsonUtil.EndJSon();
            until SSKProfileText.Next() = 0;
        end;
        JsonUtil.EndJSonArray();
    end;

    local procedure GetSSKColors(var JsonUtil: Codeunit "LSC POS JSON Util"; SSKProfile: Record "LSC SSK Profile")
    var
        SSKColor: Record "LSC SSK Profile Color";
    begin
        JsonUtil.StartJSonArray('Colors');
        SSKColor.SetRange("SSK Profile ID", SSKProfile."Profile ID");
        if SSKColor.FindSet() then begin
            repeat
                JsonUtil.StartJSon();
                JsonUtil.AddToJSon('ColorType', Format(SSKColor."Type"));
                JsonUtil.AddToJSon('FontColor', Format(SSKColor."Font Color"));
                JsonUtil.AddToJSon('BackgroundColor', Format(SSKColor."Background Color"));
                JsonUtil.EndJSon();
            until SSKColor.Next() = 0;
        end;
        JsonUtil.EndJSonArray();
    end;

    local procedure GetSSKProfileTextConstantTranslation(SSKProfileText: Record "LSC SSK Profile Text"; LanguageCode: Code[10]): Text
    var
        DataTranslationSetup: Record "LSC Data Translation Setup";
    begin
        exit(DataTranslationSetup.GetFieldTranslation(database::"LSC SSK Profile Text", SSKProfileText.FieldNo("Text Value"), CombineKey2Values(SSKProfileText."SSK Profile ID", Format(SSKProfileText."Type")), Format(SSKProfileText."Text Value"), LanguageCode));
    end;

    local procedure GetSSKProfileSalesTypeTranslation(SalesType: Record "LSC Sales Type"; LanguageCode: Code[10]): Text
    var
        DataTranslationSetup: Record "LSC Data Translation Setup";
    begin
        exit(DataTranslationSetup.GetFieldTranslation(database::"LSC Sales Type", SalesType.FieldNo(Description), SalesType.Code, SalesType.Description, LanguageCode));
    end;

    local procedure CombineKey2Values(Key1: Text; Key2: Text): Text
    var
        DataTranslationMgt: Codeunit "LSC Data Translation Mgt";
        Value3: Text;
        Value4: Text;
        Value5: Text;
    begin
        exit(DataTranslationMgt.CombineTableKey(2, Key1, key2, Value3, Value4, Value5));
    end;

    internal procedure POSMenuTextNode2JSON_brick(var JsonUtil: Codeunit "LSC POS JSON Util"; var DynamicContentBufferEntryTmp: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferTmp: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferTmp2: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferTmp3: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferTmp4: Record "LSC Dynamic Content Buffer" temporary; ParentMenu: Text)
    begin
        JsonUtil.StartJSon();
        JsonUtil.AddToJSon('NodeType', 'Node');
        JsonUtil.AddToJSon('Description', DynamicContentBufferEntryTmp.Description);
        JsonUtil.AddToJSon('NodeID', DynamicContentBufferEntryTmp."Node ID");
        JsonUtil.AddToJSon('Level', DynamicContentBufferEntryTmp.Level);
        JsonUtil.AddToJSon('Image', DynamicContentBufferEntryTmp.ImageId);
        JsonUtil.AddToJSon('Parent', ParentMenu);
    end;

    local procedure GetPOSMenuItemUOM(var JsonUtil: Codeunit "LSC POS JSON Util"; var ItemDynamicContentBufferTmp: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferTmp: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferItemPriceTmp: Record "LSC Dynamic Content Buffer" temporary)
    begin
        JsonUtil.StartJSonArray('UOM');

        DynamicContentBufferTmp.Reset();
        DynamicContentBufferItemPriceTmp.Reset();

        DynamicContentBufferTmp.SetRange(ItemId, ItemDynamicContentBufferTmp.ItemId);
        DynamicContentBufferTmp.SetRange(sectionid, 'ITEMUOM');
        IF DynamicContentBufferTmp.FindSet() then begin
            repeat
                JsonUtil.StartJSon();
                IF ItemDynamicContentBufferTmp.ItemUoM = DynamicContentBufferTmp.ItemUoM then
                    JsonUtil.AddToJSon('DefaultUOM', true)
                else
                    JsonUtil.AddToJSon('DefaultUOM', false);

                JsonUtil.AddToJSon('Description', DynamicContentBufferTmp.Description);
                JsonUtil.AddToJSon('ItemUoM', DynamicContentBufferTmp.ItemUoM);
                JsonUtil.AddToJSon('Order', DynamicContentBufferTmp.Order);
                JsonUtil.AddToJSon('UomFactor', DynamicContentBufferTmp.UomFactor);
                DynamicContentBufferItemPriceTmp.SetRange(ItemId, DynamicContentBufferTmp.ItemId);
                DynamicContentBufferItemPriceTmp.SetRange(ItemUoM, DynamicContentBufferTmp.ItemUoM);
                DynamicContentBufferItemPriceTmp.SetRange(SectionId, 'ITEMPRICE');
                IF DynamicContentBufferItemPriceTmp.FindFirst() then begin
                    JsonUtil.AddToJSon('UOMPrice', DynamicContentBufferItemPriceTmp.ItemPrice);
                    JsonUtil.AddToJSon('PriceGroup', DynamicContentBufferItemPriceTmp.ItemPriceGr);
                end;
                JsonUtil.EndJSon();
            until DynamicContentBufferTmp.Next() = 0;
        end;
        JsonUtil.EndJSonArray();

        DynamicContentBufferTmp.Reset();
        DynamicContentBufferItemPriceTmp.Reset();
    end;

    local procedure GetItemUpsell(var JsonUtil: Codeunit "LSC POS JSON Util"; var ItemDynamicContentBufferTmp: Record "LSC Dynamic Content Buffer" temporary)
    var
        Hierarchy: Record "LSC Hierarchy";
        HierarchyUpsell: Record "LSC Hierarchy Upsell";
    begin

        JsonUtil.StartJSonArray('Upsell');

        if Hierarchy.Get(LastHierarchyCode) then
            if Hierarchy."Upsell Active" then begin
                HierarchyUpsell.SetRange("Hierarchy Code", Hierarchy."Hierarchy Code");
                HierarchyUpsell.SetRange("Item No.", ItemDynamicContentBufferTmp.ItemId);
                HierarchyUpsell.SetRange(Upsell, True);
                if HierarchyUpsell.FindSet() then
                    repeat
                        JsonUtil.StartJSon();
                        JsonUtil.AddToJSon('UpsellDeal', HierarchyUpsell."Deal No.");
                        GetHierarchyNodePath(JsonUtil, Hierarchy."Hierarchy Code", HierarchyUpsell."Node ID");
                        JsonUtil.EndJSon();
                    until HierarchyUpsell.Next() = 0;
            end;

        JsonUtil.EndJSonArray();
    end;

    local procedure GetHierarchyNodePath(var JsonUtil: Codeunit "LSC POS JSON Util"; HierarchyCode: Code[20]; NodeID: Text[30])
    var
        ParentNode: Text[30];
    begin
        ParentNode := NodeID;

        JsonUtil.StartJSonArray('NodePath');
        repeat
            JsonUtil.AddToJSon(ParentNode);
            ParentNode := GetHierarchyNodeParent(HierarchyCode, ParentNode);
        until ParentNode = '';
        JsonUtil.EndJSonArray();
    end;

    local procedure GetHierarchyNodeParent(HierarchyCode: Code[20]; NodeID: Text[30]): Text[30]
    var
        HierarchyNodes: Record "LSC Hierar. Nodes";
    begin
        if HierarchyNodes.Get(HierarchyCode, NodeID) then
            exit(HierarchyNodes."Parent Node ID");
        exit('');
    end;

    internal procedure POSMenuOffer2JSON_brick(var JsonUtil: Codeunit "LSC POS JSON Util"; var DealDynamicContentBufferTmp: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferTmp: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferTmp2: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferTmp3: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferTmp4: Record "LSC Dynamic Content Buffer" temporary; Deal: Record "LSC Offer"; ParentMenu: Text)
    var
        imgID: Text;
        AvailabilitySet: Boolean;
        Availability: Decimal;
        AvailabilityUOM: Code[10];
        AvailabilityFactor: Decimal;
    begin
        DynamicContentBufferTmp.Reset();
        JsonUtil.StartJSon();
        JsonUtil.AddToJSon('NodeType', DealDynamicContentBufferTmp.EntryType);

        DynamicContentBufferTmp.SetRange(OfferId, DealDynamicContentBufferTmp.EntryID);
        DynamicContentBufferTmp.SetRange(SectionId, 'OFFER');
        if DynamicContentBufferTmp.FindFirst() then begin
            OnBeforePOSMenuOffer2JSON_brickAddToJson(JsonUtil, DealDynamicContentBufferTmp, DynamicContentBufferTmp, DynamicContentBufferTmp2, DynamicContentBufferTmp3, DynamicContentBufferTmp4, Deal, ParentMenu);
            JsonUtil.AddToJSon('DealNo', DynamicContentBufferTmp.OfferId);
            JsonUtil.AddToJSon('Description', DynamicContentBufferTmp.OfferDescription);
            JsonUtil.AddToJSon('SecondDescription', DynamicContentBufferTmp.OfferSecondaryDescription);
            JsonUtil.AddToJSon('Price', DynamicContentBufferTmp.OfferPrice);
            JsonUtil.AddToJSon('AvailabilitySet', DynamicContentBufferTmp.CurrentAvailabilitySet);
            JsonUtil.AddToJSon('Availability', DynamicContentBufferTmp.CurrentAvailability);
            JsonUtil.AddToJSon('AvailabilityUOM', DynamicContentBufferTmp.CurrentAvailabilityUOM);
            JsonUtil.AddToJSon('AvailabilityFactor', 1);
        end;
        DynamicContentBufferTmp.Reset();

        JsonUtil.AddToJSon('Image', DealDynamicContentBufferTmp.ImageId);
        JsonUtil.AddToJSon('Level', DealDynamicContentBufferTmp.Level);
        JsonUtil.AddToJSon('Parent', ParentMenu);

        JsonUtil.StartJSonArray('OfferLines');

        DynamicContentBufferTmp.Reset();
        DynamicContentBufferTmp.SetRange(OfferId, DealDynamicContentBufferTmp.EntryId);
        DynamicContentBufferTmp.SetRange(SectionId, 'OFFERLINE');
        if DynamicContentBufferTmp.FindSet() then begin
            repeat
                if DynamicContentBufferTmp.OfferLineType = 'Item' then begin
                    JsonUtil.StartJSon();
                    JsonUtil.AddToJSon('ItemNo', DynamicContentBufferTmp.DefaultItemId);
                    JsonUtil.AddToJSon('Description', DynamicContentBufferTmp.OfferLineDescription);
                    JsonUtil.AddToJSon('Quantity', DynamicContentBufferTmp.OfferLineQty);
                    JsonUtil.AddToJSon('Price', 0);
                    JsonUtil.AddToJSon('ItemUOM', DynamicContentBufferTmp.ItemUoM);
                    JsonUtil.AddToJSon('UoMDescription', DynamicContentBufferTmp.EntryUomDescription);
                    JsonUtil.AddToJSon('UoMFactor', DynamicContentBufferTmp.UomFactor);
                    JsonUtil.AddToJSon('MaxQuantity', DynamicContentBufferTmp.MaxSelection);
                    JsonUtil.AddToJSon('MinQuantity', DynamicContentBufferTmp.MinSelection);

                    GetAvailabilityAndImageForItem(DynamicContentBufferTmp.DefaultItemId, DynamicContentBufferTmp4, AvailabilitySet, Availability, imgID, '', AvailabilityUOM, AvailabilityFactor);
                    JsonUtil.AddToJSon('AvailabilitySet', AvailabilitySet);
                    JsonUtil.AddToJSon('Availability', Availability);
                    JsonUtil.AddToJSon('AvailabilityUOM', AvailabilityUOM);
                    JsonUtil.AddToJSon('AvailabilityFactor', AvailabilityFactor);
                    JsonUtil.AddToJSon('Image', imgID);

                    JsonUtil.AddToJSon('OfferLineType', DynamicContentBufferTmp.OfferLineType);
                    JsonUtil.AddToJSon('OfferLine', DynamicContentBufferTmp.OfferLineId);

                    GetIngredientsAndModifiersForRecipe(JsonUtil, DynamicContentBufferTmp.DefaultItemId, 0, DynamicContentBufferTmp2, DynamicContentBufferTmp3, DynamicContentBufferTmp4);
                    JsonUtil.EndJSon();
                end else begin
                    JsonUtil.StartJSon();
                    DynamicContentBufferTmp3.Reset();
                    DynamicContentBufferTmp3.SetRange(OfferId, DynamicContentBufferTmp.OfferId);
                    DynamicContentBufferTmp3.SetRange(OfferLineId, DynamicContentBufferTmp.OfferLineId);
                    DynamicContentBufferTmp3.SetRange(SectionId, 'OFFERMODGR');
                    IF DynamicContentBufferTmp3.FindFirst() then;
                    JsonUtil.AddToJSon('DealModGroupId', DynamicContentBufferTmp3.DealModGroupId);
                    JsonUtil.AddToJSon('DealModGroupDescription', DynamicContentBufferTmp.OfferLineDescription);
                    JsonUtil.AddToJSon('DealModGroupMaxQuantity', DynamicContentBufferTmp3.MaxSelection);
                    JsonUtil.AddToJSon('DealModGroupMinQuantity', DynamicContentBufferTmp3.MinSelection);
                    JsonUtil.AddToJSon('DealModDisplayPrompt', DynamicContentBufferTmp.DisplayPrompt);

                    JsonUtil.AddToJSon('SelectedGroup', True); //one item always selected for each deal modifier group

                    JsonUtil.AddToJSon('OfferLineType', DynamicContentBufferTmp.OfferLineType);
                    JsonUtil.AddToJSon('OfferLine', DynamicContentBufferTmp.OfferLineId);

                    DynamicContentBufferTmp3.Reset();

                    GetDealModifierItems(JsonUtil, DealDynamicContentBufferTmp.EntryId, DynamicContentBufferTmp, DynamicContentBufferTmp2, DynamicContentBufferTmp3);
                    JsonUtil.EndJSon();
                end;
            until DynamicContentBufferTmp.Next() = 0;
        end;

        JsonUtil.EndJSonArray();
        JsonUtil.EndJSon();

        DynamicContentBufferTmp.Reset();
        DynamicContentBufferTmp2.Reset();
        DynamicContentBufferTmp3.Reset();
        DynamicContentBufferTmp4.Reset();
    end;

    local procedure GetDealModifierItems(var JsonUtil: Codeunit "LSC POS JSON Util"; DealNo: Code[20]; var DynamicContentBufferTmp: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferTmp2: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferTmp3: Record "LSC Dynamic Content Buffer" temporary)
    var
        AvailabilitySet: Boolean;
        Availability: Decimal;
        AvailabilityUOM: Code[10];
        AvailabilityFactor: Decimal;
        LastItemNo: Text;
        ModifierSelectedByDefault: Boolean;
        imgID: Text;
    begin
        LastItemNo := '';
        DynamicContentBufferTmp2.Reset();
        DynamicContentBufferTmp2.SetRange(OfferId, DynamicContentBufferTmp.OfferId);
        DynamicContentBufferTmp2.SetRange(OfferLineId, DynamicContentBufferTmp.OfferLineId);
        DynamicContentBufferTmp2.SetRange(SectionId, 'OFFERMODGRITEM');
        IF DynamicContentBufferTmp2.FindSet() then begin
            JsonUtil.StartJSonArray('DealModGroupItems');
            repeat
                if LastItemNo <> DynamicContentBufferTmp2.ItemId then begin
                    if LastItemNo <> '' then begin
                        JsonUtil.EndJSonArray();
                        JsonUtil.AddToJSon('SelectedItem', ModifierSelectedByDefault);
                        if ModifierSelectedByDefault then
                            JsonUtil.AddToJSon('SelQuantity', 1)
                        else
                            JsonUtil.AddToJSon('SelQuantity', 0);
                        JsonUtil.EndJSon();
                    end;
                    ModifierSelectedByDefault := false;
                    LastItemNo := DynamicContentBufferTmp2.itemid;
                    JsonUtil.StartJSon();
                    JsonUtil.AddToJSon('ItemNo', DynamicContentBufferTmp2.ItemId);
                    JsonUtil.AddToJSon('Description', DynamicContentBufferTmp2.Description);

                    GetAvailabilityAndImageForItem(DynamicContentBufferTmp2.ItemId, DynamicContentBufferTmp3, AvailabilitySet, Availability, imgID, '', AvailabilityUOM, AvailabilityFactor);
                    JsonUtil.AddToJSon('AvailabilitySet', AvailabilitySet);
                    JsonUtil.AddToJSon('Availability', Availability);
                    JsonUtil.AddToJSon('AvailabilityUOM', AvailabilityUOM);
                    JsonUtil.AddToJSon('AvailabilityFactor', AvailabilityFactor);
                    JsonUtil.AddToJSon('Image', imgID);

                    JsonUtil.AddToJSon('ParentDealNo', DealNo);

                    JsonUtil.StartJSonArray('ItemUom');

                    InsertDealModifierItemUOMAndPrice(JsonUtil, DynamicContentBufferTmp2, DynamicContentBufferTmp.DefaultLineId, ModifierSelectedByDefault);
                end else
                    InsertDealModifierItemUOMAndPrice(JsonUtil, DynamicContentBufferTmp2, DynamicContentBufferTmp.DefaultLineId, ModifierSelectedByDefault);
            until DynamicContentBufferTmp2.Next() = 0;
            JsonUtil.EndJSonArray();
            JsonUtil.AddToJSon('SelectedItem', ModifierSelectedByDefault);
            if ModifierSelectedByDefault then
                JsonUtil.AddToJSon('SelQuantity', 1)
            else
                JsonUtil.AddToJSon('SelQuantity', 0);

            JsonUtil.EndJSon();
            JsonUtil.EndJSonArray();
        end;
        DynamicContentBufferTmp2.Reset();
    end;

    local procedure InsertDealModifierItemUOMAndPrice(var JsonUtil: Codeunit "LSC POS JSON Util"; var DynamicContentBufferTmp2: Record "LSC Dynamic Content Buffer" temporary; DefaultLineID: Integer; var DefaultSelected: Boolean)
    begin
        JsonUtil.StartJSon();
        JsonUtil.AddToJSon('DefaultQuantity', 0);
        JsonUtil.AddToJSon('Price', DynamicContentBufferTmp2.DealModPrice);
        JsonUtil.AddToJSon('ItemUOM', DynamicContentBufferTmp2.ItemModUoM);
        JsonUtil.AddToJSon('UoMDescription', DynamicContentBufferTmp2.ItemModUoMDescription);
        JsonUtil.AddToJSon('MaxQuantity', DynamicContentBufferTmp2.MaxSelection);
        JsonUtil.AddToJSon('MinQuantity', DynamicContentBufferTmp2.MinSelection);
        JsonUtil.AddToJSon('DealLine', DynamicContentBufferTmp2.OfferLineId);
        JsonUtil.AddToJSon('DealModLine', DynamicContentBufferTmp2.DealModLineId);
        if DefaultLineId = DynamicContentBufferTmp2.DealModLineId then begin
            JsonUtil.AddToJSon('Default', True);
            JsonUtil.AddToJSon('SelectedItem', True);
            JsonUtil.AddToJSon('SelQuantity', 1);
            DefaultSelected := true;
        end else begin
            JsonUtil.AddToJSon('Default', false);
            JsonUtil.AddToJSon('SelectedItem', false);
            JsonUtil.AddToJSon('SelQuantity', 0);
        end;
        JsonUtil.EndJSon();
    end;

    internal procedure POSMenuRecipe2JSON_brick(var JsonUtil: Codeunit "LSC POS JSON Util"; VAR DynamicContentBufferOriginalTmp: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferTmp: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferTmp2: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferTmp3: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferModGroupItemTmp: Record "LSC Dynamic Content Buffer" temporary; ParentMenu: Text)
    begin
        DynamicContentBufferTmp.SetRange(SectionId, 'ITEM');
        DynamicContentBufferTmp.SetRange(ItemId, DynamicContentBufferOriginalTmp.EntryId);
        if not DynamicContentBufferTmp.FindFirst() then begin
            DynamicContentBufferTmp.Reset();
            exit;
        end;
        JsonUtil.StartJSon();
        OnBeforePOSMenuRecipe2JSON_brickAddToJson(JsonUtil, DynamicContentBufferOriginalTmp, DynamicContentBufferTmp, DynamicContentBufferTmp2, DynamicContentBufferTmp3, DynamicContentBufferModGroupItemTmp, ParentMenu);
        JsonUtil.AddToJSon('NodeType', 'Recipe');
        JsonUtil.AddToJSon('ItemNo', DynamicContentBufferTmp.ItemId);
        JsonUtil.AddToJSon('Description', DynamicContentBufferTmp.ItemDescription);
        JsonUtil.AddToJSon('Price', DynamicContentBufferTmp.ItemPrice);
        if DynamicContentBufferOriginalTmp.EntryUoM <> '' then begin
            JsonUtil.AddToJSon('ItemUOM', DynamicContentBufferOriginalTmp.EntryUoM);
            JsonUtil.AddToJSon('UoMDescription', DynamicContentBufferOriginalTmp.EntryUomDescription);
        end else begin
            JsonUtil.AddToJSon('ItemUOM', DynamicContentBufferTmp.ItemUoM);
            JsonUtil.AddToJSon('UoMDescription', DynamicContentBufferTmp.EntryUomDescription);
            JsonUtil.AddToJSon('UoMFactor', DynamicContentBufferTmp.UomFactor);
        end;

        JsonUtil.AddToJSon('Image', DynamicContentBufferTmp.ImageId);
        JsonUtil.AddToJSon('AvailabilitySet', DynamicContentBufferTmp.CurrentAvailabilitySet);
        JsonUtil.AddToJSon('Availability', DynamicContentBufferTmp.CurrentAvailability);
        JsonUtil.AddToJSon('AvailabilityUOM', DynamicContentBufferTmp.CurrentAvailabilityUOM);
        JsonUtil.AddToJSon('AvailabilityFactor', DynamicContentBufferTmp.CurrentAvailItemQtyPerUOM);

        JsonUtil.AddToJSon('Level', DynamicContentBufferOriginalTmp.Level);
        JsonUtil.AddToJSon('Parent', ParentMenu);

        GetIngredientsAndModifiersForRecipe(JsonUtil, DynamicContentBufferTmp.ItemId, DynamicContentBufferTmp.ItemPrice, DynamicContentBufferTmp2, DynamicContentBufferTmp3, DynamicContentBufferModGroupItemTmp);

        GetPOSMenuItemUOM(JsonUtil, DynamicContentBufferTmp, DynamicContentBufferTmp2, DynamicContentBufferModGroupItemTmp);

        GetItemUpsell(JsonUtil, DynamicContentBufferTmp);

        DynamicContentBufferTmp.Reset();
        DynamicContentBufferTmp2.Reset();
        DynamicContentBufferTmp3.Reset();
        DynamicContentBufferModGroupItemTmp.Reset();

        JsonUtil.EndJSon();
    end;

    local procedure GetIngredientsAndModifiersForRecipe(var JsonUtil: Codeunit "LSC POS JSON Util"; ItemNo: Code[20]; ItemPrice: Decimal; var DynamicContentBufferTmp2: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferTmp3: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferModGroupItemTmp: Record "LSC Dynamic Content Buffer" temporary)
    begin
        AddIngredientsToJson(JsonUtil, ItemNo, DynamicContentBufferTmp3);
        AddModifierGroupsToJson(JsonUtil, ItemNo, ItemPrice, DynamicContentBufferTmp2, DynamicContentBufferTmp3, DynamicContentBufferModGroupItemTmp, 'ITEMMODGR', 'MODGR', 'MODGRITEM');
        AddCrossSellsCodesToJson(JsonUtil, ItemNo, DynamicContentBufferTmp2);
    end;

    local procedure AddIngredientsToJson(var JsonUtil: Codeunit "LSC POS JSON Util"; ItemNo: Code[20]; var DynamicContentBufferTmp3: Record "LSC Dynamic Content Buffer" temporary)
    begin
        JsonUtil.StartJSonArray('Ingredients');

        DynamicContentBufferTmp3.Reset();
        DynamicContentBufferTmp3.SetRange(ItemId, ItemNo);
        DynamicContentBufferTmp3.SetRange(SectionId, 'INGREDIENT');
        DynamicContentBufferTmp3.SetFilter(IngredientItemId, '<>%1', '');
        if DynamicContentBufferTmp3.FindSet() then begin
            repeat
                JsonUtil.StartJSon();
                JsonUtil.AddToJSon('ItemNo', DynamicContentBufferTmp3.IngredientItemId);
                JsonUtil.AddToJSon('Description', DynamicContentBufferTmp3.IngredientItemDescription);
                JsonUtil.AddToJSon('SelQuantity', DynamicContentBufferTmp3.BOMQuantity);
                JsonUtil.AddToJSon('DefaultQuantity', DynamicContentBufferTmp3.BOMQuantity);
                JsonUtil.AddToJSon('IngredientExcludeable', DynamicContentBufferTmp3.IngredientExcludeable);
                JsonUtil.AddToJSon('PriceReductionOnExclusion', DynamicContentBufferTmp3.PriceReductionOnExclusion);
                JsonUtil.AddToJSon('PriceReduction', DynamicContentBufferTmp3.PriceReduction);
                JsonUtil.AddToJSon('ItemUOM', DynamicContentBufferTmp3.BOMUoM);
                JsonUtil.AddToJSon('UoMDescription', DynamicContentBufferTmp3.EntryUomDescription);
                JsonUtil.AddToJSon('MaxQuantity', DynamicContentBufferTmp3.MaxSelection);
                JsonUtil.AddToJSon('MinQuantity', DynamicContentBufferTmp3.MinSelection);
                JsonUtil.AddToJSon('Image', DynamicContentBufferTmp3.ImageId);
                JsonUtil.EndJSon();
            until DynamicContentBufferTmp3.Next() = 0;
        end;
        JsonUtil.EndJSonArray();
        DynamicContentBufferTmp3.Reset();
    end;

    local procedure AddModifierGroupsToJson(var JsonUtil: Codeunit "LSC POS JSON Util"; ItemNo: Code[20]; ItemPrice: Decimal; var DynamicContentBufferTmp2: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferTmp3: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferModGroupItemTmp: Record "LSC Dynamic Content Buffer" temporary; ItemModSectionID: Text; ModSectionID: Text; ModGrItemSectionID: Text)
        SelectedModPerGroupCount: Integer;
    begin
        JsonUtil.StartJSonArray('ModifierGroups');

        DynamicContentBufferTmp2.Reset();
        DynamicContentBufferTmp2.SetRange(ItemId, ItemNo);
        DynamicContentBufferTmp2.SetRange(SectionId, ItemModSectionID);

        IF DynamicContentBufferTmp2.FindSet() then begin
            repeat
                AddModifierGroupToJson(JsonUtil, DynamicContentBufferTmp2, DynamicContentBufferTmp3, DynamicContentBufferModGroupItemTmp, SelectedModPerGroupCount, ModSectionID, ModGrItemSectionID, ItemPrice);
            until DynamicContentBufferTmp2.Next() = 0;
        end;

        JsonUtil.EndJSonArray();
        ResetBuffers(DynamicContentBufferTmp2, DynamicContentBufferTmp3, DynamicContentBufferModGroupItemTmp);
    end;

    local procedure AddModifierGroupToJson(var JsonUtil: Codeunit "LSC POS JSON Util"; var DynamicContentBufferTmp2: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferTmp3: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferModGroupItemTmp: Record "LSC Dynamic Content Buffer" temporary; var SelectedModPerGroupCount: Integer; ModSectionID: Text; ModGrItemSectionID: Text; ItemPrice: Decimal)
    begin
        DynamicContentBufferTmp3.SetRange(ItemModGroupId, DynamicContentBufferTmp2.ItemModGroupId);
        DynamicContentBufferTmp3.SetRange(SectionId, ModSectionID);
        if DynamicContentBufferTmp3.FindFirst() then;
        JsonUtil.StartJSon();

        AddModifierGroupDetailsToJson(JsonUtil, DynamicContentBufferTmp3);

        AddModifierItemsToJson(JsonUtil, DynamicContentBufferTmp2.ItemModGroupId, DynamicContentBufferTmp3, DynamicContentBufferModGroupItemTmp, SelectedModPerGroupCount, ModGrItemSectionID, ItemPrice);

        JsonUtil.AddToJSon('SelQuantity', SelectedModPerGroupCount);
        JsonUtil.EndJSon();
    end;

    local procedure AddModifierGroupDetailsToJson(var JsonUtil: Codeunit "LSC POS JSON Util"; var DynamicContentBufferTmp3: Record "LSC Dynamic Content Buffer" temporary)
    begin
        JsonUtil.AddToJSon('ModGroupId', DynamicContentBufferTmp3.ItemModGroupId);
        JsonUtil.AddToJSon('ModGroupDescription', DynamicContentBufferTmp3.ItemModGroupDescription);
        JsonUtil.AddToJSon('ModGroupMaxQuantity', DynamicContentBufferTmp3.MaxSelection);
        JsonUtil.AddToJSon('ModGroupMinQuantity', DynamicContentBufferTmp3.MinSelection);
        JsonUtil.AddToJSon('ModGroupDisplayPrompt', DynamicContentBufferTmp3.DisplayPrompt);
        JsonUtil.AddToJSon('Image', DynamicContentBufferTmp3.ImageId);
        JsonUtil.AddToJSon('FilterByParentUOM', DynamicContentBufferTmp3.FilterByParentUOM);

        DynamicContentBufferTmp3.Reset();
    end;

    local procedure AddModifierItemsToJson(var JsonUtil: Codeunit "LSC POS JSON Util"; ItemModGroupId: Text; var DynamicContentBufferTmp3: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferModGroupItemTmp: Record "LSC Dynamic Content Buffer" temporary; var SelectedModPerGroupCount: Integer; SectionID: Text; ItemPrice: Decimal)
    begin
        DynamicContentBufferModGroupItemTmp.SetRange(ItemModGroupId, ItemModGroupId);
        DynamicContentBufferModGroupItemTmp.SetRange(SectionId, SectionID);
        IF DynamicContentBufferModGroupItemTmp.FindSet() then begin
            JsonUtil.StartJSonArray('ModifierItems');
            SelectedModPerGroupCount := 0;
            repeat
                AddModifierItemToJson(JsonUtil, DynamicContentBufferTmp3, DynamicContentBufferModGroupItemTmp, SelectedModPerGroupCount, ItemPrice);
            until DynamicContentBufferModGroupItemTmp.Next() = 0;
            JsonUtil.EndJSonArray();
        end;
    end;

    local procedure AddModifierItemToJson(var JsonUtil: Codeunit "LSC POS JSON Util"; var DynamicContentBufferTmp3: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferModGroupItemTmp: Record "LSC Dynamic Content Buffer" temporary; var SelectedModPerGroupCount: Integer; ParentItemPrice: Decimal)
    var
        imgID: Text;
        AvailabilitySet: Boolean;
        Availability: Decimal;
        AvailabilityUOM: Code[10];
        AvailabilityFactor: Decimal;
        ModifierPrice: Decimal;
    begin
        JsonUtil.StartJSon();
        if DynamicContentBufferModGroupItemTmp.TextModifier = '1' then
            JsonUtil.AddToJSon('ItemId', DynamicContentBufferModGroupItemTmp.Description)
        else
            JsonUtil.AddToJSon('ItemId', DynamicContentBufferModGroupItemTmp.ItemId);
        JsonUtil.AddToJSon('Description', DynamicContentBufferModGroupItemTmp.Description);
        JsonUtil.AddToJSon('MaxQuantity', DynamicContentBufferModGroupItemTmp.MaxSelection);
        JsonUtil.AddToJSon('MinQuantity', DynamicContentBufferModGroupItemTmp.MinSelection);

        if DynamicContentBufferModGroupItemTmp.TextModifier <> '1' then
            GetAvailabilityAndImageForItem(DynamicContentBufferModGroupItemTmp.ItemId, DynamicContentBufferTmp3, AvailabilitySet, Availability, imgID, DynamicContentBufferModGroupItemTmp.ItemModUoM, AvailabilityUOM, AvailabilityFactor);
        JsonUtil.AddToJSon('AvailabilitySet', AvailabilitySet);
        JsonUtil.AddToJSon('Availability', Availability);
        JsonUtil.AddToJSon('AvailabilityUOM', AvailabilityUOM);
        JsonUtil.AddToJSon('AvailabilityFactor', AvailabilityFactor);
        JsonUtil.AddToJSon('Image', imgID);
        JsonUtil.AddToJSon('ModGroupId', DynamicContentBufferModGroupItemTmp.ItemModGroupId);
        if DynamicContentBufferModGroupItemTmp.MinSelection > 0 then
            JsonUtil.AddToJSon('SelQuantity', DynamicContentBufferModGroupItemTmp.MinSelection)
        else
            JsonUtil.AddToJSon('SelQuantity', 0);
        SelectedModPerGroupCount += DynamicContentBufferModGroupItemTmp.MinSelection;
        JsonUtil.AddToJSon('DefaultQuantity', 0);
        if DynamicContentBufferModGroupItemTmp.ItemModPriceType = 'Percentage' then
            ModifierPrice := POSFunctions().RoundAmount(ParentItemPrice * DynamicContentBufferModGroupItemTmp.ItemModPricePercentage / 100)
        else
            ModifierPrice := DynamicContentBufferModGroupItemTmp.ItemModPricePercentage;
        if DynamicContentBufferModGroupItemTmp.ItemModQty <> 0 then
            ModifierPrice := ModifierPrice * DynamicContentBufferModGroupItemTmp.ItemModQty;

        JsonUtil.AddToJSon('ItemModPriceType', DynamicContentBufferModGroupItemTmp.ItemModPriceType);
        JsonUtil.AddToJSon('ItemModPriceAmount', ModifierPrice);
        JsonUtil.AddToJSon('ModGroupSubCode', DynamicContentBufferModGroupItemTmp.ItemModSubcode);
        JsonUtil.AddToJSon('ItemModRequired', DynamicContentBufferModGroupItemTmp.ItemModRequired);
        JsonUtil.AddToJSon('TextModifier', DynamicContentBufferModGroupItemTmp.TextModifier);
        JsonUtil.AddToJson('ItemModUom', DynamicContentBufferModGroupItemTmp.ItemModUoM);
        JsonUtil.AddToJSon('DefaultSelection', DynamicContentBufferModGroupItemTmp.ItemModDefaultSelection);
        JsonUtil.EndJSon();
    end;

    local procedure ResetBuffers(var DynamicContentBufferTmp2: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferTmp3: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferModGroupItemTmp: Record "LSC Dynamic Content Buffer" temporary)
    begin
        DynamicContentBufferModGroupItemTmp.Reset();
        DynamicContentBufferTmp3.Reset();
        DynamicContentBufferTmp2.Reset();
    end;

    local procedure AddCrossSellsCodesToJson(var JsonUtil: Codeunit "LSC POS JSON Util"; ItemNo: Code[20]; var DynamicContentBufferTmp2: Record "LSC Dynamic Content Buffer" temporary)
    begin
        JsonUtil.StartJSonArray('CrossSells');

        DynamicContentBufferTmp2.SetRange(ItemId, ItemNo);
        DynamicContentBufferTmp2.SetRange(SectionId, 'CROSSSELL');
        IF DynamicContentBufferTmp2.FindSet() then begin
            repeat
                JsonUtil.StartJSon();
                JsonUtil.AddToJSon('CrossSellId', DynamicContentBufferTmp2.ItemModGroupId);
                JsonUtil.EndJSon();
            until DynamicContentBufferTmp2.Next() = 0;
        end;
        JsonUtil.EndJSonArray();
        DynamicContentBufferTmp2.Reset();
    end;

    procedure AddCrossSellingGroupsToJson(var JsonUtil: Codeunit "LSC POS JSON Util"; var DynamicContentBufferTmp2: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferTmp3: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferModGroupItemTmp: Record "LSC Dynamic Content Buffer" temporary; SectionID: Text; SubSectionID: Text; ItemPrice: Decimal)
        SelectedModPerGroupCount: Integer;
    begin
        JsonUtil.StartJSonArray('CrossSelling');

        DynamicContentBufferTmp2.Reset();
        DynamicContentBufferTmp2.SetRange(SectionId, SectionID);

        IF DynamicContentBufferTmp2.FindSet() then begin
            repeat
                AddModifierGroupToJson(JsonUtil, DynamicContentBufferTmp2, DynamicContentBufferTmp3, DynamicContentBufferModGroupItemTmp, SelectedModPerGroupCount, SectionID, SubSectionID, ItemPrice);
            until DynamicContentBufferTmp2.Next() = 0;
        end;

        JsonUtil.EndJSonArray();
    end;

    local procedure Image_GetDealImageID(DealNo: Code[20]): Text
    var
        Deal: Record "LSC Offer";
    begin
        if not Deal.Get(DealNo) then
            exit('');
        exit(POSSession().AddWebTemplateImage(Deal.RecordId, ''));
    end;

    local procedure Image_GetItemImageID(ItemNo: Code[20]): Text
    var
        Item: Record Item;
    begin
        if not Item.Get(ItemNo) then
            exit('');
        exit(POSSession().AddWebTemplateImage(Item.RecordId, ''));
    end;

    procedure GetPosTerminalStoreAndPosFuncProfileV2(var POSTerminal: Record "LSC POS Terminal"; var Store: Record "LSC Store"; Var PosFuncProfile: Record "LSC POS Func. Profile"; var ErrorText: Text): Boolean
    var
        SSKProfile: Record "LSC SSK Profile";
    begin
        exit(GetPosTerminalStoreAndPosFuncProfileV2(POSTerminal, Store, PosFuncProfile, ErrorText, SSKProfile));
    end;

    procedure GetPosTerminalStoreAndPosFuncProfileV2(var POSTerminal: Record "LSC POS Terminal"; var Store: Record "LSC Store"; Var PosFuncProfile: Record "LSC POS Func. Profile"; var ErrorText: Text; var SSKProfile: Record "LSC SSK Profile"): Boolean
    var
        RetailUser: Record "LSC Retail User";
        StoreNotFoundErr: Label '%1 %2 not found for %3 %4';
        NoFuncProfileErr: Label '%1 not found for %2 %3';
        TableValueNotFoundErr: Label '%1 %2 not found';
        CurrencyCodeMustBeSetErr: Label '%1 must be set for restaurant %2 even if it is the local currency.';
        SSKProfileMissingErr: Label '%1 missing from %2 %3.';
    begin
        if POSTerminal."No." = '' then begin
            if not RetailUser.Get(UserId) then begin
                ErrorText := StrSubstNo(TableValueNotFoundErr, RetailUser.TableCaption, UserId);
                exit(false);
            end;

            if not POSTerminal.Get(RetailUser."POS Terminal") then begin
                ErrorText := StrSubstNo(TableValueNotFoundErr, POSTerminal.TableCaption, RetailUser."POS Terminal");
                exit(false);
            end;
        end;

        if not Store.Get(POSTerminal."Store No.") then begin
            ErrorText := StrSubstNo(StoreNotFoundErr, store.TableCaption, POSTerminal."Store No.", POSTerminal.TableCaption, POSTerminal."No.");
            exit(false);
        end;

        if not SSKProfile.get(POSTerminal."SSK Profile ID") then
            if not SSKProfile.get(Store."SSK Profile ID") then begin
                ErrorText := StrSubstNo(SSKProfileMissingErr, POSTerminal.FieldCaption("SSK Profile ID"), POSTerminal.TableCaption, POSTerminal."No.");
                exit(false);
            end;

        if SSKProfile."Currency Code" = '' then begin
            ErrorText := StrSubstNo(CurrencyCodeMustBeSetErr, store.FieldCaption("Currency Code"), store."No.");
            exit(false);
        end;

        if POSTerminal."Functionality Profile" <> '' then begin
            if PosFuncProfile.Get(POSTerminal."Functionality Profile") then
                exit(true);
        end;
        if Store."Functionality Profile" <> '' then begin
            if PosFuncProfile.Get(Store."Functionality Profile") then
                exit(True);
        end;
        if not PosFuncProfile.Get(Format("LSC POS Profile ID"::DefaultFunctionality)) then begin
            ErrorText := StrSubstNo(NoFuncProfileErr, PosFuncProfile.tablecaption, POSTerminal.tablecaption, POSTerminal."No.");
            exit(False);
        end;

        exit(true);
    end;

    /// <summary>
    /// Receives orderline from Selfservice POS and recalculates the basket and returns the whole calculated transaction
    /// </summary>
    /// <param name="KioskBasketJSON"></param>
    /// <param name="CalcBasketJSON"></param>
    internal procedure KioskBasketCalculate(var KioskBasketJSON: Text; var CalcBasketJSON: Text)
    var
        MobileTransactionLineTmp: Record LSCMobileTransactionLine temporary;
        MobileTransactionTmp: Record LSCMobileTransaction temporary;
        MobileTransDiscLineTmp: Record LSCMobileTransDiscountLine temporary; //nothing is done with this disount line - this is definetely coming back
        MobileTransSubLineTmp: Record LSCMobileTransactionSubLine temporary;
        POSTerminal: Record "LSC POS Terminal";
        Store: Record "LSC Store";
        PosFuncProfile: Record "LSC POS Func. Profile";
        SSKProfile: Record "LSC SSK Profile";
        ErrorText: Text;
        ErrorCode: Code[10];
        FunctionOK: Boolean;
    begin
        if not GetPosTerminalStoreAndPosFuncProfileV2(POSTerminal, Store, PosFuncProfile, ErrorText, SSKProfile) then begin
            CalcBasketJSON := ReturnErrorToKiosk('GetProfiles', '', ErrorText, '', '');
            exit;
        end;
        if not KioskBasketAddToMobileTransactionV2(KioskBasketJSON, MobileTransactionLineTmp, MobileTransactionTmp, MobileTransDiscLineTmp, MobileTransSubLineTmp, true, POSTerminal, Store, PosFuncProfile, ErrorText, SSKProfile) then begin
            CalcBasketJSON := ReturnErrorToKiosk('AddToMobileTrans', '', ErrorText, '', '');
            exit;
        end;

        case MobileTransactionTmp."Self Service Action" of
            "LSC Self Service Action"::Added:
                FunctionOK := KioskBasketCalculateTransaction(MobileTransactionLineTmp, MobileTransactionTmp, MobileTransDiscLineTmp, MobileTransSubLineTmp, ErrorCode, ErrorText);
            "LSC Self Service Action"::Modified:
                FunctionOK := KioskBasketModifyTransaction(MobileTransactionLineTmp, MobileTransactionTmp, MobileTransDiscLineTmp, MobileTransSubLineTmp, ErrorCode, ErrorText);
            "LSC Self Service Action"::Voided:
                FunctionOK := VoidTransaction(MobileTransactionTmp.ReceiptNo, ErrorCode, ErrorText);
            "LSC Self Service Action"::"Member Added to New Transaction":
                FunctionOk := AddMemberToNewMobileTransaction(MobileTransactionLineTmp, MobileTransactionTmp, MobileTransDiscLineTmp, MobileTransSubLineTmp, ErrorCode, ErrorText);
            "LSC Self Service Action"::"Member Added to Existing Transaction":
                FunctionOK := AddMemberToExistingMobileTransaction(MobileTransactionLineTmp, MobileTransactionTmp, MobileTransDiscLineTmp, MobileTransSubLineTmp, ErrorCode, ErrorText);
        end;
        if not FunctionOK then begin
            CalcBasketJSON := ReturnErrorToKiosk('BasketFunction' + format(MobileTransactionTmp."Self Service Action"), ErrorCode, ErrorText, MobileTransactionTmp.ReceiptNo, POSTerminal."No.");
            exit;
        end;
        if MobileTransactionTmp."Self Service Action" <> "LSC Self Service Action"::Voided then
            KioskBasketTurnCalculatedTransactionIntoJson(CalcBasketJSON, MobileTransactionLineTmp, MobileTransactionTmp, MobileTransDiscLineTmp, MobileTransSubLineTmp, PosFuncProfile);
    end;

    /// <summary>
    /// Process item from SelfService kiosk
    /// Only one Item or Deal is sent from the Kiosk each time
    /// </summary>
    /// <param name="JSONBuffer"></param>
    /// <param name="MobileTransactionLineTmp"></param>
    /// <param name="MobileTransactionTmp"></param>
    /// <param name="MobileTransDiscLine"></param>
    /// <param name="MobileTransSubLineTmp"></param>
    /// <param name="StoreTmpOnly">If to store data in actual Mobiletables or just temporary</param>
    procedure KioskBasketAddToMobileTransactionV2(
        var JSONBuffer: Text;
        var MobileTransactionLineTmp: Record LSCMobileTransactionLine temporary;
        var MobileTransactionTmp: Record LSCMobileTransaction temporary;
        var MobileTransDiscLine: Record LSCMobileTransDiscountLine temporary;
        var MobileTransSubLineTmp: Record LSCMobileTransactionSubLine temporary;
        StoreTmpOnly: Boolean;
        POSTerminal: Record "LSC POS Terminal";
        Store: Record "LSC Store";
        PosFuncProfile: Record "LSC POS Func. Profile";
        var ErrorText: Text): Boolean
    var
        SSKProfile: Record "LSC SSK Profile";
    begin
        exit(KioskBasketAddToMobileTransactionV2(JSONBuffer, MobileTransactionLineTmp, MobileTransactionTmp, MobileTransDiscLine, MobileTransSubLineTmp, StoreTmpOnly, POSTerminal, Store, PosFuncProfile, ErrorText, SSKProfile));
    end;

    procedure KioskBasketAddToMobileTransactionV2(
        var JSONBuffer: Text;
        var MobileTransactionLineTmp: Record LSCMobileTransactionLine temporary;
        var MobileTransactionTmp: Record LSCMobileTransaction temporary;
        var MobileTransDiscLine: Record LSCMobileTransDiscountLine temporary;
        var MobileTransSubLineTmp: Record LSCMobileTransactionSubLine temporary;
        StoreTmpOnly: Boolean;
        POSTerminal: Record "LSC POS Terminal";
        Store: Record "LSC Store";
        PosFuncProfile: Record "LSC POS Func. Profile";
        var ErrorText: Text;
        SSKProfile: Record "LSC SSK Profile"): Boolean
    var
        CurrTransLine_LineNo: Integer;
        CurrSubLineNo: Integer;
        ParentItemLineNo: Integer;

        jsObject: JsonObject;
        jsObjItem: JsonObject;
        jsObjModifier: JsonObject;
        jsObjIngredient: JsonObject;
        jsObjDeal: JsonObject;
        jsObjMember: JsonObject;
        jsArrayItems: JsonArray;
        jsArraySubElements: JsonArray;
        jsToken: JsonToken;
        jsTkItem: JsonToken;
        jsTkModifier: JsonToken;
        jsTkIngredient: JsonToken;
        jsTkMember: JsonToken;
        TransactionGUID: Guid;
        ErrorReadJson: Label 'Read From JsonBuffer failed';
        ErrorGetGuid: Label 'Read Guid From JsonBuffer failed';
        ModItemNo: Text;
        BarcodeNo: Code[100];
        Item: Record Item;
        ItemFound: Boolean;
        NewMemberInTransaction: Boolean;
    begin
        if not (jsObject.ReadFrom(JSONBuffer)) then begin
            ErrorText := ErrorReadJson;
            exit(false);
        end;
        MobileTransactionTmp.DeleteAll();
        MobileTransactionLineTmp.DeleteAll();
        MobileTransSubLineTmp.DeleteAll();
        CurrTransLine_LineNo := 0;
        CurrSubLineNo := 0;
        ItemFound := false;
        NewMemberInTransaction := false;

        if not (jsObject.Get('guid', jsToken)) then begin
            ErrorText := ErrorGetGuid;
            exit(False);
        end;
        TransactionGUID := jsToken.AsValue().AsText();
        MobileTransactionTmp.Init();
        MobileTransactionTmp.Id := TransactionGUID;
        jsObject.Get('receiptNo', jsToken);
        MobileTransactionTmp.ReceiptNo := jsToken.AsValue().AsCode();
        if (MobileTransactionTmp.ReceiptNo = '') then begin
            MobileTransactionTmp.StoreId := Store."No.";
            MobileTransactionTmp.TerminalId := POSTerminal."No.";
            MobileTransactionTmp.StaffId := PosFuncProfile."Automatic Logon Staff ID";
            MobileTransactionTmp.TransDate := CurrentDateTime; //Only for the first time, then we need the actual start date of the transaction                  
        end
        else begin
            if (jsObject.Get('storeId', jsToken)) then
                MobileTransactionTmp.StoreId := jsToken.AsValue().AsCode();
            if (jsObject.Get('terminalId', jsToken)) then
                MobileTransactionTmp.TerminalId := jsToken.AsValue().AsCode();
            if (jsObject.Get('staffId', jsToken)) then
                MobileTransactionTmp.StaffId := jsToken.AsValue().AsCode();
        end;
        if (jsObject.Get('salesType', jsToken)) then
            MobileTransactionTmp.SalesType := jsToken.AsValue().AsCode();
        if (jsObject.Get('action', jsToken)) then
            MobileTransactionTmp."Self Service Action" := "LSC Self Service Action".FromInteger(jsToken.AsValue().AsInteger())
        else
            MobileTransactionTmp."Self Service Action" := "LSC Self Service Action"::None;

        MobileTransactionTmp."Source Type" := MobileTransactionTmp."Source Type"::"Self Service Kiosk";

        MobileTransactionTmp.Insert();

        if (jsObject.Get('barcode', jsToken)) then begin
            BarcodeNo := jsToken.AsValue().AsCode();
            if (BarcodeNo <> '') then begin
                if not HandleBarcodeMask(BarcodeNo, ItemFound, MobileTransactionTmp, SSKProfile, Item, NewMemberInTransaction, ErrorText) then
                    exit(false);
                if ItemFound then
                    InsertMobileTransactionLine(TransactionGUID, CurrTransLine_LineNo, jsObject, jsToken, MobileTransactionLineTmp, Item);
            end;
        end;

        // Single Item
        if (jsObject.Get('items', jsToken)) then begin
            jsObjItem := jsToken.AsObject();
            if (jsObjItem.Get('itemNo', jsToken)) then begin
                MobileTransactionLineTmp.Init();
                MobileTransactionLineTmp.Number := jsToken.AsValue().AsCode();
                MobileTransactionLineTmp.Id := TransactionGUID;
                MobileTransactionLineTmp.LineType := 0;

                CurrTransLine_LineNo += 10000;
                MobileTransactionLineTmp.LineNo := CurrTransLine_LineNo;
                if (jsObjItem.Get('quantity', jsToken)) then
                    MobileTransactionLineTmp.Quantity := jsToken.AsValue().AsDecimal();
                if (jsObjItem.Get('extLineNo', jsToken)) then
                    MobileTransactionLineTmp.ExternalLineNo := jsToken.AsValue().AsInteger();
                if (jsObjItem.Get('cartSequenceNo', jsToken)) then
                    MobileTransactionLineTmp.CartSequenceNo := jsToken.AsValue().AsInteger();
                if (jsObjItem.Get('selectedUom', jsToken)) then
                    MobileTransactionLineTmp.UomId := jsToken.AsValue().AsCode();
                if (jsObjItem.Get('action', jsToken)) then
                    MobileTransactionLineTmp."Self Service Action" := "LSC Self Service Action".FromInteger(jsToken.AsValue().AsInteger())
                else
                    MobileTransactionLineTmp."Self Service Action" := "LSC Self Service Action"::None;
                if MobileTransactionLineTmp."Self Service Action" = "LSC Self Service Action"::"CrossSelling Modifier Added" then begin
                    if (jsObjItem.Get('modGroupId', jsToken)) then
                        MobileTransactionLineTmp."Cross-selling Infocode" := jsToken.AsValue().AsCode();
                    if (jsObjItem.Get('modGroupSubCode', jsToken)) then
                        MobileTransactionLineTmp."Cross-selling Subcode" := jsToken.AsValue().AsCode();
                    if (jsObjItem.Get('ParentLineNo', jsToken)) then
                        MobileTransactionLineTmp."Cross-selling Parent Line No." := jsToken.AsValue().AsInteger();
                end;

                MobileTransactionLineTmp.Insert();

                //Modifiers
                if (jsObjItem.Get('modifiers', jsToken)) then begin
                    jsArraySubElements := jsToken.AsArray();
                    foreach jsTkModifier in jsArraySubElements do begin
                        jsObjModifier := jsTkModifier.AsObject();
                        if (jsObjModifier.Get('modifierItemNo', jsToken)) then begin
                            MobileTransSubLineTmp.Init();
                            MobileTransSubLineTmp.Id := TransactionGUID;
                            ModItemNo := jsToken.AsValue().AsCode();
                            if (jsObjModifier.Get('textModifier', jsToken)) then begin
                                if jsToken.AsValue().AsCode() = '1' then
                                    ModItemNo := '';
                            end;
                            MobileTransSubLineTmp.Number := CopyStr(ModItemNo, 1, MaxStrLen(MobileTransSubLineTmp.Number));
                            MobileTransSubLineTmp.LineType := 0;
                            MobileTransSubLineTmp.ParentLineNo := MobileTransactionLineTmp.LineNo;
                            if (jsObjModifier.Get('modGroupId', jsToken)) then
                                MobileTransSubLineTmp.ModifierGroupCode := jsToken.AsValue().AsCode();
                            if (jsObjModifier.Get('modGroupSubCode', jsToken)) then
                                MobileTransSubLineTmp.ModifierSubCode := jsToken.AsValue().AsCode();
                            if (jsObjModifier.Get('quantity', jsToken)) then
                                MobileTransSubLineTmp.Quantity := jsToken.AsValue().AsDecimal();
                            if (jsObjIngredient.Get('extLineNo', jsToken)) then
                                MobileTransSubLineTmp.ExternalLineNo := jsToken.AsValue().AsInteger();
                            if (jsObjModifier.Get('selectedUom', jsToken)) then
                                MobileTransSubLineTmp.UomId := jsToken.AsValue().AsCode();
                            CurrSubLineNo += 10000;
                            MobileTransSubLineTmp.LineNo := CurrSubLineNo;

                            MobileTransSubLineTmp.Insert();
                        end;
                    end;
                end;

                // Ingredients
                if (jsObjItem.Get('ingredients', jsToken)) then begin
                    jsArraySubElements := jsToken.AsArray();
                    foreach jsTkIngredient in jsArraySubElements do begin
                        MobileTransSubLineTmp.Init();
                        MobileTransSubLineTmp.Id := TransactionGUID;
                        jsObjIngredient := jsTkIngredient.AsObject();
                        if (jsObjIngredient.Get('ingredientItemNo', jsToken)) then
                            MobileTransSubLineTmp.Number := jsToken.AsValue().AsCode();
                        if (jsObjIngredient.Get('quantity', jsToken)) then
                            MobileTransSubLineTmp.Quantity := jsToken.AsValue().AsDecimal();
                        if (jsObjIngredient.Get('extLineNo', jsToken)) then
                            MobileTransSubLineTmp.ExternalLineNo := jsToken.AsValue().AsInteger();
                        if (jsObjIngredient.Get('selectedUom', jsToken)) then
                            MobileTransSubLineTmp.UomId := jsToken.AsValue().AsCode();
                        MobileTransSubLineTmp.ParentLineNo := CurrTransLine_LineNo;
                        MobileTransSubLineTmp.ParentLineIsSubline := 0;
                        MobileTransSubLineTmp.DealLine := 0;
                        MobileTransSubLineTmp.LineType := 0;
                        CurrSubLineNo += 10000;
                        MobileTransSubLineTmp.LineNo := CurrSubLineNo;

                        MobileTransSubLineTmp.Insert();
                    end;
                end;
            end;
        end;

        //Deal/Offer
        if (jsObject.Get('deals', jsToken)) then begin
            jsObjDeal := jsToken.AsObject();
            if (jsObjDeal.Get('dealNo', jsToken)) then begin
                MobileTransactionLineTmp.Init();
                MobileTransactionLineTmp.Id := TransactionGUID;
                MobileTransactionLineTmp.Number := jsToken.AsValue().AsCode();
                if (jsObjDeal.Get('extLineNo', jsToken)) then
                    MobileTransactionLineTmp.ExternalLineNo := jsToken.AsValue().AsInteger();
                if (jsObjDeal.Get('cartSequenceNo', jsToken)) then
                    MobileTransactionLineTmp.CartSequenceNo := jsToken.AsValue().AsInteger();
                if (jsObjDeal.Get('quantity', jsToken)) then
                    MobileTransactionLineTmp.Quantity := jsToken.AsValue().AsInteger();
                CurrTransLine_LineNo += 10000;
                MobileTransactionLineTmp.LineNo := CurrTransLine_LineNo;

                if (jsObjDeal.Get('action', jsToken)) then
                    MobileTransactionLineTmp."Self Service Action" := "LSC Self Service Action".FromInteger(jsToken.AsValue().AsInteger())
                else
                    MobileTransactionLineTmp."Self Service Action" := "LSC Self Service Action"::None;
                MobileTransactionLineTmp.SalesType := MobileTransactionTmp.SalesType;
                MobileTransactionLineTmp.DealItem := 1;

                MobileTransactionLineTmp.Insert();

                //DealModifiers
                if (jsObjDeal.Get('dealModifiers', jsToken)) then begin
                    jsArraySubElements := jsToken.AsArray();
                    foreach jsTkModifier in jsArraySubElements do begin
                        jsObjModifier := jsTkModifier.AsObject();

                        if (jsObjModifier.Get('dealModifierItemNo', jsToken)) then begin
                            MobileTransSubLineTmp.Init();
                            MobileTransSubLineTmp.Id := TransactionGUID;
                            MobileTransSubLineTmp.Number := jsToken.AsValue().AsCode();
                            MobileTransSubLineTmp.LineType := 1;
                            MobileTransSubLineTmp.ParentLineNo := MobileTransactionLineTmp.LineNo;
                            MobileTransSubLineTmp.ParentLineIsSubline := 0;
                            MobileTransSubLineTmp.DealId := MobileTransactionLineTmp.Number;
                            CurrSubLineNo += 10000;
                            MobileTransSubLineTmp.LineNo := CurrSubLineNo;

                            if (jsObjItem.Get('extLineNo', jsToken)) then
                                MobileTransSubLineTmp.ExternalLineNo := jsToken.AsValue().AsInteger();
                            if (jsObjModifier.Get('quantity', jsToken)) then
                                MobileTransSubLineTmp.Quantity := jsToken.AsValue().AsDecimal();
                            if (jsObjModifier.Get('selectedUom', jsToken)) then
                                MobileTransSubLineTmp.UomId := jsToken.AsValue().AsCode();
                            if (jsObjModifier.Get('dealLine', jsToken)) then     //Originates from Dynamic Content (Hiearchy)
                                MobileTransSubLineTmp.DealLine := jsToken.AsValue().AsInteger();
                            if (jsObjModifier.Get('dealModLine', jsToken)) then  //Originates from Dynamic Content (Hiearchy)
                                MobileTransSubLineTmp.DealModLine := jsToken.AsValue().AsInteger();

                            MobileTransSubLineTmp.Insert();
                        end;
                    end;
                end;

                //Items within the Deal
                if (jsObjDeal.Get('items', jsToken)) then begin
                    jsArrayItems := jsToken.AsArray();
                    foreach jsTkItem in jsArrayItems do begin
                        jsObjItem := jsTkItem.AsObject();
                        MobileTransSubLineTmp.Init();

                        MobileTransSubLineTmp.ID := MobileTransactionTmp.Id;
                        MobileTransSubLineTmp.ParentLineNo := MobileTransactionLineTmp.LineNo;
                        MobileTransSubLineTmp.LineType := 1;
                        MobileTransSubLineTmp.DealId := MobileTransactionLineTmp.Number;
                        CurrSubLineNo += 10000;
                        MobileTransSubLineTmp.LineNo := CurrSubLineNo;
                        ParentItemLineNo := CurrSubLineNo;

                        if (jsObjItem.Get('itemNo', jsToken)) then
                            MobileTransSubLineTmp.Number := jsToken.AsValue().AsCode();
                        if (jsObjItem.Get('quantity', jsToken)) then
                            MobileTransSubLineTmp.Quantity := jsToken.AsValue().AsDecimal();
                        if (jsObjItem.Get('extLineNo', jsToken)) then
                            MobileTransSubLineTmp.ExternalLineNo := jsToken.AsValue().AsInteger();
                        if (jsObjItem.Get('selectedUom', jsToken)) then
                            MobileTransSubLineTmp.UomId := jsToken.AsValue().AsCode();
                        if (jsObjItem.Get('dealLine', jsToken)) then     //Originates from Dynamic Content (Hiearchy)
                            MobileTransSubLineTmp.DealLine := jsToken.AsValue().AsInteger();
                        MobileTransSubLineTmp.ParentLineIsSubline := 0;
                        MobileTransSubLineTmp.DealModLine := 0;

                        MobileTransSubLineTmp.Insert();

                        //ItemModifiers
                        if (jsObjItem.Get('modifiers', jsToken)) then begin
                            jsArraySubElements := jsToken.AsArray();
                            foreach jsTkModifier in jsArraySubElements do begin
                                jsObjModifier := jsTkModifier.AsObject();

                                if (jsObjModifier.Get('modifierItemNo', jsToken)) then begin
                                    MobileTransSubLineTmp.Init();
                                    MobileTransSubLineTmp.Id := TransactionGUID;
                                    MobileTransSubLineTmp.Number := jsToken.AsValue().AsCode();
                                    MobileTransSubLineTmp.LineType := 0;
                                    MobileTransSubLineTmp.ParentLineNo := ParentItemLineNo;
                                    MobileTransSubLineTmp.ParentLineIsSubline := 1;
                                    MobileTransSubLineTmp.DealId := MobileTransactionLineTmp.Number;
                                    MobileTransSubLineTmp.DealLine := 0;
                                    CurrSubLineNo += 10000;
                                    MobileTransSubLineTmp.LineNo := CurrSubLineNo;

                                    if (jsObjItem.Get('extLineNo', jsToken)) then
                                        MobileTransSubLineTmp.ExternalLineNo := jsToken.AsValue().AsInteger();
                                    if (jsObjModifier.Get('modGroupId', jsToken)) then
                                        MobileTransSubLineTmp.ModifierGroupCode := jsToken.AsValue().AsCode();
                                    if (jsObjModifier.Get('modGroupSubCode', jsToken)) then
                                        MobileTransSubLineTmp.ModifierSubCode := jsToken.AsValue().AsCode();
                                    if (jsObjModifier.Get('quantity', jsToken)) then
                                        MobileTransSubLineTmp.Quantity := jsToken.AsValue().AsDecimal();
                                    if (jsObjModifier.Get('selectedUom', jsToken)) then
                                        MobileTransSubLineTmp.UomId := jsToken.AsValue().AsCode();

                                    MobileTransSubLineTmp.Insert();
                                end;
                            end;
                        end;

                        // ItemIngredients
                        if (jsObjItem.Get('ingredients', jsToken)) then begin
                            jsArraySubElements := jsToken.AsArray();
                            foreach jsTkIngredient in jsArraySubElements do begin
                                MobileTransSubLineTmp.Init();
                                jsObjIngredient := jsTkIngredient.AsObject();

                                if (jsObjIngredient.Get('ingredientItemNo', jsToken)) then begin
                                    MobileTransSubLineTmp.Id := TransactionGUID;
                                    MobileTransSubLineTmp.Number := jsToken.AsValue().AsCode();
                                    MobileTransSubLineTmp.LineType := 0;
                                    MobileTransSubLineTmp.ParentLineNo := ParentItemLineNo;
                                    MobileTransSubLineTmp.ParentLineIsSubline := 1;
                                    MobileTransSubLineTmp.DealLine := 0;
                                    MobileTransSubLineTmp.DealId := MobileTransactionLineTmp.Number;
                                    CurrSubLineNo += 10000;
                                    MobileTransSubLineTmp.LineNo := CurrSubLineNo;

                                    if (jsObjIngredient.Get('quantity', jsToken)) then
                                        MobileTransSubLineTmp.Quantity := jsToken.AsValue().AsDecimal();
                                    if (jsObjIngredient.Get('extLineNo', jsToken)) then
                                        MobileTransSubLineTmp.ExternalLineNo := jsToken.AsValue().AsInteger();
                                    if (jsObjIngredient.Get('selectedUom', jsToken)) then
                                        MobileTransSubLineTmp.UomId := jsToken.AsValue().AsCode();

                                    MobileTransSubLineTmp.Insert();
                                end;
                            end;
                        end;
                    end;
                end;
            end;
        end;
        // Member
        if not NewMemberInTransaction then
            if (jsObject.Get('member', jsToken)) then begin
                jsArraySubElements := jsToken.AsArray();
                foreach jsTkMember in jsArraySubElements do begin
                    jsObjMember := jsTkMember.AsObject();
                    if (jsObjMember.Get('memberCode', jsToken)) then
                        MobileTransactionTmp.MemberCardNo := jsToken.AsValue().AsCode();
                    if (jsObjMember.Get('memberContactNo', jsToken)) then
                        MobileTransactionTmp.MemberContactNo := jsToken.AsValue().AsCode();
                    if (jsObjMember.Get('memberPriceGroup', jsToken)) then
                        MobileTransactionTmp.MemberPriceGroupCode := jsToken.AsValue().AsCode();
                    MobileTransactionTmp.Modify();
                end;
            end;
        exit(true);
    end;

    internal procedure HandleBarcodeMask(
        var BarcodeNo: Code[100];
        var ItemFound: Boolean;
        var MobileTransactionTmp: Record LSCMobileTransaction temporary;
        SSKProfile: Record "LSC SSK Profile";
        var Item: Record Item;
        var NewMemberInTransaction: Boolean;
        var ErrorText: Text
        ): Boolean
    var
        BarcodeMgt: Codeunit "LSC Barcode Management";
        BarcodeMask: Record "LSC Barcode Mask";
    begin
        if BarcodeMgt.FindBarcodeMask(CopyStr(BarcodeNo, 1, 22), BarcodeMask) then
            if BarcodeMask.Type = BarcodeMask.Type::"Member Card" then
                exit(HandleMemberCard(BarcodeNo, MobileTransactionTmp, SSKProfile, NewMemberInTransaction, ErrorText));
        exit(HandleItemScanning(BarcodeNo, ItemFound, SSKProfile, Item, ErrorText));
    end;

    internal procedure HandleMemberCard(var BarcodeNo: Code[100]; var MobileTransactionTmp: Record LSCMobileTransaction; SSKProfile: Record "LSC SSK Profile"; var NewMemberInTransaction: Boolean; var ErrorText: Text): Boolean;
    var
        MembershipCard: Record "LSC Membership Card";
        NoMemberWithThisNumberErr: Label 'There is no Member assigned to this Card';
        MemberNotAllowedInStoreErr: Label 'Member sale is not allowed in this store';
    begin
        if SSKProfile."Scan Member" then begin
            if MembershipCard.Get(BarcodeNo) then begin
                MemberCardScanned(BarcodeNo, MobileTransactionTmp, NewMemberInTransaction, MembershipCard);
                exit(true);
            end;
            ErrorText := NoMemberWithThisNumberErr;
            exit(false);
        end;
        ErrorText := MemberNotAllowedInStoreErr;
        exit(false);
    end;

    internal procedure MemberCardScanned(var BarcodeNo: Code[100]; var MobileTransactionTmp: Record LSCMobileTransaction temporary; var NewMemberInTransaction: Boolean; var MembershipCard: Record "LSC Membership Card")
    var
        MemberAccount: Record "LSC Member Account";
    begin
        MobileTransactionTmp.MemberCardNo := BarcodeNo;
        MobileTransactionTmp.MemberContactNo := MembershipCard."Contact No.";
        if MobileTransactionTmp."Self Service Action" = "LSC Self Service Action"::Added then
            MobileTransactionTmp."Self Service Action" := "LSC Self Service Action"::"Member Added to New Transaction"
        else
            if MobileTransactionTmp."Self Service Action" = "LSC Self Service Action"::Modified then
                MobileTransactionTmp."Self Service Action" := "LSC Self Service Action"::"Member Added to Existing Transaction";
        if MemberAccount.Get(MembershipCard."Account No.") then
            MobileTransactionTmp.MemberPriceGroupCode := MemberAccount."Price Group";
        MobileTransactionTmp.Modify();
        NewMemberInTransaction := true;
    end;

    internal procedure HandleItemScanning(var BarcodeNo: Code[100]; var ItemFound: Boolean; SSKProfile: Record "LSC SSK Profile"; var Item: Record Item; var ErrorText: Text): Boolean
    var
        Barcode: Record "LSC Barcodes";
        BarcodeMgt: Codeunit "LSC Barcode Management";
        Amount: Decimal;
        Quantity: Decimal;
        ItemNotFoundFromBarcodeErr: Label 'Item not found from barcode';
        ItemScanningDisabledErr: Label 'Item scanning is disabled';
    begin
        if SSKProfile."Item Scanning Enabled" then begin
            BarcodeNo := CopyStr(BarcodeNo, 1, 20);
            if (BarcodeMgt.FindBarcodeDetails(BarcodeNo, Item, Barcode, Amount, Quantity)) then
                ItemFound := true
            else begin
                ErrorText := ItemNotFoundFromBarcodeErr;
                exit(false);
            end;
        end else begin
            ErrorText := ItemScanningDisabledErr;
            exit(false);
        end;
        exit(true);
    end;

    internal procedure InsertMobileTransactionLine(TransactionGUID: Guid; var CurrTransLine_LineNo: Integer; var jsObject: JsonObject; var jsToken: JsonToken; var MobileTransactionLineTmp: Record LSCMobileTransactionLine temporary; var Item: Record Item);
    begin
        MobileTransactionLineTmp.Init();
        MobileTransactionLineTmp.Number := Item."No.";
        MobileTransactionLineTmp.Id := TransactionGUID;
        MobileTransactionLineTmp.LineType := 0;
        CurrTransLine_LineNo += 10000;
        MobileTransactionLineTmp.LineNo := CurrTransLine_LineNo;
        MobileTransactionLineTmp.Quantity := 1;
        MobileTransactionLineTmp.ExternalLineNo := 0;
        if (jsObject.Get('cartSequenceNo', jsToken)) then
            MobileTransactionLineTmp.CartSequenceNo := jsToken.AsValue().AsInteger();
        MobileTransactionLineTmp."Self Service Action" := Enum::"LSC Self Service Action".FromInteger(1);
        MobileTransactionLineTmp.Insert();
    end;

    procedure GetNewTransLineNo(ReceiptNo: Code[20]): Integer
    var
        POSTransLine: Record "LSC POS Trans. Line";

    begin
        if (ReceiptNo <> '') then begin
            POSTransLine.Reset();
            POSTransLine.SetRange("Receipt No.", ReceiptNo);
            if (PosTransLine.FindLast()) then
                exit(PosTransLine."Line No." + 10000)
        end;
        exit(10000);
    end;

    internal procedure KioskBasketCalculateTransaction(var MobileTransactionLineTmp: Record LSCMobileTransactionLine temporary; var MobileTransactionTmp: Record LSCMobileTransaction temporary; var MobileTransDiscLine: Record LSCMobileTransDiscountLine temporary; var MobileTransSubLineTmp: Record LSCMobileTransactionSubLine temporary; var ResponseCode: Code[10]; var ResponseText: Text[250]): Boolean
    var
        MobileTransactionOrderTmp: Record LSCMobileTransactionOrder temporary;
        WebDeliveryOrderTemp: Record "LSC WebDeliveryOrder" temporary;
        WebPOS: Codeunit LSCWebPOS;
        PreCalc: Boolean;
        Post: Boolean;
        DeleteTmpTrans: Boolean;
        HospitalityTerminal: Boolean;
        StaffID: Code[20];
        WarningCode: Code[10];
        WarningText: Text[250];
    begin
        PreCalc := false;
        Post := false;
        DeleteTmpTrans := false;

        webpos.CalculateMobileTransaction(MobileTransactionTmp, MobileTransactionLineTmp, MobileTransDiscLine, MobileTransactionOrderTmp, MobileTransSubLineTmp, PreCalc, false, DeleteTmpTrans, HospitalityTerminal, StaffID, WebDeliveryOrderTemp, ResponseCode, ResponseText, WarningCode, WarningText);
        if ResponseCode <> '' then
            if ResponseCode <> '0000' then
                exit(False);
        exit(true);
    end;

    internal procedure KioskBasketModifyTransaction(var MobileTransactionLineTmp: Record LSCMobileTransactionLine temporary; var MobileTransactionTmp: Record LSCMobileTransaction temporary; var MobileTransDiscLine: Record LSCMobileTransDiscountLine temporary; var MobileTransSubLineTmp: Record LSCMobileTransactionSubLine temporary; var ResponseCode: Code[10]; var ResponseText: Text[250]): Boolean
    var
        PreCalc: Boolean;
        Post: Boolean;
        DeleteTmpTrans: Boolean;
        FunctionOK: Boolean;
        ErrorNoTransLine: Label 'Neither item/deal nor member line found';
    begin
        PreCalc := false;
        Post := false;
        DeleteTmpTrans := false;

        if (not MobileTransactionLineTmp.FindFirst()) and (MobileTransactionTmp.MemberCardNo = '') then begin//sending only one line in each call
            ResponseCode := 'NOITEM';
            ResponseText := ErrorNoTransLine;
            exit(false);
        end;

        case MobileTransactionLineTmp."Self Service Action" of
            "LSC Self Service Action"::Added:
                FunctionOK := KioskBasketAddItemToExistingTransaction(MobileTransactionLineTmp, MobileTransactionTmp, MobileTransDiscLine, MobileTransSubLineTmp, ResponseCode, ResponseText);
            "LSC Self Service Action"::Modified:
                FunctionOK := KioskBasketModifyItemInExistingTransaction(MobileTransactionLineTmp, MobileTransactionTmp, MobileTransDiscLine, MobileTransSubLineTmp, ResponseCode, ResponseText);
            "LSC Self Service Action"::Voided:
                FunctionOK := KioskBasketVoidItemInExistingTransaction(MobileTransactionLineTmp, MobileTransactionTmp, MobileTransDiscLine, MobileTransSubLineTmp, ResponseCode, ResponseText);
            "LSC Self Service Action"::"CrossSelling Modifier Added":
                FunctionOK := KioskBasketAddCrossSellingItemToExistingTransaction(MobileTransactionLineTmp, MobileTransactionTmp, MobileTransDiscLine, MobileTransSubLineTmp, ResponseCode, ResponseText);
        end;

        if (not MobileTransactionLineTmp.FindFirst()) and (MobileTransactionTmp.MemberCardNo <> '') then
            FunctionOK := KioskBasketAddItemToExistingTransaction(MobileTransactionLineTmp, MobileTransactionTmp, MobileTransDiscLine, MobileTransSubLineTmp, ResponseCode, ResponseText);

        exit(FunctionOK);
    end;

    /// <summary>
    /// Transfers the MobileTransaction table data to JSON formatted string
    /// ReceiptNo and LineNo for the lines - they all come from the mobiletransaction tables (they may have changed on calculate)
    /// </summary>
    /// <param name="JSONBuffer"></param>
    /// <param name="MobileTransactionLineTmp"></param>
    /// <param name="MobileTransactionTmp"></param>
    /// <param name="MobileTransDiscLineTmp"></param>
    /// <param name="MobileTransSubLineTmp"></param>
    internal procedure KioskBasketTurnCalculatedTransactionIntoJson(var JSONBuffer: Text; var MobileTransactionLineTmp: Record LSCMobileTransactionLine temporary; var MobileTransactionTmp: Record LSCMobileTransaction temporary; var MobileTransDiscLineTmp: Record LSCMobileTransDiscountLine temporary; var MobileTransSubLineTmp: Record LSCMobileTransactionSubLine temporary; PosFuncProfile: Record "LSC POS Func. Profile")
    var
        JSonUtil: Codeunit "LSC POS JSON Util";
        MobileTransDealSubLinesTmp: Record LSCMobileTransactionSubLine temporary;
        MembershipCard: Record "LSC Membership Card";
        MemberContact: Record "LSC Member Contact";
        MemberAccount: Record "LSC Member Account";
        Points: array[6] of Decimal;
        UnProcessedPoints: Decimal;
    begin
        JSONBuffer := '{}';

        if (PosFuncProfile."Profile ID" = '') then //previously checked
            exit;
        if not (MobileTransactionTmp.FindFirst()) then //previously checked
            exit; //There should only be one transaction
        JsonUtil.StartJSon();
        JsonUtil.AddToJSon('HTTPErrorCode', '200');
        JsonUtil.AddToJSon('guid', Format(MobileTransactionTmp.Id));
        JsonUtil.AddToJSon('terminalId', MobileTransactionTmp.TerminalId);
        JsonUtil.AddToJSon('storeId', MobileTransactionTmp.StoreId);
        JsonUtil.AddToJSon('staffId', MobileTransactionTmp.StaffId);
        JsonUtil.AddToJSon('salesType', MobileTransactionTmp.SalesType);
        JsonUtil.AddToJSon('receiptNo', MobileTransactionTmp.ReceiptNo);
        JsonUtil.AddToJSon('netAmount', Round(MobileTransactionTmp.NetAmount, PosFuncProfile."Amount Rounding to"));
        JsonUtil.AddToJSon('grossAmount', MobileTransactionTmp.GrossAmount);
        JsonUtil.AddToJSon('discountAmount', MobileTransactionLineTmp.DiscountAmount);
        JSonUtil.AddToJSon('queueCounter', MobileTransactionTmp."Queue Counter");

        //Member
        if MembershipCard.Get(MobileTransactionTmp.MemberCardNo) then begin
            if MemberContact.Get(MembershipCard."Account No.", MembershipCard."Contact No.") then begin
                JSonUtil.StartJSonArray('member');
                JsonUtil.StartJSon();
                JSonUtil.AddToJSon('memberCode', MobileTransactionTmp.MemberCardNo);
                JSonUtil.AddToJSon('memberPriceGroup', MobileTransactionTmp.MemberPriceGroupCode);
                JSonUtil.AddToJSon('memberContactNo', MobileTransactionTmp.MemberContactNo);
                JSonUtil.AddToJSon('memberName', MemberContact.Name);
                JSonUtil.AddToJSon('memberSchemeCode', MembershipCard."Scheme Code");
                if MemberAccount.Get(MembershipCard."Account No.") then begin
                    MemberAccount.CalculateMemberPoints(Points);
                    UnprocessedPoints := MemberAccount.CalculateUnprocessedPoints();
                    JSonUtil.StartJSonArray('memberPoints');
                    JsonUtil.StartJSon();
                    JSonUtil.AddToJSon('IssuedAwardPoints', Points[2]);
                    JSonUtil.AddToJSon('IssuedOtherPoints', Points[3]);
                    JSonUtil.AddToJSon('TotalIssuedPoints', Points[2] + Points[3]);
                    JSonUtil.AddToJSon('ExpiredPoints', Points[1]);
                    JSonUtil.AddToJSon('UsedPoints', Points[4]);
                    JSonUtil.AddToJSon('Balance', Points[6]);
                    JSonUtil.AddToJSon('UnprocessedPoints', UnprocessedPoints);
                    JSonUtil.AddToJSon('TotalRemainingPoints', Points[6] + UnprocessedPoints);
                    JSonUtil.AddToJSon('TransferedPoints', Points[5]);
                    JSonUtil.EndJSon();
                    JSonUtil.EndJSonArray();
                end;
                JSonUtil.EndJSon();
                JSonUtil.EndJSonArray();
            end;
        end;

        //Items
        MobileTransactionLineTmp.Reset();
        MobileTransactionLineTmp.SetRange(LineType, 0);
        MobileTransactionLineTmp.SetRange(DealItem, 0);
        MobileTransactionLineTmp.SetRange(TransactionNo, MobileTransactionTmp.TransactionNo);
        if MobileTransactionLineTmp.FindSet() then begin
            JSonUtil.StartJSonArray('items');
            repeat
                JsonUtil.StartJSon();
                JsonUtil.AddToJSon('itemNo', MobileTransactionLineTmp.Number);
                JsonUtil.AddToJSon('description', MobileTransactionLineTmp.ItemDescription);
                JsonUtil.AddToJSon('image', Image_GetItemImageID(MobileTransactionLineTmp.Number));
                JsonUtil.AddToJSon('extLineNo', MobileTransactionLineTmp.ExternalLineNo);
                JsonUtil.AddToJSon('cartSequenceNo', MobileTransactionLineTmp.CartSequenceNo);
                if (MobileTransactionLineTmp.EntryStatus = 1) then
                    JsonUtil.AddToJSon('quantity', 0)
                else
                    JsonUtil.AddToJSon('quantity', MobileTransactionLineTmp.Quantity);
                JsonUtil.AddToJSon('selectedUom', MobileTransactionLineTmp.UomId);
                JsonUtil.AddToJSon('uomDescription', MobileTransactionLineTmp.UomDescription);
                JsonUtil.AddToJSon('price', MobileTransactionLineTmp.Price);
                JsonUtil.AddToJSon('netPrice', MobileTransactionLineTmp.NetPrice);
                JsonUtil.AddToJSon('discountAmount', MobileTransactionLineTmp.DiscountAmount);
                JsonUtil.AddToJSon('netAmount', Round(MobileTransactionLineTmp.NetAmount, PosFuncProfile."Amount Rounding to"));
                JsonUtil.AddToJSon('taxAmount', Round(MobileTransactionLineTmp.TAXAmount, PosFuncProfile."Amount Rounding to"));
                JsonUtil.AddToJSon('amount', MobileTransactionLineTmp.NetAmount + MobileTransactionLineTmp.TAXAmount);
                JSonUtil.AddToJSon('availabilitySet', MobileTransactionLineTmp.AvailabilitySet);
                JSonUtil.AddToJSon('availability', MobileTransactionLineTmp.Availability);
                JsonUtil.AddToJSon('availabilityUOM', MobileTransactionLineTmp.AvailabilityUOM);
                JsonUtil.AddToJSon('availabilityFactor', MobileTransactionLineTmp.AvailabilityFactor);

                //Modifiers
                MobileTransSubLineTmp.Reset();
                MobileTransSubLineTmp.SetRange(ParentLineNo, MobileTransactionLineTmp.LineNo);
                MobileTransSubLineTmp.SetRange(ParentLineIsSubline, 0);
                MobileTransSubLineTmp.SetRange(DealLine, 0);
                MobileTransSubLineTmp.SetFilter(ModifierGroupCode, '<>%1', '');
                if (MobileTransSubLineTmp.FindSet()) then begin
                    JSonUtil.StartJSonArray('modifiers');
                    repeat
                        JsonUtil.StartJSon();
                        JsonUtil.AddToJSon('modifierItemNo', MobileTransSubLineTmp.Number);
                        JsonUtil.AddToJSon('description', MobileTransSubLineTmp.Description);
                        JsonUtil.AddToJSon('image', Image_GetItemImageID(MobileTransSubLineTmp.Number));
                        JsonUtil.AddToJSon('extLineNo', MobileTransSubLineTmp.ExternalLineNo);
                        JsonUtil.AddToJSon('modGroupId', MobileTransSubLineTmp.ModifierGroupCode);
                        JsonUtil.AddToJSon('modGroupSubCode', MobileTransSubLineTmp.ModifierSubCode);
                        JsonUtil.AddToJSon('quantity', MobileTransSubLineTmp.Quantity);
                        JsonUtil.AddToJSon('selectedUom', MobileTransSubLineTmp.UomId);
                        JsonUtil.AddToJSon('uomDescription', MobileTransSubLineTmp.UomDescription);
                        JsonUtil.AddToJSon('price', MobileTransSubLineTmp.Price);
                        JsonUtil.AddToJSon('netPrice', MobileTransSubLineTmp.NetPrice);
                        JsonUtil.AddToJSon('discountAmount', MobileTransSubLineTmp.DiscountAmount);
                        JsonUtil.AddToJSon('netAmount', Round(MobileTransSubLineTmp.NetAmount, PosFuncProfile."Amount Rounding to"));
                        JsonUtil.AddToJSon('taxAmount', Round(MobileTransSubLineTmp.TAXAmount, PosFuncProfile."Amount Rounding to"));
                        JsonUtil.AddToJSon('amount', MobileTransSubLineTmp.NetAmount + MobileTransSubLineTmp.TAXAmount);
                        JsonUtil.EndJSon();
                    until MobileTransSubLineTmp.Next() = 0;
                    JSonUtil.EndJSonArray();
                end;

                //Ingredients
                MobileTransSubLineTmp.Reset();
                MobileTransSubLineTmp.SetRange(ParentLineNo, MobileTransactionLineTmp.LineNo);
                MobileTransSubLineTmp.SetRange(ParentLineIsSubline, 0);
                MobileTransSubLineTmp.SetRange(DealLine, 0);
                MobileTransSubLineTmp.SetRange(LineType, 0);
                MobileTransSubLineTmp.SetRange(ModifierGroupCode, '');
                if (MobileTransSubLineTmp.FindSet()) then begin
                    JSonUtil.StartJSonArray('ingredients');
                    repeat
                        JsonUtil.StartJSon();
                        JsonUtil.AddToJSon('ingredientItemNo', MobileTransSubLineTmp.Number);
                        JsonUtil.AddToJSon('description', MobileTransSubLineTmp.Description);
                        JsonUtil.AddToJSon('extLineNo', MobileTransSubLineTmp.ExternalLineNo);
                        JsonUtil.AddToJSon('quantity', MobileTransSubLineTmp.Quantity);
                        JsonUtil.AddToJSon('selectedUom', MobileTransSubLineTmp.UomId);
                        JsonUtil.AddToJSon('uomDescription', MobileTransSubLineTmp.UomDescription);
                        JsonUtil.AddToJSon('price', MobileTransSubLineTmp.Price);
                        JsonUtil.AddToJSon('netPrice', MobileTransSubLineTmp.NetPrice);
                        JsonUtil.AddToJSon('discountAmount', MobileTransSubLineTmp.DiscountAmount);
                        JsonUtil.AddToJSon('netAmount', Round(MobileTransSubLineTmp.NetAmount, PosFuncProfile."Amount Rounding to"));
                        JsonUtil.AddToJSon('taxAmount', Round(MobileTransSubLineTmp.TAXAmount, PosFuncProfile."Amount Rounding to"));
                        JsonUtil.AddToJSon('amount', MobileTransSubLineTmp.NetAmount + MobileTransSubLineTmp.TAXAmount);
                        JsonUtil.EndJSon();
                    until MobileTransSubLineTmp.Next() = 0;
                    JSonUtil.EndJSonArray();
                end;
                JsonUtil.EndJSon();
            until MobileTransactionLineTmp.Next() = 0;
            JSonUtil.EndJSonArray();
        end;

        //Deals
        MobileTransactionLineTmp.Reset();
        MobileTransactionLineTmp.SetRange(LineType, 0);
        MobileTransactionLineTmp.SetRange(DealItem, 1);
        MobileTransactionLineTmp.SetFilter(EntryStatus, '<>%1', 1);  //We don't want voided Deals to go back
        MobileTransactionLineTmp.SetRange(TransactionNo, MobileTransactionTmp.TransactionNo);
        if MobileTransactionLineTmp.FindSet() then begin
            //Make a copy of all the sublines for handling item modifiers/ingredients
            MobileTransSubLineTmp.Reset();
            MobileTransDealSubLinesTmp.DeleteAll();
            if MobileTransSubLineTmp.FindSet() then
                repeat
                    MobileTransDealSubLinesTmp.TransferFields(MobileTransSubLineTmp);
                    MobileTransDealSubLinesTmp.Insert();
                until MobileTransSubLineTmp.Next() = 0;

            JSonUtil.StartJSonArray('deals');
            repeat
                JsonUtil.StartJSon();
                JsonUtil.AddToJSon('dealNo', MobileTransactionLineTmp.Number);
                JsonUtil.AddToJSon('description', MobileTransactionLineTmp.ItemDescription);
                JsonUtil.AddToJSon('extLineNo', MobileTransactionLineTmp.ExternalLineNo);
                JsonUtil.AddToJSon('cartSequenceNo', MobileTransactionLineTmp.CartSequenceNo);
                JsonUtil.AddToJSon('image', Image_GetDealImageID(MobileTransactionLineTmp.Number));
                JsonUtil.AddToJSon('quantity', MobileTransactionLineTmp.Quantity);
                JsonUtil.AddToJSon('price', MobileTransactionLineTmp.Price);
                JsonUtil.AddToJSon('netPrice', MobileTransactionLineTmp.NetPrice);
                JsonUtil.AddToJSon('discountAmount', MobileTransactionLineTmp.DiscountAmount);
                JsonUtil.AddToJSon('netAmount', Round(MobileTransactionLineTmp.NetAmount, PosFuncProfile."Amount Rounding to"));
                JsonUtil.AddToJSon('taxAmount', Round(MobileTransactionLineTmp.TAXAmount, PosFuncProfile."Amount Rounding to"));
                JsonUtil.AddToJSon('amount', MobileTransactionLineTmp.NetAmount + MobileTransactionLineTmp.TAXAmount);

                //Deal Modifiers
                MobileTransSubLineTmp.Reset();
                MobileTransSubLineTmp.SetRange(ParentLineNo, MobileTransactionLineTmp.LineNo);
                MobileTransSubLineTmp.SetRange(ParentLineIsSubline, 0);
                MobileTransSubLineTmp.SetRange(LineType, 1);
                MobileTransSubLineTmp.SetRange(DealId, MobileTransactionLineTmp.Number);
                MobileTransSubLineTmp.SetFilter(DealLine, '<>%1', 0);
                MobileTransSubLineTmp.SetFilter(DealModLine, '<>%1', 0);

                if (MobileTransSubLineTmp.FindSet()) then begin
                    JSonUtil.StartJSonArray('dealModifiers');
                    repeat
                        JsonUtil.StartJSon();
                        JsonUtil.AddToJSon('dealModifierItemNo', MobileTransSubLineTmp.Number);
                        JsonUtil.AddToJSon('description', MobileTransSubLineTmp.Description);
                        JsonUtil.AddToJSon('image', Image_GetItemImageID(MobileTransSubLineTmp.Number));
                        JsonUtil.AddToJSon('extLineNo', MobileTransSubLineTmp.ExternalLineNo);
                        JsonUtil.AddToJSon('quantity', MobileTransSubLineTmp.Quantity);
                        JsonUtil.AddToJSon('selectedUom', MobileTransSubLineTmp.UomId);
                        JsonUtil.AddToJSon('uomDescription', MobileTransSubLineTmp.UomDescription);
                        JsonUtil.AddToJSon('price', MobileTransSubLineTmp.Price);
                        JsonUtil.AddToJSon('netPrice', MobileTransSubLineTmp.NetPrice);
                        JsonUtil.AddToJSon('discountAmount', MobileTransSubLineTmp.DiscountAmount);
                        JsonUtil.AddToJSon('netAmount', Round(MobileTransSubLineTmp.NetAmount, PosFuncProfile."Amount Rounding to"));
                        JsonUtil.AddToJSon('taxAmount', Round(MobileTransSubLineTmp.TAXAmount, PosFuncProfile."Amount Rounding to"));
                        JsonUtil.AddToJSon('amount', MobileTransSubLineTmp.NetAmount + MobileTransSubLineTmp.TAXAmount);
                        JsonUtil.EndJSon();
                    until MobileTransSubLineTmp.Next() = 0;
                    JSonUtil.EndJSonArray();
                end;

                // Deal Items
                MobileTransSubLineTmp.Reset();
                MobileTransSubLineTmp.SetRange(ParentLineNo, MobileTransactionLineTmp.LineNo);
                MobileTransSubLineTmp.SetRange(ParentLineIsSubline, 0);
                MobileTransSubLineTmp.SetFilter(DealLine, '<>%1', 0);
                MobileTransSubLineTmp.SetRange(DealId, MobileTransactionLineTmp.Number);
                MobileTransSubLineTmp.SetRange(LineType, 1);
                MobileTransSubLineTmp.SetRange(DealModLine, 0);
                if (MobileTransSubLineTmp.FindSet()) then begin
                    JSonUtil.StartJSonArray('items');
                    repeat
                        JsonUtil.StartJSon();
                        JsonUtil.AddToJSon('itemNo', MobileTransSubLineTmp.Number);
                        JsonUtil.AddToJSon('dealLine', MobileTransSubLineTmp.DealLine);
                        JsonUtil.AddToJSon('description', MobileTransSubLineTmp.Description);
                        JsonUtil.AddToJSon('image', Image_GetItemImageID(MobileTransSubLineTmp.Number));
                        JsonUtil.AddToJSon('extLineNo', MobileTransSubLineTmp.ExternalLineNo);
                        JsonUtil.AddToJSon('quantity', MobileTransSubLineTmp.Quantity);
                        JsonUtil.AddToJSon('selectedUom', MobileTransSubLineTmp.UomId);
                        JsonUtil.AddToJSon('uomDescription', MobileTransSubLineTmp.UomDescription);
                        JsonUtil.AddToJSon('price', MobileTransSubLineTmp.Price);
                        JsonUtil.AddToJSon('netPrice', MobileTransSubLineTmp.NetPrice);
                        JsonUtil.AddToJSon('discountAmount', MobileTransSubLineTmp.DiscountAmount);
                        JsonUtil.AddToJSon('netAmount', Round(MobileTransSubLineTmp.NetAmount, PosFuncProfile."Amount Rounding to"));
                        JsonUtil.AddToJSon('taxAmount', Round(MobileTransSubLineTmp.TAXAmount, PosFuncProfile."Amount Rounding to"));
                        JsonUtil.AddToJSon('amount', MobileTransSubLineTmp.NetAmount + MobileTransSubLineTmp.TAXAmount);

                        //Modifiers
                        MobileTransDealSubLinesTmp.Reset();
                        MobileTransDealSubLinesTmp.SetFilter(LineType, '%1|%2', 0, 2);
                        MobileTransDealSubLinesTmp.SetRange(ParentLineIsSubline, 1);
                        MobileTransDealSubLinesTmp.SetRange(ParentLineNo, MobileTransSubLineTmp.LineNo);
                        MobileTransDealSubLinesTmp.SetFilter(Quantity, '<>%1', 0);
                        MobileTransDealSubLinesTmp.SetRange(DealId, '');
                        MobileTransDealSubLinesTmp.SetRange(DealLine, 0);
                        MobileTransDealSubLinesTmp.SetFilter(ModifierGroupCode, '<>%1', '');
                        MobileTransDealSubLinesTmp.SetFilter(ModifierSubCode, '<>%1', '');

                        if (MobileTransDealSubLinesTmp.FindSet()) then begin
                            JSonUtil.StartJSonArray('modifiers');
                            repeat
                                JsonUtil.StartJSon();
                                JsonUtil.AddToJSon('modifierItemNo', MobileTransDealSubLinesTmp.Number);
                                JsonUtil.AddToJSon('description', MobileTransDealSubLinesTmp.Description);
                                JsonUtil.AddToJSon('image', Image_GetItemImageID(MobileTransDealSubLinesTmp.Number));
                                JsonUtil.AddToJSon('extLineNo', MobileTransDealSubLinesTmp.ExternalLineNo);
                                JsonUtil.AddToJSon('quantity', MobileTransDealSubLinesTmp.Quantity);
                                JsonUtil.AddToJSon('modGroupId', MobileTransDealSubLinesTmp.ModifierGroupCode);
                                JsonUtil.AddToJSon('modGroupSubCode', MobileTransDealSubLinesTmp.ModifierSubCode);
                                JsonUtil.AddToJSon('selectedUom', MobileTransDealSubLinesTmp.UomId);
                                JsonUtil.AddToJSon('uomDescription', MobileTransDealSubLinesTmp.UomDescription);
                                JsonUtil.AddToJSon('price', MobileTransDealSubLinesTmp.Price);
                                JsonUtil.AddToJSon('netPrice', MobileTransDealSubLinesTmp.NetPrice);
                                JsonUtil.AddToJSon('discountAmount', MobileTransDealSubLinesTmp.DiscountAmount);
                                JsonUtil.AddToJSon('netAmount', Round(MobileTransDealSubLinesTmp.NetAmount, PosFuncProfile."Amount Rounding to"));
                                JsonUtil.AddToJSon('taxAmount', Round(MobileTransDealSubLinesTmp.TAXAmount, PosFuncProfile."Amount Rounding to"));
                                JsonUtil.AddToJSon('amount', MobileTransDealSubLinesTmp.NetAmount + MobileTransDealSubLinesTmp.TAXAmount);
                                JsonUtil.EndJSon();
                            until MobileTransDealSubLinesTmp.Next() = 0;
                            JSonUtil.EndJSonArray();
                        end;

                        //Ingredients
                        MobileTransDealSubLinesTmp.Reset();
                        MobileTransDealSubLinesTmp.SetRange(LineType, 0);
                        MobileTransDealSubLinesTmp.SetRange(ParentLineIsSubline, 1);
                        MobileTransDealSubLinesTmp.SetRange(ParentLineNo, MobileTransSubLineTmp.LineNo);
                        MobileTransDealSubLinesTmp.SetRange(DealId, '');
                        MobileTransDealSubLinesTmp.SetRange(DealLine, 0);
                        MobileTransDealSubLinesTmp.SetRange(Quantity, 0);
                        MobileTransDealSubLinesTmp.SetRange(ModifierGroupCode, '');
                        MobileTransDealSubLinesTmp.SetRange(ModifierSubCode, '');

                        if (MobileTransDealSubLinesTmp.FindSet()) then begin
                            JSonUtil.StartJSonArray('ingredients');
                            repeat
                                JsonUtil.StartJSon();
                                JsonUtil.AddToJSon('ingredientItemNo', MobileTransDealSubLinesTmp.Number);
                                JsonUtil.AddToJSon('description', MobileTransDealSubLinesTmp.Description);
                                JsonUtil.AddToJSon('image', Image_GetItemImageID(MobileTransDealSubLinesTmp.Number));
                                JsonUtil.AddToJSon('extLineNo', MobileTransDealSubLinesTmp.ExternalLineNo);
                                JsonUtil.AddToJSon('quantity', MobileTransDealSubLinesTmp.Quantity);
                                JsonUtil.AddToJSon('selectedUom', MobileTransDealSubLinesTmp.UomId);
                                JsonUtil.AddToJSon('uomDescription', MobileTransDealSubLinesTmp.UomDescription);
                                JsonUtil.AddToJSon('price', MobileTransDealSubLinesTmp.Price);
                                JsonUtil.AddToJSon('netPrice', MobileTransDealSubLinesTmp.NetPrice);
                                JsonUtil.AddToJSon('discountAmount', MobileTransDealSubLinesTmp.DiscountAmount);
                                JsonUtil.AddToJSon('netAmount', Round(MobileTransDealSubLinesTmp.NetAmount, PosFuncProfile."Amount Rounding to"));
                                JsonUtil.AddToJSon('taxAmount', Round(MobileTransDealSubLinesTmp.TAXAmount, PosFuncProfile."Amount Rounding to"));
                                JsonUtil.AddToJSon('amount', MobileTransDealSubLinesTmp.NetAmount + MobileTransDealSubLinesTmp.TAXAmount);
                                JsonUtil.EndJSon();
                            until MobileTransDealSubLinesTmp.Next() = 0;
                            JSonUtil.EndJSonArray();
                        end;
                        JsonUtil.EndJSon();
                    until MobileTransSubLineTmp.Next() = 0;
                    JSonUtil.EndJSonArray();
                end;
                JsonUtil.EndJSon();
            until MobileTransactionLineTmp.Next() = 0;
            JSonUtil.EndJSonArray();
        end;
        JSonUtil.EndJSon();
        JSONBuffer := JSonUtil.GetJSon();
    end;

    local procedure KioskBasketAddItemToExistingTransaction(var MobileTransactionLineTmp: Record LSCMobileTransactionLine temporary; var MobileTransactionTmp: Record LSCMobileTransaction temporary; var MobileTransDiscLine: Record LSCMobileTransDiscountLine temporary; var MobileTransSubLineTmp: Record LSCMobileTransactionSubLine temporary; var ResponseCode: Code[10]; var ResponseText: Text[250]): Boolean
    var
        WebPOSHosp: Codeunit "LSC WebPOS Hospitality";
    begin
        exit(WebPOSHosp.AddMobileTransLine(MobileTransactionLineTmp, MobileTransactionTmp, MobileTransDiscLine, MobileTransSubLineTmp, ResponseCode, ResponseText));
    end;

    local procedure KioskBasketModifyItemInExistingTransaction(var MobileTransactionLineTmp: Record LSCMobileTransactionLine temporary; var MobileTransactionTmp: Record LSCMobileTransaction temporary; var MobileTransDiscLine: Record LSCMobileTransDiscountLine temporary; var MobileTransSubLineTmp: Record LSCMobileTransactionSubLine temporary; var ResponseCode: Code[10]; var ResponseText: Text[250]): Boolean
    var
        POSTransaction: Record "LSC POS Transaction";
        POSTransLine: Record "LSC POS Trans. Line";
        TableRecNotFoundErr: Label '%1 %2 not found';
        NewLineNo: Integer;
    begin
        if not POSTransaction.get(MobileTransactionTmp.ReceiptNo) then begin
            ResponseCode := 'MODITEMEX';
            ResponseText := StrSubstNo(TableRecNotFoundErr, POSTransaction.TableCaption, MobileTransactionTmp.ReceiptNo);
            exit(False);
        end;

        if not MobileTransactionLineTmp.FindFirst() then begin
            ResponseCode := 'MODITEMEX';
            ResponseText := StrSubstNo(TableRecNotFoundErr, MobileTransactionLineTmp.tablecaption, MobileTransactionLineTmp.LineNo);
            exit(false);
        end;

        if not POSTransLine.get(POSTransaction."Receipt No.", MobileTransactionLineTmp.ExternalLineNo) then begin
            ResponseCode := 'MODITEMEX';
            ResponseText := StrSubstNo(TableRecNotFoundErr, POSTransLine.TableCaption, MobileTransactionLineTmp.ExternalLineNo);
            exit(False);
        end;

        VoidPOSTransLineAndSubLines(POSTransLine);

        NewLineNo := GetNewTransLineNo(POSTransaction."Receipt No.");

        SwitchLineNumbersInMobileTransLines(MobileTransactionLineTmp, MobileTransSubLineTmp, NewLineNo);
        MobileTransactionLineTmp.Reset();
        MobileTransDiscLine.Reset();
        MobileTransSubLineTmp.Reset();

        exit(KioskBasketAddItemToExistingTransaction(MobileTransactionLineTmp, MobileTransactionTmp, MobileTransDiscLine, MobileTransSubLineTmp, ResponseCode, ResponseText));
    end;

    local procedure KioskBasketVoidItemInExistingTransaction(var MobileTransactionLineTmp: Record LSCMobileTransactionLine temporary; var MobileTransactionTmp: Record LSCMobileTransaction temporary; var MobileTransDiscLine: Record LSCMobileTransDiscountLine temporary; var MobileTransSubLineTmp: Record LSCMobileTransactionSubLine temporary; var ResponseCode: Code[10]; var ResponseText: Text[250]): Boolean
    var
        POSTransaction: Record "LSC POS Transaction";
        POSTransLine: Record "LSC POS Trans. Line";
        Store: Record "LSC Store";
        POSTerminal: Record "LSC POS Terminal";
        Staff: Record "LSC Staff";
        POSFuncProfile: Record "LSC POS Func. Profile";
        WebPOS: Codeunit lscwebpos;
        TableRecNotFoundErr: Label '%1 %2 not found';
    begin
        if not POSTransaction.get(MobileTransactionTmp.ReceiptNo) then begin
            ResponseCode := 'VOIDITEM';
            ResponseText := StrSubstNo(TableRecNotFoundErr, POSTransaction.TableCaption, MobileTransactionTmp.ReceiptNo);
            exit(False);
        end;

        if not MobileTransactionLineTmp.FindFirst() then begin
            ResponseCode := 'VOIDITEM';
            ResponseText := StrSubstNo(TableRecNotFoundErr, MobileTransactionLineTmp.tablecaption, MobileTransactionLineTmp.LineNo);
            exit(False);
        end;

        if not POSTransLine.get(POSTransaction."Receipt No.", MobileTransactionLineTmp.ExternalLineNo) then begin
            ResponseCode := 'VOIDITEM';
            ResponseText := StrSubstNo(TableRecNotFoundErr, POSTransLine.TableCaption, MobileTransactionLineTmp.ExternalLineNo);
            exit(False);
        end;

        VoidPOSTransLineAndSubLines(POSTransLine);

        if not WebPOS.LoadTransaction_GetBasicInfoFromMobileTransactionV2(MobileTransactionTmp, Store, POSTerminal, Staff, POSFuncProfile, ResponseCode, ResponseText) then
            exit(false);

        if not WebPOS.LoadTransaction_CalculatePOSTransAfterProcessingLines(POSTransaction, false, ResponseCode, ResponseText) then
            exit(False);

        WebPOS.LoadMobileTransaction(MobileTransactionTmp, MobileTransactionLineTmp, MobileTransDiscLine, MobileTransSubLineTmp, false);
        POSTransaction.Get(MobileTransactionTmp.ReceiptNo);
        if MobileTransactionTmp.MemberCardNo <> '' then
            POSFunctions().GetMemberPointValuesCalculate(MobileTransactionTmp, MobileTransactionLineTmp, POSTransaction);

        exit(true);
    end;

    local procedure KioskBasketAddCrossSellingItemToExistingTransaction(var MobileTransactionLineTmp: Record LSCMobileTransactionLine temporary; var MobileTransactionTmp: Record LSCMobileTransaction temporary; var MobileTransDiscLine: Record LSCMobileTransDiscountLine temporary; var MobileTransSubLineTmp: Record LSCMobileTransactionSubLine temporary; var ResponseCode: Code[10]; var ResponseText: Text[250]): Boolean
    var
        Store: Record "LSC Store";
        POSTerminal: Record "LSC POS Terminal";
        Staff: Record "LSC Staff";
        POSFuncProfile: Record "LSC POS Func. Profile";
        POSTransaction: Record "LSC POS Transaction";
        POSTransLineTmp: Record "LSC POS Trans. Line" temporary;
        ParentPOSTransLine: Record "LSC POS Trans. Line";
        NewPOSTransLine: Record "LSC POS Trans. Line";
        MobileTransSubLineTmp2: Record LSCMobileTransactionSubLine temporary;
        LineMappingTmp: Record "LSC POS Trans. Line" temporary;
        Infocode: Record "LSC Infocode";
        InformationSubcode: Record "LSC Information Subcode";
        WebPOS: Codeunit LSCWebPOS;
        WebPOSHosp: Codeunit "LSC WebPOS Hospitality";
        WebPOSProcessMobileLines: Codeunit "LSC WebPOS Process Mob. Line";
        POSInfocodeUtility: Codeunit "LSC POS Infocode Utility";
        SubLinesExist: Boolean;
        ItemPrice: Decimal;
        SetPrice: Boolean;
        ItemQty: Decimal;
        ItemUOM: Code[10];
        ErrorText: Text;
        Canceled: Boolean;
        TSError: Boolean;
        EntryLineNo: Integer;
        TransNotFoundErr: Label '%1 %2 not found.';
        CrossSellingCodeNotFoundErr: Label '%1 %2 not found.';
        CrossSellingSubCodeNotFoundErr: Label '%1 %2 %3 not found.';
    begin
        if not POSTransaction.get(MobileTransactionTmp.ReceiptNo) then begin
            ResponseCode := 'ADDITEMCR';
            ResponseText := StrSubstNo(TransNotFoundErr, POSTransaction.TableCaption, MobileTransactionTmp.ReceiptNo);
            exit(false);
        end;
        if MobileTransactionLineTmp."Cross-selling Parent Line No." <> 0 then begin
            if not ParentPOSTransLine.Get(POSTransaction."Receipt No.", MobileTransactionLineTmp."Cross-selling Parent Line No.") then begin
                ResponseCode := 'ADDITEMCR';
                ResponseText := StrSubstNo(TransNotFoundErr, ParentPOSTransLine.TableCaption, MobileTransactionTmp.ReceiptNo, MobileTransactionLineTmp.LineNo);
                exit(false);
            end;
        end else
            ParentPOSTransLine."Receipt No." := POSTransaction."Receipt No.";

        if not Infocode.Get(MobileTransactionLineTmp."Cross-selling Infocode") then begin
            ResponseCode := 'ADDITEMCR';
            ResponseText := StrSubstNo(CrossSellingCodeNotFoundErr, Infocode.TableCaption, MobileTransactionLineTmp."Cross-selling Infocode");
            exit(false);
        end;

        if not InformationSubcode.Get(MobileTransactionLineTmp."Cross-selling Infocode", MobileTransactionLineTmp."Cross-selling Subcode") then begin
            ResponseCode := 'ADDITEMCR';
            ResponseText := StrSubstNo(CrossSellingSubCodeNotFoundErr, InformationSubcode.TableCaption, MobileTransactionLineTmp."Cross-selling Infocode", MobileTransactionLineTmp."Cross-selling Subcode");
            exit(false);
        end;

        GetPriceForCrossSellingItem(InformationSubcode, ItemPrice, SetPrice, ItemQty, ItemUOM, POSTransaction."Trans. Currency Code", ParentPOSTransLine.Price);
        if SetPrice then begin
            MobileTransactionLineTmp.ManualPrice := ItemPrice;
            MobileTransactionLineTmp.ManualPriceSet := true;
        end;
        MobileTransactionLineTmp.UomId := ItemUOM;
        MobileTransactionLineTmp.Quantity := ItemQty;

        if not WebPOS.LoadTransaction_GetBasicInfoFromMobileTransactionV2(MobileTransactionTmp, Store, POSTerminal, Staff, POSFuncProfile, ResponseCode, ResponseText) then
            exit(false);

        WebPOSHosp.SetHospTableInfo(LineMappingTmp, MobileTransSubLineTmp, MobileTransSubLineTmp2, SubLinesExist);

        if not WebPOSProcessMobileLines.ProcessItemLine(MobileTransactionTmp, MobileTransactionLineTmp, MobileTransSubLineTmp, MobileTransSubLineTmp2, ResponseCode, ResponseText, false, POSTransaction, Store, POSTransLineTmp, LineMappingTmp, POSFuncProfile, SubLinesExist) then
            exit(false);

        if not WebPOS.LoadTransaction_CalculatePOSTransAfterProcessingLines(POSTransaction, false, ResponseCode, ResponseText) then
            exit(false);

        if MobileTransactionTmp.MemberCardNo <> '' then
            if POSTransaction."Member Card No." <> MobileTransactionTmp.MemberCardNo then begin
                POSTransaction.Validate("Member Card No.", MobileTransactionTmp.MemberCardNo);
                POSTransaction.Modify();
            end;

        WebPOS.LoadMobileTransaction(MobileTransactionTmp, MobileTransactionLineTmp, MobileTransDiscLine, MobileTransSubLineTmp, false);
        POSTransaction.Get(MobileTransactionTmp.ReceiptNo);
        if MobileTransactionTmp.MemberCardNo <> '' then
            POSFunctions().GetMemberPointValuesCalculate(MobileTransactionTmp, MobileTransactionLineTmp, POSTransaction);

        NewPOSTransLine.Get(POSTransaction."Receipt No.", MobileTransactionLineTmp.ExternalLineNo);
        if not POSInfocodeUtility.IsInputOk(Infocode, InformationSubcode.Subcode, ErrorText, ParentPOSTransLine, Canceled, POSSession().MgrKey(), false, TSError, NewPOSTransLine.Quantity, '', '', SetPrice, NewPOSTransLine.Price, false, EntryLineNo) then begin
            ResponseCode := 'ADDITEMCR';
            ResponseText := ErrorText;
            exit(false);
        end;
        exit(true);
    end;

    local procedure VoidTransaction(ReceiptNo: Code[20]; var ResponseCode: Code[10]; var ResponseText: Text): Boolean
    var
        POSTrans: Record "LSC POS Transaction";
        POSPostUtility: Codeunit "LSC POS Post Utility";
        TransNotFoundErr: Label '%1 %2 not found.';
    begin
        if POSTrans.get(ReceiptNo) then begin
            PosTrans."Entry Status" := PosTrans."Entry Status"::Voided;
            PosTrans.Modify();
            PosPostUtility.ProcessTransaction(PosTrans);
            exit(true);
        end;
        ResponseCode := 'VOIDTR';
        ResponseText := StrSubstNo(TransNotFoundErr, POSTrans.TableCaption, ReceiptNo);
        exit(false);
    end;

    local procedure VoidPOSTransLineAndSubLines(POSTransLine: Record "LSC POS Trans. Line"): Boolean
    begin
        POSFunctions().PosTransDiscLoadData(POSTransLine."Receipt No.", true);
        POSTransLine.VoidLine();
        if POSTransLine."Deal Line" then
            VoidDeal(POSTransLine)
        else
            POSTransLine.VoidLinkedLines(POSTransLine."Receipt No.", POSTransLine."Line No.");
    end;

    local procedure VoidDeal(POSTransLine: Record "LSC POS Trans. Line")
    var
        LinkedLine: Record "LSC POS Trans. Line";
        POSPriceUtility: Codeunit "LSC POS Price Utility";
    begin
        if POSTransLine."Disc. Info Line No." <> 0 then begin
            POSTransLine.VoidLinkedLines(POSTransLine."Receipt No.", POSTransLine."Line No.");
            POSPriceUtility.RegisterDeal(POSTransLine);
        end else begin
            LinkedLine.SetRange("Receipt No.", POSTransLine."Receipt No.");
            LinkedLine.SetRange("Disc. Info Line No.", POSTransLine."Line No.");
            if LinkedLine.FindSet() then
                repeat
                    LinkedLine.VoidLine();
                    LinkedLine.VoidLinkedLines(LinkedLine."Receipt No.", LinkedLine."Line No.");
                until LinkedLine.Next() = 0;
        end;
    end;

    local procedure SwitchLineNumbersInMobileTransLines(var MobileTransactionLineTmp: Record LSCMobileTransactionLine temporary; var MobileTransSubLineTmp: Record LSCMobileTransactionSubLine temporary; NewLineNo: Integer)
    var
        NewMobileTransactionLineTmp: Record LSCMobileTransactionLine temporary;
        NewMobileTransSubLineTmp: Record LSCMobileTransactionSubLine temporary;
        OldLineNo: Integer;
    begin
        NewMobileTransactionLineTmp.DeleteAll();
        NewMobileTransSubLineTmp.DeleteAll();

        OldLineNo := MobileTransactionLineTmp.LineNo;
        NewMobileTransactionLineTmp := MobileTransactionLineTmp;
        NewMobileTransactionLineTmp.LineNo := NewLineNo;
        NewMobileTransactionLineTmp.ExternalLineNo := 0;
        NewMobileTransactionLineTmp.insert();
        MobileTransactionLineTmp.delete();

        if MobileTransSubLineTmp.FindSet() then
            repeat
                NewMobileTransSubLineTmp := MobileTransSubLineTmp;
                if (MobileTransSubLineTmp.ParentLineNo = OldLineNo) then
                    NewMobileTransSubLineTmp.ParentLineNo := NewLineNo;
                NewMobileTransSubLineTmp.ExternalLineNo := 0;
                NewMobileTransSubLineTmp.insert();
            until MobileTransSubLineTmp.Next() = 0;
        MobileTransSubLineTmp.deleteall();

        if NewMobileTransactionLineTmp.FindFirst() then begin
            MobileTransactionLineTmp := NewMobileTransactionLineTmp;
            MobileTransactionLineTmp.insert();
        end;

        if NewMobileTransSubLineTmp.FindSet() then
            repeat
                MobileTransSubLineTmp := NewMobileTransSubLineTmp;
                MobileTransSubLineTmp.insert();
            until NewMobileTransSubLineTmp.Next() = 0;
    end;

    local procedure ReturnErrorToKiosk(ErrorInFunction: Text; ErrorCode: Code[10]; ErrorText: Text; ReceiptNo: Code[20]; POSTerminalNo: Code[20]): Text
    var
        HospSetup: Record "LSC Hospitality Setup";
        WebPOSRequest: Codeunit "LSC WebPOS Request";
        JsonUtil: Codeunit "LSC POS JSON Util";
    begin
        if HospSetup.Get() then;
        if HospSetup."Log Kiosk Errors" then
            WebPOSRequest.LogWebPos(ErrorInFunction, ErrorCode, ErrorText, ReceiptNo, POSTerminalNo, '', '');

        JsonUtil.StartJSon();
        JsonUtil.AddToJSon('HTTPErrorCode', '404');
        JsonUtil.AddToJSon('errorInFunction', ErrorInFunction);
        JsonUtil.AddToJSon('internalErrorCode', ErrorCode);
        JsonUtil.AddToJSon('internalErrorText', ErrorText);
        JsonUtil.EndJSon();

        exit(JsonUtil.GetJSon());
    end;

    internal procedure ViewHierarchyAsJsonObject(HierarchyCode: Text): Text
    var
        DynamicContentBufferOriginalTmp: Record "LSC Dynamic Content Buffer" temporary;
        DynamicContentBufferTmp: Record "LSC Dynamic Content Buffer" temporary;
        DynamicContentBufferTmp2: Record "LSC Dynamic Content Buffer" temporary;
        DynamicContentBufferTmp3: Record "LSC Dynamic Content Buffer" temporary;
        DynamicContentBufferTmp4: Record "LSC Dynamic Content Buffer" temporary;
        DynamicContentBuffer: Record "LSC Dynamic Content Buffer";
        Store: Record "LSC Store";
        POSTerminal: Record "LSC POS Terminal";
        Hierarchy: Record "LSC Hierarchy";
        Language: Record Language;
        JsonUtil: Codeunit "LSC POS JSON Util";
        POSTerminalList: Page "LSC POS Terminal List";
        LanguagePage: Page Languages;
        DynamicContentMgt: Codeunit "LSC Dynamic Content Mgt.";
        MenuDescription: Text;
        ActionVar: Action;
    begin
        POSTerminal.Reset();
        POSTerminalList.LookupMode(true);
        ActionVar := POSTerminalList.runmodal();
        if ActionVar <> ActionVar::lookupOK then
            exit('');

        POSTerminalList.GetRecord(POSTerminal);
        Store.get(POSTerminal."Store No.");

        if not Hierarchy.Get(HierarchyCode) then
            exit('');

        Language.Reset();
        LanguagePage.LookupMode(true);
        ActionVar := LanguagePage.runmodal();
        if ActionVar <> ActionVar::lookupOK then
            exit('');

        LanguagePage.GetRecord(Language);

        Clear(DynamicContentBufferOriginalTmp);
        DynamicContentBufferOriginalTmp.DeleteAll();
        DynamicContentMgt.CreateDynamicContentBufferFromHierarchyNodes(Hierarchy, DynamicContentBufferOriginalTmp, POSTerminal."Default Sales Type", Store."No.", Language.Code);

        DynamicContentBuffer.DeleteAll();
        if DynamicContentBufferOriginalTmp.FindSet() then
            repeat
                DynamicContentBufferTmp.TransferFields(DynamicContentBufferOriginalTmp);
                DynamicContentBufferTmp.Insert();
                DynamicContentBufferTmp2.TransferFields(DynamicContentBufferOriginalTmp);
                DynamicContentBufferTmp2.Insert();
                DynamicContentBufferTmp3.TransferFields(DynamicContentBufferOriginalTmp);
                DynamicContentBufferTmp3.Insert();
                DynamicContentBufferTmp4.TransferFields(DynamicContentBufferOriginalTmp);
                DynamicContentBufferTmp4.Insert();
                DynamicContentBuffer.transferfields(DynamicContentBufferOriginalTmp);
                DynamicContentBuffer.insert();
            until DynamicContentBufferOriginalTmp.Next() = 0;

        DynamicContentBufferOriginalTmp.FindFirst();
        MenuDescription := DynamicContentBufferOriginalTmp.Description;
        JsonUtil.StartJSon();
        JsonUtil.AddToJSon('HTTPErrorCode', '200');
        JsonUtil.StartJSonArray('DynamicContentMenu');
        JsonUtil.StartJSon();
        JsonUtil.AddToJSon('NodeType', 'Title');
        JsonUtil.AddToJSon('NodeID', DynamicContentBufferOriginalTmp.DynamicContentId);
        JsonUtil.AddToJSon('Description', MenuDescription);
        JsonUtil.AddToJSon('Level', DynamicContentBufferOriginalTmp.Level);
        JsonUtil.EndJSon();

        DynamicContentBufferOriginalTmp.Reset();

        AddHierarchyChildren(JsonUtil, DynamicContentBufferOriginalTmp, DynamicContentBufferTmp, DynamicContentBufferTmp2, DynamicContentBufferTmp3, DynamicContentBufferTmp4, MenuDescription);

        JsonUtil.EndJSonArray();
        JsonUtil.EndJSon();
        exit(JsonUtil.GetJSon());
    end;

    internal procedure ViewInitalSettings(): Text
    var
        POSTerminal: Record "LSC POS Terminal";
        Language: Record Language;
        POSTerminalList: Page "LSC POS Terminal List";
        LanguagePage: Page Languages;
        ActionVar: Action;
    begin
        POSTerminal.Reset();
        POSTerminalList.LookupMode(true);
        ActionVar := POSTerminalList.runmodal();
        if ActionVar <> ActionVar::lookupOK then
            exit('');

        Language.Reset();
        LanguagePage.LookupMode(true);
        ActionVar := LanguagePage.runmodal();
        if ActionVar <> ActionVar::lookupOK then
            clear(Language)
        else
            LanguagePage.GetRecord(Language);

        POSTerminalList.GetRecord(POSTerminal);
        exit(GetInitialSettings('', POSTerminal."No.", Language.Code, false));
    end;

    local procedure GetAvailabilityAndImageForItem(ItemNo: Text; var DynamicContentBufferTmp: Record "LSC Dynamic Content Buffer" temporary; var AvailabilitySet: Boolean; var Availability: Decimal; var ImageID: Text; ItemUOM: Code[10]; var AvailabilityUOM: Code[10]; var AvailabilityFactor: Decimal)
    var
        Item: Record Item;
        RecRef: RecordRef;
        CurrentAvailabFunction: Codeunit "LSC Current Availab. Functions";
    begin
        Availability := 0;
        AvailabilitySet := false;
        AvailabilityUOM := '';
        ImageID := '';
        DynamicContentBufferTmp.SetRange(SectionId, 'ITEM');
        DynamicContentBufferTmp.SetRange(ItemId, ItemNo);
        if DynamicContentBufferTmp.FindFirst() then begin
            AvailabilitySet := DynamicContentBufferTmp.CurrentAvailabilitySet;
            Availability := DynamicContentBufferTmp.CurrentAvailability;
            AvailabilityUOM := DynamicContentBufferTmp.CurrentAvailabilityUOM;
            AvailabilityFactor := DynamicContentBufferTmp.CurrentAvailItemQtyPerUOM;
            ImageID := DynamicContentBufferTmp.ImageId;
        end else begin
            if CurrentAvailabFunction.StoreShowCurrentAvailability() <> 0 then begin
                Availability := CurrentAvailabFunction.GetItemCurrentAvailabilityForUOM(POSSession().StoreNo(), ItemNo, ItemUOM, AvailabilitySet);
                AvailabilityUOM := ItemUOM;
            end;
            if Item.Get(ItemNo) then begin
                RecRef.GetTable(Item);
                ImageID := POSSession().AddWebTemplateImage(RecRef.RecordId, '');
            end;
        end;
        DynamicContentBufferTmp.Reset();
        DynamicContentBufferTmp.Reset();
    end;

    local procedure GetPriceForCrossSellingItem(InformationSubcode: Record "LSC Information Subcode"; var ItemPrice: Decimal; var SetPrice: Boolean; var ItemQty: Decimal; var ItemUOM: Code[10]; CurrCode: Code[10]; ParentItemPrice: Decimal)
    begin
        ItemPrice := 0;

        case InformationSubcode."Price Handling" of
            InformationSubcode."Price Handling"::"No Charge":
                begin
                    SetPrice := true;
                    PopupFunctions().GetItemSubcodeItemInfo(InformationSubcode, ItemPrice, SetPrice, ItemQty, ItemUOM, CurrCode);
                end;
            InformationSubcode."Price Handling"::"Always charge":
                begin
                    ItemPrice := ParentItemPrice;
                    PopupFunctions().GetItemSubcodeItemInfo(InformationSubcode, ItemPrice, SetPrice, ItemQty, ItemUOM, CurrCode);
                end;
            else begin
                SetPrice := true;
                PopupFunctions().GetItemSubcodeItemInfo(InformationSubcode, ItemPrice, SetPrice, ItemQty, ItemUOM, CurrCode);
                SetPrice := false;
            end;
        end;
    end;

    procedure VoidTransactionOnAutoLogoffPOSEvent(var PosEvent: Codeunit "LSC POS Event"; NewTransaction: Boolean; AllowAutoLogoffInSalesMode: Boolean; PanelControlCodeunit: Integer; var SuppressEvent: Boolean)
    var
        POSTransaction: Record "LSC POS Transaction";
        POSTerminal: Record "LSC POS Terminal";
        ErrorCode: Code[10];
        ErrorText: Text;
    begin
        POSTerminal.SetLoadFields("Terminal Type");
        if not POSTerminal.get(POSSession().TerminalNo()) then
            exit;

        if POSTerminal."Terminal Type" <> POSTerminal."Terminal Type"::"Self Service Kiosk" then
            exit;

        if PosEvent.ActivePanel() <> Format("LSC POS Panel Id"::"#POS") then begin
            SuppressEvent := true;
            exit;
        end;

        if POSTransaction.Get(POSSession().GetValue("LSC POS Tag"::"CURRORDER")) then
            VoidTransaction(POSTransaction."Receipt No.", ErrorCode, ErrorText);
    end;

    procedure AddMemberToNewMobileTransaction(var MobileTransactionLineTmp: Record LSCMobileTransactionLine temporary; var MobileTransactionTmp: Record LSCMobileTransaction temporary; var MobileTransDiscLineTmp: Record LSCMobileTransDiscountLine temporary; var MobileTransSubLineTmp: Record LSCMobileTransactionSubLine temporary; var ErrorCode: Code[10]; var ErrorText: Text) FunctionOk: Boolean;
    var
        WebPOS: Codeunit LSCWebPOS;
    begin
        FunctionOK := KioskBasketCalculateTransaction(MobileTransactionLineTmp, MobileTransactionTmp, MobileTransDiscLineTmp, MobileTransSubLineTmp, ErrorCode, ErrorText);
        if FunctionOk then
            WebPOS.LoadMobileTransaction(MobileTransactionTmp, MobileTransactionLineTmp, MobileTransDiscLineTmp, MobileTransSubLineTmp, true);
    end;

    procedure AddMemberToExistingMobileTransaction(var MobileTransactionLineTmp: Record LSCMobileTransactionLine temporary; var MobileTransactionTmp: Record LSCMobileTransaction temporary; var MobileTransDiscLineTmp: Record LSCMobileTransDiscountLine temporary; var MobileTransSubLineTmp: Record LSCMobileTransactionSubLine temporary; var ErrorCode: Code[10]; var ErrorText: Text) FunctionOk: Boolean;
    var
        WebPOS: Codeunit LSCWebPOS;
    begin
        WebPOS.LoadMobileTransaction(MobileTransactionTmp, MobileTransactionLineTmp, MobileTransDiscLineTmp, MobileTransSubLineTmp, true);
        FunctionOK := KioskBasketCalculateTransaction(MobileTransactionLineTmp, MobileTransactionTmp, MobileTransDiscLineTmp, MobileTransSubLineTmp, ErrorCode, ErrorText);
        if FunctionOk then
            WebPOS.LoadMobileTransaction(MobileTransactionTmp, MobileTransactionLineTmp, MobileTransDiscLineTmp, MobileTransSubLineTmp, true);
    end;

    internal procedure GetCrossSellsInfo(CrossSellCode: Code[20]; StoreNo: Code[10]; SalesType: Code[20]; SelectedLanguage: Code[10]; ReceiptNo: Code[20]; LineNo: Integer; CurrencyCode: Code[10]): Text
    var
        Store: Record "LSC Store";
        Infocode: Record "LSC Infocode";
        InformationSubcode: Record "LSC Information Subcode";
        POSTransLine: Record "LSC POS Trans. Line";
        CrossSellingGrBuffer: Record "LSC WI Item With Daily Updates" temporary;
        DynContentBuffer: Record "LSC Dynamic Content Buffer" temporary;
        DynContentBuffer2: Record "LSC Dynamic Content Buffer" temporary;
        DynContentBuffer3: Record "LSC Dynamic Content Buffer" temporary;
        Currency: Record Currency;
        TableSpecificInfocode: Record "LSC Table Specific Infocode";
        DynamicContentMgt: Codeunit "LSC Dynamic Content Mgt.";
        JsonUtil: Codeunit "LSC POS JSON Util";
        POSInfocodeUtility: Codeunit "LSC POS Infocode Utility";
        EntryNo: Integer;
        IsHandled: Boolean;
        JsonReturnText: Text;
        NotValidCrossSellCodeErr: Label 'Not a valid CrossSellCode';
    begin
        OnBeforeGetCrossSellsInfo(CrossSellCode, StoreNo, SalesType, SelectedLanguage, ReceiptNo, LineNo, CurrencyCode, IsHandled, JsonReturnText);
        if IsHandled then
            exit(JsonReturnText);

        if not Infocode.Get(CrossSellCode) then
            exit(NotValidCrossSellCodeErr);
        if POSTransLine.Get(ReceiptNo, LineNo) then
            if TableSpecificInfocode.Get(Database::Item, POSTransLine.Number, Infocode.Code) then
                if not POSInfocodeUtility.IsInfoCodeValid(Infocode, POSTransLine, "LSC POS Trans. Request Infoc."::All, TableSpecificInfocode) then
                    exit(NotValidCrossSellCodeErr);
        Store.Get(StoreNo);
        Currency.Get(CurrencyCode);

        if Infocode.Type = Infocode.Type::Group then begin
            InformationSubcode.SetRange(Code, Infocode.Code);
            if InformationSubcode.FindSet() then
                repeat
                    DynamicContentMgt.InsertCrossSellingGrBuffer(CrossSellingGrBuffer, InformationSubcode."Trigger Code");
                until InformationSubcode.Next() = 0;
        end else
            DynamicContentMgt.InsertCrossSellingGrBuffer(CrossSellingGrBuffer, Infocode.Code);
        DynamicContentMgt.AssignInfocodeGrBuffer(CrossSellingGrBuffer, EntryNo, DynContentBuffer, Store, SalesType, Currency, 'CROSSSELL', 'CROSSSELLITEMS', true, SessionLanguageCode);

        CopyDynContentBuffer2Times(DynContentBuffer, DynContentBuffer2, DynContentBuffer3);

        JsonUtil.StartJSon();
        JsonUtil.AddToJSon('HTTPErrorCode', '200');
        JsonUtil.AddToJSon('InfoCode', CrossSellCode);

        DynContentBuffer2.FindFirst(); //infocode details

        AddCrossSellingGroupsToJson(JsonUtil, DynContentBuffer, DynContentBuffer2, DynContentBuffer3, 'CROSSSELL', 'CROSSSELLITEMS', POSTransLine.Price);
        JsonUtil.EndJSon();

        exit(JsonUtil.GetJSon());
    end;

    procedure CopyDynContentBuffer2Times(var DynamicContentBufferOriginalTmp: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferTmp2: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferTmp3: Record "LSC Dynamic Content Buffer" temporary)
    begin
        if DynamicContentBufferOriginalTmp.FindSet() then
            repeat
                DynamicContentBufferTmp2.TransferFields(DynamicContentBufferOriginalTmp);
                DynamicContentBufferTmp2.Insert();
                DynamicContentBufferTmp3.TransferFields(DynamicContentBufferOriginalTmp);
                DynamicContentBufferTmp3.Insert();
            until DynamicContentBufferOriginalTmp.Next() = 0;
    end;

    #region Open Manager Panel

    internal procedure OpenManagerPanel(): Text
    var
        HospitalityType: Record "LSC Hospitality Type";
        ManagerMenuProfileID: Code[10];
        ManagerInterfaceProfileID: Code[10];
        ResultOKTxt: Label 'OK';
    begin
        ManagerMenuProfileID := GetSSKManagerMenuProfileID();
        ManagerInterfaceProfileID := GetSSKManagerInterfaceProfileID();

        if ManagerMenuProfileID = '' then
            exit('');
        If ManagerInterfaceProfileID = '' then
            exit('');

        HospitalityType.SetRange("Restaurant No.", POSSession().StoreNo());
        HospitalityType.SetRange("Sales Type", POSSession().Terminal()."Default Sales Type");
        IF HospitalityType.FindFirst() then
            POSSession().SetValue("LSC POS Tag"::"HOSTYPSEQ", Format(HospitalityType.Sequence));
        POSSession().SetValue("LSC POS Tag"::"SALESTYPE", HospitalityType."Sales Type");
        POSSession().DeleteValue("LSC POS Tag"::"SHOWSALESMENU");
        POSSession().SetValue("LSC POS Tag"::"CURRORDER", 'NEWSALE');
        SetManagerProfiles(ManagerMenuProfileID, ManagerInterfaceProfileID);
        PosCtrlInterface.PostCommand("LSC POS Command"::LOGON, '');
        exit(ResultOKTxt);
    end;

    internal procedure SetManagerProfiles(ManagerMenuProfileID: Code[10]; ManagerInterfaceProfileID: Code[10])
    var
        HospStartupUtilities: Codeunit "LSC Hosp. Startup Utilities";
    begin
        POSSession().SetValue("LSC POS Tag"::Ssk_ManagerLogin, 'YES');
        HospStartupUtilities.SetSpecificMenuAndInterfaceProfiles(ManagerMenuProfileID, ManagerInterfaceProfileID, false);
        SetTerminalStatusText(false);
    end;

    internal procedure ResetManagerProfiles()
    var
        HospStartupUtilities: Codeunit "LSC Hosp. Startup Utilities";
    begin
        POSSession().SetValue("LSC POS Tag"::Ssk_ManagerLogin, '');
        HospStartupUtilities.SetSpecificMenuAndInterfaceProfiles('', '', true);
        SetTerminalStatusText(true);
    end;

    local procedure GetSSKManagerMenuProfileID(): Code[10]
    var
        SSKProfile: Record "LSC SSK Profile";
    begin
        if SSKProfile.Get(POSSession().Store()."SSK Profile ID") then
            exit(SSKProfile."Manager Menu Profile ID");
        exit('');
    end;

    local procedure GetSSKManagerInterfaceProfileID(): Code[10]
    var
        SSKProfile: Record "LSC SSK Profile";
    begin
        if SSKProfile.Get(POSSession().Store()."SSK Profile ID") then
            exit(SSKProfile."Manager Interface Profile ID");
        exit('');
    end;

    internal procedure OnPOSCommand(var ActivePanel: Record "LSC POS Panel"; var PosMenuLine: Record "LSC POS Menu Line")
    var
        POSView: Codeunit "LSC POS View";
    begin
        if PosMenuLine.Command <> Format("LSC POS Command"::LOGON) then
            exit;
        if POSSession().GetValue("LSC POS Tag"::Ssk_ManagerLogin) = '' then
            exit;
        PosMenuLine.Processed := true;
        POSView.LoginEx(true, '', true, '', '', '');
    end;

    internal procedure OnBeforeProcessModalResult(panelID: Text; resultOK: Boolean; payload: Text; var processed: Boolean)
    begin
        if processed then
            exit;
        if panelID <> Format("LSC POS Panel Id"::"#LOGIN") then
            exit;
        if POSSession().GetValue("LSC POS Tag"::Ssk_ManagerLogin) = '' then
            exit;
        processed := true;

        if not resultOK then begin
            ResetManagerProfiles();
            exit;
        end;

        if not ProcessLoginInputOnManagerLogin(panelID, payload) then
            ResetManagerProfiles();
    end;

    internal procedure ProcessLoginInputOnManagerLogin(panelID: Text; payload: Text): Boolean
    var
        POSController: Codeunit "LSC POS Controller";
        POSView: Codeunit "LSC POS View";
        StaffID: Text;
        Password: Text;
        Workshift: Text;
        Manager: Boolean;
        SetNewStaffID: Text;
    begin
        if StrPos(payload, ',') > 0 then begin
            Evaluate(Manager, SelectStr(1, payload)); // Login called with Manager true
            Evaluate(SetNewStaffID, SelectStr(2, payload));
        end;

        StaffID := PosCtrlInterface.GetInputText(Format("LSC POS Input Control Id"::"#STAFFID"));
        Password := PosCtrlInterface.GetInputText(Format("LSC POS Input Control Id"::"#PASSWORD"));
        Workshift := CopyStr(PosCtrlInterface.GetInputText(Format("LSC POS Input Control Id"::"#WORKSHIFT")), 1, 1);
        if StaffID = '' then
            exit(false);

        if not POSView.LoginEx(Manager, SetNewStaffID, false, StaffID, Password, Workshift) then
            exit(false);

        POSSession().SetValue("LSC POS Tag"::Ssk_ManagerLogin, '');

        POSController.SetRefreshMenuFlags();
        POSController.UpdateSessionPermissions();
        POSSession().SetStaff(StaffID);
        POSController.RunPos();
        exit(true);
    end;

    #endregion
    #region Kiosk Opening

    internal procedure GetTerminalTodaysOpeningText(POSTerminal: Record "LSC POS Terminal"): Text
    var
        CalendarMgt: Codeunit "LSC Retail Calendar Management";
        NoOpeningHours: Label 'No opening hours defined';
        RestaurantHours: Label 'Restaurant hours';
        SelfServiceKioskHours: Label 'Self Service Kiosk hours';
        OpenHoursTxt: Text;
    begin
        POSTerminal.CalcFields("Store Name");
        OpenHoursTxt := OpenHoursClosedHoursText(CalendarMgt.GetStoreCalText4Day(POSTerminal."Store No.", "LSC Retail Calendar Type"::"Self Service Kiosk", Today));
        if OpenHoursTxt <> '' then
            OpenHoursTxt := SelfServiceKioskHours + ': ' + OpenHoursTxt
        else begin
            OpenHoursTxt := OpenHoursClosedHoursText(CalendarMgt.GetStoreCalText4Day(POSTerminal."Store No.", "LSC Retail Calendar Type"::"Opening Hours", Today));
            if OpenHoursTxt <> '' then
                OpenHoursTxt := RestaurantHours + ': ' + OpenHoursTxt
            else
                OpenHoursTxt := NoOpeningHours;
        end;
        exit(OpenHoursTxt);
    end;

    local procedure OpenHoursClosedHoursText(OpenHoursText: Text): Text
    var
        Pos: Integer;
    begin
        Pos := StrPos(OpenHoursText, ';');
        if Pos = 0 then
            exit(OpenHoursText);
        OpenHoursText := CopyStr(OpenHoursText, 1, Pos - 1) + ' - ' + CopyStr(OpenHoursText, Pos + 1, StrLen(OpenHoursText) - Pos);
        exit(OpenHoursText);
    end;

    internal procedure GetTerminalOpenNow(POSTerminal: Record "LSC POS Terminal"): Boolean
    begin
        exit(POSTerminal."SSK Terminal Enabled" and KioskCalendarScheduleOpen(POSTerminal."Store No."));
    end;

    internal procedure ChangeTerminalStatus()
    var
        POSTerminal: Record "LSC POS Terminal";
        CloseTerminalTxt: Label 'Do you want to disable the %1?';
        OpenTerminalTxt: Label 'Do you want to enable the %1?';
        TerminalDoesNotExistErr: Label 'Terminal %1 does not exist';
    begin
        if not POSTerminal.Get(POSSession().TerminalNo()) then begin
            TransactionGui().PosMessage(StrSubstNo(TerminalDoesNotExistErr, POSSession().TerminalNo()));
            exit;
        end;
        if POSTerminal."SSK Terminal Enabled" then begin
            if not TransactionGui().PosConfirm(StrSubstNo(CloseTerminalTxt, POSTerminal."Terminal Type"), true) then
                exit;
        end else begin
            if not TransactionGui().PosConfirm(StrSubstNo(OpenTerminalTxt, POSTerminal."Terminal Type"), true) then
                exit;
        end;
        POSTerminal."SSK Terminal Enabled" := not POSTerminal."SSK Terminal Enabled";
        POSTerminal.Modify();
        SetTerminalStatusText(false);
    end;

    internal procedure SetTerminalStatusText(Reset: Boolean)
    var
        POSTerminal: Record "LSC POS Terminal";
        TerminalOpen: Label '%1 %2 is enabled. Press to disable.';
        TerminalClosed: Label '%1 %2 is disabled. Press to enable.';
        TerminalStatusTxt: Text;
    begin
        if Reset then begin
            POSSession().SetValue("LSC POS Tag"::Ssk_TerminalStatus, '');
            POSSession().SetValue("LSC POS Tag"::"Ssk_CalOpenHours", '');
            exit;
        end;
        POSTerminal.Get(POSSession().TerminalNo()); // Get terminal again to get the updated status
        if POSTerminal."SSK Terminal Enabled" then
            TerminalStatusTxt := StrSubstNo(TerminalOpen, POSTerminal."Terminal Type", POSTerminal."No.")
        else
            TerminalStatusTxt := StrSubstNo(TerminalClosed, POSTerminal."Terminal Type", POSTerminal."No.");
        POSSession().SetValue("LSC POS Tag"::Ssk_TerminalStatus, TerminalStatusTxt);
        POSSession().SetValue("LSC POS Tag"::"Ssk_CalOpenHours", GetTerminalTodaysOpeningText(POSTerminal));
    end;

    #endregion

    internal procedure PosSessionOnBeforeUpdateLanguageCode(var LanguageCode: Code[10])
    begin
        if POSSession().Terminal()."Terminal Type" <> "LSC POS Terminal Terminal Type"::"Self Service Kiosk" then
            exit;
        if SessionLanguageCode <> '' then
            LanguageCode := SessionLanguageCode; // Overwrite Staff/Store/Global language if SelfService lang is set
    end;

    #region events

    [IntegrationEvent(false, false)]
    local procedure OnBeforeCreateDynamicContentBufferFromHierarchy(Hierarchy: Record "LSC Hierarchy"; DefaultSalesType: Code[20]; StoreNo: Code[10]; var CreateTranslBuffer: Boolean; var ImageSize: Integer);
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforePOSMenuOffer2JSON_brickAddToJson(var JsonUtil: Codeunit "LSC POS JSON Util"; var DealDynamicContentBufferTmp: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferTmp: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferTmp2: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferTmp3: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferTmp4: Record "LSC Dynamic Content Buffer" temporary; Deal: Record "LSC Offer"; ParentMenu: Text);
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforePOSMenuRecipe2JSON_brickAddToJson(var JsonUtil: Codeunit "LSC POS JSON Util"; VAR DynamicContentBufferOriginalTmp: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferTmp: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferTmp2: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferTmp3: Record "LSC Dynamic Content Buffer" temporary; var DynamicContentBufferModGroupItemTmp: Record "LSC Dynamic Content Buffer" temporary; ParentMenu: Text);
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeGetInitialSettings(var JsonUtil: Codeunit "LSC POS JSON Util"; var SSKProfile: Record "LSC SSK Profile"; var POSFuncProfile: Record "LSC POS Func. Profile"; var Store: Record "LSC Store"; var POSTerminal: Record "LSC POS Terminal");
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeGetCrossSellsInfo(CrossSellCode: Code[20]; StoreNo: Code[10]; SalesType: Code[20]; SelectedLanguage: Code[10]; ReceiptNo: Code[20]; LineNo: Integer; CurrencyCode: Code[10]; var IsHandled: Boolean; var JsonReturnText: Text)
    begin
    end;

    #endregion

    local procedure POSSession(): Interface "LSC IPOSSession"
    begin
        exit(ServiceLocator.PosSession());
    end;

    local procedure POSFunctions(): Interface "LSC IFunctions"
    begin
        exit(ServiceLocator.POSFunctions());
    end;

    local procedure TransactionGui(): Interface "LSC ITransactionGUI"
    begin
        exit(ServiceLocator.TransactionGUI());
    end;

    local procedure PopupFunctions(): Interface "LSC IPopupFunctions"
    begin
        exit(ServiceLocator.PopupFunctions());
    end;
}