codeunit 10001398 "LSC Preaction Functions"
{
    internal procedure CreateTimestampAscendingSortViewTxt(var RecRef_p: RecordRef): Text
    var
        RecRefTmp: RecordRef;
        TimeStampField: FieldRef;
        TimestampAscendingSortViewMask: Label 'Sorting(%1) Order(Ascending)', Locked = true;
        TimestampAscendingSortViewTxt: Text;
    begin
        RecRefTmp.Open(RecRef_p.Number, true);
        TimeStampField := RecRefTmp.Field(0);
        TimestampAscendingSortViewTxt := StrSubstNo(TimestampAscendingSortViewMask, TimeStampField.Name);
        exit(TimestampAscendingSortViewTxt);
    end;

    internal procedure SetTimestampFilter(LastTimestamp: BigInteger; var RecRef_p: RecordRef)
    var
        TimeStampField: FieldRef;
    begin
        TimeStampField := RecRef_p.Field(0);
        TimeStampField.SetFilter('>%1', LastTimestamp);
    end;

    internal procedure SetTimestampFilterWithMax(LastTimestamp: BigInteger; MaxTimestamp: BigInteger; var RecRef_p: RecordRef)
    var
        TimeStampField: FieldRef;
    begin
        TimeStampField := RecRef_p.Field(0);
        TimeStampField.SetFilter('>%1&<%2', LastTimestamp, MaxTimestamp);
    end;

    internal procedure GetTimestamp(var RecRef_p: RecordRef): BigInteger
    var
        TimeStampField: FieldRef;
        Timestamp: BigInteger;
    begin
        TimeStampField := RecRef_p.Field(0);
        Timestamp := TimeStampField.Value;
        exit(Timestamp);
    end;

    internal procedure SetPrimaryFieldsAsLoadFields(var RecRef_p: RecordRef)
    var
        WebReplFunc: Codeunit "LSC Web Repl. Functions";
        TablePrimaryKeyFieldList: list of [Integer];
        FieldNo: Integer;
        FieldIndex: Integer;
    begin
        Clear(TablePrimaryKeyFieldList);
        FieldIndex := 0;
        WebReplFunc.GetTablePrimaryKeyFieldList(RecRef_p.number, TablePrimaryKeyFieldList);
        foreach FieldNo in TablePrimaryKeyFieldList do begin
            FieldIndex := FieldIndex + 1;
            if FieldIndex = 1 then
                RecRef_p.SetLoadFields(FieldNo)
            else
                RecRef_p.AddLoadFields(FieldNo);
        end;
    end;

    internal procedure FindLastTimestampForTable(TableNo: Integer): BigInteger
    var
        TimestampAscendingSortViewTxt: Text;
        RecRef: RecordRef;
        LastTimestamp: BigInteger;
    begin
        LastTimestamp := 0;
        RecRef.Open(TableNo);
        TimestampAscendingSortViewTxt := CreateTimestampAscendingSortViewTxt(RecRef);
        RecRef.SetView(TimestampAscendingSortViewTxt);
        IF RecRef.FindLast() then
            LastTimestamp := GetTimestamp(RecRef);
        RecRef.Close();
        exit(LastTimestamp);
    end;

    internal procedure FindLastDeleteEntryNoForTable(TableNo: Integer): BigInteger
    var
        DeletePreaction: Record "LSC Delete Preaction";
        LastDeleteEntryNo: Integer;
    begin
        LastDeleteEntryNo := 0;
        DeletePreaction.SetCurrentKey("Table No.");
        DeletePreaction.SetRange("Table No.", TableNo);
        IF DeletePreaction.FindLast() then
            LastDeleteEntryNo := DeletePreaction."Entry No.";
        exit(LastDeleteEntryNo);
    end;

    internal procedure FindLastDeleteEntryNo(): BigInteger
    var
        DeletePreaction: Record "LSC Delete Preaction";
        LastDeleteEntryNo: Integer;
    begin
        LastDeleteEntryNo := 0;
        IF DeletePreaction.FindLast() then
            LastDeleteEntryNo := DeletePreaction."Entry No.";
        exit(LastDeleteEntryNo);
    end;

    internal procedure IsCurrentLocationUsingPreactionTimestamp(): Boolean
    var
        RetailSetup: Record "LSC Retail Setup";
    begin
        IF not RetailSetup.get() then
            exit(false)
        else
            exit(IsDistributionLocationUsingPreactionTimestamp(RetailSetup."Distribution Location"));
    end;

    internal procedure IsDistributionLocationUsingPreactionTimestamp(DistributionLocation: Code[20]): Boolean
    var
        DistLoc: Record "LSC Distribution Location";
    begin
        IF not DistLoc.get(DistributionLocation) then
            exit(false);
        IF DistLoc."Use Preaction Timestamp" then
            exit(true)
        else
            exit(false);
    end;
}