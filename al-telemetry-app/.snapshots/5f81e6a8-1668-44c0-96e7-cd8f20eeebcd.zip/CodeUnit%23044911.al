// ************************
// Copyright Notice
// This objects content is copyright of Dynamic Manufacturing Solutions Inc 2017.  All rights reserved.
// Any redistribution or reproduction of part or all of the contents in any form is prohibited.
// ************************

/// <summary>
/// Codeunit WHI Assisted Setup (ID 23044911).
/// </summary>
codeunit 23044911 "WHI Assisted Setup"
{
    Permissions = TableData "Assisted Company Setup Status" = rimd;
    TableNo = "WHI Assisted Setup Buffer";

    trigger OnRun();
    begin
        if Rec."Setup Action" = Rec."Setup Action"::BasicConfiguration then
            DownloadConfigurationFiles(Rec."Base URL", true, false);

        if Rec."Setup Action" = Rec."Setup Action"::Translations then
            DownloadConfigurationFiles(Rec."Base URL", false, true);

        if Rec."Setup Action" = Rec."Setup Action"::Icons then
            DownloadIcons(Rec."Base URL", Rec.AppVersion);

        if Rec."Setup Action" = Rec."Setup Action"::Applications then
            DownloadApplicationXML(Rec."Base URL", Rec.AppVersion);
    end;


    /// <summary>
    /// Set the global languages list based on the supplied value.
    /// Languages will be used to download the appropriate rapidstart file.
    /// </summary>
    /// <param name="plistLanguages">The languages to install</param>
    procedure SetLanguagesToInstall(plistLanguages: List of [Text])
    begin
        listLanguages := plistLanguages;
    end;

    local procedure InsertAssistedSetup()
    var
#if V18_OR_HIGHER    
        lcuGuidedExperience: Codeunit "Guided Experience";
#endif        
        ltcTitleTxt: Label 'Set up Warehouse Insight Advanced WMS';
        ltcShortTitleTxt: Label 'Warehouse Insight Advanced WMS';
        ltcDescriptionTxt: Label 'Warehouse Insight Advanced WMS for Dynamics 365 Business Central';
        ltcHelpURLTxt: Label 'https://app.dmsiworks.com/warehouse-insight/product-help/', Locked = true; //@ExpressRemoveLine
        //ltcHelpURLTxt: Label 'https://app.dmsiworks.com/wms-express/product-help/', Locked = true; // @ExpressIncludeLine
        ltcVideoURLTxt: Label '';
    begin
#if V21_OR_HIGHER
        lcuGuidedExperience.InsertAssistedSetup(
            ltcTitleTxt,
            ltcShortTitleTxt,
            ltcDescriptionTxt,
            15,
            ObjectType::Page,
            Page::"WHI Setup Wizard",
            "Assisted Setup Group"::IWX,
            ltcVideoURLTxt,
            "Video Category"::GettingStarted,
            ltcHelpURLTxt,
            true    // IsPrimarySetup
        );
#elif V18_OR_HIGHER
        lcuGuidedExperience.InsertAssistedSetup(
            ltcTitleTxt,
            ltcShortTitleTxt,
            ltcDescriptionTxt,
            15,
            ObjectType::Page,
            Page::"WHI Setup Wizard",
            "Assisted Setup Group"::IWX,
            ltcVideoURLTxt,
            "Video Category"::GettingStarted,
            ltcHelpURLTxt
        );
#endif
    end;


#if V18_OR_HIGHER
    local procedure CreateAssistedSetupEntry()
    var
        lcuGuidedExperience: Codeunit "Guided Experience";

        lbCompleted: Boolean;
    begin
        lbCompleted := false;
        if lcuGuidedExperience.Exists("Guided Experience Type"::"Assisted Setup", ObjectType::Page, Page::"WHI Setup Wizard") then begin
            lbCompleted := lcuGuidedExperience.IsAssistedSetupComplete(ObjectType::Page, Page::"WHI Setup Wizard");
            lcuGuidedExperience.Remove("Guided Experience Type"::"Assisted Setup", ObjectType::Page, Page::"WHI Setup Wizard");
        end;

        InsertAssistedSetup();

        if lbCompleted then
            lcuGuidedExperience.CompleteAssistedSetup(ObjectType::Page, Page::"WHI Setup Wizard");
    end;

    /// <summary>
    /// Set our extension up for assisted setup
    /// </summary>
    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Guided Experience", 'OnRegisterAssistedSetup', '', true, true)]
    local procedure OnRegisterAssistedSetup();
    var
        lcuGuidedExperience: Codeunit "Guided Experience";
        leGuidedExperienceType: Enum "Guided Experience Type";
    begin
        if not lcuGuidedExperience.Exists(leGuidedExperienceType::"Manual Setup", ObjectType::Page, Page::"WHI Setup Wizard") then
            CreateAssistedSetupEntry();
    end;

    /// <summary>
    /// Set our extension up for assisted setup
    /// </summary>
    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Guided Experience", 'OnRegisterManualSetup', '', true, true)]

    local procedure OnRegisterManualSetup();
    var
        lrecSetup: Record "WHI Setup";
    begin

        if (not lrecSetup.GET()) then
            lrecSetup.Insert(false);

        CreateAssistedSetupEntry();
    end;
#elif V15_OR_HIGHER

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Assisted Setup", 'OnRegister', '', true, true)]
    local procedure HandleD365OnRegisterAssistedSetup();
    begin
        V15ToV17HandleD365OnRegisterAssistedSetup();
    end;





    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Manual Setup", 'OnRegisterManualSetup', '', true, true)]
    local procedure HandleD365OnRegisterBusinessSetup();
    var
        lrecSetup: Record "WHI Setup";
        lcuManualSetup: Codeunit "Manual Setup";
        lenumManualSetupCat: Enum "Manual Setup Category";
    begin

        if (not lrecSetup.GET()) then
            lrecSetup.INSERT(false);

        lcuManualSetup.Insert(
            tcSetUpAssistantNameLbl,
            tcAssistedSetupDescLbl,
            'Warehouse Insight Advanced WMS,Insight Works,WMS,Barcoding',
            PAGE::"WHI Setup",
            cuRegistrationMgmt.GetProductID(),
            lenumManualSetupCat::Uncategorized
        );
    end;
#endif

#if V18_OR_HIGHER
    // do nothing
#elif V16_OR_HIGHER
    local procedure V15ToV17HandleD365OnRegisterAssistedSetup()
    var
        lcuAssistedSetup: Codeunit "Assisted Setup";
        lenumGroup: Enum "Assisted Setup Group";
    begin 
        if not lcuAssistedSetup.Exists(Page::"WHI Setup Wizard") then
            lcuAssistedSetup.Add(
                cuRegistrationMgmt.GetProductID(),
                Page::"WHI Setup Wizard",
                tcSetUpAssistantNameLbl,
                lenumGroup::IWX
            );
    end;
#elif V15_OR_HIGHER
    local procedure V15ToV17HandleD365OnRegisterAssistedSetup()
    var
        lcuAssistedSetup: Codeunit "Assisted Setup";
        lenumGroup: Enum "Assisted Setup Group";
    begin
        if not lcuAssistedSetup.Exists(cuRegistrationMgmt.GetProductID(), Page::"WHI Setup Wizard") then
            lcuAssistedSetup.Add(
                cuRegistrationMgmt.GetProductID(),
                Page::"WHI Setup Wizard",
                tcSetUpAssistantNameLbl,
                lenumGroup::IWX
            );
    end;
#endif

    /// <summary>
    /// Acquires current registration information and puts up a notification if required
    /// </summary>
    local procedure RunRegCheckNotification();
    var
        lrecSetup: Record "WHI Setup";
        lrecRegistrationLine: Record "IWX Registration Line";
        lcuRegistration: Codeunit "IWX Registration";
    begin
        if not lrecSetup.WritePermission() or not lrecSetup.ReadPermission()
        or not lrecRegistrationLine.WritePermission() or not lrecRegistrationLine.ReadPermission() then
            exit
        else begin
            if not lrecSetup.Get() then begin
                lrecSetup.Init();
                lrecSetup.Insert(true);
            end;

            if lrecSetup."Wizard State" = lrecSetup."Wizard State"::Incomplete then
                CreateActionNotification(tcWizardLbl, tcStartLbl, Codeunit::"WHI Assisted Setup", 'RunWizard', runSetupGuidTok, Codeunit::"WHI Assisted Setup", 'HideSetupNotification')
            else begin
                lcuRegistration.CheckRegistration(lrecRegistrationLine, cuRegistrationMgmt.GetProductID(), cuRegistrationMgmt.GetProductLogoURL(), false);

                // @ExpressRemoveBlockStart
                case lrecRegistrationLine.Status of
                    lrecRegistrationLine.Status::"Not Registered":
                        if lrecRegistrationLine."Expiry Date" < CalcDate('<+2d>', Today()) then
                            CreateActionNotification(tcExpiryThresholdMsg, tcContactLbl, Codeunit::"WHI Assisted Setup", 'HandleAction', expiryThresholdGuidTok, Codeunit::"WHI Assisted Setup", 'HideExpiryNotification')
                        else
                            CreateActionNotification(tcNotRegisteredMsg, tcContactLbl, Codeunit::"WHI Assisted Setup", 'HandleAction', notRegisteredGuidTok, Codeunit::"WHI Assisted Setup", 'HideNotRegisteredNotification');
                    lrecRegistrationLine.Status::Registered:
                        if lrecRegistrationLine."Expiry Date" < CalcDate('<+2d>', Today()) then
                            CreateActionNotification(tcExpiryThresholdMsg, tcContactLbl, Codeunit::"WHI Assisted Setup", 'HandleAction', expiryThresholdGuidTok, Codeunit::"WHI Assisted Setup", 'HideExpiryNotification');
                    lrecRegistrationLine.Status::Blocked:
                        CreateActionNotification(tcBlockedErr, tcContactLbl, Codeunit::"WHI Assisted Setup", 'HandleAction', blockedGuidTok, Codeunit::"WHI Assisted Setup", 'HideBlockedNotification');
                end;
                // @ExpressRemoveBlockEnd
            end;
        end;
    end;

    /// <summary>
    /// Creates and sends a message to the local scope based on the provided string and action parameters
    /// Local scope = the page the user is currently on
    /// </summary>
    /// <param name="ptxtMessage"></param>
    /// <param name="ptxtActionMessage"></param>
    /// <param name="piCodeunit"></param>
    /// <param name="ptxtFunction"></param>
    /// <param name="pgID"></param>
    /// <param name="piDontShowAgainCodeunit"></param>
    /// <param name="ptxtDontShowAgainFunction"></param>
    local procedure CreateActionNotification(ptxtMessage: Text; ptxtActionMessage: Text; piCodeunit: Integer; ptxtFunction: Text; pgID: Guid; piDontShowAgainCodeunit: Integer; ptxtDontShowAgainFunction: Text)
    var
        lrecMyNotifications: Record "My Notifications";
        lnNotify: Notification;
        ltcDontShowAgainLbl: Label 'Don''t show this again.';
    begin

        if (not lrecMyNotifications.IsEnabled(pgID)) then
            exit;

        lnNotify.Message(ptxtMessage);
        lnNotify.AddAction(ptxtActionMessage, piCodeunit, ptxtFunction);

        if piDontShowAgainCodeunit > 0 then
            lnNotify.AddAction(ltcDontShowAgainLbl, piDontShowAgainCodeunit, ptxtDontShowAgainFunction);

        lnNotify.Scope := NotificationScope::LocalScope;
        lnNotify.SetData('origin', ptxtMessage);
        lnNotify.Id := pgID;
        lnNotify.Send();
    end;

    /// <summary>
    /// 
    /// </summary>
    /// <param name="pnNotification"></param>
    procedure HandleAction(pnNotification: Notification)
    var
        lcuRegistration: Codeunit "IWX Registration";
    begin
        lcuRegistration.RequestRegistration(pnNotification.GetData('origin'));
    end;


    local procedure HideNotification(notif: Notification; notificationName: Text[128]; notificationDescription: Text)
    var
        myNotifications: Record "My Notifications";
    begin
        if (not myNotifications.Disable(notif.Id())) then
            myNotifications.InsertDefault(notif.Id(), notificationName, notificationDescription, false);
    end;

    /// <summary>
    /// Hides the upgrade data notification.
    /// </summary>
    /// <param name="pnNotification"></param>
#if V15_OR_HIGHER
    internal
#endif
    procedure HideDataUpgradeNotification(pnNotification: Notification)
    var
        ltcNotificationNameTxt: Label 'Warehouse Insight Advanced WMS: Notify the user of data upgrade.';
        ltcNotificationDescrTxt: Label 'Show a notification when a data upgrade is required due to a newer version being installed.';
    begin
        HideNotification(pnNotification, ltcNotificationNameTxt, ltcNotificationDescrTxt);
    end;


    /// <summary>
    /// Hides the expiry notification.
    /// </summary>
    /// <param name="pnNotification"></param>
#if V15_OR_HIGHER
    internal
#endif
    procedure HideExpiryNotification(pnNotification: Notification)
    var
        ltcNotificationNameTxt: Label 'Warehouse Insight Advanced WMS: Notify the user of pending license expiration.';
        ltcNotificationDescrTxt: Label 'Show a notification when the license is close to expiring or has expired.';
    begin
        HideNotification(pnNotification, ltcNotificationNameTxt, ltcNotificationDescrTxt);
    end;

    /// <summary>
    /// Hides the setup notification.
    /// </summary>
    /// <param name="pnNotification"></param>
#if V15_OR_HIGHER
    internal
#endif
    procedure HideSetupNotification(pnNotification: Notification)
    var
        ltcNotificationNameTxt: Label 'Warehouse Insight Advanced WMS: Notify the user of assisted setup required.';
        ltcNotificationDescrTxt: Label 'Show a notification when the assisted setup has not been completed.';
    begin
        HideNotification(pnNotification, ltcNotificationNameTxt, ltcNotificationDescrTxt);
    end;

    /// <summary>
    /// Hides the not registered/demo notification.
    /// </summary>
    /// <param name="pnNotification"></param>
#if V15_OR_HIGHER
    internal
#endif
    procedure HideNotRegisteredNotification(pnNotification: Notification)
    var
        ltcNotificationNameTxt: Label 'Warehouse Insight Advanced WMS: Notify the user of demo account.';
        ltcNotificationDescrTxt: Label 'Show a notification when the license has not been registered and is running in demonstration mode.';
    begin
        HideNotification(pnNotification, ltcNotificationNameTxt, ltcNotificationDescrTxt);
    end;


    /// <summary>
    /// Hides the blocked notification.
    /// </summary>
    /// <param name="pnNotification"></param>
#if V15_OR_HIGHER
    internal
#endif
    procedure HideBlockedNotification(pnNotification: Notification)
    var
        ltcNotificationNameTxt: Label 'Warehouse Insight Advanced WMS: Notify the user of blocked account.';
        ltcNotificationDescrTxt: Label 'Show a notification when the license has registratioon has been set to blocked.';
    begin
        HideNotification(pnNotification, ltcNotificationNameTxt, ltcNotificationDescrTxt);
    end;




    /// <summary>
    /// Run the setup wizard.
    /// </summary>
    /// <param name="pnNotification"></param>
    procedure RunWizard(pnNotification: Notification)
    var
        lpgWizard: Page "WHI Setup Wizard";
    begin
        lpgWizard.Run();
    end;


    [EventSubscriber(ObjectType::Page, Page::"O365 Activities", 'OnOpenPageEvent', '', false, false)]
    local procedure HandlePageO365ActivitiesOnOpenPage(var Rec: Record "Activities Cue");
    begin
        RunRegCheckNotification();
        CheckUpdateRequiredNotification();
    end;


    [EventSubscriber(ObjectType::Page, Page::"Shop Supervisor Activities", 'OnOpenPageEvent', '', false, false)]
    local procedure HandlePageShopSupervisorActivitiesOnOpenPage(var Rec: Record "Manufacturing Cue");
    begin
        RunRegCheckNotification();
        CheckUpdateRequiredNotification();
    end;

#if V17_OR_HIGHER
    [EventSubscriber(ObjectType::Page, Page::"Approvals Activities", 'OnOpenPageEvent', '', false, false)]
    local procedure HandleApprovalActivitiesPartOnOpenPage(var Rec: Record "Approvals Activities Cue");
    begin
        RunRegCheckNotification();
        CheckUpdateRequiredNotification();
    end;

    [EventSubscriber(ObjectType::Page, Page::"Email Activities", 'OnOpenPageEvent', '', false, false)]
    local procedure HandleEmailActivitiesPartOnOpenPage();
    begin
        RunRegCheckNotification();
        CheckUpdateRequiredNotification();
    end;
#endif

    [EventSubscriber(ObjectType::Page, Page::"My Customers", 'OnOpenPageEvent', '', false, false)]
    local procedure HandleMyCustomersPartOnOpenPage(var Rec: Record "My Customer");
    begin
        RunRegCheckNotification();
        CheckUpdateRequiredNotification();
    end;

    [EventSubscriber(ObjectType::Page, Page::"My Items", 'OnOpenPageEvent', '', false, false)]
    local procedure HandleMyItemsPartOnOpenPage(var Rec: Record "My Item");
    begin
        RunRegCheckNotification();
        CheckUpdateRequiredNotification();
    end;

    local procedure DownloadConfigurationFiles(psBaseURL: Text; pbApplySetup: Boolean; pbApplyTranslations: Boolean)
    var
        ldlgProgress: Dialog;
        lsURL: Text;
        ltcRapidStartProgressMsg: Label 'Applying configuration data.  This will take a few minutes...';
        ltcBasicConfigLbl: Label 'Basic Configuration';
        ltcTranslationConfigLbl: Label 'Translations';
    begin
        if (not pbApplySetup) and (not pbApplyTranslations) then
            exit;

        lsURL := psBaseURL + '/data/';

        IF GUIALLOWED() then
            ldlgProgress.Open(ltcRapidStartProgressMsg);

        if pbApplySetup then begin
            DownloadAndApplyConfigurationFile(lsURL + 'base_setup.txt', ltcBasicConfigLbl);
            DownloadAndApplyConfigurationFile(lsURL + 'whi_setup.txt', ltcBasicConfigLbl);  // @ExpressRemoveLine
            //DownloadAndApplyConfigurationFile(lsURL + 'whx_setup.txt', ltcBasicConfigLbl); // @ExpressIncludeLine

#if V18_OR_HIGHER
            DownloadAndApplyConfigurationFile(lsURL + 'whi_v18_or_higher_setup.txt', ltcBasicConfigLbl);  // @ExpressRemoveLine
            //DownloadAndApplyConfigurationFile(lsURL + 'whx_v18_or_higher_setup.txt', ltcBasicConfigLbl); // @ExpressIncludeLine
#endif


#if V17_OR_HIGHER
            DownloadAndApplyConfigurationFile(lsURL + 'base_v17_or_higher_setup.txt', ltcBasicConfigLbl);
#else
            DownloadAndApplyConfigurationFile(lsURL + 'base_v16_or_lower_setup.txt', ltcBasicConfigLbl);
#endif

#if V18_OR_HIGHER
            DownloadAndApplyConfigurationFile(lsURL + 'base_v18_or_higher_setup.txt', ltcBasicConfigLbl);
#endif
        end;

#pragma warning disable AA0005
        if pbApplyTranslations then begin
            DownloadAndApplyConfigurationFile(lsURL + 'base_translations.txt', ltcTranslationConfigLbl);
            //DownloadAndApplyConfigurationFile(lsURL + 'whx_translations.txt', ltcTranslationConfigLbl); // @ExpressIncludeLine
        end;
#pragma warning restore AA0005        

        if GUIALLOWED() then
            ldlgProgress.Close();
    end;

    local procedure DownloadAndApplyConfigurationFile(ptxtPath: Text; psDescription: Text)
    var
        lxpUniversalXMLPort: XmlPort "WHI Universal Import";
        client: HttpClient;
        response: HttpResponseMessage;
        configStream: InStream;
    begin
        client.Get(ptxtPath, response);
        if (response.Content.ReadAs(configStream)) then begin
            lxpUniversalXMLPort.SetParams(
                psDescription,          // file name/description
                0,                      // table id
                true,                   // allow inserts
                true,                   // allow updates
                0,                      // validate options (0 = only ones with *)
                false,                  // run oninsert
                false,                  // run onmodify
                true,                   // disable change log
                TextEncoding::UTF8,     // text encoding
                1,                      // Field Action (1=IgnoreAll)
                0,                      // Delimiter Handling (0=RemoveQuotes)
                true                    // Hide Interaction Messages
            );

            lxpUniversalXMLPort.SetSource(configStream);
            lxpUniversalXMLPort.Import();
        end;
    end;


    /// <summary>
    /// Wrapper for downloading the rapidstart files and applying them.
    /// </summary>
    /// <param name="psBaseURL">The base URL to download from.</param>
#if V15_OR_HIGHER
    procedure DownloadRapidStartFiles(psBaseURL: Text)
    begin
        DownloadRapidStartFiles(psBaseURL, true);
    end;
#endif

    /// <summary>
    /// Download and apply the rapidstart files.
    /// </summary>
    /// <param name="psBaseURL">The base URL to download from.</param>
    /// <param name="pbApplySetup">True if the setup file should be also downloaded.</param>
#if V15_OR_HIGHER
    procedure DownloadRapidStartFiles(psBaseURL: Text; pbApplySetup: Boolean)
    var
        ldlgProgress: Dialog;
        lsURL: Text;
        lsLanguage: Text;
        ltcRapidStartProgressMsg: Label 'Applying RapidStart configuration data.  This will take a few minutes...';
    begin
        lsURL := psBaseURL + '/rapidstart/';

        IF GUIALLOWED() then
            ldlgProgress.Open(ltcRapidStartProgressMsg);

        if pbApplySetup then
            ApplyRapidstart(lsURL + 'whi_setup.rapidstart');

        ApplyRapidstart(lsURL + 'whi_translation_keys.rapidstart');

        foreach lsLanguage in listLanguages do
            ApplyRapidStart(lsURL + 'whi_translation_' + LowerCase(lsLanguage) + '.rapidstart');

        IF GUIALLOWED() then
            ldlgProgress.Close();
    end;
#endif


    /// <summary>
    /// Downloads the application icons.
    /// Icons downloaded will be based on the icon name contained in the icon table.
    /// </summary>
    /// <param name="psBaseURL"></param>
    /// <param name="psVersion"></param>
    procedure DownloadIcons(psBaseURL: Text; psVersion: Text)
    var
        lrecIcon: Record "WHI Icon";
        lsURL: Text;
    begin
        lsURL := psBaseURL + '/icons';

        lrecIcon.SetFilter("Deployment Tag", '%1|%2', 'WHI', 'WHX');
        if lrecIcon.FINDSET(FALSE) then
            repeat
                ImportIcon(lsURL, lrecIcon.Code, psVersion, true);
            until lrecIcon.Next() = 0;
    end;


    /// <summary>
    /// Download and import the icon.
    /// </summary>
    /// <param name="psURL">The url to donwload from.</param>
    /// <param name="pcodIconCode">The icon code.</param>
    /// <param name="psVersion">The version.</param>
    /// <param name="pbOverride">True if the data should be overwritten.</param>
    procedure ImportIcon(psURL: Text; pcodIconCode: Code[20]; psVersion: Text; pbOverride: Boolean)
    var
        lrecIcon: Record "WHI Icon";
#if V15_OR_HIGHER
        lcuTempBlob: Codeunit "Temp Blob";
#else
        lcuTempBlob: Codeunit "IWX Temp Blob";
#endif
        lsFileName: Text;
        lisInStream: InStream;
        losOutStream: OutStream;
    begin
        if lrecIcon.GET(pcodIconCode) then begin
            lrecIcon.CalcFields(Image);
            if lrecIcon.Image.HasValue() and (NOT pbOverride) then
                exit;

#pragma warning disable AA0217
            lsFileName := StrSubstNo('%1/%2.png', psURL, LowerCase(lrecIcon.Code));
#pragma warning restore AA0217

            // will swallow any errors that occur in the download process
            if cuCommonFunctions.TryDownloadFromUrl(lsFileName, lcuTempBlob) then
                if lcuTempBlob.HasValue() then begin
                    lcuTempBlob.CreateInStream(lisInstream);
                    lrecIcon.Image.CreateOutStream(losOutStream);
                    CopyStream(losOutStream, lisInStream);
                    lrecIcon."Deployment Version" := CopyStr(psVersion, 1, MaxStrLen(lrecIcon."Deployment Version"));
                    lrecIcon.Modify();
                end;
        end;
    end;


    /// <summary>
    /// Downloads the application xml.
    /// Applications downloaded will be based on the application name contained in the app table.
    /// </summary>
    /// <param name="psBaseURL"></param>
    /// <param name="psVersion"></param>
    procedure DownloadApplicationXML(psBaseURL: Text; psVersion: Text)
    var
        lrecApplication: Record "WHI Application";
        lsURL: Text;
    begin
        lsURL := psBaseURL + '/xml';

        lrecApplication.SetFilter("Deployment Tag", '%1|%2', 'WHI', 'WHX');
        if lrecApplication.FINDSET(FALSE) then
            repeat
                ImportXML(lsURL, lrecApplication.Code, psVersion, true);
            until lrecApplication.Next() = 0;
    end;

    /// <summary>
    /// Download and import the applicaiton xml.
    /// </summary>
    /// <param name="psURL">The url to donwload from.</param>
    /// <param name="pcodApplicationCode">The application code.</param>
    /// <param name="psVersion">The version.</param>
    /// <param name="pbOverride">True if the data should be overwritten.</param>
    procedure ImportXML(psURL: Text; pcodApplicationCode: Code[20]; psVersion: Text; pbOverride: Boolean)
    var
        lrecApplication: Record "WHI Application";
#if V15_OR_HIGHER
        lcuTempBlob: Codeunit "Temp Blob";
#else
        lcuTempBlob: Codeunit "IWX Temp Blob";
#endif
        lsFileName: Text;
        lisInStream: InStream;
        losOutStream: OutStream;
    begin
        if lrecApplication.GET(pcodApplicationCode) then begin
            lrecApplication.CalcFields("Application Blob");
            if lrecApplication."Application Blob".HasValue() and (NOT pbOverride) then
                exit;
#pragma warning disable AA0217
            lsFileName := StrSubstNo('%1/%2.xml', psURL, LowerCase(lrecApplication.Code));
#pragma warning restore AA0217

            // will swallow any errors that occur in the download process
            if cuCommonFunctions.TryDownloadFromUrl(lsFileName, lcuTempBlob) then
                if lcuTempBlob.HasValue() then begin
                    lcuTempBlob.CreateInStream(lisInStream);
                    lrecApplication."Application Blob".CreateOutStream(losOutStream);
                    CopyStream(losOutStream, lisInStream);
                    lrecApplication."Deployment Version" := CopyStr(psVersion, 1, MaxStrLen(lrecApplication."Deployment Version"));
                    lrecApplication.Modify();
                end
        end;
    end;





    /// <summary>
    /// Download the .cab and .apk files and attach to the setup record.
    /// </summary>
    /// <param name="psBaseURL">The base url to download from.</param>
    procedure DownloadSoftware(psBaseURL: Text)
    begin
        DownloadAndroidAPK(psBaseURL);
        DownloadWindowsCAB(psBaseURL);
    end;

    /// <summary>
    /// Download the .apk file and attach to the setup record.
    /// </summary>
    /// <param name="psBaseURL">The base url to download from.</param>
    procedure DownloadAndroidAPK(psBaseURL: Text)
    var
        lrecWHISetup: Record "WHI Setup";
#if V15_OR_HIGHER
        lcuTempBlob: Codeunit "Temp Blob";
        lcuBase64Convert: Codeunit "Base64 Convert";
#else
        lcuTempBlob: Codeunit "IWX Temp Blob";
        lcuBase64Convert: Codeunit "IWX Base64 Convert";
#endif
        lsFileName: Text;
        lsBase64Text: Text;
        lisInStream: InStream;
        losOutStream: OutStream;
    begin
        lrecWHISetup.Get();
        lsFileName := GetAndroidSoftwareDownloadURL(psBaseURL);

        // will swallow any errors that occur in the download process
        if cuCommonFunctions.TryDownloadFromUrl(lsFileName, lcuTempBlob) then
            if lcuTempBlob.HasValue() then begin
                lrecWHISetup.CalcFields("Android APK");
                CLEAR(lrecWHISetup."Android APK");

                lcuTempBlob.CreateInStream(lisInStream);
                lsBase64Text := lcuBase64Convert.ToBase64(lisInStream);

                lrecWHISetup."Android APK".CreateOutStream(losOutStream);
                losOutStream.WriteText(lsBase64Text);
                lrecWHISetup."Android APK".CreateInStream(lisInStream);

                CopyStream(losOutStream, lisInStream);
                lrecWHISetup.Modify();
            end;
    end;

    /// <summary>
    /// Download the .cab file and attach to the setup record.
    /// </summary>
    /// <param name="psBaseURL">The base url to download from.</param>
    procedure DownloadWindowsCAB(psBaseURL: Text)
    var
        lrecWHISetup: Record "WHI Setup";
#if V15_OR_HIGHER
        lcuTempBlob: Codeunit "Temp Blob";
        lcuBase64Convert: Codeunit "Base64 Convert";
#else
        lcuTempBlob: Codeunit "IWX Temp Blob";
        lcuBase64Convert: Codeunit "IWX Base64 Convert";
#endif
        lsFileName: Text;
        lsBase64Text: Text;
        lisInStream: InStream;
        losOutStream: OutStream;
    begin
        lrecWHISetup.Get();
        lsFileName := GetWindowsSoftwareDownloadURL(psBaseURL);

        // will swallow any errors that occur in the download process
        if cuCommonFunctions.TryDownloadFromUrl(lsFileName, lcuTempBlob) then
            if lcuTempBlob.HasValue() then begin
                lrecWHISetup.CalcFields("Windows CAB");
                CLEAR(lrecWHISetup."Windows CAB");

                lcuTempBlob.CreateInStream(lisInStream);
                lsBase64Text := lcuBase64Convert.ToBase64(lisInStream);

                lrecWHISetup."Windows CAB".CreateOutStream(losOutStream);
                losOutStream.WriteText(lsBase64Text);
                lrecWHISetup."Windows CAB".CreateInStream(lisInStream);

                CopyStream(losOutStream, lisInStream);
                lrecWHISetup.Modify();
            end;
    end;

    /// <summary>
    /// Get the URL to download the .apk file.
    /// </summary>
    /// <param name="psBaseURL">The download base url.</param>
    /// <returns>The url.</returns>
    procedure GetAndroidSoftwareDownloadURL(psBaseURL: Text): Text
    var
        lsURL: Text;
    begin
        lsURL := psBaseURL + '/software/com.insightworks.warehouseinsight.apk';
        exit(lsURL);
    end;

    /// <summary>
    /// Get the URL to download the .cab file.
    /// </summary>
    /// <param name="psBaseURL">The download base url.</param>
    /// <returns>The url.</returns>
    procedure GetWindowsSoftwareDownloadURL(psBaseURL: Text): Text
    var
        lsURL: Text;
    begin
        lsURL := psBaseURL + '/software/WHI_Scanner_Install.CAB';
        exit(lsURL);
    end;

    /// <summary>
    /// Returns the Major.Minor version of the curent extension.
    /// </summary>
    /// <returns></returns>
    procedure GetMajorMinorVesionString(): Text
    var
        lModuleInfo: ModuleInfo;
        lVersion: Version;
    begin
        NavApp.GetCurrentModuleInfo(lModuleInfo);
        lVersion := lModuleInfo.AppVersion();
#pragma warning disable AA0217
        exit(STRSUBSTNO('%1.%2', lVersion.Major(), lVersion.Minor()));
#pragma warning restore AA0217
    end;

    /// <summary>
    /// Returns the users current web service key and optionally creates one.
    /// </summary>
    /// <returns></returns>
    procedure GetWebServiceKey(): Text
    var
        lrecUser: Record User;
    begin
        lrecUser.Get(UserSecurityId());
    end;

    /// <summary>
    /// Returns the web service and appends the required extra parameters.
    /// </summary>
    /// <param name="poptObjectType">The object type.</param>
    /// <param name="piObjectID">The object id.</param>
    /// <returns>The URL.</returns>
#if V15_OR_HIGHER
    procedure GetWebService(poptObjectType: Option; piObjectID: Integer): Text
    var
        ltrecWSAggregate: Record "Web Service Aggregate" temporary;
        lcuWSMgmt: Codeunit "Web Service Management";
        lsURL: Text;
        lsNewURL: Text;
        liPos: Integer;
        eClientType: Enum "Client Type";
    begin

        lsURL := '';
        lsNewURL := '';

        lcuWSMgmt.LoadRecords(ltrecWSAggregate);
        ltrecWSAggregate.SetRange("Object Type", poptObjectType);
        ltrecWSAggregate.SetRange("Object ID", piObjectID);

        IF ltrecWSAggregate.FindFirst() then begin
            lsURL := lcuWSMgmt.GetWebServiceUrl(ltrecWSAggregate, eClientType::SOAP);

            liPos := StrPos(lsURL, '/WS/');
            if liPos > 0 then begin
                lsNewURL := CopyStr(lsURL, 1, liPos + 2);
                liPos := StrPos(lsURL, '/Codeunit');
                lsNewURL := lsNewURL + '/ReplaceWithAPercentEncodedCompanyName' + CopyStr(lsURL, liPos);
            end;
        end;

        exit(lsNewURL);
    end;
#else
    procedure GetWebService(poptObjectType: Option; piObjectID: Integer): Text
    begin
        exit('https://server:7047/BC/WS/ReplaceWithAPercentEncodedCompanyName/Codeunit/WHI');
    end;
#endif

    /// <summary>
    /// Get the OData service url.
    /// </summary>
    /// <returns>The OData service url</returns>
#if V15_OR_HIGHER
    internal procedure GetODataServiceURL(): Text
    var
        ltrecWSAggregate: Record "Web Service Aggregate" temporary;
        lcuWSMgmt: Codeunit "Web Service Management";
        lsURL: Text;
        lsNewURL: Text;
        lsTenant: Text;
        liPos: Integer;
        eClientType: Enum "Client Type";
    begin
        lsURL := '';
        lsNewURL := '';

        lcuWSMgmt.LoadRecords(ltrecWSAggregate);
        ltrecWSAggregate.SetFilter("Object Type", '%1|%2', ltrecWSAggregate."Object Type"::Page, ltrecWSAggregate."Object Type"::Query);
        ltrecWSAggregate.SetRange("Published", true);
        ltrecWSAggregate.SetRange("All Tenants", true);


        if ltrecWSAggregate.FindFirst() then begin
            lsURL := lcuWSMgmt.GetWebServiceUrl(ltrecWSAggregate, eClientType::ODataV4);

            liPos := StrPos(lsURL, '/ODataV4/');
            if liPos > 0 then begin
                lsNewURL := CopyStr(lsURL, 1, liPos + 8);
                lsNewURL := lsNewURL + 'WHI_ExecuteEventJson';

                liPos := StrPos(lsURL, '?');

                if liPos > 0 then begin
                    lsTenant := CopyStr(lsURL, liPos);
                    lsTenant := lsTenant + '&company=ReplaceWithAPercentEncodedCompanyName';
                end
                else
                    lsTenant := '?company=ReplaceWithAPercentEncodedCompanyName';

                lsNewURL := lsNewURL + lsTenant;
            end;
        end;

        exit(lsNewURL);
    end;
#else
    procedure GetODataServiceURL(): Text
    begin
        exit('https://server:7048/BC/ODataV4/WHI_ExecuteEventJson?company=ReplaceWithAPercentEncodedCompanyName');
    end;
#endif
    /// <summary>
    /// Gets the url for the Warehouse Insight web service.
    /// </summary>
    /// <returns>The URL.</returns>
    procedure GetWHIWebService(): Text
    var
        ltrecWSAggregate: Record "Web Service Aggregate" temporary;
    begin
        exit(GetWebService(ltrecWSAggregate."Object Type"::Codeunit, Codeunit::"WHI Data Broker"));
    end;


    /// <summary>
    /// Update the Setup configured version to indicate the last version the data was configured for.
    /// </summary>
    /// <param name="pbSetDeviceVersion">The version to set.</param>
    procedure SetConfiguredVersion(pbSetDeviceVersion: Boolean)
    var
        lrecWHISetup: Record "WHI Setup";
    begin
        if not lrecWHISetup.Get() then begin
            lrecWHISetup.Init();
            lrecWHISetup.Insert(true);
        end;
        lrecWHISetup."Configured Version" := CopyStr(GetMajorMinorVesionString(), 1, MaxStrLen(lrecWHISetup."Configured Version"));

        if pbSetDeviceVersion then begin
            lrecWHISetup."Android Device Version" := lrecWHISetup."Configured Version";
            lrecWHISetup."Windows Device Version" := lrecWHISetup."Android Device Version";
        end;
        lrecWHISetup.Modify();
    end;
#if V15_OR_HIGHER
    internal
#endif
    procedure RegisterAICapabilities()
    var
        lcuAppWizardChatCompletion: Codeunit "WHI App. Wizard AI Completion"; // @ExpressRemoveLine
    begin
#if SAASONLY
        lcuAppWizardChatCompletion.RegisterCapability(); // @ExpressRemoveLine
#endif
    end;


    /// <summary>
    /// Determine the appropriate base url for the extension data downloads.
    /// </summary>
    /// <param name="psVersion">The extension version to download.</param>
    /// <returns>The base url to download the data from.</returns>

    procedure GetDownloadBaseURL(psVersion: Text): Text
    var
        lrecRegistrationHeader: Record "IWX Registration Header";
        lsBaseURL: Text;
        lsFolder: Text;
    begin
        lsFolder := 'releases';
        if lrecRegistrationHeader.Get() then
            if lrecRegistrationHeader."Contact E-Mail" = 'qa-testing@iworks.com' then
                lsFolder := 'qa-testing'
            else
                if lrecRegistrationHeader."Contact E-Mail" = 'development@iworks.com' then
                    lsFolder := 'development';

        lsBaseURL := 'https://app.dmsiworks.com/wp-content/uploads/endpoints/warehouse-insight/' + lsFolder + '/';   //@ExpressRemoveLine
        //lsBaseURL := 'https://app.dmsiworks.com/wp-content/uploads/endpoints/warehouse-insight/express/' + lsFolder + '/';  // @ExpressIncludeLine

        exit(lsBaseURL + psVersion);
    end;

    local procedure CheckUpdateRequiredNotification()
    var
        lrecWHISetup: Record "WHI Setup";
        lrecDeviceConfig: Record "WHI Device Configuration";
        lsVersion: Text;
    begin
        if lrecDeviceConfig.Count() > 0 then
            if (lrecWHISetup.Get()) then begin
                lsVersion := GetMajorMinorVesionString();

                if lrecWHISetup."Configured Version" <> lsVersion then
                    if lrecWHISetup."Wizard State" = lrecWHISetup."Wizard State"::Finished then
                        CreateActionNotification(
                            tcNotificationUpdateRequiredLbl,
                            tcUpdateDataLbl,
                            Codeunit::"WHI Assisted Setup",
                            'UpdateDataNotificationHandler',
                            updateDataGuidTok,
                            Codeunit::"WHI Assisted Setup",
                            'HideDataUpgradeNotification');
            end;

    end;

#if V17_OR_HIGHER
    /// <summary>
    /// Check to see if the user has data caching enabled on their device
    /// </summary>
    procedure ConfirmDataCaching()
    var
        lrecDeviceConfig: Record "WHI Device Configuration";
        lcuCommon: Codeunit "WHI Common Functions";
    begin
        lrecDeviceConfig.Reset();
        lrecDeviceConfig.SetRange(lrecDeviceConfig."Cache Data", lrecDeviceConfig."Cache Data"::No);
        if (lrecDeviceConfig.FindFirst()) then
            if Confirm(tcConfirmDeviceCacheQst) then begin
                lrecDeviceConfig.Reset();
                lrecDeviceConfig.SetRange(lrecDeviceConfig."Cache Data", lrecDeviceConfig."Cache Data"::No);
                if (lrecDeviceConfig.FindSet(true)) then
                    repeat
                        lrecDeviceConfig."Cache Data" := lrecDeviceConfig."Cache Data"::Yes;
                        lcuCommon.CreateCacheSettingEntries(lrecDeviceConfig.Code);
                        lrecDeviceConfig.Modify(true);
                    until (lrecDeviceConfig.Next() = 0);

            end;
    end;
#endif

    /// <summary>
    /// Called when the user clicks on the update data notification.
    /// </summary>
    /// <param name="pnNotification"></param>
    procedure UpdateDataNotificationHandler(pnNotification: Notification)
    begin
        UpdateInstallData();
    end;

    /// <summary>
    /// Download and apply and data required for the current version of the extension.
    /// </summary>
    procedure UpdateInstallData()
    var
        lrecWHISetup: Record "WHI Setup";
        lcuUpradeMgmt: Codeunit "WHI Upgrade Mgmt.";
        lsVersion: Text;
        lsDownloadBaseURL: Text;
    begin
        lrecWHISetup.Get();

        lsVersion := GetMajorMinorVesionString();

        if lrecWHISetup."Configured Version" = lsVersion then
            if not Confirm(StrSubstNo(tcConfirmUpdateQst, lsVersion)) then
                exit;
#if V17_OR_HIGHER
        ConfirmDataCaching();
#endif

        GetListOfLanguagesInstalled();

        lsDownloadBaseURL := GetDownloadBaseURL(lsVersion);

        NavApp.GetCurrentModuleInfo(miModuleInfo);
        lcuUpradeMgmt.UpgradeVersions();

        DownloadConfigurationFiles(lsDownloadBaseURL, false, true);
        DownloadIcons(lsDownloadBaseURL, lsVersion);
        DownloadApplicationXML(lsDownloadBaseURL, lsVersion);
        DownloadSoftware(lsDownloadBaseURL);

        SetConfiguredVersion(true);
    end;

    /// <summary>
    /// Populate the global language list with the currently installed Warehouse Insight languages
    /// </summary>
    local procedure GetListOfLanguagesInstalled()
    var
        lrecWHILanguage: Record "WHI Language";
    begin
        Clear(listLanguages);
        if lrecWHILanguage.FindSet(false) then
            repeat
                listLanguages.Add(lrecWHILanguage.Region);
            until (lrecWHILanguage.Next() = 0);
    end;

#if V18_OR_HIGHER
    /// <summary>
    /// Indicate that the assisted setup has been completed.
    /// </summary>
    procedure SetStatusComplete()
    var
        lcuGuidedExperience: Codeunit "Guided Experience";
    begin
        lcuGuidedExperience.CompleteAssistedSetup(ObjectType::Page, Page::"WHI Setup Wizard");
    end;
#elif V16_OR_HIGHER
    procedure SetStatusComplete()
    var
        lcuAssistedSetup: Codeunit "Assisted Setup";
    begin
        lcuAssistedSetup.Complete(Page::"WHI Setup Wizard");
    end;
#elif V15_OR_HIGHER
    procedure SetStatusComplete()
    var
        lcuAssistedSetup: Codeunit "Assisted Setup";
    begin
        lcuAssistedSetup.Complete(cuRegistrationMgmt.GetProductID(), Page::"WHI Setup Wizard");
    end;
#endif

    /// <summary>
    /// Download and apply the rapidstart file.
    /// </summary>
    /// <param name="ptxtPath">The URL to download the file from.</param>
#if V15_OR_HIGHER
    procedure ApplyRapidstart(ptxtPath: Text)
    var
        lcuTempBlob: Codeunit "Temp Blob";
        lcuRapidStart: Codeunit "Config. Package - Import";
    begin
        if cuCommonFunctions.TryDownloadFromUrl(ptxtPath, lcuTempBlob) then
            lcuRapidStart.ImportAndApplyRapidStartPackageStream(lcuTempBlob);
    end;
#endif


    var
        cuRegistrationMgmt: Codeunit "WHI Registration Mgmt.";
        cuCommonFunctions: Codeunit "WHI Common Functions";
        miModuleInfo: ModuleInfo;
        listLanguages: List of [Text];
        tcExpiryThresholdMsg: Label 'Warehouse Insight Advanced WMS: Your access will expire soon';
        tcNotRegisteredMsg: Label 'Warehouse Insight Advanced WMS: You currently have a demo account';
        tcBlockedErr: Label 'Warehouse Insight Advanced WMS: There is a problem with your account';
        tcContactLbl: Label 'Contact Support';
        tcWizardLbl: Label 'You have not completed the Warehouse Insight Advanced WMS setup wizard';
        tcStartLbl: Label 'Get Started';

        tcConfirmUpdateQst: Label 'The current version [%1] has already been updated.  Do you want to re-apply the update?', Comment = '%1 = Version No.';
        tcConfirmDeviceCacheQst: Label 'Do you want to enable data caching on your device? This setting can be changed within the Device Configuration page.';
        tcNotificationUpdateRequiredLbl: Label 'Warehouse Insight Advanced WMS: Additional upgrade data required.';
        tcUpdateDataLbl: Label 'Update Data';
#pragma warning disable AA0137
        tcSetUpAssistantNameLbl: Label 'Set up Warehouse Insight Advanced WMS';
        tcAssistantNameLbl: Label 'Warehouse Insight Advanced WMS';
        tcAssistedSetupDescLbl: Label 'Warehouse Insight Advanced WMS for Dynamics 365 Business Central';
#pragma warning restore AA0137

        expiryThresholdGuidTok: Label 'aad6637e-697f-41c5-94e7-d7cc6d74e3ea', Locked = true;
        blockedGuidTok: Label '0ad23d7f-183a-4a33-98a9-b471fb7a537d', Locked = true;
        notRegisteredGuidTok: Label 'f3ec85e1-65bd-47df-8361-4184d9085f71', Locked = true;
        runSetupGuidTok: Label '014d121f-fe09-4d60-a04e-1848da956247', Locked = true;
        updateDataGuidTok: Label '8a7b80a7-af01-4a8e-85fc-0cd92c8f2b61', Locked = true;
}

