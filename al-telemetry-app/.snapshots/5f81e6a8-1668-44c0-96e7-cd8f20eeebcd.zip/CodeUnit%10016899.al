codeunit 10016899 "LSC Set Client Session Variab."
{

    var
        SessionKeyValues: Codeunit "LSC Session Key Values";
        ClientSessionUtility: Codeunit "LSC Client Session Utility";

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"System Initialization", OnAfterLogin, '', false, false)]
    local procedure SetW1ClientSessionVariables()
    begin
        //W1 Version
        if ClientSessionUtility.FindLocalizedVersion() <> 'W1' then
            exit;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"System Initialization", OnAfterLogin, '', false, false)]
    local procedure SetNOClientSessionVariables()
    var
        "Key": Code[20];
        KeyValue: Text;
    begin
        //NO Version
        if ClientSessionUtility.FindLocalizedVersion() <> 'NO' then
            exit;

        Key := '#MAXCOPIES';
        KeyValue := Format(1);
        SessionKeyValues.SetValue(Key, KeyValue);

        Key := '#OPENDRAWERBLOCKSALE';
        KeyValue := 'TRUE';
        SessionKeyValues.SetValue(Key, KeyValue);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"System Initialization", OnAfterLogin, '', false, false)]
    local procedure SetSEClientSessionVariables()
    var
        "Key": Code[20];
        KeyValue: Text;
    begin
        //SE Version
        if ClientSessionUtility.FindLocalizedVersion() <> 'SE' then
            exit;

        Key := '#MAXCOPIES';
        KeyValue := Format(1);
        SessionKeyValues.SetValue(Key, KeyValue);
    end;

}

