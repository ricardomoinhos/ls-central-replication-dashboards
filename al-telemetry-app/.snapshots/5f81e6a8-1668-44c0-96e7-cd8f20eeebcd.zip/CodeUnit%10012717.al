codeunit 10012717 "LSC Control Lib. Server"
{
    Access = Internal;
    SingleInstance = true;

    var
        POSSession: Codeunit "LSC POS Session";
        _Logger: Codeunit "LSC Debug Log";
        _ContextMenuFieldList: List of [Integer];
        POSUTILS: Codeunit "LSC POS Control Utils";
        RESOURCELIB: Codeunit "LSC POS Resource Library";

    procedure UpdateMenuLine(var pMenuLineRec: Record "LSC POS Menu Line") PermissionOK: Boolean
    var
        tmpText: Text;
        posCommands: Record "LSC POS Command";
    begin
        PermissionOK := true;
        //update Disabled field from Permissions
        if PosSession.MenuPermission(pMenuLineRec, pMenuLineRec.Command, tmpText) then begin
            if not PosSession.MenuPermission(pMenuLineRec, pMenuLineRec."Post Command", tmpText) then begin
                pMenuLineRec.Disabled := true;
                PermissionOK := false;
                exit;
            end;
        end
        else begin
            pMenuLineRec.Disabled := true;
            PermissionOK := false;
            exit;
        end;

        //update skin and font from POS Command
        if posCommands.Get(pMenuLineRec.Command) then begin
            if pMenuLineRec.Skin = '' then
                pMenuLineRec.Skin := posCommands.Skin;
            if pMenuLineRec.Font = '' then
                pMenuLineRec.Font := posCommands.Font;
            if pMenuLineRec."POS Help ID" = '' then
                pMenuLineRec."POS Help ID" := posCommands."POS Help ID";
            if not pMenuLineRec.Blocking then
                pMenuLineRec.Blocking := posCommands.Blocking;
        end;
    end;

    procedure LogTrace(message: Text; dualDisp: Boolean)
    begin
        _Logger.LogTrace(message, dualDisp);
    end;

    procedure LogDebug(message: Text; dualDisp: Boolean)
    begin
        _Logger.LogDebug(message, dualDisp);
    end;

    procedure LogWarning(message: Text; dualDisp: Boolean)
    begin
        _Logger.LogWarning(message, dualDisp);
    end;

    procedure LogError(message: Text; dualDisp: Boolean)
    begin
        _Logger.LogError(message, dualDisp);
    end;

    procedure LogEvent(var pPOSEvent: Codeunit "LSC POS Event"; dualDisp: Boolean)
    begin
        _Logger.LogEvent(pPOSEvent, dualDisp);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Control Library", LogTrace, '', false, false)]
    local procedure ControlLibTrace(sender: Codeunit "LSC POS Control Library"; message: Text)
    begin
        LogTrace(message, sender.IsDualDisplay);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Control Library", LogDebug, '', false, false)]
    local procedure ControlLibDebug(sender: Codeunit "LSC POS Control Library"; message: Text)
    begin
        LogDebug(message, sender.IsDualDisplay);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Control Library", LogWarning, '', false, false)]
    local procedure ControlLibWarning(sender: Codeunit "LSC POS Control Library"; message: Text)
    begin
        LogWarning(message, sender.IsDualDisplay);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Control Library", LogError, '', false, false)]
    local procedure ControlLibError(sender: Codeunit "LSC POS Control Library"; message: Text)
    begin
        LogError(message, sender.IsDualDisplay);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Control Library", InterfaceProfileRequest, '', false, false)]
    local procedure InterfaceProfileRequest(sender: Codeunit "LSC POS Control Library"; mainProfileID: Text; storeProfileID: Text; var pProfileEntity: Record "LSC Interface Profile Entity")
    begin
        LoadInterfaceProfile(mainProfileID, storeProfileID, pProfileEntity);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Control Library", StyleProfileRequest, '', false, false)]
    local procedure StyleProfileRequest(sender: Codeunit "LSC POS Control Library"; mainProfileID: Text; storeProfileID: Text; fontIdsFilter: Text; skinIdsFilter: Text; colorIdsFilter: Text; skipDefaultResources: Boolean; var jsonUtil: Codeunit "Json Text Reader/Writer")
    begin
        //LogTrace('NoDLL.StyleRequest: ' + mainProfileID + ' - ' + storeProfileID);
        RESOURCELIB.SetMainStyleProfileID(mainProfileID);
        RESOURCELIB.SetSecondaryStyleProfileID(storeProfileID);
        RESOURCELIB.GetResourcesJson(jsonUtil, fontIdsFilter, skinIdsFilter, colorIdsFilter, skipDefaultResources);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Control Library", PanelRequest, '', false, false)]
    local procedure PanelRequest(sender: Codeunit "LSC POS Control Library"; pMainProfileID: Text; pStoreProfileID: Text; pControlID: Text; var pPanelRec: Record "LSC POS Panel Entity"; var pPanelRowColumns: Record "LSC POS Panel RowColumn Entity"; var pPanelControls: Record "LSC POS Panel Ctrl Line Entity"; var found: Boolean)
    var
        panelRec: Record "LSC POS Panel";
        panelRowColRec: Record "LSC POS Panel Row/Column";
        panelControlsRec: Record "LSC POS Panel Control Line";
        tmpImg: Text;
    begin
        LogTrace('NoDLL.PanelRequest: ' + pControlID, sender.IsDualDisplay);

        found := panelRec.Get(pMainProfileID, pControlID);
        if not found then
            found := panelRec.Get(pStoreProfileID, pControlID);
        if not found then
            found := panelRec.Get(Format("LSC POS Profile ID"::DefaultInterface), pControlID);

        if not found then
            exit;

        pPanelRec.Init();
        pPanelRec.TransferFields(panelRec, false);
        pPanelRec.ControlID := panelRec."Control ID";
        pPanelRec.ProfileID := panelRec."Interface Profile ID";
        tmpImg := sender.GetPosImage(Enum::"LSC POS Control Type"::Panel, panelRec."Control ID");
        if tmpImg = '' then
            tmpImg := GetImg(panelRec.RecordId, sender);
        pPanelRec.Img := tmpImg;
        if not pPanelRec.Insert then
            pPanelRec.Modify;

        LogTrace(StrSubstNo('NoDLL.PanelRequest Result: %1-%2', pPanelRec.ProfileID, pPanelRec.ControlID), sender.IsDualDisplay);

        pPanelRowColumns.Reset();
        pPanelRowColumns.SetRange(PanelControlID, pControlID);
        pPanelRowColumns.DeleteAll();

        panelRowColRec.SetRange("Interface Profile ID", panelRec."Interface Profile ID");
        panelRowColRec.SetRange("Panel Control ID", panelRec."Control ID");
        if panelRowColRec.Find('-') then
            repeat
                pPanelRowColumns.Init();
                pPanelRowColumns.TransferFields(panelRowColRec, true);
                if not pPanelRowColumns.Insert then
                    pPanelRowColumns.Modify;
            until panelRowColRec.Next = 0;

        pPanelControls.Reset();
        pPanelControls.SetRange(PanelControlID, pControlID);
        pPanelControls.DeleteAll();

        panelControlsRec.SetRange("Interface Profile ID", panelRec."Interface Profile ID");
        panelControlsRec.SetRange("Panel Control ID", panelRec."Control ID");
        panelControlsRec.SetFilter("Control ID", '<>%1', '');
        if panelControlsRec.Find('-') then
            repeat
                pPanelControls.Init();
                pPanelControls.TransferFields(panelControlsRec, true);
                pPanelControls.Insert;
            until panelControlsRec.Next = 0;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Control Library", MenuRequest, '', false, false)]
    local procedure MenuRequest(sender: Codeunit "LSC POS Control Library"; pMainProfileID: Text; pStoreProfileID: Text; pMenuID: Text; var pMenuRec: Record "LSC POS Menu Entity"; var pMenuButtonsRec: Record "LSC POS Menu Button Entity"; var pFound: Boolean; pOverwrite: Boolean)
    var
        menuHeaderRec: Record "LSC POS Menu Header";
        menuLinesRec: Record "LSC POS Menu Line";
        tmpImg: Text;
    begin
        LogTrace('NoDLL.MenuRequest: ' + pMenuID, sender.IsDualDisplay);

        pFound := menuHeaderRec.Get(pMainProfileID, pMenuID);
        if not pFound then
            pFound := menuHeaderRec.Get(pStoreProfileID, pMenuID);
        if not pFound then
            pFound := menuHeaderRec.Get(Format("LSC POS Profile ID"::DefaultMenu), pMenuID);

        if not pFound then
            exit;

        OnBeforeMenuLinesLoad(menuHeaderRec."Profile ID", menuHeaderRec."Menu ID", menuLinesRec);

        if pMenuRec.Get(menuHeaderRec."Profile ID", menuHeaderRec."Menu ID") then
            if not pOverwrite then begin
                LogTrace(StrSubstNo('NoDLL.MenuRequest has already loaded [%1] [%2]', menuHeaderRec."Profile ID", menuHeaderRec."Menu ID"), sender.IsDualDisplay);
                exit;
            end;

        //if pFound and (not pMenuRec.Get(menuHeaderRec."Profile ID", menuHeaderRec."Menu ID")) then begin
        LogTrace(StrSubstNo('NoDLL.MenuRequest returns [%1] [%2]', menuHeaderRec."Profile ID", menuHeaderRec."Menu ID"), sender.IsDualDisplay);
        pMenuRec.Init();
        pMenuRec.TransferFields(menuHeaderRec);
        tmpImg := sender.GetPosImage(Enum::"LSC POS Control Type"::Menu, menuHeaderRec."Menu ID");
        if tmpImg = '' then
            tmpImg := GetImg(menuHeaderRec.RecordId, sender);
        pMenuRec.Img := tmpImg;
        if not pMenuRec.Insert then
            pMenuRec.Modify;

        pMenuButtonsRec.Reset();
        pMenuButtonsRec.SetRange(ProfileID, menuHeaderRec."Profile ID");
        pMenuButtonsRec.SetRange(ControlID, menuHeaderRec."Menu ID");
        pMenuButtonsRec.DeleteAll();

        menuLinesRec.SetRange("Profile ID", menuHeaderRec."Profile ID");
        menuLinesRec.SetRange("Menu ID", menuHeaderRec."Menu ID");
        menuLinesRec.SetFilter("Key No.", '>=0');
        if menuLinesRec.Find('-') then
            repeat
                UpdateMenuLine(menuLinesRec);
                pMenuButtonsRec.Init();
                pMenuButtonsRec.TransferFields(menuLinesRec, true);
                TranslateButtonEntity(pMenuButtonsRec, POSSession.GetLanguageCode());
                tmpImg := sender.GetPosImage(Enum::"LSC POS Control Type"::MenuButton, POSUTILS.GetTextAndNumberControlID(menuLinesRec."Menu ID", menuLinesRec."Key No."));
                if tmpImg = '' then
                    tmpImg := GetImg(menuLinesRec.RecordId, sender);
                pMenuButtonsRec.Img := tmpImg;
                pMenuButtonsRec.Insert;
            //pMenuButtonsRec.Modify;
            until menuLinesRec.Next = 0;
    end;

    internal procedure GetImg(recID: RecordId; var CONTROLLIB: Codeunit "LSC POS Control Library"): Code[20];
    var
        PosImgUtils: Codeunit "LSC POS Image Utils";
    begin
        exit(PosImgUtils.GetImg(recID, CONTROLLIB));
    end;

    internal procedure LoadPlaylist(playlistID: Text; var CONTROLLIB: Codeunit "LSC POS Control Library")
    var
        PosImgUtils: Codeunit "LSC POS Image Utils";
    begin
        PosImgUtils.GetPlaylist(playlistID, CONTROLLIB);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Control Library", MenuButtonRequest, '', false, false)]
    local procedure MenuButtonRequest(sender: Codeunit "LSC POS Control Library"; pProfileID: Text; pMenuID: Text; pButtonNo: Integer; var pMenuButtonsRec: Record "LSC POS Menu Button Entity"; var pFound: Boolean)
    var
        menuLinesRec: Record "LSC POS Menu Line";
        tmpImg: Text;
    begin
        LogTrace('NoDLL.MenuButtonRequest: ' + pMenuID, sender.IsDualDisplay);

        if menuLinesRec.Get(pProfileID, pMenuID, pButtonNo) then begin
            pFound := true;
            UpdateMenuLine(menuLinesRec);
            pMenuButtonsRec.Init();
            pMenuButtonsRec.TransferFields(menuLinesRec, true);
            TranslateButtonEntity(pMenuButtonsRec, POSSession.GetLanguageCode());
            tmpImg := sender.GetPosImage(Enum::"LSC POS Control Type"::MenuButton, POSUTILS.GetTextAndNumberControlID(menuLinesRec."Menu ID", menuLinesRec."Key No."));
            if tmpImg = '' then
                tmpImg := GetImg(menuLinesRec.RecordId, sender);
            pMenuButtonsRec.Img := tmpImg;
            if not pMenuButtonsRec.Insert() then
                pMenuButtonsRec.Modify();
        end;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Control Library", ButtonPermissionRequest, '', false, false)]
    local procedure ButtonPermissionRequest(sender: Codeunit "LSC POS Control Library"; var pMenuButtonRec: Record "LSC POS Menu Button Entity"; var pBlockedButtons: List of [RecordID])
    var
        lMenuLine: Record "LSC POS Menu Line";
        tmpImg: Text;
    begin
        if pMenuButtonRec.Find('-') then
            repeat
                if lMenuLine.Get(pMenuButtonRec.ProfileID, pMenuButtonRec.ControlID, pMenuButtonRec.ButtonNo) then begin
                    if not UpdateMenuLine(lMenuLine) then begin //No Permission
                        pMenuButtonRec.TransferFields(lMenuLine);
                        tmpImg := sender.GetPosImage(Enum::"LSC POS Control Type"::MenuButton, POSUTILS.GetTextAndNumberControlID(lMenuLine."Menu ID", lMenuLine."Key No."));
                        if tmpImg = '' then
                            tmpImg := GetImg(lMenuLine.RecordId, sender);
                        pMenuButtonRec.Img := tmpImg;
                        pMenuButtonRec.Modify;
                        pBlockedButtons.Add(pMenuButtonRec.RecordId);
                    end;
                end;
            until pMenuButtonRec.Next = 0;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Control Library", ButtonPadRequest, '', false, false)]
    local procedure ButtonPadRequest(sender: Codeunit "LSC POS Control Library"; pMainProfileID: Text; pStoreProfileID: Text; pControlID: Text; var pControlRec: Record "LSC POS Button Pad Entity"; var pFound: Boolean)
    var
        controlRec: Record "LSC POS ButtonPad Control";
    begin
        LogTrace('NoDLL.ButtonPadRequest: ' + pControlID, sender.IsDualDisplay);

        pFound := controlRec.Get(pMainProfileID, pControlID);
        if not pFound then
            pFound := controlRec.Get(pStoreProfileID, pControlID);
        if not pFound then
            pFound := controlRec.Get(Format("LSC POS Profile ID"::DefaultInterface), pControlID);

        if pFound AND (not pControlRec.Get(controlRec."Interface Profile ID", controlRec."Control ID")) then begin
            LogTrace(StrSubstNo('NoDLL.ButtonPadRequest returns [%1] [%2]', controlRec."Interface Profile ID", controlRec."Control ID"), sender.IsDualDisplay);
            pControlRec.Init();
            pControlRec.TransferFields(controlRec, true);
            pControlRec.Insert();
        end;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Control Library", DataGridRequest, '', false, false)]
    local procedure DataGridRequest(sender: Codeunit "LSC POS Control Library"; pMainProfileID: Text; pStoreProfileID: Text; pControlID: Text; var pControlRec: Record "LSC POS Data Grid Entity"; var pFound: Boolean)
    var
        controlRec: Record "LSC POS Data Grid Control";
    begin
        LogTrace('NoDLL.DataGridRequest: ' + pControlID, sender.IsDualDisplay);

        pFound := controlRec.Get(pMainProfileID, pControlID);
        if not pFound then
            pFound := controlRec.Get(pStoreProfileID, pControlID);
        if not pFound then
            pFound := controlRec.Get(Format("LSC POS Profile ID"::DefaultInterface), pControlID);

        if pFound AND (not pControlRec.Get(controlRec."Interface Profile ID", controlRec."Control ID")) then begin
            LogTrace(StrSubstNo('NoDLL.DataGridRequest returns [%1] [%2]', controlRec."Interface Profile ID", controlRec."Control ID"), sender.IsDualDisplay);
            pControlRec.Init();
            pControlRec.TransferFields(controlRec, true);
            pControlRec.Insert();
        end;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Control Library", InputRequest, '', false, false)]
    local procedure InputRequest(sender: Codeunit "LSC POS Control Library"; pMainProfileID: Text; pStoreProfileID: Text; pControlID: Text; var pControlRec: Record "LSC POS Input Entity"; var pFound: Boolean)
    var
        controlRec: Record "LSC POS Input Control";
    begin
        LogTrace('NoDLL.InputRequest: ' + pControlID, sender.IsDualDisplay);

        pFound := controlRec.Get(pMainProfileID, pControlID);
        if not pFound then
            pFound := controlRec.Get(pStoreProfileID, pControlID);
        if not pFound then
            pFound := controlRec.Get(Format("LSC POS Profile ID"::DefaultInterface), pControlID);

        if pFound AND (not pControlRec.Get(controlRec."Interface Profile ID", controlRec."Control ID")) then begin
            LogTrace(StrSubstNo('NoDLL.InputRequest returns [%1] [%2]', controlRec."Interface Profile ID", controlRec."Control ID"), sender.IsDualDisplay);
            pControlRec.Init();
            pControlRec.TransferFields(controlRec, true);
            pControlRec.InputType := controlRec."Input Type" > controlRec."Input Type"::Date ? controlRec."Input Type" + 1 : controlRec."Input Type"; // This is done to match the offset in LSC ColumnType enum
            pControlRec.Insert();
        end;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Control Library", RecordZoomRequest, '', false, false)]
    local procedure RecordZoomRequest(sender: Codeunit "LSC POS Control Library"; pMainProfileID: Text; pStoreProfileID: Text; pControlID: Text; var pControlRec: Record "LSC POS Record Zoom Entity"; var pFound: Boolean)
    var
        controlRec: Record "LSC POS Record Zoom Control";
    begin
        LogTrace('NoDLL.RecordZoomRequest: ' + pControlID, sender.IsDualDisplay);

        pFound := controlRec.Get(pMainProfileID, pControlID);
        if not pFound then
            pFound := controlRec.Get(pStoreProfileID, pControlID);
        if not pFound then
            pFound := controlRec.Get(Format("LSC POS Profile ID"::DefaultInterface), pControlID);

        if pFound AND (not pControlRec.Get(controlRec."Interface Profile ID", controlRec."Control ID")) then begin
            LogTrace(StrSubstNo('NoDLL.RecordZoomRequest returns [%1] [%2]', controlRec."Interface Profile ID", controlRec."Control ID"), sender.IsDualDisplay);
            pControlRec.Init();
            pControlRec.TransferFields(controlRec, true);
            pControlRec.Insert();
        end;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Control Library", BrowserRequest, '', false, false)]
    local procedure BrowserRequest(sender: Codeunit "LSC POS Control Library"; pMainProfileID: Text; pStoreProfileID: Text; pControlID: Text; var pControlRec: Record "LSC POS Browser Entity"; var pFound: Boolean)
    var
        controlRec: Record "LSC POS Browser Control";
    begin
        LogTrace('NoDLL.BrowserRequest: ' + pControlID, sender.IsDualDisplay);

        pFound := controlRec.Get(pMainProfileID, pControlID);
        if not pFound then
            pFound := controlRec.Get(pStoreProfileID, pControlID);
        if not pFound then
            pFound := controlRec.Get(Format("LSC POS Profile ID"::DefaultInterface), pControlID);

        if pFound AND (not pControlRec.Get(controlRec."Interface Profile ID", controlRec."Control ID")) then begin
            LogTrace(StrSubstNo('NoDLL.BrowserRequest returns [%1] [%2]', controlRec."Interface Profile ID", controlRec."Control ID"), sender.IsDualDisplay);
            pControlRec.Init();
            pControlRec.TransferFields(controlRec, true);
            pControlRec.Insert();
        end;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Control Library", MediaRequest, '', false, false)]
    local procedure MediaRequest(sender: Codeunit "LSC POS Control Library"; pMainProfileID: Text; pStoreProfileID: Text; pControlID: Text; var pControlRec: Record "LSC POS Media Entity"; var pFound: Boolean)
    var
        controlRec: Record "LSC POS Media Control";
        tmpImg: Text;
    begin
        LogTrace('NoDLL.MediaRequest: ' + pControlID, sender.IsDualDisplay);

        pFound := controlRec.Get(pMainProfileID, pControlID);
        if not pFound then
            pFound := controlRec.Get(pStoreProfileID, pControlID);
        if not pFound then
            pFound := controlRec.Get(Format("LSC POS Profile ID"::DefaultInterface), pControlID);

        if pFound AND (not pControlRec.Get(controlRec."Interface Profile ID", controlRec."Control ID")) then begin
            LogTrace(StrSubstNo('NoDLL.MediaRequest returns [%1] [%2]', controlRec."Interface Profile ID", controlRec."Control ID"), sender.IsDualDisplay);
            pControlRec.Init();
            pControlRec.TransferFields(controlRec, true);
            if controlRec.Playlist <> '' then begin
                LoadPlaylist(controlRec.Playlist, sender);
                pControlRec.Img := '';
            end else begin
                tmpImg := sender.GetPosImage(Enum::"LSC POS Control Type"::"Media", controlRec."Control ID");
                if tmpImg = '' then
                    tmpImg := GetImg(controlRec.RecordId, sender);
                pControlRec.Img := tmpImg;
            end;
            pControlRec.Insert();
        end;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Control Library", ContextMenuRequest, '', false, false)]
    local procedure ContextMenuRequest(sender: Codeunit "LSC POS Control Library"; filterText: Text; var jsonUtil: Codeunit "Json Text Reader/Writer")
    var
        ContextMenu: Record "LSC POS Context Menu Line";
    begin
        LogTrace('NoDLL.ContextMenuRequest: ' + filterText, sender.IsDualDisplay);
        if ContextMenu.IsEmpty then
            exit;
        JSONUtil.WriteStartObject(Format("LSC POS String Request Type"::ContextMenus));
        if ContextMenu.FindSet() then
            repeat
                jsonUtil.WriteStartObject(POSUtils.GetTextAndNumberControlID(FORMAT(ContextMenu."Context Menu ID"), ContextMenu."Line No."));
                if ContextMenu."Display Text" <> '' then
                    jsonUtil.WriteStringProperty('t', ContextMenu."Display Text");
                if ContextMenu.Command <> '' then
                    jsonUtil.WriteStringProperty('c', ContextMenu.Command);
                if ContextMenu.Parameter <> '' then
                    jsonUtil.WriteStringProperty('p', ContextMenu.Parameter);
                if ContextMenu."Indent Level" <> 0 then
                    jsonUtil.WriteStringProperty('i', ContextMenu."Indent Level");
                jsonUtil.WriteEndObject();
            until ContextMenu.Next() = 0;
        JSONUtil.WriteEndObject();
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Control Library", KeyCommandRequest, '', false, false)]
    local procedure KeyCommandRequest(sender: Codeunit "LSC POS Control Library"; filterText: Text; var jsonUtil: Codeunit "Json Text Reader/Writer")
    var
        r: Record "LSC POS Key Command";
        RequiresFixedMenu: Boolean;
        OptionAsInt: Integer;
    begin
        if filterText = '' then
            filterText := POSSession.HardwareProfileID;
        LogTrace('NoDLL.KeyCommandRequest: ' + filterText, sender.IsDualDisplay);
        r.SetFilter("Profile ID", filterText);
        if r.IsEmpty then
            exit;
        JSONUtil.WriteStartObject(Format("LSC POS String Request Type"::KeyCommands));

        // Note, Pre-26: JSONUtil.WriteStringProperty(StrSubstNo('%1|%2|%3|%4', r."Key Code", B2I(r.Shift), B2I(r.Ctrl), B2I(r.Alt)), StrSubstNo('%1|||%2|||%3|||%4', r."POS Command", r.Parameter, Format(r."Key Type", 0, 9), r."Key No."));

        if r.Find('-') then
            repeat
                jsonUtil.WriteStartObject(StrSubstNo('%1,%2,%3,%4', r."Key Code", B2I(r.Shift), B2I(r.Ctrl), B2I(r.Alt)));

                // Note: Sending compressed + minimal info to deduct what the keycommand should do:
                case r."Key Type" of
                    r."Key Type"::"Menu Key",
                    r."Key Type"::"Fixed Key":
                        begin
                            jsonUtil.WriteNumberProperty('n', r."Key No.");
                            RequiresFixedMenu := true;
                        end;
                    r."Key Type"::"POS Command":
                        begin
                            jsonUtil.WriteStringProperty('c', r."POS Command");
                            if r.Parameter <> '' then
                                jsonUtil.WriteStringProperty('p', r.Parameter);
                        end;
                end;
                if r."Key Type" in [
                    r."Key Type"::"Fixed Key",
                    r."Key Type"::"Scanner Wedge",
                    r."Key Type"::"MSR Wedge"
                ] then begin
                    OptionAsInt := r."Key Type";
                    jsonUtil.WriteNumberProperty('t', OptionAsInt);
                end;

                jsonUtil.WriteEndObject();
            until r.Next = 0;
        JSONUtil.WriteEndObject();

        if RequiresFixedMenu then
            sender.RefreshMenu(Format("LSC POS Menu Id"::"FIXED"));
    end;

    local procedure B2I(b: Boolean): Integer
    begin
        if b then
            exit(1);
        exit(0);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Control Library", ButtonTranslationRequest, '', false, false)]
    local procedure ButtonTranslationRequest(sender: Codeunit "LSC POS Control Library"; pLanguageID: Text; var pMenuButtonRec: Record "LSC POS Menu Button Entity"; var pTranslatedButtons: List of [RecordID])
    begin
        if pMenuButtonRec.Find('-') then
            repeat
                if TranslateButtonEntity(pMenuButtonRec, pLanguageID) then begin
                    pMenuButtonRec.Modify;
                    pTranslatedButtons.Add(pMenuButtonRec.RecordId);
                end;
            until pMenuButtonRec.Next = 0;
    end;

    local procedure TranslateButtonEntity(var pMenuButtonEntity: Record "LSC POS Menu Button Entity"; pLanguageID: Text) TranslationFound: Boolean
    var
        btnTrans: Record "LSC POS Button Translation";
        btnCommandAccents: Record "LSC POS Button Parameters";
    begin
        if pLanguageID <> '' then
            if pLanguageID <> 'ENU' then // DefaultLanguage
                if btnTrans.Get(pMenuButtonEntity.ProfileID, pMenuButtonEntity.ControlID, pMenuButtonEntity.ButtonNo, pLanguageID) then begin
                    TranslationFound := btnTrans.Description <> '';
                    if TranslationFound then
                        pMenuButtonEntity.Description := btnTrans.Description;
                end;

        if pMenuButtonEntity.Command = Format(Enum::"LSC POS Command"::ALPHANUM_K) then
            if btnCommandAccents.Get(pMenuButtonEntity.ProfileID, pMenuButtonEntity.ControlID, pMenuButtonEntity.ButtonNo, pMenuButtonEntity.Command, 'ACCENTS') then
                pMenuButtonEntity.Accents := btnCommandAccents."Parameter Value";
    end;

    local procedure LoadInterfaceProfile(interfaceProfileID: Text; storeInterfaceProfileID: Text; var pProfileEntity: Record "LSC Interface Profile Entity")
    var
        InterfaceProfileRec: Record "LSC POS Interface Profile";
        SecondaryInterfaceProfileRec: Record "LSC POS Interface Profile";
        DefaultInterfaceProfileRec: Record "LSC POS Interface Profile";
        RecRef: RecordRef;
        FieldVal: Text;
        FieldNo: Integer;
    begin
        if _ContextMenuFieldList.Count() = 0 then begin
            _ContextMenuFieldList.Add(InterfaceProfileRec.FieldNo("Panel Context Menu"));
            _ContextMenuFieldList.Add(InterfaceProfileRec.FieldNo("Panel Design Context Menu"));
            _ContextMenuFieldList.Add(InterfaceProfileRec.FieldNo("Button Pad Context Menu"));
            _ContextMenuFieldList.Add(InterfaceProfileRec.FieldNo("Button Pad Design Context Menu"));
            _ContextMenuFieldList.Add(InterfaceProfileRec.FieldNo("Data Grid Context Menu"));
            _ContextMenuFieldList.Add(InterfaceProfileRec.FieldNo("Data Grid Design Context Menu"));
            _ContextMenuFieldList.Add(InterfaceProfileRec.FieldNo("Input Context Menu" ));
            _ContextMenuFieldList.Add(InterfaceProfileRec.FieldNo("Input Design Context Menu"));
            _ContextMenuFieldList.Add(InterfaceProfileRec.FieldNo("Zoom Context Menu" ));
            _ContextMenuFieldList.Add(InterfaceProfileRec.FieldNo("Zoom Design Context Menu"));
            _ContextMenuFieldList.Add(InterfaceProfileRec.FieldNo("Media Context Menu" ));
            _ContextMenuFieldList.Add(InterfaceProfileRec.FieldNo("Media Design Context Menu"));
            _ContextMenuFieldList.Add(InterfaceProfileRec.FieldNo("Browser Context Menu" ));
            _ContextMenuFieldList.Add(InterfaceProfileRec.FieldNo("Browser Design Context Menu"));
        end;

        if interfaceProfileID = '' then
            interfaceProfileID := POSSession.InterfaceProfile().ID;

        if interfaceProfileID <> '' then
            if InterfaceProfileRec.Get(interfaceProfileID) then;
        
        if storeInterfaceProfileID <> '' then
            if storeInterfaceProfileID <> interfaceProfileID then
                if SecondaryInterfaceProfileRec.Get(storeInterfaceProfileID) then;

        if InterfaceProfileRec.ID <> Format("LSC POS Profile ID"::DefaultInterface) then
            if SecondaryInterfaceProfileRec.ID <> Format("LSC POS Profile ID"::DefaultInterface) then
                if DefaultInterfaceProfileRec.Get(Format("LSC POS Profile ID"::DefaultInterface)) then;

        foreach FieldNo in _ContextMenuFieldList do begin
            FieldVal := '';
            if InterfaceProfileRec.ID <> '' then begin
                RecRef.GetTable(InterfaceProfileRec);
                FieldVal := Format(RecRef.Field(FieldNo).Value());
            end;
            if FieldVal <> '' then
                continue; // field already set, no need for fallbacks
            if SecondaryInterfaceProfileRec.ID <> '' then begin
                RecRef.GetTable(SecondaryInterfaceProfileRec);
                FieldVal := Format(RecRef.Field(FieldNo).Value());
            end;
            if FieldVal = '' then
                if DefaultInterfaceProfileRec.ID <> '' then begin
                    RecRef.GetTable(DefaultInterfaceProfileRec);
                    FieldVal := Format(RecRef.Field(FieldNo).Value());
                end;
            if FieldVal <> '' then begin
                RecRef.GetTable(InterfaceProfileRec);
                RecRef.Field(FieldNo).Value(FieldVal);
                RecRef.SetTable(InterfaceProfileRec);
            end;
        end;

        pProfileEntity.TransferFields(InterfaceProfileRec);
        if not pProfileEntity.Insert then
            pProfileEntity.Modify;
    end;

    [InternalEvent(false, false)]
    local procedure OnBeforeMenuLinesLoad(MenuProfileID: Text; MenuID: Text; var POSMenuLine: Record "LSC POS Menu Line")
    begin
    end;
}
