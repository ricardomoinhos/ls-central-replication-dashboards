codeunit 10000755 "LSC Current Availab. Subscr."
{

    var
        CurrentAvailabilityFunctions: Codeunit "LSC Current Availab. Functions";

    [EventSubscriber(ObjectType::Table, database::"LSC Current Availability", OnAfterValidateEvent, "Available Qty.", false, false)]
    local procedure DisplayCurrentAvailability(var Rec: Record "LSC Current Availability"; var xRec: Record "LSC Current Availability"; CurrFieldNo: Integer)
    begin
        CurrentAvailabilityFunctions.DisplayCurrentAvailability(Rec, xrec, CurrFieldNo);
    end;

    [EventSubscriber(ObjectType::Table, database::"LSC POS Trans. Line", OnBeforeValidateEvent, Quantity, false, false)]
    local procedure CheckPOSTransLineQuantity(var Rec: Record "LSC POS Trans. Line"; var xRec: Record "LSC POS Trans. Line"; CurrFieldNo: Integer)
    begin
        CurrentAvailabilityFunctions.CheckPOSTransLineQuantity(Rec, Xrec, CurrFieldNo);
    end;

    [EventSubscriber(ObjectType::Table, database::"LSC POS Trans. Line", OnAfterValidateEvent, "Entry Status", false, false)]
    local procedure CheckPOSTransLineVoidline(var Rec: Record "LSC POS Trans. Line"; var xRec: Record "LSC POS Trans. Line"; CurrFieldNo: Integer)
    begin
        CurrentAvailabilityFunctions.CheckPOSTransLineVoidline(Rec, xREc, CurrFieldNo);
    end;

    [EventSubscriber(ObjectType::Codeunit, codeunit::"LSC POS Post Utility", OnBeforeProcessTransaction, '', false, false)]
    local procedure CheckPOSTransVoidOnBeforeProcessTransaction(var POSTrans: Record "LSC POS Transaction"; var TransSalesTaxEntryTEMP: Record "LSC Trans. SalesTax Entry" temporary)
    begin
        CurrentAvailabilityFunctions.CheckPOSTransVoid(POSTrans);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnBeforeOnTimer, '', true, true)]
    local procedure RefreshOnTimer(var POSTransaction: Record "LSC POS Transaction"; var POSTransLine: Record "LSC POS Trans. Line"; var CurrInput: Text)
    begin
        CurrentAvailabilityFunctions.RefreshOnTimer(POSTransaction, POSTransLine, CurrInput);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Control Interface", OnAfterShowMenu, '', true, true)]
    local procedure RefreshOnAfterShowMenu(var pMenuID: Code[20])
    begin
        CurrentAvailabilityFunctions.RefreshOnAfterShowMenu(pMenuID);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC Control Lib. Server", OnBeforeMenuLinesLoad, '', true, true)]
    local procedure OnBeforeMenuLinesLoad(MenuProfileID: Text; MenuID: Text; var POSMenuLine: Record "LSC POS Menu Line")
    begin
        CurrentAvailabilityFunctions.LoadCurrentAvailabilityTag(POSMenuLine, MenuProfileID, MenuID);
    end;
}

