codeunit 10037986 "LSC Rtl Assisted Setup Mgmt"
{
    var
        ConfigPackageManagement_g: Codeunit "Config. Package Management";
        ConfigExcelExchange_g: Codeunit "Config. Excel Exchange";
        GLAcctType: Option Posting,Heading,Total,"Begin-Total","End-Total";
        PackageCodeTxt: Label 'LSCentral.W1.EXCEL';
        PackageNameTxt: Label 'Excel Setup Data';
        ExcelFileExtensionTok: Label '*.xlsx';
        ExcelFileNameTok: Label 'DataImport_Dynamics365%1.xlsx', Comment = '%1 = String generated from current datetime to make sure file names are unique ';
        ImportFromExcelTxt: Label 'Import from Excel';
        ImportingMsg: Label 'Importing Data...';
        ExcelValidationErr: Label 'The file that you imported is corrupted. It contains columns that cannot be mapped to %1.', Comment = '%1 - product name';
        ValidateErrorsBeforeApplyQst: Label 'Some of the fields in template will not be applied because errors were found in the imported data.\\Do you want to continue?';
        ApplyingMsg: Label 'Applying Data...';

    internal procedure ExportExcelTemplate(): Boolean
    var
        FileName: Text;
        HideDialog: Boolean;
    begin
        exit(ExportExcelTemplateByFileName(FileName, HideDialog));
    end;

    internal procedure ExportExcelTemplateByFileName(var FileName: Text; HideDialog: Boolean): Boolean
    var
        ConfigPackageTable: Record "Config. Package Table";
    begin
        if FileName = '' then
            FileName :=
              StrSubstNo(ExcelFileNameTok, Format(CurrentDateTime, 0, '<Day,2>_<Month,2>_<Year4>_<Hours24>_<Minutes,2>_<Seconds,2>'));

        CreatePackageMetadata();
        ConfigPackageTable.SetRange("Package Code", PackageCodeTxt);
        ConfigExcelExchange_g.SetHideDialog(HideDialog);
        exit(ConfigExcelExchange_g.ExportExcel(FileName, ConfigPackageTable, false, true));
    end;

    local procedure CreatePackageMetadata()
    var
        ConfigPackage: Record "Config. Package";
        ConfigPackageManagement2: Codeunit "Config. Package Management";
        LanguageManagement: Codeunit Language;
        ApplicationSystemConstants: Codeunit "Application System Constants";
    begin
        ConfigPackage.SetRange(Code, PackageCodeTxt);
        ConfigPackage.DeleteAll(true);

        ConfigPackageManagement2.InsertPackage(ConfigPackage, PackageCodeTxt, PackageNameTxt, false);
        ConfigPackage."Language ID" := LanguageManagement.GetDefaultApplicationLanguageId();
        ConfigPackage."Product Version" :=
          CopyStr(ApplicationSystemConstants.ApplicationVersion(), 1, StrLen(ConfigPackage."Product Version"));
        ConfigPackage.Modify();

        InsertPackageTables();
        InsertPackageFields();
    end;

    local procedure InsertPackageTables()
    var
        ConfigPackageField: Record "Config. Package Field";
        RetailDataSetup: Record "LSC Retail Master Data Setup";
    begin
        if not RetailDataSetup.Get() then begin
            RetailDataSetup.Init();
            RetailDataSetup.Insert();
        end;

        InsertPackageTableCustomer(RetailDataSetup);
        InsertPackageTableVendor(RetailDataSetup);
        InsertPackageTableItem(RetailDataSetup);
        InsertPackageTableBarcodes();

        ConfigPackageField.SetRange("Package Code", PackageCodeTxt);
        ConfigPackageField.ModifyAll("Include Field", false);
    end;

    local procedure InsertPackageFields()
    begin
        InsertPackageFieldsCustomer();
        InsertPackageFieldsVendor();
        InsertPackageFieldsItem();
        InsertPackageFieldsBarcodes();
    end;

    local procedure InsertPackageTableCustomer(var RetailDataSetup: Record "LSC Retail Master Data Setup")
    var
        ConfigPackageTable: Record "Config. Package Table";
        ConfigTableProcessingRule: Record "Config. Table Processing Rule";
    begin
        ConfigPackageManagement_g.InsertPackageTable(ConfigPackageTable, PackageCodeTxt, Database::Customer);
        ConfigPackageTable."Data Template" := RetailDataSetup."Default Customer Template";
        ConfigPackageTable.Modify();
        ConfigPackageManagement_g.InsertProcessingRuleCustom(
          ConfigTableProcessingRule, ConfigPackageTable, 100000, Codeunit::"Excel Post Processor");
    end;

    local procedure InsertPackageFieldsCustomer()
    var
        ConfigPackageField: Record "Config. Package Field";
    begin
        ConfigPackageField.SetRange("Package Code", PackageCodeTxt);
        ConfigPackageField.SetRange("Table ID", Database::Customer);
        ConfigPackageField.DeleteAll(true);

        InsertPackageField(Database::Customer, 1, 1);     // No.
        InsertPackageField(Database::Customer, 2, 2);     // Name
        InsertPackageField(Database::Customer, 3, 3);     // Search Name
        InsertPackageField(Database::Customer, 5, 4);     // Address
        InsertPackageField(Database::Customer, 7, 5);     // City
        InsertPackageField(Database::Customer, 92, 6);    // County
        InsertPackageField(Database::Customer, 91, 7);    // Post Code
        InsertPackageField(Database::Customer, 35, 8);    // Country/Region Code
        InsertPackageField(Database::Customer, 8, 9);     // Contact
        InsertPackageField(Database::Customer, 9, 10);    // Phone No.
        InsertPackageField(Database::Customer, 102, 11);  // E-Mail
        InsertPackageField(Database::Customer, 20, 12);   // Credit Limit (LCY)
        InsertPackageField(Database::Customer, 21, 13);   // Customer Posting Group
        InsertPackageField(Database::Customer, 27, 14);   // Payment Terms Code
        InsertPackageField(Database::Customer, 88, 15);   // Gen. Bus. Posting Group
    end;

    local procedure InsertPackageTableVendor(var RetailDataSetup: Record "LSC Retail Master Data Setup")
    var
        ConfigPackageTable: Record "Config. Package Table";
        ConfigTableProcessingRule: Record "Config. Table Processing Rule";
    begin
        ConfigPackageManagement_g.InsertPackageTable(ConfigPackageTable, PackageCodeTxt, Database::Vendor);
        ConfigPackageTable."Data Template" := RetailDataSetup."Default Vendor Template";
        ConfigPackageTable.Modify();
        ConfigPackageManagement_g.InsertProcessingRuleCustom(
          ConfigTableProcessingRule, ConfigPackageTable, 100000, Codeunit::"Excel Post Processor");
    end;

    local procedure InsertPackageFieldsVendor()
    var
        ConfigPackageField: Record "Config. Package Field";
    begin
        ConfigPackageField.SetRange("Package Code", PackageCodeTxt);
        ConfigPackageField.SetRange("Table ID", Database::Vendor);
        ConfigPackageField.DeleteAll(true);

        InsertPackageField(Database::Vendor, 1, 1);     // No.
        InsertPackageField(Database::Vendor, 2, 2);     // Name
        InsertPackageField(Database::Vendor, 3, 3);     // Search Name
        InsertPackageField(Database::Vendor, 5, 4);     // Address
        InsertPackageField(Database::Vendor, 7, 5);     // City
        InsertPackageField(Database::Vendor, 92, 6);    // County
        InsertPackageField(Database::Vendor, 91, 7);    // Post Code
        InsertPackageField(Database::Vendor, 35, 8);    // Country/Region Code
        InsertPackageField(Database::Vendor, 8, 9);     // Contact
        InsertPackageField(Database::Vendor, 9, 10);    // Phone No.
        InsertPackageField(Database::Vendor, 102, 11);  // E-Mail
        InsertPackageField(Database::Vendor, 21, 12);   // Vendor Posting Group
        InsertPackageField(Database::Vendor, 27, 13);   // Payment Terms Code
        InsertPackageField(Database::Vendor, 88, 14);   // Gen. Bus. Posting Group
    end;

    local procedure InsertPackageTableItem(var RetailDataSetup: Record "LSC Retail Master Data Setup")
    var
        ConfigPackageTable: Record "Config. Package Table";
        ConfigTableProcessingRule: Record "Config. Table Processing Rule";
    begin
        ConfigPackageManagement_g.InsertPackageTable(ConfigPackageTable, PackageCodeTxt, Database::Item);
        ConfigPackageTable."Data Template" := RetailDataSetup."Default Item Template";
        ConfigPackageTable.Modify();
        ConfigPackageManagement_g.InsertProcessingRuleCustom(
          ConfigTableProcessingRule, ConfigPackageTable, 100000, Codeunit::"Excel Post Processor");
    end;

    local procedure InsertPackageFieldsItem()
    var
        ConfigPackageField: Record "Config. Package Field";
    begin
        ConfigPackageField.SetRange("Package Code", PackageCodeTxt);
        ConfigPackageField.SetRange("Table ID", Database::Item);
        ConfigPackageField.DeleteAll(true);

        InsertPackageField(Database::Item, 1, 1);     // No.
        InsertPackageField(Database::Item, 3, 2);     // Description
        InsertPackageField(Database::Item, 4, 3);     // Search Description
        InsertPackageField(Database::Item, 8, 4);     // Base Unit of Measure
        InsertPackageField(Database::Item, 18, 5);    // Unit Price
        InsertPackageField(Database::Item, 22, 6);    // Unit Cost
        InsertPackageField(Database::Item, 24, 7);    // Standard Cost
        InsertPackageField(Database::Item, 68, 8);    // Inventory
        InsertPackageField(Database::Item, 35, 9);    // Maximum Inventory
        InsertPackageField(Database::Item, 121, 10);  // Prevent Negative Inventory
        InsertPackageField(Database::Item, 34, 11);   // Reorder Point
        InsertPackageField(Database::Item, 36, 12);   // Reorder Quantity
        InsertPackageField(Database::Item, 38, 13);   // Unit List Price
        InsertPackageField(Database::Item, 41, 14);   // Gross Weight
        InsertPackageField(Database::Item, 42, 15);   // Net Weight
        InsertPackageField(Database::Item, 5411, 16); // Minimum Order Quantity
        InsertPackageField(Database::Item, 5412, 17); // Maximum Order Quantity
        InsertPackageField(Database::Item, 5413, 18); // Safety Stock Quantity
    end;

    local procedure InsertPackageTableBarcodes()
    var
        ConfigPackageTable: Record "Config. Package Table";
    begin
        ConfigPackageManagement_g.InsertPackageTable(ConfigPackageTable, PackageCodeTxt, Database::"LSC Barcodes");
    end;

    local procedure InsertPackageFieldsBarcodes()
    var
        ConfigPackageField: Record "Config. Package Field";
    begin
        ConfigPackageField.SetRange("Package Code", PackageCodeTxt);
        ConfigPackageField.SetRange("Table ID", Database::"LSC Barcodes");
        ConfigPackageField.DeleteAll(true);

        InsertPackageField(Database::"LSC Barcodes", 1, 1);     // Item No.
        InsertPackageField(Database::"LSC Barcodes", 10, 2);     // Barcode No.
        InsertPackageField(Database::"LSC Barcodes", 16, 3);     // Show for Item
        InsertPackageField(Database::"LSC Barcodes", 25, 4);     // Description
        InsertPackageField(Database::"LSC Barcodes", 100, 5);     // Last Date Modified
        InsertPackageField(Database::"LSC Barcodes", 110, 6);    // Variant Code
        InsertPackageField(Database::"LSC Barcodes", 200, 7);    // Unit of Measure Code
        InsertPackageField(Database::"LSC Barcodes", 300, 8);    // Discount %
    end;

    local procedure InsertPackageField(TableNo: Integer; FieldNum: Integer; ProcessingOrderNo: Integer)
    var
        ConfigPackageField: Record "Config. Package Field";
        RecordRef: RecordRef;
        FieldRef: FieldRef;
    begin
        RecordRef.Open(TableNo);
        FieldRef := RecordRef.Field(FieldNum);

        ConfigPackageManagement_g.InsertPackageField(ConfigPackageField, PackageCodeTxt, TableNo,
          FieldRef.Number, FieldRef.Name, FieldRef.Caption, true, true, false, false);
        ConfigPackageField.Validate("Processing Order", ProcessingOrderNo);
        ConfigPackageField.Modify(true);
    end;

    procedure ImportExcelDataStream(): Boolean
    var
        FileManagement: Codeunit "File Management";
        FileStream: InStream;
        Name: Text;
    begin
        ClearLastError();

        // There is no way to check if NVInStream is null before using it after calling the
        // UPLOADINTOSTREAM therefore if result is false this is the only way we can throw the error.
        Name := ExcelFileExtensionTok;

        if not UploadIntoStream(ImportFromExcelTxt, '', FileManagement.GetToFilterText('', '.xlsx'), Name, FileStream) then
            exit(false);
        ImportExcelDataByStream(FileStream);
        exit(true);
    end;

    procedure ImportExcelDataByStream(FileStream: InStream)
    var
        Window: Dialog;
    begin
        Window.Open(ImportingMsg);

        CreatePackageMetadata();
        ValidateTemplateAndImportDataStream(FileStream);

        Window.Close();
    end;

    local procedure ValidateTemplateAndImportDataStream(FileStream: InStream)
    var
        ConfigPackage: Record "Config. Package";
        ConfigPackageTable: Record "Config. Package Table";
        ConfigPackageField: Record "Config. Package Field";
        TempExcelBuffer: Record "Excel Buffer" temporary;
    begin
        ConfigPackage.Get(PackageCodeTxt);
        ConfigPackageTable.SetRange("Package Code", ConfigPackage.Code);

        if ConfigPackageTable.FindSet() then
            repeat
                ConfigPackageField.Reset();

                // Check if Excel file contains data sheets with the supported master tables (Customer, Vendor, Item)
                if IsTableInExcelStream(TempExcelBuffer, FileStream, ConfigPackageTable) then
                    ValidateTemplateAndImportDataCommon(TempExcelBuffer, ConfigPackageField, ConfigPackageTable)
                else begin
                    // Table is removed from the configuration package because it doen't exist in the Excel file
                    TempExcelBuffer.CloseBook();
                    ConfigPackageTable.Delete(true);
                end;
            until ConfigPackageTable.Next() = 0;
    end;

    local procedure ValidateTemplateAndImportDataCommon(var TempExcelBuffer: Record "Excel Buffer" temporary; var ConfigPackageField: Record "Config. Package Field"; var ConfigPackageTable: Record "Config. Package Table")
    var
        ConfigPackageRecord: Record "Config. Package Record";
        ColumnHeaderRow: Integer;
        ColumnCount: Integer;
        RecordNo: Integer;
        FieldID: array[250] of Integer;
        I: Integer;
    begin
        ColumnHeaderRow := 3; // Data is stored in the Excel sheets starting from row 3

        TempExcelBuffer.ReadSheet();
        // Jump to the Columns' header row
        TempExcelBuffer.SetFilter("Row No.", '%1..', ColumnHeaderRow);

        ConfigPackageField.SetRange("Package Code", PackageCodeTxt);
        ConfigPackageField.SetRange("Table ID", ConfigPackageTable."Table ID");

        ColumnCount := 0;

        if TempExcelBuffer.FindSet() then
            repeat
                if TempExcelBuffer."Row No." = ColumnHeaderRow then begin // Columns' header row
                    ConfigPackageField.SetRange("Field Caption", TempExcelBuffer."Cell Value as Text");

                    // Column can be mapped to a field, data will be imported to NAV
                    if ConfigPackageField.FindFirst() then begin
                        FieldID[TempExcelBuffer."Column No."] := ConfigPackageField."Field ID";
                        ConfigPackageField."Include Field" := true;
                        ConfigPackageField.Modify();
                        ColumnCount += 1;
                    end else // Error is thrown when the template is corrupted (i.e., there are columns in Excel file that cannot be mapped to NAV)
                        Error(ExcelValidationErr, PRODUCTNAME.Marketing());
                end else begin // Read data row by row
                               // A record is created with every new row
                    ConfigPackageManagement_g.InitPackageRecord(ConfigPackageRecord, PackageCodeTxt, ConfigPackageTable."Table ID");
                    RecordNo := ConfigPackageRecord."No.";
                    if ConfigPackageTable."Table ID" = 15 then begin
                        for I := 1 to ColumnCount do
                            if TempExcelBuffer.Get(TempExcelBuffer."Row No.", I) then // Mapping for Account fields
                                InsertAccountsFieldData(ConfigPackageTable."Table ID", RecordNo, FieldID[I], TempExcelBuffer."Cell Value as Text");
                    end else
                        for I := 1 to ColumnCount do
                            if TempExcelBuffer.Get(TempExcelBuffer."Row No.", I) then
                                // Fields are populated in the record created
                                InsertFieldData(ConfigPackageTable."Table ID", RecordNo, FieldID[I], TempExcelBuffer."Cell Value as Text")
                            else
                                InsertFieldData(ConfigPackageTable."Table ID", RecordNo, FieldID[I], '');

                    // Go to next line
                    TempExcelBuffer.SetFilter("Row No.", '%1..', TempExcelBuffer."Row No." + 1);
                end;
            until TempExcelBuffer.Next() = 0;

        TempExcelBuffer.Reset();
        TempExcelBuffer.DeleteAll();
        TempExcelBuffer.CloseBook();
    end;

    local procedure IsTableInExcelStream(var TempExcelBuffer: Record "Excel Buffer" temporary; FileStream: InStream; ConfigPackageTable: Record "Config. Package Table"): Boolean
    begin
        ConfigPackageTable.CalcFields("Table Name", "Table Caption");

        if OpenExcelStream(TempExcelBuffer, FileStream, ConfigPackageTable."Table Name") = '' then
            exit(true);
        if OpenExcelStream(TempExcelBuffer, FileStream, ConfigPackageTable."Table Caption") = '' then
            exit(true);
        exit(false);
    end;

    local procedure InsertAccountsFieldData(TableNo: Integer; RecordNo: Integer; FieldNum: Integer; Value: Text[250])
    var
        GLAccount: Record "G/L Account";
    begin
        if FieldNum = 4 then begin
            if Value = '0' then
                InsertFieldData(TableNo, RecordNo, FieldNum, Format(GLAccount."Account Type"::Posting))
            else
                if Value = '1' then
                    InsertFieldData(TableNo, RecordNo, FieldNum, Format(GLAccount."Account Type"::Heading))
                else
                    if Value = '2' then
                        InsertFieldData(TableNo, RecordNo, FieldNum, Format(GLAcctType::Total))
                    else
                        if Value = '3' then
                            InsertFieldData(TableNo, RecordNo, FieldNum, Format(GLAcctType::"Begin-Total"))
                        else
                            if Value = '4' then
                                InsertFieldData(TableNo, RecordNo, FieldNum, Format(GLAcctType::"End-Total"));
        end else
            if FieldNum = 8 then begin
                if Value = '0' then
                    InsertFieldData(TableNo, RecordNo, FieldNum, Format(GLAccount."Account Category"::" "))
                else
                    if Value = '1' then
                        InsertFieldData(TableNo, RecordNo, FieldNum, Format(GLAccount."Account Category"::Assets))
                    else
                        if Value = '2' then
                            InsertFieldData(TableNo, RecordNo, FieldNum, Format(GLAccount."Account Category"::Liabilities))
                        else
                            if Value = '3' then
                                InsertFieldData(TableNo, RecordNo, FieldNum, Format(GLAccount."Account Category"::Equity))
                            else
                                if Value = '4' then
                                    InsertFieldData(TableNo, RecordNo, FieldNum, Format(GLAccount."Account Category"::Income))
                                else
                                    if Value = '5' then
                                        InsertFieldData(TableNo, RecordNo, FieldNum, Format(GLAccount."Account Category"::"Cost of Goods Sold"))
                                    else
                                        if Value = '6' then
                                            InsertFieldData(TableNo, RecordNo, FieldNum, Format(GLAccount."Account Category"::Expense));
            end else
                if FieldNum = 9 then begin
                    if Value = '0' then
                        InsertFieldData(TableNo, RecordNo, FieldNum, Format(GLAccount."Income/Balance"::"Income Statement"))
                    else
                        if Value = '1' then
                            InsertFieldData(TableNo, RecordNo, FieldNum, Format(GLAccount."Income/Balance"::"Balance Sheet"));
                end else
                    if FieldNum = 10 then begin
                        if Value = '0' then
                            InsertFieldData(TableNo, RecordNo, FieldNum, Format(GLAccount."Debit/Credit"::Both))
                        else
                            if Value = '1' then
                                InsertFieldData(TableNo, RecordNo, FieldNum, Format(GLAccount."Debit/Credit"::Debit))
                            else
                                if Value = '2' then
                                    InsertFieldData(TableNo, RecordNo, FieldNum, Format(GLAccount."Debit/Credit"::Credit));
                    end else
                        if FieldNum = 43 then begin
                            if Value = '0' then
                                InsertFieldData(TableNo, RecordNo, FieldNum, Format(GLAccount."Gen. Posting Type"::" "))
                            else
                                if Value = '1' then
                                    InsertFieldData(TableNo, RecordNo, FieldNum, Format(GLAccount."Gen. Posting Type"::Purchase))
                                else
                                    if Value = '2' then
                                        InsertFieldData(TableNo, RecordNo, FieldNum, Format(GLAccount."Gen. Posting Type"::Sale));
                        end else
                            InsertFieldData(TableNo, RecordNo, FieldNum, Value);
    end;

    local procedure InsertFieldData(TableNo: Integer; RecordNo: Integer; FieldNum: Integer; Value: Text[250])
    var
        ConfigPackageData: Record "Config. Package Data";
    begin
        ConfigPackageManagement_g.InsertPackageData(ConfigPackageData, PackageCodeTxt, TableNo, RecordNo, FieldNum, Value, false);
    end;

    local procedure OpenExcelStream(var TempExcelBuffer: Record "Excel Buffer" temporary; FileStream: InStream; SheetName: Text[250]): Text
    begin
        exit(TempExcelBuffer.OpenBookStream(FileStream, SheetName));
    end;

    internal procedure ApplyPackageData()
    var
        ConfigPackage: Record "Config. Package";
        ConfigPackageTable: Record "Config. Package Table";
        TempConfigPackageTable: Record "Config. Package Table" temporary;
        ConfigPackageManagement2: Codeunit "Config. Package Management";
        Window: Dialog;
    begin
        ConfigPackage.Get(PackageCodeTxt);
        ConfigPackageTable.SetRange("Package Code", ConfigPackage.Code);

        // Validate the package
        ConfigPackageManagement2.SetHideDialog(true);
        ConfigPackageManagement2.CleanPackageErrors(PackageCodeTxt, '');
        if ConfigPackageTable.FindSet() then
            repeat
                ConfigPackageManagement2.ValidatePackageRelations(ConfigPackageTable, TempConfigPackageTable, true);
            until ConfigPackageTable.Next() = 0;

        ConfigPackageTable.SetRange("Table ID");
        ConfigPackage.CalcFields("No. of Errors");
        ConfigPackageManagement2.CleanPackageErrors(PackageCodeTxt, '');

        if ConfigPackage."No. of Errors" <> 0 then
            if not Confirm(ValidateErrorsBeforeApplyQst) then
                exit;

        Window.Open(ApplyingMsg);
        ConfigPackageManagement2.ApplyPackage(ConfigPackage, ConfigPackageTable, true);
        Window.Close();
        ConfigPackageManagement2.SetHideDialog(false);
    end;

    [EventSubscriber(ObjectType::Table, Database::"My Notifications", OnAfterIsNotificationEnabled, '', true, true)]
    local procedure OnAfterIsNotificationEnabled(NotificationId: Guid; var IsNotificationEnabled: Boolean; "Record": Variant)
    var
        PLBPOPUP: Codeunit "LSC PLB Item Popup";
    begin
        if PLBPOPUP.GetRetailCompanySetupInUse() then
            IsNotificationEnabled := false;
    end;
}
