codeunit 10036998 "LSC Retail Data Privacy Ext."
{

    var
        RecordNotFoundErr: Label 'Record not found.';

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Data Privacy Mgmt", OnCreateData, '', false, false)]
    local procedure CreateData(EntityTypeTableNo: Integer; EntityNo: Code[50]; var PackageCode: Code[20]; ActionType: Option "Export a data subject's data","Create a data privacy configuration package"; DataSensitivityOption: Option Sensitive,Personal,"Company Confidential",Normal,Unclassified)
    var
        MemberContact: Record "LSC Member Contact";
        Staff: Record "LSC Staff";
        MemberAccount: Record "LSC Member Account";
        DataPrivacy: Codeunit "Data Privacy Mgmt";
        RecRef: RecordRef;
    begin

        if EntityTypeTableNo = Database::"LSC Staff" then begin
            RecRef.GetTable(Staff);
            DataPrivacy.CreateRelatedData(RecRef, EntityTypeTableNo, EntityNo, PackageCode, ActionType, DataSensitivityOption);
        end;

        if EntityTypeTableNo = Database::"LSC Member Contact" then begin
            RecRef.GetTable(MemberContact);
            DataPrivacy.CreateRelatedData(RecRef, EntityTypeTableNo, EntityNo, PackageCode, ActionType, DataSensitivityOption);
        end;

        if EntityTypeTableNo = Database::"LSC Member Account" then begin
            RecRef.GetTable(MemberAccount);
            DataPrivacy.CreateRelatedData(RecRef, EntityTypeTableNo, EntityNo, PackageCode, ActionType, DataSensitivityOption);
        end;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Data Privacy Mgmt", OnAfterGetPackageCode, '', false, false)]
    local procedure GetPackageCode(EntityTypeTableNo: Integer; EntityNo: Code[50]; ActionType: Option "Export a data subject's data","Create a data privacy configuration package"; var PackageCodeTemp: Code[20]; var PackageCodeKeep: Code[20])
    var
        TempEntityNumber: Code[17];
    begin

        if StrLen(EntityNo) >= 18 then
            TempEntityNumber := CopyStr(EntityNo, (StrLen(EntityNo) mod 17) + 1, (StrLen(EntityNo) - (StrLen(EntityNo) mod 17)))
        else
            TempEntityNumber := CopyStr(EntityNo, 1, StrLen(EntityNo));

        if EntityTypeTableNo = Database::"LSC Staff" then begin
            PackageCodeTemp := 'ST*' + TempEntityNumber;
            PackageCodeKeep := 'STA' + TempEntityNumber;
        end;

        if EntityTypeTableNo = Database::"LSC Member Contact" then begin
            PackageCodeTemp := 'MC*' + TempEntityNumber;
            PackageCodeKeep := 'MCO' + TempEntityNumber;
        end;

        if EntityTypeTableNo = Database::"LSC Member Account" then begin
            PackageCodeTemp := 'MA*' + TempEntityNumber;
            PackageCodeKeep := 'MAC' + TempEntityNumber;
        end;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Data Privacy Mgmt", OnAfterSetPrivacyBlocked, '', false, false)]
    local procedure SetPrivacyBlocked(EntityTypeTableNo: Integer; EntityNo: Code[50])
    var
        MemberContact: Record "LSC Member Contact";
        Staff: Record "LSC Staff";
        MemberAccount: Record "LSC Member Account";
    begin

        if EntityTypeTableNo = Database::"LSC Staff" then begin
            if not Staff.Get(EntityNo) then
                Error(RecordNotFoundErr);
            if not Staff."Privacy Blocked" then begin
                Staff.Validate("Privacy Blocked", true);
                if Staff.Modify then;
            end;
        end;

        if EntityTypeTableNo = Database::"LSC Member Contact" then begin
            MemberContact.SetRange("Contact No.", EntityNo);
            if not MemberContact.FindFirst then
                Error(RecordNotFoundErr);
            if not MemberContact."Privacy Blocked" then begin
                MemberContact.Validate("Privacy Blocked", true);
                if MemberContact.Modify then;
            end;
        end;

        if EntityTypeTableNo = Database::"LSC Member Account" then begin
            if not MemberAccount.Get(EntityNo) then
                Error(RecordNotFoundErr);
            if not MemberAccount."Privacy Blocked" then begin
                MemberAccount.Validate("Privacy Blocked", true);
                if MemberAccount.Modify then;
            end;
        end;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Data Classification Mgt.", OnGetDataPrivacyEntities, '', false, false)]
    local procedure GetPrivacyMasterTables(var DataPrivacyEntities: Record "Data Privacy Entities")
    var
        DummyStaff: Record "LSC Staff";
        DummyMemberContact: Record "LSC Member Contact";
        DataClassificationMgt: Codeunit "Data Classification Mgt.";
    begin
        DataClassificationMgt.InsertDataPrivacyEntity(DataPrivacyEntities, Database::"LSC Staff", Page::"LSC Staff List",
          DummyStaff.FieldNo(ID), '', DummyStaff.FieldNo("Privacy Blocked"));
        DataClassificationMgt.InsertDataPrivacyEntity(DataPrivacyEntities, Database::"LSC Member Contact", Page::"LSC Member Contacts",
          DummyMemberContact.FieldNo("Contact No."), '', DummyStaff.FieldNo("Privacy Blocked"));
        DataClassificationMgt.InsertDataPrivacyEntity(DataPrivacyEntities, Database::"LSC Member Account", Page::"LSC Member Accounts",
          DummyMemberContact.FieldNo("Account No."), '', DummyStaff.FieldNo("Privacy Blocked"));
    end;

    [EventSubscriber(ObjectType::Page, Page::"Data Privacy Wizard", OnDrillDownForEntityNumber, '', false, false)]
    local procedure DrilldownForEntityNumber(EntityTypeTableNo: Integer; var EntityNo: Code[50])
    var
        MemberContact: Record "LSC Member Contact";
        Staff: Record "LSC Staff";
        MemberAccount: Record "LSC Member Account";
        DataPrivacyEntities: Record "Data Privacy Entities";
        MemberContacts: Page "LSC Member Contacts";
        StaffList: Page "LSC Staff List";
        MemberAccounts: Page "LSC Member Accounts";
        Instream: InStream;
        FilterAsText: Text;
        DataSubjectBlockedMsg: Label 'This data subject is already marked as blocked due to privacy. You can export the related data.';
    begin
        if EntityTypeTableNo = Database::"LSC Staff" then begin
            if DataPrivacyEntities.Get(Database::"LSC Staff") then begin
                DataPrivacyEntities.CalcFields("Entity Filter");
                DataPrivacyEntities."Entity Filter".CreateInStream(Instream);
                Instream.ReadText(FilterAsText);
            end;
            StaffList.LookupMode := true;
            Staff.SetView(FilterAsText);
            StaffList.SetTableView(Staff);
            if StaffList.RunModal = ACTION::LookupOK then begin
                StaffList.GetRecord(Staff);
                if Staff."Privacy Blocked" then
                    Message(DataSubjectBlockedMsg);
                EntityNo := Staff.ID;
            end;
        end;

        if EntityTypeTableNo = Database::"LSC Member Contact" then begin
            if DataPrivacyEntities.Get(Database::"LSC Member Contact") then begin
                DataPrivacyEntities.CalcFields("Entity Filter");
                DataPrivacyEntities."Entity Filter".CreateInStream(Instream);
                Instream.ReadText(FilterAsText);
            end;
            MemberContacts.LookupMode := true;
            MemberContact.SetView(FilterAsText);
            MemberContacts.SetTableView(MemberContact);
            if MemberContacts.RunModal = ACTION::LookupOK then begin
                MemberContacts.GetRecord(MemberContact);
                if MemberContact."Privacy Blocked" then
                    Message(DataSubjectBlockedMsg);
                EntityNo := MemberContact."Contact No.";
            end;
        end;

        if EntityTypeTableNo = Database::"LSC Member Account" then begin
            if DataPrivacyEntities.Get(Database::"LSC Member Account") then begin
                DataPrivacyEntities.CalcFields("Entity Filter");
                DataPrivacyEntities."Entity Filter".CreateInStream(Instream);
                Instream.ReadText(FilterAsText);
            end;
            MemberAccounts.LookupMode := true;
            MemberAccount.SetView(FilterAsText);
            MemberAccounts.SetTableView(MemberAccount);
            if MemberAccounts.RunModal = ACTION::LookupOK then begin
                MemberAccounts.GetRecord(MemberAccount);
                if MemberAccount."Privacy Blocked" then
                    Message(DataSubjectBlockedMsg);
                EntityNo := MemberAccount."No.";
            end;
        end;
    end;

    [EventSubscriber(ObjectType::Page, Page::"Data Privacy Wizard", OnEntityNoValidate, '', false, false)]
    local procedure ValidateEntityNo(EntityTypeTableNo: Integer; var EntityNo: Code[50])
    var
        MemberContact: Record "LSC Member Contact";
        Staff: Record "LSC Staff";
        MemberAccount: Record "LSC Member Account";
        DataSubjectBlockedMsg: Label 'This data subject is already marked as blocked due to privacy. You can export the related data.';
    begin

        if EntityTypeTableNo = Database::"LSC Staff" then begin
            if not Staff.Get(EntityNo, 20) then
                Error(RecordNotFoundErr);
            if Staff."Privacy Blocked" then
                Message(DataSubjectBlockedMsg);
        end;

        if EntityTypeTableNo = Database::"LSC Member Contact" then begin
            MemberContact.SetRange("Contact No.", EntityNo);
            if not MemberContact.FindFirst then
                Error(RecordNotFoundErr);
            if MemberContact."Privacy Blocked" then
                Message(DataSubjectBlockedMsg);
        end;

        if EntityTypeTableNo = Database::"LSC Member Account" then begin
            if not MemberAccount.Get(EntityNo, 20) then
                Error(RecordNotFoundErr);
            if MemberAccount."Privacy Blocked" then
                Message(DataSubjectBlockedMsg);
        end;
    end;
}
