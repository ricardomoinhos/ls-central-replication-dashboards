codeunit 10044625 "LSCNA POS Transaction Mgt." implements "LSCNA IPOS Transaction Mgt.", "LSCNA IPOSTransactionMgt.Controller"
{
    internal procedure SetTaxInfoFromStore(var POSTransaction: Record "LSC POS Transaction"; var POSTransLine: Record "LSC POS Trans. Line")
    var
        Store: Record "LSC Store";
        TransSalesTaxEntry: Record "LSC Trans. SalesTax Entry" temporary;
        POSPostUtilitySub: Codeunit "LSCNA POS Post Utility Mgt.";
    begin
        if POSTransaction."Transaction Type" = POSTransaction."Transaction Type"::Logon then
            exit;

        if (POSTransLine."Text Type" = POSTransLine."Text Type"::"Member Text") and (POSTransLine."Entry Type" = POSTransLine."Entry Type"::FreeText) then
            if POSTransaction."Entry Status" <> POSTransaction."Entry Status"::Voided then begin
                Store.Get(POSTransaction."Store No.");
                POSTransaction."LSCNA Tax Area Code" := Store."LSCNA Tax Area Code";
                POSTransaction."LSCNA Tax Liable" := Store."LSCNA Tax Liable";
                POSTransaction.Modify();
                if POSPostUtilitySub.RecalcTax(POSTransaction, TransSalesTaxEntry, false) then;
            end;
    end;

    internal procedure OnFindPosCommandBeforeValidateInput(PosCommand: Enum "LSC POS Command"; var IsHandled: Boolean)
    var
        POSTransaction: Codeunit "LSC POS Transaction";
    begin
        case PosCommand of
            PosCommand::GETINFO:
                begin
                    IsHandled := true;

                    if POSTransaction.ValidateInfo() then
                        POSTransaction.NextInfoPhase();
                end;
        end;
    end;

    internal procedure OnBeforePOSCommandCaseProcessed(Command: Code[20]; var Processed: Boolean)
    var
        POSCommandRec: Record "LSC POS Command";
        PosCommand: Enum "LSC POS Command";
    begin
        PosCommand := POSCommandRec.CommandToEnum(Command);

        case PosCommand of
            PosCommand::CANCEL3:
                begin
                    Cancel3Pressed();
                    Processed := true;
                end;
        end;
    end;

    local procedure Cancel3Pressed();
    var
        LineRec: Record "LSC POS Trans. Line";
        POSTransaction: Record "LSC POS Transaction";
        PosTrans: Codeunit "LSC POS Transaction";
        PosView: Codeunit "LSC POS View";
        STATE: Enum "LSC POS Transaction State";
        CurrLevel: Integer;
        MaxLevel: Integer;
    begin
        PosTrans.GetPOSTransaction(POSTransaction);
        STATE := PosView.GetPosStateEnum();

        if POSTransaction."New Transaction" then
            exit;

        if POSTransaction."Transaction Type" <> POSTransaction."Transaction Type"::Sales then
            exit;

        if STATE = "LSC POS Transaction State"::SALES then
            exit;

        CurrLevel := 0;
        MaxLevel := 5;
        while ((STATE <> "LSC POS Transaction State"::SALES) and (CurrLevel < MaxLevel)) do begin
            CurrLevel := CurrLevel + 1;
            PosTrans.CancelPressed(true, "LSC POS Trans. Request Infoc."::AutoOnly);
        end;

        if (STATE = "LSC POS Transaction State"::SALES) and not POSTransaction."New Transaction" then begin
            Clear(LineRec);
            LineRec.SetRange("Receipt No.", POSTransaction."Receipt No.");
            if not LineRec.IsEmpty() then
                exit;

            PosTrans.ClearPOSTransaction();
        end
    end;

    internal procedure OnAfterPOSCommandCaseProcessed(PosCommand: Enum "LSC POS Command"; var Processed: Boolean)
    begin
        case PosCommand of
            // PosCommand::TARE:
            //     begin
            //         Processed := true;
            //         ;
            //         // TAREPressed();//TODO: SCALE
            //     end;
            PosCommand::WIC:
                begin
                    Processed := true;
                    WICPressed();
                end;
        end;
    end;

    local procedure WICPressed()
    var
        POSTransaction: Codeunit "LSC POS Transaction";
        POSView: Codeunit "LSC POS View";
        WICInBeginningErr: Label 'WIC must be pressed in the beginning of Transaction';
    begin
        if not POSTransaction.TestNewTransaction() then begin
            POSView.ErrorBeep(WICInBeginningErr);
            exit;
        end;

        POSTransaction.SetFunctionMode("LSC POS Command"::GETINFO);

        POSTransaction.SetInfoPhase(100);
        POSTransaction.NextInfoPhase();
    end;

    internal procedure ItemLineOnAfterCheckVATSetups(var POSTransaction: Record "LSC POS Transaction"; var Item: Record Item; var IsHandled: Boolean)
    var
        POSView: Codeunit "LSC POS View";
        MissingOnItemErr: Label '%1 is missing on item';
    begin
        if not UseSalesTax() then
            exit;

        if Item."Tax Group Code" <> '' then
            exit;

        POSView.ErrorBeep(StrSubstNo(MissingOnItemErr, Item.FieldCaption("Tax Group Code")));
        IsHandled := true;
    end;

    internal procedure ItemLineOnAfterEvaluateSalesIsReturnSales(var POSTransaction: Record "LSC POS Transaction"; var Item: Record Item; var IsHandled: Boolean)
    var
        POSTransactionCU: Codeunit "LSC POS Transaction";
        POSView: Codeunit "LSC POS View";
        WICApplicableItemErr: Label 'Item must be WIC Applicable';
    begin
        if not POSTransaction."LSCNA WIC Transaction" then
            exit;

        if Item."LSCNA WIC Applicable" then
            exit;

        POSTransactionCU.SetLastItemNo('');
        POSView.ErrorBeep(WICApplicableItemErr);

        IsHandled := true;
    end;

    internal procedure OnBeforeEvaluateSaleIsReturnItemPhase1()
    begin
        // POSTransScale.SetReScaling(false);//TODO: SCALE
    end;

    internal procedure InsertPaymentLineOnBeforeSetAmountsMultiplyInTenderOperations(TenderType: Record "LSC Tender Type"; var NewLine: Record "LSC POS Trans. Line"; PosFuncProfile: Record "LSC POS Func. Profile"; PaymentAmount: Decimal; var isHandled: Boolean)
    begin
        isHandled := true;

        if TenderType."Multiply in Tender Operations" then begin
            if UseSalesTax() then
                NewLine.Amount := Round(PaymentAmount * NewLine.Quantity, PosFuncProfile."Amount Rounding to")
            else begin
                NewLine.Validate(Price, PaymentAmount);
                NewLine.Validate(Quantity);
                NewLine.CalcPrices()
            end;
        end else
            NewLine.Validate(Amount, PaymentAmount);

        NewLine."Net Amount" := NewLine.Amount;
        NewLine."LSCNA Food Stamp Applicable" := TenderType."Food Stamp";
    end;

    internal procedure OnBeforeInsertLineInsertPaymentLine(var NewLine: Record "LSC POS Trans. Line")
    var
        FoodStampChangeMsg: Label '$1 Food Stamp Change';
    begin
        if NewLine."LSCNA Food Stamp Applicable" and (NewLine.Amount < 0) then
            NewLine.Description := FoodStampChangeMsg;
    end;

    internal procedure OnTransactionTenderedAfterInitAmounts(var REC: Record "LSC POS Transaction"; var TenderType: Record "LSC Tender Type"; var PaymentAmount: Decimal; var ChangeTender: Boolean; var IsHandled: Boolean)
    var
        POSTransImplExt: Codeunit "LSCNA POS Trans. Impl. Ext.";
        POSTransactionCU: Codeunit "LSC POS Transaction";
        FoodStampAmt: Decimal;
    begin
        if not TenderType."Food Stamp" then
            exit;

        FoodStampAmt := POSTransImplExt.GetFoodStampAmount();
        if FoodStampAmt > -1 then
            exit;

        PaymentAmount := Round(FoodStampAmt, 1, '<');
        POSTransImplExt.SetRemainingFoodStamp(POSTransImplExt.GetRemainingFoodStamp() + PaymentAmount);

        ChangeTender := true;

        POSTransactionCU.InitNewLine();
        POSTransactionCU.InsertPaymentLine();

        IsHandled := true;
    end;

    internal procedure OnBeforeCheckStoreVATGroupCodeIsEmpty(Store: Record "LSC Store"; var SkipVatProdPostGrpLimitationCheck: Boolean; var IsHandled: Boolean)
    var
        POSView: Codeunit "LSC POS View";
        TaxCodeCodeErr: Label '%1 field cannot be blank in %2 table.';
    begin
        SkipVatProdPostGrpLimitationCheck := true;

        if Store."LSCNA TaxGroupCode(Limitation)" <> '' then
            exit;

        POSView.ErrorBeep(StrSubstNo(TaxCodeCodeErr, Store.FieldCaption("LSCNA TaxGroupCode(Limitation)"), Store.TableCaption));
        IsHandled := true;
    end;

    internal procedure OnTenderKeyPressedExAfterInitNewLine(var REC: Record "LSC POS Transaction"; var TenderType: Record "LSC Tender Type"; var IsHandled: Boolean)
    var
        POSView: Codeunit "LSC POS View";
        WICTenderOnlyInWicErr: Label 'WIC Tender Type can only be used in WIC Transactions';
    begin
        if (not REC."LSCNA WIC Transaction") and TenderType."WIC Tender Type" then begin
            POSView.ErrorBeep(WICTenderOnlyInWicErr);
            IsHandled := true;
        end;

        if REC."LSCNA WIC Transaction" and (not TenderType."WIC Tender Type") then begin
            POSView.ErrorBeep(WICTenderOnlyInWicErr);
            IsHandled := true;
        end;
    end;

    internal procedure OnBeforeRoundPaymentAmount_TenderKeyPressedEx(var REC: Record "LSC POS Transaction"; TenderType: Record "LSC Tender Type"; PosFuncProfile: Record "LSC POS Func. Profile"; var Balance: Decimal)
    var
        POSTransImplExt: Codeunit "LSCNA POS Trans. Impl. Ext.";
        FoodStampAmount: Decimal;
    begin
        if not TenderType."Food Stamp" then
            exit;

        FoodStampAmount := CalcFoodStampAmount(REC);
        FoodStampAmount := Round(FoodStampAmount, PosFuncProfile."Amount Rounding to");

        POSTransImplExt.SetFoodStampAmount(FoodStampAmount);

        Balance := FoodStampAmount;
    end;

    local procedure CalcFoodStampAmount(var POSTransaction: Record "LSC POS Transaction"): Decimal
    begin
        POSTransaction.SetRange("LSCNA Food Stamp Applicable Filter", true);
        POSTransaction.CalcFields("Gross Amount", Payment);
        POSTransaction.SetRange("LSCNA Food Stamp Applicable Filter");
        exit(POSTransaction."Gross Amount" - POSTransaction.Payment);
    end;

    internal procedure OnBeforeClearPrepaymentFromCustomer(Rec: Record "LSC POS Transaction"; var Customer: Record Customer; StoreSetup: Record "LSC Store")
    begin
        Customer."Tax Liable" := StoreSetup."LSCNA Tax Liable";
    end;

    internal procedure OnBeforePosFuncChangeVATBusOnLine(var POSTransaction: Record "LSC POS Transaction"; var Customer: Record Customer; var IsHandled: Boolean)
    var
        Store: Record "LSC Store";
        POSSession: Codeunit "LSC POS Session";
    begin
        if not UseSalesTax() then
            exit;

        IsHandled := true;

        if (POSTransaction."Customer No." <> '') then
            if (POSTransaction."Customer Order") and (Customer."Tax Area Code" <> '') then
                UpdateTaxAreaInfo(POSTransaction, Customer."Tax Area Code", Customer."Tax Liable")
            else
                if Store.Get(POSSession.StoreNo()) then
                    UpdateTax(POSTransaction, Store);
        ChangeTAXOnLine(POSTransaction);
    end;

    local procedure UpdateTax(var POSTransaction: Record "LSC POS Transaction"; Store: Record "LSC Store")
    var
        Customer: Record Customer;
        CustomerTaxLiable: Boolean;
        IsHandled: Boolean;
        TaxLiable: Boolean;
        TaxArea: Code[20];
    begin
        OnBeforeUpdateTax(POSTransaction, Customer, Store, IsHandled);
        if IsHandled then
            exit;

        if Customer.Get(POSTransaction."Customer No.") then begin
            CustomerTaxLiable := Customer.IsTaxLiable();
            TaxLiable := GetTaxLiable(CustomerTaxLiable, Store."LSCNA Tax Liable");
        end;

        TaxArea := GetTaxAreaCode(Store."LSCNA Tax Area Code", Customer."Tax Area Code", CustomerTaxLiable);

        UpdateTaxAreaInfo(POSTransaction, TaxArea, TaxLiable);
        OnAfterUpdateTax(POSTransaction, Customer, Store);
    end;

    local procedure GetTaxLiable(CustomerTaxLiable: Boolean; StoreTaxLiable: Boolean): Boolean
    begin
        exit(CustomerTaxLiable and StoreTaxLiable);
    end;

    local procedure GetTaxAreaCode(StoreTaxArea: Code[20]; CustomerTaxArea: Code[20]; CustomerTaxLiable: Boolean): Code[20]
    begin
        if not CustomerTaxLiable then
            exit(StoreTaxArea);

        if CustomerTaxArea <> '' then
            exit(CustomerTaxArea);

        exit(StoreTaxArea);
    end;

    internal procedure OnAfterOfferPosCalcDeletAllProcessCustomer(var POSTransLine2: Record "LSC POS Trans. Line")
    var
        PosMixMatchEntry: Record "LSC POS Mix & Match Entry";
    begin
        PosMixMatchEntry.SetRange("Receipt No.", POSTransLine2."Receipt No.");
        PosMixMatchEntry.SetRange("Line No.", POSTransLine2."Line No.");
        PosMixMatchEntry.DeleteAll();
    end;

    internal procedure OnBeforeInsertIncExpLineValidateAmount(var NewLine: Record "LSC POS Trans. Line"; PaymentAmount: Decimal; var IsHandled: Boolean)
    begin
        if not UseSalesTax() then
            exit;

        IsHandled := true;

        NewLine.Quantity := 1;
        NewLine.Price := PaymentAmount;
        NewLine."Net Price" := PaymentAmount;

        NewLine.LSCNAUpdateAmounts();
    end;

    internal procedure OnAfterCalculateAmountToDiscDiscAmountGetAmountToDiscount(POSTransLine: Record "LSC POS Trans. Line"; var AmountToDisc: Decimal)
    begin
        if not UseSalesTax() then
            exit;

        AmountToDisc := POSTransLine."Net Price" * POSTransLine.Quantity;
    end;

    internal procedure OnBeforeGetBalanceCalcTotals(var POSTransaction: Record "LSC POS Transaction"; PosFuncProfile: Record "LSC POS Func. Profile"; var Balance: Decimal; var IsHandled: Boolean);
    var
        POSTransImplExt: Codeunit "LSCNA POS Trans. Impl. Ext.";
        FoodStampAmount: Decimal;
    begin
        if UseSalesTax() then
            exit;

        IsHandled := true;

        FoodStampAmount := CalcFoodStampAmount(POSTransaction);
        FoodStampAmount := Round(FoodStampAmount, PosFuncProfile."Amount Rounding to");
        POSTransImplExt.SetFoodStampAmount(FoodStampAmount);

        POSTransaction.CalcFields("Gross Amount", "Line Discount", Payment, "Net Amount", "Total Discount", "Income/Exp. Amount", "LSCNA Net Income/Exp. Amount", Prepayment);

        Balance := POSTransaction."Gross Amount" + POSTransaction."Income/Exp. Amount" - POSTransaction.Payment;
        Balance := Round(Balance, PosFuncProfile."Amount Rounding to");
    end;

    internal procedure OnTotalPressedBeforeDisplayTotal(PosFuncProfile: Record "LSC POS Func. Profile"; Balance: Decimal; var IsHandled: Boolean)
    var
        POSTransImplExt: Codeunit "LSCNA POS Trans. Impl. Ext.";
        FoodStampAmount: Decimal;
    begin
        if not PosFuncProfile."LSCNA Show Food Stamp on Total" then
            exit;

        FoodStampAmount := POSTransImplExt.GetFoodStampAmount();

        if FoodStampAmount <= 0 then
            exit;

        IsHandled := true;
        DisplayFoodStampTotals(FoodStampAmount, Balance)
    end;

    internal procedure DisplayFoodStampTotals(FoodBalance: Decimal; Balance: Decimal): Boolean
    var
        OPOSUtility: Codeunit "LSC POS OPOS Utility";
        Line1: Text[30];
        Line2: Text[30];
    begin
        //TODO: ????
        // InitDisplay(false);
        // if DisplayDevice.Display = DisplayDevice.Display::None then
        //     exit;

        // LastQty := 0;
        // AmTxt := ProtScale.FormatAmount(Balance);
        // Len := StrLen(AmTxt);
        // Line1 := DisplayDevice."Display Balance Text";
        // Line1 := PadStr(Line1, 20 - Len) + AmTxt;

        // AmTxt := ProtScale.FormatAmount(FoodBalance);
        // Len := StrLen(AmTxt);
        // Line2 := PosSetup."Display Food Balance Text";
        // Line2 := PadStr(Line1, 20 - Len) + AmTxt;

        OPOSUtility.Display(Line1, Line2);
    end;

    internal procedure OnTotalPressedAfterSetInfoTextDescriptions(var CustomerOrderLine_Temp: Record "LSC Customer Order Line" temporary; PosFuncProfile: Record "LSC POS Func. Profile"; var InfoTextDescription2: Text)
    var
        POSTransImplExt: Codeunit "LSCNA POS Trans. Impl. Ext.";
        Formatting: Codeunit "LSC POS Formatting";
        FoodStampAmount: Decimal;
        FoodStampIsMsg: Label 'Food Stamp Amount is %1';
    begin
        if not PosFuncProfile."LSCNA Show Food Stamp on Total" then
            exit;

        FoodStampAmount := POSTransImplExt.GetFoodStampAmount();

        if FoodStampAmount <= 0 then
            exit;

        InfoTextDescription2 := StrSubstNo(FoodStampIsMsg, Formatting.FormatAmount(FoodStampAmount));
    end;

    internal procedure OnTotDiscAmPressedAfterCalcNewBalance(Rec: Record "LSC POS Transaction"; NewBalance: Decimal; var Tax: Decimal; var AmDec: Decimal)
    var
        PosFunc: Codeunit "LSC POS Functions";
    begin
        if not UseSalesTax() then
            exit;

        Rec.CalcFields(Rec."Net Amount", Rec."Gross Amount");
        if Rec."Net Amount" <> 0 then
            Tax := (Rec."Gross Amount" - Rec."Net Amount") / Rec."Net Amount" * 100
        else
            Tax := 0;
        AmDec := PosFunc.RoundAmount(AmDec / (1 + Tax / 100));
    end;

    internal procedure OnAccNoCheckOnIncExpPressed(AccNo: Code[20]; var IsHandled: Boolean)
    var
        POSTransaction: Record "LSC POS Transaction";
        POSTransactionCU: Codeunit "LSC POS Transaction";
        POSView: Codeunit "LSC POS View";
        IncExpNotAllowedInWICErr: Label 'Income/Expenses are not allowed in WIC transaction';
    begin
        POSTransactionCU.GetPOSTransaction(POSTransaction);
        if not POSTransaction."LSCNA WIC Transaction" then
            exit;

        IsHandled := true;

        POSView.ErrorBeep(IncExpNotAllowedInWICErr);
    end;

    internal procedure OnBeforeStartNewTransaction()
    var
        POSTransImplExt: Codeunit "LSCNA POS Trans. Impl. Ext.";
    begin
        POSTransImplExt.SetRemainingFoodStamp(0);
    end;

    internal procedure OnStartNewTransactionBeforeInsertLoadCardNoInNewTrans(var POSTransaction: Record "LSC POS Transaction"; Store: Record "LSC Store")
    begin
        if not POSTransaction."VAT by InfoCode" then
            exit;

        POSTransaction."LSCNA Tax Area Code" := Store."LSCNA Tax Area Code";
        POSTransaction."LSCNA Tax Liable" := Store."LSCNA Tax Liable";
    end;

    internal procedure OnAfterInitNewLine()
    begin
        //  POSTransScale.SetTareDone(false);//TODO: SCALE
    end;

    internal procedure OnValidatePriceCheckAfterInitTmpLine(var TmpLine: Record "LSC POS Trans. Line")
    begin
        if not UseSalesTax() then
            exit;

        TmpLine."Net Price" := TmpLine.Price;
        TmpLine.LSCNAUpdateAmounts();
    end;

    internal procedure OnBeforeGetNewBalance(PosTrLine: Record "LSC POS Trans. Line"; var NewBalance: Decimal; var IsHandled: Boolean)
    begin
        if PosTrLine."LSCNA VAT Calculation Type" <> PosTrLine."LSCNA VAT Calculation Type"::"Sales Tax" then
            exit;

        IsHandled := true;
        NewBalance := NewBalance + PosTrLine."Net Amount" + PosTrLine."Total Disc. Amount"
    end;

    internal procedure OnAfterUpdateMemberContext(POSTransaction: Record "LSC POS Transaction")
    var
        POSSESSION: Codeunit "LSC POS Session";
    begin
        POSSESSION.SetValue("LSC POS Tag"::TotalNetAmount, GetTotalNetAmountTxt(POSTransaction));
        POSSESSION.SetValue("LSC POS Tag"::SalesTax, GetSalesTaxTxt(POSTransaction));
    end;

    local procedure GetTotalNetAmountTxt(POSTransaction: Record "LSC POS Transaction"): Text[30]
    var
        Formatting: Codeunit "LSC POS Formatting";
    begin
        exit(Formatting.FormatAmount(GetTotalNetAmount(POSTransaction)));
    end;

    procedure GetSalesTaxTxt(POSTransaction: Record "LSC POS Transaction"): Text[30]
    var
        Formatting: Codeunit "LSC POS Formatting";
    begin
        exit(Formatting.FormatAmount(GetSalesTax(POSTransaction)));
    end;

    procedure GetTotalNetAmount(POSTransaction: Record "LSC POS Transaction"): Decimal
    begin
        exit(POSTransaction."Net Amount" + POSTransaction."Line Discount" + POSTransaction."LSCNA Net Income/Exp. Amount");
    end;

    local procedure GetSalesTax(POSTransaction: Record "LSC POS Transaction"): Decimal
    begin
        exit(POSTransaction."Gross Amount" - POSTransaction."Net Amount" + POSTransaction."Income/Exp. Amount" - POSTransaction."LSCNA Net Income/Exp. Amount");
    end;

    local procedure UpdateTaxAreaInfo(var POSTransaction: Record "LSC POS Transaction"; TaxAreaCode: Code[20]; TaxLiable: Boolean)
    begin
        POSTransaction."LSCNA Tax Area Code" := TaxAreaCode;
        POSTransaction."LSCNA Tax Liable" := TaxLiable;
        POSTransaction.Modify(false);
    end;

    internal procedure OnBeforeInsertPosTransLineBuffer(var pPosTransLineBuffer: Record "LSC POS Trans. Line" temporary; TransSalesEntry: Record "LSC Trans. Sales Entry")
    begin
        pPosTransLineBuffer."LSCNA Tax Group Code" := TransSalesEntry."LSCNA Tax Group Code";
    end;

    internal procedure OnMakeRepayTransBeforeInsertLineRec(var POSTransLine: Record "LSC POS Trans. Line")
    begin
        POSTransLine."Net Amount" := -POSTransLine."Net Amount";
    end;

    internal procedure UpdateSalesTaxAmountsOnInsertCopiedTransLine(var newLine: Record "LSC POS Trans. Line")
    begin
        if newLine."LSCNA VAT Calculation Type" <> newLine."LSCNA VAT Calculation Type"::"Sales Tax" then
            exit;

        newLine.LSCNAUpdateAmounts();
    end;

    internal procedure SetTaxDataOnInsertIncExpLine(var NewLine: Record "LSC POS Trans. Line"; TransIncomeExpenseEntry_L: Record "LSC Trans. Inc./Exp. Entry")
    begin
        NewLine."LSCNA Tax Group Code" := TransIncomeExpenseEntry_L."LSCNA Tax Group Code";
    end;

    internal procedure InitTaxOnNewTransactionFromStore(var POSTransaction: Record "LSC POS Transaction")
    var
        Store: Record "LSC Store";
    begin
        Store.SetLoadFields("LSCNA Tax Area Code", "LSCNA Tax Liable");
        if not Store.Get(POSTransaction."Store No.") then
            exit;

        UpdateTaxAreaInfo(POSTransaction, Store."LSCNA Tax Area Code", Store."LSCNA Tax Liable");
    end;

    internal procedure SetWICTransaction(var POSTransaction: Record "LSC POS Transaction")
    begin
        POSTransaction."LSCNA WIC Transaction" := true;
        POSTransaction.Modify(true);
    end;

    internal procedure GetTareWeight(Item: Record Item; var CurrInput: Text)
    begin
        if Item."LSCNA Default Tare Weight" = 0 then
            exit;

        CurrInput := Format(Item."LSCNA Default Tare Weight");
    end;

    internal procedure GetTotalNetAmount(var POSTransaction: Record "LSC POS Transaction"; var TotalNetAmount: Decimal)
    begin
        TotalNetAmount := POSTransaction."Net Amount" + POSTransaction."Line Discount" + POSTransaction."LSCNA Net Income/Exp. Amount";
    end;

    internal procedure OnProcessOtherInfoTrigger(SubInfo: Record "LSC Information Subcode"; Info: Record "LSC Infocode"; var POSTr: Record "LSC POS Transaction"; POSTerminal: Record "LSC POS Terminal")
    var
        BOUtils: Codeunit "LSC BO Utils";
        POSSession: Codeunit "LSC POS Session";
    begin
        case SubInfo."Trigger Function" of
            SubInfo."Trigger Function"::"Tax Area Code":
                if BOUtils.UseSalesTax(POSSession.StoreNo()) then begin
                    POSTr."LSCNA Tax Area Code" := SubInfo."Trigger Code";
                    POSTr."VAT by InfoCode" := true;
                    POSTr.Modify();
                    ChangeTAXOnLine(POSTr);
                    //Clear(LineRec);//TODO: FERI - this line is needed
                end;
        end;
    end;

    internal procedure CalcFieldsOnBeforeGetCotext(var POSTransaction: Record "LSC POS Transaction")
    begin
        POSTransaction.CalcFields("LSCNA Net Income/Exp. Amount");
    end;

    local procedure ChangeTAXOnLine(POSTransaction: Record "LSC POS Transaction")
    var
        POSTransLine: Record "LSC POS Trans. Line";
    begin
        POSTransLine.SetCurrentKey("Receipt No.", "LSCNA Tax Group Code", "Entry Status");
        POSTransLine.SetRange("Receipt No.", POSTransaction."Receipt No.");
        POSTransLine.SetRange("Entry Status", POSTransLine."Entry Status"::" ");
        POSTransLine.SetFilter("Entry Type", '%1|%2', POSTransLine."Entry Type"::Item, POSTransLine."Entry Type"::IncomeExpense);
        POSTransLine.SetRange("LSCNA VAT Calculation Type", POSTransLine."LSCNA VAT Calculation Type"::"Sales Tax");
        if POSTransLine.FindSet() then
            repeat
                POSTransLine.SetRange("LSCNA Tax Group Code", POSTransLine."LSCNA Tax Group Code");
                POSTransLine.RecalcTaxOnPosting();
                POSTransLine.FindLast();
                POSTransLine.SetRange("LSCNA Tax Group Code");
            until POSTransLine.Next() = 0;
    end;

    internal procedure UpdateAmountInDealLines(var POSTransaction: Record "LSC POS Transaction")
    var
        DealPOSTransLine: Record "LSC POS Trans. Line";
    begin
        UpdateAmountInDealLines(POSTransaction, DealPOSTransLine, this);
    end;

    internal procedure UpdateAmountInDealLines(var POSTransaction: Record "LSC POS Transaction"; var DealPOSTransLine: Record "LSC POS Trans. Line"; Controller: Interface "LSCNA IPOSTransactionMgt.Controller")
    begin
        DealPOSTransLine.SetRange("Receipt No.", POSTransaction."Receipt No.");
        DealPOSTransLine.SetRange("Disc. Info Line No.", 0);

        if not DealPOSTransLine.FindSet() then
            exit;

        repeat
            Controller.UpdateAmountInDealLine(DealPOSTransLine, Controller)
        until DealPOSTransLine.Next() = 0;
    end;

    internal procedure UpdateAmountInDealLine(var DealPOSTransLine: Record "LSC POS Trans. Line"; Controller: Interface "LSCNA IPOSTransactionMgt.Controller")
    var
        POSTransLine: Record "LSC POS Trans. Line";
        DealAmount: Decimal;
    begin
        DealAmount := Controller.GetDealAmountLinesValue(POSTransLine, DealPOSTransLine, Controller);
        if DealAmount = 0 then
            exit;

        DealPOSTransLine.Amount := DealAmount;
        DealPOSTransLine.Modify();
    end;

    internal procedure RecalculatePeriodicDiscount(var DealPOSTransLine: Record "LSC POS Trans. Line"): Boolean
    var
        PeriodicDiscount: Record "LSC Periodic Discount";
    begin
        exit(RecalculatePeriodicDiscount(DealPOSTransLine, PeriodicDiscount));
    end;

    internal procedure RecalculatePeriodicDiscount(var DealPOSTransLine: Record "LSC POS Trans. Line"; var PeriodicDiscount: Record "LSC Periodic Discount"): Boolean
    begin
        if DealPOSTransLine."Entry Type" <> DealPOSTransLine."Entry Type"::PerDiscount then
            exit(false);

        if not PeriodicDiscount.Get(DealPOSTransLine.Number) then
            exit(false);

        exit(PeriodicDiscount.Type in [PeriodicDiscount.Type::"Mix&Match", PeriodicDiscount.Type::Multibuy]);
    end;

    internal procedure GetDealAmountLinesValue(var POSTransLine: Record "LSC POS Trans. Line"; var DealPOSTransLine: Record "LSC POS Trans. Line"; Controller: Interface "LSCNA IPOSTransactionMgt.Controller"): Decimal
    var
        LinesAmount: Decimal;
    begin
        if Controller.RecalculatePeriodicDiscount(DealPOSTransLine) then
            exit;

        if not Controller.HasDiscountLines(DealPOSTransLine, POSTransLine) then
            exit;

        POSTransLine.Reset();
        POSTransLine.SetRange("Receipt No.", DealPOSTransLine."Receipt No.");
        POSTransLine.SetRange("Disc. Info Line No.", DealPOSTransLine."Line No.");
        if not POSTransLine.FindSet() then
            exit;
        repeat
            LinesAmount += POSTransLine.Amount;
        until POSTransLine.Next() = 0;

        exit(LinesAmount);
    end;

    internal procedure HasDiscountLines(var DealPOSTransLine: Record "LSC POS Trans. Line"; var POSTransLine: Record "LSC POS Trans. Line"): Boolean
    begin
        POSTransLine.SetRange("Receipt No.", DealPOSTransLine."Receipt No.");
        POSTransLine.SetFilter("Disc. Info Line No.", '<>%1', 0);
        if POSTransLine.IsEmpty() then
            exit(false);
        exit(true);
    end;

    local procedure UseSalesTax(): Boolean
    var
        ServiceLocator: Codeunit "LSCNA ServiceLocator";
        POSSession: Codeunit "LSC POS Session";
    begin
        exit(ServiceLocator.GetBOUtils().UseSalesTax(POSSession.StoreNo()));
    end;

    /// <summary>
    /// This event is raised before updating the tax information on the transaction.
    /// </summary>
    [IntegrationEvent(false, false)]
    local procedure OnBeforeUpdateTax(var POSTransaction: Record "LSC POS Transaction"; var Customer: Record Customer; var Store: Record "LSC Store"; var IsHandled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterUpdateTax(var POSTransaction: Record "LSC POS Transaction"; Customer: Record Customer; Store: Record "LSC Store")
    begin
    end;
}