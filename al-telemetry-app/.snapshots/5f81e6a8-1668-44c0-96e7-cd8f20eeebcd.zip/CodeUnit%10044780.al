codeunit 10044780 "LSCNA Store H."
{
    Access = Internal;

    [EventSubscriber(ObjectType::Table, Database::"LSC Store", OnBeforeVerifyPostingSetup, '', false, false)]
    local procedure "LSC Store_OnBeforeVerifyPostingSetup"(Store: Record "LSC Store"; var IsHandled: Boolean)
    var
        POSMgt: Codeunit "LSCNA POS Mgt.";
    begin
        POSMgt.VerifyStorePostingSetup(Store, IsHandled);
    end;
}