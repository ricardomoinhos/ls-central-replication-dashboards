table 99001470 "LSC Store"
{
    Caption = 'Store';
    DataCaptionFields = "No.", Name;
    DrillDownPageId = "LSC Store List";
    LookupPageId = "LSC Store List";
    DataClassification = CustomerContent;

    fields
    {
        field(1; "No."; Code[10])
        {
            Caption = 'No.';
            ToolTip = 'Specifies the number of the store. To enter a new number, you can use one of the following methods: If you have set up a default store number series, press Enter and the program automatically fills in this field with the next number in the series. If you have not set up a default store number series, you can enter a number manually. The number must be unique, you cannot use the same number twice in one table. You can set up as many numbers as you want.';
            trigger OnValidate()
            begin
                if "No." <> xRec."No." then begin
                    BackOfficeSetup.Get();
                    NoSeries.TestManual(BackOfficeSetup."Store No. Nos.");
                    "No. Series." := '';
                end;
            end;
        }
        field(2; "Responsibility Center"; Code[10])
        {
            Caption = 'Responsibility Center';
            TableRelation = "Responsibility Center".Code;
            ToolTip = 'Specifies the responsibility center for the store. Responsibility centers are used as an aid in the administration of your business.';
        }
        field(3; Name; Text[100])
        {
            Caption = 'Name';
            ToolTip = 'Specifies the name of the store. You can enter a maximum of 100 characters. The content of this field is often used when printing out.';
            trigger OnValidate()
            var
                Text008: Label 'No %1 represents this %2. \You need to create one with %3 equal to %4.';
            begin
                if not DistrLocation.Get("No.") then
                    Error(Text008, DistrLocation.TableCaption, TableCaption, DistrLocation.FieldCaption(Code), "No.");
                DistrLocation.Validate(Description, Name);
                DistrLocation.Modify(true);
            end;
        }
        field(5; Address; Text[100])
        {
            Caption = 'Address';
            ToolTip = 'Specifies the address of the store. You can enter a maximum of 100 characters. The content of this field is often used when printing out.';
        }
        field(6; "Address 2"; Text[50])
        {
            Caption = 'Address 2';
            ToolTip = 'Specifies the additional address of the store. You can enter a maximum of 50 characters. The content of this field is often used when printing out.';
        }
        field(7; City; Text[30])
        {
            Caption = 'City';
            TableRelation = "Post Code".City;
            ValidateTableRelation = false;
            ToolTip = 'Specifies the city of the store''s address. You can enter a maximum of 30 characters. The content of this field is often used when printing out. If you assign a Post Code to the store, before filling in this field, the program will automatically fill in the City field.';
            trigger OnValidate()
            var
                lCountryCode: Code[10];
                lCounty: Text[30];
            begin
                PostCode.ValidatePostCode(City, "Post Code", lCounty, lCountryCode, (CurrFieldNo <> 0) and GuiAllowed);
            end;
        }
        field(8; "Post Code"; Code[20])
        {
            Caption = 'Post Code';
            TableRelation = "Post Code".Code;
            ValidateTableRelation = false;
            ToolTip = 'Specifies the post code of the store''s address.';
            trigger OnValidate()
            var
                lCountryCode: Code[10];
                lCounty: Text[30];
            begin
                PostCode.ValidatePostCode(City, "Post Code", lCounty, lCountryCode, (CurrFieldNo <> 0) and GuiAllowed);
            end;
        }
        field(9; "Store Manager ID"; Code[20])
        {
            Caption = 'Store Manager ID';
            TableRelation = "LSC Staff".ID where("Store No." = field("No."));
            ToolTip = 'Specifies the Staff ID of the store manager for the selected store.';
            trigger OnValidate()
            begin
                CalcFields("Store Manager Name");
            end;
        }
        field(10; "E-Mail"; Text[80])
        {
            Caption = 'Email';
            ToolTip = 'Specifies the e-mail address of the store. You can enter a maximum of 80 characters. The content of this field is often used when printing out.';
            ExtendedDatatype = EMail;
            trigger OnValidate()
            var
                MailManagement: Codeunit "Mail Management";
            begin
                MailManagement.ValidateEmailAddressField("E-Mail");
            end;
        }
        field(12; "Store Manager Name"; Text[30])
        {
            CalcFormula = lookup("LSC Staff"."Last Name" where(ID = field("Store Manager ID")));
            Caption = 'Store Manager Name';
            Editable = false;
            FieldClass = FlowField;
            ToolTip = 'Specifies the last name of the store manager. The program retrieves the name automatically from the Staff table when the Store Manager ID field is filled in.';
        }
        field(13; "Phone No."; Text[30])
        {
            Caption = 'Phone No.';
            ToolTip = 'Specifies the phone number of the store. You can enter a maximum of 30 characters. Use a standard format for the phone number, so that it looks uniform on printouts. Example: 123 456 7890 or 12 34 56 78';
        }
        field(14; "Country Code"; Code[10])
        {
            Caption = 'Country Code';
            TableRelation = "Country/Region".Code;
            ToolTip = 'Specifies the country code assigned to the store. You can use Country/Region code to sort stores in the store list. The program uses the country code to format the store address fields (post code, city, country) on printouts.';
        }
        field(15; "Global Dimension 1 Code"; Code[20])
        {
            CaptionClass = '1,1,1';
            Caption = 'Global Dimension 1 Code';
            TableRelation = "Dimension Value".Code where("Global Dimension No." = const(1));
            ToolTip = 'Specifies the code for the department dimension to which the store belongs. You can create a specific department dimension value for the store, or use the department code automatically assigned when the Responsibility Center field is filled in.';
            trigger OnValidate()
            begin
                ValidateShortcutDimCode(1, "Global Dimension 1 Code");
                Modify();
            end;
        }
        field(16; "Location Code"; Code[10])
        {
            Caption = 'Location Code';
            TableRelation = Location.Code;
            ToolTip = 'Specifies the Location code for the store. Each store should have its own location code.';
            trigger OnValidate()
            var
                lLocation: Record Location;
                lStore: Record "LSC Store";
                StoreLocation: Record "LSC Store Location";
                isHandled: Boolean;
                LocationAlreadyAssignedToStore: Label 'Location %1 is related to store %2';
                LocationIsWarehouse: Label 'Location %1 is a Warehouse';
            begin
                OnBeforeValidateLocationCode(isHandled);
                if isHandled then
                    exit;
                if "Location Code" <> '' then begin
                    lStore.SetCurrentKey("Location Code");
                    lStore.SetFilter("No.", '<>%1', "No.");
                    lStore.SetRange("Location Code", "Location Code");
                    if lStore.FindFirst() then
                        Error(LocationAlreadyAssignedToStore, "Location Code", lStore."No.");

                    StoreLocation.SetCurrentKey("Location Code");
                    StoreLocation.SetRange("Location Code", "Location Code");
                    if StoreLocation.FindFirst() then
                        Error(LocationAlreadyAssignedToStore, "Location Code", StoreLocation."Store No.");

                    if lLocation.Get("Location Code") then
                        if lLocation."LSC Location is a Warehouse" then
                            Error(LocationIsWarehouse, "Location Code");
                end;
                UpdateSourcingLocations();
            end;
        }
        field(17; "Currency Code"; Code[10])
        {
            Caption = 'Currency Code';
            TableRelation = Currency;
            ToolTip = 'Specifies the identity code of the currency assigned to the restaruant. All POS terminals in the store will use this currency code. Attention: If the currency code in this field is not the local currency, the General Ledgers will still be posted into by using the local currency (LCY).';
        }
        field(18; "Global Dimension 2 Code"; Code[20])
        {
            CaptionClass = '1,1,2';
            Caption = 'Global Dimension 2 Code';
            TableRelation = "Dimension Value".Code where("Global Dimension No." = const(2));
            ToolTip = 'Specifies the code for the project dimension to which the store belongs. You can create a specific project dimension value for the store, or use the project code automatically assigned when the Responsibility Center field is filled in.';
            trigger OnValidate()
            begin
                ValidateShortcutDimCode(2, "Global Dimension 2 Code");
                Modify();
            end;
        }
        field(30; "Store Type"; Option)
        {
            Caption = 'Store Type';
            OptionCaption = 'Store,Head Office,Call Center,Warehouse,Other';
            OptionMembers = Store,"Head Office","Call Center",Warehouse,Other;
            ToolTip = 'Specifies the type of the store, is it a regular store or is it a specialized location like Head Office, Call Center, Warehouse or something else.';
        }
        field(35; "Last Date Modified"; Date)
        {
            Caption = 'Last Date Modified';
            Editable = false;
            ToolTip = 'Specifies when the store was last modified. When you change information about the store, the program automatically enters the program date in the Last Date Modified field.';
        }
        field(40; "Date Filter"; Date)
        {
            Caption = 'Date Filter';
            FieldClass = FlowFilter;
        }
        field(41; "Time Filter"; Time)
        {
            Caption = 'Time Filter';
            FieldClass = FlowFilter;
        }
        field(42; "Store Filter"; Code[10])
        {
            Caption = 'Store Filter';
            FieldClass = FlowFilter;
            TableRelation = "LSC Store"."No.";
        }
        field(47; "Item Filter"; Code[20])
        {
            Caption = 'Item Filter';
            FieldClass = FlowFilter;
            TableRelation = Item."No.";
        }
        field(58; "No. of Sales Transactions"; Integer)
        {
            CalcFormula = count("LSC Transaction Header" where("Store No." = field("No."),
                                                            "Transaction Type" = const(Sales),
                                                            Date = field("Date Filter"),
                                                            "Entry Status" = filter(" " | Posted)));
            Caption = 'No. of Sales Transactions';
            Editable = false;
            FieldClass = FlowField;
        }
        field(59; "Net Turnover"; Decimal)
        {
            CalcFormula = - sum("LSC Transaction Header"."Net Amount" where("Store No." = field("No."),
                                                                        "Transaction Type" = const(Sales),
                                                                        Date = field("Date Filter"),
                                                                        "Entry Status" = filter(" " | Posted)));
            Caption = 'Net Turnover';
            AutoFormatType = 2;
            Editable = false;
            FieldClass = FlowField;
        }
        field(67; "No. of Items Sold"; Decimal)
        {
            CalcFormula = sum("LSC Transaction Header"."No. of Items" where("Store No." = field("No."),
                                                                         "Transaction Type" = const(Sales),
                                                                         Date = field("Date Filter"),
                                                                         "Entry Status" = filter(" " | Posted)));
            Caption = 'No. of Items Sold';
            Editable = false;
            FieldClass = FlowField;
        }
        field(70; "Functionality Profile"; Code[10])
        {
            Caption = 'Functionality Profile';
            TableRelation = "LSC POS Func. Profile"."Profile ID";
            ToolTip = 'Specifies the POS Functionality Profile for the store. The functionality profile controls for example default settings for VAT, Infocode for store actions, rounding of numbers, how many days transactions exist on the POS terminals and so on.';
        }
        field(71; "Menu Profile"; Code[10])
        {
            Caption = 'Menu Profile';
            TableRelation = "LSC POS Menu Profile".ID;
            ToolTip = 'Specifies which POS menu profile is in use for the store.';
        }
        field(72; "Interface Profile"; Code[10])
        {
            Caption = 'Interface Profile';
            TableRelation = "LSC POS Interface Profile";
            ToolTip = 'Specifies which POS interface profile is in use for the store.';
        }
        field(73; "Fraud Sort Field"; Decimal)
        {
            Caption = 'Fraud Sort Field';
        }
        field(74; "Style Profile"; Code[20])
        {
            Caption = 'Style Profile';
            TableRelation = "LSC POS Style Profile";
            ToolTip = 'Specifies whith POS style profile is in use for the store.';
        }
        field(75; "Event View Group Filter"; Code[20])
        {
            Caption = 'Event View Group Filter';
            FieldClass = FlowFilter;
            TableRelation = "LSC Event View Header".Code;
        }
        field(76; "Hardware Profile"; Code[10])
        {
            Caption = 'Hardware Profile';
            TableRelation = "LSC POS Hardware Profile"."Profile ID";
            ToolTip = 'Specifies whith POS hardware profile is in use for the store.';
        }
        field(77; "eCommerce Profile Code"; Code[20])
        {
            Caption = 'eCommerce Profile Code';
            TableRelation = "LSC ECommerce Profile";
            ToolTip = 'Specifies the eCommerce profile that the store uses.';
        }
        field(78; "Language Profile ID"; Code[20])
        {
            Caption = 'Language Profile ID';
            TableRelation = "LSC Language Profile";
            ObsoleteState = Pending;
            ObsoleteReason = 'Moved to the SSK Profile';
            ObsoleteTag = '24.0';
            ToolTip = 'Specifies ID of the language profile assigned to the restaurant. Used to allow the Self Service Kiosk user to select from a selection of languages that are used to display menus and print receipts.';
        }
        field(79; "SSK Profile ID"; Code[20])
        {
            Caption = 'Self Service Kiosk Profile ID';
            TableRelation = "LSC SSK Profile";
            ToolTip = 'Specifies the ID of the self service kiosk profile assigned to the restaurant. The setting is overruled by the profile assigned to the POS terminal.';
        }
        field(81; "No. Series"; Code[10])
        {
            Caption = 'No. Series';
            TableRelation = "No. Series";
            ObsoleteReason = 'Use No. Series. instead';
            ObsoleteState = Pending;
            ObsoleteTag = '27.0';
        }
        field(82; "Statement Nos."; Code[10])
        {
            Caption = 'Statement Nos.';
            TableRelation = "No. Series";
            ToolTip = 'Specifies the number series for the statement in the store. This field must be filled in for proper functionality. Each store needs to have its own statement number series. If you are posting statements in a database, the Local Store No. in the Retail Setup table must be a store. The statement number series for this store must have a relationship to statement no. series for all other stores that you are posting statements in the database for, so you can select the correct number series for the store that you are creating a statement for.';
            ObsoleteReason = 'Use Statement No. Series instead';
            ObsoleteState = Pending;
            ObsoleteTag = '27.0';
        }
        field(83; "Posted Statem. Nos."; Code[10])
        {
            Caption = 'Posted Statem. Nos';
            TableRelation = "No. Series";
            ToolTip = 'Specifies the number series for posted statements in the store. This field must be filled in for proper functionality. Each store needs to have its own statement number series. If you are posting statements in a database, the Local Store No. in the Retail Setup table must be a store. The statement number series for this store must have a relationship to statement no. series for all other stores that you are posting statements in the database for, so you can select the correct number series for the store that you are creating a statement for.';
            ObsoleteReason = 'Use Posted Statement Nos. instead';
            ObsoleteState = Pending;
            ObsoleteTag = '27.0';
        }
        field(90; "One Statement per Day"; Boolean)
        {
            Caption = 'One Statement per Day';
            ToolTip = 'Specifies wether the store has one statement per day. If so, the program automatically inserts the Trans. Starting Date field into the Trans. Ending Date field and only transactions for one day are included in the statement. By default, the date entered in both date fields is Today. You can still change the transaction ending date if desired.';
            trigger OnValidate()
            begin
                if (not "One Statement per Day") and ("Closing Method" = "Closing Method"::"Date and Time") and "Auto. Calculate Statement" then
                    Validate("Auto. Calculate Statement", false);
            end;
        }
        field(91; "Auto. Calculate Statement"; Boolean)
        {
            Caption = 'Auto. Calculate Statement';
            ToolTip = 'Specifies if statements will be automatically created and calculated for the store using the codeunit Statement - Auto Calculate (99001479).';
            trigger OnValidate()
            var
                AutoCalcStmtErr: Label 'To enable %1 with %2 %3, %4 must be selected.';
            begin
                if (not "One Statement per Day") and ("Closing Method" = "Closing Method"::"Date and Time") and "Auto. Calculate Statement" then
                    Error(AutoCalcStmtErr, FieldCaption("Auto. Calculate Statement"), FieldCaption("Closing Method"), "Closing Method"::"Date and Time", FieldCaption("One Statement per Day"))
                else
                    if (not "Auto. Calculate Statement") then
                        Validate("Group by Staff/POS", false);
            end;
        }
        field(92; "Group by Staff/POS"; Boolean)
        {
            Caption = 'Group by Staff/POS Terminal';
            ToolTip = 'Specifies if the statements that are automatically created for the store will be grouped by Staff/POS Terminal.';
        }
        field(101; "Statement Method"; Option)
        {
            Caption = 'Statement Method';
            OptionCaption = 'Staff,POS Terminal,Total';
            OptionMembers = Staff,"POS Terminal",Total;
            ToolTip = 'Specifies the statement method of your business, that is, how Statement Line in statements are divided. Staff: For each staff member, the program creates a statement line for each tender type in transactions transacted by the Staff. POS Terminal: For each POS Terminal, the program creates a statement line for each tender type in transactions transacted on the POS terminal. Total: The program creates a statement line for each tender type Staff in the transactions. You can use the Staff/POS Terminal Filter in the Statement table to select to see the turnover for a particular POS terminal or staff member if the Statement Method is POS Terminal or Staff respectively.';
            trigger OnValidate()
            var
                PosFixStartAmount: Record "LSC POS Fixed Start Amount";
                PTerminal: Record "LSC POS Terminal";
                Statement: Record "LSC Statement";
                Counter: Integer;
                Text009: Label '%1 has been changed for %4. You need to clear and recalculate %2 unposted %3 before they can be posted.';
                Text022: Label 'Statement Method can not be changed because there are open statements with posted sales entries.  \Please close the statements before changing the statement method.';
            begin
                Statement.SetRange(Statement."Store No.", "No.");
                Statement.SetRange(Status, Statement.Status::"Sales Entries Posted");
                if Statement.FindFirst() then
                    Error(Text022);
                Statement.SetRange(Status);
                if Statement.FindFirst() then
                    repeat
                        Statement.Recalculate := true;
                        Statement.Method := "Statement Method";
                        Statement."Staff/POS Term Filter Internal" := '';
                        Statement.Modify();
                        Counter += 1;
                    until Statement.Next() = 0;
                if Counter > 0 then
                    Message(Text009, Statement.FieldCaption(Method), Format(Counter), Statement.TableCaption, "No.");

                if "Statement Method" <> xRec."Statement Method" then begin
                    PTerminal.Reset();
                    PTerminal.SetCurrentKey("Store No.");
                    PTerminal.SetRange("Store No.", "No.");
                    PTerminal.SetRange("Statement Method", xRec."Statement Method");
                    if PTerminal.FindFirst() then
                        repeat
                            PTerminal."Statement Method" := "Statement Method";
                            PTerminal.Modify();
                        until PTerminal.Next() = 0;

                    PosFixStartAmount.Reset();
                    PosFixStartAmount.SetRange("Store No.", "No.");
                    PosFixStartAmount.DeleteAll(true);
                    if "Statement Method" = "Statement Method"::Total then
                        "Group by Staff/POS" := false;
                end;
            end;
        }
        field(102; "Closing Method"; Option)
        {
            Caption = 'Closing Method';
            OptionCaption = 'Date and Time,Shift';
            OptionMembers = "Date and Time",Shift;
            ToolTip = 'Specifies the closing method of the store. The closing method determines when the Statement should be calculated and posted. Date and Time: Statements are calculated and posted at a selected date and time. You can create as many statements as you like. Shift: One statement is calculated and posted for each Work Shift RBO set up for the store.';
            trigger OnValidate()
            begin
                if "Closing Method" <> "Closing Method"::Shift then begin
                    if (not "One Statement per Day") and ("Closing Method" = "Closing Method"::"Date and Time") and "Auto. Calculate Statement" then
                        Validate("Auto. Calculate Statement", false);
                end else
                    Validate("Group by Staff/POS", false);
            end;
        }
        field(103; "Rounding Account"; Code[20])
        {
            Caption = 'Rounding Account';
            TableRelation = "G/L Account"."No.";
            ToolTip = 'Specifies the number of the G/L Account into which you wish to post a rounding difference in a Statement. The maximum amount allowed as rounding difference is defined in the Max. Round. in Stmt. field.';
            trigger OnValidate()
            begin
                CalcFields("Rounding Acc. Name");
            end;
        }
        field(104; "Max. Diff. to Allow Post."; Decimal)
        {
            Caption = 'Max. Diff. to Allow Post.';
            ToolTip = 'Specifies the maximum Difference in LCY that can be between the Trans. Amount in LCY and Counted Amount in LCY in the statement to allow posting.';
        }
        field(105; "Max. Round. in Stmt."; Decimal)
        {
            Caption = 'Max. Round. in Stmt.';
            ToolTip = 'Specifies the maximum rounding difference amount allowed when posting the Statement. Rounding difference is a summed up difference in the statement transactions between the total sales amount and the total payment amount. There is a rounding difference if you select Rounding a tender type. This difference depends on the rounding of the tender types in your company. The Trans. Sale/Pmt. Diff. field shows the exact difference between the sales amount and payment amount in each transaction.';
        }
        field(106; "Max. Diff. from Shift Date"; Decimal)
        {
            Caption = 'Max. Diff. from Shift Date';
            ToolTip = 'Specifies the maximum difference in hours allowed from the date and time of the Transaction Header to the date and time limits set up for the Work Shift Setup in the transaction. If the difference between the transaction date and the work shift setup dates is greater than this field for a transaction, the program places a checkmark in the field in the Transaction table. Example - If the maximum difference allowed is 2 and a half hours, you enter 2,5 in this field. A transaction transacted at 11:00:00, belonging to a night shift that is set up to end at 8:00:00, is marked as belonging to the wrong shift since the 2,5 hour time difference is exceeded.';
        }
        field(107; "Allowed Diff. in Trans."; Decimal)
        {
            Caption = 'Allowed Diff. in Trans.';
            ToolTip = 'Specifies the maximum amount allowed in the Trans. Sale/Pmt. Diff. field that shows the difference between sales and payment per transaction. This limit is for helping you to spot errors in the transactions. If the amount in the Trans. Sale/Pmt. Diff. field of a transaction exceeds the limit set in the Allowed Diff. in Trans., the program marks the transaction with Sale/Pmt. Difference in the Transaction Code field. The Trans. w/ Sale/Pmt. Diff. field in the Statement table counts the transactions that have Transaction Code Sale/Pmt.Difference.';
        }
        field(108; "Rounding Acc. Name"; Text[100])
        {
            CalcFormula = lookup("G/L Account".Name where("No." = field("Rounding Account")));
            Caption = 'Rounding Acc. Name';
            Editable = false;
            FieldClass = FlowField;
            ToolTip = 'Specifies the name of the rounding account. The program retrieves the account name automatically from the G/L Account table when the Rounding Account field is filled in.';
        }
        field(109; "Paym. Compr. in Statem. Post."; Boolean)
        {
            Caption = 'Paym. Compr. in Statem. Post.';
            ToolTip = 'Specifies whether payment compression is on for the store.';
        }
        field(110; "Tend. Decl. Calculation"; Option)
        {
            Caption = 'Tend. Decl. Calculation';
            OptionCaption = 'Last,Sum';
            OptionMembers = Last,"Sum";
            ToolTip = 'Specifies the tender declaration method for the store. Last - the program uses the last Tender Declaration for the calculation. Sum - the program uses the sum of Tender Declarations performed for the calculation.';
        }
        field(111; "Advanced Shift Method"; Boolean)
        {
            Caption = 'Advanced Shift Method';
            ObsoleteState = Removed;
            ObsoleteReason = 'Forecourt moved to a separate extension.';
            ObsoleteTag = '25.0'; // Pending='21.1'

            trigger OnValidate()
            begin
                TestField("Closing Method", "Closing Method"::Shift);
            end;
        }
        field(112; "Advanced Shift Nos."; Code[20])
        {
            Caption = 'Shift Nos.';
            TableRelation = "No. Series";
            ObsoleteState = Removed;
            ObsoleteReason = 'Forecourt moved to a separate extension.';
            ObsoleteTag = '25.0'; // Pending='21.1'
        }
        field(113; "Default Commission Group"; Code[10])
        {
            Caption = 'Default Commission Group';
            TableRelation = "LSC Cmsn Salesperson Group";
        }
        field(130; "Campaign Nos."; Code[20])
        {
            Caption = 'Campaign Nos.';
            Description = '';
            TableRelation = "No. Series";
            ToolTip = 'Specifies the campaign number series assigned to the store.';
        }
        field(135; "Promotion Nos."; Code[20])
        {
            Caption = 'Promotion Nos.';
            TableRelation = "No. Series";
            ToolTip = 'Specifies the promotion number series assigned to the store.';
        }
        field(140; "Periodic Discount Nos."; Code[20])
        {
            Caption = 'Periodic Discount Nos.';
            TableRelation = "No. Series";
            ToolTip = 'Specifies the periodic discount number series assigned to the store.';
        }
        field(142; "Published Offer Nos."; Code[20])
        {
            Caption = 'Published Offer Nos.';
            TableRelation = "No. Series";
            ToolTip = 'Specifies the published offer number series assigned to the store.';
        }
        field(143; "Member Notification Nos."; Code[20])
        {
            Caption = 'Member Notification Nos.';
            TableRelation = "No. Series";
            ToolTip = 'Specifies the member notification number series assigned to the store.';
        }
        field(144; "FBP Nos."; Code[20])
        {
            Caption = 'FBP Nos.';
            TableRelation = "No. Series";
            ToolTip = 'Specifies the number series for the Frequent Buyer Program assigned to the store.';
        }
        field(145; "POS Terminal Nos."; Code[20])
        {
            Caption = 'POS Terminal Nos.';
            TableRelation = "No. Series";
            ToolTip = 'Specifies the POS Terminal number series assigned to the store.';
        }
        field(150; "Staff ID Nos."; Code[20])
        {
            Caption = 'Staff ID Nos.';
            TableRelation = "No. Series";
            ToolTip = 'Specifies the Staff number series assigned to the store.';
        }
        field(151; "Coupon Nos."; Code[20])
        {
            Caption = 'Coupon Nos.';
            TableRelation = "No. Series";
            ToolTip = 'Specifies the coupon number series assigned to the store.';
        }
        field(155; "Item Nos."; Code[20])
        {
            Caption = 'Item Nos.';
            TableRelation = "No. Series";
            ToolTip = 'Specifies the Item number series assigned to the store.';
        }
        field(156; "Data Access Control"; Boolean)
        {
            Caption = 'Data Access Control';
            ToolTip = 'Specifies whether data access controls are active for this store.';
        }
        field(160; "Store VAT Bus. Post. Gr."; Code[20])
        {
            Caption = 'Store VAT Bus. Post. Gr.';
            TableRelation = "VAT Business Posting Group".Code;
            ToolTip = 'Specifies the VAT Business Posting Group assigned to the store.';
        }
        field(165; "Store Gen. Bus. Post. Gr."; Code[10])
        {
            Caption = 'Store Gen. Bus. Post. Gr.';
            TableRelation = "Gen. Business Posting Group".Code;
            ObsoleteReason = 'New field "Gen. Bus. Post. Gr." replaces this field.';
            ObsoleteState = Pending;
            ObsoleteTag = '24.0';
            ToolTip = 'Specifies the General Product Posting Group assigned to the store.';
        }
        field(166; "Gen. Bus. Post. Gr."; Code[20])
        {
            Caption = 'Gen. Business Posting Group';
            TableRelation = "Gen. Business Posting Group".Code;
            ToolTip = 'Specifies the General Product Posting Group assigned to the store.';
        }
        field(170; "Language Code"; Code[10])
        {
            Caption = 'Language Code';
            TableRelation = Language;
            ToolTip = 'Specifies the identity code of the language assigned to the store. All POS terminals in the store will use this language code.';
        }
        field(180; "POS Inventory Lookup"; Boolean)
        {
            Caption = 'POS Inventory Lookup';
            ToolTip = 'Specifies if it is possible to perform an Inventory Lookup on the store. The system will manage this for the POS. Note - It is necessary to update this after a change has been made.';
        }
        field(181; "POS Warmup Active"; Boolean)
        {
            Caption = 'POS Warmup Active';
        }
        field(182; "Click and Collect"; Boolean)
        {
            Caption = 'Click and Collect';
            ToolTip = 'Specifies whether this store accepts Click & Collect orders.';
        }
        field(228; "Print Receipt Logo"; Text[80])
        {
            Caption = 'Print Receipt Logo';
        }
        field(229; "Print Receipt Bitmap No."; Integer)
        {
            Caption = 'Print Receipt Bitmap No.';
        }
        field(230; "Rcpt. Text Max. Length"; Integer)
        {
            Caption = 'Rcpt. Text Max. Length';
            InitValue = 39;
            MaxValue = 50;
        }
        field(231; "No. of Top/Bottom Lines"; Integer)
        {
            Caption = 'No. of Top/Bottom Lines';
            InitValue = 10;
        }
        field(232; "Item No. on Receipt"; Enum "LSC Item No. On Receipt")
        {
            Caption = 'Item No. on Receipt';
        }
        field(235; "Last Action for Label Upd"; Integer)
        {
            Caption = 'Last Action for Label Upd';
        }
        field(240; "Last Action for Item Label Upd"; Integer)
        {
            Caption = 'Last Action for Item Label Upd';
        }
        field(245; "No Shelf Label Printing"; Boolean)
        {
            Caption = 'No Shelf Label Printing';
            ToolTip = 'Specifies if shelf labels will be printed for the current store. This is particularly useful for virtual stores - such as the head office - that do not require any label printing.';
        }
        field(250; "No Item Label Printing"; Boolean)
        {
            Caption = 'No Item Label Printing';
            ToolTip = 'Specifies if item labels will be printed for the current store. This is particularly useful for virtual stores - such as the head office - that do not require any label printing.';
        }
        field(503; "Service Charge %"; Decimal)
        {
            Caption = 'Service Charge %';
        }
        field(504; "Serv. Charge. Inc/Exp Acc"; Code[10])
        {
            Caption = 'Serv. Charge. Inc/Exp Acc';
            TableRelation = "LSC Income/Expense Account"."No.";
        }
        field(700; "Project Filter"; Code[10])
        {
            CaptionClass = '1,3,2';
            Caption = 'Project Filter';
            FieldClass = FlowFilter;
            TableRelation = "Dimension Value".Code where("Global Dimension No." = const(2));
        }
        field(701; "Sales (Qty.)"; Decimal)
        {
            CalcFormula = - sum("Value Entry"."Invoiced Quantity" where("Item Ledger Entry Type" = const(Sale),
                                                                        "Posting Date" = field("Date Filter"),
                                                                        "Location Code" = field("Location Code"),
                                                                        "Global Dimension 2 Code" = field("Project Filter")));
            Caption = 'Sales (Qty.)';
            FieldClass = FlowField;
        }
        field(702; "Sales (LCY)"; Decimal)
        {
            CalcFormula = sum("Value Entry"."Sales Amount (Actual)" where("Item Ledger Entry Type" = const(Sale),
                                                                           "Posting Date" = field("Date Filter"),
                                                                           "Location Code" = field("Location Code"),
                                                                           "Global Dimension 2 Code" = field("Project Filter")));
            Caption = 'Sales (LCY)';
            FieldClass = FlowField;
        }
        field(703; "COGS (LCY)"; Decimal)
        {
            CalcFormula = - sum("Value Entry"."Cost Amount (Actual)" where("Item Ledger Entry Type" = const(Sale),
                                                                           "Posting Date" = field("Date Filter"),
                                                                           "Location Code" = field("Location Code"),
                                                                           "Global Dimension 2 Code" = field("Project Filter")));
            Caption = 'COGS (LCY)';
            FieldClass = FlowField;
        }
        field(704; "Date Filter comp."; Date)
        {
            Caption = 'Date Filter comp.';
            FieldClass = FlowFilter;
        }
        field(706; "Sales (LCY) comp."; Decimal)
        {
            CalcFormula = sum("Value Entry"."Sales Amount (Actual)" where("Item Ledger Entry Type" = const(Sale),
                                                                           "Location Code" = field("Location Code"),
                                                                           "Posting Date" = field("Date Filter comp."),
                                                                           "Global Dimension 2 Code" = field("Project Filter")));
            Caption = 'Sales (LCY) comp.';
            FieldClass = FlowField;
        }
        field(707; "COGS (LCY) comp."; Decimal)
        {
            CalcFormula = - sum("Value Entry"."Cost Amount (Actual)" where("Item Ledger Entry Type" = const(Sale),
                                                                           "Location Code" = field("Location Code"),
                                                                           "Posting Date" = field("Date Filter comp."),
                                                                           "Global Dimension 2 Code" = field("Project Filter")));
            Caption = 'COGS (LCY) comp.';
            FieldClass = FlowField;
        }
        field(730; "Safe Mgnt. in Use"; Boolean)
        {
            Caption = 'Safe Mgnt. in Use';

            trigger OnValidate()
            begin
                if "Safe Mgnt. in Use" then
                    if "POS Start Amount Method" = "POS Start Amount Method"::Flexible then
                        Message(
                          POSStartMethodFlexibleMsg, FieldCaption("Safe Mgnt. in Use"), Format("Safe Mgnt. in Use"),
                          FieldCaption("POS Start Amount Method"), Format("POS Start Amount Method"));
            end;
        }
        field(740; Latitude; Decimal)
        {
            Caption = 'Latitude';
            DecimalPlaces = 6 : 6;
            MaxValue = 180;
            MinValue = -180;

            trigger OnValidate()
            begin
                UpdateLocationLongLat();
            end;
        }
        field(741; Longitude; Decimal)
        {
            Caption = 'Longitude';
            DecimalPlaces = 6 : 6;
            MaxValue = 180;
            MinValue = -180;

            trigger OnValidate()
            begin
                UpdateLocationLongLat();
            end;
        }
        field(745; County; Text[30])
        {
            Caption = 'County';
        }
        field(750; Picture; Blob)
        {
            Caption = 'Picture';
            Compressed = false;
            Subtype = Bitmap;
            ObsoleteState = Removed;
            ObsoleteReason = 'Not used. Use retail images instead.';
            ObsoleteTag = '25.0'; // Pending='18.0'
        }
        field(751; "Picture Media"; Media)
        {
            Caption = 'Picture Media';
            ObsoleteState = Removed;
            ObsoleteReason = 'Not used anymore. Use Retail Image Link with Display Order = 10000 instead.';
            ObsoleteTag = '25.0'; // Pending='18.0'
        }
        field(773; "POS Check Z-Report"; Boolean)
        {
            Caption = 'POS Check Z-Report';
            ToolTip = 'Specifies whether the POS checks if the Z-Report was printed for the last business day. If not, the system gives the user an option to print a Z-Report. If the system finds transactions that are not marked Z-Report executed from the last business day, and yet there exist transactions from the current business day, it will prompt the user with the option to run a Z-Report. If the system finds transactions that are not marked Z-Report executed from the last business day, and there are no transactions from the current business day, it will prompt the user with the option to run a Z-Report.';
        }
        field(790; "Store size (square meters)"; Integer)
        {
            Caption = 'Store size (square meters)';
        }
        field(855; "Loading Card Nos."; Code[10])
        {
            Caption = 'Loading Card Nos.';
            TableRelation = "No. Series";
            ToolTip = 'Specifies the number series that is used for loading cards. The loading card number is used to mark a transaction. The customer receives the loading card and by scanning the card, they can add items to the loading card transaction on several POS terminals (located for example in different food stations or different store sections) and then pay for it on a payment receiving POS terminal. After payment is made, the loading card is no longer linked to the transaction and can be handed to the next customer. If KOTs are created for the transaction, the KOTs are identified with the loading card number. The loading card number is a short number that is easy to remember and identify for example on kitchen displays. A loading card can be linked to an MSR card or a barcode mask. The MSR card number or barcode is replaced with the loading card number when marking transactions.';
            ObsoleteReason = 'Use Load. Card Nos. instead';
            ObsoleteState = Pending;
            ObsoleteTag = '27.0';
        }
        field(860; "Receiving Nos."; Code[10])
        {
            Caption = 'Receiving Nos.';
            TableRelation = "No. Series";
            ObsoleteReason = 'Use Receiv. Nos. instead';
            ObsoleteState = Pending;
            ObsoleteTag = '27.0';

            trigger OnValidate()
            begin
                if "Receiving Nos." = '' then
                    "Posted Receiving Nos." := '';

                if "Posted Receiving Nos." = '' then
                    "Posted Receiving Nos." := "Receiving Nos.";
            end;
        }
        field(861; "Posted Receiving Nos."; Code[10])
        {
            Caption = 'Posted Receiving Nos.';
            TableRelation = "No. Series";
            ObsoleteReason = 'Use Posted Receiv. Nos. instead';
            ObsoleteState = Pending;
            ObsoleteTag = '27.0';
        }
        field(863; "Gift Registration Nos."; Code[10])
        {
            Caption = 'Gift Registration Nos.';
            TableRelation = "No. Series";
            ToolTip = 'Specifies the number series used for Gift Registration entries at the store.';
            ObsoleteReason = 'Use Gift Reg. Nos. instead';
            ObsoleteState = Pending;
            ObsoleteTag = '27.0';
        }
        field(864; "Use Batch Posting for Statem."; Boolean)
        {
            Caption = 'Use Batch Posting for Statements';
            ToolTip = 'Specifies whether statements are not posted immediately but sent to the Batch Posting Queue.';
        }
        field(870; "Only Accept Statement"; Boolean)
        {
            Caption = 'Only Accept Statement';
            ToolTip = 'Specifies that statements are not posted at store level but only accepted (confirmed). At any point later the Statements can be posted at Head Office level.';
        }
        field(871; "Max. Diff. to Allow Accept"; Decimal)
        {
            Caption = 'Max. Diff. to Allow Accept';
            MinValue = 0;
            ToolTip = 'Specifies the allowed difference between Sold and Counted.';
        }
        field(872; "Current Hosp. Printing Route"; Code[10])
        {
            Caption = 'Current Hosp. Printing Route';
            TableRelation = "LSC Station Printing Routes".Code;
        }
        field(901; "POS Start Amount Method"; Option)
        {
            Caption = 'POS Start Amount Method';
            Description = '';
            OptionCaption = 'Flexible,Fixed Bag,Flexible Bag';
            OptionMembers = Flexible,"Fixed Bag","Flexible Bag";
            ToolTip = 'Specifies the POS Start Amount Method. Flexible: If Safe Mgmt in Use is marked, it is not recommended to use a Flexible POS Start Amount Method.';
            trigger OnValidate()
            var
                PosFixedStartAmount: Record "LSC POS Fixed Start Amount";
                lText001: Label 'Verify that all %1 linked to %2 are fully configured for %3 %4';
                Text015: Label '%1 for all %2 in %3 will be removed. Continue?';
            begin
                if "POS Start Amount Method" <> xRec."POS Start Amount Method" then begin
                    if "POS Start Amount Method" = "POS Start Amount Method"::Flexible then begin
                        if "Safe Mgnt. in Use" then
                            Message(
                              POSStartMethodFlexibleMsg, FieldCaption("Safe Mgnt. in Use"), Format("Safe Mgnt. in Use"),
                              FieldCaption("POS Start Amount Method"), Format("POS Start Amount Method"));

                        PosFixedStartAmount.SetRange("Store No.", "No.");
                        if PosFixedStartAmount.FindFirst() then begin
                            if Confirm(Text015, true, PosFixedStartAmount.TableCaption, "Statement Method", "No.") then
                                PosFixedStartAmount.DeleteAll(true);
                        end;
                    end;
                    if "POS Start Amount Method" = "POS Start Amount Method"::"Fixed Bag" then begin
                        POSTerminal.Reset();
                        POSTerminal.SetRange("Store No.", "No.");
                        POSTerminal.SetFilter("Safe No.", '<>%1', '');
                        if POSTerminal.FindSet() then
                            Message(lText001, POSTerminal.TableCaption, "No.", FieldCaption("POS Start Amount Method"), "POS Start Amount Method");
                        POSTerminal.Reset();
                    end;
                end;
            end;
        }
        field(903; "POS Post Safe Ledger"; Boolean)
        {
            Caption = 'POS Post Safe Ledger';

            trigger OnValidate()
            var
                SafeTransPost: Codeunit "LSC Safe Transaction-Post";
            begin
                if "POS Post Safe Ledger" then
                    if not xRec."POS Post Safe Ledger" then begin
                        SafeTransPost.SetStoreRec(Rec);
                        SafeTransPost.Run();
                    end;
            end;
        }
        field(990; "Dining Reservation Nos."; Code[10])
        {
            Caption = 'Dining Reservation Nos.';
            TableRelation = "No. Series";
            ToolTip = 'Specifies the number series used for dining reservation entries at this restaurant.';
            ObsoleteReason = 'Use Dining Reserv. Nos. instead';
            ObsoleteState = Pending;
            ObsoleteTag = '27.0';
        }
        field(991; "Dining Waiting List Nos."; Code[10])
        {
            Caption = 'Dining Waiting List Nos.';
            TableRelation = "No. Series";
            ToolTip = 'Specifies the number series used for waiting list dining reservation entries at this restaurant.';
            ObsoleteReason = 'Use Dining Wait. List Nos. instead';
            ObsoleteState = Pending;
            ObsoleteTag = '27.0';
        }
        field(992; "Dining Walk-in Nos."; Code[10])
        {
            Caption = 'Dining Walk-in Nos.';
            TableRelation = "No. Series";
            ToolTip = 'Specifies the number series used for walk-in dining reservation entries at this store. When dining table reservation and allocation are in use, the program creates a walk-in reservation entry for each dining table that is seated without being reserved first. This is for capacity calculation purposes.';
            ObsoleteReason = 'Use Dining Walk-in Nos instead';
            ObsoleteState = Pending;
            ObsoleteTag = '27.0';
        }
        field(996; "KDS Backup Printing"; Option)
        {
            Caption = 'KDS Backup Printing';
            OptionCaption = 'Off,On';
            OptionMembers = Off,On;
            ObsoleteState = Removed;
            ObsoleteReason = 'Not used anymore';
            ObsoleteTag = '25.0'; // Pending='19.1'
        }
        field(997; "Active KDS Load Config."; Code[20])
        {
            Caption = 'Active KDS Load Config.';
            TableRelation = "LSC KDS Load Configuration";
            ToolTip = 'Specifies which KDS Load Configuration is currently active in the store. If set, the program selects the KDS display station mapping for this load configuration when sending items to the kitchen.';
        }
        field(998; "Default Delivery Type"; Enum "LSC Store DefaultDeliveryType")
        {
            Caption = 'Default Delivery Type';
            ToolTip = 'Specifies the default delivery type used by default when creating a new delivery and takeout order for the restaurant.';
        }
        field(999; "Display Del. Type Pop-up"; Boolean)
        {
            Caption = 'Display Del. Type Pop-up';
            ToolTip = 'Specifies whether a delivery type pop-up is displayed when creating a new delivery and takeout order for the restaurant.';
        }
        field(1000; "Orders in Progress"; Integer)
        {
            CalcFormula = count("LSC Delivery Order" where("Restaurant No." = field("No."),
                                                        "General Status" = const("In Process")));
            Caption = 'Orders in Progress';
            Editable = false;
            FieldClass = FlowField;
            ToolTip = 'Specifies the number of delivery orders that are in progress in the restaurant; that is, have the general status In Progress. The program updates the contents of this field automatically, using the General Status field in the Delivery Order table.';
        }
        field(1001; "Estim. Prod. Time"; Decimal)
        {
            CalcFormula = average("LSC Delivery Order"."Gross Prod. Time (Min.)" where("Restaurant No." = field("No."),
                                                                                    "Pre-Order" = const(No),
                                                                                    "General Status" = const(Confirmed)));
            Caption = 'Estim. Prod. Time';
            Editable = false;
            FieldClass = FlowField;
            ToolTip = 'Specifies the estimated production time in minutes for delivery orders in the restaurant at the current time. The program updates the contents of this field automatically with the average of the Gross Prod. Time (Min.) field in the Delivery Order table for all delivery orders that have the general status Confirmed and are not pre-orders.';
        }
        field(1002; "Avg. Prod. Timing (Min.)"; Decimal)
        {
            CalcFormula = average("LSC Posted Delivery Order"."Production Timing (Min.)" where("Restaurant No." = field("No."),
                                                                                            "Pre-Order" = const(No),
                                                                                            "General Status" = filter(<> Cancelled),
                                                                                            "Order Date" = field("Date Filter")));
            Caption = 'Avg. Prod. Timing (Min.)';
            Editable = false;
            FieldClass = FlowField;
            ToolTip = 'Specifies the average production timing of delivery orders for the restaurant in minutes for the selected period. The program updates the contents of this field automatically with the average of the Production Timing (Min.) field in the Posted Delivery Order table for all posted delivery orders that have an order date within the date filter selected, but excluding those that have the general status Cancelled or are pre-orders.';
        }
        field(1003; "Avg. Delivery Timing (Min.)"; Decimal)
        {
            CalcFormula = average("LSC Posted Delivery Order"."Delivery Timing (Min.)" where("Restaurant No." = field("No."),
                                                                                          Delivered = const(true),
                                                                                          "Order Date" = field("Date Filter")));
            Caption = 'Avg. Delivery Timing (Min.)';
            Editable = false;
            FieldClass = FlowField;
            ToolTip = 'Specifies the average delivery timing of the delivery orders in minutes for the selected period. The program updates the contents of this field automatically with the average of the Delivery Timing (Min.) field in the Posted Delivery Order table for all posted delivery orders that were delivered and have an order date within the date filter selected.';
        }
        field(1004; "Receipt Text Filter"; Code[10])
        {
            Caption = 'Receipt Text Filter';
            Description = '';
            FieldClass = FlowFilter;
            TableRelation = "LSC POS Terminal Receipt Head"."No." where("Receipt Setup Location" = const(Store));
        }
        field(1005; "Ordering Status"; Option)
        {
            Caption = 'Ordering Status';
            OptionCaption = 'Open,Temp. Closed';
            OptionMembers = Open,"Temp. Closed";
            ToolTip = 'Specifies the ordering status of the restaurant. Open: The restaurant takes orders for delivery & takeout. Temp. Closed: the restaurant is temporarily closed for ordering and does not take orders for delivery & takeout.';
            trigger OnValidate()
            var
                Text013: Label 'Are you sure you want to change the %1 to %2?';
                Text014: Label 'The %1 was not changed.';
            begin
                if not Confirm(StrSubstNo(Text013, FieldCaption("Ordering Status"), "Ordering Status"), false) then
                    Error(Text014, FieldCaption("Ordering Status"));
            end;
        }
        field(1006; "Delivery/Takeout Change"; Option)
        {
            Caption = 'Delivery/Takeout Change';
            OptionCaption = 'No Printing,Print New,Cancel Old and Print New';
            OptionMembers = "No Printing","Print New","Cancel Old and Print New";
            ToolTip = 'Specifies the action taken in restaurant station printing on delivery/takeout order type change. No Printing: The order is not printed to the restaurant printer stations. The order type is updated if visible on kitchen monitors. Print New: The order is printed to the restaurant printer stations according to the setup for the new order type. The order type is updated if the order is visible on kitchen monitors. Cancel Old and Print New: The order is reprinted as canceled to the restaurant printer stations that have already printed the order. If the order is visible on kitchen monitors, the order is shown as canceled. Then the order is printed again according to restaurant station printing setup as if it were new.';
        }
        field(1007; "Rest. Orders in Progress"; Integer)
        {
            Caption = 'Rest. Orders in Progress';
        }
        field(1008; "Rest. Estim. Prod. Time (Min.)"; Decimal)
        {
            Caption = 'Rest. Estim. Prod. Time (Min.)';
        }
        field(1009; "Kitchen Prod. System in Use"; Enum "LSC Store KitchenPrintingInUse")
        {
            Caption = 'Kitchen Prod. System in Use';
            ToolTip = 'Specifies whether a kitchen production system is in use for this store. No: No system in use for kitchen production for this store. Yes: LS Retail KDS system is used for this store. Retail POS - Printed on Posting: LS Retail KDS system, printers only, are used for this store. The POS is a retail POS with no hospitality types set up and no service flow. Printing to kitchen takes place automatically on posting the transaction, only if there are items routed to kitchen. The kitchen status becomes Served right away. Hosp. order kitchen status and all the KOT tables are created as necessary. A queue counter can be used to mark the transactions and the KOTs.';
            trigger OnValidate()
            var
                HospitalityServiceFlow: Record "LSC Hospitality Service Flow";
                HospSetup: Record "LSC Hospitality Setup";
                HospitalityType: Record "LSC Hospitality Type";
                KDSLoadConfig: Record "LSC KDS Load Configuration";
                KDSNormalLoad: Label 'NORMAL';
                KDSText001: Label 'Are you sure you want to change the %1? No orders will be sent to the KDS if you do.';
                KDSText002: Label 'Change cancelled';
                KitchenTrackingMsg: Label '%1 %2 have %3. Do you want to continue?';
                KitchenTrackingFlow: Text;
            begin
                if "Kitchen Prod. System in Use" = "LSC Store KitchenPrintingInUse"::No then begin
                    if not Confirm(StrSubstNo(KDSText001, FieldName("Kitchen Prod. System in Use"), false)) then
                        Error(KDSText002);
                    HospitalityType.Reset();
                    HospitalityType.SetRange("Restaurant No.", "No.");
                    KitchenTrackingFlow := '';
                    if HospitalityType.FindSet() then
                        repeat
                            if HospitalityServiceFlow.Get(HospitalityType."Service Flow ID") then
                                if HospitalityServiceFlow."Kitchen Order Tracking" then
                                    if StrPos(KitchenTrackingFlow, HospitalityType."Service Flow ID") = 0 then
                                        KitchenTrackingFlow := KitchenTrackingFlow + HospitalityType."Service Flow ID" + ', ';
                        until HospitalityType.Next() = 0;
                    if KitchenTrackingFlow <> '' then
                        if not Confirm(StrSubstNo(KitchenTrackingMsg, HospitalityServiceFlow.TableCaption,
                          CopyStr(KitchenTrackingFlow, 1, StrLen(KitchenTrackingFlow) - 2), HospitalityServiceFlow.FieldCaption("Kitchen Order Tracking"), false))
                        then
                            Error(KDSText002);
                end else begin
                    if not KDSLoadConfig.Get('') then begin
                        KDSLoadConfig.Code := '';
                        KDSLoadConfig.Description := KDSNormalLoad;
                        KDSLoadConfig.Insert(true);
                    end;
                    if not HospSetup.Get() then
                        HospSetup.Insert(true);
                end;
            end;
        }
        field(1010; "Normal Order Timing"; Option)
        {
            Caption = 'Normal Order Timing';
            OptionCaption = 'Use Prod. Timing Scheme,Use Estimated Timing';
            OptionMembers = "Prod. Timing Scheme","Estimated Timing";
            ToolTip = 'Specifies whether the production time calculation for a normal delivery and takeout order (due as ASAP) uses the restaurant production time scheme or the estimated order timing for the restaurant.';
        }
        field(1011; "Max. Order Timing (Min.)"; Integer)
        {
            Caption = 'Max. Order Timing (Min.)';
            ToolTip = 'Specifies the maximum estimated order time used for the production time calculation for a normal delivery and takeout order (due as ASAP). If the estimated order time for the restaurant is more than this maximum, the production calculation uses the restaurant production time scheme instead. If that is not set up, the calculation uses the Order Process Time (Min.) set for the Hospitality Setup.';
        }
        field(1012; "Time Rounding Precision"; Option)
        {
            Caption = 'Time Rounding Precision';
            OptionCaption = 'No Rounding,5 min,10 min,15 min,20 min,30 min';
            OptionMembers = "No Rounding","5 min","10 min","15 min","20 min","30 min";
            ToolTip = 'Specifies the rounding precision when calculating production time for delivery and takeout orders in the restaurant.';
        }
        field(1013; "No. of Staff"; Integer)
        {
            CalcFormula = count("LSC Staff" where("Store Filter" = field("No."),
                                             "Store Links" = filter(> 0)));
            Caption = 'No. of Staff';
            Editable = false;
            FieldClass = FlowField;
            ToolTip = 'Specifies how many staff members are registered for the store.';
        }
        field(1014; "No. of POS Terminals"; Integer)
        {
            CalcFormula = count("LSC POS Terminal" where("Store No." = field("No.")));
            Caption = 'No. of POS Terminals';
            Editable = false;
            FieldClass = FlowField;
            ToolTip = 'Specifies how many POS terminals are set up for the store.';
        }
        field(1015; "Queue Counters in Use"; Boolean)
        {
            CalcFormula = exist("LSC Store Queue Counter" where("Store No." = field("No.")));
            Caption = 'Queue Counters in Use';
            Editable = false;
            FieldClass = FlowField;
            ToolTip = 'Specifies whether queue counters are in use for this store. To check or change the assignment, click the field (Yes or No) to view the Store Queue Counters page.';
        }
        field(1016; "No. of Hospitality Types"; Integer)
        {
            CalcFormula = count("LSC Hospitality Type" where("Restaurant No." = field("No.")));
            Caption = 'No. of Hospitality Types';
            Editable = false;
            FieldClass = FlowField;
            ToolTip = 'Specifies how many hospitality types are set up for the restaurant.';
        }
        field(1017; "No. of Menu Types"; Integer)
        {
            CalcFormula = count("LSC Restaurant Menu Type" where("Restaurant No." = field("No.")));
            Caption = 'No. of Menu Types';
            Editable = false;
            FieldClass = FlowField;
            ToolTip = 'Specifies how many menu types are set up for the restaurant.';
        }
        field(1018; "No. of Dining Areas"; Integer)
        {
            CalcFormula = count("LSC Dining Area" where("Restaurant No." = field("No.")));
            Caption = 'No. of Dining Areas';
            Editable = false;
            FieldClass = FlowField;
            ToolTip = 'Specifies how many dining areas are set up for the restaurant.';
        }
        field(1019; "No. of Menu Courses"; Integer)
        {
            CalcFormula = count("LSC Menu Course" where("Restaurant No." = field("No.")));
            Caption = 'No. of Menu Courses';
            Editable = false;
            FieldClass = FlowField;
            ToolTip = 'Specifies how many menu courses are set up for the restaurant.';
        }
        field(1020; "Allow Member Scanning in Kiosk"; Boolean)
        {
            Caption = 'Allow Member Scanning in Kiosk';
            ObsoleteState = Pending;
            ObsoleteReason = 'Moved to the SSK Profile';
            ObsoleteTag = '24.0';
            ToolTip = 'Specifies whether member card scanning is allowed in the Self Service Kiosk';
        }
        field(1021; "Currency Code in Kiosk"; Code[10])
        {
            Caption = 'Currency Code in Kiosk';
            TableRelation = Currency;
            ObsoleteState = Pending;
            ObsoleteReason = 'Moved to the SSK Profile';
            ObsoleteTag = '24.0';
            ToolTip = 'Specifies the code of the currency used in the Self Service Kiosk. The system uses this field together with the language of the restaurant to select the correct number formatting in the kiosk. This field is mandatory for using the self service kiosk even if the restaurant uses local currency. If the language of the restaurant is not set, the system uses the regional settings language.';
        }
        field(1022; "Display Item HTML in Kiosk"; Boolean)
        {
            Caption = 'Display Item HTML in Kiosk';
            ObsoleteState = Pending;
            ObsoleteReason = 'Moved to the SSK Profile';
            ObsoleteTag = '24.0';
            ToolTip = 'Specifies whether item HTML buttons will be displayed in the Self Service Kiosk.';
        }
        field(1026; "Location Profile"; Code[30])
        {
            Caption = 'Location Profile';
            TableRelation = "LSC Store Location Profiles".ProfileID;
            ToolTip = 'Specifies the location profile that the store belongs to. The store is associated with a set of stores grouped together through location profile.';
            trigger OnValidate()
            var
                InventoryLookupRec: Record "LSC Inventory Lookup Table";
            begin
                InventoryLookupRec.SetRange("Store No.", "No.");
                InventoryLookupRec.ModifyAll("Location Profile", "Location Profile");
            end;
        }
        field(1027; "Location Url"; Text[250])
        {
            Caption = 'Location Url';
        }
        field(1028; LocationUrlExists; Boolean)
        {
            Caption = 'Location Url Exists';
            Editable = false;
            InitValue = false;
            ToolTip = 'This field is for internal use.';
        }
        field(1029; LocationQRCode; Blob)
        {
            Caption = 'LocationQRCode';
            Subtype = Bitmap;
            ObsoleteState = Removed;
            ObsoleteReason = 'Not used anymore. Image is now retrieved from Retail Image Link with Display Order = 20000';
            ObsoleteTag = '25.0'; // Pending='18.0'
        }
        field(1030; "Store Sales Type Filter"; Code[250])
        {
            Caption = 'Store Sales Type Filter';
            Description = '';
            TableRelation = "LSC Sales Type";
            ValidateTableRelation = false;
        }
        field(1031; "Show Availab. on POS Button"; Option)
        {
            Caption = 'Show Availab. on POS Button';
            OptionCaption = 'No,Description,Glyph 1,Glyph 2,Glyph 3,Glyph 4';
            OptionMembers = No,Description,"Glyph 1","Glyph 2","Glyph 3","Glyph 4";
            ToolTip = 'Specifies the position where Availability on POS is shown on a POS Button.';
            trigger OnValidate()
            var
                CurrentAvailabFunctions: Codeunit "LSC Current Availab. Functions";
            begin
                CurrentAvailabFunctions.ValidateCurrAvailabilityPosition(Rec);
            end;
        }
        field(1032; "Last Z-Report"; Code[10])
        {
            Caption = 'Last Z-Report';
            ToolTip = 'Specifies the number of the last Z-Report printed in the Store.';
        }
        field(1033; "Last Y-Report"; Code[10])
        {
            Caption = 'Last Y-Report';
            ToolTip = 'Specifies the number of the last Y-Report printed in the Store.';
        }
        field(1034; "Store KDS in Use"; Enum "LSC KDS ActiveKitchenService")
        {
            Caption = 'Kitchen Service (KDS) in Use';
            ToolTip = 'Specifies the type of KDS service used by this store. The default value is the value set in the Kitchen Service Configuration Card. If this value is changed, it will overrule the value in the cofiguration card. Note that this value only applies to this Store.';

            trigger OnValidate()
            begin
                Logic().Trigger_OnValidate_StoreKDSinUse(Rec, xRec);
            end;
        }
        field(1035; "KDS Service Usage"; Enum "LSC KDS Service Usage")
        {
            Caption = 'KDS Service Usage';
            ToolTip = 'Specifies the type of KDS service used by this store. For the Web KDS: "Poll" means that the Kitchen Service calls the BC to ask for new or modified KOTs. "Push" means that when the order taken and sent to KDS, the KOT is sent from the POS to the Kitchen Service. The Standard KDS can only poll for KOTs.';

            trigger OnValidate()
            begin
                Logic().Trigger_OnValidate_KDSServiceUsage(Rec, xRec);
            end;
        }
        field(1100; "Attrib 1 Code"; Text[30])
        {
            CaptionClass = '98,99001470,1100';
            Caption = 'Attrib 1 Code';

            trigger OnLookup()
            var
                AttributeSetup: Record "LSC Attribute Setup";
                lActionReturned: Action;
                lAnswer: Text[250];
            begin
                AttributeSetup.GetSetup();
                lAnswer := AttributeUtils_g.LookupOptionValues(4, AttributeSetup."Store Attrib. 1 Code", lActionReturned);
                if lActionReturned = ACTION::LookupOK then
                    Validate("Attrib 1 Code", CopyStr(lAnswer, 1, 30));
            end;

            trigger OnValidate()
            begin
                AttributeUtils_g.SoftAttributeMgmt("No.", '', '', Enum::"LSC Attribute Link Type"::Store, 1, "Attrib 1 Code", '');
            end;
        }
        field(1101; "Attrib 2 Code"; Text[30])
        {
            CaptionClass = '98,99001470,1101';
            Caption = 'Attrib 2 Code';

            trigger OnLookup()
            var
                AttributeSetup: Record "LSC Attribute Setup";
                lActionReturned: Action;
                lAnswer: Text[250];
            begin
                AttributeSetup.GetSetup();
                lAnswer := AttributeUtils_g.LookupOptionValues(4, AttributeSetup."Store Attrib. 2 Code", lActionReturned);
                if lActionReturned = ACTION::LookupOK then
                    Validate("Attrib 2 Code", CopyStr(lAnswer, 1, 30));
            end;

            trigger OnValidate()
            begin
                AttributeUtils_g.SoftAttributeMgmt("No.", '', '', Enum::"LSC Attribute Link Type"::Store, 2, "Attrib 2 Code", '');
            end;
        }
        field(1102; "Attrib 3 Code"; Text[30])
        {
            CaptionClass = '98,99001470,1102';
            Caption = 'Attrib 3 Code';

            trigger OnLookup()
            var
                AttributeSetup: Record "LSC Attribute Setup";
                lActionReturned: Action;
                lAnswer: Text[250];
            begin
                AttributeSetup.GetSetup();
                lAnswer := AttributeUtils_g.LookupOptionValues(4, AttributeSetup."Store Attrib. 3 Code", lActionReturned);
                if lActionReturned = ACTION::LookupOK then
                    Validate("Attrib 3 Code", CopyStr(lAnswer, 1, 30));
            end;

            trigger OnValidate()
            begin
                AttributeUtils_g.SoftAttributeMgmt("No.", '', '', Enum::"LSC Attribute Link Type"::Store, 3, "Attrib 3 Code", '');
            end;
        }
        field(1103; "Attrib 4 Code"; Text[30])
        {
            CaptionClass = '98,99001470,1103';
            Caption = 'Attrib 4 Code';

            trigger OnLookup()
            var
                AttributeSetup: Record "LSC Attribute Setup";
                lActionReturned: Action;
                lAnswer: Text[250];
            begin
                AttributeSetup.GetSetup();
                lAnswer := AttributeUtils_g.LookupOptionValues(4, AttributeSetup."Store Attrib. 4 Code", lActionReturned);
                if lActionReturned = ACTION::LookupOK then
                    Validate("Attrib 4 Code", CopyStr(lAnswer, 1, 30));
            end;

            trigger OnValidate()
            begin
                AttributeUtils_g.SoftAttributeMgmt("No.", '', '', Enum::"LSC Attribute Link Type"::Store, 4, "Attrib 4 Code", '');
            end;
        }
        field(1104; "Attrib 5 Code"; Text[30])
        {
            CaptionClass = '98,99001470,1104';
            Caption = 'Attrib 5 Code';

            trigger OnLookup()
            var
                AttributeSetup: Record "LSC Attribute Setup";
                lActionReturned: Action;
                lAnswer: Text[250];
            begin
                AttributeSetup.GetSetup();
                lAnswer := AttributeUtils_g.LookupOptionValues(4, AttributeSetup."Store Attrib. 5 Code", lActionReturned);
                if lActionReturned = ACTION::LookupOK then
                    Validate("Attrib 5 Code", CopyStr(lAnswer, 1, 30));
            end;

            trigger OnValidate()
            begin
                AttributeUtils_g.SoftAttributeMgmt("No.", '', '', Enum::"LSC Attribute Link Type"::Store, 5, "Attrib 5 Code", '');
            end;
        }
        field(1105; "In-Transit Code"; Code[10])
        {
            Caption = 'In-Transit Code';
            TableRelation = Location.Code where("Use As In-Transit" = const(true));
        }
        field(1200; "Web Store"; Boolean)
        {
            Caption = 'Web Store';
            ToolTip = 'Specifies whether this store is a Web Store.';
            trigger OnValidate()
            var
                PosTerminal: Record "LSC POS Terminal";
                Staff: Record "LSC Staff";
                StaffStoreLink: Record "LSC STAFF Store Link";
            begin
                if "Web Store POS Terminal" <> '' then begin
                    if PosTerminal.Get("Web Store POS Terminal") then begin
                        if PosTerminal."Store No." <> "No." then
                            "Web Store POS Terminal" := '';
                    end else
                        "Web Store POS Terminal" := '';
                end;
                if "Web Store Staff ID" <> '' then begin
                    if Staff.Get("Web Store Staff ID") then begin
                        StaffStoreLink.Reset();
                        StaffStoreLink.SetRange("Staff ID", Staff.ID);
                        StaffStoreLink.SetRange("Store No.", "No.");
                        if StaffStoreLink.IsEmpty then
                            "Web Store Staff ID" := '';
                    end else
                        "Web Store Staff ID" := '';
                end;
            end;
        }
        field(1201; "Web Store POS Terminal"; Code[10])
        {
            Caption = 'Web Store POS Terminal';
            TableRelation = "LSC POS Terminal"."No." where("Store No." = field("No."));
            ToolTip = 'Specifies a terminal that is assigned to the web store. The Web Store POS Terminal must be of the Terminal Type POS Terminal. If a terminal of the type Mobile POS is selected, an error message is displayed.';
        }
        field(1202; "Web Store Staff ID"; Code[20])
        {
            Caption = 'Web Store Staff ID';
            TableRelation = "LSC STAFF Store Link"."Staff ID" where("Store No." = field("No."));
            ToolTip = 'Specifies a Staff member that is assigned to the web store. It is selected from the list of Staff assigned to the store.';
        }
        field(1203; "Web Store Customer No."; Code[20])
        {
            Caption = 'Web Store Customer No.';
            NotBlank = true;
            TableRelation = Customer;
            ToolTip = 'Specifies a customer that is assigned to the web store so that standard Sales Orders can be created when sales takes place in the web store. This customer should only be used for this purpose.';
        }
        field(1204; "Web Store Shipping Cost Item"; Code[20])
        {
            Caption = 'Web Store Shipping Cost Item';
            TableRelation = Item."No." where(Type = filter(Service | "Non-Inventory"));
            ToolTip = 'Specifies an item to be used for Shipping Cost.';
        }
        field(1205; Loyalty; Boolean)
        {
            Caption = 'Loyalty';
            ToolTip = 'Specifies whether this store can be used in the LS Commerce Mobile Loyalty app.';
        }
        field(1206; Mobile; Boolean)
        {
            Caption = 'Mobile';
            ToolTip = 'Specifies whether this store can be used in the Mobile POS app.';
        }
        field(1207; "PLU Menu Profile"; Code[10])
        {
            Caption = 'PLU Menu Profile';
            TableRelation = "LSC POS Menu Profile";
            ToolTip = 'Specifies a PLU Menu Profile to use in the Mobile POS app.';
            trigger OnValidate()
            begin
                if "PLU Menu Profile" <> xRec."PLU Menu Profile" then
                    "PLU Menu ID" := '';
            end;
        }
        field(1208; "PLU Menu ID"; Code[10])
        {
            Caption = 'PLU Menu ID';
            TableRelation = "LSC POS Menu Header"."Menu ID" where("Profile ID" = field("PLU Menu Profile"));
            ToolTip = 'Specifies a PLU Menu ID to use in the Mobile POS app.';
        }
        field(1209; "Last Action Entry No."; Integer)
        {
            Caption = 'Last Action Entry No.';
            ToolTip = 'Internal field that specifies the highest Preaction/Action entry no. that data has been collected form. The next time the collection batch is run, it will only investigate entries from that number to the end of the log file (Preaction/Action).';
        }
        field(1210; "Prepay Customer Order"; Enum "LSC CO Prepay Type")
        {
            Caption = 'Prepay Customer Order';
        }
        field(1212; "Customer Order Inc/Expense Acc"; Code[10])
        {
            Caption = 'Customer Order Inc/Expense Acc';
            TableRelation = "LSC Income/Expense Account"."No." where("Store No." = field("No."));
        }
        field(1213; "Cust. Order Inc/Exp Acc Descr."; Text[100])
        {
            CalcFormula = lookup("LSC Income/Expense Account".Description where("No." = field("Customer Order Inc/Expense Acc"),
                                                                             "Account Type" = filter(<> Refund)));
            Caption = 'Cust. Order Inc/Exp Acc Descr.';
            Editable = false;
            FieldClass = FlowField;
        }
        field(1214; "Customer Order Refund Acc"; Code[20])
        {
            Caption = 'Customer Order Refund Acc';
            TableRelation = "LSC Income/Expense Account"."No." where("Store No." = field("No."));
        }
        field(1215; "Cust. Order Refund Acc Descr."; Text[100])
        {
            CalcFormula = lookup("LSC Income/Expense Account".Description where("No." = field("Customer Order Refund Acc")));
            Caption = 'Cust. Order Refund Acc Descr.';
            Editable = false;
            FieldClass = FlowField;
        }
        field(1216; "Cust. Ord. Refund Tender Type"; Code[10])
        {
            Caption = 'Cust. Ord. Refund Tender Type';
            TableRelation = "LSC Tender Type".Code where("Store No." = field("No."));
            ObsoleteState = Removed;
            ObsoleteReason = 'Not used. Info in now taken directly from the original Tender Type.';
            ObsoleteTag = '25.0'; // Pending='19.1'

        }
        field(1217; "Use Shelf Position"; Boolean)
        {
            InitValue = true;
        }
        field(1218; "CO To Pick Indication"; Option)
        {
            Caption = 'Customer Order To Pick Indication';
            ToolTip = 'Specifies how the Customer Order to Pick is calculated. Never: The Customer Order to Pick is not calculated. Interval ( minutes ): The Customer Order to Pick is calculated based on the interval in minutes.';
            OptionCaption = 'Never, Interval ( minutes )';
            OptionMembers = Never,"Interval ( minutes )";

            trigger OnValidate()
            begin
                if "CO To Pick Indication" <> "CO To Pick Indication"::"Interval ( minutes )" then
                    "CO To Pick Interval" := 0;

                if (xRec."CO To Pick Indication" = xRec."CO To Pick Indication"::Never) and
                    ("CO To Pick Indication" <> "CO To Pick Indication"::Never)
                then
                    "CO To Pick Interval" := 1;
            end;
        }
        field(1219; "CO To Pick Interval"; Integer)
        {
            Caption = 'Customer Order To Pick Interval';
            ToolTip = 'Specifies the interval in minutes for the Customer Order to Pick calculation. This field is only used if the Customer Order To Pick Indication is set to Interval ( minutes ).';
            MinValue = 0;
            BlankZero = true;

            trigger OnValidate()
            var
                IntervalError: Label '''Customer Order to Pick Indication'' should be set to ''Interval ( Minutes )'' to be able to set the Interval';
            begin
                if "CO To Pick Indication" <> "CO To Pick Indication"::"Interval ( minutes )" then
                    error(IntervalError);
            end;
        }
        field(1220; "Include SPG in Collect Panel"; Boolean)
        {
            Caption = 'Include ScanPayGo orders in Collect Panel';
            ToolTip = 'Specifies whether Customer Orders created through the "Scan Pay Go" App should be included in the "To Collect" pos panel';
        }
        field(1221; "Calc Inv for Sourcing Location"; Boolean)
        {
            Caption = 'Calculate Inventory for Sourcing Locations';
            ToolTip = 'Specifies if cumulated inventory should be calculated for all Sourcing Locations to the Inventory Lookup Table.';
        }
        field(1222; "Create CLE for Web Customer"; Boolean)
        {
            Caption = 'Create CLE for Web Customer';
            ToolTip = 'Specifies if to create Customer Ledger Entries from Transactions that relates to the Web Store Customer.';
        }
        field(1223; "Skip Printing Tend. Decl. Copy"; Boolean)
        {
            Caption = 'Skip Printing Tender Declaration Copy';
            ToolTip = 'Specifies whether the program should skip printing the Tender Declaration copy for the Store.';
        }
        field(1224; "Customer Order Prepayment Acc"; Code[20])
        {
            ObsoleteState = Pending;
            ObsoleteReason = 'Pending removal. Not used.';
            ObsoleteTag = '27.0';
            Caption = 'Customer Order Prepayment Account';
            TableRelation = "G/L Account"."No.";
            ToolTip = 'Spesifies the account where the prepayment amount is posted when a customer order is paid in advance.';
        }
        field(1225; "Use Prepayment Invoices"; Boolean)
        {
            Caption = 'Use Prepayment Invoices';
            ToolTip = 'Specifies if this Store uses Prepayment Invoices when creating orders with Customer account.';
        }
        field(1300; "No. Series."; Code[20])
        {
            Caption = 'No. Series';
            TableRelation = "No. Series";
        }
        field(1301; "Statement No. Series"; Code[20])
        {
            Caption = 'Statement Nos.';
            TableRelation = "No. Series";
            ToolTip = 'Specifies the number series for the statement in the store. This field must be filled in for proper functionality. Each store needs to have its own statement number series. If you are posting statements in a database, the Local Store No. in the Retail Setup table must be a store. The statement number series for this store must have a relationship to statement no. series for all other stores that you are posting statements in the database for, so you can select the correct number series for the store that you are creating a statement for.';
        }
        field(1302; "Posted Statement Nos."; Code[20])
        {
            Caption = 'Posted Statem. Nos';
            TableRelation = "No. Series";
            ToolTip = 'Specifies the number series for posted statements in the store. This field must be filled in for proper functionality. Each store needs to have its own statement number series. If you are posting statements in a database, the Local Store No. in the Retail Setup table must be a store. The statement number series for this store must have a relationship to statement no. series for all other stores that you are posting statements in the database for, so you can select the correct number series for the store that you are creating a statement for.';
        }
        field(1303; "Load. Card Nos."; Code[20])
        {
            Caption = 'Loading Card Nos.';
            TableRelation = "No. Series";
            ToolTip = 'Specifies the number series that is used for loading cards. The loading card number is used to mark a transaction. The customer receives the loading card and by scanning the card, they can add items to the loading card transaction on several POS terminals (located for example in different food stations or different store sections) and then pay for it on a payment receiving POS terminal. After payment is made, the loading card is no longer linked to the transaction and can be handed to the next customer. If KOTs are created for the transaction, the KOTs are identified with the loading card number. The loading card number is a short number that is easy to remember and identify for example on kitchen displays. A loading card can be linked to an MSR card or a barcode mask. The MSR card number or barcode is replaced with the loading card number when marking transactions.';
        }
        field(1304; "Receiv. Nos."; Code[20])
        {
            Caption = 'Receiving Nos.';
            TableRelation = "No. Series";

            trigger OnValidate()
            begin
                if "Receiv. Nos." = '' then
                    "Posted Receiv. Nos." := '';

                if "Posted Receiv. Nos." = '' then
                    "Posted Receiv. Nos." := "Receiv. Nos.";
            end;
        }
        field(1305; "Posted Receiv. Nos."; Code[20])
        {
            Caption = 'Posted Receiving Nos.';
            TableRelation = "No. Series";
        }
        field(1306; "Gift Reg. Nos."; Code[20])
        {
            Caption = 'Gift Registration Nos.';
            TableRelation = "No. Series";
            ToolTip = 'Specifies the number series used for Gift Registration entries at the store.';
        }
        field(1307; "Dining Reserv. Nos."; Code[20])
        {
            Caption = 'Dining Reservation Nos.';
            TableRelation = "No. Series";
            ToolTip = 'Specifies the number series used for dining reservation entries at this restaurant.';
        }
        field(1308; "Dining Wait. List Nos."; Code[20])
        {
            Caption = 'Dining Waiting List Nos.';
            TableRelation = "No. Series";
            ToolTip = 'Specifies the number series used for waiting list dining reservation entries at this restaurant.';
        }
        field(1309; "Dining Walk-in Nos"; Code[20])
        {
            Caption = 'Dining Walk-in Nos.';
            TableRelation = "No. Series";
            ToolTip = 'Specifies the number series used for walk-in dining reservation entries at this store. When dining table reservation and allocation are in use, the program creates a walk-in reservation entry for each dining table that is seated without being reserved first. This is for capacity calculation purposes.';
        }

        field(10000; "Tax Area Code"; Code[20])
        {
            Caption = 'Tax Area Code';
            ObsoleteState = Pending;
            ObsoleteReason = 'Pending removal. Moved to NA repository.';
            ObsoleteTag = '25.0';
            TableRelation = "Tax Area";
        }
        field(10005; "Tax Liable"; Boolean)
        {
            Caption = 'Tax Liable';
            ObsoleteState = Pending;
            ObsoleteReason = 'Pending removal. Moved to NA repository.';
            ObsoleteTag = '25.0';
        }
        field(10009; "F&B Finalized Orders"; Integer)
        {
            CalcFormula = count("LSC Finalized FAB Order" where("Store No." = field("No."),
                                                        "Order Status" = filter(Finalized),
                                                        "Pickup Date" = field("Date Filter")));

            Caption = 'F&&B Finalized Orders';
            Editable = false;
            FieldClass = FlowField;
        }
        field(10010; "F&B No-Show Orders"; Integer)
        {
            CalcFormula = count("LSC Finalized FAB Order" where("Store No." = field("No."),
                                                        "Order Status" = filter("No-Show"),
                                                        "Pickup Date" = field("Date Filter")));

            Caption = 'F&&B No-Show Orders';
            Editable = false;
            FieldClass = FlowField;
        }
        field(10011; "F&B Paid Orders"; Integer)
        {
            CalcFormula = count("LSC Food & Beverage Order" where("Store No." = field("No."),
                                                        "Order Status" = filter(Paid),
                                                        "Pickup Date" = field("Date Filter"),
                                                       PreOrder = filter(false)));

            Caption = 'F&&B Paid Orders';
            Editable = false;
            FieldClass = FlowField;
        }
        field(10012; "F&B Unpaid Orders"; Integer)
        {
            CalcFormula = count("LSC Food & Beverage Order" where("Store No." = field("No."),
                                                        "Order Status" = filter(Unpaid),
                                                        "Pickup Date" = field("Date Filter"),
                                                        PreOrder = filter(false)));
            Caption = 'F&&B Unpaid Orders';
            Editable = false;
            FieldClass = FlowField;
        }
        field(10013; "F&B Preorders"; Integer)
        {
            CalcFormula = count("LSC Food & Beverage Order" where("Store No." = field("No."),
                                                        PreOrder = filter(true)));
            Caption = 'F&&B Preorders';
            Editable = false;
            FieldClass = FlowField;
        }
        field(10014; "Use F&B Order Structure"; Boolean)
        {
            Caption = 'Use F&B Order Structure';
            ToolTip = 'Specifies whether the store is using the Food & Beverages order structure for its takeaway orders. Note that delivery orders cannot be created if F&B order structure is used.';
        }
        field(20000; "LS Recommend Batch No."; Code[20])
        {
            Caption = 'LS Recommend Batch No.';
            // TableRelation = "LSC Recomm. Batch" where(Active = const(true), "Sync. Action" = filter(0 | 2));
            ObsoleteState = Removed;
            ObsoleteReason = 'Pending removal. Discontinued feature';
            ObsoleteTag = '25.0'; // Pending='22.0'
        }
        field(20001; "Recommendation API URL"; Code[20])
        {
            Caption = 'Recommendation API URL';
            TableRelation = "LSC Recomm. API URL";
            ObsoleteState = Removed;
            ObsoleteReason = 'Pending removal. Discontinued feature';
            ObsoleteTag = '25.0'; // Pending='22.0'
        }
        field(10038905; "PLB Store"; Boolean)
        {
            Caption = 'PLB Store';
            trigger OnValidate()
            var
                PLBSetup: Record "LSC PLB Setup";
                PLBnotEnabledError: Label 'PLB funtionality must be enabled in PLB Setup';
            begin
                if (xrec."PLB Store" <> rec."PLB Store") and (Rec."PLB Store") then begin
                    PLBSetup.Get();
                    if not PLBSetup."Enable PLB" then
                        error(PLBnotEnabledError);
                end;
            end;
        }
        field(10044565; "Tax Group Code (Limitation)"; Code[20])
        {
            Caption = 'Tax Group Code (Limitation)';
            TableRelation = "Tax Group";
            ObsoleteState = Pending;//This was left out in the previous obsoletion
            ObsoleteReason = 'Pending removal. Moved to NA repository.';
            ObsoleteTag = '25.0';
            ToolTip = 'Specifies the Tax Group Code for limitation tax exempted in POS Trans. Line.';
        }
        field(10044566; "VAT Prod Post Grp (Limitation)"; Code[20])
        {
            Caption = 'VAT Prod. Posting Group (Limitation)';
            TableRelation = "VAT Product Posting Group";
            ToolTip = 'Specifies the VAT Product Posting Group for limitation tax exempted in POS Trans. Line.';
        }
        field(10044567; "Split Order on Load Balancing"; Boolean)
        {
            Caption = 'Split Order on Load Balancing';
            ToolTip = 'Specifies whether the incoming order is allowed to split, that is, whether the items can be bumped to different stations.';
        }
        field(10044568; "Synchronized Production Time"; Boolean)
        {
            Caption = 'Synchronized Production Time';
            ToolTip = 'Specifies whether production time of items is synchronized, ensuring that all items in a KOT are ready at the same time.';
        }
        field(10044569; "Show Routed Items Only"; Boolean)
        {
            Caption = 'Show Routed Items Only';
            ToolTip = 'Specifies whether the KOT shows only items that have routing.';
        }
    }

    keys
    {
        key(Key1; "No.")
        {
            Clustered = true;
        }
        key(Key2; "Location Code")
        {
        }
        key(Key3; "Fraud Sort Field")
        {
        }
    }

    trigger OnDelete()
    var
        AttributeValue: Record "LSC Attribute Value";
        CashDecl: Record "LSC Cash Declaration Setup";
        IncomeExpenseAcc: Record "LSC Income/Expense Account";
        ReceiptText: Record "LSC POS Terminal Receipt Text";
        HierarchyDefaults: Record "LSC Retail Hierar. Defaults";
        ImageLink: Record "LSC Retail Image Link";
        SecurityCheckProfile: Record "LSC Security Check Profile";
        lStoreLocation: Record "LSC Store Location";
        StoreSection: Record "LSC Store Section";
        TenderType: Record "LSC Tender Type";
        WorkShiftSetup: Record "LSC Work Shift Setup";
        RecRef: RecordRef;
        Text005: Label 'You cannot delete because %1 %2 belongs to this store.';
        Text006: Label 'There are staff members assigned to the %1. \';
        Text007: Label 'Do you want the system to delete that assignment?';
    begin
        POSTerminal.Reset();
        POSTerminal.SetCurrentKey("Store No.");
        POSTerminal.SetRange("Store No.", "No.");
        if POSTerminal.FindFirst() then
            Error(Text005, POSTerminal.TableCaption, POSTerminal."No.");

        Staff.SetCurrentKey("Store No.");
        Staff.SetRange("Store No.", "No.");
        if Staff.FindSet() then
            if Confirm(Text006 + Text007, true, TableCaption) then
                repeat
                    Staff."Store No." := '';
                    Staff.Modify(true);
                until Staff.Next() = 0;

        StoreSection.Reset();
        StoreSection.SetRange("Store No.", "No.");
        StoreSection.DeleteAll(true);

        repeat
            WorkShiftSetup.SetRange("Store No.", "No.");
            if WorkShiftSetup.FindLast() then
                if WorkShiftSetup.Delete(true) then;
        until WorkShiftSetup.Count = 0;

        TenderType.SetRange("Store No.", "No.");
        TenderType.DeleteAll(true);

        IncomeExpenseAcc.SetRange("Store No.", "No.");
        IncomeExpenseAcc.DeleteAll(true);

        if DistrLocation.Get("No.") then
            DistrLocation.Delete(true);

        ReceiptText.Reset();
        ReceiptText.SetRange(Relation, ReceiptText.Relation::Terminal);
        ReceiptText.SetRange(Number, "No.");
        ReceiptText.DeleteAll(true);

        CashDecl.Reset();
        CashDecl.SetRange("Store No.", "No.");
        CashDecl.DeleteAll(true);

        if DefaultDim.WritePermission then
            DimMgt.DeleteDefaultDim(Database::"LSC Store", "No.");

        HierarchyDefaults.Reset();
        HierarchyDefaults.SetRange(HierarchyDefaults."Table ID", 99001470);
        HierarchyDefaults.SetRange(HierarchyDefaults."No.", "No.");
        HierarchyDefaults.DeleteAll(true);

        lStoreLocation.Reset();
        lStoreLocation.SetRange("Store No.", "No.");
        lStoreLocation.DeleteAll(true);

        RecRef.GetTable(Rec);
        ImageLink.SetFilter("Record Id", Format(RecRef.RecordId));
        ImageLink.DeleteAll();

        AttributeValue.Reset();
        AttributeValue.SetRange("Link Type", AttributeValue."Link Type"::Store);
        AttributeValue.SetRange("Link Field 1", "No.");
        AttributeValue.DeleteAll(true);

        SecurityCheckProfile.Reset();
        SecurityCheckProfile.SetRange(Code, "No.");
        SecurityCheckProfile.DeleteAll(true);
    end;

    trigger OnInsert()
    var
        StaffManagementFunctions: Codeunit "LSC STAFF Functions";
        Text000: Label '%1 with %2 %3 already exists. It is not allowed to assign ';
        Text001: Label 'the same %2 to %1 and %4. Please choose another %2 or select ';
        Text002: Label 'another number series for the %4.';
        Text003: Label '%1 with %2 %3 already exists. \It will now represent this %4.';
    begin
        if "No." = '' then begin
            BackOfficeSetup.Get();
            BackOfficeSetup.TestField(BackOfficeSetup."Store No. Nos.");
            "No. Series." := BackOfficeSetup."Store No. Nos.";
            if NoSeries.AreRelated(BackOfficeSetup."Store No. Nos.", xRec."No. Series.") then
                "No. Series." := xRec."No. Series.";
            "No." := NoSeries.GetNextNo("No. Series.", 0D);
        end;

        if POSTerminal.Get("No.") then
            Error(StrSubstNo(Text000 + Text001 + Text002,
              POSTerminal.TableCaption, POSTerminal.FieldCaption("No."), POSTerminal."No.",
              Store.TableCaption));

        if not DistrLocation.Get("No.") then begin
            DistrLocation.Code := "No.";
            DistrLocation.Insert(true);
        end else
            if GuiAllowed() then
                Message(Text003, DistrLocation.TableCaption, DistrLocation.FieldCaption(Code), "No.", TableCaption);

        if DefaultDim.ReadPermission then
            DimMgt.UpdateDefaultDim(
              Database::"LSC Store", "No.",
              "Global Dimension 1 Code", "Global Dimension 2 Code");
    end;

    trigger OnModify()
    var
        StaffManagementFunctions: Codeunit "LSC STAFF Functions";
    begin

        "Last Date Modified" := Today;
    end;

    trigger OnRename()
    begin
        DimMgt.RenameDefaultDim(DATABASE::"LSC Store", xRec."No.", "No.");

        if DistrLocation.Get(xRec."No.") then
            DistrLocation.Rename("No.");

        "Last Date Modified" := Today;
    end;

    var
        DefaultDim: Record "Default Dimension";
        DistrLocation: Record "LSC Distribution Location";
        POSTerminal: Record "LSC POS Terminal";
        BackOfficeSetup: Record "LSC Retail Setup";
        Staff: Record "LSC Staff";
        Store: Record "LSC Store";
        PostCode: Record "Post Code";
        DimMgt: Codeunit DimensionManagement;
        AttributeUtils_g: Codeunit "LSC Attribute Utils";
        BOUtils: Codeunit "LSC BO Utils";
        NoSeries: Codeunit "No. Series";
        _logicDefined: Boolean;
        _logic: Interface "LSC IStore";
        POSStartMethodFlexibleMsg: Label '%1 is %2. Having %3 as %4 is not recommended. ';

    #region implelement logic
    local procedure Logic(): Interface "LSC IStore"
    var
        Default: Codeunit "LSC Store Logic";
    begin
        if not _logicDefined then
            Define(Default);

        exit(_logic);
    end;

    internal procedure Define(Implementation: Interface "LSC IStore")
    begin
        _logic := Implementation;
        _logicDefined := true;
    end;
    #endregion implelement logic

    internal procedure FindStoreFromLocation(var NewStore: Record "LSC Store"; LocationCode: Code[20]): Boolean
    begin
        exit(Logic().FindStoreFromLocation(Rec, NewStore, LocationCode));
    end;

    procedure VerifyPostingSetup()
    begin
        Logic().VerifyPostingSetup(Rec);
    end;

    internal procedure AssistEdit(OldStore: Record "LSC Store"): Boolean
    var
        Store: Record "LSC Store";
    begin
        Store := Rec;
        BackOfficeSetup.Get();
        BackOfficeSetup.TestField(BackOfficeSetup."Store No. Nos.");
        if NoSeries.LookupRelatedNoSeries(BackOfficeSetup."Store No. Nos.", Store."No. Series.") then begin
            Store."No." := NoSeries.GetNextNo(Store."No. Series.");
            Rec := Store;
            exit(true);
        end;
    end;

    local procedure ValidateShortcutDimCode(FieldNumber: Integer; var ShortcutDimCode: Code[20])
    begin
        DimMgt.ValidateDimValueCode(FieldNumber, ShortcutDimCode);
        DimMgt.SaveDefaultDim(Database::"LSC Store", "No.", FieldNumber, ShortcutDimCode);
        Modify();
    end;

    procedure FindStore(pLocation: Code[20]; var pStoreRec: Record "LSC Store"): Boolean
    var
        xStoreLocation: Record "LSC Store Location";
    begin
        xStoreLocation.Reset();
        xStoreLocation.SetRange("Location Code", pLocation);
        if xStoreLocation.FindFirst() then begin
            pStoreRec.Get(xStoreLocation."Store No.");
            exit(true);
        end else begin
            pStoreRec.Reset();
            pStoreRec.SetCurrentKey("Location Code");
            pStoreRec.SetRange("Location Code", pLocation);
            if pStoreRec.FindFirst() then begin
                exit(true);
            end
            else begin
                Clear(pStoreRec);
                exit(false);
            end;
        end;
    end;

    internal procedure UpdateInventoryLookup()
    var
        TSUtil: Codeunit "LSC POS Trans. Server Utility";
        result: Integer;
        LOOKUP_DISABLED: Label 'POS Inventory Lookup is not enabled for this store';
        PROMPT_INVUPDATE: Label 'Update POS Inventory Lookup for all stores,Update POS Inventory Lookup for Store %1 only';
        optionStr: Text[250];
    begin
        // Updates the POS Inventory Lookup table for either all stores or the selected store
        optionStr := StrSubstNo(PROMPT_INVUPDATE, "No.");
        result := StrMenu(optionStr, 2);

        if result = 0 then
            exit;

        if result = 1 then
            TSUtil.UpdateLookupTableQuery('', '', '', '')
        else begin
            if not "POS Inventory Lookup" then
                Error(LOOKUP_DISABLED);
            TSUtil.UpdateLookupTableQuery('', "No.", '', '');
        end;
    end;

    internal procedure CalcOpeningHours()
    var
        Date: Record Date;
        MobileStoreOpeningHours: Record "LSC Mobile Store Opening Hours";
        RetailCalendarManagement: Codeunit "LSC Retail Calendar Management";
        OpenAfterMidnight: Boolean;
        EndOfWeek: Date;
        Tomorrow: Date;
        CalendarType: Enum "LSC Retail Calendar Type";
        TimeFrom: Time;
        TimeTo: Time;
    begin
        EndOfWeek := CalcDate('<+6D>', Today);

        Date.SetRange("Period Type", Date."Period Type"::Date);
        Date.SetRange("Period Start", Today, EndOfWeek);

        if Date.FindSet() then
            repeat
                if RetailCalendarManagement.GetStoreOpenFromTo(
                  Rec."No.", CalendarType::"Opening Hours", Date."Period Start", TimeFrom, TimeTo, OpenAfterMidnight)
                then begin
                    if not MobileStoreOpeningHours.Get("No.", Date."Period No.") then begin
                        MobileStoreOpeningHours.Init();
                        MobileStoreOpeningHours.StoreId := "No.";
                        MobileStoreOpeningHours.DayOfWeek := Date."Period No.";
                        MobileStoreOpeningHours.Insert(true);
                    end;
                    MobileStoreOpeningHours.NameOfDay := Date."Period Name";
                    MobileStoreOpeningHours.OpenFrom := CreateDateTime(Date."Period Start", TimeFrom);
                    if OpenAfterMidnight then begin
                        Tomorrow := CalcDate('<+1D>', Date."Period Start");
                        MobileStoreOpeningHours.OpenTo := CreateDateTime(Tomorrow, TimeTo);
                    end else
                        MobileStoreOpeningHours.OpenTo := CreateDateTime(Date."Period Start", TimeTo);
                    MobileStoreOpeningHours.Modify(true);
                end;
            until Date.Next() = 0;
    end;

    procedure CalcOpeningHoursPublic()
    begin
        CalcOpeningHours();
    end;

    local procedure UpdateSourcingLocations()
    var
        COSourcingLocations: Record "LSC CO Sourcing Locations";
    begin
        COSourcingLocations.SetRange("Delivery Store", "No.");
        COSourcingLocations.SetRange("Sourcing Location", "Location Code");
        if COSourcingLocations.FindFirst() then
            COSourcingLocations.Delete();
    end;

    internal procedure DisplayMap()
    var
        MapPoint: Record "Online Map Setup";
        MapMgt: Codeunit "Online Map Management";
        OnlineMapMsg: Label 'Before you can use Online Map, you must fill in the Online Map Setup window.\See Setting Up Online Map in Help.';
    begin
        if not MapPoint.IsEmpty() then
            MapMgt.MakeSelection(Database::"LSC Store", GetPosition)
        else
            Message(OnlineMapMsg);
    end;

    internal procedure UpdateLocationLongLat()
    var
        Location: Record Location;
        LocationAddress: Text;
        StoreAddress: Text;
    begin
        if "Location Code" <> '' then
            if Location.Get("Location Code") then begin
                StoreAddress := UpperCase(Address + "Address 2" + "Post Code" + City + "Country Code");
                LocationAddress := UpperCase(Location.Address + Location."Address 2" + Location."Post Code" + Location.City + Location."Country/Region Code");
                if StoreAddress = LocationAddress then begin
                    Location."LSC Latitude" := Latitude;
                    Location."LSC Longitude" := Longitude;
                    Location.Modify(true);
                end;
            end;
    end;

    [IntegrationEvent(false, false)]
    internal procedure OnBeforeValidateLocationCode(var isHandled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    internal procedure OnBeforeVerifyPostingSetup(Store: Record "LSC Store"; var IsHandled: boolean)
    begin
    end;
}

