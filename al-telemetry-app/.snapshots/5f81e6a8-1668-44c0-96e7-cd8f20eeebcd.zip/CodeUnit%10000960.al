codeunit 10000960 "LSC Session Key Values"
{
    SingleInstance = true;

    var
        SessionKeyValue: Dictionary of [Code[20], Text[250]];

    procedure SetValue(Key_p: Code[20]; Value_p: Text[250])
    begin
        if SessionKeyValue.ContainsKey(Key_p) then
            SessionKeyValue.Set(Key_p, Value_p)
        else
            SessionKeyValue.Add(Key_p, Value_p);
    end;

    procedure GetValue(Key_p: Code[20]): Text[250]
    begin
        if SessionKeyValue.ContainsKey(Key_p) then
            exit(SessionKeyValue.Get(Key_p))
        else
            exit('');
    end;

    procedure DeleteValue(Key_p: Code[20])
    begin
        if SessionKeyValue.ContainsKey(Key_p) then
            SessionKeyValue.Remove(Key_p);
    end;
}

