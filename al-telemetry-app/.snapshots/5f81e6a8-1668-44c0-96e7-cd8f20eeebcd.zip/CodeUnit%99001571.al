codeunit 99001571 "LSC POS Trans. Lines" implements "LSC IPOSTransLines"
{
    SingleInstance = true;

    var
        REC: Record "LSC POS Trans. Line";
        POSSESSION: Codeunit "LSC POS Session";
        LSJournalDataSet: array[2] of Codeunit "LSC DataSet";
        JournalDataSet: array[2] of Codeunit "LSC POS DataSet Utility";
        LastTimestamp: BigInteger;
        LastCount: Integer;
        CurrCover: Integer;

    procedure GetCurrentLine(var CurrRec: Record "LSC POS Trans. Line")
    begin
        if not REC.Get(Rec."Receipt No.", Rec."Line No.") then
            Clear(REC);
        CurrRec := REC;
    end;

    procedure GetCurrentLineNo(): Integer
    begin
        exit(REC."Line No.");
    end;

    procedure SetCurrentLine(var NewRec: Record "LSC POS Trans. Line")
    begin
        REC := NewRec;
        LastCount := 0;
        LastTimestamp := 0;
        POSSESSION.SetValue("LSC POS Tag"::"Current_JNL_Desc", REC.Description);
    end;

    internal procedure DelRecord(var DelRec: Record "LSC POS Trans. Line")
    begin
        if DelRec.Get(DelRec."Receipt No.", DelRec."Line No.") then
            DelRec.Delete;
    end;

    [Obsolete('Not used', '26.0')]
    procedure UpdateAll()
    begin
    end;

    procedure SetCurrentLineNo(pReceiptNo: Code[20]; pLineNo: Integer)
    begin
        if not REC.Get(pReceiptNo, pLineNo) then
            Clear(REC);
        POSSESSION.SetValue("LSC POS Tag"::"Current_JNL_Desc", REC.Description);
    end;

    internal procedure SetFilterCover(Cover: Integer; pReceiptNo: Code[20])
    var
        TmpRec: Record "LSC POS Trans. Line";
    begin
        if pReceiptNo = '' then
            exit;

        CurrCover := Cover;
        if CurrCover <> 0 then begin
            TmpRec.SetRange("Receipt No.", pReceiptNo);
            TmpRec.ModifyAll(Marked, false);
            TmpRec.SetRange("Guest/Seat No.", CurrCover);
            TmpRec.ModifyAll(Marked, true);
        end
        else begin
            TmpRec.SetRange("Receipt No.", pReceiptNo);
            REC.SetRange("Guest/Seat No.");
            REC.ModifyAll(Marked, false);
        end;
    end;

    internal procedure GetFilterCover(): Integer
    begin
        exit(CurrCover);
    end;

    internal procedure ClearCurrentLine()
    begin
        Clear(REC);
    end;

    internal procedure InitJournalDataSet(pJournalSetupIndex: Integer)
    var
        InterfaceProfileLocal: Record "LSC POS Interface Profile";
        JournalColumnSetup: Record "LSC POS Data Table";
        JournalColumnsInitialized: Boolean;
    begin
        if pJournalSetupIndex < 1 then
            pJournalSetupIndex := 1;
        if pJournalSetupIndex > 2 then
            pJournalSetupIndex := 2;

        InterfaceProfileLocal := POSSESSION.InterfaceProfile;
        if pJournalSetupIndex = 2 then
            if InterfaceProfileLocal.ID <> POSSession.Terminal."Dual Disp. Interface Profile" then
                InterfaceProfileLocal.Get(POSSession.Terminal."Dual Disp. Interface Profile");
        if InterfaceProfileLocal.ID = '' then
            InterfaceProfileLocal.Get(Format("LSC POS Profile Id"::DefaultInterface));

        JournalDataSet[pJournalSetupIndex].InitDataSet;

        if InterfaceProfileLocal."Journal Data Table ID" <> '' then begin
            if JournalColumnSetup.Get(InterfaceProfileLocal."Journal Data Table ID") then begin
                JournalDataSet[pJournalSetupIndex].SetTable(JournalColumnSetup."Table No.");
                JournalDataSet[pJournalSetupIndex].InitDataTable(JournalColumnSetup);
                JournalColumnsInitialized := true;
            end;
        end;

        if not JournalColumnsInitialized then begin
            JournalDataSet[pJournalSetupIndex].SetTable(REC.RecordId.TableNo);
            JournalDataSet[pJournalSetupIndex].AddDatasetField(false, 1, REC.FieldNo("Description"), 1, 0);
            JournalDataSet[pJournalSetupIndex].AddDatasetField(false, 2, REC.FieldNo("Quantity"), 2, 3);
            JournalDataSet[pJournalSetupIndex].AddDatasetField(false, 3, REC.FieldNo("Price"), 2, 2);
            JournalDataSet[pJournalSetupIndex].AddDatasetField(false, 4, REC.FieldNo("Discount %"), 2, 0);
            JournalDataSet[pJournalSetupIndex].AddDatasetField(false, 5, REC.FieldNo("Amount"), 2, 1);
            JournalDataSet[pJournalSetupIndex].SetVisibleColumns(5);
        end;

        if InterfaceProfileLocal."Hide Voided Lines" then
            JournalDataSet[pJournalSetupIndex].SetFixedFilter(REC.FieldNo("Entry Status"), '<>1');

        JournalDataSet[pJournalSetupIndex].SetFixedFilter(REC.FieldNo("View Line in Journal"), '0');
        JournalDataSet[pJournalSetupIndex].SetJournalMode(true);

        if InterfaceProfileLocal."No. of Journal Lines" < 2 then
            LSJournalDataSet[pJournalSetupIndex].DbTablePageSize := 10 //DEFAULT
        else
            LSJournalDataSet[pJournalSetupIndex].DbTablePageSize := InterfaceProfileLocal."No. of Journal Lines";

        JournalDataSet[pJournalSetupIndex].SetSearchType("LSC POS DataTable Search Type"::Whole);

        JournalDataSet[pJournalSetupIndex].SetMaxPages(1400);
    end;

    internal procedure LoadJournalLines(pReceiptNo: Code[20]; var LSDataSetRef: Codeunit "LSC DataSet"; pJournalSetupIndex: Integer; pCurrJournalPage: Integer): Boolean
    var
        pageLimit: Integer;
        startPageIndex: Integer;
        startRowIndex: Integer;
    begin
        if GetCurrentLineNo() > 0 then
            JournalDataSet[pJournalSetupIndex].SetJournalLineNoAndType(GetCurrentLineNo, REC."Entry Type".AsInteger());

        JournalDataSet[pJournalSetupIndex].SetFixedFilter(3, pReceiptNo);

        if GetCurrentLineNo() > 0 then
            LSJournalDataSet[pJournalSetupIndex].GoToRowIndex := JournalDataSet[pJournalSetupIndex].FindByField(2, Format(GetCurrentLineNo())) - 1;

        pageLimit := 12; // Note: before this was hardcoded in POSSESSION.JournalUpdatePageLimit;

        if (pCurrJournalPage <= 0) or (pageLimit <= 0) then begin //LOAD FULL DATASET IN JOURNAL //BACKWARD COMPATIBILITY WITH OLDER TOOLBOXES
            JournalDataSet[pJournalSetupIndex].FillDataSet(false, LSJournalDataSet[pJournalSetupIndex], true);
        end
        else begin //LOAD DATA FOR THE CURRENT JOURNAL PAGE +/-
            if LSJournalDataSet[pJournalSetupIndex].GetGoToRowIndex() >= 0 then  //Set/override the CurrPage if we have GoToRowIndex
                pCurrJournalPage := Round(LSJournalDataSet[pJournalSetupIndex].GetGoToRowIndex() / LSJournalDataSet[pJournalSetupIndex].GetDBTablePageSize(), 1);

            if pCurrJournalPage > Abs(pageLimit / 2) then
                startPageIndex := pCurrJournalPage - 1 - Abs(pageLimit / 2);

            if startPageIndex < 0 then
                startPageIndex := 0;

            startRowIndex := startPageIndex * LSJournalDataSet[pJournalSetupIndex].GetDBTablePageSize();

            JournalDataSet[pJournalSetupIndex].FillDataSetRowsEx(false, LSJournalDataSet[pJournalSetupIndex], startRowIndex + 1, LSJournalDataSet[pJournalSetupIndex].GetDBTablePageSize() * pageLimit, true, false);

            LSJournalDataSet[pJournalSetupIndex].StartPageNo := startPageIndex;
            LSJournalDataSet[pJournalSetupIndex].PageCount := pageLimit;
        end;

        LSDataSetRef := LSJournalDataSet[pJournalSetupIndex];
    end;

    internal procedure UpdateSelectedJournalLine(rowIndex: Integer; pJournalSetupIndex: Integer)
    var
        TmpRecID: RecordID;
        SelectedLineRec: Record "LSC POS Trans. Line";
    begin
        if rowIndex < 0 then
            exit;

        JournalDataSet[pJournalSetupIndex].GetRecID(TmpRecID, rowIndex);

        if Format(TmpRecID) = '' then
            exit;

        if not SelectedLineRec.Get(TmpRecID) then
            exit;

        if SelectedLineRec."Line No." > 0 then
            SetCurrentLineNo(SelectedLineRec."Receipt No.", SelectedLineRec."Line No.");
    end;

    internal procedure DataRequest(fromPage: Integer; pageCount: Integer; pageSize: Integer; sortColumn: Integer; sortAscending: Boolean; filterString: Text; pJournalSetupIndex: Integer; var LSDataSetRef: Codeunit "LSC DataSet"): Boolean
    begin
        LSJournalDataSet[pJournalSetupIndex].StartPageNo := fromPage;
        LSJournalDataSet[pJournalSetupIndex].PageCount := pageCount;
        LSJournalDataSet[pJournalSetupIndex].DbTablePageSize := pageSize;
        LSJournalDataSet[pJournalSetupIndex].SortColumn := sortColumn;
        LSJournalDataSet[pJournalSetupIndex].SortAscending := sortAscending;
        LSJournalDataSet[pJournalSetupIndex].FilterString := filterString;

        LSJournalDataSet[pJournalSetupIndex].GoToRowIndex := -1;

        JournalDataSet[pJournalSetupIndex].FillDataSetRowsEx(false, LSJournalDataSet[pJournalSetupIndex], (fromPage * pageSize) + 1, pageCount * pageSize, true, false);

        LSDataSetRef := LSJournalDataSet[pJournalSetupIndex];
    end;

    procedure IsModified(): Boolean
    var
        CurrCount: Integer;
        TmpRec: Record "LSC POS Trans. Line";
    begin
        if REC."Receipt No." = '' then
            exit(true);

        TmpRec.SetRange("Receipt No.", REC."Receipt No.");
        CurrCount := TmpRec.Count + 1;
        if LastCount = CurrCount then begin
            TmpRec.SetCurrentKey("Receipt No.", "Line No.");
            TmpRec.SetRange("Receipt No.", REC."Receipt No.");
            TmpRec.SetAscending("Line No.", false);

            if TmpRec.Find('-') then
                repeat
                    if TmpRec.LSTimeStamp > LastTimestamp then begin
                        LastTimestamp := TmpRec.LSTimeStamp;
                        exit(true);
                    end;
                until TmpRec.Next = 0;

            exit(false);   //Count is same and no timestamp newer than LastTimeStamp
        end;
        //ELSE Count is different so IsModified
        LastCount := CurrCount;
        exit(true);
    end;

    procedure RefreshLastCount(): Boolean
    begin
        LastCount := 0;
    end;

    internal procedure DeleteRefundPOSLines(var POSTrans: Record "LSC POS Transaction"; InfoFunction: Code[10])
    begin
        if not (InfoFunction in ['REFUND', 'EXCHANGE']) then
            exit;

        DeletePOSLines(POSTrans);

        if POSTrans."Sale Is Return Sale" or POSTrans."Sale Is Exchange Sale" then begin
            POSTrans."Retrieved from Receipt No." := '';
            POSTrans."Retrieved from Trans. No." := 0;
            POSTrans."Retrieved from Store No." := '';
            POSTrans."Retrieved from POS Term. No." := '';
            POSTrans."Sale Is Return Sale" := false;
            POSTrans."Sale Is Exchange Sale" := false;
            POSTrans.Modify;
        end;
    end;

    local procedure DeletePOSLines(var POSTrans: Record "LSC POS Transaction")
    var
        OfferPosCalc: Record "LSC Offer Pos Calculation";
        POSTransLine: Record "LSC POS Trans. Line";
    begin
        OfferPosCalc.SetRange("Receipt No.", POSTrans."Receipt No.");
        if not OfferPosCalc.IsEmpty() then
            OfferPosCalc.DeleteAll;

        POSTransLine.SetRange("Receipt No.", POSTrans."Receipt No.");
        if POSTransLine.FindSet() then
            repeat
                DelRecord(POSTransLine);
                DeleteLinkedLines(POSTransLine."Line No.");
            until POSTransLine.Next() = 0;
    end;

    internal procedure DeleteLinkedLines(DeletedLineNo: Integer)
    var
        LinkedLine: Record "LSC POS Trans. Line";
    begin
        LinkedLine.SetCurrentKey("Receipt No.", "Parent Line");
        LinkedLine.SetRange("Receipt No.", REC."Receipt No.");
        LinkedLine.SetRange("Parent Line", DeletedLineNo);
        LinkedLine.SetFilter("Line No.", '<>%1', DeletedLineNo);
        if LinkedLine.FindSet then
            repeat
                DelRecord(LinkedLine);
                DeleteLinkedLines(LinkedLine."Line No.");
            until LinkedLine.Next = 0;
    end;

    [Obsolete('Not used, use IsModified instead', '26.0')]
    procedure PublicIsModified(): Boolean
    begin
        exit(IsModified());
    end;
}

