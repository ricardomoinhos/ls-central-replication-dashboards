codeunit 10044751 "LSCNA ServiceLocator"
{
    SingleInstance = true;
    Access = Internal;

    #region BOUtils
    var
        _IBOUtilsImplemented: Boolean;
        IBOUtils: Interface "LSCNA IBOUtils";

    procedure Implement(Dependency: Interface "LSCNA IBOUtils")
    begin
        IBOUtils := Dependency;
        _IBOUtilsImplemented := true;
    end;

    procedure GetBOUtils(): Interface "LSCNA IBOUtils"
    var
        Default: Codeunit "LSCNA BOUtils";
    begin
        if not _IBOUtilsImplemented then
            Implement(Default);
        exit(IBOUtils);
    end;
    #endregion BOUtils

    #region RetailPriceUtils
    var
        _IRetailPriceImplemented: Boolean;
        IRetailPrice: Interface "LSCNA IRetailPrice";

    procedure Implement(Dependency: Interface "LSCNA IRetailPrice")
    begin
        IRetailPrice := Dependency;
        _IRetailPriceImplemented := true;
    end;

    procedure GetRetailPrice(): Interface "LSCNA IRetailPrice"
    var
        Default: Codeunit "LSCNA RetailPriceWrapper";
    begin
        if not _IRetailPriceImplemented then
            Implement(Default);
        exit(IRetailPrice);
    end;
    #endregion RetailPriceUtils

    #region PriceCalculation
    var
        _IPriceCalculationImplemented: Boolean;
        IPriceCalculation: Interface "LSCNA IPriceCalculation";

    procedure Implement(Dependency: Interface "LSCNA IPriceCalculation")
    begin
        IPriceCalculation := Dependency;
        _IPriceCalculationImplemented := true;
    end;

    procedure GetPriceCalculation(): Interface "LSCNA IPriceCalculation"
    var
        Default: Codeunit "LSCNA PriceCalculation";
    begin
        if not _IPriceCalculationImplemented then
            Implement(Default);
        exit(IPriceCalculation);
    end;
    #endregion PriceCalculation

    #region POSPostUtility
    var
        _IPOSPostUtilityImplemented: Boolean;
        IPOSPostUtility: Interface "LSCNA IPOSPostUtility";

    procedure Implement(Dependency: Interface "LSCNA IPOSPostUtility")
    begin
        IPOSPostUtility := Dependency;
        _IPOSPostUtilityImplemented := true;
    end;

    procedure GetPOSPostUtility(): Interface "LSCNA IPOSPostUtility"
    var
        Default: Codeunit "LSCNA POSPostUtility";
    begin
        if not _IPOSPostUtilityImplemented then
            Implement(Default);
        exit(IPOSPostUtility);
    end;
    #endregion POSPostUtility

    #region CustomerOrder
    var
        _ICustomerOrderImplemented: Boolean;
        ICustomerOrder: Interface "LSCNA ICustomerOrder";

    procedure Implement(Dependency: Interface "LSCNA ICustomerOrder")
    begin
        ICustomerOrder := Dependency;
        _ICustomerOrderImplemented := true;
    end;

    procedure GetCustomerOrder(): Interface "LSCNA ICustomerOrder"
    var
        Default: Codeunit "LSCNA CustomerOrder";
    begin
        if not _ICustomerOrderImplemented then
            Implement(Default);
        exit(ICustomerOrder);
    end;
    #endregion CustomerOrder

    #region EBT EFT Utility
    var
        _eBTEFTUtilityUtilityImplemented: Boolean;
        _eBTEFTUtility: Interface "LSCNA IEBTEFTUtility";

    procedure Implement(Dependency: Interface "LSCNA IEBTEFTUtility")
    begin
        _eBTEFTUtility := Dependency;
        _eBTEFTUtilityUtilityImplemented := true;
    end;

    procedure EBTEFTUtility(): Interface "LSCNA IEBTEFTUtility"
    var
        Default: Codeunit "LSCNA EBT EFT Utility";
    begin
        if not _eBTEFTUtilityUtilityImplemented then
            Implement(Default);
        exit(_eBTEFTUtility);
    end;
    #endregion EBT EFT Utility

    #region POS Transaction Mgt.
    var
        _pOSTransactionMgtImplemented: Boolean;
        _pOSTransactionMgt: Interface "LSCNA IPOS Transaction Mgt.";

    procedure Implement(Dependency: Interface "LSCNA IPOS Transaction Mgt.")
    begin
        _pOSTransactionMgt := Dependency;
        _pOSTransactionMgtImplemented := true;
    end;

    procedure POSTransactionMgt(): Interface "LSCNA IPOS Transaction Mgt."
    var
        Default: Codeunit "LSCNA POS Transaction Mgt.";
    begin
        if not _pOSTransactionMgtImplemented then
            Implement(Default);
        exit(_pOSTransactionMgt);
    end;
    #endregion POS Transaction Mgt.

    #region POSTransactionWarmup

    var
        IPOSTransactionWarmup: Interface "LSCNA IPOSTransactionWarmup";
        _IPOSTransactionWarmupImplemented: Boolean;

    procedure Implement(Dependency: Interface "LSCNA IPOSTransactionWarmup")
    begin
        IPOSTransactionWarmup := Dependency;
        _IPOSTransactionWarmupImplemented := true;
    end;

    procedure GetPOSTransactionWarmup(): Interface "LSCNA IPOSTransactionWarmup"
    var
        Default: Codeunit "LSCNA POS Transaction Warmup";
    begin
        if not _IPOSTransactionWarmupImplemented then
            Implement(Default);
        exit(IPOSTransactionWarmup);
    end;

    #endregion POSTransactionWarmup
}