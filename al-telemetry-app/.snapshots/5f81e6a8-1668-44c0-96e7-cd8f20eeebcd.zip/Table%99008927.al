table 99008927 "LSC POS Color"
{
    Caption = 'POS Color';
    LookupPageID = "LSC POS Color Setup";
    DataClassification = CustomerContent;

    fields
    {
        field(10; "Style Profile ID"; Code[20])
        {
            Caption = 'Style Profile ID';
            NotBlank = true;
            TableRelation = "LSC POS Style Profile";
            DataClassification = CustomerContent;
            ToolTip = 'Specifies the ID of the style profile that contains the POS Color Setup.';
        }
        field(20; "Code"; Code[20])
        {
            Caption = 'Code';
            NotBlank = true;
            DataClassification = CustomerContent;
            ToolTip = 'Specifies the description of the color. You can enter a maximum of 20 characters, both numbers and letters.';
        }
        field(25; Description; Text[30])
        {
            Caption = 'Description';
            DataClassification = CustomerContent;
            ToolTip = 'Specifies the description of the color. You can enter a maximum of 30 characters';
        }
        field(30; Color; Integer)
        {
            Caption = 'Color';
            DataClassification = CustomerContent;
            ToolTip = 'Specifies the BGF color value of the color.';
        }
        field(999; "POS Module"; Code[20])
        {
            Caption = 'POS Module';
            TableRelation = "LSC Retail Module".Code;
            DataClassification = CustomerContent;
        }
    }

    keys
    {
        key(Key1; "Style Profile ID", "Code")
        {
            Clustered = true;
        }
        key(Key2; "POS Module")
        {
        }
    }

    internal procedure ChooseColour(pCol: Integer): Integer
    var
        ExtFunc: Codeunit "LSC External Functions Util";
        i: Integer;
    begin
        //ChooseColor
        i := ExtFunc.ChooseColor(Color);
        if i >= 0 then
            exit(i);

        exit(pCol)
    end;

    procedure LSLogo(): Integer
    begin
        exit(1266836);
    end;

    procedure LightGray(): Integer
    begin
        exit(13882323);
    end;

    procedure Gray(): Integer
    begin
        exit(8421504);
    end;

    procedure DarkGray(): Integer
    begin
        exit(11119017);
    end;

    procedure LightSlateGray(): Integer
    begin
        exit(7833753);
    end;

    procedure White(): Integer
    begin
        exit(16777215);
    end;

    procedure LightBlue(): Integer
    begin
        exit(11393254);
    end;

    procedure ButtonShadow(): Integer
    begin
        exit(10526880);
    end;

    procedure ButtonFace(): Integer
    begin
        exit(15790320);
    end;

    procedure ControlDarkDark(): Integer
    begin
        exit(4539717);
    end;

    procedure Navy(): Integer
    begin
        exit(128);
    end;

}

