codeunit 99001562 "LSC Debug Log"
{
    SingleInstance = true;

    var
        Initialized: Boolean;
        StoreNo: Code[10];
        TerminalNo: Code[10];
        LogSetup: Record "LSC POS Debug Setup";
        LogSetupLines: Record "LSC POS Debug Setup Line";
        LogRec: Record "LSC POS Debug Log";
        TempLogRec: Record "LSC POS Debug Log" temporary;
        entryNo: BigInteger;
        PurgeFlag: Boolean;
        LastEventType: Enum "LSC POS Event Type";
        ExtensionLogger: Codeunit "LSCLog";
        MaxRecsPerLog: Integer;
        MaxMessageLenght: Integer;
        NoExtensionAvailableTxt: Label 'Warning: No Extension is installed to handle Debug Log Events.';

    //setja listenera hér.. sem detecta að verið sé að breyta setupinu.. og kalla á configure()
    //og listen for POS Terminal change.. and call getnextentry
    procedure Init()
    begin
        TempLogRec.Reset();
        TempLogRec.DeleteAll();
        FlushLog();
        StoreNo := '';
        TerminalNo := '';
        entryNo := 0;
        Clear(LogSetup);
        Clear(LogSetupLines);
        PurgeFlag := false;
        Clear(LastEventType);
        ExtensionLogger.LogFile('');
        ExtensionLogger.LogLevel(0);
        ExtensionLogger.Close();
        MaxRecsPerLog := 3;
        MaxMessageLenght := MaxStrLen(TempLogRec.Message);
        Initialized := true;
    end;

    procedure Close()
    begin
        ExtensionLogger.Close();
    end;

    procedure SetTerminal(pTerminalNo: Code[10])
    var
        lPOSTerminal: Record "LSC POS Terminal";
    begin
        if not LogSetup.Get() then
            exit;
        if not LogSetup."Debug Log Enabled" then
            exit;
        if pTerminalNo = '' then
            exit;
        if not Initialized then
            Init();
        if TerminalNo <> pTerminalNo then begin
            TerminalNo := pTerminalNo;
            lPOSTerminal.get(TerminalNo);
            StoreNo := lPOSTerminal."Store No.";
            Configure();
        end;
    end;

    procedure Configure()
    var
        boutils: Codeunit "LSC BO Utils";
    begin
        if LogSetup.Get() then;

        if (not LogSetup."Debug Log Enabled") then begin
            Close();
            exit;
        end;

        LogSetupLines.Reset();
        LogSetupLines.SetRange(LogSetupLines."Log Type", LogSetupLines."Log Type"::Terminal);
        LogSetupLines.SetRange("Store/Terminal", TerminalNo);
        if LogSetupLines.IsEmpty() then begin
            LogSetupLines.SetRange(LogSetupLines."Log Type", LogSetupLines."Log Type"::Store);
            LogSetupLines.SetRange("Store/Terminal", StoreNo);
            if LogSetupLines.IsEmpty() then begin
                LogSetupLines.SetRange("Store/Terminal", '');
                LogSetupLines.SetRange(LogSetupLines."Log Type", LogSetupLines."Log Type"::Terminal);
                if LogSetupLines.IsEmpty() then begin
                    LogSetupLines.SetRange(LogSetupLines."Log Type", LogSetupLines."Log Type"::Store);
                    if LogSetupLines.IsEmpty() then begin
                        Close();
                        exit;
                    end;
                end;
            end;
        end;

        if LogSetup."Log Type" = LogSetup."Log Type"::File then
            if not ExtensionLogger.IsAvailable() then
                Message(NoExtensionAvailableTxt);

        LogSetupLines.FindFirst();
        if LogSetup."Log Type" = LogSetup."Log Type"::File then begin
            ExtensionLogger.LogFile(LogSetup."Log File");
            if LogSetupLines."Log Level" = LogSetupLines."Log Level"::None then
                ExtensionLogger.LogLevel := 1
            else
                ExtensionLogger.LogLevel := LogSetupLines."Log Level".AsInteger;
        end;

        LogInfo('-- ' + boutils.getLSRetailVersion() + ' --');
        LogInfo('-- Config: ' + FORMAT(LogSetupLines));
    end;

    procedure LogStartInfo()
    var
        boutils: Codeunit "LSC BO Utils";
        json: JsonObject;
        jsonTxt: Text;
        env: Codeunit "Environment Information";
    begin
        json.Add('LS Version', boutils.getLSRetailVersion());
        json.Add('Company', Database.CompanyName);
        json.Add('Language', Format(System.WindowsLanguage));
        json.Add('ClientType', Format(Session.CurrentClientType));
        json.Add('TenantId', TenantId);
        json.Add('AppFamily', env.GetApplicationFamily);
        json.Add('Environment', env.GetEnvironmentName);
        json.Add('IsFin', env.IsFinancials);
        json.Add('Saas', env.IsSaaS);
        json.Add('SaasInfr', env.IsSaaSInfrastructure());
        json.Add('IsOnPrem', env.IsOnPrem);
        json.Add('IsSandbox', env.IsSandbox);
        json.Add('IsProd', env.IsProduction);

        json.WriteTo(jsonTxt);
        LogInfo(jsonTxt);
    end;

    procedure GetLogLevel(): Integer
    begin
        exit(LogSetupLines."Log Level".AsInteger());
    end;

    local procedure CheckPurge()
    var
        minutesSinceLastCheck: Duration;
        purgeDT: DateTime;
        LastPurge: DateTime;
    begin
        PurgeFlag := false;
        LastPurge := LogSetup."Last Log Purge";

        if LastPurge = 0DT then
            LastPurge := CREATEDATETIME(20000101D, 000000T);

        if LogSetup."Purge Log At" > 0T then begin
            purgeDT := CreateDateTime(TODAY, LogSetup."Purge Log At");
            if LastPurge < purgeDT then
                if CurrentDateTime > purgeDT then
                    PurgeFlag := true;
            exit;
        end;

        minutesSinceLastCheck := Round((CurrentDateTime - LastPurge) / 1000 / 60, 1);
        if minutesSinceLastCheck > 120 then //2 hours between purge actions (only done on IDLETIMER event)
            PurgeFlag := true;
    end;

    local procedure PurgeLog()
    var
        debugLog: Record "LSC POS Debug Log";
        tmpDT: DateTime;
        c: Integer;
    begin
        if LogSetup.Get() then begin
            LogSetup."Last Log Purge" := CurrentDateTime;
            if LogSetup."Log Max Days" <= 0 then
                LogSetup."Log Max Days" := 10; //just in case
            LogSetup.Modify;
        end;

        tmpDT := CreateDateTime(CalcDate(StrSubstNo('<-%1D>', LogSetup."Log Max Days"), Today), 0T);
        debugLog.SetRange(debugLog."Entry Time", 0DT, tmpDT);
        if not debugLog.IsEmpty then begin
            c := debugLog.CountApprox;
            debugLog.DeleteAll();
            Log(Enum::"LSC POS Log Level"::None, StrSubstNo('Log Purge: Removed %1 Entries older than %2', c, tmpDT), false);
        end;
    end;

    procedure LogTrace(message: Text): Boolean
    begin
        exit(LogTrace(message, false));
    end;

    procedure LogTrace(message: Text; DualDisp: Boolean): Boolean
    begin
        exit(Log(Enum::"LSC POS Log Level"::Trace, message, DualDisp));
    end;

    procedure LogDebug(message: Text): Boolean
    begin
        exit(LogDebug(message, false));
    end;

    procedure LogDebug(message: Text; DualDisp: Boolean): Boolean
    begin
        exit(Log(Enum::"LSC POS Log Level"::Debug, message, DualDisp));
    end;

    procedure LogWarning(message: Text): Boolean
    begin
        exit(LogWarning(message, false));
    end;

    procedure LogWarning(message: Text; DualDisp: Boolean): Boolean
    begin
        exit(Log(Enum::"LSC POS Log Level"::Warning, message, DualDisp));
    end;

    procedure LogError(message: Text): Boolean
    begin
        exit(LogError(message, ''));
    end;

    procedure LogError(message: Text; callstack: Text): Boolean
    begin
        exit(LogError(message, callstack, false))
    end;

    procedure LogError(message: Text; DualDisp: Boolean): Boolean
    begin
        exit(LogError(message, '', DualDisp));
    end;

    procedure LogError(message: Text; callstack: Text; DualDisp: Boolean): Boolean
    var
        jsonObj: JsonObject;
        msg: Text;
    begin
        jsonObj.Add('message', message);
        jsonObj.Add('callstack', callstack);
        jsonObj.WriteTo(msg);
        exit(Log(Enum::"LSC POS Log Level"::Error, msg, DualDisp));
    end;

    procedure LogInfo(message: Text): Boolean
    begin
        exit(LogInfo(message, false));
    end;

    procedure LogInfo(message: Text; DualDisp: Boolean): Boolean
    begin
        exit(Log(Enum::"LSC POS Log Level"::None, message, DualDisp));
    end;

    procedure LogEvent(var posevent: Codeunit "LSC POS Event"): Boolean
    begin
        exit(LogEvent(posevent, false));
    end;

    procedure LogEvent(var posevent: Codeunit "LSC POS Event"; DualDisp: Boolean): Boolean
    begin
        if not LogSetup."Debug Log Enabled" then
            exit(false);

        if posevent.EventType = Enum::"LSC POS Event Type"::IDLETIMERTICK then begin
            CheckPurge();
            if lastEventType = Enum::"LSC POS Event Type"::IDLETIMERTICK then //only log IDLETIMERS once
                exit(true);
        end;

        lastEventType := posevent.EventType();

        if LogSetupLines.IsEmpty then
            exit(false);

        if (not LogSetupLines."Log Dual Display") and DualDisp then
            exit(true);

        if LogSetupLines."Log Events" then begin
            if not LogTimeValid(LogSetupLines) then
                exit(true);

            if LogSetup."Log Type" = LogSetup."Log Type"::File then begin
                ExtensionLogger.LogEvent(posevent);
            end
            else begin
                if entryNo = 0 then
                    entryNo := LogRec.GetNextEntry(TerminalNo)
                else
                    entryNo += 1;
                TempLogRec.InsertLogLine(StoreNo, TerminalNo, entryNo, Enum::"LSC POS Log Level"::Debug, posevent, DualDisp);
            end;
        end;

        exit(true);
    end;

    procedure LogDuration(): Boolean
    begin
        if not IsEnabled() then
            exit(false);

        exit(LogSetupLines."Log Performance" > 0);
    end;

    procedure LogDataSize(): Boolean
    begin
        if not IsEnabled() then
            exit(false);

        exit(LogSetupLines."Log Performance" > 1);
    end;

    procedure LogData(): Boolean
    begin
        if not IsEnabled() then
            exit(false);

        if not (LogSetup."Log Type" = LogSetup."Log Type"::File) then //Only valid for file (onPrem)
            exit(false);

        exit(LogSetupLines."Log Performance" > 2);
    end;

    procedure LogPerformance(tmpText: Text; pEventType: Text; pStrData: Text; pMilliseconds: BigInteger): Boolean
    begin
        exit(LogPerformance(tmpText, pEventType, pStrData, pMilliseconds, 0, 0));
    end;

    procedure LogPerformance(tmpText: Text; pEventType: Text; pStrData: Text; pMilliseconds: BigInteger; pSqlRowsRead: BigInteger; pSqlStatements: BigInteger): Boolean
    var
        i: Integer;
    begin
        if not IsEnabled() then
            exit(false);

        if LogSetupLines."Log Performance" > 0 then begin
            if not LogTimeValid(LogSetupLines) then
                exit(true);

            i := Round(pMilliseconds / 200, 1);
            if i > 100 then
                i := 100; //show indicator max 20 seconds

            tmpText := StrSubstNo('[%1] %2,%3: %4 ms, %5 SqlRows, %6 SqlStmt ', tmpText, pEventType, pStrData, pMilliseconds, pSqlRowsRead, pSqlStatements);
            tmpText := tmpText.PadRight(StrLen(tmpText) + i, '#');

            if LogSetup."Log Type" = LogSetup."Log Type"::File then begin
                ExtensionLogger.Information(tmpText, false);
            end
            else begin
                if entryNo = 0 then
                    entryNo := LogRec.GetNextEntry(TerminalNo)
                else
                    entryNo += 1;
                TempLogRec.InsertLogLine(StoreNo, TerminalNo, entryNo, Enum::"LSC POS Log Level"::None, tmpText, false, false);
            end;
        end;

        exit(true);
    end;

    local procedure Log(logLevel: Enum "LSC POS Log Level"; message: Text; DualDisp: Boolean): Boolean
    var
        CallStack: Text;
        len: Integer;
        i: Integer;
    begin
        if not IsEnabled() then
            exit(false);

        if (not LogSetupLines."Log Dual Display") and DualDisp then
            exit(true);

        if LogSetupLines."Log Level".AsInteger >= logLevel.AsInteger then begin
            if not LogTimeValid(LogSetupLines) then
                exit(true);

            if LogSetup."Log Type" = LogSetup."Log Type"::File then begin
                case logLevel of
                    logLevel::Debug, logLevel::Trace:
                        ExtensionLogger.Debug(message, DualDisp);
                    logLevel::Error:
                        ExtensionLogger.Error(message, DualDisp);
                    logLevel::Warning:
                        ExtensionLogger.Warning(message, DualDisp);
                    logLevel::None:
                        ExtensionLogger.Information(message, DualDisp);
                end;
            end
            else begin
                if entryNo = 0 then
                    entryNo := LogRec.GetNextEntry(TerminalNo)
                else
                    entryNo += 1;

                len := StrLen(message);
                i := 1;

                if LogSetup."Log Call Stack" then
                    CallStack := SessionInformation.Callstack();

                if len < MaxMessageLenght then begin
                    TempLogRec.InsertLogLine(StoreNo, TerminalNo, entryNo, logLevel, CopyStr(message, i), DualDisp, false, PrepareCallStack(CallStack));
                    exit;
                end;

                if MaxRecsPerLog < 1 then
                    MaxRecsPerLog := 3; //default 3*256 characters

                while (i < len) and (i < MaxRecsPerLog * MaxMessageLenght) do begin
                    TempLogRec.InsertLogLine(StoreNo, TerminalNo, entryNo, logLevel, CopyStr(message, i, MaxMessageLenght), DualDisp, i > 1, PrepareCallStack(CallStack));
                    i += MaxMessageLenght;
                    entryNo += 1;
                end;
            end;
        end;

        exit(true);
    end;

    local procedure LogTimeValid(var pLogSetupLine: Record "LSC POS Debug Setup Line"): Boolean
    begin
        if pLogSetupLine."End Date" <> 0D then
            if Today > pLogSetupLine."End Date" then
                exit(false);

        if pLogSetupLine."Start Date" <> 0D then
            if Today < pLogSetupLine."Start Date" then
                exit(false);

        if pLogSetupLine."End Time" = 0T then begin
            if pLogSetupLine."Start Time" = 0T then
                exit(true)
            else
                if Time > pLogSetupLine."Start Time" then
                    exit(true);
        end
        else
            if Time < pLogSetupLine."End Time" then begin
                if pLogSetupLine."Start Time" = 0T then
                    exit(true)
                else
                    if Time > pLogSetupLine."Start Time" then
                        exit(true);
            end;
        exit(false);
    end;

    procedure FlushLog()
    begin
        if PurgeFlag then
            PurgeLog();

        if TempLogRec.Find('-') then
            repeat
                LogRec.Copy(TempLogRec);
                LogRec.Insert;
            until TempLogRec.Next = 0;

        TempLogRec.Reset();
        TempLogRec.DeleteAll();

        entryNo := 0;
    end;

    procedure SetMaxRecsPerLog(pMaxRecs: Integer)
    begin
        MaxRecsPerLog := pMaxRecs;
    end;

    procedure ActiveLogLevel(): Integer
    begin
        exit(LogSetupLines."Log Level".AsInteger());
    end;

    procedure PrepareCallStack(CallStack: Text): Text
    var
        Substrings: List of [Text];
        Substring: Text;
        Len: Integer;
        Pos: Integer;
    begin
        if CallStack = '' then
            exit('');

        Substrings.Add('"LSC POS Control Library"(CodeUnit 10012739).LogDebug');
        Substrings.Add('"LSC POS Control Library"(CodeUnit 10012739).LogError');
        Substrings.Add('"LSC POS Control Library"(CodeUnit 10012739).LogWarning');
        Substrings.Add('"LSC POS Control Library"(CodeUnit 10012739).LogInfo');
        Substrings.Add('"LSC POS Control Library"(CodeUnit 10012739).LogTrace');
        Substrings.Add('"LSC POS Control Library"(CodeUnit 10012739).LogDeepTrace');
        Substrings.Add('"LSC POS Control Library"(CodeUnit 10012739).LogDebugJson');
        Substrings.Add('"LSC POS Control Library"(CodeUnit 10012739).LogEntities');

        foreach Substring in Substrings do begin
            repeat
                Len := StrLen(Substring);
                Pos := StrPos(CallStack, SubString);
                if Pos > 0 then
                    CallStack := CopyStr(CallStack, Pos + Len);
            until Pos = 0;
        end;
        exit(CopyStr(CallStack, StrPos(CallStack, '\') + 1, MaxStrLen(TempLogRec."Call Stack")));
    end;

    local procedure IsEnabled(): Boolean
    begin
        if not LogSetup."Debug Log Enabled" then
            exit(false);
        if LogSetupLines.IsEmpty then
            exit(false);

        exit(true);
    end;

    //TODO EMA.. need to find a way to check this every now and then.. maybe on IDLETIMER event..? and update config if changed
    /*[EventSubscriber(ObjectType::Table, Database::"LSC POS Debug Setup Line", 'OnAfterModifyEvent', '', true, true)]
    local procedure OnAfterLogSetupModify(RunTrigger: Boolean; var Rec: Record "LSC POS Debug Setup Line"; var xRec: Record "LSC POS Debug Setup Line")
    begin
        LogInfo('Debug Log Setup Change Event...');
        Configure();
    end;*/

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Session", OnTerminalChanged, '', false, false)]
    local procedure OnTerminalChanged(oldTerminalNo: Text; newTerminalNo: Text)
    begin
        SetTerminal(newTerminalNo);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC HTTP Wrapper", OnBeforeSend, '', false, false)]
    local procedure OnBeforeSend(sender: Codeunit "LSC Http Wrapper")
    begin
        if not GuiAllowed then
            exit;
        if not IsEnabled() then
            exit;
        LogDebug(StrSubstNo('Web Request: %1 %2', sender.GetFullUrl(), sender.GetSenderName()));
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC HTTP Wrapper", OnAfterSend, '', false, false)]
    local procedure OnAfterSend(sender: Codeunit "LSC Http Wrapper")
    begin
        if not GuiAllowed then
            exit;
        if not IsEnabled() then
            exit;

        LogDebug(StrSubstNo('Web Request finished'));
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnBeforeTSSendUnsentTransactions, '', false, false)]
    local procedure OnBeforeTSSendUnsentTransactions(var IsHandled: Boolean)
    begin
        if not GuiAllowed then
            exit;
        if not IsEnabled() then
            exit;

        LogDebug('OnBeforeTSSendUnsentTransactions');
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnBeforeTSSendUnsentTables, '', false, false)]
    local procedure OnBeforeTSSendUnsentTables()
    begin
        if not GuiAllowed then
            exit;
        if not IsEnabled() then
            exit;

        LogDebug('OnBeforeTSSendUnsentTables');
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnAfterTSSendUnsentTransactions, '', false, false)]
    local procedure OnAfterTSSendUnsentTransactions()
    begin
        if not GuiAllowed then
            exit;
        if not IsEnabled() then
            exit;

        LogDebug('OnAfterTSSendUnsentTransactions');
    e