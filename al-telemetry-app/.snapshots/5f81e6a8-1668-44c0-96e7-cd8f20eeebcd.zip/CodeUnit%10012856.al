codeunit 10012856 "LSC Service Locator"
{
    Access = Internal;
    SingleInstance = true;

    /// <summary>
    /// Resets all internal state of the service locator. Any implementations that have been set will be cleared.
    /// </summary>
    procedure Reset()
    begin
        ClearAll();
    end;

    #region Transaction GUI

    var
        _transactionGui: Interface "LSC ITransactionGUI";
        _transactionGuiImplemented: Boolean;

    procedure Implement(Dependency: Interface "LSC ITransactionGUI")
    begin
        _transactionGui := Dependency;
        _transactionGuiImplemented := true;
    end;

    /// <summary>
    /// Returns a ***shared instance*** of `LSC ITransactionGUI` implementation (defaults to `LSC POS Transaction GUI` codeunit if `Implement` has not been called).
    /// 
    /// Note: At the moment, the default implementation is a single-instance codeunit.
    /// </summary>
    procedure TransactionGUI(): Interface "LSC ITransactionGUI"
    var
        Default: Codeunit "LSC POS Transaction GUI";
    begin
        if not _transactionGuiImplemented then
            Implement(Default);
        exit(_transactionGui);
    end;

    #endregion

    #region EFT

    var
        _eft: Interface "LSC ITransactionEFT";
        _eftImplemented: Boolean;

    procedure Implement(Dependency: Interface "LSC ITransactionEFT")
    begin
        _eft := Dependency;
        _eftImplemented := true;
    end;

    /// <summary>
    /// Returns a ***shared instance*** of `LSC ITransactionEFT` implementation (defaults to `LSC POS Transaction EFT` codeunit if `Implement` has not been called).
    ///
    /// Note: The default implementation **IS NOT** a single-instance codeunit.
    /// </summary>
    procedure TransactionEFT(): Interface "LSC ITransactionEFT"
    var
        Default: Codeunit "LSC POS Transaction EFT";
    begin
        if not _eftImplemented then
            Implement(Default);
        exit(_eft);
    end;

    #endregion

    #region ICard Payment Engine

    var
        _cardPaymentEngine: Interface "LSC ICard Payment Engine";
        _cardPaymentEngineImplemented: Boolean;

    procedure Implement(Dependency: Interface "LSC ICard Payment Engine")
    begin
        _cardPaymentEngine := Dependency;
        _cardPaymentEngineImplemented := true;
    end;

    /// <summary>
    /// Returns a ***shared instance*** of a `LSC ICard Payment Engine` implementation
    /// This implementation defaults to the codeunit that implements the "LSC Card Payment Engine"::Default enum value
    /// </summary>
    procedure CardPaymentEngine(): Interface "LSC ICard Payment Engine"
    var
        RetailSetup: Record "LSC Retail Setup";
    begin
        if _cardPaymentEngineImplemented then
            exit(_cardPaymentEngine);

        if not RetailSetup.Get() then
            Implement("LSC Card Payment Engine"::Default);

        Implement(RetailSetup."Card Payment Engine");
        exit(_cardPaymentEngine);
    end;

    #endregion

    #region Transaction State

    var
        _transactionState: Interface "LSC ITransactionState";
        _transactionStateImplemented: Boolean;

    procedure Reset_TransactionState()
    begin
        Clear(_transactionState);
        Clear(_transactionStateImplemented);
    end;

    procedure Implement(Dependency: Interface "LSC ITransactionState")
    begin
        _transactionState := Dependency;
        _transactionStateImplemented := true;
    end;

    /// <summary>
    /// Returns a ***shared instance*** of `LSC ITransactionState` implementation (defaults to `LSC POS Transaction State` codeunit if `Implement` has not been called).
    ///
    /// Note: The default implementation **IS NOT** a single-instance codeunit.
    /// </summary>
    procedure TransactionState(): Interface "LSC ITransactionState"
    var
        Default: Codeunit "LSC POS Transaction State";
    begin
        if not _transactionStateImplemented then
            Implement(Default);
        exit(_transactionState);
    end;

    #endregion

    #region HttpClient

    var
        _httpClient: Interface "LSC IHttpClient";
        _httpClientImplemented: Boolean;

    procedure Implement(Dependency: Interface "LSC IHttpClient")
    begin
        _httpClient := Dependency;
        _httpClientImplemented := true;
    end;

    /// <summary>
    /// Returns a ***shared instance*** of the `LSC IHttpClient` implementation (defaults to a new instance of `LSC HttpClient` codeunit if `Implement` has not been called).
    ///
    /// > **IMPORTANT:** Reusing the same instance of HttpClient is not recommended. Please make sure to understand exactly what and why you are doing by reusing the same instance.
    /// > While there are certain performance benefits you gain by reusing the same instance (e.g. connection pooling), there are also certain risks that you need to be aware of
    /// > (e.g. state of authentication, cookies, certificates, etc.). In general, it's safe to reuse the same instance for accessing the same back end, but reusing the same
    /// > instance for accessing different back ends might lead to unexpected behavior.
    /// </summary>
    /// <returns></returns>
    procedure HttpClient(): Interface "LSC IHttpClient"
    begin
        if not _httpClientImplemented then
            Implement(GetDefaultHttpClient());
        exit(_httpClient);
    end;

    /// <summary>
    /// Creates a new instance of the `LSC IHttpClient` implementation (defaults to a new instance of `LSC HttpClient` codeunit if `Implement` has not been called).
    /// </summary>
    /// <returns></returns>
    procedure CreateNew_HttpClient(): Interface "LSC IHttpClient"
    begin
        if not _httpClientImplemented then
            exit(GetDefaultHttpClient());
        exit(_httpClient);
    end;

    /// <summary>
    /// We are just making sure that underlying C# constructor on the wrapped System.Net.Http.HttpClient is called only once, because (at least historically) there were known
    /// and documented issues with connection pooling and HttpClient instances. This method is called only once, when the first instance of HttpClient is requested.
    ///
    /// You don't need to have functions like this for returning the default instance for other codeunits, as long as they don't have underlying C# issues like HttpClient does.
    /// </summary>
    /// <returns></returns>
    local procedure GetDefaultHttpClient(): Interface "LSC IHttpClient"
    var
        Default: Codeunit "LSC HttpClient";
    begin
        exit(Default);
    end;

    #endregion

    #region HttpResponseReader

    var
        _httpResponseReader: Interface "LSC IHttpResponseReader";
        _httpResponseReaderImplemented: Boolean;

    procedure Implement(Dependency: Interface "LSC IHttpResponseReader")
    begin
        _httpResponseReader := Dependency;
        _httpResponseReaderImplemented := true;
    end;

    /// <summary>
    /// Creates a new instance of the `LSC IHttpResponseReader` implementation (defaults to a new instance of `LSC HttpResponse Reader` codeunit if `Implement` has not been called).
    /// </summary>
    procedure CreateNew_HttpResponseReader(): Interface "LSC IHttpResponseReader"
    var
        Default: Codeunit "LSC HttpResponse Reader";
    begin
        if not _httpResponseReaderImplemented then
            exit(Default); // Intentional, to return a new instance every time!
        exit(_httpResponseReader);
    end;

    #endregion

    #region Functions

    var
        _posFunctions: Interface "LSC IFunctions";
        _posFunctionsImplemented: Boolean;

    procedure Implement(Dependency: Interface "LSC IFunctions")
    begin
        _posFunctions := Dependency;
        _posFunctionsImplemented := true;
    end;

    /// <summary>
    /// Returns a ***shared instance*** of `LSC IFunctions` implementation (defaults to `LSC POS Functions` codeunit if `Implement` has not been called).
    ///
    /// Note: At the moment, the default implementation is a single-instance codeunit.
    /// </summary>
    procedure POSFunctions(): Interface "LSC IFunctions"
    var
        Default: Codeunit "LSC POS Functions";
    begin
        if not _posFunctionsImplemented then
            Implement(Default);
        exit(_posFunctions);
    end;

    #endregion    

    #region NoSeries
    var
        _NoSeries: Interface "LSC INoSeriesWrapper";
        _NoSeriesImplemented: Boolean;

    procedure Implement(Dependency: Interface "LSC INoSeriesWrapper")
    begin
        _NoSeries := Dependency;
        _NoSeriesImplemented := true;
    end;

    procedure NoSeriesWrapper(): Interface "LSC INoSeriesWrapper"
    var
        Default: Codeunit "LSC NoSeries Wrapper";
    begin
        if not _NoSeriesImplemented then
            Implement(Default);
        exit(_NoSeries);
    end;
    #endregion

    #region TypeHelperWrapper
    var
        _TypeHelperWrapper: Interface "LSC ITypeHelperWrapper";
        _TypeHelperWrapperImplemented: Boolean;

    procedure Implement(Dependency: Interface "LSC ITypeHelperWrapper")
    begin
        _TypeHelperWrapper := Dependency;
        _TypeHelperWrapperImplemented := true;
    end;

    procedure TypeHelperWrapper(): Interface "LSC ITypeHelperWrapper"
    var
        Default: Codeunit "LSC Type Helper Wrapper";
    begin
        if not _TypeHelperWrapperImplemented then
            Implement(Default);
        exit(_TypeHelperWrapper);
    end;
    #endregion

    #region MailManagement
    var
        _MailManagement: Interface "LSC IMailManagementWrapper";
        _MailManagementImplemented: Boolean;

    procedure Implement(Dependency: Interface "LSC IMailManagementWrapper")
    begin
        _MailManagement := Dependency;
        _MailManagementImplemented := true;
    end;

    procedure MailManagementWrapper(): Interface "LSC IMailManagementWrapper"
    var
        Default: Codeunit "LSC Mail Management Wrapper";
    begin
        if not _MailManagementImplemented then
            Implement(Default);
        exit(_MailManagement);
    end;
    #endregion

    #region IPosSession
    var
        _posSessionImplemented: Boolean;
        _posSession: Interface "LSC IPosSession";

    procedure Implement_PosSession(Dependency: Interface "LSC IPosSession")
    begin
        _posSessionImplemented := true;
        _posSession := Dependency;
    end;

    /// <summary>
    /// Returns a ***shared instance*** of `LSC IPosSession` implementation (defaults to `LSC POS Session` codeunit if `Implement` has not been called).
    ///
    /// Note: At the moment, the default implementation is a single-instance codeunit.
    /// </summary>
    /// <returns></returns>
    procedure PosSession(): Interface "LSC IPosSession"
    var
        Default: Codeunit "LSC POS Session";
    begin
        if not _posSessionImplemented then
            Implement_PosSession(Default);
        exit(_posSession);
    end;
    #endregion

    #region IPosSessionMenu
    var
        _IPosSessionMenuImplemented: Boolean;
        _IPosSessionMenu: Interface "LSC IPosSessionMenu";

    procedure Implement(Dependency: Interface "LSC IPosSessionMenu")
    begin
        _IPosSessionMenuImplemented := true;
        _IPosSessionMenu := Dependency;
    end;

    /// <summary>
    /// Returns a ***shared instance*** of `LSC IPosSessionMenu` implementation (defaults to `LSC POS Session` codeunit if `Implement` has not been called).
    ///
    /// Note: At the moment, the default implementation is a single-instance codeunit.
    /// </summary>
    /// <returns></returns>
    procedure PosSessionMenu(): Interface "LSC IPosSessionMenu"
    var
        Default: Codeunit "LSC POS Session";
    begin
        if not _IPosSessionMenuImplemented then
            Implement(Default);
        exit(_IPosSessionMenu);
    end;
    #endregion

    #region Transaction Hardware
    var
        _transactionRfid: Interface "LSC ITransactionRFID";
        _transactionRfidImplemented: Boolean;

    procedure Implement(Dependency: Interface "LSC ITransactionRFID")
    begin
        _transactionRfid := Dependency;
        _transactionRfidImplemented := true;
    end;

    procedure TransactionRfid(): Interface "LSC ITransactionRFID"
    var
        Default: Codeunit "LSC POS Transaction RFID";
    begin
        if not _transactionRfidImplemented then
            Implement(Default);
        exit(_transactionRfid);
    end;
    #endregion

    #region Pos Device View
    var
        _posDeviceViewImplemented: Boolean;
        _posDeviceView: Interface "LSC IDeviceView";

    procedure Implement(Dependency: Interface "LSC IDeviceView")
    begin
        _posDeviceViewImplemented := true;
        _posDeviceView := Dependency;
    end;

    /// <summary>
    /// Returns a ***shared instance*** of `LSC IPosView` implementation (defaults to `LSC POS View` codeunit if `Implement` has not been called).
    ///
    /// Note: At the moment, the default implementation is a single-instance codeunit.
    /// </summary>
    /// <returns></returns>
    procedure PosDeviceView(): Interface "LSC IDeviceView"
    var
        Default: Codeunit "LSC POS View";
    begin
        if not _posDeviceViewImplemented then
            Implement(Default);
        exit(_posDeviceView);
    end;
    #endregion

    #region Pos View
    var
        _posViewImplemented: Boolean;
        _posView: Interface "LSC IPosView";

    procedure Implement_PosView(Dependency: Interface "LSC IPosView")
    begin
        _posViewImplemented := true;
        _posView := Dependency;
    end;

    /// <summary>
    /// Returns a ***shared instance*** of `LSC IPosView` implementation (defaults to `LSC POS View` codeunit if `Implement` has not been called).
    ///
    /// Note: At the moment, the default implementation is a single-instance codeunit.
    /// </summary>
    /// <returns></returns>
    procedure PosView(): Interface "LSC IPosView"
    var
        Default: Codeunit "LSC POS View";
    begin
        if not _posViewImplemented then
            Implement_PosView(Default);
        exit(_posView);
    end;
    #endregion    

    #region IPOSPanelUtility
    var
        _IPOSPanelUtilityImplemented: Boolean;
        _IPOSPanelUtility: Interface "LSC IPOSPanelUtility";

    procedure Implement(Dependency: Interface "LSC IPOSPanelUtility")
    begin
        _IPOSPanelUtilityImplemented := true;
        _IPOSPanelUtility := Dependency;
    end;

    procedure PosPanelUtility(): Interface "LSC IPOSPanelUtility"
    var
        DefaultImpl: Codeunit "LSC POS Panel Utility";
    begin
        if not _IPOSPanelUtilityImplemented then
            Implement(DefaultImpl);
        exit(_IPOSPanelUtility);
    end;
    #endregion  

    #region IWebServiceClient
    var
        _IWebServiceClientImplemented: Boolean;
        _IWebServiceClient: Interface "LSC IWebServicesClient";

    procedure Implement(Dependency: Interface "LSC IWebServicesClient")
    begin
        _IWebServiceClientImplemented := true;
        _IWebServiceClient := Dependency;
    end;

    procedure WebServicesClient(): Interface "LSC IWebServicesClient"
    var
        DefaultImpl: Codeunit "LSC Web Services Client";
    begin
        if not _IWebServiceClientImplemented then
            Implement(DefaultImpl);
        exit(_IWebServiceClient);
    end;
    #endregion

    #region Retail Price Utils
    var
        _retailPriceUtilsImplemented: Boolean;
        _retailPriceUtils: Interface "LSC IRetailPriceUtils";

    procedure Implement(Dependency: Interface "LSC IRetailPriceUtils")
    begin
        _retailPriceUtilsImplemented := true;
        _retailPriceUtils := Dependency;
    end;

    procedure RetailPriceUtils(): Interface "LSC IRetailPriceUtils"
    var
        DefaultImpl: Codeunit "LSC Retail Price Utils";
    begin
        if not _retailPriceUtilsImplemented then
            Implement(DefaultImpl);
        exit(_retailPriceUtils);
    end;
    #endregion

    #region POS Price Utility
    var
        _POSPriceUtilsImplemented: Boolean;
        _POSPriceUtility: Interface "LSC IPOSPriceUtility";

    procedure Implement(Dependency: Interface "LSC IPOSPriceUtility")
    begin
        _POSPriceUtilsImplemented := true;
        _POSPriceUtility := Dependency;
    end;

    procedure POSPriceUtility(): Interface "LSC IPOSPriceUtility"
    var
        DefaultImpl: Codeunit "LSC POS Price Utility";
    begin
        if not _POSPriceUtilsImplemented then
            Implement(DefaultImpl);
        exit(_POSPriceUtility);
    end;
    #endregion

    #region Coupon Management
    var
        _couponManagementImplemented: Boolean;
        _couponManagement: Interface "LSC ICouponManagement";

    procedure Implement(Dependency: Interface "LSC ICouponManagement")
    begin
        _couponManagementImplemented := true;
        _couponManagement := Dependency;
    end;

    procedure CouponManagement(): Interface "LSC ICouponManagement"
    var
        DefaultImpl: Codeunit "LSC Coupon Management";
    begin
        if not _couponManagementImplemented then
            Implement(DefaultImpl);
        exit(_couponManagement);
    end;
    #endregion

    #region BOUtils
    var
        _boUtilsImplemented: Boolean;
        _boUtils: Interface "LSC IBOUtils";

    procedure Implement(Dependency: Interface "LSC IBOUtils")
    begin
        _boUtilsImplemented := true;
        _boUtils := Dependency;
    end;

    procedure BOUtils(): Interface "LSC IBOUtils"
    var
        DefaultImpl: Codeunit "LSC BO Utils";
    begin
        if not _boUtilsImplemented then
            Implement(DefaultImpl);
        exit(_boUtils);
    end;
    #endregion

    #region FBP POS Functions
    var
        _fbpPOSFunctionsImplemented: Boolean;
        _fbpPOSFunctions: Interface "LSC IFBPFunctions";

    procedure Implement(Dependency: Interface "LSC IFBPFunctions")
    begin
        _fbpPOSFunctionsImplemented := true;
        _fbpPOSFunctions := Dependency;
    end;

    procedure FBPPOSFunctions(): Interface "LSC IFBPFunctions"
    var
        DefaultImpl: Codeunit "LSC FBP POS Functions";
    begin
        if not _fbpPOSFunctionsImplemented then
            Implement(DefaultImpl);
        exit(_fbpPOSFunctions);
    end;
    #endregion

    #region FBP Utility
    var
        _fbpUtilityImplemented: Boolean;
        _fbpPOSUtility: Interface "LSC IFBPUtility";

    procedure Implement(Dependency: Interface "LSC IFBPUtility")
    begin
        _fbpUtilityImplemented := true;
        _fbpPOSUtility := Dependency;
    end;

    procedure FBPUtility(): Interface "LSC IFBPUtility"
    var
        DefaultImpl: Codeunit "LSC FBP Utility";
    begin
        if not _fbpUtilityImplemented then
            Implement(DefaultImpl);
        exit(_fbpPOSUtility);
    end;

    #endregion

    #region WebPOS ReceiptNo Handling
    var
        _WebPOSReceiptNoHandlingImplemented: Boolean;
        _WebPOSReceiptNoHandling: Interface "LSC IWebPOSReceiptNoHandling";

    procedure Implement(Dependency: Interface "LSC IWebPOSReceiptNoHandling")
    begin
        _WebPOSReceiptNoHandlingImplemented := true;
        _WebPOSReceiptNoHandling := Dependency;
    end;

    procedure WebPOSReceiptNoHandling(): Interface "LSC IWebPOSReceiptNoHandling"
    var
        DefaultImpl: Codeunit "LSC WebPOS ReceiptNo Handling";
    begin
        if not _WebPOSReceiptNoHandlingImplemented then
            Implement(DefaultImpl);
        exit(_WebPOSReceiptNoHandling);
    end;

    #endregion

    #region Retail Calendar Management  
    var
        _retailCalendarManagementImplemented: Boolean;
        _retailCalendarManagement: Interface "LSC IRetailCalenderManagement";

    procedure Implement(Dependency: Interface "LSC IRetailCalenderManagement")
    begin
        _retailCalendarManagementImplemented := true;
        _retailCalendarManagement := Dependency;
    end;

    procedure RetailCalendarManagement(): Interface "LSC IRetailCalenderManagement"
    var
        DefaultImpl: Codeunit "LSC Retail Calendar Management";
    begin
        if not _retailCalendarManagementImplemented then
            Implement(DefaultImpl);
        exit(_retailCalendarManagement);
    end;
    #endregion

    #region Deal Functions
    var
        _dealFunctionsImplemented: Boolean;
        _dealFunctions: Interface "LSC IDealFunctions";

    procedure Implement(Dependency: Interface "LSC IDealFunctions")
    begin
        _dealFunctionsImplemented := true;
        _dealFunctions := Dependency;
    end;

    procedure DealFunctions(): Interface "LSC IDealFunctions"
    var
        DefaultImpl: Codeunit "LSC Deal Functions";
    begin
        if not _dealFunctionsImplemented then
            Implement(DefaultImpl);
        exit(_dealFunctions);
    end;
    #endregion

    #region Popup Deal Utilities
    var
        _popupDealUtilitiesImplemented: Boolean;
        _popupDealUtilities: Interface "LSC IPopupDealUtilities";

    procedure Implement(Dependency: Interface "LSC IPopupDealUtilities")
    begin
        _popupDealUtilitiesImplemented := true;
        _popupDealUtilities := Dependency;
    end;

    procedure PopupDealUtilities(): Interface "LSC IPopupDealUtilities"
    var
        DefaultImpl: Codeunit "LSC Popup Deal Utilities";
    begin
        if not _popupDealUtilitiesImplemented then
            Implement(DefaultImpl);
        exit(_popupDealUtilities);
    end;
    #endregion

    #region Popup Functions
    var
        _popupFunctionsImplemented: Boolean;
        _popupFunctions: Interface "LSC IPopupFunctions";

    procedure Implement(Dependency: Interface "LSC IPopupFunctions")
    begin
        _popupFunctionsImplemented := true;
        _popupFunctions := Dependency;
    end;

    procedure PopupFunctions(): Interface "LSC IPopupFunctions"
    var
        DefaultImpl: Codeunit "LSC Pop-up Functions";
    begin
        if not _popupFunctionsImplemented then
            Implement(DefaultImpl);
        exit(_popupFunctions);
    end;
    #endregion

    #region Popup Panel Functions
    var
        _popupPanelFunctionsImplemented: Boolean;
        _popupPanelFunctions: Interface "LSC IPopupPanelFunctions";

    procedure Implement(Dependency: Interface "LSC IPopupPanelFunctions")
    begin
        _popupPanelFunctionsImplemented := true;
        _popupPanelFunctions := Dependency;
    end;

    procedure PopupPanelFunctions(): Interface "LSC IPopupPanelFunctions"
    var
        DefaultImpl: Codeunit "LSC Pop-up Panel Functions";
    begin
        if not _popupPanelFunctionsImplemented then
            Implement(DefaultImpl);
        exit(_popupPanelFunctions);
    end;
    #endregion

    #region Popup Selection Functions
    var
        _popupSelectionFunctionsImplemented: Boolean;
        _popupSelectionFunctions: Interface "LSC IPopupSelectionFunctions";

    procedure Implement(Dependency: Interface "LSC IPopupSelectionFunctions")
    begin
        _popupSelectionFunctionsImplemented := true;
        _popupSelectionFunctions := Dependency;
    end;

    procedure PopupSelectionFunctions(): Interface "LSC IPopupSelectionFunctions"
    var
        DefaultImpl: Codeunit "LSC Popup Selection Functions";
    begin
        if not _popupSelectionFunctionsImplemented then
            Implement(DefaultImpl);
        exit(_popupSelectionFunctions);
    end;
    #endregion

    #region Popup Restriction Check Functions
    var
        _popupRestrictionCheckFunctionsImplemented: Boolean;
        _popupRestrictionCheckFunctions: Interface "LSC IPopupRestrictionCheckFunctions";

    procedure Implement(Dependency: Interface "LSC IPopupRestrictionCheckFunctions")
    begin
        _popupRestrictionCheckFunctionsImplemented := true;
        _popupRestrictionCheckFunctions := Dependency;
    end;

    procedure PopupRestrictionCheckFunctions(): Interface "LSC IPopupRestrictionCheckFunctions"
    var
        DefaultImpl: Codeunit "LSC Popup Restr. Check Func.";
    begin
        if not _popupRestrictionCheckFunctionsImplemented then
            Implement(DefaultImpl);
        exit(_popupRestrictionCheckFunctions);
    end;
    #endregion

    #region POS Infocode Utility
    var
        _posInfocodeUtilityImplemented: Boolean;
        _posInfocodeUtility: Interface "LSC IPOSInfocodeUtility";

    procedure Implement(Dependency: Interface "LSC IPOSInfocodeUtility")
    begin
        _posInfocodeUtilityImplemented := true;
        _posInfocodeUtility := Dependency;
    end;

    procedure POSInfocodeUtility(): Interface "LSC IPOSInfocodeUtility"
    var
        DefaultImpl: Codeunit "LSC POS Infocode Utility";
    begin
        if not _posInfocodeUtilityImplemented then
            Implement(DefaultImpl);
        exit(_posInfocodeUtility);
    end;
    #endregion



    #region POS Trans. Lines
    var
        _posTransLinesImplemented: Boolean;
        _posTransLines: Interface "LSC IPOSTransLines";

    procedure Implement(Dependency: Interface "LSC IPOSTransLines")
    begin
        _posTransLinesImplemented := true;
        _posTransLines := Dependency;
    end;

    procedure POSTransLines(): Interface "LSC IPOSTransLines"
    var
        DefaultImpl: Codeunit "LSC POS Trans. Lines";
    begin
        if not _posTransLinesImplemented then
            Implement(DefaultImpl);
        exit(_posTransLines);
    end;
    #endregion

    #region Retail Charge Mgt
    var
        _retailChargeMgtImplemented: Boolean;
        _retailChargeMgt: Interface "LSC IRetailChargeMgt";

    procedure Implement(Dependency: Interface "LSC IRetailChargeMgt")
    begin
        _retailChargeMgtImplemented := true;
        _retailChargeMgt := Dependency;
    end;

    procedure RetailChargeMgt(): Interface "LSC IRetailChargeMgt"
    var
        DefaultImpl: Codeunit "LSC Retail Charge Mgt.";
    begin
        if not _retailChargeMgtImplemented then
            Implement(DefaultImpl);
        exit(_retailChargeMgt);
    end;
    #endregion

    #region GS1 Barcode Functions
    var
        _gs1BarcodeFunctionsImplemented: Boolean;
        _gs1BarcodeFunctions: Interface "LSC IGS1BarcodeFunctions";

    procedure Implement(Dependency: Interface "LSC IGS1BarcodeFunctions")
    begin
        _gs1BarcodeFunctionsImplemented := true;
        _gs1BarcodeFunctions := Dependency;
    end;

    procedure GS1BarcodeFunctions(): Interface "LSC IGS1BarcodeFunctions"
    var
        DefaultImpl: Codeunit "LSC GS1 Barcode Functions";
    begin
        if not _gs1BarcodeFunctionsImplemented then
            Implement(DefaultImpl);
        exit(_gs1BarcodeFunctions);
    end;
    #endregion

    #region GS1 BarcodeV1 Controller
    var
        _gs1BarcodeV1ControllerImplemented: Boolean;
        _gs1BarcodeV1Controller: Interface "LSC IGS1BarcodeV1Controller";

    procedure Implement(Dependency: Interface "LSC IGS1BarcodeV1Controller")
    begin
        _gs1BarcodeV1ControllerImplemented := true;
        _gs1BarcodeV1Controller := Dependency;
    end;

    procedure GS1BarcodeV1Controller(): Interface "LSC IGS1BarcodeV1Controller"
    var
        DefaultImpl: Codeunit "LSC GS1 BarcodeV1";
    begin
        if not _gs1BarcodeV1ControllerImplemented then
            Implement(DefaultImpl);
        exit(_gs1BarcodeV1Controller);
    end;
    #endregion
}
