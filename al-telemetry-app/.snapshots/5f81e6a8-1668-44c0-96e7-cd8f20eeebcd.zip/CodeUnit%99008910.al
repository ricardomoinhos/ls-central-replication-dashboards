codeunit 99008910 "LSC POS OPOS Utility"
{
    SingleInstance = true;

    var
        HardwareInterface: Codeunit "LSC POS Hardware Interface";
        PosSession: Codeunit "LSC POS Session";
        ProtScale: Codeunit "LSC POS Weighing Utility";
        AUProtScale: Codeunit "LSC POS Weighing Utility AU";
        LastItemNo: Code[20];
        LastQty, LastPrice, LastAmount : Decimal;
        IsScannerEnabled, IsMSREnabled, IsRFIDEnabled : Integer;

    procedure ClearDisplay()
    var
        DeviceID: Code[20];
        DisplayDevice: Record "LSC POS Display";
    begin
        if PosSession.HardwareProfile.GetDevice("LSC Hardware Profile Devices"::Display, '', '', 0, DeviceID) then
            DisplayDevice.Get(DeviceID);
        if DisplayDevice.IsActive() then
            HardwareInterface.ClearLineDisplay(DisplayDevice.ID);
    end;

    procedure Display(Text1: Text; Text2: Text): Boolean
    var
        Handled: Boolean;
        ReturnValue: Boolean;
        DeviceID: Code[20];
        DisplayDevice: Record "LSC POS Display";
    begin
        OnDisplay(Text1, Text2, ReturnValue, Handled);
        if Handled then
            exit(ReturnValue);

        if PosSession.HardwareProfile.GetDevice("LSC Hardware Profile Devices"::Display, '', '', 0, DeviceID) then
            DisplayDevice.Get(DeviceID);
        if DisplayDevice.IsActive() then
            if not HardwareInterface.DisplayTextEx(DisplayDevice.ID, Text1, Text2, 0) then
                exit(false);

        exit(true);
    end;

    procedure DisplaySalesLine(ItemNo: Code[20]; Description: Text[100]; Qty: Decimal; Price: Decimal; Amount: Decimal; UOM: Text[10]; Compressed: Boolean): Boolean
    var
        POSTransLine: Record "LSC POS Trans. Line";
        PreviousPOSTransLine: Record "LSC POS Trans. Line";
        PeriodicDiscount: Record "LSC Periodic Discount";
        POSTransLines: Codeunit "LSC POS Trans. Lines";
        DisplayDevice: Record "LSC POS Display";
        DeviceID: Code[20];
        Line1: Text[30];
        Line2: Text[30];
        AmTxt: Text[30];
        Len: Integer;
    begin
        if PosSession.HardwareProfile.GetDevice("LSC Hardware Profile Devices"::Display, '', '', 0, DeviceID) then
            DisplayDevice.Get(DeviceID);
        if not DisplayDevice.IsActive() then
            exit(true);

        if (ItemNo = '') or (LastItemNo <> ItemNo) or (Qty < 0) or (LastPrice <> Price) then begin
            LastQty := 0;
            LastAmount := 0;
        end;

        if Compressed or (LastQty < 0) then
            LastQty := 0;
        if LastQty = 0 then
            LastAmount := 0;

        LastItemNo := ItemNo;
        LastPrice := Price;
        LastQty := LastQty + Qty;
        LastAmount := LastAmount + Amount;

        POSTransLines.GetCurrentLine(POSTransLine);
        PreviousPOSTransLine.SetRange("Receipt No.", POSTransLine."Receipt No.");
        PreviousPOSTransLine.SetFilter("Line No.", '<' + Format(POSTransLine."Line No."));
        if PreviousPOSTransLine.FindLast() then
            if PreviousPOSTransLine."Entry Type" = POSTransLine."Entry Type"::PerDiscount then begin
                LastAmount := Amount;
                LastQty := Qty;
            end;
        if Price <> Amount then begin
            if POSTransLine."Entry Type" = POSTransLine."Entry Type"::PerDiscount then
                if PeriodicDiscount.Get(POSTransLine.Number) then
                    if PeriodicDiscount."Discount Type" = PeriodicDiscount."Discount Type"::"Deal Price" then begin
                        LastAmount := LastQty * Amount;
                        if (PeriodicDiscount."Deal Price Value" mod 1 = 0) and (LastAmount mod 1 <> 0) then
                            if PeriodicDiscount."Deal Price Value" = Round(LastAmount, 1, '=') then
                                LastAmount := PeriodicDiscount."Deal Price Value";
                    end;
        end;

        Description := CopyStr(Description, 1, 20);

        Line2 := '';
        if ((Qty <> 1) and (Qty <> 0)) or (LastQty > 1) then
            Line2 := ProtScale.FormatQty(LastQty) + ProtScale.FormatUOM(UOM) + PosSession.FunctionalityProfile.GetMultipleItemsSymbol() + ProtScale.FormatPrice(LastAmount / LastQty);

        AmTxt := ' ' + ProtScale.FormatAmount(LastAmount);
        Len := GetFormattedLength(AmTxt, 20);
        Line2 := PadStr(Line2, 20 - Len) + AmTxt;
        Line1 := PadStr(Description, 20);
        Display(Line1, Line2);
    end;

    internal procedure DisplayScaleLine(ItemNo: Code[20]; Description: Text[100]; Weight: Decimal; Price: Decimal; Amount: Decimal; UCode: Text[10]): Boolean
    var
        DLines: array[10] of Text[20];
        DeviceID: Code[20];
        DisplayDevice: Record "LSC POS Display";
    begin
        if PosSession.HardwareProfile.GetDevice("LSC Hardware Profile Devices"::Display, '', '', 0, DeviceID) then
            DisplayDevice.Get(DeviceID);
        if not DisplayDevice.IsActive() then
            exit(true);

        Description := CopyStr(Description, 1, 50);

        ProtScale.SetDescription(Description);
        ProtScale.FormatLines(DLines, Price, Weight, Amount, LowerCase(UCode));

        Display(DLines[1], DLines[2]);
    end;

    procedure DisplayTotals(Total: Decimal; Balance: Decimal): Boolean
    var
        AmTxt: Text[30];
        Line1: Text[30];
        Line2: Text[30];
        Len: Integer;
        DeviceID: Code[20];
        DisplayDevice: Record "LSC POS Display";
    begin
        if PosSession.HardwareProfile.GetDevice("LSC Hardware Profile Devices"::Display, '', '', 0, DeviceID) then
            DisplayDevice.Get(DeviceID);
        if not DisplayDevice.IsActive() then
            exit(true);

        LastQty := 0;
        AmTxt := ProtScale.FormatAmount(Total);
        Len := GetFormattedLength(AmTxt, 20);
        Line1 := DisplayDevice."Display Total Text";
        Line1 := PadStr(Line1, 20 - Len) + AmTxt;
        AmTxt := ProtScale.FormatAmount(Balance);
        Len := GetFormattedLength(AmTxt, 20);
        Line2 := DisplayDevice."Display Balance Text";
        Line2 := PadStr(Line2, 20 - Len) + AmTxt;

        Display(Line1, Line2);
    end;

    internal procedure DisplayCurrency(Balance: Decimal; BalanceInCurr: Decimal; CurrencyCode: Text[10])
    var
        AmTxt: Text[30];
        Line1: Text[30];
        Line2: Text[30];
        Len: Integer;
        DeviceID: Code[20];
        DisplayDevice: Record "LSC POS Display";
    begin
        if PosSession.HardwareProfile.GetDevice("LSC Hardware Profile Devices"::Display, '', '', 0, DeviceID) then
            DisplayDevice.Get(DeviceID);
        if not DisplayDevice.IsActive() then
            exit;

        LastQty := 0;
        AmTxt := ProtScale.FormatAmount(Balance);
        Len := GetFormattedLength(AmTxt, 20);
        Line1 := DisplayDevice."Display Balance Text";
        Line1 := PadStr(Line1, 20 - Len) + AmTxt;
        AmTxt := ProtScale.FormatAmount(BalanceInCurr);
        Len := GetFormattedLength(AmTxt, 20);
        Line2 := CurrencyCode;
        Line2 := PadStr(Line2, 20 - Len) + AmTxt;

        Display(Line1, Line2);
    end;

    procedure OpenDrawer(RoleID: Code[10]; SuppressDrawerAlerts: Boolean; RunDialog: Boolean): Boolean
    var
        DeviceID: Code[20];
        I: Integer;
        retVal: Boolean;
        IsHandled: Boolean;
        POSTransactionEvents: Codeunit "LSC POS Transaction Events";
        PosTransCu: Codeunit "LSC POS Transaction Impl"; // only used for GetLineRec until removed
        TransRec: Record "LSC POS Transaction";
        TransLineRec: Record "LSC POS Trans. Line";
        TransCurrInput: Text;
    begin
#pragma warning disable AL0432
        PosTransCu.GetPOSTransaction(TransRec);
        TransLineRec := PosTransCu.GetLineRec();
        TransCurrInput := PosTransCu.GetCurrInput();
        POSTransactionEvents.OnBeforeOpenDrawer(TransRec, TransLineRec, TransCurrInput);
        PosTransCu.SetPOSTransaction(TransRec);
        PosTransCu.SetLineRec(TransLineRec);
        PosTransCu.SetCurrInput(TransCurrInput);
#pragma warning restore AL0432
        OnBeforeOpenDrawerEx(retVal, IsHandled);
        if IsHandled then
            exit(retVal);

        retVal := true;
        for I := 0 to 3 do
            if retVal and PosSession.HardwareProfile.GetDevice("LSC Hardware Profile Devices"::Drawer, RoleID, '', I, DeviceID) then
                retVal := HardwareInterface.OpenDrawer(DeviceID, SuppressDrawerAlerts, RunDialog);

        exit(retVal);
    end;

    procedure SetDrawersAlertType(Type: Option Poll,Block)
    begin
        RunPosCommand('_SETDRAWERALERTYPE', Format(Type, 0, 9));
    end;

    procedure Beeper(): Boolean
    begin
        if (PosSession.HardwareProfile."Tone1 Pitch" <> 0) and (PosSession.HardwareProfile."Tone1 Duration" <> 0) then
            HardwareInterface.SoundImmediate();
        exit(true);
    end;

    internal procedure InitOpos()
    begin
        IsScannerEnabled := -1; //-1 means not initialized
        IsMSREnabled := -1; //-1 means not initialized
        IsRFIDEnabled := -1; //-1 means not initialized
    end;

    local procedure SetEnabled(b: Boolean; var globalVar: Integer; command: Text)
    begin
        if b = (globalVar = 1) then
            exit;
        globalVar := b ? 1 : 0;
        RunPosCommand(command, Format(globalVar));
    end;

    local procedure SetEnableScanner(b: Boolean)
    begin
        SetEnabled(b, IsScannerEnabled, '_ENABLESCANNER');
    end;

    procedure EnableScanner(): Boolean
    begin
        SetEnableScanner(true);
        exit(true);
    end;

    procedure DisableScanner()
    begin
        SetEnableScanner(false);
    end;

    local procedure SetEnableMsr(b: Boolean)
    begin
        SetEnabled(b, IsMSREnabled, '_ENABLEMSR');
    end;

    internal procedure EnableMSR()
    begin
        SetEnableMsr(true);
    end;

    internal procedure DisableMSR()
    begin
        SetEnableMsr(false);
    end;

    local procedure SetEnableRFIDRead(b: Boolean)
    begin
        SetEnabled(b, IsRFIDEnabled, '_ENABLE_RFID_READ');
    end;

    procedure EnableRFIDRead()
    begin
        SetEnableRFIDRead(true);
    end;

    procedure DisableRFIDRead()
    begin
        SetEnableRFIDRead(false);
    end;

    procedure RefreshRfidRead()
    var
        DeviceID: Code[20];
    begin
        if PosSession.HardwareProfile.GetDevice("LSC Hardware Profile Devices"::RFID, '', '', 0, DeviceID) then
            RunPosCommand('_REFRESH_RFID', DeviceID);
    end;

    procedure ClearRfidReadTags()
    var
        DeviceID: Code[20];
        i: Integer;
    begin
        for i := 0 to 3 do begin
            if PosSession.HardwareProfile.GetDevice("LSC Hardware Profile Devices"::RFID, '', '', i, DeviceID) then
                ClearRfidReadTags(DeviceID);
        end;
    end;

    procedure ClearRfidReadTags(DeviceId: Code[20])
    begin
        RunPosCommand('_CLEAR_RFID_READ_TAGS', deviceID);
    end;

    internal procedure InitScale(): Boolean
    var
        DeviceID: Code[20];
        ScaleDevice: Record "LSC POS Scale";
        RetailLocalization: Codeunit "LSC Retail Localization Ext.";
    begin
        DeviceID := PosSession.HardwareProfile().GetHardwareProfileDeviceId("LSC Hardware Profile Devices"::Scale);
        if not ScaleDevice.Get(DeviceID) then
            exit(true);

        if RetailLocalization.IsAULocalizationEnabled() then begin
            if not AUProtScale.InitScale() then
                exit(false);
            exit(AUProtScale.InitFormat(PosSession.GetValue("LSC POS Tag"::"CURRSYM"), PosSession.FunctionalityProfile."Amount Rounding to", PosSession.StoreNo));
        end;

        if not ProtScale.InitScale() then
            exit(false);
        exit(ProtScale.InitFormat(PosSession.GetValue("LSC POS Tag"::"CURRSYM"), PosSession.FunctionalityProfile."Amount Rounding to", PosSession.StoreNo));
    end;

    internal procedure ScaleWeigh(Description: Text[100]; UnitPrice: Decimal; TareWeight: Decimal; UnitOfMeasure: Text[10]; var Weight: Decimal; var SalesPrice: Decimal; var Displayed: Boolean): Boolean
    var
        DeviceID: Code[20];
        ScaleDevice: Record "LSC POS Scale";
        RetailLocalization: Codeunit "LSC Retail Localization Ext.";
    begin
        DeviceID := PosSession.HardwareProfile().GetHardwareProfileDeviceId("LSC Hardware Profile Devices"::Scale);
        if not ScaleDevice.Get(DeviceID) then
            exit(false);

        InitScale();

        if RetailLocalization.IsAULocalizationEnabled() then begin
            AUProtScale.SetUnitPrice(UnitPrice);
            AUProtScale.SetTareWeight(TareWeight);
            AUProtScale.SetTareCalculation(not ScaleDevice."Tare Calculation");
            AUProtScale.SetWeightConversionFactor(ScaleDevice."Weight Conversion Factor");
            AUProtScale.SetUnitPriceConversionFactor(ScaleDevice."Unit Price Conversion Factor");
            AUProtScale.SetDescription(Description);
            if (AUProtScale.ScaleWeigh()) then begin
                Weight := AUProtScale.GetWeight();
                SalesPrice := AUProtScale.GetSalesPrice();
                exit(true);
            end;
        end else begin
            ProtScale.SetUnitPrice(UnitPrice);
            ProtScale.SetTareWeight(TareWeight);
            ProtScale.SetTareCalculation(not ScaleDevice."Tare Calculation");
            ProtScale.SetWeightConversionFactor(ScaleDevice."Weight Conversion Factor");
            ProtScale.SetUnitPriceConversionFactor(ScaleDevice."Unit Price Conversion Factor");
            ProtScale.SetDescription(Description);
            if (ProtScale.ScaleWeigh()) then begin
                Weight := ProtScale.GetWeight();
                SalesPrice := ProtScale.GetSalesPrice();
                exit(true);
            end;
        end;
        exit(false);
    end;

    internal procedure GetFormattedLength(var Text: Text[30]; MaxLength: Integer) RetLength: Integer
    begin
        RetLength := StrLen(Text);
        if RetLength > MaxLength then begin
            Text := CopyStr(Text, 1, MaxLength);
            RetLength := MaxLength;
        end;
    end;

    internal procedure ClearLastQty()
    begin
        LastQty := 0;
    end;

    [Obsolete('Not used', '27.0')]
    procedure InitMSR()
    begin
    end;

    [Obsolete('Not used', '27.0')]
    procedure InitMSR(RoleID: code[10]; SubRoleID: Code[20])
    begin
    end;

    [Obsolete('Not used', '27.0')]
    procedure InitScanner()
    begin
    end;

    [Obsolete('Not used', '27.0')]
    procedure InitScanner(RoleID: Code[10]; SubRoleID: Code[20])
    begin
    end;

    [Obsolete('Not used', '27.0')]
    procedure InitRFID()
    begin
    end;

    [Obsolete('Not used', '27.0')]
    procedure InitRFID(RoleID: Code[10]; SubRoleID: Code[20])
    begin
    end;

    [Obsolete('Not used', '27.0')]
    procedure InitDrawer()
    begin
    end;

    [Obsolete('Not used', '27.0')]
    procedure InitDrawer(RoleID: Code[10]; SubRoleID: Code[20])
    begin
    end;

    local procedure RunPosCommand(Command: Text; Parameter: Text)
    var
        PosCtrlInterface: Codeunit "LSC POS Control Interface";
    begin
        PosCtrlInterface.PostEvent('RUNCOMMAND', Command, Parameter, '');
    end;

    // Exposed for partners to use in their own features that will use the lights
    // Will evolve into a better API after requirements have been gathered
    /// <summary>
    /// Switches on a light on the POS
    /// </summary>
    procedure SwitchOnLight(deviceID: Text; lightNumber: Integer; blinkOnCycle: Integer; blinkOffCycle: Integer; color: Integer; alarm: Integer)
    var
        PosCtrlInterface: Codeunit "LSC POS Control Interface";
        Params: JsonObject;
        ParamsJson: Text;
    begin
        Params.Add('on', true);
        Params.Add('deviceId', deviceID);
        Params.Add('lightNumber', lightNumber);
        Params.Add('blinkOnCycle', blinkOnCycle);
        Params.Add('blinkOffCycle', blinkOffCycle);
        Params.Add('color', color);
        Params.Add('alarm', alarm);
        Params.WriteTo(ParamsJson);
        PosCtrlInterface.PostEvent('RUNCOMMAND', '_LIGHTSWITCH', ParamsJson, '');
    end;

    // Exposed for partners to use in their own features that will use the lights
    // Will evolve into a better API after requirements have been gathered
    /// <summary>
    /// Switches off a light on the POS
    /// </summary>
    procedure SwitchOffLight(deviceID: Text; lightNumber: Integer)
    var
        PosCtrlInterface: Codeunit "LSC POS Control Interface";
        Params: JsonObject;
        ParamsJson: Text;
    begin
        Params.Add('on', false);
        Params.Add('deviceId', deviceID);
        Params.Add('lightNumber', lightNumber);
        Params.WriteTo(ParamsJson);
        PosCtrlInterface.PostEvent('RUNCOMMAND', '_LIGHTSWITCH', ParamsJson, '');
    end;

    [IntegrationEvent(false, false)]
    local procedure OnDisplay(Text1: Text[50]; Text2: Text[50]; var ReturnValue: Boolean; var Handled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeOpenDrawerEx(var retVal: Boolean; var IsHandled: Boolean)
    begin
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnAfterInsertNewTransaction, '', false, false)]
    local procedure OnNewTrans(var POSTransaction: Record "LSC POS Transaction")
    var
        Terminal: Record "LSC POS Terminal";
    begin
        if Terminal.Get(POSTransaction."POS Terminal No.") then
            if Terminal."Customer Display Text 1" <> '' then
                Display(Terminal."Customer Display Text 1", Terminal."Customer Display Text 2");
    end;
}

