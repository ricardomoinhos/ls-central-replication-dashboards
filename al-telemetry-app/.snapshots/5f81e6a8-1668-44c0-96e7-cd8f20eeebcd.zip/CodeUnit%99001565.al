codeunit 99001565 "LSC POS DataSet Utility"
{

    var
        POSTransLine: Record "LSC POS Trans. Line";
        TempFieldRec: Record "Field" temporary;
        FlowFieldBuffer: Record "LSC FlowField Buffer" temporary;
        SearchHitsTmp: Record "LSC Search Index Result" temporary;
        RecRef: RecordRef;
        KeyFieldRef: FieldRef;
        PosFormatting: Codeunit "LSC POS Formatting";
        PosSession: Codeunit "LSC POS Session";
        StdFormattingArray: array[32] of Text;
        ColumnCaptionArray: array[32] of Text;
        ColumnPosTagArray: array[32] of Text;
        LastError: Text;
        JournalLineFonts: Dictionary of [Enum "LSC POS Journal Mode", Code[20]];
        JournalLineButtonSkins: Dictionary of [Enum "LSC POS Journal Mode", Code[20]];
        ColumnSourceExprIDArray: array[32] of Code[30];
        DataTableID: Code[20];
        MaxRecFilterField: array[6] of Integer;
        FieldNoArray: array[256] of Integer; // 256 since it has been used to store other "hidden" values like SourceExpr -123456
        FieldAlignmentArray: array[32] of Integer;
        FieldFormattingArray: array[32] of Integer;
        OptionMemberArray: array[32] of Text;
        FieldTypeArray: array[256] of Integer;
        ColumnKeyArray: array[32] of Integer;
        ColumnPreferedWidthArray: array[32] of Integer;
        ColumnSortOrderArray: array[32] of Integer;
        KeyValueFieldNo: array[3] of Integer;
        DataTableMinWidth: Integer;
        MaxPages: Integer;
        MarkMode: Integer;
        TableRows: Integer;
        TableColumns: Integer;
        Counted: Integer;
        CurrTableNo: Integer;
        DefaultColumnNo: Integer;
        TableIndex: Integer;
        JournalLineNo: Integer;
        JournalLineType: Integer;
        JournalCurrColor: Enum "LSC POS Journal Mode";
        VisibleTableColumns: Integer;
        VisibleTableRows: Integer;
        C: Integer;
        R: Integer;
        SearchType: Enum "LSC POS DataTable Search Type";
        ColumnFixedSortingArray: array[32] of Boolean;
        ColumnIsImageArray: array[32] of Boolean;
        TransServerActive: Boolean;
        Online: Boolean;
        JournalMode: Boolean;
        FlowFieldBufferActive: Boolean;
        UseHits: Boolean;
        DontUseLoadFields: Boolean;
        FieldValidationError: Label '''%1'' is not a valid %2';

    internal procedure ImportDataSet(var LSDataSet: Codeunit "LSC DataSet"; CallInsModTrigger: Boolean; OnlyInsert: Boolean) affectedRecords: Integer
    var
        WSRequestSetup: Record "LSC WS Request Setup";
        XVariant: Variant;
        ImpRecRef: RecordRef;
        ImpRecID: RecordID;
        ImpFldRef: FieldRef;
        LastWSId: Text[30];
        ValidationError: Text;
        ColumnName: Text;
        Cols: Integer;
        Rows: Integer;
        Coltype: Integer;
        ColumnNo: Integer;
        R: Integer;
        Ins: Boolean;
        Ok: Boolean;
        Text005: Label 'DataSet does not contain RecordID column (#REC_ID#)';
    begin
        TableIndex := 0;
        ImpRecRef.Open(LSDataSet.GetTableNo);
        Cols := LSDataSet.GetColumns;
        Rows := LSDataSet.GetRows;

        if Rows < 1 then
            exit;

        LSDataSet.SelectRow(0);
        if LSDataSet.GetColumnName(Cols - 1) <> '#REC_ID#' then
            Error(Text005);

        for R := 1 to Rows do begin
            Ok := true;
            LSDataSet.SelectRow(R - 1);
            Clear(XVariant);
            LSDataSet.GetValue(Cols - 1, XVariant);
            if not Evaluate(ImpRecID, Format(XVariant)) then
                ImpRecID := LSDataSet.GetUpdatedRecordID(XVariant);

            if not ImpRecRef.Get(ImpRecID) then begin
                ImpRecRef.Init;
                Ins := true;
            end else begin
                Ins := false;
                if OnlyInsert then
                    Ok := false
                else
                    if ImpRecRef.Number = Database::"LSC WS Request" then begin
                        ImpFldRef := ImpRecRef.Field(1);
                        if Format(ImpFldRef.Value) <> LastWSId then begin
                            WSRequestSetup.SetRange("Request ID", Format(ImpFldRef.Value));
                            WSRequestSetup.DeleteAll;
                            LastWSId := ImpFldRef.Value;
                        end;
                    end;
            end;

            if Ok then begin
                for C := 1 to Cols - 1 do begin
                    ColumnName := LSDataSet.GetColumnName(C);
                    ColumnNo := LSDataSet.GetColumnFieldNo(C);
                    if (not IsSystemField(ColumnName)) and (ColumnName <> '#REC_ID#') then begin
                        if ImpRecRef.FieldExist(ColumnNo) then begin
                            ImpFldRef := ImpRecRef.Field(ColumnNo);
                            Coltype := LSDataSet.GetColumnType(C);
                            ImportField(C, ImpFldRef, LSDataSet, Coltype, ValidationError, false);
                        end;
                    end;
                end;
            end;

            if Ins then
                ImpRecRef.Insert(CallInsModTrigger)
            else
                if ImpRecRef.Modify(CallInsModTrigger) then;

            if Ok then
                affectedRecords += 1;
        end;
    end;

    local procedure IsSystemField(ColumnName: Text): Boolean
    begin
        exit(ColumnName in [
            '$systemId',
            'SystemCreatedAt',
            'SystemCreatedBy',
            'SystemModifiedAt',
            'SystemModifiedBy'
        ]);
    end;

    internal procedure ImportField(pColumnNo: Integer; var pFldRef: FieldRef; var pDataSet: Codeunit "LSC DataSet"; pDataType: Integer; var pValidationError: Text; pValidate: Boolean): Boolean
    var
        RecRef: RecordRef;
        TempBlobStore: Codeunit "Temp Blob";
        BlobUtils: Codeunit "LSC Blob Utils";
        XText: Text;
        XVariant: Variant;
    begin
        case pDataType of
            "LSC ColumnType"::"Option".AsInteger(): // if pDataType > 7
                if pDataSet.GetValueAsString(pColumnNo, XText) then
                    exit(ImportFieldEx(pFldRef, XText, pDataType, pValidationError, pValidate));
            "LSC ColumnType"::"Binary".AsInteger():
                if pDataSet.GetValue(pColumnNo, XVariant) then begin
                    XText := XVariant;
                    XText := BlobUtils.ConvertFromBase64(XText);
                    BlobUtils.WriteToBlob(XText, TempBlobStore);
                    RecRef := pFldRef.Record();
                    TempBlobStore.ToRecordRef(RecRef, pFldRef.Number);
                end;
            else
                if pDataSet.GetValue(pColumnNo, XVariant) then
                    exit(ImportFieldEx(pFldRef, XVariant, pDataType, pValidationError, pValidate));
        end;
        exit(true);
    end;

    internal procedure ImportFieldEx(var PFldRef: FieldRef; PVariant: Variant; PDataType: Integer; var PValidationError: Text; PValidate: Boolean): Boolean
    var
        XDateTime, TempDateTime : DateTime;
        XDecimal: Decimal;
        XDate: Date;
        XInteger: Integer;
        XTime: Time;
        XText: Text;
    begin
        ClearLastError;

        case PDataType of
            "LSC ColumnType"::"Integer".AsInteger(),
            "LSC ColumnType"::"Boolean".AsInteger(),
            "LSC ColumnType"::"Option".AsInteger():
                begin
                    if PVariant.IsText then begin
                        if not Evaluate(XInteger, Format(PVariant)) then begin
                            PValidationError := StrSubstNo(FieldValidationError, Format(PVariant), Format(PFldRef.Type));
                            exit(false);
                        end;
                    end else
                        XInteger := PVariant;

                    if PValidate then
                        PFldRef.Validate(XInteger)
                    else
                        PFldRef.Value := XInteger;
                end;
            "LSC ColumnType"::Double.AsInteger():
                begin
                    if PVariant.IsText then begin
                        if not Evaluate(XDecimal, Format(PVariant)) then begin
                            PValidationError := StrSubstNo(FieldValidationError, Format(PVariant), Format(PFldRef.Type));
                            exit(false);
                        end
                    end else
                        XDecimal := PVariant;

                    if PValidate then
                        PFldRef.Validate(XDecimal)
                    else
                        PFldRef.Value := XDecimal;
                end;
            "LSC ColumnType"::"DateTime".AsInteger():
                begin
                    if PVariant.IsText then begin
                        if not Evaluate(XDateTime, Format(PVariant)) then begin
                            PValidationError := StrSubstNo(FieldValidationError, Format(PVariant), Format(PFldRef.Type));
                            exit(false);
                        end;
                    end else begin
                        XTime := Variant2Time(PVariant);
                        if Format(PFldRef.Type) = 'Time' then begin
                            if PValidate then
                                PFldRef.Validate(XTime)
                            else
                                PFldRef.Value := XTime;
                            exit(true);
                        end;

                        XDate := Variant2Date(PVariant);
                        if Format(PFldRef.Type) = 'Date' then begin
                            if PValidate then
                                PFldRef.Validate(XDate)
                            else
                                PFldRef.Value := XDate;
                            exit(true);
                        end;

                        XDateTime := CreateDateTime(XDate, XTime);
                    end;

                    if PValidate then
                        PFldRef.Validate(XDateTime)
                    else
                        PFldRef.Value := XDateTime;
                end;
            "LSC ColumnType"::"Date".AsInteger():
                begin
                    if PVariant.IsText then begin
                        if not Evaluate(XDateTime, Format(PVariant)) then begin
                            PValidationError := StrSubstNo(FieldValidationError, Format(PVariant), Format(PFldRef.Type));
                            exit(false);
                        end;
                        XDate := DT2Date(XDateTime);
                    end else
                        XDate := Variant2Date(PVariant);

                    if PValidate then
                        PFldRef.Validate(XDate)
                    else
                        PFldRef.Value := XDate;
                end;
            "LSC ColumnType"::"Time".AsInteger():
                begin
                    if PVariant.IsText then begin
                        if not Evaluate(XTime, Format(PVariant)) then begin
                            if Evaluate(TempDateTime, format(PVariant)) then begin //text could be in datetime format
                                if not Evaluate(XTime, Format(DT2Time(TempDateTime))) then begin
                                    PValidationError := StrSubstNo(FieldValidationError, Format(PVariant), Format(PFldRef.Type));
                                    exit(false);
                                end;
                            end else begin
                                PValidationError := StrSubstNo(FieldValidationError, Format(PVariant), Format(PFldRef.Type));
                                exit(false);
                            end;
                        end;
                    end else
                        XTime := Variant2Time(PVariant);

                    if PValidate then
                        PFldRef.Validate(XTime)
                    else
                        PFldRef.Value := XTime;
                end;
            else begin
                XText := PVariant;
                if PValidate then
                    PFldRef.Validate(XText)
                else
                    PFldRef.Value := XText; // Variant; // cuts off first part of a CODE
            end;
        end;

        PValidationError := GetLastErrorText;
        exit(PValidationError = '');
    end;

    internal procedure FillDataSet(Unformatted: Boolean; var LSDataSet: Codeunit "LSC DataSet"; pIncludeRecIDs: Boolean)
    begin
        FillDataSetRows(Unformatted, LSDataSet, 1, GetCount, pIncludeRecIDs);
    end;

    internal procedure FillDataSetRowsEx(Unformatted: Boolean; var LSDataSet: Codeunit "LSC DataSet"; pStartRow: Integer; pDataRows: Integer; pIncludeRecIDs: Boolean; pSingleRow: Boolean): Boolean
    var
        FldRef: FieldRef;
        TempBlob: Codeunit "Temp Blob";
        BlobUtil: Codeunit "LSC Blob Utils";
        SearchUtil: Codeunit "LSC Search Index";
        ValidateCodeunit: Codeunit "LSC POS Zoom Validation";
        EPOSCtrl: Codeunit "LSC POS Control Interface";
        SourceExprUtil: Codeunit "LSC Data Table SourceExpr Util";
        FVar: Variant;
        XDateTime: DateTime;
        XDate: Date;
        XDecimal: Decimal;
        XInteger: Integer;
        XTime: Time;
        FilterString: Text;
        DatasetColumnFilter: Text;
        TmpColCaption: Text;
        RecIdColumnOffset: Integer;
        Nxt: Integer;
        CaptionCreated: Boolean;
        FilterUpdate: Boolean;
        CalcFlowFields: Boolean;
    begin
        if RecRef.Number = 0 then
            exit(false);
        TableIndex := 0;
        LSDataSet.CreateTable(Format(RecRef.Name));
        LSDataSet.DBTableRowCount := 1;
        if not pSingleRow then
            LSDataSet.DbTableRowCount := GetCount;

        LSDataSet.Id := DataTableID;
        LSDataSet.TableNo := RecRef.Number;

        LSDataSet.MarkMode := MarkMode;

        if Unformatted then begin
            for C := 1 to TableColumns do begin
                FldRef := RecRef.Field(FieldNoArray[C]);
                FilterString := ConstructFilterString(LSDataSet.GetColumnFilter(C), FldRef.Type);
                if FilterString <> FldRef.GetFilter() then begin
                    FldRef.SetFilter(FilterString);
                    FilterUpdate := true;
                end;

                if true in [C > 32, ColumnCaptionArray[C] = ''] then
                    TmpColCaption := FldRef.Caption
                else
                    TmpColCaption := ColumnCaptionArray[C];
                LSDataSet.AddColumnEx(FldRef.Name, FieldTypeArray[C], TmpColCaption, FldRef.Number);
            end;
        end else begin
            XInteger := LSDataSet.GetSortColumn;
            for C := 1 to TableColumns do begin
                if FieldNoArray[C] > 0 then begin
                    FldRef := RecRef.Field(FieldNoArray[C]);
                    if (CurrTableNo = Database::"LSC Transaction Header") and (FieldNoArray[C] = 5) then begin
                        DatasetColumnFilter := GetTransNoFromReceipt(LSDataSet.GetColumnFilter(C));
                        FilterString := ConstructFilterString(DatasetColumnFilter, FldRef.Type);
                    end else
                        FilterString := ConstructFilterString(LSDataSet.GetColumnFilter(C), FldRef.Type);

                    if FilterString <> FldRef.GetFilter() then begin
                        ValidateCodeunit.SetFilterValidation(FldRef, FilterString);
                        if not ValidateCodeunit.Run() then
                            if XInteger = C then
                                EPOSCtrl.PosMessageBanner(GetLastErrorText(), Enum::"LSC POS Message Banner Level"::Error, 3000);
                        FilterUpdate := true;
                    end;

                    if true in [C > 32, ColumnCaptionArray[C] = ''] then
                        TmpColCaption := FldRef.Caption
                    else
                        TmpColCaption := ColumnCaptionArray[C];

                    LSDataSet.AddColumnEx(FldRef.Name, 0, TmpColCaption, FldRef.Number)
                end else
                    if FieldNoArray[C] < 0 then
                        LSDataSet.AddColumn(ColumnCaptionArray[C], 0);
                LSDataSet.SetColumnAttribute(C, 'KeyNo', ColumnKeyArray[C]);
                LSDataSet.SetColumnAttribute(C, 'ColumnAlignment', FieldAlignmentArray[C]);
                LSDataSet.SetColumnAttribute(C, 'ColumnWidth', ColumnPreferedWidthArray[C]);
                LSDataSet.SetColumnAttribute(C, 'POSTAG', ColumnPosTagArray[C]);
                LSDataSet.SetColumnAttribute(C, 'ISIMAGE', ColumnIsImageArray[C]);
                LSDataSet.SetColumnAttribute(C, 'ColumnType', FieldTypeArray[C]);
                LSDataSet.SetColumnAttribute(C, 'OptionMembers', OptionMemberArray[C]);
            end;
        end;

        // Use Column 0 for DataTable Minimum Width
        LSDataSet.SetColumnAttribute(0, 'ColumnWidth', DataTableMinWidth);

        if LSDataSet.GetColumnFilter(0) = 'RESET' then begin// RESET ACTION WAS PERFORMED
            FilterUpdate := true;
        end;

        LSDataSet.MaxMarkCount := MaxPages;

        if FilterUpdate then begin
            ResetMaxRecFilter;
            Counted := 0;
            LSDataSet.DbTableRowCount := GetCount;
        end;

        if JournalMode then begin
            LSDataSet.AddColumn('#FONT_ID#', 0);
            LSDataSet.AddColumn('#SKIN_ID#', 0);
            LSDataSet.AddColumn('#POS_PDL#', 0);
            LSDataSet.AddColumn('#POS_TDL#', 0);

            RecIdColumnOffset += 4;
        end;

        if pIncludeRecIDs then begin
            LSDataSet.AddColumn('#REC_ID#', 0);
            RecIdColumnOffset += 1;
        end;

        LSDataSet.VisibleColumns := VisibleTableColumns;

        if LSDataSet.GetSortColumn > 0 then begin
            if FieldNoArray[LSDataSet.GetSortColumn] > 0 then begin
                KeyFieldRef := RecRef.Field(FieldNoArray[LSDataSet.GetSortColumn]);
                if ColumnFixedSortingArray[LSDataSet.GetSortColumn] then
                    LSDataSet.SortAscending := ColumnSortOrderArray[LSDataSet.GetSortColumn] = 0;
                SetCurrentKeyIndex(ColumnKeyArray[LSDataSet.GetSortColumn], LSDataSet.GetSortAscending);
            end;
        end
        else
            if (LSDataSet.GetSortColumn = 0) then begin // Sort column not selected (first time data)
                if DefaultColumnNo = 0 then begin
                    DefaultColumnNo := 1;
                end;

                LSDataSet.DefaultColumn := DefaultColumnNo;

                if (FieldNoArray[DefaultColumnNo] > 0) and (ColumnKeyArray[DefaultColumnNo] > 0) then begin
                    LSDataSet.SortColumn := DefaultColumnNo;
                    LSDataSet.SortAscending := ColumnSortOrderArray[DefaultColumnNo] = 0;

                    KeyFieldRef := RecRef.Field(FieldNoArray[LSDataSet.GetSortColumn]);
                    SetCurrentKeyIndex(ColumnKeyArray[LSDataSet.GetSortColumn], LSDataSet.GetSortAscending);
                end;
            end;

        if (not pSingleRow) and (not UseHits) then begin
            if not RecRef.FindFirst then begin
                exit(true);
            end;

            if pStartRow > 1 then begin
                Nxt := RecRef.Next(pStartRow - 1);
                if Nxt < pStartRow - 1 then begin
                    exit(true);
                end;
            end;
        end;

        R := pStartRow + pDataRows;
        while pStartRow < R do begin
            if UseHits then
                while not SearchUtil.HitToRec(SearchHitsTmp, RecRef) do
                    if SearchHitsTmp.Next = 0 then
                        exit(true);

            if FlowFieldBufferActive then begin
                CalcFlowFields := false;
                FlowFieldBuffer.GetFlowFields(FlowFieldBuffer, RecRef);
            end else
                CalcFlowFields := true;
            LSDataSet.InsertRow(pStartRow - 1);
            pStartRow += 1;

            if JournalMode then
                SetJournalLineInfo(RecRef, LSDataSet);

            if pIncludeRecIDs then
                LSDataSet.SetValue(TableColumns + RecIdColumnOffset, Format(RecRef.RecordId));

            for C := 1 to TableColumns do begin
                if Unformatted then begin
                    FldRef := RecRef.Field(FieldNoArray[C]);

                    if (Format(FldRef.Class) = 'FlowField') and CalcFlowFields then
                        FldRef.CalcField;

                    FVar := FldRef.Value;
                    case FieldTypeArray[C] of
                        "LSC ColumnType"::"Integer".AsInteger(),
                        "LSC ColumnType"::"Boolean".AsInteger(),
                        "LSC ColumnType"::"Option".AsInteger():
                            begin
                                XInteger := FVar;
                                LSDataSet.SetValue(C, XInteger);
                            end;
                        "LSC ColumnType"::"Double".AsInteger():
                            begin
                                XDecimal := FVar;
                                LSDataSet.SetValue(C, XDecimal);
                            end;
                        "LSC ColumnType"::"DateTime".AsInteger():
                            begin
                                XDateTime := FVar;
                                if XDateTime <> 0DT then
                                    LSDataSet.SetValue(C, XDateTime);
                            end;
                        "LSC ColumnType"::"Date".AsInteger():
                            begin
                                XDate := FVar;
                                if XDate <> 0D then
                                    LSDataSet.SetValue(C, XDate);
                            end;
                        "LSC ColumnType"::"Time".AsInteger():
                            begin
                                XTime := FVar;
                                if XTime <> 0T then begin
                                    XDateTime := CreateDateTime(Today, XTime);
                                    LSDataSet.SetValue(C, XDateTime);
                                end;
                            end;
                        "LSC ColumnType"::"Binary".AsInteger():
                            begin
                                if FldRef.CalcField then begin
                                    TempBlob.FromRecordRef(RecRef, FldRef.Number);
                                    LSDataSet.SetValue(C, BlobUtil.ReadFromBlobTo64(TempBlob));
                                end;
                            end;
                        else
                            LSDataSet.SetValue(C, Format(FVar)); // Text Variables
                    end;
                end else begin
                    if FieldNoArray[C] = -123456 then begin // SourceExpr Field
                        LSDataSet.SetValue(C, SourceExprUtil.GetSourceExpr(DataTableID, ColumnSourceExprIDArray[C], RecRef, POSTransLine));
                    end else
                        if (FieldNoArray[C] <> 0) then begin
                            if JournalMode then
                                CaptionCreated := CreateJournalLinesCaption(RecRef, FieldNoArray[C], C, LSDataSet);

                            if not CaptionCreated then begin
                                if FieldNoArray[C] = -1 then  // OnPurchaseOrderField (hardcoding for Inv.Lookup)
                                    LSDataSet.SetValue(C, CreateNetInventoryCaption(RecRef))
                                else
                                    if FieldNoArray[C] = -2 then // OnPurchaseOrderField (hardcoding for Inv.Lookup)
                                        LSDataSet.SetValue(C, CreateOnPurchOrderCaption(RecRef))
                                    else
                                        if ColumnIsImageArray[C] then begin
                                            FldRef := RecRef.Field(FieldNoArray[C]);
                                            if Format(FldRef.Type) = 'BLOB' then begin
                                                LSDataSet.SetValue(C, ''); // Note: blob fields should be migrated to media/mediaset and have a RetailImage
                                            end else
                                                LSDataSet.SetValue(C, Format(FldRef.Value));
                                        end else begin
                                            FldRef := RecRef.Field(FieldNoArray[C]);
                                            SetDataSetValue(LSDataSet, C, FldRef, FieldFormattingArray[C], StdFormattingArray[C], CalcFlowFields);
                                        end;
                            end;
                        end;
                end;
            end;

            if pSingleRow then
                exit(true);

            if UseHits then begin
                if SearchHitsTmp.Next = 0 then
                    exit(true);
            end else
                if RecRef.Next = 0 then
                    exit(true);
        end;
        exit(true);
    end;

    internal procedure FillDataSetFromSearchHits(var pHitsTmp: Record "LSC Search Index Result" temporary; Unformatted: Boolean; var LSDataSet: Codeunit "LSC DataSet"; pIncludeRecIDs: Boolean)
    begin
        SearchHitsTmp.Copy(pHitsTmp, true); //share table
        if SearchHitsTmp.FindFirst() then;
        UseHits := true;
        FillDataSetRowsEx(Unformatted, LSDataSet, 1, pHitsTmp.Count, pIncludeRecIDs, false);
        LSDataSet.DbTableRowCount := LSDataSet.GetRows;
        UseHits := false;
    end;

    internal procedure SetDataSetValue(var LSDataSet: Codeunit "LSC DataSet"; ColumnNo: Integer; var FldRef: FieldRef; Formatting: Option "None",Amount,Price,Quantity,Standard; StdFormatting: Text; CalcFlowFields: Boolean)
    begin
        LSDataSet.SetValue(ColumnNo, GetValueText(FldRef, Formatting, StdFormatting, CalcFlowFields));
    end;

    procedure GetValueText(var FldRef: FieldRef; Formatting: Option "None",Amount,Price,Quantity,Standard; StdFormatting: Text; CalcFlowFields: Boolean): Text
    var
        OptionNo: Integer;
    begin
        if (Format(FldRef.Class) = 'FlowField') and CalcFlowFields then
            FldRef.CalcField;

        if Format(FldRef.Type) = 'BLOB' then  //NOTE *************** leave empty for now
            exit('');

        if Format(FldRef.Type) = 'Option' then begin
            OptionNo := FldRef.Value;
            exit(FldRef.GetEnumValueCaptionFromOrdinalValue(OptionNo));
        end;

        case Formatting of
            Formatting::"None":
                exit(Format(FldRef.Value));
            Formatting::Amount:
                exit(PosFormatting.FormatAmount(FldRef.Value));
            Formatting::Price:
                exit(PosFormatting.FormatPrice(FldRef.Value));
            Formatting::Quantity:
                exit(PosFormatting.FormatQty(FldRef.Value));
            Formatting::Standard:
                exit(Format(FldRef.Value, 0, StdFormatting));
        end;
    end;

    internal procedure FillDataSetRows(Unformatted: Boolean; var LSDataSet: Codeunit "LSC DataSet"; pStartRow: Integer; pDataRows: Integer; pIncludeRecIDs: Boolean): Boolean
    begin
        exit(FillDataSetRowsEx(Unformatted, LSDataSet, pStartRow, pDataRows, pIncludeRecIDs, false));
    end;

    internal procedure FillDataSetSingleRow(Unformatted: Boolean; var LSDataSet: Codeunit "LSC DataSet"; pIncludeRecIDs: Boolean): Boolean
    begin
        exit(FillDataSetRowsEx(Unformatted, LSDataSet, 1, 1, pIncludeRecIDs, true));
    end;

    internal procedure ConstructFilterString(FilterIn: Text; FieldType: FieldType) filterOut: Text
    var
        RangeTokenFound: Boolean;
        EscapeTokenFound: Boolean;
        FilterSyntax: Label '%1%2%3', Locked = true;
    begin
        if FilterIn = '' then
            exit;
        filterOut := '';

        if SearchType = SearchType::None then
            exit(FilterIn);

        if not (FieldType in [FieldType::"Text", FieldType::"Code"]) then
            exit(FilterIn);

        RangeTokenFound := filterIn.Contains('<>=');
        if not RangeTokenFound then
            RangeTokenFound := FilterIn.Contains('..');

        if StrLen(FilterIn) > 2 then begin
            EscapeTokenFound := FilterIn.StartsWith('''') and FilterIn.EndsWith('''');
            if EscapeTokenFound then begin
                filterOut += '''';
                FilterIn := CopyStr(FilterIn, 2, StrLen(FilterIn) - 2)
            end;
        end;

        if FilterIn.StartsWith('@') then
            FilterIn := FilterIn.Substring(2);

        FilterIn := DelChr(FilterIn, '=', '*');

        if not RangeTokenFound then begin
            case SearchType of
                SearchType::Beginning:
                    filterOut += StrSubstNo(FilterSyntax, '@', FilterIn, '*');
                SearchType::Whole:
                    filterOut += StrSubstNo(FilterSyntax, '@', FilterIn, '');
                SearchType::"Any Part":
                    filterOut += StrSubstNo(FilterSyntax, '@*', FilterIn.Replace(' ', '*&@*'), '*');
                SearchType::FullText:
                    filterOut += StrSubstNo(FilterSyntax, '&&', FilterIn.Replace(' ', '*&&&'), '*');
            end;
        end else
            filterOut := FilterIn;

        if EscapeTokenFound then
            filterOut += '''';
    end;

    internal procedure GetFieldTypeInt(var pFldRef: FieldRef): Integer
    begin
        exit(GetFieldTypeEnum(pFldRef).AsInteger());
    end;

    internal procedure GetFieldTypeEnum(var pFldRef: FieldRef) FieldTypeEnum: Enum "LSC ColumnType"
    var
        FieldRec: Record "Field";
    begin
        if not TempFieldRec.Get(RecRef.Number, pFldRef.Number) then begin
            if FieldRec.Get(RecRef.Number, pFldRef.Number) then begin
                TempFieldRec := FieldRec;
                TempFieldRec.Insert();
            end;
        end;

        case TempFieldRec.Type of
            TempFieldRec.Type::"Integer", TempFieldRec.Type::"BigInteger":
                exit(FieldTypeEnum::"Integer");
            TempFieldRec.Type::"Decimal":
                exit(FieldTypeEnum::"Double");
            TempFieldRec.Type::"DateTime":
                exit(FieldTypeEnum::"DateTime");
            TempFieldRec.Type::"Boolean":
                exit(FieldTypeEnum::"Boolean");
            TempFieldRec.Type::"BLOB":
                exit(FieldTypeEnum::"Binary");
            TempFieldRec.Type::"Date":
                exit(FieldTypeEnum::"Date");
            TempFieldRec.Type::"Time":
                exit(FieldTypeEnum::"Time");
            TempFieldRec.Type::"Option":
                exit(FieldTypeEnum::"Option");
            else
                exit(FieldTypeEnum::"Text");
        end;
    end;

    internal procedure SetTable(TableNo: Integer)
    begin
        RecRef.Close;
        Clear(RecRef);
        RecRef.Open(TableNo);

        CurrTableNo := TableNo;
    end;

    internal procedure AddDatasetField(Unformatted: Boolean; ColumnNo: Integer; FieldNumber: Integer; Alignment: Option Center,Left,Right; Formatting: Option "None",Amount,Price,Quantity,Standard)
    var
        FldRef: FieldRef;
    begin
        FieldNoArray[ColumnNo] := FieldNumber;

        if ColumnNo < 33 then begin
            FieldAlignmentArray[ColumnNo] := Alignment;
            FieldFormattingArray[ColumnNo] := Formatting;
        end;

        FieldTypeArray[ColumnNo] := 0;
        if FieldNumber > 0 then begin
            FldRef := RecRef.Field(FieldNumber);
            FieldTypeArray[ColumnNo] := GetFieldTypeInt(FldRef);
            if ColumnNo <= 32 then
                OptionMemberArray[ColumnNo] := FldRef.OptionMembers;
            LoadField(ColumnNo, FieldNumber);
        end;

        if ColumnNo > TableColumns then
            TableColumns := ColumnNo;
    end;

    local procedure LoadField(pColumnNo: Integer; pFieldNo: Integer)
    var
        HasError: Boolean;
    begin
        if DontUseLoadFields then
            exit;
        if pFieldNo <= 0 then
            exit;
        if pColumnNo = 1 then
            HasError := RecRef.SetLoadFields(pFieldNo)
        else
            HasError := RecRef.AddLoadFields(pFieldNo);
        if HasError then
            ClearLastError();
    end;

    internal procedure AddAllFields(Unformatted: Boolean)
    var
        i: Integer;
        TmpFields: Record "Field";
    begin
        TmpFields.SetRange(TableNo, RecRef.Number);
        TmpFields.SetFilter(ObsoleteState, '<>%1', TmpFields.ObsoleteState::Removed);
        DontUseLoadFields := true;
        i := 1;
        if TmpFields.FindSet() then
            repeat
                if TmpFields.Enabled then begin
                    AddDatasetField(Unformatted, i, TmpFields."No.", 1, 0); //LEFT ALIGN DEFAULT
                    i += 1;
                end;
            until TmpFields.Next = 0;
    end;

    internal procedure AddDatasetFieldNo(pColumnNo: Integer; pFieldNo: Integer)
    var
        FldRef: FieldRef;
    begin
        FieldNoArray[pColumnNo] := pFieldNo;

        if pFieldNo > 0 then begin
            FldRef := RecRef.Field(pFieldNo);
            FieldTypeArray[pColumnNo] := GetFieldTypeInt(FldRef);
            LoadField(pColumnNo, pFieldNo);
        end
        else
            FieldTypeArray[pColumnNo] := 0;

        if pColumnNo > TableColumns then
            TableColumns := pColumnNo;
    end;

    internal procedure AddFieldNoArray(var pArray: array[100] of Integer; pLength: Integer)
    var
        i: Integer;
    begin
        for i := 1 to pLength do
            AddDatasetFieldNo(i, pArray[i]);
    end;

    internal procedure GetColumnIndexFromFieldNo(pFieldNo: Integer): Integer
    var
        i: Integer;
    begin
        for i := 1 to TableColumns do begin
            if FieldNoArray[i] = pFieldNo then
                exit(i);
        end;
        exit(-1);
    end;

    internal procedure InitDataTable(var DataTableSetup: Record "LSC POS Data Table")
    var
        DataTableColumnSetup: Record "LSC POS Data Table Columns";
    begin
        UseHits := false;

        DataTableColumnSetup.Reset;
        DataTableColumnSetup.SetRange("Data Table ID", DataTableSetup."Data Table ID");
        DataTableColumnSetup.SetRange("Table No.", DataTableSetup."Table No.");

        InitDataTableDyn(DataTableSetup, DataTableColumnSetup);
    end;

    internal procedure InitDataTableDyn(var pDataTableSetup: Record "LSC POS Data Table"; var pDataTableColumnSetup: Record "LSC POS Data Table Columns")
    var
        ButtonTranslation: Record "LSC POS Button Translation";
        columnCaption: Text;
    begin
        DataTableID := pDataTableSetup."Data Table ID";
        DontUseLoadFields := pDataTableSetup."Load All Fields (SQL)";

        if RecRef.Number = 0 then
            SetTable(pDataTableSetup."Table No.");

        KeyValueFieldNo[1] := pDataTableSetup."Key Value Field 1";
        KeyValueFieldNo[2] := pDataTableSetup."Key Value Field 2";
        KeyValueFieldNo[3] := pDataTableSetup."Key Value Field 3";

        C := 1;

        DataTableMinWidth := pDataTableSetup."Minimum Width";

        if pDataTableColumnSetup.FindSet() then
            repeat
                if pDataTableColumnSetup."Source Expr. ID" <> '' then begin
                    pDataTableColumnSetup."Field No." := -123456;
                end
                else
                    if pDataTableColumnSetup."Special Field Type" > 0 then begin
                        if pDataTableColumnSetup."Special Field Type" <> pDataTableColumnSetup."Special Field Type"::FindByNumberField then
                            if pDataTableColumnSetup."Special Field Type" <> pDataTableColumnSetup."Special Field Type"::FindByNameField then
                                pDataTableColumnSetup."Field No." := -1 * pDataTableColumnSetup."Special Field Type";
                    end;
                if pDataTableColumnSetup."Field No." <> 0 then begin
                    AddDatasetField(false, C, pDataTableColumnSetup."Field No.", pDataTableColumnSetup."Caption Alignment", pDataTableColumnSetup.Formatting);

                    SetColumnStandardFormat(C, pDataTableColumnSetup."Std. Formatting Text");
                    SetColumnKeyIndex(C, pDataTableColumnSetup."Key No.", pDataTableColumnSetup."Default Sort Order");
                    SetColumnFixedSorting(C, pDataTableColumnSetup."Sorting Fixed");
                    SetColumnPreferedWidth(C, pDataTableColumnSetup."Preferred Width %");
                    if pDataTableColumnSetup."Fixed Filter" <> '' then
                        SetFixedFilter(pDataTableColumnSetup."Field No.", pDataTableColumnSetup."Fixed Filter");
                    if pDataTableColumnSetup."Default Column" then
                        SetDefaultColumn(C, pDataTableColumnSetup."Default Sort Order");
                    columnCaption := pDataTableColumnSetup."Column Caption";
                    if ButtonTranslation.Get(pDataTableColumnSetup.Internal_GetDataTableProfile(), DataTableID, C, PosSession.GetLanguageCode()) then
                        columnCaption := ButtonTranslation.Description; // Workaround for Data Table Caption Translations using Button Translations
                    SetColumnCaption(C, columnCaption);

                    SetColumnSourceExpr(C, pDataTableColumnSetup."Source Expr. ID");
                    SetColumnPosTag(C, pDataTableColumnSetup."POS Tag Link");
                    SetColumnIsImage(C, pDataTableColumnSetup."Is Image");
                end;
                C += 1;
            until pDataTableColumnSetup.Next = 0;

        VisibleTableRows := pDataTableSetup."Table Rows";
        VisibleTableColumns := pDataTableSetup."Table Columns";

        MaxPages := pDataTableSetup."UI Page Limit";
        if MaxPages <= 0 then
            MaxPages := 200;

        SearchType := pDataTableSetup."Default Search Type";
        MarkMode := pDataTableSetup."Selection Mode";

        FlowFieldBufferActive := false;
        FlowFieldBuffer.Reset;
        FlowFieldBuffer.DeleteAll;
    end;

    internal procedure SetColumnStandardFormat(ColumnNo: Integer; FormatText: Text[100])
    begin
        StdFormattingArray[ColumnNo] := FormatText;
    end;

    internal procedure InitDataSet()
    begin
        DontUseLoadFields := false;
        ResetMaxRecFilter();
        Counted := 0;
        MarkMode := -1;

        UseHits := false;

        Clear(RecRef);

        DataTableMinWidth := 0;

        CurrTableNo := 0;
        TableRows := 0;
        TableColumns := 0;

        JournalMode := false;

        for C := 1 to 256 do begin
            FieldNoArray[C] := 0;
            FieldTypeArray[C] := 0;
        end;

        for C := 1 to 32 do begin
            FieldAlignmentArray[C] := 0;
            FieldFormattingArray[C] := 0;
            StdFormattingArray[C] := '';
            ColumnFixedSortingArray[C] := false;
            ColumnSortOrderArray[C] := 0;
            ColumnKeyArray[C] := 0;
            ColumnCaptionArray[C] := '';
        end;

        if not TempFieldRec.IsEmpty then
            TempFieldRec.DeleteAll;
    end;

    internal procedure SetRecRefData(var pRecRef: RecordRef)
    begin
        RecRef := pRecRef;
    end;

    internal procedure SetCurrentKeyIndex(Index: Integer; SortAscending: Boolean)
    var
        xIndex: Integer;
        xSortAscending: Boolean;
    begin
        if (Index <= 0) or (Index > RecRef.KeyCount) then
            exit;

        GetCurrentKeyIndex(xIndex, xSortAscending);
        if (xIndex = Index) and (xSortAscending = SortAscending) then
            exit;

        RecRef.CurrentKeyIndex(Index);
        RecRef.Ascending := SortAscending;
    end;

    internal procedure GetCurrentKeyIndex(var Index: Integer; var SortAscending: Boolean)
    begin
        Index := RecRef.CurrentKeyIndex;
        SortAscending := RecRef.Ascending;
    end;

    internal procedure SetColumnKeyIndex(Column: Integer; KeyIndex: Integer; SortOrder: Integer)
    begin
        ColumnKeyArray[Column] := KeyIndex;
        ColumnSortOrderArray[Column] := SortOrder;
    end;

    internal procedure SetColumnFixedSorting(Column: Integer; FixedSorting: Boolean)
    begin
        ColumnFixedSortingArray[Column] := FixedSorting;
    end;

    internal procedure GetRecID(var pRecID: RecordID; pIndex: Integer)
    var
        FldRef: FieldRef;
    begin
        if RecRef.Number = 0 then
            exit;

        if not RecRef.FindFirst() then
            exit;

        if pIndex > 0 then
            RecRef.Next(pIndex);

        pRecID := RecRef.RecordId;

        if JournalMode then begin
            FldRef := RecRef.Field(1); //Entry Type
            JournalLineType := FldRef.Value;
            FldRef := RecRef.Field(2); //Line No.
            JournalLineNo := FldRef.Value;
        end;
    end;

    internal procedure GetRecRefPointer(var pRecRefPtr: RecordRef)
    begin
        pRecRefPtr := RecRef;
    end;

    internal procedure GetFieldRefPointer(pFieldNo: Integer; var pFieldRefPtr: FieldRef)
    begin
        pFieldRefPtr := RecRef.Field(pFieldNo);
    end;

    internal procedure GetCount(): Integer
    begin
        if Counted = 0 then begin
            if RecRef.Number <> 0 then begin
                Counted := RecRef.Count;
            end;
        end;

        exit(Counted);
    end;

    internal procedure FindString(FindText: Text[100]): Integer
    begin
        exit(FindEx(KeyFieldRef, FindText));
    end;

    internal procedure FindByField(FieldNumber: Integer; FindText: Text[100]): Integer
    begin
        KeyFieldRef := RecRef.Field(FieldNumber);
        exit(FindString(FindText));
    end;

    internal procedure FindByColumn(ColumnNo: Integer; FindText: Text[100]): Integer
    begin
        KeyFieldRef := RecRef.Field(FieldNoArray[ColumnNo]);
        exit(FindString(FindText));
    end;

    internal procedure "Filter"(FilterText: Text[100]): Boolean
    begin
        KeyFieldRef.SetFilter(FilterText);
        Counted := 0; //Reset Count
    end;

    internal procedure FilterByField(FieldNumber: Integer; FilterText: Text[100]): Boolean
    begin
        KeyFieldRef := RecRef.Field(FieldNumber);
        exit(Filter(FilterText));
    end;

    internal procedure FilterByColumn(ColumnNo: Integer; FilterText: Text[100]): Boolean
    begin
        KeyFieldRef := RecRef.Field(FieldNoArray[ColumnNo]);
        exit(Filter(FilterText));
    end;

    internal procedure GetLastError(): Text[100]
    begin
        exit(LastError);
    end;

    procedure SetFixedFilter(pFieldNo: Integer; pFilterText: Text)
    var
        TmpFieldRef: FieldRef;
        lOldFilterGroup: Integer;
    begin
        if pFieldNo = -1 then  //Special case for "Net Inventory"
            pFieldNo := 120;

        LoadField(999, pFieldNo);

        TmpFieldRef := RecRef.Field(pFieldNo);

        lOldFilterGroup := RecRef.FilterGroup;
        RecRef.FilterGroup(2);
        TmpFieldRef.SetFilter(ParseTokenString(pFilterText));
        RecRef.FilterGroup(lOldFilterGroup);

        Counted := 0; //Reset Count
    end;

    internal procedure GetFixedFilter() retVal: Text
    var
        lOldFilterGroup: Integer;
    begin
        lOldFilterGroup := RecRef.FilterGroup;
        RecRef.FilterGroup(2);
        retVal := RecRef.GetFilters;
        RecRef.FilterGroup(lOldFilterGroup);
    end;

    internal procedure ResetFixedFilters()
    begin
        if RecRef.Number > 0 then
            RecRef.Reset
    end;

    internal procedure SetDefaultColumn(ColumnNo: Integer; DefaultSortOrder: Option "Ascending","Descending")
    begin
        DefaultColumnNo := ColumnNo;
    end;

    internal procedure ParseTokenString(var pStartPosString: Text): Text
    var
        Token: Text[30];
        Retval: Text[100];
        i: Integer;
        Len: Integer;
        Tokenstart: Integer;
        Tokenlength: Integer;
    begin
        if StrPos(pStartPosString, '[') = 0 then
            exit(pStartPosString);

        Len := StrLen(pStartPosString);
        for i := 1 to Len do begin
            if Tokenstart > 0 then begin
                if pStartPosString[i] = ']' then begin
                    Token[Tokenlength] := 0;
                    case Token of
                        'STORE':
                            Retval += PosSession.StoreNo;
                        'TERMINAL':
                            Retval += PosSession.TerminalNo;
                        'STAFF':
                            Retval += PosSession.StaffID;
                        'ITEM':
                            Retval += POSTransLine.Number;
                        'VARIANT':
                            Retval += POSTransLine."Variant Code";
                        'RECEIPTNO':
                            Retval += POSTransLine."Receipt No.";
                        'LINENO':
                            Retval += Format(POSTransLine."Line No.");
                        'TODAY':
                            Retval += Format(Today);
                        else
                            if CopyStr(Token, 1, 2) = '%=' then //GET VALUE FROM GLOBALS  //ONLY SESSION VARIABLES
                                Retval += PosSession.GetValue(CopyStr(Token, 3))
                            else
                                if CopyStr(Token, 1, 2) = '<#' then //GET VALUE FROM CONTEXT  //ONLY SESSION VARIABLES
                                    Retval += PosSession.GetValue(Token) // ExtractContextKey
                                else
                                    if CopyStr(Token, 1, 8) = 'TRANS.<#' then //GET VALUE FROM CURRENT TRANSACTION
                                        Retval += PosSession.GetValue(CopyStr(Token, 7));
                    end;

                    Tokenstart := 0;
                end
                else begin
                    Token[Tokenlength] := pStartPosString[i];
                    Tokenlength += 1;
                end;
            end
            else
                if pStartPosString[i] = '[' then begin
                    Token := '';
                    Tokenstart := i;
                    Tokenlength := 1;
                end
                else
                    Retval += Format(pStartPosString[i]);
        end;

        exit(Retval);
    end;

    internal procedure FindStartPosition(pStartPosition: Text[100]): Integer
    var
        KRef: KeyRef;
        FldRef: FieldRef;
        CurrKeyValue: Text[30];
        FilterPrefix: Text[2];
        xKeyIndex: Integer;
        FldIndex: Integer;
        p: Integer;
        NewCount: Integer;
        MaxRecsBack: Integer;
        xSortAscending: Boolean;
        Found: Boolean;
    begin
        if RecRef.Number = 0 then
            exit(0);

        if pStartPosition = '' then
            exit(0);

        pStartPosition := ParseTokenString(pStartPosition);

        GetCurrentKeyIndex(xKeyIndex, xSortAscending);
        KRef := RecRef.KeyIndex(xKeyIndex);

        if xSortAscending then
            FilterPrefix := '>='
        else
            FilterPrefix := '<=';

        FldIndex := 1;
        p := StrPos(pStartPosition, ';');
        while p > 0 do begin
            CurrKeyValue := CopyStr(pStartPosition, 1, p - 1);
            if (CurrKeyValue <> '') and (FldIndex <= KRef.FieldCount) then begin
                FldRef := KRef.FieldIndex(FldIndex);
                FldRef.SetFilter(FilterPrefix + '''' + CurrKeyValue + '''');
            end;
            pStartPosition := CopyStr(pStartPosition, p + 1);
            FldIndex += 1;
            p := StrPos(pStartPosition, ';');
        end;

        if (pStartPosition <> '') and (FldIndex <= KRef.FieldCount) then begin
            FldRef := KRef.FieldIndex(FldIndex);
            FldRef.SetFilter(FilterPrefix + '''' + pStartPosition + '''');
        end;

        if RecRef.FindFirst then begin
            Found := true; //NewCount := RecRef.COUNT;
        end;

        while FldIndex > 0 do begin
            FldRef := KRef.FieldIndex(FldIndex);
            FldRef.SetFilter('');
            FldIndex -= 1;
        end;

        if Found then begin
            MaxRecsBack := Round(((VisibleTableRows * MaxPages) / 2), 1, '>');
            NewCount := -RecRef.Next(-MaxRecsBack);
            if NewCount = MaxRecsBack then
                SetMaxRecFilter;

            exit(NewCount);
        end;

        exit(0);
    end;

    internal procedure FindRecordPosition(pRecID: RecordID): Integer
    var
        Position: Integer;
    begin
        if RecRef.Number <> pRecID.TableNo then
            exit(-1);

        if RecRef.Get(pRecID) then begin
            Position := -RecRef.Next(-GetCount);  //Jump back to top to count records
            exit(Position);
        end else
            exit(-1);
    end;

    internal procedure CreateOnPurchOrderCaption(var pRecRef: RecordRef): Text[30]
    var
        InvLookupTable: Record "LSC Inventory Lookup Table";
        PurchaseOrdered: Decimal;
    begin
        if pRecRef.Number <> Database::"LSC Inventory Lookup Table" then
            exit('');

        InvLookupTable.SetPosition(pRecRef.GetPosition(false));
        InvLookupTable.Get(InvLookupTable."Item No.", InvLookupTable."Variant Code", InvLookupTable."Store No.",
           InvLookupTable."Lot No.", InvLookupTable."Serial No.");

        if TransServerActive then
            if Online and (InvLookupTable."Store No." = PosSession.StoreNo) then
                InvLookupTable.UpdateInventory(false)
            else
                InvLookupTable.UpdateInventory(true)
        else
            InvLookupTable.UpdateInventory(false);

        if TransServerActive then
            if Online and (InvLookupTable."Store No." = PosSession.StoreNo) then
                if InvLookupTable."Variant Code" <> '' then
                    PurchaseOrdered := InvLookupTable."Calc. Var. Purch. Order."
                else
                    PurchaseOrdered := InvLookupTable."Calc. Purch. Order."
            else
                if InvLookupTable."Variant Code" <> '' then
                    PurchaseOrdered := InvLookupTable."Var. Purchase Order"
                else
                    PurchaseOrdered := InvLookupTable."Purchase Order"
        else
            if InvLookupTable."Variant Code" <> '' then
                PurchaseOrdered := InvLookupTable."Calc. Var. Purch. Order."
            else
                PurchaseOrdered := InvLookupTable."Calc. Purch. Order.";

        OnAfterCreateOnPurchOrderCaption(PurchaseOrdered, InvLookupTable, TransServerActive, Online);

        exit(PosFormatting.FormatQty(PurchaseOrdered));
    end;

    internal procedure CreateNetInventoryCaption(var pRecRef: RecordRef): Text[30]
    var
        InvLookupTable: Record "LSC Inventory Lookup Table";
        InvLookup2: Record "LSC Inventory Lookup Table";
        ServiceLocator: Codeunit "LSC Service Locator";
        OnPOS: Decimal;
    begin
        if pRecRef.Number <> Database::"LSC Inventory Lookup Table" then
            exit('');

        InvLookupTable.SetPosition(pRecRef.GetPosition(false));
        InvLookupTable.Get(InvLookupTable."Item No.", InvLookupTable."Variant Code", InvLookupTable."Store No.",
          InvLookupTable."Lot No.", InvLookupTable."Serial No.");

        if TransServerActive then
            if Online and (InvLookupTable."Store No." = PosSession.StoreNo) then
                InvLookupTable.UpdateInventory(false)
            else
                InvLookupTable.UpdateInventory(true)
        else
            InvLookupTable.UpdateInventory(false);

        OnPOS := 0;
        if (POSTransLine."Receipt No." <> '') and (InvLookupTable."Store No." = PosSession.StoreNo) then
            OnPOS := ServiceLocator.POSFunctions.GetSerialLotSalesQty(POSTransLine, InvLookupTable."Serial No.", InvLookupTable."Lot No.");

        if PosSession.GetValue("LSC POS Tag"::INVENTORY_LOOKUP_BY_STORE) = '1' then begin
            InvLookup2.SetRange("Item No.", InvLookupTable."Item No.");
            InvLookup2.SetRange("Variant Code", InvLookupTable."Variant Code");
            InvLookup2.SetRange("Store No.", InvLookupTable."Store No.");
            InvLookup2.CalcSums("Net Inventory");
            InvLookupTable."Net Inventory" += InvLookup2."Net Inventory";
        end else
            InvLookupTable."Net Inventory" := InvLookupTable."Net Inventory" - OnPOS;

        exit(PosFormatting.FormatQty(InvLookupTable."Net Inventory"));
    end;

    internal procedure SetTransServerActive()
    begin
        TransServerActive := true;
    end;

    internal procedure SetOnline()
    begin
        Online := true;
    end;

    internal procedure SetPosTransLine(var pPosTransLine: Record "LSC POS Trans. Line")
    begin
        POSTransLine.TransferFields(pPosTransLine, true);
    end;

    internal procedure SetColumnCaption(pColumnNo: Integer; var pCaption: Text[30])
    begin
        ColumnCaptionArray[pColumnNo] := pCaption;
    end;

    internal procedure SetJournalMode(pJournalMode: Boolean)
    begin
        JournalMode := pJournalMode and (RecRef.Number = Database::"LSC POS Trans. Line");

        if not JournalMode then
            exit;

        InitJournalMenuLines();
    end;

    local procedure InitJournalMenuLines()
    begin
        if JournalLineFonts.Keys.Count > 0 then
            exit;
        JournalLineFonts.Add("LSC POS Journal Mode"::" ", '');
        JournalLineFonts.Add("LSC POS Journal Mode"::NORMAL, '#SL_NORMAL');
        JournalLineFonts.Add("LSC POS Journal Mode"::VOIDED, '#SL_VOIDED');
        JournalLineFonts.Add("LSC POS Journal Mode"::MULTIBUY, '#SL_MULTIBUY');
        JournalLineFonts.Add("LSC POS Journal Mode"::MIXMATCH, '#SL_MIXMATCH');
        JournalLineFonts.Add("LSC POS Journal Mode"::TOTALDISC, '#SL_TOTALDISC');
        JournalLineFonts.Add("LSC POS Journal Mode"::INCEXP, '#SL_INCEXP');
        JournalLineFonts.Add("LSC POS Journal Mode"::COUPON, '#SL_COUPON');
        JournalLineFonts.Add("LSC POS Journal Mode"::NEGQTY, '#SL_NEGQTY');
        JournalLineFonts.Add("LSC POS Journal Mode"::MARKED, '#SL_MARKED');
        JournalLineFonts.Add("LSC POS Journal Mode"::FREETEXT, '#SL_FREETEXT');
        JournalLineFonts.Add("LSC POS Journal Mode"::GIFTREC, '#SL_GIFTREC');
        JournalLineFonts.Add("LSC POS Journal Mode"::DEALHEADER, '#SL_DEALHEADER');
        JournalLineFonts.Add("LSC POS Journal Mode"::DEALLINE, '#SL_DEALLINE');
        JournalLineFonts.Add("LSC POS Journal Mode"::MODIFIERPOS, '#SL_MODIFIERPOS');
        JournalLineFonts.Add("LSC POS Journal Mode"::MODIFIERNEG, '#SL_MODIFIERNEG');
        JournalLineFonts.Add("LSC POS Journal Mode"::MODIFIERTEXT, '#SL_MODIFIERTEXT');

        if JournalLineButtonSkins.Keys.Count > 0 then
            exit;
        JournalLineButtonSkins.Add("LSC POS Journal Mode"::" ", '');
        JournalLineButtonSkins.Add("LSC POS Journal Mode"::NORMAL, '#SL_NORMAL');
        JournalLineButtonSkins.Add("LSC POS Journal Mode"::VOIDED, '#SL_VOIDED');
        JournalLineButtonSkins.Add("LSC POS Journal Mode"::MULTIBUY, '#SL_MULTIBUY');
        JournalLineButtonSkins.Add("LSC POS Journal Mode"::MIXMATCH, '#SL_MIXMATCH');
        JournalLineButtonSkins.Add("LSC POS Journal Mode"::TOTALDISC, '#SL_TOTALDISC');
        JournalLineButtonSkins.Add("LSC POS Journal Mode"::INCEXP, '#SL_INCEXP');
        JournalLineButtonSkins.Add("LSC POS Journal Mode"::COUPON, '#SL_COUPON');
        JournalLineButtonSkins.Add("LSC POS Journal Mode"::NEGQTY, '#SL_NEGQTY');
        JournalLineButtonSkins.Add("LSC POS Journal Mode"::MARKED, '#SL_MARKED');
        JournalLineButtonSkins.Add("LSC POS Journal Mode"::FREETEXT, '#SL_FREETEXT');
        JournalLineButtonSkins.Add("LSC POS Journal Mode"::GIFTREC, '#SL_GIFTREC');
        JournalLineButtonSkins.Add("LSC POS Journal Mode"::DEALHEADER, '#SL_DEALHEADER');
        JournalLineButtonSkins.Add("LSC POS Journal Mode"::DEALLINE, '#SL_DEALLINE');
        JournalLineButtonSkins.Add("LSC POS Journal Mode"::MODIFIERPOS, '#SL_MODIFIERPOS');
        JournalLineButtonSkins.Add("LSC POS Journal Mode"::MODIFIERNEG, '#SL_MODIFIERNEG');
        JournalLineButtonSkins.Add("LSC POS Journal Mode"::MODIFIERTEXT, '#SL_MODIFIERTEXT');
    end;

    local procedure CreateJournalLinesCaption(var pRecRef: RecordRef; pFieldNo: Integer; pColumnNo: Integer; var pLSDataSet: Codeunit "LSC DataSet"): Boolean
    var
        PosTrPerDisc: Record "LSC POS Trans. Per. Disc. Type";
        Staff: Record "LSC Staff";
        ItemTranslate: Record "Item Translation";
        PosTransLine: Record "LSC POS Trans. Line";
        Item: Record Item;
        RecRef_l: RecordRef;
        RetailLocExt: Codeunit "LSC Retail Localization Ext.";
        PosPriceUtil: Codeunit "LSC POS Price Utility";
        ServiceLocator: Codeunit "LSC Service Locator";
        Txt: Text;
        UOMTxt: Text[20];
        PriceTxt: Text[20];
        NETTxt: Text[20];
        EventSaysExit: Boolean;
        Eol: Text[2];
    begin
        RecRef_l := pRecRef.Duplicate;
        RecRef_l.SetTable(PosTransLine);
        OnBeforeCreateJournalLinesCaption(pRecRef, pFieldNo, pColumnNo, Txt, EventSaysExit);
        if EventSaysExit then begin
            pLSDataSet.SetValue(pColumnNo, Txt);
            exit(true);
        end;
        case pFieldNo of
            //DESCRIPTION
            PosTransLine.FieldNo(Description):
                begin
                    Txt := PosTransLine.Description;
                    if PosTransLine."Weight manually Entered" then
                        Txt := 'MAN ' + Txt;

                    if PosTransLine."Entry Type" = PosTransLine."Entry Type"::Item then begin
                        if PosSession.GetLanguageCode() <> '' then
                            if PosSession.GetLanguageCode() <> 'ENU' then // DefaultLanguage
                                if ItemTranslate.Get(PosTransLine.Number, PosTransLine."Variant Code", PosSession.GetLanguageCode()) then
                                    if ItemTranslate.Description <> '' then
                                        Txt := ItemTranslate.Description;

                        if PosSession.InterfaceProfile."Qty and Price in Descr." then begin
                            if PosTransLine."Unit of Measure" = '' then begin
                                UOMTxt := PosFormatting.FormatQty(PosTransLine.Quantity);
                                PriceTxt := PosFormatting.FormatPriceWithCurrencySymbol(PosTransLine.Price);
                            end else begin
                                UOMTxt := PosFormatting.FormatWeight(PosTransLine.Quantity, PosTransLine."Unit of Measure");
                                PriceTxt := PosFormatting.FormatPricePrUnit(PosTransLine.Price, PosTransLine."Unit of Measure");
                            end;
                            if RetailLocExt.IsAULocalizationEnabled() and Item.Get(PosTransLine.Number) then
                                if (Item."LSC Tare Weight" > 0) and (Item."LSC Scale Item") then
                                    NETTxt := 'NET '
                                else
                                    NETTxt := '';

                            Eol[1] := 13;
                            Eol[2] := 10;
                            Txt := Txt + Eol + '(' + NETTxt + UOMTxt + PosSession.FunctionalityProfile.GetMultipleItemsSymbol() + PriceTxt + ')';
                        end;
                    end;
                    if (PosTransLine."Indent No." > 0) and (PosTransLine."Indent No." < 20) then
                        Txt := SetIndent(PosSession.InterfaceProfile."Indent Symbol", PosTransLine."Indent No.") + Txt;
                    pLSDataSet.SetValue(pColumnNo, Txt);
                    exit(true);
                end;

            //QTY
            PosTransLine.FieldNo(Quantity):
                begin
                    if PosTransLine."Unit of Measure" <> '' then begin
                        if PosTransLine."Scale Item" then
                            pLSDataSet.SetValue(pColumnNo, PosFormatting.FormatWeight(PosTransLine.Quantity, PosTransLine."Unit of Measure"))
                        else
                            pLSDataSet.SetValue(pColumnNo, PosFormatting.FormatQty(PosTransLine.Quantity) + ' ' + LowerCase(PosTransLine."Unit of Measure"))
                    end
                    else
                        if (PosTransLine."Entry Type" = PosTransLine."Entry Type"::Item) and PosTransLine."Show Unit on POS" then begin
                            Item.Get(PosTransLine.Number);
                            pLSDataSet.SetValue(pColumnNo, PosFormatting.FormatQty(PosTransLine.Quantity) + ' ' + LowerCase(Item."Sales Unit of Measure"));
                        end
                        else
                            pLSDataSet.SetValue(pColumnNo, PosFormatting.FormatQty(PosTransLine.Quantity));
                    exit(true);
                end;

            //PRICE
            PosTransLine.FieldNo(Price):
                begin
                    if PosTransLine."Deal Line" and not (PosTransLine."Entry Type" = PosTransLine."Entry Type"::FreeText) then
                        pLSDataSet.SetValue(pColumnNo, '')
                    else
                        if PosTransLine."Scale Item" or PosTransLine."Price in Barcode" then
                            pLSDataSet.SetValue(pColumnNo, PosFormatting.FormatPricePrUnit(PosTransLine.Price, PosTransLine."Unit of Measure"))
                        else
                            pLSDataSet.SetValue(pColumnNo, PosFormatting.FormatPriceWithCurrencySymbol(PosTransLine.Price));
                    exit(true);
                end;

            //Discount %
            PosTransLine.FieldNo("Discount %"):
                begin
                    pLSDataSet.SetValue(pColumnNo, ServiceLocator.POSFunctions.RoundAmount(PosTransLine."Discount %"));
                    exit(true);
                end;

            //Amount
            PosTransLine.FieldNo(Amount):
                begin
                    if PosTransLine."Deal Line" and not (PosTransLine."Entry Type" = PosTransLine."Entry Type"::FreeText) then
                        pLSDataSet.SetValue(pColumnNo, '')
                    else
                        if (PosTransLine."Entry Type" = PosTransLine."Entry Type"::Payment) and PosTransLine."Special Order Deposit Entry" then
                            pLSDataSet.SetValue(pColumnNo, PosFormatting.FormatAmount(-PosTransLine.Amount))
                        else
                            pLSDataSet.SetValue(pColumnNo, PosFormatting.FormatAmount(PosTransLine.Amount));
                    exit(true);
                end;

            //Promotion/PerDiscGroup
            PosTransLine.FieldNo("Promotion No."):
                begin
                    if PosTransLine."Deal Line" and not (PosTransLine."Entry Type" = PosTransLine."Entry Type"::FreeText) then
                        pLSDataSet.SetValue(pColumnNo, '')
                    else begin
                        PosPriceUtil.GetTransDisc(PosTransLine, false, PosTrPerDisc.DiscType::Total);
                        if (PosTransLine."Entry Type" = PosTransLine."Entry Type"::PerDiscount) then begin
                            pLSDataSet.SetValue(pColumnNo, PosTransLine.Number)
                        end
                        else begin
                            PosPriceUtil.GetPerDiscLine(PosTrPerDisc, PosTransLine);
                            pLSDataSet.SetValue(pColumnNo, PosTrPerDisc."Periodic Disc. Group")
                        end;
                        exit(true);
                    end;
                end;

            //Info
            -5:
                begin
                    if ServiceLocator.POSFunctions.PosTransInfoExists(PosTransLine."Receipt No.", PosTransLine."Line No.") then
                        pLSDataSet.SetValue(pColumnNo, 'i')
                    else
                        pLSDataSet.SetValue(pColumnNo, '');
                    exit(true);
                end;
        end;

        exit(false);
    end;

    local procedure GetJournalLineColor(var pRecRef: RecordRef): Enum "LSC POS Journal Mode"
    var
        Header: Record "LSC POS Transaction";
        PosTransLine: Record "LSC POS Trans. Line";
        RecRef_l: RecordRef;
    begin
        RecRef_l := pRecRef.Duplicate;
        RecRef_l.SetTable(PosTransLine);

        if PosTransLine."Entry Status" = PosTransLine."Entry Status"::Voided then
            exit("LSC POS Journal Mode"::VOIDED);

        if PosTransLine.Marked then
            exit("LSC POS Journal Mode"::MARKED);

        if not Header.Get(PosTransLine."Receipt No.") then
            exit("LSC POS Journal Mode"::NORMAL);

        if PosTransLine."Entry Type" = PosTransLine."Entry Type"::Item then
            if PosTransLine."Orig. from Infocode" <> '' then
                if PosTransLine."Line No." <> PosTransLine."Parent Line" then
                    exit("LSC POS Journal Mode"::MODIFIERPOS);

        if PosTransLine."Excluded Bom Item" then
            exit("LSC POS Journal Mode"::MODIFIERNEG);

        if PosTransLine."Entry Type" = PosTransLine."Entry Type"::Item then
            if (PosTransLine.Quantity < 0) xor (Header."Sale Is Return Sale") then
                exit("LSC POS Journal Mode"::NEGQTY);

        if PosTransLine."Entry Type" = PosTransLine."Entry Type"::IncomeExpense then
            exit("LSC POS Journal Mode"::INCEXP);

        if (PosTransLine."Entry Type" = PosTransLine."Entry Type"::Payment) and (PosTransLine."Coupon EAN Org." <> '') then
            exit("LSC POS Journal Mode"::COUPON);

        if PosTransLine."Text Type" = PosTransLine."Text Type"::"Deal Header" then
            exit("LSC POS Journal Mode"::DEALHEADER);

        if PosTransLine."Entry Type" = PosTransLine."Entry Type"::FreeText then begin
            if PosTransLine."Orig. from Infocode" <> '' then
                exit("LSC POS Journal Mode"::MODIFIERTEXT)
            else
                exit("LSC POS Journal Mode"::FREETEXT);
        end;

        if PosTransLine."Marked for Gift Receipt" then
            exit("LSC POS Journal Mode"::GIFTREC);

        if PosTransLine."Deal Line No." <> 0 then
            exit("LSC POS Journal Mode"::DEALLINE);

        if PosTransLine."Entry Type" = PosTransLine."Entry Type"::TotalDiscount then
            exit("LSC POS Journal Mode"::TOTALDISC);

        exit("LSC POS Journal Mode"::NORMAL);
    end;

    internal procedure FindEx(var pFldRef: FieldRef; FindText: Text[100]): Integer
    var
        CurrFilter: Text[100];
        AndText: Text[1];
        FilterPrefix: Text[2];
        NewCount: Integer;
        xIndex: Integer;
        MaxRecsBack: Integer;
        xSortAscending: Boolean;
        Text004: Label 'Input text to long, max length for this column is %1';
    begin
        if FindText = '' then
            exit(0);

        if Format(pFldRef.Type) in ['Text', 'Code'] then
            if pFldRef.Length < StrLen(FindText) then begin
                LastError := StrSubstNo(Text004, pFldRef.Length);
                exit(0);
            end;

        ResetMaxRecFilter();

        GetCurrentKeyIndex(xIndex, xSortAscending);
        CurrFilter := pFldRef.GetFilter;

        if CurrFilter <> '' then begin
            AndText := '&'
        end;

        if xSortAscending then
            FilterPrefix := '>='
        else
            FilterPrefix := '<=';

        if StrPos(FindText, '..') > 0 then
            pFldRef.SetFilter(FindText)
        else begin
            if SearchType = SearchType::Whole then begin
                pFldRef.SetFilter(CurrFilter + AndText + FindText);
                if RecRef.FindFirst then
                    pFldRef.SetFilter(CurrFilter + AndText + FilterPrefix + Format(pFldRef.Value));
            end
            else
                if SearchType = SearchType::"Any Part" then begin
                    pFldRef.SetFilter(CurrFilter + AndText + '''*' + FindText + '*''');
                    if RecRef.FindFirst then
                        pFldRef.SetFilter(CurrFilter + AndText + FilterPrefix + '''' + Format(pFldRef.Value) + '''');
                end
                else
                    pFldRef.SetFilter(CurrFilter + AndText + FilterPrefix + '''' + FindText + '''');
        end;

        if not RecRef.IsEmpty then
            NewCount := RecRef.Count;

        pFldRef.SetFilter(CurrFilter);

        maxRecsBack := Round(((VisibleTableRows * MaxPages) / 2), 1, '>');
        if RecRef.Next(-maxRecsBack) = -maxRecsBack then begin
            SetMaxRecFilter();
        end;

        exit(GetCount - NewCount + 1)
    end;

    internal procedure GetColumnFieldNo(pColumnNo: Integer): Integer
    begin
        exit(FieldNoArray[pColumnNo]);
    end;

    internal procedure GetKeyFieldType(): Text[30]
    begin
        exit(Format(KeyFieldRef.Type));
    end;

    internal procedure SetColumnPreferedWidth(pColumnNo: Integer; pWidth: Integer)
    begin
        ColumnPreferedWidthArray[pColumnNo] := pWidth;
    end;

    internal procedure VisibleRows(): Integer
    begin
        exit(VisibleTableRows);
    end;

    internal procedure VisibleColumns(): Integer
    begin
        exit(VisibleTableColumns);
    end;

    internal procedure SetVisibleColumns(pColumns: Integer)
    begin
        VisibleTableColumns := pColumns;
    end;

    internal procedure GetColumnCaption(pColumnNo: Integer): Text[30]
    begin
        if pColumnNo = 0 then
            pColumnNo := DefaultColumnNo;
        exit(ColumnCaptionArray[pColumnNo]);
    end;

    internal procedure ClearCount()
    begin
        Counted := 0;
    end;

    internal procedure SetActiveRecord(pRecordID: RecordID)
    var
        lRecRef: RecordRef;
        lFldRef: FieldRef;
    begin
        if JournalMode then begin
            if lRecRef.Get(pRecordID) then begin
                lFldRef := lRecRef.Field(1); //Entry Type
                JournalLineType := lFldRef.Value;
                lFldRef := lRecRef.Field(2); //Line No.
                JournalLineNo := lFldRef.Value;
            end;
        end;
    end;

    internal procedure SetJournalLineNoAndType(pLineNo: Integer; pLineType: Integer)
    begin
        JournalLineNo := pLineNo;
        JournalLineType := pLineType;
    end;

    internal procedure SetSearchType(pSearchType: Enum "LSC POS DataTable Search Type")
    begin
        SearchType := pSearchType;
    end;

    internal procedure CreateReturnKeyValue(var KeyVal: Code[60]; RecordIDText: Text)
    var
        RecID_l: RecordID;
        FldRef: FieldRef;
        BOUtils: Codeunit "LSC BO Utils";
        KeyText1: Text[30];
        KeyText2: Text[30];
        KeyText3: Text[30];
        KeyCount: Integer;
        CalcFlowFields: Boolean;
    begin
        Evaluate(RecID_l, RecordIDText);
        RecRef.Get(RecID_l);

        KeyCount := 0;

        if FlowFieldBufferActive then begin
            CalcFlowFields := false;
            FlowFieldBuffer.GetFlowFields(FlowFieldBuffer, RecRef);
        end else
            CalcFlowFields := true;

        if KeyValueFieldNo[1] <> 0 then begin
            FldRef := RecRef.Field(KeyValueFieldNo[1]);
            if (Format(FldRef.Class) = 'FlowField') and (CalcFlowFields) then
                FldRef.CalcField;
            KeyText1 := Format(FldRef.Value);
            KeyCount += 1;
        end;

        if KeyValueFieldNo[2] <> 0 then begin
            FldRef := RecRef.Field(KeyValueFieldNo[2]);
            if (Format(FldRef.Class) = 'FlowField') and (CalcFlowFields) then
                FldRef.CalcField;
            KeyText2 := Format(FldRef.Value);
            KeyCount += 1;
        end;

        if KeyValueFieldNo[3] <> 0 then begin
            FldRef := RecRef.Field(KeyValueFieldNo[3]);
            if (Format(FldRef.Class) = 'FlowField') and (CalcFlowFields) then
                FldRef.CalcField;
            KeyText3 := Format(FldRef.Value);
            KeyCount += 1;
        end;

        if KeyCount = 1 then
            KeyVal := KeyText1
        else
            if KeyCount = 2 then
                KeyVal := BOUtils.CombineActKey(2, KeyText1, KeyText2, '', '', '')
            else
                if KeyCount = 3 then
                    KeyVal := BOUtils.CombineActKey(3, KeyText1, KeyText2, KeyText3, '', '');
    end;

    internal procedure SetColumnSourceExpr(pColumnNo: Integer; pSourceExprID: Code[30])
    begin
        ColumnSourceExprIDArray[pColumnNo] := pSourceExprID;
    end;

    internal procedure SetColumnPosTag(pColumnNo: Integer; pTag: Text)
    begin
        ColumnPosTagArray[pColumnNo] := pTag;
    end;

    local procedure SetColumnIsImage(pColumnNo: Integer; pIsImage: Boolean)
    begin
        ColumnIsImageArray[pColumnNo] := pIsImage;
    end;

    internal procedure GetColumnDataType(ColumnNo: Integer): Integer
    begin
        exit(FieldTypeArray[ColumnNo]);
    end;

    internal procedure SetFlowFieldBuffer(var pFlowFieldBuffer: Record "LSC FlowField Buffer" temporary)
    begin
        FlowFieldBufferActive := true;

        pFlowFieldBuffer.Reset;
        if pFlowFieldBuffer.FindSet() then
            repeat
                FlowFieldBuffer.Init;
                FlowFieldBuffer := pFlowFieldBuffer;
                FlowFieldBuffer.Insert;
            until pFlowFieldBuffer.Next = 0;
    end;

    internal procedure SetMaxRecFilter()
    var
        KeyFieldRef_l: FieldRef;
        KRef: KeyRef;
        FilterPrefix: Text;
        i: Integer;
        lOldFilterGroup: Integer;
        xKeyIndex: Integer;
        xSortAscending: Boolean;
    begin
        GetCurrentKeyIndex(xKeyIndex, xSortAscending);
        KRef := RecRef.KeyIndex(xKeyIndex);

        if xSortAscending then
            FilterPrefix := '>='
        else
            FilterPrefix := '<=';

        lOldFilterGroup := RecRef.FilterGroup;
        RecRef.FilterGroup(3);
        for i := 1 to KRef.FieldCount do begin
            KeyFieldRef_l := KRef.FieldIndex(i);
            if Format(KeyFieldRef_l.Value) <> '' then
                KeyFieldRef_l.SetFilter(FilterPrefix + '''' + Format(KeyFieldRef_l.Value) + '''');
            MaxRecFilterField[i] := KeyFieldRef_l.Number;
        end;
        RecRef.FilterGroup(lOldFilterGroup);

        Counted := 0; //Reset Count
    end;

    internal procedure ResetMaxRecFilter()
    var
        lOldFilterGroup: Integer;
        TmpFieldRef: FieldRef;
        i: Integer;
    begin
        if MaxRecFilterField[1] = 0 then
            exit;

        if RecRef.Number = 0 then
            exit;

        lOldFilterGroup := RecRef.FilterGroup;
        RecRef.FilterGroup(3);
        for i := 1 to 6 do begin
            if MaxRecFilterField[i] > 0 then begin
                TmpFieldRef := RecRef.Field(MaxRecFilterField[i]);
                TmpFieldRef.SetFilter('');
                MaxRecFilterField[i] := 0;
            end;
        end;
        RecRef.FilterGroup(lOldFilterGroup);
    end;

    internal procedure GetDataTableID(): Code[20]
    begin
        exit(DataTableID);
    end;

    internal procedure GetTableNo(): Integer
    begin
        exit(CurrTableNo);
    end;

    local procedure GetTransNoFromReceipt(p_DatasetColumnFilter: Text): Text
    var
        Len: Integer;
        Int_l: Integer;
    begin
        Len := StrLen(p_DatasetColumnFilter);
        if (Len > 9) and (UpperCase(CopyStr(p_DatasetColumnFilter, 1, 1)) = 'T') then
            if Evaluate(Int_l, CopyStr(p_DatasetColumnFilter, Len - 8)) then //Return last 9 digits...
                exit(Format(Int_l));

        exit(p_DatasetColumnFilter);
    end;

    internal procedure SetMaxPages(newValue: Integer)
    begin
        MaxPages := newValue;
    end;

    local procedure SetJournalLineInfo(var pRecRef: RecordRef; var pDataSet: Codeunit "LSC DataSet")
    var
        Transline: Record "LSC POS Trans. Line";
        JournalFont, JournalSkin : Code[20];
    begin
        pRecRef.SetTable(TransLine);

        //Set static Font/colors for Negative Quantity, Info Text etc.
        JournalCurrColor := GetJournalLineColor(pRecRef);
        JournalFont := JournalLineFonts.Get(JournalCurrColor);
        JournalSkin := JournalLineButtonSkins.Get(JournalCurrColor);
        OnBeforeSetJournalLineColorV2(pRecRef, JournalFont, JournalSkin);

        pDataSet.SetValue(TableColumns + 1, JournalFont);
        pDataSet.SetValue(TableColumns + 2, JournalSkin);

        if transline."Entry Status" <> transline."Entry Status"::Voided then begin
            if (transline."Entry Type" = transline."Entry Type"::PerDiscount) or
              ((transline."Entry Type" = transline."Entry Type"::FreeText) and (transline."Text Type" = transline."Text Type"::"Deal Header")) then
                pDataSet.SetValue(TableColumns + 3, '-')
            else
                pDataSet.SetValue(TableColumns + 3, TransLine."Disc. Info Line No.");

            if TransLine."Entry Type" = TransLine."Entry Type"::TotalDiscount then
                pDataSet.SetValue(TableColumns + 4, '-')
            else
                pDataSet.SetValue(TableColumns + 4, TransLine."Tot. Disc Info Line No.");
        end;
    end;

    internal procedure SetIndent(IndentSymbol: Text; IndentNo: Integer): Text
    var
        IndentSymbol_l: Text;
        PadIndentSymbol_l: Text;
    begin
        if StrLen(IndentSymbol) = 0 then
            IndentSymbol := '> ';
        IndentSymbol_l := PadStr(PadIndentSymbol_l, IndentNo, CopyStr(IndentSymbol, 1, 1));
        if StrLen(IndentSymbol) > 1 then
            IndentSymbol_l := IndentSymbol_l + PadStr(PadIndentSymbol_l, IndentNo, CopyStr(IndentSymbol, 2, 1));
        IndentSymbol_l := IndentSymbol_l + CopyStr(IndentSymbol, 3, 1);
        exit(IndentSymbol_l);
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeCreateJournalLinesCaption(var pRecRef: RecordRef; var pFieldNo: Integer; var pColumnNo: Integer; var tmpText: Text; var EventSaysExit: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeSetJournalLineColorV2(var pRecRef: RecordRef; var JournalFont: Code[20]; var JournalSkin: Code[20])
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterCreateOnPurchOrderCaption(var PurchaseOrdered: Decimal; var InvLookupTable: Record "LSC Inventory Lookup Table"; TransServerActive: Boolean; Online: Boolean)
    begin
    end;
}

