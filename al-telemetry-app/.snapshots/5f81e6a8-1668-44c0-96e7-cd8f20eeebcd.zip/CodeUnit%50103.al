codeunit 50103 "AAA Suscriber"
{

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnBeforeRunCommand, '', false, false)]
    local procedure "LSC POS Transaction Events_OnBeforeRunCommand"(var POSTransaction: Record "LSC POS Transaction"; var POSTransLine: Record "LSC POS Trans. Line"; var CurrInput: Text; var POSMenuLine: Record "LSC POS Menu Line"; var isHandled: Boolean; TenderType: Record "LSC Tender Type"; var CusomterOrCardNo: Code[20])
    var
        POSTransCU: Codeunit "LSC POS Transaction";
        TransHeaderL: Record "LSC Transaction Header";
        BarcodesL: Record "LSC Barcodes";
        LastErrorText: Text;
        ItemRecL: Record Item;
        ScannedDatabar: Text;
        lMemberCardNo: Text;
        lCloseCommand: Text;
        gOldMemberCardNo: Text;
        StaffL: Record "LSC Staff";
        POSSessionL: Codeunit "LSC POS Session";
        GS1DatabarBarcodeMgmt: Codeunit "AAA GS1 Databar Barcode Mgmt.";
        lText0001: Label 'Barcode %1 is not Valid';
        IsNotOnFileErr: Label 'Item %1 is not on file!';
        Item: Record Item;
        OposUtil: Codeunit "LSC POS OPOS Utility";
    begin
        CurrInput := CurrInput;
        case POSMenuLine.Command of
            //Long Barcode Scan Issue fix
            'ITEMNO':
                begin
                    Clear(ScannedDatabar);
                    if GS1DatabarBarcodeMgmt.IsComplexBarcode(CurrInput) then begin
                        ScannedDatabar := CurrInput;
                        CurrInput := GS1DatabarBarcodeMgmt.GetGTINFromDatabar(ScannedDatabar);
                        if CurrInput = '' then
                            CurrInput := ScannedDatabar;
                    end else begin
                        //if not Item.Get(CurrInput) then begin
                        //    POSTransCU.PosMessage(StrSubstNo(lText0001, CurrInput));
                        //    OposUtil.Beeper;
                        //    OposUtil.Beeper;
                        //    POSTransCU.PosMessage(StrSubstNo(IsNotOnFileErr, CurrInput));
                        //    Clear(CurrInput);
                        //    Error('');
                        //    exit;
                        //end;
                    end;
                end;
            'VOID_TR':
                begin
                    TransHeaderL.Reset();
                    TransHeaderL.SetFilter("Member Card No.", '<>%1', '');
                    TransHeaderL.SetFilter("Member Card No.", '%1', '');
                    if TransHeaderL.FindSet() then
                        repeat
                            TransHeaderL."Member Card No." := TransHeaderL."Member Card No.";
                            TransHeaderL.Modify(false);
                        until TransHeaderL.Next() = 0;
                end;
            'TOTAL':
                begin
                    IF POSTransaction."Member Card No." = '' then begin
                        IF StaffL.Get(POSSessionL.StaffID()) then
                            If Not StaffL."AAA Allow Sale Without Member" then begin
                                POSTransCU.ErrorBeep('Please select a Member before proceeding to Tender.');
                                Error('');
                                exit;
                            end;
                    end;

                    //IF POSTransaction."Sale Is Return Sale" then begin
                    //    If not POSSessionL.MgrKey() then begin
                    //        POSTransCU.ErrorBeep('Refund settlement only allowed by Managers.');
                    //        Error('');
                    //        exit;
                    //    end;
                    //end;
                end;
            'TENDER_K':
                begin
                    //IF POSTransaction."Sale Is Return Sale" then begin
                    //    If not POSSessionL.MgrKey() then begin
                    //        POSTransCU.ErrorBeep('Refund settlement only allowed by Managers.');
                    //        Error('');
                    //        exit;
                    //    end;
                    //end;
                end;
        end;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnBeforeCheckMemberCard, '', false, false)]
    local procedure "LSC POS Transaction Events_OnBeforeCheckMemberCard"(var PosTransaction: Record "LSC POS Transaction"; var MemberAccountTemp: Record "LSC Member Account" temporary; var MemberContactTemp: Record "LSC Member Contact" temporary; var MembershipCardTemp: Record "LSC Membership Card" temporary; var Handled: Boolean)
    begin
        //PosTransaction."Customer No." := MemberAccountTemp."Linked To Customer No.";
        PosTransaction."Customer No." := '';
    end;

    [EventSubscriber(ObjectType::Table, Database::"LSC Member Account", 'OnAfterValidateEvent', 'Description', false, false)]
    local procedure UpdateMemberContactDescription(var Rec: Record "LSC Member Account")
    var
        MemContactL: Record "LSC Member Contact";
    begin
        MemContactL.Reset();
        MemContactL.SetRange("Account No.", Rec."No.");
        MemContactL.ModifyAll("Account Name AAA", Rec.Description);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", 'OnBeforeTotalExecuted', '', false, false)]
    local procedure CheckMemberCardTotalPressed(var POSTransaction: Record "LSC POS Transaction")
    var
        POSTransactionCU: Codeunit "LSC POS Transaction";
    begin
        if POSTransaction."Member Card No." = '' then
            POSTransactionCU.InputMemberCard('');
    end;

    var
        XPD: Dictionary of [Integer, Text];

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC XmlPort Mapping", 'OnAfterWriteToXml', '', false, false)]
    local procedure "LSC XmlPort Mapping_OnAfterWriteToXml"(var pXmlPortDictionary: Dictionary of [Integer, List of [Text]])
    begin
        WriteToXml();
        pXmlPortDictionary.Add(50200, XPD.Get(50200).Split('|'));
    end;


    local procedure WriteToXml()
    begin
        XPD.Add(50200, '0,,,Text,RootGetInventoryLookup,,|1,,OPT Inventory Lookup Table,Table,InventoryLookupTable,,|2,Item No.,OPT Inventory Lookup Table,Field,ItemNo,,|2,Variant Code,OPT Inventory Lookup Table,Field,VariantCode,,|2,Location,OPT Inventory Lookup Table,Field,Location,,|2,Store No.,OPT Inventory Lookup Table,Field,StoreNo,,|2,Phys. Inventory,OPT Inventory Lookup Table,Field,PhysInventory,,|2,Purchase Order,OPT Inventory Lookup Table,Field,PurchaseOrder,,|2,Total Sales,OPT Inventory Lookup Table,Field,TotalSales,,|2,Var. Phys. Inventory,OPT Inventory Lookup Table,Field,VarPhysInventory,,|2,Var. Purchase Order,OPT Inventory Lookup Table,Field,VarPurchaseOrder,,|2,Var. Total Sales,OPT Inventory Lookup Table,Field,VarTotalSales,,|2,Posted Sales,OPT Inventory Lookup Table,Field,PostedSales,,|2,Var. Posted Sales,OPT Inventory Lookup Table,Field,VarPostedSales,,|2,Serial No.,OPT Inventory Lookup Table,Field,SerialNo,,|2,Lot No.,OPT Inventory Lookup Table,Field,LotNo,,|2,Expiration Date,OPT Inventory Lookup Table,Field,ExpirationDate,,|2,Total Inv. Adjmt.,OPT Inventory Lookup Table,Field,TotalInvAdjmt,,|2,Var. Total Inv. Adjmt.,OPT Inventory Lookup Table,Field,VarTotalInvAdjmt,,|2,Posted Inv. Adjmt.,OPT Inventory Lookup Table,Field,PostedInvAdjmt,,|2,Var. Posted Inv. Adjmt.,OPT Inventory Lookup Table,Field,VarPostedInvAdjmt,,|2,Net Inventory,OPT Inventory Lookup Table,Field,NetInventory,,|2,Qty. Sold (POS),OPT Inventory Lookup Table,Field,QtySoldPOS,,');
    end;

    local procedure GetBin(LocationCode: Code[10]; BinCode: Code[20]; var Bin: Record Bin)
    begin
        if (Bin."Location Code" <> LocationCode) or
           (Bin.Code <> BinCode)
        then begin
            Bin.SetLoadFields(Code, "Location Code", "Zone Code", "Dedicated", "Bin Ranking", "Bin Type Code", "Empty", "Maximum Cubage", "Maximum Weight",
                              "Warehouse Class Code", "Block Movement", "Cross-Dock Bin", "Special Equipment Code");
            Bin.Get(LocationCode, BinCode);
        end;
    end;

    local procedure InsertWhseActivHeader(var PostedWhseRcptLine: Record "Posted Whse. Receipt Line"; var WhseActivHeader: Record "Warehouse Activity Header"; BreakbulkNo: Integer; BreakbulkFilter: Boolean)
    begin
        WhseActivHeader.LockTable();
        WhseActivHeader.Init();
        WhseActivHeader.Type := WhseActivHeader.Type::"Put-away";
        WhseActivHeader."Location Code" := PostedWhseRcptLine."Location Code";
        WhseActivHeader.Validate("Assigned User ID", UserId);
        //WhseActivHeader."Sorting Method" := WhseActivHeader."Sorting Method"::;
        WhseActivHeader."Breakbulk Filter" := BreakbulkFilter;
        WhseActivHeader.Insert(true);
        WhseActivHeader.LockTable();
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnBeforeInsertItemLine, '', false, false)]
    local procedure "LSC POS Transaction Events_OnBeforeInsertItemLine"(var POSTransaction: Record "LSC POS Transaction"; var POSTransLine: Record "LSC POS Trans. Line"; var CurrInput: Text; var CompressEntry: Boolean)
    begin
        CompressEntry := true;
        POSTransLine."Journal Compression" := POSTransLine."Journal Compression"::Allowed;
        POSTransLine."Orig. of a Linked Item List" := false;
    end;

    [EventSubscriber(ObjectType::Table, Database::"LSC POS Trans. Line", OnBeforeCompressLine, '', false, false)]
    local procedure "LSC POS Trans. Line_OnBeforeCompressLine"(var Rec: Record "LSC POS Trans. Line"; var IsHandled: Boolean)
    var
        AAAFunctions: Codeunit "AAA Functions";
        UnitofMeasure: Record "Unit of Measure";
        Item: Record Item;
    begin
        IsHandled := true;
        if Item.Get(Rec.Number) then begin
            if UnitofMeasure.Get(Item."Sales Unit of Measure") and not (UnitofMeasure."LSC Weight Unit Of Measure") then begin
                AAAFunctions.CompressLine(Rec);
            end;

            If Item."Sales Unit of Measure" = '' then
                AAAFunctions.CompressLine(Rec);
        end;
    end;


    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnAfterCheckMemberCardV2, '', false, false)]
    local procedure "LSC POS Transaction Events_OnAfterCheckMemberCardV2"(var PosTransaction: Record "LSC POS Transaction"; var MemberAccountTemp: Record "LSC Member Account" temporary; var MemberContactTemp: Record "LSC Member Contact" temporary; var MembershipCardTemp: Record "LSC Membership Card" temporary)
    begin
        PosTransaction."Member Card No. AAA" := PosTransaction."Member Card No.";
        PosTransaction."Account No. AAA" := MemberAccountTemp."No.";
        PosTransaction.Modify();
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnAfterProcessRefundSelection, '', false, false)]
    local procedure "LSC POS Transaction Events_OnAfterProcessRefundSelection"(var POSTransaction: Record "LSC POS Transaction"; var POSTransLine: Record "LSC POS Trans. Line"; var CurrInput: Text; Balance: Decimal; var IsHandled: Boolean)
    var
        PosFunctions: Codeunit "LSC POS Functions";
        AccountRec: Record "LSC Member Account" temporary;
    begin
        if PosFunctions.GetMemberAccountInfo(AccountRec) then begin
            PosTransaction."Account No. AAA" := AccountRec."No.";
            PosTransaction.Modify();
        end;
    end;


    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Infocode Utility", OnAfterTypeCreateDataEntry, '', false, false)]
    local procedure "LSC POS Infocode Utility_OnAfterTypeCreateDataEntry"(Input: Text; var NewInput: Text; MgrKeyActive: Boolean; Training: Boolean; RLineAmount: Decimal; NextCode: Code[20]; NumSer: Code[10]; var TSError: Boolean; var VoucherRemainingAmount: Decimal; var VoucherEntries: Record "LSC Voucher Entries"; var Line: Record "LSC POS Trans. Line"; var Trans: Record "LSC POS Transaction"; var BarcodeMasksRec: Record "LSC Barcode Mask"; var DataEntry: Record "LSC POS Data Entry"; var DataEntryType: Record "LSC POS Data Entry Type"; var InfoCodeRec: Record "LSC Infocode"; var ErrorTxt: Text)
    begin
        DataEntry."Member Card No. AAA" := Trans."Member Card No.";
        DataEntry."Account No. AAA" := Trans."Account No. AAA";
        DataEntry.Modify();

        VoucherEntries."Member Card No. AAA" := Trans."Member Card No.";
        VoucherEntries."Account No. AAA" := Trans."Account No. AAA";
        VoucherEntries.Modify();
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", 'OnAfterGetContext', '', false, false)]
    local procedure OnAfterGetContext(var POSTransaction: Record "LSC POS Transaction")
    var
        POSSESSION: Codeunit "LSC POS Session";
        AAACustomization: Codeunit "AAA - Customization";
    begin
        POSSESSION.SetValue('MemberVoucherBalance', AAACustomization.GetMemberVoucherBalance(POSTransaction));
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Post Utility", OnAfterInsertTransHeader, '', false, false)]
    local procedure "LSC POS Post Utility_OnAfterInsertTransHeader"(var Transaction: Record "LSC Transaction Header"; var POSTrans: Record "LSC POS Transaction")
    begin
        Transaction."Account No. AAA" := POSTrans."Account No. AAA";
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Document Attachment Mgmt", OnAfterGetRefTable, '', false, false)]
    local procedure "Document Attachment Mgmt_OnAfterGetRefTable"(var RecRef: RecordRef; DocumentAttachment: Record "Document Attachment")
    var
        MemberAccount: Record "LSC Member Account";
        MemberContact: Record "LSC Member Contact";
    begin
        case DocumentAttachment."Table ID" of
            Database::"LSC Member Account":
                begin
                    RecRef.Open(Database::"LSC Member Account");
                    if MemberAccount.Get(DocumentAttachment."No.") then
                        RecRef.GetTable(MemberAccount);
                end;
            Database::"LSC Member Contact":
                begin
                    RecRef.Open(Database::"LSC Member Contact");
                    if MemberContact.Get(DocumentAttachment."No.") then
                        RecRef.GetTable(MemberContact);
                end;
        end;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Document Attachment Mgmt", OnAfterTableHasNumberFieldPrimaryKey, '', false, false)]
    local procedure "Document Attachment Mgmt_OnAfterTableHasNumberFieldPrimaryKey"(TableNo: Integer; var Result: Boolean; var FieldNo: Integer)
    begin
        case TableNo of
            Database::"LSC Member Contact",
            Database::"LSC Member Account":
                begin
                    Result := true;
                    FieldNo := 1;
                end;
        end;
    end;

    [EventSubscriber(ObjectType::Table, Database::"Bank Account Ledger Entry", OnAfterCopyFromGenJnlLine, '', false, false)]
    local procedure "Bank Account Ledger Entry_OnAfterCopyFromGenJnlLine"(var BankAccountLedgerEntry: Record "Bank Account Ledger Entry"; GenJournalLine: Record "Gen. Journal Line")
    begin
        BankAccountLedgerEntry."Payment Method Code AAA" := GenJournalLine."Payment Method Code";
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC Actions Management", OnBeforeErrorOnReName, '', false, false)]
    local procedure "LSC Actions Management_OnBeforeErrorOnReName"(var IsHandled: Boolean)
    begin
        IsHandled := true;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Over-Receipt Mgt.", OnGetDefaultOverReceiptCode, '', false, false)]
    local procedure "Over-Receipt Mgt._OnGetDefaultOverReceiptCode"(PurchaseLine: Record "Purchase Line"; var DefaultOverReceipCode: Code[20]; var IsHandled: Boolean)
    var
        AAAFunctions: Codeunit "AAA Functions";
    begin
        if PurchaseLine.Type = PurchaseLine.Type::" " then begin
            IsHandled := true;
            DefaultOverReceipCode := AAAFunctions.GetDefaultOverReceiptCode(PurchaseLine);
        end;
    end;

    [EventSubscriber(ObjectType::Table, Database::"Over-Receipt Code", OnBeforeCheckMinMaxValue, '', false, false)]
    local procedure "Over-Receipt Code_OnBeforeCheckMinMaxValue"(var OverReceiptCode: Record "Over-Receipt Code"; var IsHandled: Boolean)
    begin
        IsHandled := true;
        if (OverReceiptCode."Over-Receipt Tolerance %" < 0) then
            OverReceiptCode.FieldError("Over-Receipt Tolerance %");
    end;


    [EventSubscriber(ObjectType::Table, Database::"LSC Picking / Receiving lines", 'OnAfterValidateEvent', 'Barcode', true, true)]
    local procedure "LSC Picking / Receiving lines_OnAfterValidateEvent_Barcode"
    (
        var Rec: Record "LSC Picking / Receiving lines";
        var xRec: Record "LSC Picking / Receiving lines";
        CurrFieldNo: Integer
    )
    begin
        if Rec."Variant Code" <> '' then begin
            Rec.Validate("Variant Code");
        end;
    end;

    [EventSubscriber(ObjectType::Table, Database::"Purchase Line", 'OnAfterValidateEvent', 'Variant Code', true, true)]
    local procedure "Purchase Line_OnAfterValidateEvent_Variant_Code"
    (
        var Rec: Record "Purchase Line";
        var xRec: Record "Purchase Line";
        CurrFieldNo: Integer
    )
    var
        "Pic/RecSetup": Record "LSC Inventory Management Setup";
        lVariant: Record "Item Variant";
    begin
        "Pic/RecSetup".Get;
        if "Pic/RecSetup"."P/R Line Description" > 1 then begin
            lVariant.SetLoadFields(Description, "Description 2");
            if lVariant.Get(Rec."No.", Rec."Variant Code") then begin
                if "Pic/RecSetup"."P/R Line Description" = "Pic/RecSetup"."P/R Line Description"::"Variant Desc.2" then
                    Rec.Description := lVariant."Description 2"
                else
                    Rec.Description := lVariant.Description;

                if "Pic/RecSetup"."P/R Line Description" = "Pic/RecSetup"."P/R Line Description"::"Variant Desc.1+2" then
                    Rec.Description += ' ' + lVariant."Description 2";
            end;
        end;
    end;


    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnAfterRunCommand, '', false, false)]
    local procedure "LSC POS Transaction Events_OnAfterRunCommand"(var POSTransaction: Record "LSC POS Transaction"; var POSTransLine: Record "LSC POS Trans. Line"; var CurrInput: Text; var Command: Code[20]; var POSMenuLine: Record "LSC POS Menu Line")
    var
        TransactionHeader: Record "LSC Transaction Header";
        TransLines: Record "LSC POS Trans. Line";
        LinkedItems: Record "LSC Linked Item";
        Item: Record Item;
        UnitofMeasure: Record "Unit of Measure";
        POSSession: Codeunit "LSC POS Session";
        POSView: Codeunit "LSC POS View";
        LASTRECEIPT: Code[20];
        FilterUOM: Text;
        TotalQtyL: Decimal;
        TotalNumberOfItems: Decimal;
    begin
        LASTRECEIPT := POSView.GetReceiptNo();

        TransLines.Reset();
        TransLines.SetCurrentKey("Receipt No.", "Entry Type", Number, "Variant Code", "Unit of Measure", "Entry Status");
        TransLines.SetRange("Receipt No.", LASTRECEIPT);
        TransLines.SetRange("Entry Status", TransLines."Entry Status"::" ");
        TransLines.SetRange("Entry Type", TransLines."Entry Type"::Item);
        if TransLines.FindSet() then
            if TransLines.FindSet() then
                repeat
                    LinkedItems.Reset;
                    LinkedItems.SetRange("Item No.", TransLines.Number);
                    LinkedItems.SetFilter("Unit of Measure", '%1|%2', '', TransLines."Unit of Measure");
                    LinkedItems.SetFilter("Sales Type", '%1|%2', '', TransactionHeader."Sales Type");
                    if LinkedItems.FindFirst then begin
                        TotalQtyL += LinkedItems."No. of Items" * Abs(TransLines.Quantity);
                    end else begin
                        if Item.Get(TransLines.Number) then begin
                            if UnitOfMeasure.Get(Item."Sales Unit of Measure") and (UnitOfMeasure."LSC Weight Unit Of Measure") then begin
                                TotalNumberOfItems := TotalNumberOfItems + Abs(1);
                            end else
                                TotalNumberOfItems := TotalNumberOfItems + Abs(TransLines."Quantity");
                        end;
                    end;
                until TransLines.next() = 0;

        POSSession.SetValue("LSC POS Tag"::"AAABasketSize", Format(Round(TotalNumberOfItems, 1, '>')));
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Post Utility", OnBeforeModifyCompressSalesTrans2POSTransLineTmp, '', false, false)]
    local procedure "LSC POS Post Utility_OnBeforeModifyCompressSalesTrans2POSTransLineTmp"(var POSTransLineTmp: Record "LSC POS Trans. Line" temporary; var POSSalesEntry: Record "LSC POS Trans. Line")
    begin
        POSTransLineTmp."Quantity Real AAA" += POSSalesEntry."Quantity Real AAA";
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Post Utility", OnAfterInsertTransaction, '', false, false)]
    local procedure "LSC POS Post Utility_OnAfterInsertTransaction"(var Sender: Codeunit "LSC POS Post Utility"; var POSTrans: Record "LSC POS Transaction"; var Transaction: Record "LSC Transaction Header")
    var
        POSSalesEntry: Record "LSC POS Trans. Line";
        Item: Record Item;
        UnitOfMeasure: Record "Unit of Measure";
    begin
        POSSalesEntry.Reset();
        POSSalesEntry.SetRange("Receipt No.", POSTrans."Receipt No.");
        POSSalesEntry.SetRange("Entry Type", POSSalesEntry."Entry Type"::Item);
        POSSalesEntry.SetRange("Entry Status", POSSalesEntry."Entry Status"::" ");
        if POSSalesEntry.FindSet() then
            repeat
                if Item.Get(POSSalesEntry.Number) then begin
                    if UnitOfMeasure.Get(Item."Sales Unit of Measure") and (UnitOfMeasure."LSC Weight Unit Of Measure") then begin
                        POSSalesEntry."Quantity Real AAA" += 1;
                    end else
                        POSSalesEntry."Quantity Real AAA" += POSSalesEntry.Quantity;
                end;
                POSSalesEntry.Modify();
            until POSSalesEntry.Next() = 0;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Post Utility", SalesEntryOnBeforeInsertV2, '', false, false)]
    local procedure "LSC POS Post Utility_SalesEntryOnBeforeInsertV2"(var pPOSTransLineTemp: Record "LSC POS Trans. Line" temporary; var pTransSalesEntry: Record "LSC Trans. Sales Entry"; var Transaction: Record "LSC Transaction Header"; Sign: Integer)
    begin
        pTransSalesEntry."Quantity Real AAA" := pPOSTransLineTemp."Quantity Real AAA";
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Functions", OnBeforeShouldAddItemOnEnter, '', false, false)]
    local procedure "LSC POS Functions_OnBeforeShouldAddItemOnEnter"(PosMenuLine: Record "LSC POS Menu Line"; LastItemNo: Code[20]; LineRec: Record "LSC POS Trans. Line"; var IsHandled: Boolean; var ReturnValue: Boolean)
    begin
        IsHandled := true;
        ReturnValue := false;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Whse.-Post Receipt", 'OnAfterPostedWhseRcptLineInsert', '', false, false)]
    local procedure "Whse.-Post Receipt_OnAfterPostedWhseRcptLineInsert"(WarehouseReceiptLine: Record "Warehouse Receipt Line")
    var
        AAAReceiptLPDetails: Record "AAA Receipt LP Details 1";
        IWXLPHeader: Record "IWX LP Header";
        IWXLPLine: Record "IWX LP Line";
        IWXLPLineUsage: Record "IWX LP Line Usage";
        LicensePlate: Code[20];
        NoLine: Integer;
        QtyperUnitofMeasure: Decimal;
        DescriptionLPLbl: Label '%1, %2';
        LicenseEmplyLbl: Label 'Warehouse Received %1, line %2: No License Plate specified. You must validate that all lines have a License Plate.';
    begin
        AAAReceiptLPDetails.Reset();
        AAAReceiptLPDetails.SetCurrentKey("Whse Document No.", "Whse Line No.", "Item No.");
        AAAReceiptLPDetails.SetRange("Whse Document No.", WarehouseReceiptLine."No.");
        AAAReceiptLPDetails.SetRange("Whse Line No.", WarehouseReceiptLine."Line No.");
        AAAReceiptLPDetails.SetRange("Item No.", WarehouseReceiptLine."Item No.");
        if AAAReceiptLPDetails.FindSet() then begin
            Clear(LicensePlate);
            repeat
                if AAAReceiptLPDetails."License Plate" <> '' then begin
                    if AAAReceiptLPDetails."License Plate" <> LicensePlate then begin
                        NoLine := 10000;
                        LicensePlate := AAAReceiptLPDetails."License Plate";
                    end else
                        NoLine += 10000;

                    IWXLPHeader.Reset();
                    IWXLPHeader.SetRange("No.", AAAReceiptLPDetails."License Plate");
                    IWXLPHeader.SetRange("Automatic Process AAA", true);
                    if IWXLPHeader.FindSet() then begin
                        IWXLPLine.Init();
                        IWXLPLine.Validate("License Plate No.", IWXLPHeader."No.");
                        IWXLPLine.Validate("Line No.", NoLine);
                        IWXLPLine.Validate(Type, IWXLPLine.Type::Item);
                        IWXLPLine.Validate("No.", AAAReceiptLPDetails."Item No.");
                        IWXLPLine.Validate("Variant Code", AAAReceiptLPDetails."Variant Code");
                        IWXLPLine.Validate(Quantity, AAAReceiptLPDetails.Quantity);
                        IWXLPLine.Validate("Unit of Measure Code", AAAReceiptLPDetails."Unit of Measure Code");
                        IWXLPLine.Validate("Quantity (Base)", AAAReceiptLPDetails.Quantity * AAAReceiptLPDetails."Qty. per Unit of Measure");
                        IWXLPLine.Validate("Lot No.", AAAReceiptLPDetails."Lot No.");
                        IWXLPLine.Validate("Expiration Date", AAAReceiptLPDetails."Expiration Date");
                        IWXLPLine.Insert();
                        IWXLPHeader.Description := StrSubstNo(DescriptionLPLbl, AAAReceiptLPDetails."Item No.", Format(AAAReceiptLPDetails.Quantity, 0, '<Precision,2:2><Standard Format,2>'));
                        IWXLPHeader."Bin Code" := AAAReceiptLPDetails."Bin Code";
                        IWXLPHeader."Created by PDA" := 'OPT';
                        IWXLPHeader.Modify();

                        if WarehouseReceiptLine."No." <> '' then begin
                            IWXLPLineUsage.Init();
                            IWXLPLineUsage."Entry No." := IWXLPLineUsage.GetLastEntry();
                            IWXLPLineUsage."License Plate No." := IWXLPHeader."No.";
                            IWXLPLineUsage."License Plate Line No." := NoLine;
                            IWXLPLineUsage."Source Line No." := NoLine;
                            IWXLPLineUsage.Quantity := AAAReceiptLPDetails.Quantity;
                            IWXLPLineUsage."Lot No." := AAAReceiptLPDetails."Lot No.";
                            IWXLPLineUsage."License Plate Line Quantity" := AAAReceiptLPDetails.Quantity;
                            IWXLPLineUsage."Source Document" := IWXLPLineUsage."Source Document"::Receipt;
                            IWXLPLineUsage."Source No." := WarehouseReceiptLine."No.";
                            IWXLPLineUsage."Posting Date" := Today;
                            IWXLPLineUsage."No." := AAAReceiptLPDetails."Item No.";
                            IWXLPLineUsage.Insert();
                        end;

                        if WarehouseReceiptLine."Source No." <> '' then begin
                            IWXLPLineUsage.Init();
                            IWXLPLineUsage."Entry No." := IWXLPLineUsage.GetLastEntry();
                            IWXLPLineUsage."License Plate No." := IWXLPHeader."No.";
                            IWXLPLineUsage."License Plate Line No." := NoLine;
                            IWXLPLineUsage."Source Line No." := NoLine;
                            IWXLPLineUsage.Quantity := AAAReceiptLPDetails.Quantity;
                            IWXLPLineUsage."Lot No." := AAAReceiptLPDetails."Lot No.";
                            IWXLPLineUsage."License Plate Line Quantity" := AAAReceiptLPDetails.Quantity;
                            IWXLPLineUsage."Source Document" := IWXLPLineUsage."Source Document"::"Purchase Order";
                            IWXLPLineUsage."Source No." := WarehouseReceiptLine."Source No.";
                            IWXLPLineUsage."Posting Date" := Today;
                            IWXLPLineUsage."No." := AAAReceiptLPDetails."Item No.";
                            IWXLPLineUsage.Insert();
                        end;
                    end;
                end;
            until AAAReceiptLPDetails.Next() = 0;
        end;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnAfterInsertItemLine, '', false, false)]
    local procedure "LSC POS Transaction Events_OnAfterInsertItemLine"(var POSTransaction: Record "LSC POS Transaction"; var POSTransLine: Record "LSC POS Trans. Line"; var CurrInput: Text)
    var
        TransactionHeader: Record "LSC Transaction Header";
        TransLines: Record "LSC POS Trans. Line";
        LinkedItems: Record "LSC Linked Item";
        Item: Record Item;
        UnitofMeasure: Record "Unit of Measure";
        POSSession: Codeunit "LSC POS Session";
        POSView: Codeunit "LSC POS View";
        LASTRECEIPT: Code[20];
        FilterUOM: Text;
        TotalQtyL: Decimal;
        TotalNumberOfItems: Decimal;
    begin
        LASTRECEIPT := POSView.GetReceiptNo();

        TransLines.Reset();
        TransLines.SetCurrentKey("Receipt No.", "Entry Type", Number, "Variant Code", "Unit of Measure", "Entry Status");
        TransLines.SetRange("Receipt No.", LASTRECEIPT);
        TransLines.SetRange("Entry Status", TransLines."Entry Status"::" ");
        TransLines.SetRange("Entry Type", TransLines."Entry Type"::Item);
        if TransLines.FindSet() then
            if TransLines.FindSet() then
                repeat
                    LinkedItems.Reset;
                    LinkedItems.SetRange("Item No.", TransLines.Number);
                    LinkedItems.SetFilter("Unit of Measure", '%1|%2', '', TransLines."Unit of Measure");
                    LinkedItems.SetFilter("Sales Type", '%1|%2', '', TransactionHeader."Sales Type");
                    if LinkedItems.FindFirst then begin
                        TotalQtyL += LinkedItems."No. of Items" * Abs(TransLines.Quantity);
                    end else begin
                        if Item.Get(TransLines.Number) then begin
                            if UnitOfMeasure.Get(Item."Sales Unit of Measure") and (UnitOfMeasure."LSC Weight Unit Of Measure") then begin
                                TotalNumberOfItems := TotalNumberOfItems + Abs(1);
                            end else
                                TotalNumberOfItems := TotalNumberOfItems + Abs(TransLines."Quantity");
                        end;
                    end;
                until TransLines.next() = 0;

        POSSession.SetValue("LSC POS Tag"::"AAABasketSize", Format(Round(TotalNumberOfItems, 1, '>')));
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnAfterChangeQty, '', false, false)]
    local procedure "LSC POS Transaction Events_OnAfterChangeQty"(var POSTransaction: Record "LSC POS Transaction"; var POSTransLine: Record "LSC POS Trans. Line"; var CurrInput: Text)
    var
        TransactionHeader: Record "LSC Transaction Header";
        TransLines: Record "LSC POS Trans. Line";
        LinkedItems: Record "LSC Linked Item";
        Item: Record Item;
        UnitofMeasure: Record "Unit of Measure";
        POSSession: Codeunit "LSC POS Session";
        POSView: Codeunit "LSC POS View";
        LASTRECEIPT: Code[20];
        FilterUOM: Text;
        TotalQtyL: Decimal;
        TotalNumberOfItems: Decimal;
    begin
        LASTRECEIPT := POSView.GetReceiptNo();

        TransLines.Reset();
        TransLines.SetCurrentKey("Receipt No.", "Entry Type", Number, "Variant Code", "Unit of Measure", "Entry Status");
        TransLines.SetRange("Receipt No.", LASTRECEIPT);
        TransLines.SetRange("Entry Status", TransLines."Entry Status"::" ");
        TransLines.SetRange("Entry Type", TransLines."Entry Type"::Item);
        if TransLines.FindSet() then
            if TransLines.FindSet() then
                repeat
                    LinkedItems.Reset;
                    LinkedItems.SetRange("Item No.", TransLines.Number);
                    LinkedItems.SetFilter("Unit of Measure", '%1|%2', '', TransLines."Unit of Measure");
                    LinkedItems.SetFilter("Sales Type", '%1|%2', '', TransactionHeader."Sales Type");
                    if LinkedItems.FindFirst then begin
                        TotalQtyL += LinkedItems."No. of Items" * Abs(TransLines.Quantity);
                    end else begin
                        if Item.Get(TransLines.Number) then begin
                            if UnitOfMeasure.Get(Item."Sales Unit of Measure") and (UnitOfMeasure."LSC Weight Unit Of Measure") then begin
                                TotalNumberOfItems := TotalNumberOfItems + Abs(1);
                            end else
                                TotalNumberOfItems := TotalNumberOfItems + Abs(TransLines."Quantity");
                        end;
                    end;
                until TransLines.next() = 0;

        POSSession.SetValue("LSC POS Tag"::"AAABasketSize", Format(Round(TotalNumberOfItems, 1, '>')));
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction Events", OnAfterGetRecord, '', false, false)]
    local procedure "LSC POS Transaction Events_OnAfterGetRecord"(var LSCPosTransaction: Record "LSC POS Transaction")
    var
        TransactionHeader: Record "LSC Transaction Header";
        TransLines: Record "LSC POS Trans. Line";
        LinkedItems: Record "LSC Linked Item";
        Item: Record Item;
        UnitofMeasure: Record "Unit of Measure";
        POSSession: Codeunit "LSC POS Session";
        POSView: Codeunit "LSC POS View";
        LASTRECEIPT: Code[20];
        FilterUOM: Text;
        TotalQtyL: Decimal;
        TotalNumberOfItems: Decimal;
    begin
        LASTRECEIPT := POSView.GetReceiptNo();

        TransLines.Reset();
        TransLines.SetCurrentKey("Receipt No.", "Entry Type", Number, "Variant Code", "Unit of Measure", "Entry Status");
        TransLines.SetRange("Receipt No.", LASTRECEIPT);
        TransLines.SetRange("Entry Status", TransLines."Entry Status"::" ");
        TransLines.SetRange("Entry Type", TransLines."Entry Type"::Item);
        if TransLines.FindSet() then
            if TransLines.FindSet() then
                repeat
                    LinkedItems.Reset;
                    LinkedItems.SetRange("Item No.", TransLines.Number);
                    LinkedItems.SetFilter("Unit of Measure", '%1|%2', '', TransLines."Unit of Measure");
                    LinkedItems.SetFilter("Sales Type", '%1|%2', '', TransactionHeader."Sales Type");
                    if LinkedItems.FindFirst then begin
                        TotalQtyL += LinkedItems."No. of Items" * Abs(TransLines.Quantity);
                    end else begin
                        if Item.Get(TransLines.Number) then begin
                            if UnitOfMeasure.Get(Item."Sales Unit of Measure") and (UnitOfMeasure."LSC Weight Unit Of Measure") then begin
                                TotalNumberOfItems := TotalNumberOfItems + Abs(1);
                            end else
                                TotalNumberOfItems := TotalNumberOfItems + Abs(TransLines."Quantity");
                        end;
                    end;
                until TransLines.next() = 0;

        POSSession.SetValue("LSC POS Tag"::"AAABasketSize", Format(Round(TotalNumberOfItems, 1, '>')));
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Create Put-away", 'OnBeforeCreateNewWhseActivity', '', false, false)]
    local procedure "Create Put-away_OnBeforeCreateNewWhseActivity"(PostedWhseRcptLine: Record "Posted Whse. Receipt Line"; var WhseActivLine: Record "Warehouse Activity Line"; var WhseActivHeader: Record "Warehouse Activity Header"; var Location: Record Location; InsertHeader: Boolean; Bin: Record Bin; ActionType: Option ,Take,Place; var LineNo: Integer; BreakbulkNo: Integer; BreakbulkFilter: Boolean; QtyToHandleBase: Decimal; BreakPackage: Boolean; var EmptyZoneBin: Boolean; Breakbulk: Boolean; CrossDockInfo: Option; PutAwayItemUOM: Record "Item Unit of Measure"; DoNotFillQtytoHandle: Boolean; var IsHandled: Boolean)
    var
        AAAReceiptLPDetails: Record "AAA Receipt LP Details 1";
        CreatePutaway: Codeunit "Create Put-away";
        NoLine: Integer;
    begin
        AAAReceiptLPDetails.Reset();
        AAAReceiptLPDetails.SetRange("Whse Document No.", PostedWhseRcptLine."Whse. Receipt No.");
        AAAReceiptLPDetails.SetRange("Whse Line No.", PostedWhseRcptLine."Whse Receipt Line No.");
        AAAReceiptLPDetails.SetRange("Source ID", PostedWhseRcptLine."Source No.");
        AAAReceiptLPDetails.SetRange("Source Ref. No.", PostedWhseRcptLine."Source Line No.");
        //Revisar
        AAAReceiptLPDetails.SetRange("Variant Code", PostedWhseRcptLine."Variant Code");
        AAAReceiptLPDetails.SetRange("Lot No.", PostedWhseRcptLine."Lot No.");
        if AAAReceiptLPDetails.FindSet() then begin
            IsHandled := true;
            if (WhseActivHeader."No." = '') and InsertHeader then
                InsertWhseActivHeader(PostedWhseRcptLine, WhseActivHeader, BreakbulkNo, BreakbulkFilter);
            NoLine := LineNo;
            repeat
                if (not AAAReceiptLPDetails."Put-Away Place") or (not AAAReceiptLPDetails."Put-Away Take") then begin
                    WhseActivLine.Init();
                    WhseActivLine."Activity Type" := WhseActivHeader.Type;
                    WhseActivLine."No." := WhseActivHeader."No.";
                    WhseActivLine."Line No." := WhseActivLine.GetLastLineNo(WhseActivHeader.Type, WhseActivHeader."No.", ActionType, NoLine);
                    case ActionType of
                        ActionType::Place:
                            begin
                                WhseActivLine."Action Type" := WhseActivLine."Action Type"::Place;
                                AAAReceiptLPDetails."Put-Away Place" := true;
                            end;
                        ActionType::Take:
                            begin
                                WhseActivLine."Action Type" := WhseActivLine."Action Type"::Take;
                                AAAReceiptLPDetails."Put-Away Take" := true;
                            end;
                    end;
                    WhseActivLine."Source Type" := PostedWhseRcptLine."Source Type";
                    WhseActivLine."Source Subtype" := PostedWhseRcptLine."Source Subtype";
                    WhseActivLine."Source No." := PostedWhseRcptLine."Source No.";
                    WhseActivLine."Source Line No." := PostedWhseRcptLine."Source Line No.";
                    WhseActivLine."Source Document" := PostedWhseRcptLine."Source Document";
                    if WhseActivLine."Source Type" = 0 then
                        WhseActivLine."Whse. Document Type" := WhseActivLine."Whse. Document Type"::"Internal Put-away"
                    else
                        WhseActivLine."Whse. Document Type" := WhseActivLine."Whse. Document Type"::Receipt;
                    WhseActivLine."Whse. Document No." := PostedWhseRcptLine."No.";
                    WhseActivLine."Whse. Document Line No." := PostedWhseRcptLine."Line No.";
                    WhseActivLine."Location Code" := Location.Code;
                    WhseActivLine."Shelf No." := PostedWhseRcptLine."Shelf No.";
                    WhseActivLine."Due Date" := PostedWhseRcptLine."Due Date";
                    WhseActivLine."Starting Date" := PostedWhseRcptLine."Starting Date";
                    WhseActivLine."Breakbulk No." := BreakbulkNo;
                    WhseActivLine."Original Breakbulk" := Breakbulk;
                    if BreakbulkFilter then
                        WhseActivLine.Breakbulk := Breakbulk;
                    case ActionType of
                        ActionType::Take:
                            begin
                                WhseActivLine."Bin Code" := PostedWhseRcptLine."Bin Code";
                                WhseActivLine."Zone Code" := PostedWhseRcptLine."Zone Code";
                            end;
                        ActionType::Place:
                            if not EmptyZoneBin then
                                CreatePutaway.AssignPlaceBinZone(WhseActivLine, PostedWhseRcptLine, Location, Bin)
                            else begin
                                WhseActivLine."Bin Code" := '';
                                WhseActivLine."Zone Code" := '';
                            end
                    end;
                    WhseActivLine."Item No." := PostedWhseRcptLine."Item No.";
                    WhseActivLine."Variant Code" := PostedWhseRcptLine."Variant Code";
                    WhseActivLine.Description := PostedWhseRcptLine.Description;
                    WhseActivLine."Description 2" := PostedWhseRcptLine."Description 2";
                    if WhseActivLine."Bin Code" <> '' then begin
                        GetBin(WhseActivLine."Location Code", WhseActivLine."Bin Code", Bin);
                        WhseActivLine.Dedicated := Bin.Dedicated;
                        WhseActivLine."Bin Ranking" := Bin."Bin Ranking";
                        WhseActivLine."Bin Type Code" := Bin."Bin Type Code";
                    end;
                    WhseActivLine."Cross-Dock Information" := CrossDockInfo;
                    if BreakPackage or (ActionType <> ActionType::Place) and (ActionType <> ActionType::Take) or
                       not Location."Directed Put-away and Pick"
                    then begin
                        WhseActivLine."Unit of Measure Code" := PostedWhseRcptLine."Unit of Measure Code";
                        WhseActivLine."Qty. per Unit of Measure" := PostedWhseRcptLine."Qty. per Unit of Measure";
                        WhseActivLine."Qty. Rounding Precision" := PostedWhseRcptLine."Qty. Rounding Precision";
                        WhseActivLine."Qty. Rounding Precision (Base)" := PostedWhseRcptLine."Qty. Rounding Precision (Base)";
                    end else begin
                        WhseActivLine."Unit of Measure Code" := PutAwayItemUOM.Code;
                        WhseActivLine."Qty. per Unit of Measure" := PutAwayItemUOM."Qty. per Unit of Measure";
                        WhseActivLine."Qty. Rounding Precision" := PutAwayItemUOM."Qty. Rounding Precision";
                        WhseActivLine."Qty. Rounding Precision (Base)" := PutAwayItemUOM."Qty. Rounding Precision";
                    end;
                    WhseActivLine.Validate(Quantity, AAAReceiptLPDetails.Quantity);
                    //if AAAReceiptLPDetails.Quantity <> 0 then begin
                    //    WhseActivLine."Qty. (Base)" := AAAReceiptLPDetails.Quantity * AAAReceiptLPDetails."Qty. per Unit of Measure";
                    //    WhseActivLine."Qty. to Handle (Base)" := AAAReceiptLPDetails.Quantity * AAAReceiptLPDetails."Qty. per Unit of Measure";
                    //    WhseActivLine."Qty. Outstanding (Base)" := AAAReceiptLPDetails.Quantity * AAAReceiptLPDetails."Qty. per Unit of Measure";
                    //end;
                    //if DoNotFillQtytoHandle then begin
                    //    WhseActivLine."Qty. to Handle" := 0;
                    //    WhseActivLine."Qty. to Handle (Base)" := 0;
                    //    WhseActivLine.Cubage := 0;
                    //    WhseActivLine.Weight := 0;
                    //end;
                    if AAAReceiptLPDetails.Quantity <> 0 then begin
                        WhseActivLine."Qty. (Base)" := AAAReceiptLPDetails.Quantity * PutAwayItemUOM."Qty. per Unit of Measure";
                        WhseActivLine."Qty. to Handle (Base)" := AAAReceiptLPDetails.Quantity * PutAwayItemUOM."Qty. per Unit of Measure";
                        WhseActivLine."Qty. Outstanding (Base)" := AAAReceiptLPDetails.Quantity * PutAwayItemUOM."Qty. per Unit of Measure";
                    end;

                    if PostedWhseRcptLine."Serial No." <> '' then
                        WhseActivLine.ValidateQtyWhenSNDefined();

                    WhseActivLine.CopyTrackingFromPostedWhseRcptLine(PostedWhseRcptLine);
                    WhseActivLine."Warranty Date" := PostedWhseRcptLine."Warranty Date";
                    WhseActivLine."Expiration Date" := PostedWhseRcptLine."Expiration Date";
                    WhseActivLine."License Plate Put-away AAA" := AAAReceiptLPDetails."License Plate";
                    WhseActivLine.Insert();
                    AAAReceiptLPDetails.Modify();
                end;
            until AAAReceiptLPDetails.Next() = 0;
        end;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::ICInboxOutboxMgt, OnCreateOutboxPurchDocTransOnAfterICOutBoxPurchLineInsert, '', true, true)]
    local procedure OnCreateOutboxPurchDocTransOnAfterICOutBoxPurchLineInsert(var ICOutboxPurchaseLine: Record "IC Outbox Purchase Line"; PurchaseLine: Record "Purchase Line")
    begin
        ICOutboxPurchaseLine."IC Partner Variant AAA" := PurchaseLine."Variant Code";
        ICOutboxPurchaseLine.Modify();
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::ICInboxOutboxMgt, OnCreateOutboxSalesDocTransOnAfterICOutBoxSalesLineInsert, '', false, false)]
    local procedure ICInboxOutboxMgt_OnCreateOutboxSalesDocTransOnAfterICOutBoxSalesLineInsert(var ICOutboxSalesLine: Record "IC Outbox Sales Line"; SalesLine: Record "Sales Line")
    begin
        ICOutboxSalesLine."IC Partner Variant AAA" := SalesLine."Variant Code";
        ICOutboxSalesLine.Modify();
    end;


    [EventSubscriber(ObjectType::Codeunit, Codeunit::ICInboxOutboxMgt, OnBeforeICInboxSalesLineInsert, '', true, true)]
    local procedure OnBeforeICInboxSalesLineInsert(var ICInboxSalesLine: Record "IC Inbox Sales Line"; ICOutboxPurchaseLine: Record "IC Outbox Purchase Line")
    begin
        ICInboxSalesLine."IC Partner Variant AAA" := ICOutboxPurchaseLine."IC Partner Variant AAA";
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::ICInboxOutboxMgt, OnBeforeICInboxPurchLineInsert, '', false, false)]
    local procedure ICInboxOutboxMgt_OnBeforeICInboxPurchLineInsert(var ICInboxPurchaseLine: Record "IC Inbox Purchase Line"; ICOutboxSalesLine: Record "IC Outbox Sales Line")
    begin
        ICInboxPurchaseLine."IC Partner Variant AAA" := ICOutboxSalesLine."IC Partner Variant AAA";
    end;


    [EventSubscriber(ObjectType::Codeunit, Codeunit::ICInboxOutboxMgt, OnCreateSalesLinesOnAfterValidateNo, '', true, true)]
    local procedure OnCreateSalesLinesOnAfterValidateNo(var SalesLine: Record "Sales Line"; SalesHeader: Record "Sales Header"; ICInboxSalesLine: Record "IC Inbox Sales Line")
    begin
        SalesLine."Variant Code" := ICInboxSalesLine."IC Partner Variant AAA";
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::ICInboxOutboxMgt, OnCreatePurchLinesOnAfterValidateNo, '', false, false)]
    local procedure ICInboxOutboxMgt_OnCreatePurchLinesOnAfterValidateNo(var PurchaseLine: Record "Purchase Line"; PurchaseHeader: Record "Purchase Header"; ICInboxPurchaseLine: Record "IC Inbox Purchase Line")
    begin
        PurchaseLine."Variant Code" := ICInboxPurchaseLine."IC Partner Variant AAA";
    end;


    [EventSubscriber(ObjectType::Codeunit, codeunit::"Whse.-Activity-Register", 'OnAfterFindWhseActivLine', '', true, true)]
    procedure OnAfterFindWhseActivLine(var WarehouseActivityLine: Record "Warehouse Activity Line")
    var
        iwxLPHeader: Record "IWX LP Header";
    begin
        if WarehouseActivityLine."Activity Type" = WarehouseActivityLine."Activity Type"::"Put-away" then begin
            if WarehouseActivityLine."Action Type" = WarehouseActivityLine."Action Type"::Place then
                if (WarehouseActivityLine."License Plate Put-away AAA" <> '')

                then begin
                    WarehouseActivityLine.TestField("Bin Code");
                    iwxLPHeader.Reset();
                    if iwxLPHeader.get(WarehouseActivityLine."License Plate Put-away AAA") then begin
                        iwxLPHeader."Bin Code" := WarehouseActivityLine."Bin Code";
                        iwxLPHeader.Modify()
                    end;


                end;
        end;
    end;

    //CAS-14422-J4L6--
    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC Picking/Receiving - Post", OnBeforeSetStatusPostMethod, '', false, false)]
    local procedure _OnBeforeSetStatusPostMethod(var SetStatusPostMethod: Integer)
    var
        Text011: Label 'Part. receipt';
        fakeint: Integer;

    begin
        fakeint := StrMenu(Text011, 1);
        if fakeint = 1 then
            SetStatusPostMethod := 1
        else
            Error('Process cancelled');

    end;
    //CAS-14422-J4L6++

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Transaction", OnAfterKeyboardTriggerToProcess, '', false, false)]
    local procedure "LSC POS Transaction_OnAfterKeyboardTriggerToProcess"(InputValue: Text; KeyboardTriggerToProcess: Integer; var Rec: Record "LSC POS Transaction"; var IsHandled: Boolean; ResultOk: Boolean)
    begin
        if KeyboardTriggerToProcess = 8899 then begin
            IsHandled := true;
        end;
    end;


}
