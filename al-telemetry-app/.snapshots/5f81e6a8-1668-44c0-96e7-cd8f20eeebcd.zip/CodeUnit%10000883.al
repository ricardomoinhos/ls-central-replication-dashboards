codeunit 10000883 "LSC License Manager Notificat." implements "LSC ILicenseManagerNotification", "LSC ILicenseManagerNotificationBuild"
{
    Access = Internal;

    #region interface LicenseManagerNotification
    internal procedure FireNoLicenseNotification(LicManNotifCheck: Interface "LSC ILicManNotifCheck"; LicManagerNotifBuild: Interface "LSC ILicenseManagerNotificationBuild")
    var
        LicManCheck: Codeunit "LSC License Manager Check";
        LicManagerStorageMgt: Codeunit "LSC Lic. Manager Storage Mgt.";
        LicenseManagerDemo: Codeunit "LSC License Manager Demo";
    begin
        if not LicManNotifCheck.NoLicenseNotif(LicManCheck, LicManagerStorageMgt, LicenseManagerDemo) then
            exit;

        LicManagerNotifBuild.FireNoLicenseNotificationBuild();
    end;

    internal procedure FireNoBaseUsersNotification(LicManagerNotifBuild: Interface "LSC ILicenseManagerNotificationBuild"; LicManUserCheck: Interface "LSC ILicManUserCheck")
    var
        LicManagerStorageMgt: Codeunit "LSC Lic. Manager Storage Mgt.";
        LicenseManagerUser: Codeunit "LSC License Manager User";
    begin
        if LicManUserCheck.CheckUserAssigned(LicManagerStorageMgt, LicenseManagerUser) then
            exit;

        LicManagerNotifBuild.FireBaseNotificationBuild();
    end;

    internal procedure FireUsersNotification(LicManNotifCheck: Interface "LSC ILicManNotifCheck")
    var
        UsersInPlansUtils: Codeunit "LSC UsersInPlans Utils";
    begin
        FireUsersNotification(LicManNotifCheck, UsersInPlansUtils, this);
    end;

    internal procedure FireUsersNotification(LicManNotifCheck: Interface "LSC ILicManNotifCheck"; UsersInPlans: Interface "LSC IUsersInPlansUtils"; LicManagerNotification: Interface "LSC ILicenseManagerNotification")
    var
        LicManCheck: Codeunit "LSC License Manager Check";
        LicManagerStorageMgt: Codeunit "LSC Lic. Manager Storage Mgt.";
        EnvironmentInformation: Codeunit "Environment Information";
        LicManUserCheck: Codeunit "LSC Lic. Man. User Check";
    begin
        if not LicManNotifCheck.UserNotif(EnvironmentInformation.IsOnPrem(), LicManCheck, LicManagerStorageMgt) then
            exit;

        if UsersInPlans.UserHasBaseUnitPlans() then
            LicManagerNotification.FireNoBaseUsersNotification(this, LicManUserCheck);
    end;

    internal procedure FireNoEcomNotification(var CustomerOrderHeader: Record "LSC Customer Order Header"; LicManNotifCheck: Interface "LSC ILicManNotifCheck"; LicManagerNotifBuild: Interface "LSC ILicenseManagerNotificationBuild")
    begin
        if not CheckRecord(CustomerOrderHeader) then
            exit;

        FireNoEcomNotification(LicManagerNotifBuild, LicManNotifCheck);
    end;
    #endregion interface LicenseManagerNotification

    internal procedure FireNoEcomNotification(LicManagerNotifBuild: Interface "LSC ILicenseManagerNotificationBuild"; LicManNotifCheck: Interface "LSC ILicManNotifCheck")
    var
        LicManCheck: Codeunit "LSC License Manager Check";
        LicManagerStorageMgt: Codeunit "LSC Lic. Manager Storage Mgt.";
    begin
        if not LicManNotifCheck.EcomNotif(LicManCheck, LicManagerStorageMgt) then
            exit;

        LicManagerNotifBuild.FireEcomNotificationBuild();
    end;

    #region interface LicenseManagerNotificationBuild
    internal procedure FireNoLicenseNotificationBuild()
    var
        LicenseManagerCheck: Codeunit "LSC License Manager Check";
        NotificationID: Label 'f92fec82-6e4e-4bd9-8ad4-e397caaad913', Locked = true;
    begin
        OpenLicenseManagerSetupNotificationBuild(NotificationID, LicenseManagerCheck.GetNoLicenseActiveMessage(false));
    end;

    internal procedure FireBaseNotificationBuild()
    var
        LicenseManagerUnitBase: Codeunit "LSC License Manager Unit Base";
        NotificationID: Label '58c05262-2ae5-4853-a88a-ba9413ca4503', Locked = true;
    begin
        OpenLicenseManagerSetupNotificationBuild(NotificationID, LicenseManagerUnitBase.GetNoBaseUsersMsg());
    end;

    internal procedure FireEcomNotificationBuild()
    var
        LicenseManagerUnitEcom: Codeunit "LSC License Manager Unit Ecom";
        NotificationID: Label 'f1a89457-1584-46d4-9b38-0df54cc83c08', Locked = true;
    begin
        OpenLicenseManagerSetupNotificationBuild(NotificationID, LicenseManagerUnitEcom.GetNoEcomUnitMsg());
    end;

    internal procedure OpenLicenseManagerSetupNotificationBuild(Guid: Text; Message: Text)
    var
        Notification: Notification;
        NotificationActionName: Label 'Open License Manager Setup';
    begin
        Notification.Id(Guid);
        if Notification.Recall() then;
        Notification.Message(Message);
        Notification.AddAction(NotificationActionName, Codeunit::"LSC License Manager Notificat.", 'OpenLicenseManagerSetupPage');
        Notification.Send();
    end;
    #endregion interface LicenseManagerNotificationBuild

    #region Check
    internal procedure CheckRecord(var CustomerOrderHeader: Record "LSC Customer Order Header"): Boolean
    begin
        if CustomerOrderHeader."Scan Pay Go" then
            exit(false);

        if CustomerOrderHeader."CO Source Type" <> CustomerOrderHeader."CO Source Type"::Web then
            exit(false);

        exit(true);
    end;
    #endregion Check

    #region "externals"
    internal procedure FireNotifications()
    begin
        FireNotifications(this);
    end;

    internal procedure FireNoEcomNotification()
    var
        LicManagerNotifCheck: Codeunit "LSC Lic. Man. Notif. Check";
    begin
        FireNoEcomNotification(this, LicManagerNotifCheck);
    end;
    #endregion "externals"

    #region "locals"
    internal procedure FireNotifications(LicManagerNotification: Interface "LSC ILicenseManagerNotification")
    var
        LicManNotifCheck: Codeunit "LSC Lic. Man. Notif. Check";
    begin
        LicManagerNotification.FireNoLicenseNotification(LicManNotifCheck, this);
        LicManagerNotification.FireUsersNotification(LicManNotifCheck);
    end;

    internal procedure FireNoEcomNotification_RetailSalesOrder(LicManagerNotification: Interface "LSC ILicenseManagerNotification"; var SalesHeader: Record "Sales Header"; var CustomerOrderHeader: Record "LSC Customer Order Header")
    var
        LicManNotifCheck: Codeunit "LSC Lic. Man. Notif. Check";
    begin
        if SalesHeader."LSC Customer Order ID" = '' then
            exit;

        if not CustomerOrderHeader.Get(SalesHeader."LSC Customer Order ID") then
            exit;

        LicManagerNotification.FireNoEcomNotification(CustomerOrderHeader, LicManNotifCheck, this);
    end;
    #endregion "locals"

    #region Nofitifcation Actions
    internal procedure OpenRetailSetupPage(var Notific: Notification)
    begin
        Page.Run(Page::"LSC Retail Setup");
    end;

    internal procedure OpenLicenseManagerSetupPage(var Notific: Notification)
    begin
        Page.Run(Page::"LSC License Manager Setup");
    end;

    internal procedure ActivateLicense(var Notific: Notification)
    var
        LicenseManagerSetup: Page "LSC License Manager Setup";
    begin
        LicenseManagerSetup.ActivateLicense();
    end;
    #endregion Nofitifcation Actions

    #region Subscribers
    [NonDebuggable]
    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Conf./Personalization Mgt.", OnRoleCenterOpen, '', false, false)]
    local procedure OnRoleCenterOpen()
    begin
        FireNotifications();
    end;
    #endregion
}