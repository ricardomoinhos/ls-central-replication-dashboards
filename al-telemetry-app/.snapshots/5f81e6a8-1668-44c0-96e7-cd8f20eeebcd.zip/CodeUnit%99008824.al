codeunit 99008824 "LSC Current Availab. Functions"
{

    var
        POSSession: Codeunit "LSC POS Session";
        EposControlInterface: Codeunit "LSC POS Control Interface";
        POSTransactionCu: Codeunit "LSC POS Transaction";
        ServiceLocator: Codeunit "LSC Service Locator";
        ItemStockOnHand: Label 'Enter Availability, -1 to remove limit %1';
        InvalidValueInAmount: Label 'Invalid value in amount';
        StockModeText: Label 'Cannot change Item Stock - %1 %2 - %3 %4 is making changes.';

    internal procedure DisplayCurrentAvailability(var Rec: Record "LSC Current Availability"; var xRec: Record "LSC Current Availability"; CurrFieldNo: Integer)
    var
        POSFormatting: Codeunit "LSC POS Formatting";
        TagPrefix: Text;
    begin
        if Rec.IsTemporary then
            exit;
        TagPrefix := GetItemTagPrefix();
        if Rec.Type = Rec.Type::Deal then
            TagPrefix := GetDealTagPrefix();
        if Rec."Available Qty." = -1 then
            POSSession.SetValue(TagPrefix + Rec."No.", '')
        else
            POSSession.SetValue(TagPrefix + Rec."No.", POSFormatting.FormatQty(Rec."Available Qty.") + ' ' + Rec."Unit of Measure");
    end;

    internal procedure CheckPOSTransLineQuantity(var Rec: Record "LSC POS Trans. Line"; var xRec: Record "LSC POS Trans. Line"; CurrFieldNo: Integer)
    begin
        if SkipCurrentAvailabilityCheck(Rec) then
            exit;
        ValidateCurrentAvailabilityPOS(Rec, Rec.Quantity - xRec.Quantity);
    end;

    internal procedure CheckPOSTransLineVoidline(var Rec: Record "LSC POS Trans. Line"; var xRec: Record "LSC POS Trans. Line"; CurrFieldNo: Integer)
    var
        KDSFunctions: Codeunit "LSC KDS Functions";
        QtyNotSent: Decimal;
    begin
        if Rec."Entry Status" <> Rec."Entry Status"::Voided then
            exit;
        if SkipCurrentAvailabilityCheck(Rec) then
            exit;
        if (not KDSFunctions.TransLineSentToKitchen2(Rec, QtyNotSent)) then
            ValidateCurrentAvailabilityPOS(Rec, -Rec.Quantity);
    end;

    internal procedure CheckPOSTransVoid(var POSTransaction: Record "LSC POS Transaction")
    var
        POSTransLine: Record "LSC POS Trans. Line";
        KDSFunctions: Codeunit "LSC KDS Functions";
        QtyNotSent: Decimal;
    begin
        if POSTransaction."Entry Status" <> POSTransaction."Entry Status"::Voided then
            exit;
        if StoreShowCurrentAvailability() = 0 then
            exit;

        POSTransLine.SetRange("Receipt No.", POSTransaction."Receipt No.");
        POSTransLine.SetRange("Entry Status", POSTransaction."Entry Status"::" ");
        POSTransLine.SetLoadFields("Entry Type", "Text Type", Quantity, "Kitchen Routing", "Promotion No.", Number, "Receipt No.", "Line No.", Description, "Unit of Measure");
        if POSTransLine.FindSet() then
            repeat
                if not SkipCurrentAvailabilityCheck(POSTransLine) then
                    if (not KDSFunctions.TransLineSentToKitchen2(POSTransLine, QtyNotSent)) then
                        ValidateCurrentAvailabilityPOS(POSTransLine, -POSTransLine.Quantity);
            until POSTransLine.Next() = 0;
    end;

    internal procedure CheckCurrentAvailability(CurrentAvailability: Record "LSC Current Availability"; DealItemNo: Code[20]; ItemStockType: enum "LSC Curr. Avail. Entry Type"; QtyChange: Decimal): Boolean
    begin
        if QtyChange = 0 then
            exit(true);
        if CurrentAvailability."Available Qty." <> -1 then
            if (QtyChange > CurrentAvailability."Available Qty.") then
                exit(false);
        exit(true);
    end;

    internal procedure CheckCurrentAvailabilityForItem(StoreNo: code[10]; ItemNo: Code[20]; UnitOfMeasure: Code[10]; QtyPerUOM: Decimal; QtyToCheck: Decimal): Boolean
    var
        CurrAvailQty: Decimal;
        AvailabilitySet: Boolean;
    begin
        if QtyToCheck = 0 then
            exit(true);

        CurrAvailQty := GetItemCurrentAvailabilityForUOM(StoreNo, ItemNo, UnitOfMeasure, AvailabilitySet);
        if not AvailabilitySet then
            exit(true);

        if QtyPerUOM = 0 then
            QtyPerUOM := 1;
        if (QtyToCheck * QtyPerUOM) > CurrAvailQty then
            exit(false);
        exit(true);
    end;

    internal procedure UpdateCurrentAvailability(var CurrentAvailability: Record "LSC Current Availability"; QtyChange: Decimal)
    begin
        if CurrentAvailability."Available Qty." = -1 then
            exit;

        CurrentAvailability."Available Qty." := CurrentAvailability."Available Qty." - QtyChange;
        CurrentAvailability.Modify(true);
        RefreshCurrentAvailabilityInStore();
        EnableDisableButtonsForLastMenuShown();
    end;

    internal procedure GetQtyChangeForUOM(POSTransLine: Record "LSC POS Trans. Line"; CurrentAvailability: Record "LSC Current Availability"; DealItemNo: Code[20]; ItemStockType: enum "LSC Curr. Avail. Entry Type"): Decimal
    var
        ItemUnitofMeasure: Record "Item Unit of Measure";
        QtyUnitMeasure: Decimal;
        QtyChange: Decimal;
        UnitofMeasure: Code[10];
    begin
        if ItemStockType = ItemStockType::Deal then
            exit(POSTransLine.Quantity);

        QtyChange := POSTransLine.Quantity;
        POSTransLine."Unit of Measure" := GetItemUnitOfMeasure(POSTransLine."Unit of Measure", DealItemNo);
        if POSTransLine."Unit of Measure" <> '' then
            if ItemUnitofMeasure.Get(DealItemNo, POSTransLine."Unit of Measure") then begin
                UnitofMeasure := GetUnitOfMeasure(CurrentAvailability, DealItemNo);
                QtyUnitMeasure := GetQtyPerUnitOfMeasure(ItemUnitofMeasure, POSTransLine, UnitofMeasure);
                QtyChange := Round(QtyChange * QtyUnitMeasure, 0.00001);
            end;
        exit(QtyChange);
    end;

    local procedure GetUnitOfMeasure(CurrentAvailability: Record "LSC Current Availability"; DealItemNo: Code[20]): Code[10]
    var
        Item: Record Item;
        UnitofMeasure: Code[10];
    begin
        UnitofMeasure := CurrentAvailability."Unit of Measure";
        if UnitofMeasure = '' then begin
            if Item.Get(DealItemNo) then begin
                UnitofMeasure := Item."Sales Unit of Measure";
                if UnitofMeasure = '' then
                    UnitofMeasure := Item."Base Unit of Measure";
            end;
        end;
        exit(UnitofMeasure);
    end;

    local procedure GetItemUnitOfMeasure(POSTransLineUOM: Code[10]; ItemNo: Code[20]): Code[10]
    var
        Item: Record Item;
        UnitofMeasure: Code[10];
    begin
        UnitofMeasure := POSTransLineUOM;
        if UnitofMeasure <> '' then
            exit(UnitofMeasure);
        if not Item.Get(ItemNo) then
            exit('');
        UnitofMeasure := Item."Sales Unit of Measure";
        if UnitofMeasure = '' then
            UnitofMeasure := Item."Base Unit of Measure";
        exit(UnitofMeasure);
    end;

    local procedure GetQtyPerUnitOfMeasure(var ItemUnitofMeasure: Record "Item Unit of Measure"; POSTransLine: Record "LSC POS Trans. Line"; UnitofMeasure: Code[10]): Decimal
    var
        QtyUnitMeasure: Decimal;
    begin
        QtyUnitMeasure := ItemUnitofMeasure."Qty. per Unit of Measure";
        if UnitofMeasure <> '' then
            if ItemUnitofMeasure.Get(POSTransLine.Number, UnitofMeasure) then
                QtyUnitMeasure := QtyUnitMeasure / ItemUnitofMeasure."Qty. per Unit of Measure";
        exit(QtyUnitMeasure);
    end;

    internal procedure GetAvailableQtyForUOM(UnitOfMeasureCode: Code[10]; CurrentAvailability: Record "LSC Current Availability"; ItemNo: Code[20]): Decimal
    var
        UnitOfMeasureMgt: Codeunit "Unit of Measure Management";
        Item: Record Item;
        AvailQty: Decimal;
        ItemUnitOfMeasureCode: Code[10];
        CurrAvailQtyPerUOM: Decimal;
        CurrAvailBaseQty: Decimal;
        IncomingQtyPerUOM: Decimal;
    begin
        AvailQty := CurrentAvailability."Available Qty.";

        If (UnitOfMeasureCode <> '') and (UnitOfMeasureCode = CurrentAvailability."Unit of Measure") then
            exit(AvailQty);

        if Item.Get(ItemNo) then;
        ItemUnitOfMeasureCode := Item."Sales Unit of Measure";
        if ItemUnitOfMeasureCode = '' then
            ItemUnitOfMeasureCode := Item."Base Unit of Measure";

        if CurrentAvailability."Unit of Measure" = '' then
            CurrentAvailability."Unit of Measure" := ItemUnitOfMeasureCode;
        if UnitOfMeasureCode = '' then
            UnitOfMeasureCode := ItemUnitofMeasureCode;

        If (UnitOfMeasureCode <> '') and (UnitOfMeasureCode = CurrentAvailability."Unit of Measure") then
            exit(AvailQty);

        CurrAvailQtyPerUOM := UnitOfMeasureMgt.GetQtyPerUnitOfMeasure(Item, CurrentAvailability."Unit of Measure");
        CurrAvailBaseQty := UnitOfMeasureMgt.CalcBaseQty(AvailQty, CurrAvailQtyPerUOM);

        IncomingQtyPerUOM := UnitOfMeasureMgt.GetQtyPerUnitOfMeasure(Item, UnitOfMeasureCode);
        AvailQty := UnitOfMeasureMgt.CalcQtyFromBase(CurrAvailBaseQty, IncomingQtyPerUOM);

        exit(AvailQty);
    end;

    internal procedure ValidateCurrentAvailabilityPOS(POSTransLine: Record "LSC POS Trans. Line"; QtyChange: Decimal)
    var
        POSMenuLine: Record "LSC POS Menu Line";
        ServiceLocator: Codeunit "LSC Service Locator";
        MessageReturn: Boolean;
        BlankText: Text;
        CurrentAvailabilityText: Label 'Not enough quantity for item: %1 %2';
        ErrorText: Text;
    begin
        if not ValidateCurrentAvailability(POSTransLine, POSSession.StoreNo(), QtyChange, ErrorText) then begin
            MessageReturn := EposControlInterface.PosMessage(StrSubstNo(CurrentAvailabilityText, POSMenuLine.Parameter, POSTransLine.Description));
            ServiceLocator.TransactionState().UnitOfMeasure_Clear();
            EPOSControlInterface.SetInputText(Format("LSC POS Input Control Id"::"#CURRINPUT"), BlankText);
            Error('');
        end;
    end;

    internal procedure ValidateCurrentAvailabilityWebPos(POSTransLine: Record "LSC POS Trans. Line"; Store: Record "LSC Store"; QtyChange: Decimal; var ErrorText: Text): Boolean
    begin
        if Store."Show Availab. on POS Button" = Store."Show Availab. on POS Button"::No then
            exit(true);
        exit(ValidateCurrentAvailability(POSTransLine, POSSession.StoreNo(), QtyChange, ErrorText));
    end;

    internal procedure ValidateCurrentAvailability(POSTransLine: Record "LSC POS Trans. Line"; StoreNo: Code[10]; QtyChange: Decimal; var ErrorText: text): Boolean
    var
        CurrentAvailability: Record "LSC Current Availability";
        DealItemNo: Code[20];
        ItemStockType: Enum "LSC Curr. Avail. Entry Type";
        CurrentAvailabilityDealText: Label 'Not enough quantity for deal: %1 %2';
        CurrentAvailabilityItemText: Label 'Not enough quantity for item: %1 %2';
    begin
        if QtyChange = 0 then
            exit(true);

        Errortext := '';
        GetTypeOfTransLineForCurrentAvailability(POSTransLine, DealItemNo, ItemStockType);
        if CurrentAvailability.Get(StoreNo, ItemStockType, DealItemNo) then begin
            if QtyChange < 0 then begin
                QtyChange := GetQtyChangeForUOM(POSTransLine, CurrentAvailability, DealItemNo, ItemStockType);
                QtyChange := QtyChange * -1;
            end else
                QtyChange := GetQtyChangeForUOM(POSTransLine, CurrentAvailability, DealItemNo, ItemStockType);

            if CheckCurrentAvailabilityOnValidate() then
                if CheckCurrentAvailability(CurrentAvailability, DealItemNo, ItemStockType, QtyChange) then begin
                    if UpdateCurrentAvailabilityOnValidate() then
                        UpdateCurrentAvailability(CurrentAvailability, QtyChange)
                end else begin
                    if ItemStockType = ItemStockType::Deal then
                        ErrorText := StrSubstNo(CurrentAvailabilityDealText, POSTransLine.Number, POSTransLine.Description)
                    else
                        ErrorText := StrSubstNo(CurrentAvailabilityItemText, POSTransLine.Number, POSTransLine.Description);
                    exit(false);
                end;
        end;
        exit(true);
    end;

    internal procedure GetTypeOfTransLineForCurrentAvailability(POSTransLine: Record "LSC POS Trans. Line"; var DealItemNo: Code[20]; var ItemStockType: Enum "LSC Curr. Avail. Entry Type")
    begin
        case POSTransLine."Entry Type" of
            POSTransLine."Entry Type"::FreeText:
                begin
                    DealItemNo := POSTransLine."Promotion No.";
                    ItemStockType := ItemStockType::Deal;
                end;
            POSTransLine."Entry Type"::Item:
                begin
                    DealItemNo := POSTransLine.Number;
                    ItemStockType := ItemStockType::Item;
                end;
        end;
    end;

    internal procedure CheckPOSMenuLine(var POSMenuLine: Record "LSC POS Menu Line"; ActionType: enum "LSC Curr. Avail. Action Type")
    var
        CurrentAvailability: Record "LSC Current Availability";
        ItemStockType: enum "LSC Curr. Avail. Entry Type";
        TagPrefix: Text;
    begin
        if StoreShowCurrentAvailability() = 0 then
            exit;
        case ActionType of
            ActionType::ResetAll:
                EnableDisableButtonsForLastMenuShown();
            ActionType::EnableAll:
                EnableAllButtonsForLastMenuShown();
            ActionType::SetPopUpInfo:
                begin
                    SetTagPrefixAndType(POSMenuLine, ItemStockType, TagPrefix);
                    if CurrentAvailability.Get(POSSession.StoreNo(), ItemStockType, POSMenuLine."Current-INPUT") then begin
                        if CurrentAvailability."Available Qty." <> -1 then begin
                            if (CurrentAvailability."Available Qty." = 0) then
                                POSMenuLine.Disabled := true;
                            if (CurrentAvailability."Available Qty." > 0) then
                                POSMenuLine.Disabled := false;
                            if (StrPos(POSMenuLine.Description, '<#' + TagPrefix + POSMenuLine."Current-INPUT" + '>') = 0) then
                                POSMenuLine.Description := POSMenuLine.Description + ' <#' + TagPrefix + POSMenuLine."Current-INPUT" + '>';
                        end;
                    end;
                end;
        end;
    end;

    internal procedure SetCurrentAvailabilityTag(var POSMenuLine: Record "LSC POS Menu Line"; AvailableQty: Decimal; ShowCurrentAvailability: Option No,Description,"Glyph 1","Glyph 2","Glyph 3","Glyph 4"): Boolean
    var
        CurrentAvailability: Record "LSC Current Availability";
        Item: Record Item;
        RecordsModified: Boolean;
        ItemStockType: Enum "LSC Curr. Avail. Entry Type";
        TagPrefix: Text;
    begin
        SetTagPrefixAndType(POSMenuLine, ItemStockType, TagPrefix);

        if not CurrentAvailability.Get(POSSession.StoreNo(), ItemStockType, POSMenuLine.Parameter) then begin
            if AvailableQty <> -1 then begin
                CurrentAvailability."Store No." := POSSession.StoreNo();
                CurrentAvailability.Type := ItemStockType;
                CurrentAvailability."No." := CopyStr(POSMenuLine.Parameter, 1, MaxStrLen(CurrentAvailability."No."));
                CurrentAvailability."Available Qty." := AvailableQty;
                if Item.Get(POSMenuLine.Parameter) then
                    if Item."Sales Unit of Measure" <> '' then
                        CurrentAvailability."Unit of Measure" := Item."Sales Unit of Measure"
                    else
                        CurrentAvailability."Unit of Measure" := Item."Base Unit of Measure";
                CurrentAvailability.Insert(true);
                RecordsModified := true;
            end;
        end else begin //if -1, availability is no longer set, set as -1 instead of deleting
            if CurrentAvailability."Available Qty." <> AvailableQty then begin
                CurrentAvailability."Available Qty." := AvailableQty;
                CurrentAvailability.Modify(true);
                RecordsModified := true;
            end;
        end;
        exit(RecordsModified);
    end;

    procedure UpdateTagOnButton(var POSMenuLine: Record "LSC POS Menu Line"; ShowCurrentAvailability: Option No,Description,"Glyph 1","Glyph 2","Glyph 3","Glyph 4"): Boolean
    var
        xPOSMenuLine: Record "LSC POS Menu Line";
        iPos: Integer;
        ButtonTag: text;
        RecordsModified: Boolean;
        ItemStockType: enum "LSC Curr. Avail. Entry Type";
        TagPrefix: Text;
    begin
        SetTagPrefixAndType(POSMenuLine, ItemStockType, TagPrefix);
        ButtonTag := '<#' + TagPrefix + POSMenuLine.Parameter + '>';
        iPos := StrPos(POSMenuLine.Description, ButtonTag);
        xPOSMenuLine.TransferFields(POSMenuLine);
        if iPos > 0 then
            POSMenuLine.Description := CopyStr(POSMenuLine.Description, 1, iPos - 2);
        if POSMenuLine."Glyph Text" = ButtonTag then begin
            POSMenuLine.Glyph := POSMenuLine.Glyph::None;
            POSMenuLine."Glyph Text" := '';
        end;
        if POSMenuLine."Glyph Text 2" = ButtonTag then begin
            POSMenuLine."Glyph 2" := POSMenuLine."Glyph 2"::None;
            POSMenuLine."Glyph Text 2" := '';
        end;
        if POSMenuLine."Glyph Text 3" = ButtonTag then begin
            POSMenuLine."Glyph 3" := POSMenuLine."Glyph 3"::None;
            POSMenuLine."Glyph Text 3" := '';
        end;
        if POSMenuLine."Glyph Text 4" = ButtonTag then begin
            POSMenuLine."Glyph 4" := POSMenuLine."Glyph 4"::None;
            POSMenuLine."Glyph Text 4" := '';
        end;

        case ShowCurrentAvailability of
            ShowCurrentAvailability::Description:
                begin
                    if (StrPos(POSMenuLine.Description, ButtonTag) = 0) then begin
                        POSMenuLine.Description := POSMenuLine.Description + ' ' + ButtonTag;
                    end;
                end;
            ShowCurrentAvailability::"Glyph 1":
                begin
                    POSMenuLine.Glyph := POSMenuLine.Glyph::Text;
                    POSMenuLine."Glyph Text" := ButtonTag;
                end;
            ShowCurrentAvailability::"Glyph 2":
                begin
                    POSMenuLine."Glyph 2" := POSMenuLine."Glyph 2"::Text;
                    POSMenuLine."Glyph Text 2" := ButtonTag;
                end;
            ShowCurrentAvailability::"Glyph 3":
                begin
                    POSMenuLine."Glyph 3" := POSMenuLine."Glyph 3"::Text;
                    POSMenuLine."Glyph Text 3" := ButtonTag;
                end;
            ShowCurrentAvailability::"Glyph 4":
                begin
                    POSMenuLine."Glyph 4" := POSMenuLine."Glyph 4"::Text;
                    POSMenuLine."Glyph Text 4" := ButtonTag;
                end;
        end;
        if (xPOSMenuLine.Description <> POSMenuLine.Description) or (xPOSMenuLine.Glyph <> POSMenuLine.Glyph) or
           (xPOSMenuLine."Glyph 2" <> POSMenuLine."Glyph 2") or (xPOSMenuLine."Glyph 3" <> POSMenuLine."Glyph 3") or
           (xPOSMenuLine."Glyph 4" <> POSMenuLine."Glyph 4") or (xPOSMenuLine."Glyph Text" <> POSMenuLine."Glyph Text") or
           (xPOSMenuLine."Glyph Text 2" <> POSMenuLine."Glyph Text 2") or (xPOSMenuLine."Glyph Text 3" <> POSMenuLine."Glyph Text 3") or
           (xPOSMenuLine."Glyph Text 4" <> POSMenuLine."Glyph Text 4")
        then begin
            if POSMenuLine.Modify(true) then;
            RecordsModified := true;
        end;

        exit(RecordsModified);
    end;

    internal procedure SetCurrentAvailability(var CurrentAvailabilityOn: Boolean)
    var
        CurrentAvailabilityLock: Record "LSC Current Availability Lock";
        POSTransaction: Codeunit "LSC POS Transaction";
        ErrorFlag: Boolean;
        UserText: Text;
        PressToQuitLbl: Label 'Press to Quit';
    begin
        POSTransaction.MessageBeep('');
        ErrorFlag := false;
        if CurrentAvailabilityOn then begin
            POSSession.SetValue("LSC POS Tag"::"AVAILABILITY_MODE", '');
            if SetCurrentAvailabilityLock(false) then
                CurrentAvailabilityOn := false
            else
                ErrorFlag := true
        end else begin
            POSSession.SetValue("LSC POS Tag"::"AVAILABILITY_MODE", PressToQuitLbl);
            if SetCurrentAvailabilityLock(true) then
                CurrentAvailabilityOn := true
            else
                ErrorFlag := true;
        end;
        if ErrorFlag then
            if CurrentAvailabilityLock.Get() then begin
                UserText := CopyStr(CurrentAvailabilityLock."User ID", StrPos(CurrentAvailabilityLock."User ID", '\') + 1);
                POSTransaction.ErrorBeep(
                  StrSubstNo(StockModeText, CurrentAvailabilityLock.FieldCaption("Staff ID"), CurrentAvailabilityLock."Staff ID",
                  CurrentAvailabilityLock.FieldCaption("User ID"), UserText));
            end;
    end;

    internal procedure SetCurrentAvailabilityLock(Lock: Boolean): Boolean
    var
        CurrentAvailabilityLock: Record "LSC Current Availability Lock";
        ReturnOk: Boolean;
    begin
        ReturnOk := true;
        if Lock then begin
            if not CurrentAvailabilityLock.Get() then begin
                CurrentAvailabilityLock.Init();
                CurrentAvailabilityLock.Insert(true);
            end;
            if CurrentAvailabilityLock."Date-Time Set" = 0DT then begin
                CurrentAvailabilityLock."In Use on POS Terminal" := POSSession.TerminalNo();
                CurrentAvailabilityLock."Staff ID" := POSSession.StaffID();
                CurrentAvailabilityLock."User ID" := UserId;
                CurrentAvailabilityLock."Date-Time Set" := CurrentDateTime;
                if not CurrentAvailabilityLock.Modify(true) then
                    ReturnOk := false;
            end else
                if (POSSession.StaffID() <> CurrentAvailabilityLock."Staff ID") or (UserId <> CurrentAvailabilityLock."User ID") then
                    ReturnOk := false;
        end else
            if CurrentAvailabilityLock.Get() then
                if (POSSession.StaffID() = CurrentAvailabilityLock."Staff ID") and (UserId = CurrentAvailabilityLock."User ID") then begin
                    CurrentAvailabilityLock."In Use on POS Terminal" := '';
                    CurrentAvailabilityLock."Date-Time Set" := 0DT;
                    if not CurrentAvailabilityLock.Modify(true) then
                        ReturnOk := false;
                end;
        exit(ReturnOk);
    end;

    internal procedure CurrentAvailabilityPressed(var POSMenuLine: Record "LSC POS Menu Line"; var CurrInput: Text)
    var
        CurrentAvailability: Record "LSC Current Availability";
        BOUtils: Codeunit "LSC BO Utils";
        POSTransaction: Codeunit "LSC POS Transaction";
        Item: Record Item;
        ItemSalesLimit: Decimal;
        UnitofMeasure: Code[10];
        ItemStockType: Enum "LSC Curr. Avail. Entry Type";
        TagPrefix: Text;
    begin
        if CurrInput = '' then begin
            SetTagPrefixAndType(POSMenuLine, ItemStockType, TagPrefix);
            UnitofMeasure := '';
            if CurrentAvailability.Get(POSSession.StoreNo(), ItemStockType, POSMenuLine.Parameter) then
                UnitofMeasure := CurrentAvailability."Unit of Measure"
            else
                if Item.Get(POSMenuLine.Parameter) then
                    if Item."Sales Unit of Measure" <> '' then
                        UnitofMeasure := Item."Sales Unit of Measure"
                    else
                        UnitofMeasure := Item."Base Unit of Measure";
            POSTransaction.OpenNumericKeyboard(StrSubstNo(ItemStockOnHand, BOUtils.GetCrLf() + POSMenuLine.Parameter + ' ' + POSMenuLine.Description + ' ' + UnitofMeasure), '', Enum::"LSC POS Trans. Numpad Trigger"::CurrentAvailability.AsInteger());
            exit;
        end;
        if not Evaluate(ItemSalesLimit, CurrInput) then begin
            POSTransaction.ErrorBeep(InvalidValueInAmount);
            CurrInput := '';
            exit;
        end;
        SetCurrentAvailabilityTag(POSMenuLine, ItemSalesLimit, StoreShowCurrentAvailability());
        RefreshCurrentAvailabilityInStore();
        CurrInput := '';
    end;

    local procedure SkipCurrentAvailabilityCheck(var POSTransLine: Record "LSC POS Trans. Line"): Boolean
    begin
        if POSTransLine.IsTemporary or (StoreShowCurrentAvailability() = 0) then
            exit(true);
        if LineIsItemOrDeal(POSTransLine) then
            exit(false);
        exit(true);
    end;

    local procedure LineIsItemOrDeal(var POSTransLine: Record "LSC POS Trans. Line"): Boolean
    begin
        if POSTransLine."Entry Type" = POSTransLine."Entry Type"::Item then
            exit(true);
        if POSTransLine."Entry Type" = POSTransLine."Entry Type"::FreeText then
            if POSTransLine."Text Type" = POSTransLine."Text Type"::"Deal Header" then
                exit(true);
        exit(false);
    end;

    internal procedure SetTagPrefixAndType(POSMenuLine: Record "LSC POS Menu Line"; var ItemStockType: enum "LSC Curr. Avail. Entry Type"; var TagPrefix: Text)
    begin
        ItemStockType := ItemStockType::Item;
        TagPrefix := GetItemTagPrefix();
        if POSMenuLine.Command = Format(Enum::"LSC POS Command"::DEAL) then begin
            ItemStockType := ItemStockType::Deal;
            TagPrefix := GetDealTagPrefix();
        end;
    end;

    local procedure GetItemTagPrefix(): Text
    var
        GetItemTagPrefixTxt: Label 'I-', Locked = true;
    begin
        exit(GetItemTagPrefixTxt);
    end;

    local procedure GetDealTagPrefix(): Text
    var
        GetDealTagPrefixTxt: Label 'D-', Locked = true;
    begin
        exit(GetDealTagPrefixTxt);
    end;

    internal procedure LoadCurrentAvailabilityTag(var POSMenuLine: Record "LSC POS Menu Line"; pProfileIDFilter: Text; pMenuIDFilter: Text)
    var
        CurrentAvailability: Record "LSC Current Availability";
        ItemStockType: enum "LSC Curr. Avail. Entry Type";
        TagPrefix: Text;
        RecordsModified: Boolean;
        CurrentAvailabilitySet: Boolean;
    begin
        POSMenuLine.SetFilter("Profile ID", pProfileIDFilter);
        POSMenuLine.SetFilter("Menu ID", pMenuIDFilter);
        POSMenuLine.SetFilter(Command, '%1|%2', Format(Enum::"LSC POS Command"::PLU_K), Format(Enum::"LSC POS Command"::DEAL));

        if POSMenuLine.IsEmpty() then begin
            POSMenuLine.Reset();
            exit;
        end;
        //if availability on, insert the tag into all Item/Deal buttons when the menu is shown - remove tag if not on
        POSMenuLine.LoadFields(Command, Parameter, Description, Glyph, "Glyph 2", "Glyph 3", "Glyph 4", "Glyph Text", "Glyph Text 2", "Glyph Text 3", "Glyph Text 4");

        if POSMenuLine.FindSet() then
            repeat
                CurrentAvailabilitySet := false;
                clear(CurrentAvailability);
                SetTagPrefixAndType(POSMenuLine, ItemStockType, TagPrefix);
                if StoreShowCurrentAvailability() <> 0 then begin
                    if CurrentAvailability.Get(POSSession.StoreNo(), ItemStockType, POSMenuLine.Parameter) then
                        CurrentAvailabilitySet := true;
                end;
                RecordsModified := UpdateTagOnButton(POSMenuLine, StoreShowCurrentAvailability()); //inserted or removed
                //update tag values
                if not CurrentAvailabilitySet then
                    POSSession.SetValue(TagPrefix + POSMenuLine.Parameter, ''); //clear out tag if no current availability
            until POSMenuLine.Next() = 0;

        if RecordsModified then
            Commit();
        POSMenuLine.Reset();
    end;

    procedure RefreshCurrentAvailabilityInStore()
    var
        CurrentAvailability: Record "LSC Current Availability";
    begin
        if StoreShowCurrentAvailability() = 0 then
            exit;
        CurrentAvailability.SetRange("Store No.", POSSession.StoreNo());
        if CurrentAvailability.FindSet() then
            repeat
                CurrentAvailability.Validate("Available Qty.", CurrentAvailability."Available Qty.");
            until CurrentAvailability.Next() = 0;
    end;

    procedure RefreshCurrentAvailabilityForMenu(MenuID: code[20])
    var
        CurrentAvailability: Record "LSC Current Availability";
        POSMenuLine: Record "LSC POS Menu Line";
        POSMenuHeader: Record "LSC POS Menu Header";
        ItemStockType: enum "LSC Curr. Avail. Entry Type";
        ButtonEnabled: Boolean;
    begin
        if StoreShowCurrentAvailability() = 0 then
            exit;

        POSMenuLine.SetRange("Menu ID", MenuID);
        POSMenuLine.SetFilter(Command, '%1|%2', Format(Enum::"LSC POS Command"::PLU_K), Format(Enum::"LSC POS Command"::DEAL));
        if POSMenuline.IsEmpty then
            exit;
        if not POSSession.GetPosMenuRec(MenuID, POSMenuHeader) then
            exit;

        POSSession.SetValue("LSC POS Tag"::"CA-LASTMENUSHOWN", POSMenuHeader."Menu ID");

        if POSTransactionCu.AvailabilityModeOn() then
            exit;
        POSMenuLine.SetRange("Profile ID", POSMenuHeader."Profile ID");

        POSMenuLine.LoadFields(Command, Parameter);

        if POSMenuLine.FindSet() then
            repeat
                if POSMenuLine.Command = Format(Enum::"LSC POS Command"::DEAL) then
                    ItemStockType := ItemStockType::Deal;
                ButtonEnabled := true;
                if CurrentAvailability.get(POSSession.StoreNo(), ItemStockType, POSMenuLine.Parameter) then
                    if CurrentAvailability."Available Qty." = 0 then
                        ButtonEnabled := false;
                EposControlInterface.SetButtonEnabled(MenuID, POSMenuLine."Key No.", ButtonEnabled);
            until POSMenuLine.Next() = 0;
    end;

    procedure EnableAllButtonsForLastMenuShown()
    var
        POSMenuLine: Record "LSC POS Menu Line";
        POSMenuHeader: Record "LSC POS Menu Header";
        LastMenuShown: code[20];
    begin
        LastMenuShown := POSSession.GetValue("LSC POS Tag"::"CA-LASTMENUSHOWN");

        if not POSSession.GetPosMenuRec(LastMenuShown, POSMenuHeader) then
            exit;
        POSMenuLine.SetRange("Profile ID", POSMenuHeader."Profile ID");
        POSMenuLine.SetRange("Menu ID", LastMenuShown);
        POSMenuLine.SetFilter(Command, '%1|%2', Format(Enum::"LSC POS Command"::PLU_K), Format(Enum::"LSC POS Command"::DEAL));
        POSMenuLine.LoadFields(Command);

        if POSMenuLine.FindSet() then
            repeat
                EposControlInterface.SetButtonEnabled(LastMenuShown, POSMenuLine."Key No.", true);
            until POSMenuLine.Next() = 0;
    end;

    procedure EnableDisableButtonsForLastMenuShown()
    var
        CurrentAvailability: Record "LSC Current Availability";
        POSMenuLine: Record "LSC POS Menu Line";
        POSMenuHeader: Record "LSC POS Menu Header";
        ItemStockType: Enum "LSC Curr. Avail. Entry Type";
        ButtonEnabled: Boolean;
        LastMenuShown: code[20];
    begin
        LastMenuShown := POSSession.GetValue("LSC POS Tag"::"CA-LASTMENUSHOWN");

        if not POSSession.GetPosMenuRec(LastMenuShown, POSMenuHeader) then
            exit;
        POSMenuLine.SetRange("Profile ID", POSMenuHeader."Profile ID");
        POSMenuLine.SetRange("Menu ID", LastMenuShown);
        POSMenuLine.SetFilter(Command, '%1|%2', Format(Enum::"LSC POS Command"::PLU_K), Format(Enum::"LSC POS Command"::DEAL));
        POSMenuLine.LoadFields(Command, Parameter);

        if POSMenuLine.FindSet() then
            repeat
                if POSMenuLine.Command = Format(Enum::"LSC POS Command"::DEAL) then
                    ItemStockType := ItemStockType::Deal;
                ButtonEnabled := true;
                if CurrentAvailability.get(POSSession.StoreNo(), ItemStockType, POSMenuLine.Parameter) then
                    if CurrentAvailability."Available Qty." = 0 then
                        ButtonEnabled := false;
                EposControlInterface.SetButtonEnabled(LastMenuShown, POSMenuLine."Key No.", ButtonEnabled);
            until POSMenuLine.Next() = 0;
    end;

    internal procedure GetCurrentAvailabilityForItemOrDealInStore(StoreNo: code[10]; ItemStockType: Enum "LSC Curr. Avail. Entry Type"; ItemOrDealNo: code[20]; var AvailabilitySet: Boolean; var AvailabilityUOM: Code[10]; var AvailabilityFactor: Decimal): Decimal
    var
        CurrentAvailability: Record "LSC Current Availability";
    begin
        CurrentAvailability.SetAutoCalcFields("Item Qty. per Unit of Measure");
        if CurrentAvailability.Get(StoreNo, ItemStockType, ItemOrDealNo) then begin
            if CurrentAvailability."Available Qty." >= 0 then begin
                AvailabilitySet := True;
                AvailabilityUOM := CurrentAvailability."Unit of Measure";
                AvailabilityFactor := CurrentAvailability."Item Qty. per Unit of Measure";
                exit(CurrentAvailability."Available Qty.");
            end;
            if CurrentAvailability."Available Qty." = -1 then begin
                AvailabilitySet := false;
                exit(0);
            end;
            if CurrentAvailability."Available Qty." = 0 then begin
                AvailabilitySet := true;
                AvailabilityUOM := CurrentAvailability."Unit of Measure";
                AvailabilityFactor := CurrentAvailability."Item Qty. per Unit of Measure";
                exit(0);
            end;
        end;
        AvailabilitySet := false;
        exit(0);
    end;

    internal procedure GetItemCurrentAvailabilityForUOM(StoreNo: code[10]; ItemNo: code[20]; UnitOfMeasure: Code[10]; var AvailabilitySet: Boolean): Decimal
    var
        CurrentAvailability: Record "LSC Current Availability";
        ItemStockType: Enum "LSC Curr. Avail. Entry Type";
    begin
        if CurrentAvailability.Get(StoreNo, ItemStockType::Item, ItemNo) then begin
            if CurrentAvailability."Available Qty." >= 0 then begin
                CurrentAvailability."Available Qty." := GetAvailableQtyForUOM(UnitOfMeasure, CurrentAvailability, ItemNo);
                AvailabilitySet := True;
                exit(CurrentAvailability."Available Qty.");
            end;
            if CurrentAvailability."Available Qty." = -1 then begin
                AvailabilitySet := false;
                exit(0);
            end;
            if CurrentAvailability."Available Qty." = 0 then begin
                AvailabilitySet := true;
                exit(0);
            end;
        end;
        AvailabilitySet := false;
        exit(0);
    end;

    internal procedure RefreshOnTimer(var POSTransaction: Record "LSC POS Transaction"; var POSTransLine: Record "LSC POS Trans. Line"; var CurrInput: Text)
    begin
        RefreshCurrentAvailabilityInStore();
        EnableDisableButtonsForLastMenuShown();
    end;

    internal procedure RefreshOnAfterShowMenu(var pMenuID: Code[20])
    begin
        RefreshCurrentAvailabilityInStore();
        RefreshCurrentAvailabilityForMenu(pMenuID);
    end;

    internal procedure UpdateCurrentAvailabilityOnValidate(): Boolean
    var
        POSSession: Codeunit "LSC POS Session";
        SkipUpdate: Text;
    begin
        SkipUpdate := POSSession.GetValue("LSC POS Tag"::"CURRAVAIL-SKIPUPDATE");
        SetSkipUpdateCurrentAvailabilityOnValidate(false);
        exit(SkipUpdate = '');
    end;

    internal procedure SetSkipUpdateCurrentAvailabilityOnValidate(SkipUpdate: Boolean)
    var
        POSSession: Codeunit "LSC POS Session";
    begin
        if SkipUpdate then
            POSSession.SetValue("LSC POS Tag"::"CURRAVAIL-SKIPUPDATE", '1')
        else
            POSSession.SetValue("LSC POS Tag"::"CURRAVAIL-SKIPUPDATE", '')
    end;

    internal procedure CheckCurrentAvailabilityOnValidate(): Boolean
    var
        POSSession: Codeunit "LSC POS Session";
        SkipCheck: Text;
    begin
        SkipCheck := POSSession.GetValue("LSC POS Tag"::"CURRAVAIL-SKIPCHECK");
        SetSkipCheckCurrentAvailabilityOnValidate(false);
        exit(skipCheck = '');
    end;

    internal procedure SetSkipCheckCurrentAvailabilityOnValidate(SkipUpdate: Boolean)
    var
        POSSession: Codeunit "LSC POS Session";
    begin
        if SkipUpdate then
            POSSession.SetValue("LSC POS Tag"::"CURRAVAIL-SKIPCHECK", '1')
        else
            POSSession.SetValue("LSC POS Tag"::"CURRAVAIL-SKIPCHECK", '')
    end;

    internal procedure StoreShowCurrentAvailability(): Integer
    begin
        exit(POSSession.Store()."Show Availab. on POS Button");
    end;


    internal procedure ValidateCurrAvailabilityPosition(Store: Record "LSC Store")
    var
        CurrentAvailability: Record "LSC Current Availability";
        POSObjectWhereUsedTmp: Record "LSC POS Object - Where Used" temporary;
        ObjectWhereUsedUtility: Codeunit "LSC Object-Where Used Utility";
        ShowAvailPOSButtonQst: Label 'All records in table %1 with store %2 will be deleted, do you want to continue?';
        UsePOSButtonGlyphQst: Label 'The %1 is already used, if you continue these values may be deleted when you start using Current Availability. Do you want to use this glyph?';
    begin
        if Store."Show Availab. on POS Button" = Store."Show Availab. on POS Button"::No then begin
            if Confirm(ShowAvailPOSButtonQst, true, CurrentAvailability.TableCaption, Store."No.") then begin
                CurrentAvailability.SetFilter("Store No.", Store."No.");
                CurrentAvailability.DeleteAll(true);
                exit;
            end;
            Error('');
        end;
        if not (Store."Show Availab. on POS Button" in [Store."Show Availab. on POS Button"::No, Store."Show Availab. on POS Button"::Description]) then begin
            ObjectWhereUsedUtility.POSGlyphWhereUsed(POSObjectWhereUsedTmp, Store);
            POSObjectWhereUsedTmp.Reset();
            if not POSObjectWhereUsedTmp.IsEmpty then begin
                if Confirm(UsePOSButtonGlyphQst, false, Store."Show Availab. on POS Button") then
                    exit;
                Error('');
            end;
        end;
    end;

    internal procedure UpdatePopupPOSMenuLineWithCurrAvailbilityInfoForItem(
        var POSMenuLine: Record "LSC POS Menu Line";
        ItemNo: Code[20];
        UnitOfMeasureCode: Code[10])
    var
        TagPrefix: Text;
        CurrAvailableQty: Decimal;
        AvailabilitySet: Boolean;
    begin
        TagPrefix := GetItemTagPrefix();
        CurrAvailableQty := GetItemCurrentAvailabilityForUOM(POSSession.StoreNo(), ItemNo, UnitOfMeasureCode, AvailabilitySet);
        if not AvailabilitySet then
            exit;

        POSMenuLine.Disabled := (CurrAvailableQty <= 0);

        AddTagToPopupMenuLine(POSMenuLine, POSSession.StoreNo(), TagPrefix);
    end;

    internal procedure AddTagToPopupMenuLine(var POSMenuLine: Record "LSC POS Menu Line"; StoreNo: Code[10]; TagPrefix: Text)
    var
        Store: Record "LSC Store";
        CurrAvailPOSTagTxt: Text;
        PreferredGlyphPos: Integer;
        GlyphPos: Integer;
    begin
        CurrAvailPOSTagTxt := '<#' + TagPrefix + POSMenuLine."Current-INPUT" + '>';
        Store.Get(StoreNo);
        PreferredGlyphPos := GetGlyphPOSAsNumber(Store);
        GlyphPos := PopupPanelFunctions().POSMenuLine_GetAvailableGlyph(POSMenuLine, PreferredGlyphPos);
        PopupPanelFunctions().POSMenuLine_AddTagTextToGlyph(POSMenuLine, CurrAvailPOSTagTxt, GlyphPos);
    end;

    local procedure GetGlyphPOSAsNumber(Store: Record "LSC Store"): Integer
    begin
        case Store."Show Availab. on POS Button" of
            Store."Show Availab. on POS Button"::"Glyph 1":
                exit(1);
            Store."Show Availab. on POS Button"::"Glyph 2":
                exit(2);
            Store."Show Availab. on POS Button"::"Glyph 3":
                exit(3);
            Store."Show Availab. on POS Button"::"Glyph 4":
                exit(4);
            else
                exit(0);
        end;
    end;

    local procedure PopupPanelFunctions(): Interface "LSC IPopupPanelFunctions"
    begin
        exit(ServiceLocator.PopupPanelFunctions());
    end;
}

