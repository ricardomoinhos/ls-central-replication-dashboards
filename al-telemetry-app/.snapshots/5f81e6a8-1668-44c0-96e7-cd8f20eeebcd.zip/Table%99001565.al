table 99001565 "LSC POS Data Table Columns"
{
    Caption = 'POS Data Table Columns';
    DrillDownPageID = "LSC POS Data Table Columns";
    LookupPageID = "LSC POS Data Table Columns";
    DataClassification = CustomerContent;

    fields
    {
        field(1; "Data Table ID"; Code[20])
        {
            Caption = 'Data Table ID';
            TableRelation = "LSC POS Data Table"."Data Table ID";
        }
        field(2; "Table No."; Integer)
        {
            Caption = 'Table No.';
        }
        field(3; "Column No."; Integer)
        {
            Caption = 'Column No.';
            NotBlank = true;
            ToolTip = 'Specifies the number of the Column in the grid. 1 being the first column (from left) and so on.';
            trigger OnValidate()
            var
                MaxNrOfLookupColsErr: Label 'Max number of Lookup Columns is %1';
                MaxColNo: Integer;
            begin
                MaxColNo := 32;
                if "Column No." > MaxColNo then
                    Error(StrSubstNo(MaxNrOfLookupColsErr, MaxColNo));
            end;
        }
        field(4; "Field No."; Integer)
        {
            Caption = 'Field No.';
            TableRelation = Field."No." WHERE(TableNo = FIELD("Table No."));
            ToolTip = 'Specifies the field number from the Table that should be associated with this column.';
            trigger OnValidate()
            begin
                CalcFields("Field Name");
            end;
        }
        field(5; "Key No."; Integer)
        {
            Caption = 'Key No.';
            ToolTip = 'Specifies a Key index number that associates that key with this column/field. If the value in this field is 0 then no key is associated with the column/field and the column will not be searchable, filterable or sortable. The same key can be associated with more than one column and in that case all columns that have the same key will be selected together and sorted by that single key.';
            trigger OnLookup()
            var
                boutil: Codeunit "LSC BO Utils";
                tmpInt: Integer;
            begin
                tmpInt := boutil.GetTableKeys("Table No.");
                if tmpInt > 0 then
                    "Key No." := tmpInt;
            end;
        }
        field(7; "Field Name"; Text[80])
        {
            CalcFormula = Lookup(Field."Field Caption" WHERE(TableNo = FIELD("Table No."), "No." = FIELD("Field No.")));
            Caption = 'Field Name';
            Editable = false;
            FieldClass = FlowField;
            ToolTip = 'Specifies the name of the field selected in the Field No. field.';
        }
        field(8; "Column Caption"; Text[50])
        {
            Caption = 'Column Caption';
            ToolTip = 'Specifies a special caption for the column. If this is not set, the field name will be used as caption.';
        }
        field(9; "Caption Alignment"; Option)
        {
            Caption = 'Caption Alignment';
            InitValue = Left;
            OptionCaption = 'Center,Left,Right';
            OptionMembers = Center,Left,Right;
            ToolTip = 'Specifies the alignment of text in this column, Center, Left or Right.';
        }
        field(10; Formatting; Option)
        {
            Caption = 'Formatting';
            OptionCaption = 'None,Amount,Price,Quantity,Standard';
            OptionMembers = "None",Amount,Price,Quantity,Standard;
            ToolTip = 'Specifies the formatting of text/values in this column. None: No Formatting (standard formatting). Amount: Same Amount formatting as the POS uses. Price: Same Price formatting as the POS uses. Quantity: Same Quantity formatting as the POS uses.';
        }
        field(11; "Fixed Filter"; Text[30])
        {
            Caption = 'Fixed Filter';
            ToolTip = 'Specifies the fixed filter. If this field contains a value, then that value is used to filter the field of the column. Any valid filter in can be used, such as 10..20 and so on. Additionally, on supports using built-in Tags (Context Name-Values) to filter the field. Supported built-in tags are: [STORE]: Use the current Store No. as a filter. [TERMINAL]: Use the current Terminal No. as a filter. [STAFF]: Use current Staff ID as a filter. [ITEM]: Use the Item No. of the active Journal Line as a filter. [VARIANT]: Use the Variant Code of the active Journal Line as a filter. [RECEIPTNO]: Use the current Receipt No. as a filter. [LINENO]: Use the Line No. of the active Journal Line as a filter. [TODAY]: Use the current Date (System TODAY variable) as a filter. It is also possible to use Dynamic Tags. This is done by adding a %= into the brackets, then a dynamic tag could be [%=MYTAG]. The system will then fetch the value for MYTAG from the POS Session (POSSESSION.GetValue). To set the value of the tag, a programmer can use the POSSESSION.SetValue function like this: POSSESSION.SetValue(''MYTAG'',123); Where POSSESSION is the "POS Session" single instance codeunit. The value 123 would then be used as the filter when data is requested.';
        }
        field(12; "Default Column"; Boolean)
        {
            Caption = 'Default Column';
            ToolTip = 'Specifies whether to make the column the default column and is therefore selected (and sorted by) when the POS Lookup form opens.';
            trigger OnValidate()
            var
                tmpRec: Record "LSC POS Data Table Columns";
                OnlyOneDefaultColAllowedErr: Label 'Only one %1 is allowed';
                DefaultColNeedsKeyErr: Label 'A %1 needs to have a %2 assigned to it';
            begin
                if not "Default Column" then
                    exit;

                tmpRec.SetRange(tmpRec."Data Table ID", "Data Table ID");
                tmpRec.SetRange(tmpRec."Table No.", "Table No.");
                tmpRec.SetRange("Default Column", true);
                if not tmpRec.IsEmpty() then
                    Error(OnlyOneDefaultColAllowedErr, Rec.FieldCaption("Default Column"));

                if "Key No." = 0 then
                    Error(DefaultColNeedsKeyErr, Rec.FieldCaption("Default Column"), Rec.FieldCaption("Key No."));
            end;
        }
        field(13; "Default Sort Order"; Option)
        {
            Caption = 'Default Sort Order';
            OptionCaption = 'Ascending,Descending';
            OptionMembers = "Ascending","Descending";
            ToolTip = 'Specifies the default sort order. It can be set to Ascending or Descending which will then be the starting sort order when the POS Lookup form opens.';
        }
        field(14; "Special Field Type"; Option)
        {
            Caption = 'Special Field Type';
            OptionCaption = ' ,Net Inventory,OnPurchaseOrder,FindByNumberField,FindByNameField,POS Info';
            OptionMembers = " ","Net Inventory",OnPurchaseOrder,FindByNumberField,FindByNameField,"POS Info";
            ToolTip = 'Specifies the field/column as a special type of field for LS Retail. NetInventory: This field type should only be used for the Inventory Lookup (INV_LU) to show the net inventory. OnPurchOrder: This field type should only be used for the Inventory Lookup (INV_LU) to show the quantity on purchase order. FindByNumberField: If the FINDNO pos command is used on a button in the POS Lookup then a column with this special field type will be selected and searched in. Note that using the FIND pos command will search in the selected column. FindByNameField: If the FINDNAME pos command is used on a button in the POS Lookup then a column with this special field type will be selected and searched in. Note that using the FIND pos command will search in the selected column.';
        }
        field(15; "Std. Formatting Text"; Text[100])
        {
            Caption = 'Std. Formatting Text';
        }
        field(16; "Preferred Width %"; Integer)
        {
            Caption = 'Preferred Width %';
            MaxValue = 100;
            MinValue = 0;
            Tooltip = 'Specifies the preferred width of the Data Grid column in percentage. Zero will auto-size the column (equal-remaining-width).';
        }
        field(17; "Sorting Fixed"; Boolean)
        {
            Caption = 'Sorting Fixed';
        }
        field(30; "Table Filter"; Code[20])
        {
            Caption = 'Table Filter';
            TableRelation = "LSC POS Data Table"."Data Table ID";
        }
        field(32; "Source Expr. ID"; Code[30])
        {
            Caption = 'Source Expr. ID';
            TableRelation = "LSC POS Tag".Tag WHERE(Type = CONST("Data Table Source Expression"));
        }
        field(40; Editable; Boolean)
        {
            Caption = 'Editable';
            Tooltip = 'Specifies if a Zoom Control Input representing the column should be editable or read-only.';
        }
        field(41; "Assist Lookup ID"; Code[20])
        {
            Caption = 'Assist Lookup ID';
            TableRelation = "LSC POS Lookup"."Lookup ID";
            ToolTip = 'Specifies if a Zoom Control Input representing the column should open a POS Lookup when on assist (e.g. when the keyboard icon is clicked).';
        }
        field(42; "Validate Input"; Boolean)
        {
            Caption = 'Validate Input';
            Tooltip = 'Specifies if a Zoom Control Input representing the column should be automatically validated once it loses focus. If true, an error will force the focus back to the input until it has a valid value. If false, the server must make sure valid values are placed in the target table.';
        }
        field(43; "Zoom Glyph Text"; Text[50])
        {
            Caption = 'Zoom Glyph Text';
        }
        field(50; "Filter Tags"; Code[10])
        {
            Caption = 'Filter Tags';
            ToolTip = 'Specifies the Filter Tags, like the letter P which indicates that the column (field) is part of the Primary Key. This will make the Insert action (NEW_GRID_REC and NEW_LOOKUP_REC) prompt the user for input into this field before attempting to insert the record.';
        }
        field(60; "POS Tag Link"; Text[30])
        {
            Caption = 'POS Tag Link';
            TableRelation = "LSC POS Tag";
            ValidateTableRelation = false;
            Tooltip = 'Specifies which POS Tag should be set with the value of the column when its row is selected.';
        }
        field(61; "Is Image"; Boolean)
        {
            Caption = 'Is Image';
            Tooltip = 'Specifies if the cells of the column should be displayed as Images rather than Text.';
        }
        field(70; "POS Command Code"; Code[20])
        {
            Caption = 'POS Command Code';
            TableRelation = "LSC POS Command"."Function Code";
            ToolTip = 'Specifies the code of a POS command that will be executed when the table column is pressed. The data grid line selected is the base for the execution of the POS command. If the data table is used as a journal, the data grid control must be marked with Notify Marked Count Changed. Adding a command to a column must be tested. Not all commands are suitable for this.';
            trigger OnValidate()
            var
                POSCommand: Record "LSC POS Command";
            begin
                if "POS Command Code" <> '' then begin
                    POSCommand.Get("POS Command Code");
                    "Parameter Type" := POSCommand."Parameter Type";
                end else begin
                    "Parameter Type" := "Parameter Type"::" ";
                    Parameter := '';
                end;

                UpdatePOSCommParameters(Rec, xRec."POS Command Code");
            end;
        }
        field(71; "Parameter Type"; Enum "LSC POS Command Parameter Type")
        {
            Caption = 'Parameter Type';
        }
        field(72; Parameter; Text[100])
        {
            Caption = 'Parameter';
            ToolTip = 'Specifies the parameter for the POS Command on the line.';
            trigger OnLookup()
            var
                POSCommand: Record "LSC POS Command";
                ProfileID: Code[10];
            begin
                Clear(Parameter);
                POSCommand.ParameterLookup(Parameter, "Parameter Type", ProfileID, "POS Command Code");
            end;

            trigger OnValidate()
            var
                POSCommand: Record "LSC POS Command";
            begin
                POSCommand.ValidateParameter(Parameter, "Parameter Type", "POS Command Code");
            end;
        }
    }

    keys
    {
        key(Key1; "Data Table ID", "Table No.", "Column No.")
        {
            Clustered = true;
        }
        key(Key2; "Data Table ID", "Table No.", "Field No.")
        {
        }
    }

    trigger OnInsert()
    var
        tmpRec: Record "LSC POS Data Table Columns";
    begin
        tmpRec.SetRange(tmpRec."Data Table ID", "Data Table ID");
        tmpRec.SetRange(tmpRec."Table No.", "Table No.");
        if tmpRec.Find('-') then
            repeat
                //if any column has width 
                //then set this to 10% so it will be shown
                if tmpRec."Preferred Width %" > 0 then begin
                    Rec."Preferred Width %" := 10;
                    exit;
                end;
            until tmpRec.Next = 0;
    end;

    trigger OnDelete()
    var
        POSDataTableColParameter: Record "LSC POS Data Table Col. Param";
        POSButtonTranslation: Record "LSC POS Button Translation";
    begin
        POSDataTableColParameter.SetRange("Data Table ID", "Data Table ID");
        POSDataTableColParameter.SetRange("Table No.", "Table No.");
        POSDataTableColParameter.SetRange("Column No.", "Column No.");
        if not POSDataTableColParameter.IsEmpty then
            POSDataTableColParameter.DeleteAll(true);

        POSButtonTranslation.SetRange("Profile ID", Internal_GetDataTableProfile());
        POSButtonTranslation.SetRange("Menu ID", "Data Table ID");
        POSButtonTranslation.SetRange("Button No.", "Column No.");
        if not POSButtonTranslation.IsEmpty then
            POSButtonTranslation.DeleteAll(true);
    end;

    internal procedure SwitchLines(pDirection: Option Up,Down; SelRec: Record "LSC POS Data Table Columns"): Boolean
    var
        POSDataTblCol: Record "LSC POS Data Table Columns";
        POSDataTblCol2: Record "LSC POS Data Table Columns";
        POSDataTblColTmp: Record "LSC POS Data Table Columns" temporary;
    begin
        POSDataTblColTmp.Reset;
        POSDataTblColTmp.DeleteAll;
        POSDataTblCol.SetRange("Data Table ID", SelRec."Data Table ID");
        POSDataTblCol.SetRange("Table No.", SelRec."Table No.");
        POSDataTblCol.SetRange("Column No.", SelRec."Column No.");

        if not POSDataTblCol.FindFirst then
            exit(false);
        POSDataTblCol2 := POSDataTblCol;
        POSDataTblCol2.SetRange("Data Table ID", SelRec."Data Table ID");
        POSDataTblCol2.SetRange("Table No.", SelRec."Table No.");
        case pDirection of
            pDirection::Up:
                if POSDataTblCol2.Next(-1) = 0 then
                    exit(false);
            pDirection::Down:
                if POSDataTblCol2.Next = 0 then
                    exit(false);
        end;

        POSDataTblColTmp := POSDataTblCol;
        POSDataTblCol.TransferFields(POSDataTblCol2, false);
        POSDataTblCol.Modify(true);
        POSDataTblCol2.TransferFields(POSDataTblColTmp, false);
        POSDataTblCol2.Modify(true);
        exit(true);
    end;

    procedure UpdatePOSCommParameters(POSDataTableColumn: Record "LSC POS Data Table Columns"; OldCommand: Code[20])
    var
        POSDataTableColParameter: Record "LSC POS Data Table Col. Param";
        POSParameterSetup: Record "LSC POS Parameter Setup";
        NewCommand: Code[20];
    begin
        NewCommand := POSDataTableColumn."POS Command Code";

        if OldCommand <> NewCommand then begin
            POSDataTableColParameter.SetRange("Data Table ID", POSDataTableColumn."Data Table ID");
            POSDataTableColParameter.SetRange("Table No.", POSDataTableColumn."Table No.");
            POSDataTableColParameter.SetRange("Column No.", POSDataTableColumn."Column No.");
            POSDataTableColParameter.SetRange("POS Command", OldCommand);
            POSDataTableColParameter.DeleteAll(true);
        end;

        POSParameterSetup.SetRange("Code Type", 0);
        POSParameterSetup.SetRange(Code, NewCommand);
        if POSParameterSetup.FindSet then
            repeat
                if not POSDataTableColParameter.Get(POSDataTableColumn."Data Table ID", POSDataTableColumn."Table No.", POSDataTableColumn."Column No.", NewCommand, POSParameterSetup."Parameter Code") then begin
                    POSDataTableColParameter.Init;
                    POSDataTableColParameter."Data Table ID" := POSDataTableColumn."Data Table ID";
                    POSDataTableColParameter."Table No." := POSDataTableColumn."Table No.";
                    POSDataTableColParameter."Column No." := POSDataTableColumn."Column No.";
                    POSDataTableColParameter."POS Command" := NewCommand;
                    POSDataTableColParameter."Parameter Code" := POSParameterSetup."Parameter Code";
                    POSDataTableColParameter."Parameter Value" := POSParameterSetup."Default Value";
                    POSDataTableColParameter.Insert(true);
                end;
            until POSParameterSetup.Next = 0;
        Commit;
    end;

    /// <summary> Profile ID used in POS Button Translations table to translate POS Data Table Columns (workaround) </summary>
    internal procedure Internal_GetDataTableProfile(): Code[20]
    begin
        exit('#DATATABLE');
    end;
}

