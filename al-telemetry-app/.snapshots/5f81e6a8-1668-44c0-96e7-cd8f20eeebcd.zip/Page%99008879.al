page 99008879 "LSC POS Main JS"
{
    ApplicationArea = All;
    Extensible = true;
    Caption = '';
    Editable = false;
    PageType = CardPart;
    ShowFilter = false;
    SourceTable = Company;
    SourceTableTemporary = true;
    UsageCategory = Tasks;
    layout
    {
        area(content)
        {
            usercontrol(control; "LSC_POS")
            {
                trigger AddInReady(j: JsonObject)
                begin
                    _C.Handle(_C.AddInReady(j, Rec), CurrPage.control);
                end;

                trigger POSEvent(j: JsonObject)
                begin
                    _C.Handle(_C.POSEvent(j), CurrPage.control);
                end;
            }
        }
    }

    trigger OnClosePage()
    begin
        _C.OnClosePage();
    end;

    trigger OnInit()
    begin
        _C.OnInit();
    end;

    trigger OnQueryClosePage(CloseAction: Action): Boolean
    begin
        if _C.ClosePos(true) then begin
            CurrPage.Close();
            exit(true);
        end;
        exit(false);
    end;

    var
        _C: Codeunit "LSC POS Addin Wrapper";
}