codeunit 10000784 "LSC POS Image Utils"
{
    Access = Internal;
    Permissions = tabledata "Tenant Media" = rmid;

    internal procedure GetImg(recID: RecordId; var ControlLib: Codeunit "LSC POS Control Library") imgCode: Code[20]
    begin
        // Get from SQL for each line (potentially slow, to bump up speed, load all SQL recs to control lib. as temp entity collection - or Dictionary of [Text: Key, Text: ImgID])
        imgCode := GetImgCode(recID);
        GetImg(imgCode, ControlLib);
    end;

    internal procedure GetImg(imgCode: Code[20]; var ControlLib: Codeunit "LSC POS Control Library")
    var
        PendingImages, imgObj : JsonObject;
    begin
        if imgCode = '' then
            exit;
        PendingImages := ControlLib.GetPendingImages();
        if PendingImages.Contains(imgCode) then
            exit; // perf. optimization (could also "force" it to load the image again (comparing oldImgObj.u with newImgObj.u))
        imgObj := GetImgObj(imgCode);
        ControlLib.AddPendingImage(imgCode, imgObj);
    end;

    internal procedure GetImgObj(imgCode: Code[20]) imgObj: JsonObject
    var
        RetailImage: Record "LSC Retail Image";
    begin
        if true in [
            imgCode = '',
            not RetailImage.Get(imgCode)
        ] then
            exit;
        imgObj := GetImgObj(RetailImage);
    end;

    internal procedure GetImgObj(RetailImage: Record "LSC Retail Image") imgObj: JsonObject
    var
        RetailImageUtils: Codeunit "LSC Retail Image Utils";
        TenantMedia: Record "Tenant Media";
        TenantMediaMimeType, Url : Text;
    begin
        if RetailImage."Code" = '' then
            exit;
        Url := RetailImage."Image Location";
        RetailImageUtils.OnGetPosImageUrl(RetailImage."Code", Url);
        if Url <> '' then begin
            imgObj.Add('u', Url);
            imgObj.Add('t', 1);
            exit;
        end;
        if not RetailImageUtils.ReturnTenantMediaForRetailImage(RetailImage, TenantMedia) then
            exit;
        imgObj.Add('u', Format(TenantMedia.ID, 0, 4)); // 4: GUID without brackets
        // imgObj.Add('w', TenantMedia.Width);
        // imgObj.Add('h', TenantMedia.Height);
        TenantMediaMimeType := TenantMedia."Mime Type".ToLower();
        if TenantMediaMimeType <> '' then
            if TenantMediaMimeType <> 'image/png' then
                imgObj.Add('m', TenantMediaMimeType);
    end;

    internal procedure HandleWebTemplateImages(var ControlLib: Codeunit "LSC POS Control Library") pendingLinksObj: JsonObject
    var
        d: Dictionary of [Text, Code[20]];
        PosImgUtils: Codeunit "LSC POS Image Utils";
        k, v : Text;
        PosCtrl: Codeunit "LSC POS Control Interface";
        WebTmplHandler: Codeunit "LSC POS Web Template Handler";
    begin
        // Internal (invoked from AddinWrapper)
        WebTmplHandler := PosCtrl.GetWebTemplateHandler();
        d := WebTmplHandler.GetPendingWebTemplateImageLinks();
        foreach k in d.Keys do begin
            v := d.Get(k);
            PosImgUtils.GetImg(v, ControlLib);
            if k <> v then
                pendingLinksObj.Add(k, v);
        end;
        WebTmplHandler.ClearPendingWebTemplateImageLinks();
    end;

    internal procedure SetTempControlImage(ctrlType: Enum "LSC POS Control Type"; ctrlID: Text; imgID: Code[20])
    var
        PosCtrl: Codeunit "LSC POS Control Interface";
        ControlLib: Codeunit "LSC POS Control Library";
        ImgUtils: Codeunit "LSC POS Image Utils";
    begin
        ControlLib := PosCtrl.GetControlLibrary();
        ImgUtils.GetImg(imgID, ControlLib);
        ControlLib.SetPosImage(ctrlType, ctrlID, imgID);
    end;

    internal procedure HasControlImage(ctrlType: Enum "LSC POS Control Type"; ctrlID: Text; clearIfFound: Boolean) found: Boolean
    var
        PosCtrl: Codeunit "LSC POS Control Interface";
        ControlLib: Codeunit "LSC POS Control Library";
        ImgCode: Text;
    begin
        ControlLib := PosCtrl.GetControlLibrary();
        ImgCode := ControlLib.GetPosImage(ctrlType, ctrlID);
        found := ImgCode <> '';
        if found then
            if clearIfFound then
                ControlLib.SetPosImage(ctrlType, ctrlID, '');
        exit(found);
    end;

    internal procedure AddSpecialImage(imgID: Code[20]): Boolean
    var
        RI: Record "LSC Retail Image";
        PosCtrl: Codeunit "LSC POS Control Interface";
        ControlLib: Codeunit "LSC POS Control Library";
        ImgUtils: Codeunit "LSC POS Image Utils";
    begin
        // This method should not be public, use PosSession.SetPosCtrlImage or PosSession.AddWebTemplateImage instead
        if true in [
            imgID = '',
            not RI.Get(imgID)
         ] then
            exit(false);
        ControlLib := PosCtrl.GetControlLibrary();
        ImgUtils.GetImg(imgID, ControlLib);
        exit(true);
    end;

    internal procedure GetImgCode(recID: RecordId): Code[20]
    begin
        exit(GetImgCode(recID, Enum::"LSC Retail Image Link Type"::Image));
    end;

    internal procedure GetImgCode(recID: RecordId; linkType: Enum "LSC Retail Image Link Type"): Code[20]
    var
        RetailImageLink: Record "LSC Retail Image Link";
        recIdTxt: Text;
    begin
        recIdTxt := Format(recID);
        if recIdTxt = '' then
            exit('');
        RetailImageLink.SetCurrentKey(TableName, KeyValue, "Display Order");
        RetailImageLink.SetRange("Record Id", recIdTxt);
        RetailImageLink.SetRange("Link Type", linkType);
        if not RetailImageLink.FindFirst() then
            exit('');
        exit(RetailImageLink."Image Id");
    end;

    internal procedure GetImgCodes(recID: RecordId) codes: List of [Code[20]]
    begin
        exit(GetImgCodes(recID, Enum::"LSC Retail Image Link Type"::Image));
    end;

    internal procedure GetImgCodes(recID: RecordId; linkType: Enum "LSC Retail Image Link Type") codes: List of [Code[20]]
    var
        RetailImageLink: Record "LSC Retail Image Link";
        recIdTxt: Text;
    begin
        recIdTxt := Format(recID);
        if recIdTxt = '' then
            exit;
        RetailImageLink.SetCurrentKey(TableName, KeyValue, "Display Order");
        RetailImageLink.SetRange("Record Id", recIdTxt);
        RetailImageLink.SetRange("Link Type", linkType);
        if RetailImageLink.FindSet() then
            repeat
                codes.Add(RetailImageLink."Image Id");
            until RetailImageLink.Next() = 0;
    end;

    internal procedure GetImgs(recID: RecordId; var CONTROLLIB: Codeunit "LSC POS Control Library") ImgIds: JsonArray
    var
        k: Text;
        ks: List of [Code[20]];
    begin
        ks := GetImgCodes(recID);
        foreach k in ks do begin
            ImgIds.Add(k);
            GetImg(k, CONTROLLIB);
        end;
    end;

    internal procedure GetPlaylist(playlistID: Text; var CONTROLLIB: Codeunit "LSC POS Control Library")
    var
        PlaylistHdr: Record "LSC POS Media Playlist Header";
        PendingPlaylists: JsonObject;
        ImgIds: JsonArray;
    begin
        if playlistID = '' then
            exit;
        if not PlaylistHdr.Get(playlistID) then
            exit; // remove?
        PendingPlaylists := CONTROLLIB.GetPendingPlaylists();
        if PendingPlaylists.Contains(playlistID) then // ID: Code[20]
            exit;
        ImgIds := GetImgs(PlaylistHdr.RecordId, CONTROLLIB);
        CONTROLLIB.AddPendingPlaylist(playlistID, ImgIds);
    end;

    internal procedure Add1PxTenantImage(): Text;
    var
        B64cu: Codeunit "Base64 Convert";
        Outstr: OutStream;
        Instr: InStream;
        tmpBlob: Codeunit "Temp Blob";
        existingGuid: Guid;
        RetailImage: Record "LSC Retail Image";
        TenantMediaOut: Record "Tenant Media";
        TenantMediaSet: Record "Tenant Media Set";
        base64Image: Text;
        description: text;
    begin
        // There needs to be at least 1 hardcoded RetailImage in the database which the client requests when the POS starts
        // This makes sure the service tier doesn't crash if an image is displayed "too soon" or if an image is deleted for some reason in the middle of a POS session
        base64Image := 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+P+/HgAFhAJ/wlseKgAAAABJRU5ErkJggg==';
        description := 'POS1PXIMAGE';

        // Check existance:
        TenantMediaOut.SetCurrentKey("Company Name");
        TenantMediaOut.SetRange("Company Name", CompanyName);
        TenantMediaOut.SetRange(Description, description);
        if TenantMediaOut.FindFirst() then
            existingGuid := TenantMediaOut.ID;

        if IsNullGuid(existingGuid) then begin
            tmpBlob.CreateOutStream(Outstr);
            B64cu.FromBase64(base64Image, Outstr);
            tmpBlob.CreateInStream(InStr);
            existingGuid := RetailImage."Image Mediaset".ImportStream(Instr, description, 'image/png');
            Clear(TenantMediaOut);
            TenantMediaSet.SetRange(ID, existingGuid);
            if TenantMediaSet.FindFirst() then
                if TenantMediaOut.Get(Format(TenantMediaSet."Media ID")) then
                    existingGuid := TenantMediaOut.ID;
        end;

        exit(Format(existingGuid, 0, 4));
    end;
}