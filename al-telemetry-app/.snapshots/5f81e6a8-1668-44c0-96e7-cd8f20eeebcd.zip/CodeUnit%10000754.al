codeunit 10000754 "LSC Basic Search" implements "LSC ISearchEngine"
{
    Access = Internal;
    //Interface Impl.
    var
        SearchTreeBuffer: Record "LSC Search Tree Buffer" temporary;
        SearchResultBuffer: Record "LSC Search Result Buffer" temporary;
        LastNodeId: Integer;
        LastValueId: Integer;
        LastSetId: integer;
        ValueIds: Dictionary of [Text[1], Integer];
        MinSearchChar: Integer;
        MinEntryCount: Integer;
        MaxEntryCount: Integer;

    procedure Init()
    begin
        SearchTreeBuffer.Reset();
        SearchTreeBuffer.DeleteAll();
        LastSetId := 0;
        LastValueId := 0;
        Clear(ValueIds);
        MinSearchChar := 3;
        MinEntryCount := 1;
        MaxEntryCount := 1000;
        SearchTreeBuffer.OnAfterInitBasicSearch(MinSearchChar);
    end;

    procedure SearchEngineName(): Text
    begin
        exit('LS Basic Search');
    end;

    procedure Search(pSearchIndexCode: Text; pQuery: Text; pFilter: Text; pMaxHits: Integer; var pHits: Record "LSC Search Index Result" temporary; UseWildcard: Boolean; UseFuzzy: Boolean): Integer
    var
        SearchValue: Text[1];
        SearchValueIndex: Integer;
        SearchStringLen: Integer;
        ValueId: Integer;
        LastParentId: Integer;
        EntryCountLimit: Boolean;
    begin
        pQuery := pQuery.Trim();
        EntryCountLimit := false;
        SearchValueIndex := 0;
        SearchStringLen := StrLen(pQuery);
        while ((SearchValueIndex < SearchStringLen) and (not EntryCountLimit)) do begin
            SearchValueIndex := SearchValueIndex + 1;
            SearchValue := UpperCase(CopyStr(pQuery, SearchValueIndex, 1));
            IF ValueIds.ContainsKey(SearchValue) then
                ValueId := ValueIds.Get(SearchValue)
            else begin
                LastValueId := LastValueId + 1;
                ValueId := LastValueId;
                ValueIds.Add(SearchValue, ValueId);
            end;
            SearchTreeBuffer.SetRange("Parent ID", LastParentId);
            SearchTreeBuffer.SetRange("Value ID", ValueId);
            IF SearchTreeBuffer.FindFirst() then begin
                LastParentId := SearchTreeBuffer."Node ID";
                IF (SearchTreeBuffer."Set ID" > 0) and (SearchTreeBuffer."Entry Count" < MinEntryCount) then
                    EntryCountLimit := true;
            end else begin
                LastNodeId := LastNodeId + 1;
                SearchTreeBuffer.Init();
                SearchTreeBuffer."Parent ID" := LastParentId;
                SearchTreeBuffer."Node ID" := LastNodeId;
                SearchTreeBuffer."Value ID" := ValueId;
                SearchTreeBuffer.Insert();
                LastParentId := SearchTreeBuffer."Node ID";
            end;
        end;
        If (SearchValueIndex >= MinSearchChar) and (SearchTreeBuffer."Set ID" = 0) then begin
            LastSetId := LastSetId + 1;
            SearchTreeBuffer."Set ID" := LastSetId;
            SearchTreeBuffer."Entry Count" := SearchAndLoadResultBuffer(SearchTreeBuffer."Set ID", pQuery);
            SearchTreeBuffer.Modify();
        end;
        IF EntryCountLimit then
            LoadSearchIndexResult(SearchTreeBuffer."Set ID", pSearchIndexCode, pQuery, pMaxHits, pHits)
        else
            LoadSearchIndexResult(SearchTreeBuffer."Set ID", pSearchIndexCode, '', pMaxHits, pHits);
    end;

    procedure UseIndexing(): Boolean
    begin
        exit(false); //No Indexing
    end;

    procedure OpenIndex()
    begin
        //No Indexing
        Message('OpenIndex');
    end;

    procedure CreateIndex()
    begin
        //No Indexing
        Message('CreateIndex');
    end;

    procedure CloseIndex(pDBName: Text)
    begin
        //No Indexing
    end;

    procedure IsIndexAllRequired(pDBName: Text): Boolean
    begin
        exit(false); //No Indexing
    end;

    procedure IndexEntry(EntryRecRef: RecordRef; SearchTable: Record "LSC Search Index Table")
    begin
        //No Indexing
    end;

    procedure DeleteSearchIndex(pSearchTable: Text)
    begin
        //No Indexing
    end;

    procedure DeleteEntry(pRecordID: RecordID)
    begin
        //No Indexing
    end;

    procedure GetLastSyncTime(): DateTime
    begin
        exit(0DT); //No Indexing
    end;

    local procedure SearchAndLoadResultBuffer(SetId: Integer; SearchString: text): Integer
    Var
        SearchIndexTable: Record "LSC Search Index Table";
        SetEntryNo: Integer;
    begin
        SetEntryNo := 0;
        SearchIndexTable.reset;
        SearchIndexTable.SetCurrentKey(Boost);
        SearchIndexTable.SetAscending(Boost, false);
        SearchIndexTable.SetRange("Parent Code", '');
        IF SearchIndexTable.FindSet() then
            repeat
                SearchPrimaryTable(SetId, SetEntryNo, SearchIndexTable, SearchString);
            until SearchIndexTable.Next() = 0;
        exit(SetEntryNo);
    end;

    local procedure SearchPrimaryTable(SetId: Integer; var SetEntryNo: Integer; var SearchIndexTable: Record "LSC Search Index Table"; SearchString: text)
    Var
        SearchResultBuffer2: Record "LSC Search Result Buffer" temporary;
        SearchIndexNestedTable: Record "LSC Search Index Table";
        TitleFieldBuffer: Record "LSC WS Node Buffer" temporary;
        PrimaryTableRec: RecordRef;
        NestedTableRec: RecordRef;
        IntermediateSetEntryNo: Integer;
        SearchCodeEntryCount: Integer;
    begin
        IntermediateSetEntryNo := SetEntryNo;
        SearchCodeEntryCount := 0;
        FindTitleFieldNo(SearchIndexTable, TitleFieldBuffer);
        SearchResultBuffer2.Reset();
        SearchResultBuffer2.DeleteAll();
        PrimaryTableRec.open(SearchIndexTable."Table No.");
        SearchTable(SetId, SearchCodeEntryCount, SearchIndexTable, SearchString, PrimaryTableRec, SearchResultBuffer2);
        SearchResultBuffer2.Reset();
        if SearchResultBuffer2.FindSet() then
            repeat
                SetEntryNo := SetEntryNo + 1;
                SearchResultBuffer.Init();
                SearchResultBuffer := SearchResultBuffer2;
                SearchResultBuffer."Entry No." := SetEntryNo;
                SearchResultBuffer.Insert();
            until SearchResultBuffer2.Next() = 0;
        SearchIndexNestedTable.Reset();
        SearchIndexNestedTable.SetCurrentKey(Boost);
        SearchIndexNestedTable.SetAscending(Boost, false);
        SearchIndexNestedTable.SetRange("Parent Code", SearchIndexTable.Code);
        IF SearchIndexNestedTable.FindSet() then
            repeat
                SearchResultBuffer2.Reset();
                SearchResultBuffer2.DeleteAll();
                NestedTableRec.open(SearchIndexNestedTable."Table No.");
                SearchTable(SetId, SearchCodeEntryCount, SearchIndexNestedTable, SearchString, NestedTableRec, SearchResultBuffer2);
                SearchResultBuffer2.Reset();
                if SearchResultBuffer2.FindSet() then begin
                    PrimaryTableRec.reset;
                    NestedTableRec.Reset();
                    repeat
                        IF NestedTableRec.get(SearchResultBuffer2."Record Id") then begin
                            SetLinkedTableFilter(NestedTableRec, SearchIndexNestedTable."Filter Key", PrimaryTableRec, SearchIndexNestedTable."Parent Filter Key");
                            IF PrimaryTableRec.FindSet() then
                                repeat
                                    SetEntryNo := SetEntryNo + 1;
                                    SearchResultBuffer.Init();
                                    SearchResultBuffer := SearchResultBuffer2;
                                    SearchResultBuffer."Entry No." := SetEntryNo;
                                    SearchResultBuffer."Table No." := PrimaryTableRec.Number;
                                    SearchResultBuffer."Record Id" := PrimaryTableRec.RecordId;
                                    SearchResultBuffer.Type := SearchIndexTable.Code;
                                    SearchResultBuffer.Insert();
                                until PrimaryTableRec.Next() = 0;
                        end
                    until SearchResultBuffer2.Next() = 0;
                end;
                NestedTableRec.Close();
            until SearchIndexNestedTable.Next() = 0;
        PrimaryTableRec.Close();
        UpdateSearchResultBufferTitle(SetId, IntermediateSetEntryNo, TitleFieldBuffer);
    end;

    local procedure SearchTable(SetId: Integer; var SearchCodeEntryCount: Integer; var SearchIndexTable: Record "LSC Search Index Table"; SearchString: text; Var TableRec: RecordRef; var SearchResultBuffer2: Record "LSC Search Result Buffer" temporary)
    Var
        SearchIndexField: Record "LSC Search Index Field";
        WSFunc: Codeunit "LSC WS Functions";
        TableField: FieldRef;
        BestKeyIndex: Integer;
    begin
        SetFixedFilter(SearchIndexTable, TableRec);
        SearchIndexField.Reset();
        SearchIndexField.SetRange("Search Index Code", SearchIndexTable.Code);
        SearchIndexField.SetRange("Table No.", SearchIndexTable."Table No.");
        SearchIndexField.SetFilter("Field No.", '<>%1', 0);
        SearchIndexField.SetRange(Searchable, true);
        IF SearchIndexField.FindSet() then
            repeat
                TableField := TableRec.Field(SearchIndexField."Field No.");
                BestKeyIndex := WSFunc.FindKeyIndex(TableRec, TableField);
                if BestKeyIndex <> 0 then
                    TableRec.CurrentKeyIndex(BestKeyIndex);
                TableField.SetFilter(ConstructFilterString(SearchString, SearchIndexField."Skip Optimized Text Search"));

                if TableRec.FindSet() then
                    repeat
                        SearchCodeEntryCount := SearchCodeEntryCount + 1;
                        SearchResultBuffer2.Init();
                        SearchResultBuffer2."Set ID" := SetId;
                        SearchResultBuffer2."Entry No." := SearchCodeEntryCount;
                        SearchResultBuffer2."Table No." := TableRec.Number;
                        SearchResultBuffer2."Record Id" := TableRec.RecordId;
                        SearchResultBuffer2."Search Value" := format(TableField.Value);
                        SearchResultBuffer2.Type := SearchIndexTable.Code;
                        SearchResultBuffer2.Insert();
                    until ((TableRec.Next() = 0) or (SearchCodeEntryCount >= MaxEntryCount));
                TableField.SetRange();
            until ((SearchIndexField.Next() = 0) or (SearchCodeEntryCount >= MaxEntryCount));
    end;

    local procedure FindTitleFieldNo(var SearchIndexTable: Record "LSC Search Index Table"; var TitleFieldBuffer: Record "LSC WS Node Buffer" temporary)
    Var
        SearchIndexField: Record "LSC Search Index Field";
        SearchIndexNestedTable: Record "LSC Search Index Table";
        Helper: Codeunit "LSC Helper";
        TitleFormat: text;
        TitleFormatToken: text;
        TmpToken: text;
        AliasFieldName: Text;
        AliasFieldFound: Boolean;
        EntryNo: Integer;
    begin
        EntryNo := 0;
        TitleFormat := SearchIndexTable."Title Format";
        TitleFormatToken := Helper.GetToken(TitleFormat, '}');
        While (TitleFormatToken <> '') do begin
            TitleFormatToken := TitleFormatToken + '}';
            AliasFieldName := '';
            IF (StrPos(TitleFormatToken, '{') > 0) and (StrPos(TitleFormatToken, '}') > 0) then begin
                TmpToken := Helper.GetToken(TitleFormatToken, '{');
                AliasFieldName := Helper.GetToken(TitleFormatToken, '}');
            end;
            IF AliasFieldName <> '' then begin
                SearchIndexField.Reset();
                SearchIndexField.SetRange("Search Index Code", SearchIndexTable.Code);
                SearchIndexField.SetRange("Table No.", SearchIndexTable."Table No.");
                SearchIndexField.SetRange(Alias, AliasFieldName);
                IF SearchIndexField.FindFirst() then begin
                    EntryNo := EntryNo + 1;
                    TitleFieldBuffer.Init();
                    TitleFieldBuffer."Entry No." := EntryNo;
                    TitleFieldBuffer.Source := SearchIndexField."Search Index Code";
                    TitleFieldBuffer."Node Name" := AliasFieldName;
                    TitleFieldBuffer."Table No." := SearchIndexField."Table No.";
                    TitleFieldBuffer."Field No." := SearchIndexField."Field No.";
                    TitleFieldBuffer.Insert();
                end else begin
                    AliasFieldFound := false;
                    SearchIndexNestedTable.Reset();
                    SearchIndexNestedTable.SetCurrentKey(Boost);
                    SearchIndexNestedTable.SetAscending(Boost, false);
                    SearchIndexNestedTable.SetRange("Parent Code", SearchIndexTable.Code);
                    IF SearchIndexNestedTable.FindSet() then
                        repeat
                            SearchIndexField.Reset();
                            SearchIndexField.SetRange("Search Index Code", SearchIndexNestedTable.Code);
                            SearchIndexField.SetRange("Table No.", SearchIndexNestedTable."Table No.");
                            SearchIndexField.SetRange(Alias, AliasFieldName);
                            IF SearchIndexField.FindFirst() then begin
                                EntryNo := EntryNo + 1;
                                TitleFieldBuffer.Init();
                                TitleFieldBuffer."Entry No." := EntryNo;
                                TitleFieldBuffer.Source := SearchIndexField."Search Index Code";
                                TitleFieldBuffer."Node Name" := AliasFieldName;
                                TitleFieldBuffer."Table No." := SearchIndexField."Table No.";
                                TitleFieldBuffer."Field No." := SearchIndexField."Field No.";
                                TitleFieldBuffer.Insert();
                                AliasFieldFound := true;
                            end;
                        until (SearchIndexNestedTable.Next() = 0) or (AliasFieldFound);
                end;
            end;
            TitleFormatToken := Helper.GetToken(TitleFormat, '}');
        end;
    end;

    local procedure UpdateSearchResultBufferTitle(SetId: Integer; IntermediateSetEntryNo: Integer; var TitleFieldBuffer: Record "LSC WS Node Buffer" temporary)
    var
        SearchIndexTable: Record "LSC Search Index Table";
        NestedSearchIndexTable: Record "LSC Search Index Table";
        PrimaryTableRec: RecordRef;
        NestedTableRec: RecordRef;
        TitleField: FieldRef;
        TitleFieldText: text;
        TitleText: TextBuilder;
        AliasFieldToken: Text;
    begin
        SearchResultBuffer.Reset();
        SearchResultBuffer.SetRange("Set ID", SetID);
        SearchResultBuffer.SetFilter("Entry No.", '>%1', IntermediateSetEntryNo);
        IF SearchResultBuffer.FindSet() then begin
            SearchIndexTable.get(SearchResultBuffer.Type);
            PrimaryTableRec.open(SearchResultBuffer."Table No.");
            repeat
                TitleText.Clear();
                PrimaryTableRec.Get(SearchResultBuffer."Record Id");
                TitleFieldBuffer.Reset();
                IF TitleFieldBuffer.FindSet() then
                    repeat
                        TitleFieldText := '';
                        if TitleFieldBuffer."Table No." = SearchResultBuffer."Table No." then begin
                            TitleField := PrimaryTableRec.Field(TitleFieldBuffer."Field No.");
                            TitleFieldText := format(TitleField.Value);
                        end else begin
                            NestedSearchIndexTable.Get(TitleFieldBuffer.Source);
                            NestedTableRec.Open(TitleFieldBuffer."Table No.");
                            SetLinkedTableFilter(PrimaryTableRec, NestedSearchIndexTable."Parent Filter Key", NestedTableRec, NestedSearchIndexTable."Filter Key");
                            if NestedTableRec.FindFirst() then begin
                                TitleField := NestedTableRec.Field(TitleFieldBuffer."Field No.");
                                TitleFieldText := format(TitleField.Value);
                            end;
                            NestedTableRec.Close();
                        end;
                        AliasFieldToken := '{' + TitleFieldBuffer."Node Name" + '}';
                        if TitleText.Length = 0 then begin
                            TitleText.Append(SearchIndexTable."Title Format");
                            TitleText.Replace(AliasFieldToken, TitleFieldText);
                        end else
                            TitleText.Replace(AliasFieldToken, TitleFieldText);
                    until TitleFieldBuffer.Next() = 0;
                if TitleText.Length > 0 then
                    SearchResultBuffer.Title := TitleText.ToText()
                else
                    SearchResultBuffer.Title := SearchResultBuffer."Search Value";
                SearchResultBuffer.Modify();
            until SearchResultBuffer.Next() = 0;
            PrimaryTableRec.Close();
        end
    end;

    local procedure SetFixedFilter(var SearchIndexTable: Record "LSC Search Index Table"; Var TableRec: RecordRef)
    Var
        SearchIndexField: Record "LSC Search Index Field";
        TableField: FieldRef;
        WSFunctions: Codeunit "LSC WS Functions";
        Helper: Codeunit "LSC Helper";
        FixedValue: Text;
        IntegerValue: Integer;
        BooleanValue: Boolean;
    begin
        SearchIndexField.Reset();
        SearchIndexField.SetRange("Search Index Code", SearchIndexTable.Code);
        SearchIndexField.SetRange("Table No.", SearchIndexTable."Table No.");
        SearchIndexField.SetFilter("Field No.", '<>%1', 0);
        SearchIndexField.SetRange(Searchable, false);
        SearchIndexField.SetFilter("Fixed Filter", '<>%1', '');
        IF SearchIndexField.FindSet() then
            repeat
                TableField := TableRec.Field(SearchIndexField."Field No.");
                FixedValue := SearchIndexField."Fixed Filter";
                if (Format(TableField.Type)) = 'Integer' then begin
                    Evaluate(IntegerValue, FixedValue);
                    TableField.SetFilter('%1', IntegerValue);
                end else
                    if (Format(TableField.Type)) = 'Boolean' then begin
                        Evaluate(BooleanValue, FixedValue);
                        TableField.SetFilter('%1', BooleanValue);
                    end else begin
                        FixedValue := Helper.ReplaceStrContaningStrWithStr(FixedValue, '''', ' ');
                        TableField.SetFilter(WSFunctions.MakeFilter(FixedValue));
                    end;
            until SearchIndexField.Next() = 0;
    end;

    local procedure SetLinkedTableFilter(var SourceFilterRecRef: RecordRef; SourceFilterFields: Text; var TargetRecRef: RecordRef; TargetFilterFields: Text)
    var
        Helper: Codeunit "LSC Helper";
        TargetFilterFieldStr: Text;
        SourceFilterFieldStr: Text;
        TargetFieldNo: Integer;
        SourceFieldNo: Integer;
        Variant: Variant;
        TargetFieldRef: FieldRef;
        SourceFieldRef: FieldRef;
        OptionVar: Option;
    begin
        if (TargetFilterFields = '') or (SourceFilterFields = '') then
            exit;
        repeat
            TargetFilterFieldStr := Helper.GetToken(TargetFilterFields, ',');
            SourceFilterFieldStr := Helper.GetToken(SourceFilterFields, ',');
            if (TargetFilterFieldStr <> '') and (SourceFilterFieldStr <> '') then begin
                Clear(Variant);
                Evaluate(TargetFieldNo, TargetFilterFieldStr);
                Evaluate(SourceFieldNo, SourceFilterFieldStr);
                TargetFieldRef := TargetRecRef.Field(TargetFieldNo);
                SourceFieldRef := SourceFilterRecRef.Field(SourceFieldNo);
                if Format(SourceFieldRef.Type) = 'Option' then begin
                    OptionVar := SourceFieldRef.Value;
                    TargetFieldRef.SetFilter(Format(OptionVar, 0, 2));
                end else
                    if Format(SourceFieldRef.Type) in ['Text', 'Code'] then begin
                        Variant := SourceFieldRef.Value;
                        TargetFieldRef.SetFilter('%1', Variant);
                    end else begin
                        Variant := SourceFieldRef.Value;
                        TargetFieldRef.SetFilter(Format(Variant));
                    end;
            end;
        until TargetFilterFieldStr = '';
    end;

    local procedure LoadSearchIndexResult(SetId: Integer; SearchIndexCode: Text; SearchString: text; MaxResultCount: Integer; var SearchIndexResult: Record "LSC Search Index Result" temporary)
    var
        PrimaryRecordIndex: Record "LSC Search Index Result" temporary;
        Index: Integer;
        TableRec: RecordRef;
        RecordIdText: Text;
    begin
        SearchIndexResult.Reset();
        SearchIndexResult.DeleteAll();
        Index := 0;
        SearchResultBuffer.Reset();
        SearchResultBuffer.SetRange("Set ID", SetID);
        If SearchIndexCode <> '' then
            SearchResultBuffer.SetRange(Type, SearchIndexCode);
        IF SearchString <> '' then
            SearchResultBuffer.SetFilter("Search Value", ConstructFilterString(SearchString, true));

        IF SearchResultBuffer.FindSet() then
            repeat
                IF TableRec.number <> SearchResultBuffer."Table No." then begin
                    IF TableRec.number <> 0 then
                        TableRec.close;
                    TableRec.Open(SearchResultBuffer."Table No.");
                end;
                IF TableRec.Get(SearchResultBuffer."Record Id") then begin
                    RecordIdText := format(SearchResultBuffer."Record Id");
                    PrimaryRecordIndex.SetRange(ID, RecordIdText);
                    IF PrimaryRecordIndex.IsEmpty then begin
                        Index := Index + 1;
                        SearchIndexResult.Init();
                        SearchIndexResult."No." := Index;
                        SearchIndexResult.Score := 1.0;
                        SearchIndexResult.id := format(SearchResultBuffer."Record Id");
                        SearchIndexResult.Title := SearchResultBuffer.Title;
                        SearchIndexResult.Type := SearchResultBuffer.Type;
                        SearchIndexResult.Insert();
                        PrimaryRecordIndex.Init();
                        PrimaryRecordIndex."No." := Index;
                        PrimaryRecordIndex.ID := SearchIndexResult.ID;
                        PrimaryRecordindex.Insert();
                    end;
                end;
            until (SearchResultBuffer.next = 0) or ((MaxResultCount > 0) and (Index >= MaxResultCount));
        IF TableRec.number <> 0 then
            TableRec.close;
    end;

    local procedure ConstructFilterString(SearchString: Text; SkipOptimizedTextSearch: Boolean): Text
    var
        filterOut: Text;
    begin
        if SkipOptimizedTextSearch then begin
            filterOut := StrSubstNo('@*%1*', SearchString);
            filterOut := filterOut.Replace(' ', '*&@*');
        end else begin
            filterOut := StrSubstNo('&&%1*', SearchString);
            filterOut := filterOut.Replace(' ', '*&&&');
        end;
        exit(filterOut);
    end;
}

