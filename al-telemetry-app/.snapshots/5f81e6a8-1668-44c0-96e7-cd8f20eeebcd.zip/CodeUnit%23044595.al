codeunit 23044595 "LPM Assisted Setup"
{
    TableNo = "LPM Assisted Setup Buffer";

    trigger OnRun()
    begin
        if Rec."Setup Action" = Rec."Setup Action"::Initialize then
            InitializeSetupData();
    end;

    local procedure InitializeSetupData()
    var
        lrecLPMSetup: Record "IWX License Plate Setup";
        llblNoSeriesDescriptionLbl: Label 'LPM License Plates';
    begin
        // create the number series
        if lrecLPMSetup.Get() then
            if lrecLPMSetup."License Plate Nos." = '' then begin
                CreateNumberSeries('LPM LP', llblNoSeriesDescriptionLbl, 'LP');
                lrecLPMSetup."License Plate Nos." := 'LPM LP';
                lrecLPMSetup.Modify(false);
            end;
    end;

    /// <summary>
    /// Generate a number series
    /// </summary>
    /// <param name="pcodNumberSeriesCode">The name of the number series to create</param>
    /// <param name="psDescription">The number series description</param>
    /// <param name="pcodStartBase">The base of the number series line</param>
    procedure CreateNumberSeries(pcodNumberSeriesCode: Code[10]; psDescription: Text; pcodStartBase: Code[10])
    var
        lrecNoSeries: Record "No. Series";
        lrecNoSeriesLine: Record "No. Series Line";
    begin
        if lrecNoSeries.Get(pcodNumberSeriesCode) then
            exit;

        lrecNoSeries.Init();
        lrecNoSeries.Code := pcodNumberSeriesCode;
        lrecNoSeries.Description := CopyStr(psDescription, 1, MaxStrLen(lrecNoSeries.Description));
        lrecNoSeries."Default Nos." := true;
        lrecNoSeries.Insert(true);

        lrecNoSeriesLine.Init();
        lrecNoSeriesLine."Series Code" := lrecNoSeries.Code;
        lrecNoSeriesLine."Line No." := 10000;
        lrecNoSeriesLine."Starting No." := pcodStartBase + '000001';
        lrecNoSeriesLine."Ending No." := pcodStartBase + '999999';
        lrecNoSeriesLine.Insert(true);
    end;

#if V18_OR_HIGHER
    local procedure CreateAssistedSetupEntry()
    var
        lcuGuidedExperience: Codeunit "Guided Experience";
        ltcTitleTxt: Label 'Set up License Plate Management';
        ltcShortTitleTxt: Label 'License Plate Management';
        ltcDescriptionTxt: Label 'License Plate Management for Dynamics 365 Business Central';
        ltcHelpURLTxt: Label 'https://app.dmsiworks.com/license-plating/product-help/', Locked = true;
        ltcVideoURLTxt: Label '';
        lbCompleted: Boolean;
    begin
        lbCompleted := false;
        if lcuGuidedExperience.Exists("Guided Experience Type"::"Assisted Setup", ObjectType::Page, Page::"LPM Setup Wizard") then begin
            lbCompleted := lcuGuidedExperience.IsAssistedSetupComplete(ObjectType::Page, Page::"LPM Setup Wizard");
            lcuGuidedExperience.Remove("Guided Experience Type"::"Assisted Setup", ObjectType::Page, Page::"LPM Setup Wizard");
        end;

        lcuGuidedExperience.InsertAssistedSetup(
            ltcTitleTxt,
            ltcShortTitleTxt,
            ltcDescriptionTxt,
            15,
            ObjectType::Page,
            Page::"LPM Setup Wizard",
            "Assisted Setup Group"::IWX,
            ltcVideoURLTxt,
            "Video Category"::GettingStarted,
            ltcHelpURLTxt
        );

        if lbCompleted then
            lcuGuidedExperience.CompleteAssistedSetup(ObjectType::Page, Page::"LPM Setup Wizard");
    end;


    /// <summary>
    /// Set our extension up for assisted setup
    /// </summary>
    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Guided Experience", 'OnRegisterAssistedSetup', '', true, true)]
    local procedure OnRegisterAssistedSetup();
    var
        lcuGuidedExperience: Codeunit "Guided Experience";
        leGuidedExperienceType: Enum "Guided Experience Type";
    begin
        if not lcuGuidedExperience.Exists(leGuidedExperienceType::"Manual Setup", ObjectType::Page, Page::"LPM Setup Wizard") then
            CreateAssistedSetupEntry();
    end;

    /// <summary>
    /// Set our extension up for assisted setup
    /// </summary>
    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Guided Experience", 'OnRegisterManualSetup', '', true, true)]

    local procedure OnRegisterManualSetup();
    var
        lrecSetup: Record "IWX License Plate Setup";
    begin

        if (not lrecSetup.GET()) then
            lrecSetup.Insert(false);

        CreateAssistedSetupEntry();
    end;
#elif V15_OR_HIGHER

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Assisted Setup", 'OnRegister', '', true, true)]
    local procedure HandleD365OnRegisterAssistedSetup();
    begin
        V15ToV17HandleD365OnRegisterAssistedSetup();
    end;





    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Manual Setup", 'OnRegisterManualSetup', '', true, true)]
    local procedure HandleD365OnRegisterBusinessSetup();
    var
        lrecSetup: Record "IWX License Plate Setup";
        lcuManualSetup: Codeunit "Manual Setup";
        lenumManualSetupCat: Enum "Manual Setup Category";
    begin

        if (not lrecSetup.GET()) then
            lrecSetup.INSERT(false);

        lcuManualSetup.Insert(
            tcSetUpAssistantNameLbl,
            tcAssistedSetupDescLbl,
            'License Plate Management,Insight Works',
            PAGE::"IWX License Plate Setup",
            GetAppID(),
            lenumManualSetupCat::Uncategorized
        );
    end;
#endif

#if V18_OR_HIGHER
    // do nothing
#elif V16_OR_HIGHER
    local procedure V15ToV17HandleD365OnRegisterAssistedSetup()
    var
        lcuAssistedSetup: Codeunit "Assisted Setup";
        lenumGroup: Enum "Assisted Setup Group";
    begin 
        if not lcuAssistedSetup.Exists(Page::"LPM Setup Wizard") then
            lcuAssistedSetup.Add(
                GetAppID(),
                Page::"LPM Setup Wizard",
                tcSetUpAssistantNameLbl,
                lenumGroup::IWX
            );
    end;
#elif V15_OR_HIGHER
    local procedure V15ToV17HandleD365OnRegisterAssistedSetup()
    var
        lcuAssistedSetup: Codeunit "Assisted Setup";
        lenumGroup: Enum "Assisted Setup Group";
    begin
        if not lcuAssistedSetup.Exists(GetAppID(), Page::"LPM Setup Wizard") then
            lcuAssistedSetup.Add(
                GetAppID(),
                Page::"LPM Setup Wizard",
                tcSetUpAssistantNameLbl,
                lenumGroup::IWX
            );
    end;
#endif




    /// <summary>
    /// Acquires current registration information and puts up a notification if required
    /// </summary>
    local procedure RunRegCheckNotification();
    var
        lrecLPMSetup: Record "IWX License Plate Setup";
        lrecRegistrationLine: Record "IWX Registration Line";
        lcuRegistration: Codeunit "IWX Registration";
        lcuPaths: Codeunit "IWX Well Known Values";
    begin
        if not lrecLPMSetup.Get() then begin
            lrecLPMSetup.Init();
            lrecLPMSetup.Insert(true);
        end;

        //if lrecLPMSetup."Wizard State" = lrecSetup."Wizard State"::Incomplete then begin
        if lrecLPMSetup."License Plate Nos." = '' then
            CreateActionNotification(tcWizardLbl, tcStartLbl, Codeunit::"LPM Assisted Setup", 'RunWizard', runSetupGuidTok, Codeunit::"LPM Assisted Setup", 'HideSetupNotification')
        else begin
            lcuRegistration.CheckRegistration(lrecRegistrationLine, lcuPaths.GetLPID(), lcuPaths.GetLP240LogoURL(), false);

            case lrecRegistrationLine.Status of
                lrecRegistrationLine.Status::"Not Registered":
                    if lrecRegistrationLine."Expiry Date" < CalcDate('<+2d>', Today()) then
                        CreateActionNotification(tcExpiryThresholdMsg, tcContactMsg, Codeunit::"LPM Assisted Setup", 'HandleAction', expiryThresholdGuidTok, Codeunit::"LPM Assisted Setup", 'HideExpiryNotification')
                    else
                        CreateActionNotification(tcNotRegisteredQst, tcContactMsg, Codeunit::"LPM Assisted Setup", 'HandleAction', notRegisteredGuidTok, Codeunit::"LPM Assisted Setup", 'HideNotRegisteredNotification');
                lrecRegistrationLine.Status::Registered:
                    if lrecRegistrationLine."Expiry Date" < CalcDate('<+2d>', Today()) then
                        CreateActionNotification(tcExpiryThresholdMsg, tcContactMsg, Codeunit::"LPM Assisted Setup", 'HandleAction', expiryThresholdGuidTok, Codeunit::"LPM Assisted Setup", 'HideExpiryNotification');
                lrecRegistrationLine.Status::Blocked:
                    CreateActionNotification(tcBlockedErr, tcContactMsg, Codeunit::"LPM Assisted Setup", 'HandleAction', blockedGuidTok, Codeunit::"LPM Assisted Setup", 'HideBlockedNotification');
            end;
        end;
    end;

    /// <summary>
    /// Creates and sends a message to the local scope based on the provided string and action parameters
    /// Local scope = the page the user is currently on
    /// </summary>
    /// <param name="ptxtMessage"></param>
    /// <param name="ptxtActionMessage"></param>
    /// <param name="piCodeunit"></param>
    /// <param name="ptxtFunction"></param>
    local procedure CreateActionNotification(ptxtMessage: Text; ptxtActionMessage: Text; piCodeunit: Integer; ptxtFunction: Text; pgID: Guid; piDontShowAgainCodeunit: Integer; ptxtDontShowAgainFunction: Text)
    var
        lrecMyNotifications: Record "My Notifications";
        lnNotify: Notification;
        ltcDontShowAgainLbl: Label 'Don''t show this again.';
    begin

        if (not lrecMyNotifications.IsEnabled(pgID)) then
            exit;

        lnNotify.Message(ptxtMessage);
        lnNotify.AddAction(ptxtActionMessage, piCodeunit, ptxtFunction);

        if piDontShowAgainCodeunit > 0 then
            lnNotify.AddAction(ltcDontShowAgainLbl, piDontShowAgainCodeunit, ptxtDontShowAgainFunction);

        lnNotify.Scope := NotificationScope::LocalScope;
        lnNotify.SetData('origin', ptxtMessage);
        lnNotify.Id := pgID;
        lnNotify.Send();
    end;

    procedure HandleAction(pnNotification: Notification)
    var
        lcuRegistration: Codeunit "IWX Registration";
    begin
        lcuRegistration.RequestRegistration(pnNotification.GetData('origin'));
    end;


    local procedure HideNotification(notif: Notification; notificationName: Text[128]; notificationDescription: Text)
    var
        myNotifications: Record "My Notifications";
    begin
        if (not myNotifications.Disable(notif.Id())) then
            myNotifications.InsertDefault(notif.Id(), notificationName, notificationDescription, false);
    end;

    /// <summary>
    /// Hides the setup notification.
    /// </summary>
    /// <param name="pnNotification"></param>
#if V15_OR_HIGHER
    internal
#endif
    procedure HideSetupNotification(pnNotification: Notification)
    var
        ltcNotificationNameTxt: Label 'License Plate Management: Notify the user of assisted setup required.';
        ltcNotificationDescrTxt: Label 'Show a notification when the assisted setup has not been completed.';
    begin
        HideNotification(pnNotification, ltcNotificationNameTxt, ltcNotificationDescrTxt);
    end;

    /// <summary>
    /// Hides the not registered/demo notification.
    /// </summary>
    /// <param name="pnNotification"></param>
#if V15_OR_HIGHER
    internal
#endif
    procedure HideNotRegisteredNotification(pnNotification: Notification)
    var
        ltcNotificationNameTxt: Label 'License Plate Management: Notify the user of demo account.';
        ltcNotificationDescrTxt: Label 'Show a notification when the license has not been registered and is running in demonstration mode.';
    begin
        HideNotification(pnNotification, ltcNotificationNameTxt, ltcNotificationDescrTxt);
    end;


    /// <summary>
    /// Hides the blocked notification.
    /// </summary>
    /// <param name="pnNotification"></param>
#if V15_OR_HIGHER
    internal
#endif
    procedure HideBlockedNotification(pnNotification: Notification)
    var
        ltcNotificationNameTxt: Label 'License Plate Management: Notify the user of blocked account.';
        ltcNotificationDescrTxt: Label 'Show a notification when the license has registratioon has been set to blocked.';
    begin
        HideNotification(pnNotification, ltcNotificationNameTxt, ltcNotificationDescrTxt);
    end;

    /// <summary>
    /// Hides the expiry notification.
    /// </summary>
    /// <param name="pnNotification"></param>
#if V15_OR_HIGHER
    internal procedure HideExpiryNotification(pnNotification: Notification)
#else
    procedure HideExpiryNotification(pnNotification: Notification)
#endif
    var
        ltcNotificationNameTxt: Label 'License Plate Management: Notify the user of pending license expiration.';
        ltcNotificationDescrTxt: Label 'Show a notification when the license is close to expiring or has expired.';
    begin
        HideNotification(pnNotification, ltcNotificationNameTxt, ltcNotificationDescrTxt);
    end;

    procedure RunWizard(pnNotification: Notification)
    var
        lpgWizard: Page "LPM Setup Wizard";
    begin
        lpgWizard.Run();
    end;


    [EventSubscriber(ObjectType::Page, Page::"O365 Activities", 'OnOpenPageEvent', '', false, false)]
    local procedure HandlePageO365ActivitiesOnOpenPage(var Rec: Record "Activities Cue");
    begin
        RunRegCheckNotification();
    end;


    [EventSubscriber(ObjectType::Page, Page::"Shop Supervisor Activities", 'OnOpenPageEvent', '', false, false)]
    local procedure HandlePageShopSupervisorActivitiesOnOpenPage(var Rec: Record "Manufacturing Cue");
    begin
        RunRegCheckNotification();
    end;

#if V17_OR_HIGHER
    [EventSubscriber(ObjectType::Page, Page::"Approvals Activities", 'OnOpenPageEvent', '', false, false)]
    local procedure HandleApprovalActivitiesPartOnOpenPage(var Rec: Record "Approvals Activities Cue");
    begin
        RunRegCheckNotification();
    end;

    [EventSubscriber(ObjectType::Page, Page::"Email Activities", 'OnOpenPageEvent', '', false, false)]
    local procedure HandleEmailActivitiesPartOnOpenPage();
    begin
        RunRegCheckNotification();
    end;
#endif

    [EventSubscriber(ObjectType::Page, Page::"My Customers", 'OnOpenPageEvent', '', false, false)]
    local procedure HandleMyCustomersPartOnOpenPage(var Rec: Record "My Customer");
    begin
        RunRegCheckNotification();
    end;

    [EventSubscriber(ObjectType::Page, Page::"My Items", 'OnOpenPageEvent', '', false, false)]
    local procedure HandleMyItemsPartOnOpenPage(var Rec: Record "My Item");
    begin
        RunRegCheckNotification();
    end;


#if V18_OR_HIGHER
    /// <summary>
    /// Indicate that the assisted setup has been completed.
    /// </summary>
    procedure SetStatusComplete()
    var
        lcuGuidedExperience: Codeunit "Guided Experience";
    begin
        lcuGuidedExperience.CompleteAssistedSetup(ObjectType::Page, Page::"LPM Setup Wizard");
    end;
#elif V16_OR_HIGHER
    procedure SetStatusComplete()
    var
        lcuAssistedSetup: Codeunit "Assisted Setup";
    begin
        lcuAssistedSetup.Complete(Page::"LPM Setup Wizard");
    end;
#elif V15_OR_HIGHER
    procedure SetStatusComplete()
    var
        lcuAssistedSetup: Codeunit "Assisted Setup";
    begin
        lcuAssistedSetup.Complete(GetAppID(), Page::"LPM Setup Wizard");
    end;
#endif

    procedure GetAppID(): Guid
    var
        currentExtension: ModuleInfo;
    begin
        NavApp.GetCurrentModuleInfo(currentExtension);
        exit(currentExtension.Id);
    end;

    /// <summary>
    /// Wrapper to create registration line and bypass IWX Common.
    /// This function will be replaced/not required when new registration framework implemented.
    /// </summary>
    procedure InitializeRegistrationLine()
    var
        lrecRegistrationHeader: Record "IWX Registration Header";
        lrecRegistrationLine: Record "IWX Registration Line";
        lcuData: Codeunit "IWX Data Setup";
    begin
        if not lrecRegistrationHeader.Get() then
            lcuData.InitializeRegistrationHeader(lrecRegistrationHeader);

        if not lrecRegistrationLine.Get(lrecRegistrationHeader."License ID", GetAppID()) then begin
            lrecRegistrationLine."Client ID" := lrecRegistrationHeader."License ID";
            lrecRegistrationLine."App ID" := GetAppID();
            lrecRegistrationLine.Name := 'License Plate Management';
            lcuData.GetAppLogo(lrecRegistrationLine, GetProductLogoURL());
            lrecRegistrationLine.Insert(true);
        end;
    end;

    procedure GetProductLogoURL(): Text;
    begin
        exit('https://app.dmsiworks.com/wp-content/uploads/License-Plating-240.png');
    end;


    var
        tcExpiryThresholdMsg: Label 'License Plate Management: Your subscription will expire soon';
        tcNotRegisteredQst: Label 'License Plate Management: You are currently using a demo, would you like to register?';
        tcBlockedErr: Label 'License Plate Management: There is a problem with your account';
        tcContactMsg: Label 'Contact Support';
        tcWizardLbl: Label 'You have not completed the License Plate Management setup wizard';
        tcStartLbl: Label 'Get Started';

#if V17_OR_LOWER
        tcSetUpAssistantNameLbl: Label 'Set up License Plate Management';
        tcAssistedSetupDescLbl: Label 'License Plate Management for Dynamics 365 Business Central';
#endif

        expiryThresholdGuidTok: Label '6118053d-15dd-48f2-b364-438b94f856f0', Locked = true;
        blockedGuidTok: Label 'a32d87b5-2cfb-4898-8a63-18d01de92d32', Locked = true;
        notRegisteredGuidTok: Label '857ee1da-0cd8-4e80-a449-d6d1136ad1a3', Locked = true;
        runSetupGuidTok: Label '596fcccc-5b25-4569-9084-3208a8acdb67', Locked = true;
}