codeunit 10038906 "LSC PLB Item Popup"
{
    SingleInstance = true;
    TableNo = "LSC POS Menu Line";

    var
        RetailAssistedSetupInUse: Boolean;

    trigger OnRun()
    begin
        if Rec.Command <> Format(Enum::"LSC POS Command"::CUSTOM) then
            exit;
        if Rec.Parameter = 'OVERRIDE' then
            OverridePLBItem();
    end;

    local procedure OverridePLBItem()
    var
        POSTransCodeunit: Codeunit "LSC POS Transaction";
    begin
        POSTransCodeunit.OverridePLBItem();
    end;

    internal procedure SetRetailCompanySetupInUse()
    begin
        RetailAssistedSetupInUse := true;
    end;

    internal procedure ClearRetailCompanySetupInUse()
    begin
        RetailAssistedSetupInUse := false;
    end;

    internal procedure GetRetailCompanySetupInUse(): Boolean
    begin
        exit(RetailAssistedSetupInUse);
    end;
}