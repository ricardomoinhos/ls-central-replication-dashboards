codeunit 10000823 "LSC POS Transaction Member"
{
    Access = internal;

    var
        AccountRec: Record "LSC Member Account" temporary;
        MemberRec: Record "LSC Member Contact" temporary;
        ClubRec: Record "LSC Member Club" temporary;
        CardRec: Record "LSC Membership Card" temporary;

        PosSession: Codeunit "LSC POS Session";
        PosFunctions: Codeunit "LSC POS Functions";
        POSTransactionEvents: Codeunit "LSC POS Transaction Events";

        __TSError: Label 'Trans. or Web Server Connection failed';

    procedure Init()
    begin
        Clear(AccountRec);
        Clear(MemberRec);
        Clear(ClubRec);
        Clear(CardRec);
    end;

    procedure GetAccountRec(): Record "LSC Member Account" temporary
    begin
        exit(AccountRec);
    end;

    procedure GetMemberRec(): Record "LSC Member Contact" temporary
    begin
        exit(MemberRec);
    end;

    procedure GetClubRec(): Record "LSC Member Club" temporary
    begin
        exit(ClubRec);
    end;

    procedure Set(pAccountRec: Record "LSC Member Account" temporary; pMemberRec: Record "LSC Member Contact" temporary)
    begin
        AccountRec := pAccountRec;
        MemberRec := pMemberRec;
    end;

    procedure LoadMemberInfo(pMemberCardNo: Text): Boolean
    var
        NotUsed: Text;
    begin
        exit(LoadMemberInfo(pMemberCardNo, NotUsed));
    end;

    procedure LoadMemberInfo(pMemberCardNo: Text; var pErrorTxt: Text): Boolean
    var
        NotUsed: Boolean;
    begin
        exit(LoadMemberInfo(pMemberCardNo, pErrorTxt, false, NotUsed))
    end;

    procedure LoadMemberInfo(pMemberCardNo: Text; var pErrorTxt: Text; pDoWebSync: Boolean): Boolean
    var
        NotUsed: Boolean;
    begin
        exit(LoadMemberInfo(pMemberCardNo, pErrorTxt, pDoWebSync, NotUsed))
    end;

    procedure LoadMemberInfo(pMemberCardNo: Text; var pErrorTxt: Text; pDoWebSync: Boolean; var pWebSyncError: Boolean): Boolean
    var
        ErrorText: Text;
        ResponseCode: Code[30];
        FailedToLoadMemberInfoErr: Label 'Failed to load %1 member information for %2 %3.';
        FailedToLoadMemberInfoWithErrorErr: Label 'Failed to load member information for %1 %2.\%3';
        IsHandled: Boolean;
    begin
        Init();
        pErrorTxt := '';
        pWebSyncError := false;

        if pMemberCardNo = '' then
            exit(true);

        if pDoWebSync then
            if not PosFunctions.GetMemberInfoForPos(pMemberCardNo, ResponseCode, ErrorText) then begin
                POSTransactionEvents.OnGetMemberInfoForPOSFailed(pMemberCardNo, ResponseCode, IsHandled);
                if not IsHandled then
                    if (ResponseCode = '0098') or (ResponseCode = '0099') then begin
                        pWebSyncError := true;
                        pErrorTxt := __TSError + ':' + ErrorText;
                    end
                    else
                        pErrorTxt := StrSubstNo(FailedToLoadMemberInfoWithErrorErr, CardRec.TableCaption, pMemberCardNo, ErrorText);
                exit(false);
            end;

        if not PosFunctions.GetMemberClubInfo(ClubRec) then begin
            pErrorTxt := StrSubstNo(FailedToLoadMemberInfoErr, ClubRec.TableCaption, CardRec.TableCaption, pMemberCardNo);
            Init();
            exit(false);
        end;
        if not PosFunctions.GetMemberAccountInfo(AccountRec) then begin
            pErrorTxt := StrSubstNo(FailedToLoadMemberInfoErr, AccountRec.TableCaption, CardRec.TableCaption, pMemberCardNo);
            Init();
            exit(false);
        end;
        if not PosFunctions.GetCurrMemberContact(MemberRec) then begin
            pErrorTxt := StrSubstNo(FailedToLoadMemberInfoErr, MemberRec.TableCaption, CardRec.TableCaption, pMemberCardNo);
            Init();
            exit(false);
        end;
        if not PosFunctions.GetMemberShipCardInfo(CardRec) then begin
            ErrorText := StrSubstNo(FailedToLoadMemberInfoErr, ' ', CardRec.TableCaption, CardRec."Card No.");
            Init();
            exit(false);
        end;

        exit(true);
    end;

    procedure ContactNo(): Text
    begin
        exit(MemberRec."Contact No.");
    end;

    procedure ContactName(): Text
    begin
        exit(MemberRec.Name);
    end;

    procedure ContactName2(): Text
    begin
        exit(MemberRec."Name 2");
    end;

    procedure DateOfBirth(): Text
    begin
        exit(Format(MemberRec."Date of Birth"));
    end;

    procedure Address(): Text
    begin
        exit(MemberRec.Address);
    end;

    procedure Address2(): Text
    begin
        exit(MemberRec."Address 2");
    end;

    procedure PostCode(): Text
    begin
        exit(MemberRec."Post Code");
    end;

    procedure City(): Text
    begin

        exit(MemberRec.City);
    end;

    procedure Country(): Text
    begin
        exit(MemberRec."Country/Region Code");
    end;

    procedure Phone(): Text
    begin
        exit(Format(MemberRec."Phone No."));
    end;

    procedure MobilePhone(): Text
    begin
        exit(Format(MemberRec."Mobile Phone No."));
    end;

    procedure EMail(): Text
    begin
        exit(MemberRec."E-Mail");
    end;

    procedure Image() obsoleteImgUrl: Text
    begin
        exit(PosSession.AddWebTemplateImage(MemberRec.RecordId, 'MemberContact_Image'));
    end;

    procedure MemberSince(): Text[50]
    begin
        exit(Format(MemberRec."Created Date"));
    end;

    procedure AccountNo(): Text
    begin
        exit(AccountRec."No.")
    end;

    procedure AccountScheme(): Text
    begin
        exit(MemberRec."Scheme Code");
    end;

    procedure AccountClub(): Text[50]
    begin
        exit(AccountRec."Club Code")
    end;

    procedure PointBalance(): Text
    var
        PosFunc: Codeunit "LSC POS Functions";
    begin
        if MemberRec."Contact No." = '' then
            exit('');

        exit(Format(PosFunc.GetMemberPointBalance));
    end;

    procedure TotalSales(): Text[50]
    begin
        if MemberRec."Contact No." = '' then
            exit('');

        exit(Format(AccountRec.TotalSalesInt))
    end;

    procedure CurrYearSales(): Text[50]
    begin
        if MemberRec."Contact No." = '' then
            exit('');

        exit(Format(AccountRec."Sales Current Year"))
    end;

    procedure LastSale(): Text
    begin
        if MemberRec."Contact No." = '' then
            exit('');

        exit(Format(AccountRec."Last Sales Date"))
    end;

    procedure PointsExpireInPeriod(): Text
    begin
        if MemberRec."Contact No." = '' then
            exit('');

        exit(Format(AccountRec.ExpirationinPeriodInt));
    end;

    procedure TotalRemainingPointsInt(): Decimal
    begin
        exit(AccountRec.TotalRemainingPointsInt);
    end;

    procedure PointTenderType(): Code[10]
    begin
        exit(ClubRec."Member Point Tender Type");
    end;

    procedure Club(): Code[10]
    begin
        exit(ClubRec.Code);
    end;

    procedure CardClubCode(): Code[10]
    begin
        exit(CardRec."Club Code")
    end;

    procedure CardSchemeCode(): Code[10]
    begin
        exit(CardRec."Scheme Code")
    end;

    procedure PublishedOffers(pMemberCardNo: Text): Text
    var
        PublishedOfferTemp: Record "LSC Published Offer" temporary;
        PosTransaction: Codeunit "LSC POS Transaction";
        WebFunctions: Codeunit "LSC POS Web Functions";
        JsonUtil: Codeunit "LSC POS JSON Util";
        ResponseCode: Code[30];
        JsonResponse: Text;
        ErrorText: Text;
    begin
        if MemberRec."Contact No." <> '' then begin
            if PosFunctions.GetMemberDirectMarketingInfoForPos(pMemberCardNo, ResponseCode, ErrorText) then begin
                if PosFunctions.GetMemberPublishedOffers(PublishedOfferTemp) then begin
                    if WebFunctions.MemberPublishedOffers2JSONArray(JsonUtil, PublishedOfferTemp) = '' then begin
                        JsonResponse := JsonUtil.GetJSon();
                    end;
                    exit(JsonResponse);
                end;
            end else begin
                PosTransaction.ErrorBeep(ErrorText);
                exit(ErrorText);
            end;
        end;

        exit('');
    end;

    procedure CouponList(): Text
    var
        MemberCouponBuffer: Record "LSC Member Coupon Buffer" temporary;
        WebFunctions: Codeunit "LSC POS Web Functions";
        JsonUtil: Codeunit "LSC POS JSON Util";
        JsonResponse: Text;
    begin
        if MemberRec."Contact No." <> '' then begin
            if PosFunctions.GetMemberCoupons(MemberCouponBuffer) then begin
                if WebFunctions.MemberCouponList2JSONArray(JsonUtil, MemberCouponBuffer) = '' then begin
                    JsonResponse := JsonUtil.GetJSon();
                end;
                exit(JsonResponse);
            end;
        end;

        exit('');
    end;

    procedure SalesHistory(): Text
    var
        MemberSalesEntryTemp: Record "LSC Member Sales Entry" temporary;
        WebFunctions: Codeunit "LSC POS Web Functions";
        JsonUtil: Codeunit "LSC POS JSON Util";
        JsonResponse: Text;
    begin
        if MemberRec."Contact No." <> '' then begin
            if PosFunctions.GetMemberSalesHistory(MemberSalesEntryTemp) then begin
                if WebFunctions.MemberSalesHistory2JSONArray(JsonUtil, MemberSalesEntryTemp) = '' then begin
                    JsonResponse := JsonUtil.GetJSon();
                end;
                exit(JsonResponse);
            end;
        end;

        exit('');
    end;

    procedure DisplayMessageOnPOS(): Boolean
    begin
        exit(ClubRec."Display Message on POS" = ClubRec."Display Message on POS"::Yes);
    end;

    procedure LinkedToCustomerNo(): Code[20]
    begin
        exit(AccountRec."Linked To Customer No.");
    end;

    #region CAPTIONS
    procedure ContactName_Caption(): Text[50]
    var
        ContactNameMsg: Label 'Contact Name';
    begin
        if MemberRec."Contact No." <> '' then
            exit(ContactNameMsg)
        else
            exit('');
    end;

    procedure AccountScheme_Caption(): Text[50]
    var
        AccSchemeCodeMsg: Label 'Account Scheme Code';
    begin
        if MemberRec."Contact No." <> '' then
            exit(AccSchemeCodeMsg)
        else
            exit('');
    end;

    procedure AccountClub_Caption(): Text[50]
    var
        AccClubMsg: Label 'Account Club';
    begin
        if MemberRec."Contact No." <> '' then
            exit(AccClubMsg)
        else
            exit('');
    end;

    procedure AccountPointBalance_Caption(): Text
    var
        AccPointBalanceMsg: Label 'Account Point Balance';
    begin
        if MemberRec."Contact No." <> '' then
            exit(AccPointBalanceMsg)
        else
            exit('');
    end;

    procedure ContactAddress_Caption(): Text[50]
    var
        ContactAddrMsg: Label 'Contact Address';
    begin
        if MemberRec."Contact No." <> '' then
            exit(ContactAddrMsg)
        else
            exit('');
    end;

    procedure ContactAddress2_Caption(): Text
    var
        ContactAddr2Msg: Label 'Contact Address 2';
    begin
        if MemberRec."Contact No." <> '' then
            exit(ContactAddr2Msg)
        else
            exit('');
    end;

    procedure ContactPostCode_Caption(): Text[50]
    var
        ContactPostCodeMsg: Label 'Contact Post Code';
    begin
        if MemberRec."Contact No." <> '' then
            exit(ContactPostCodeMsg)
        else
            exit('');
    end;

    procedure ContactCity_Caption(): Text[50]
    var
        ContactCityMsg: Label 'Contact City';
    begin
        if MemberRec."Contact No." <> '' then
            exit(ContactCityMsg)
        else
            exit('');
    end;

    procedure ContactCountry_Caption(): Text
    var
        ContactCountryMsg: Label 'Contact Country';
    begin
        if MemberRec."Contact No." <> '' then
            exit(ContactCountryMsg)
        else
            exit('');
    end;

    procedure ContactEMail_Caption(): Text
    var
        ContactEmailAddressMsg: Label 'Contact Email Address';
    begin
        if MemberRec."Contact No." <> '' then
            exit(ContactEmailAddressMsg)
        else
            exit('');
    end;

    procedure ContactDateOfBirth_Caption(): Text[50]
    var
        ContactDateOfBirth: Label 'Contact Date of Birth';
    begin
        if MemberRec."Contact No." <> '' then
            exit(ContactDateOfBirth)
        else
            exit('');
    end;

    procedure ContactMemberSince_Caption(): Text[50]
    var
        ContactMemberSinceMsg: Label 'Contact Member Since';
    begin
        if MemberRec."Contact No." <> '' then
            exit(ContactMemberSinceMsg)
        else
            exit('');
    end;

    procedure AccountNo_Caption(): Text
    var
        AccNoMsg: Label 'Account No.';
    begin
        if MemberRec."Contact No." <> '' then
            exit(AccNoMsg)
        else
            exit('');
    end;

    procedure ContactNo_Caption(): Text
    var
        ContactNoMsg: Label 'Contact No.';
    begin
        if MemberRec."Contact No." <> '' then
            exit(ContactNoMsg)
        else
            exit('');
    end;

    procedure AccountTotalSales_Caption(): Text[50]
    var
        AccTotalSalesMsg: Label 'Account Total Sales';
    begin
        if MemberRec."Contact No." <> '' then
            exit(AccTotalSalesMsg)
        else
            exit('');
    end;

    procedure AccountCurrYearSales_Caption(): Text[50]
    var
        AccSalesCurrYear: Label 'Account Sales Current Year';
    begin
        if MemberRec."Contact No." <> '' then
            exit(AccSalesCurrYear)
        else
            exit('');
    end;

    procedure AccountLastSale_Caption(): Text
    var
        AccDateOfLastSaleMsg: Label 'Account Date of Last Sale';
    begin
        if MemberRec."Contact No." <> '' then
            exit(AccDateOfLastSaleMsg)
        else
            exit('');
    end;
    #endregion

    internal procedure UpdateContext(pMemberCardNo: Text)
    begin
        PosSession.SetValue("LSC POS Tag"::"MemberContactName", ContactName);
        PosSession.SetValue("LSC POS Tag"::"MemberAccountScheme", AccountScheme);
        PosSession.SetValue("LSC POS Tag"::"MemberAccountClub", AccountClub);
        PosSession.SetValue("LSC POS Tag"::"MemberAccountPointBalance", PointBalance);
        PosSession.SetValue("LSC POS Tag"::"MemberContactAddress", Address);
        PosSession.SetValue("LSC POS Tag"::"MemberContactAddress2", Address2);
        PosSession.SetValue("LSC POS Tag"::"MemberContactPostCode", PostCode);
        PosSession.SetValue("LSC POS Tag"::"MemberContactCity", City);
        PosSession.SetValue("LSC POS Tag"::"MemberContactCountry", Country);
        PosSession.SetValue("LSC POS Tag"::"MemberContactDateOfBirth", DateOfBirth);
        PosSession.SetValue("LSC POS Tag"::"MemberContactMemberSince", MemberSince);
        PosSession.SetValue("LSC POS Tag"::"MemberContactEmail", EMail);
        PosSession.SetValue("LSC POS Tag"::"MemberAccountNo", AccountNo);
        PosSession.SetValue("LSC POS Tag"::"MemberContactNo", ContactNo);
        PosSession.SetValue("LSC POS Tag"::"MemberAccountTotalSales", TotalSales);
        PosSession.SetValue("LSC POS Tag"::"MemberAccountCurrYearSales", CurrYearSales);
        PosSession.SetValue("LSC POS Tag"::"MemberAccountLastSale", LastSale);
        PosSession.SetValue("LSC POS Tag"::"MemberAccCurrYearSales_Capt", AccountCurrYearSales_Caption);
        PosSession.SetValue("LSC POS Tag"::"MemberAccountClub_Capt", AccountClub_Caption);
        PosSession.SetValue("LSC POS Tag"::"MemberAccountLastSale_Capt", AccountLastSale_Caption);
        PosSession.SetValue("LSC POS Tag"::"MemberAccountNo_Capt", AccountNo_Caption);
        PosSession.SetValue("LSC POS Tag"::"MemberAccountPointBal_Capt", AccountPointBalance_Caption);
        PosSession.SetValue("LSC POS Tag"::"MemberAccountScheme_Capt", AccountScheme_Caption);
        PosSession.SetValue("LSC POS Tag"::"MemberAccTotalSales_Capt", AccountTotalSales_Caption);
        PosSession.SetValue("LSC POS Tag"::"MemberContactAddress_Capt", ContactAddress_Caption);
        PosSession.SetValue("LSC POS Tag"::"MemberContactAddress2_Capt", ContactAddress2_Caption);
        PosSession.SetValue("LSC POS Tag"::"MemberContactCity_Capt", ContactCity_Caption);
        PosSession.SetValue("LSC POS Tag"::"MemberContactCountry_Capt", ContactCountry_Caption);
        PosSession.SetValue("LSC POS Tag"::"MemberContactEmail_Capt", ContactEMail_Caption);
        PosSession.SetValue("LSC POS Tag"::"MemberContactName_Capt", ContactName_Caption);
        PosSession.SetValue("LSC POS Tag"::"MemberContactNo_Capt", ContactNo_Caption);
        PosSession.SetValue("LSC POS Tag"::"MemberContactPostCode_Capt", ContactPostCode_Caption);
        PosSession.SetValue("LSC POS Tag"::"MemberContDateOfBirth_Capt", ContactDateOfBirth_Caption);
        PosSession.SetValue("LSC POS Tag"::"MemberContMemberSince_Capt", ContactMemberSince_Caption);
        PosSession.SetValue("LSC POS Tag"::"MemberContact_Image", Image);
        PosSession.SetValue("LSC POS Tag"::"MemberContactPhone", Phone);
        PosSession.SetValue("LSC POS Tag"::"MemberContactMobilePhone", MobilePhone);
        PosSession.SetValue("LSC POS Tag"::"MEMBERCONTPOINTSEXPINPERIOD", PointsExpireInPeriod);
        PosSession.SetValue("LSC POS Tag"::"MemberContactPublishedOffers", PublishedOffers(pMemberCardNo));
        PosSession.SetValue("LSC POS Tag"::"MemberContactCouponList", CouponList);
        PosSession.SetValue("LSC POS Tag"::"MemberSalesHistory", SalesHistory);
    end;

    procedure CheckMemberCard(var Rec: Record "LSC POS Transaction"; var ErrorText: Text): Boolean
    var
        POSTransLine2: Record "LSC POS Trans. Line";
        DT: Record "LSC POS Trans. Per. Disc. Type";
        OfferPosCalc: Record "LSC Offer Pos Calculation";
        lPOSTransPerDisc: Record "LSC POS Trans. Per. Disc. Type";
        PosPrice: Codeunit "LSC POS Price Utility";
        PosOfferExt: Codeunit "LSC POS Offer Ext. Utility";
        DealPricingFunctions: Codeunit "LSC Deal Pricing Functions";
        NewPriceGroup: Code[10];
        NewCustDiscGroup: Code[20];
        lPrice: Decimal;
        lQty: Decimal;
        OfferType: Enum "LSC POS Trans. Per. Disc. Type";
        RecalcNeeded: Boolean;
        PromotionForMember: Boolean;
        Handled: Boolean;
    begin
        lPOSTransPerDisc.Reset;
        lPOSTransPerDisc.SetRange("Receipt No.", REC."Receipt No.");
        lPOSTransPerDisc.SetRange(lPOSTransPerDisc.DiscType, lPOSTransPerDisc.DiscType::Coupon);
        PosFunctions.PosTransDiscSetTableFilter(1, lPOSTransPerDisc);
        PosFunctions.PosTransDiscDeleteAllRec(1);

        POSTransactionEvents.OnBeforeCheckMemberCard(REC, AccountRec, MemberRec, CardRec, Handled);
        if Handled then
            exit(false);

        Rec."Starting Point Balance" := TotalRemainingPointsInt;

        NewCustDiscGroup := PosFunctions.GetMemberCustomerDiscountGroup;
        NewPriceGroup := PosFunctions.GetMemberPriceGroup;

        if (LinkedToCustomerNo <> '') and (REC."Customer Disc. Group" <> '') then
            NewCustDiscGroup := REC."Customer Disc. Group";
        if NewCustDiscGroup <> REC."Customer Disc. Group" then begin
            RecalcNeeded := true;
            REC."Customer Disc. Group" := NewCustDiscGroup;
        end;
        if NewPriceGroup <> Rec."Member Price Group" then begin
            RecalcNeeded := true;
            REC."Member Price Group" := NewPriceGroup;
        end;
        REC."Member Card No." := CardRec."Card No.";
        REC.Modify;

        PromotionForMember := PosPrice.IsPromotionForMember(REC);
        POSTransLine2.Reset;
        POSTransLine2.SetRange("Receipt No.", REC."Receipt No.");
        POSTransLine2.SetRange("Entry Type", POSTransLine2."Entry Type"::Item);
        if POSTransLine2.FindSet then
            repeat
                if PromotionForMember or RecalcNeeded then begin
                    lPrice := POSTransLine2.Price;
                    lQty := POSTransLine2.Quantity;
                    PosPrice.InsertTransDiscPercent(POSTransLine2, 0, DT.DiscType::"Periodic Disc.", '');
                    if not POSTransLine2."Deal Line" then
                        POSTransLine2."Promotion No." := '';
                    POSTransLine2."Mix & Match Line No." := 0;
                    PosPrice.InsertTransDiscAmount(POSTransLine2, 0, DT.DiscType::"Periodic Disc.", '');
                    Clear(OfferPosCalc);
                    OfferPosCalc.SetRange("Receipt No.", POSTransLine2."Receipt No.");
                    OfferPosCalc.SetRange("Trans. Line No.", POSTransLine2."Line No.");
                    OfferPosCalc.DeleteAll;
                    if not (POSTransLine2."Price Change" or POSTransLine2."System-Unchangable Price") then
                        PosPrice.CalcPrice(POSTransLine2, false);
                    if (lPrice <> POSTransLine2.Price) then begin
                        POSTransLine2.Validate(Quantity, lQty);
                        POSTransLine2.Modify(true);
                    end;
                end;
                PosFunctions.ClearPosTransLineOffers(POSTransLine2);
                PosPrice.InitGlobals(POSTransLine2, true);
                PosPrice.FindPeriodicOffers(POSTransLine2);
                PosFunctions.AddPosTransLineOffers(POSTransLine2);
                POSTransLine2.Modify(true);
            until POSTransLine2.Next = 0;

        InsertMemberLine(REC);
        PosPrice.CalcPeriodicOnTotalPressed(REC);
        POSTransactionEvents.OnCalcPeriodicBeforeRecalc(REC, POSTransLine2);
        DealPricingFunctions.DealPricing_UpdatePricingForDealsInTransaction(REC);
        PosFunctions.RecalcSlip(REC);
        if not PosFunctions.IsInPaymentState then
            PosOfferExt.ReCalcLinePreTotal(REC);
        if PosFunctions.IsInPaymentState then
            PosOfferExt.ReCalcOfferSeq(REC, OfferType::"Total Discount");
        Commit;

        exit(true);
    end;

    procedure OnAfterCheckMemberCard(var Rec: Record "LSC POS Transaction")
    begin
        POSTransactionEvents.OnAfterCheckMemberCardV2(REC, AccountRec, MemberRec, CardRec);
    end;

    local procedure InsertMemberLine(var Rec: Record "LSC POS Transaction")
    var
        POSTransLine: Record "LSC POS Trans. Line";
        OldMemberLine: Record "LSC POS Trans. Line";
        LastLineNo: Integer;
        IsHandled: Boolean;
        MemberMsg: Label 'Member:';
    begin
        POSTransactionEvents.OnBeforeInsertMemberLine(Rec, IsHandled);
        If IsHandled then
            exit;

        OldMemberLine.SetRange("Receipt No.", REC."Receipt No.");
        OldMemberLine.SetRange("Entry Type", OldMemberLine."Entry Type"::FreeText);
        OldMemberLine.SetRange("Text Type", OldMemberLine."Text Type"::"Member Text");
        OldMemberLine.SetRange("Entry Status", OldMemberLine."Entry Status"::" ");
        if OldMemberLine.FindFirst then begin
            OldMemberLine.Description := CopyStr(MemberMsg + ' ' + ContactName(), 1, MaxStrLen(POSTransLine.Description));
            POSTransactionEvents.OnAfterGetMemberDescription(OldMemberLine, ContactName(), Rec."Member Card No.");
            OldMemberLine.Modify;
            exit;
        end;

        POSTransLine.SetRange("Receipt No.", REC."Receipt No.");
        if POSTransLine.FindLast then
            LastLineNo := POSTransLine."Line No."
        else
            LastLineNo := -500; //To allow member card info to be inserted before handling Customer Orders.

        Clear(POSTransLine);
        POSTransLine."Receipt No." := REC."Receipt No.";
        POSTransLine."Store No." := REC."Store No.";
        POSTransLine."POS Terminal No." := REC."POS Terminal No.";
        POSTransLine."Line No." := LastLineNo + 10000;
        POSTransLine."Parent Line" := POSTransLine."Line No.";
        POSTransLine.Description := CopyStr(MemberMsg + ' ' + ContactName(), 1, MaxStrLen(POSTransLine.Description));
        POSTransactionEvents.OnAfterGetMemberDescription(POSTransLine, ContactName(), Rec."Member Card No.");
        POSTransLine."Entry Type" := POSTransLine."Entry Type"::FreeText;
        POSTransLine."Text Type" := POSTransLine."Text Type"::"Member Text";
        POSTransLine."Entry Status" := POSTransLine."Entry Status"::" ";
        POSTransLine.Quantity := 0;
        POSTransLine.Price := 0;
        POSTransLine.Insert(true);
        LastLineNo := 0;
    end;

    procedure OnBeforeTender(var REC: Record "LSC POS Transaction"; var TenderType: Record "LSC Tender Type")
    begin
        POSTransactionEvents.OnBeforeMemberTender(MemberRec, TenderType, REC);
    end;

    procedure CheckPointBalance(var REC: Record "LSC POS Transaction"; var LineRec: Record "LSC POS Trans. Line"; var CurrInput: Text): Boolean
    var
        ServiceLocator: Codeunit "LSC Service Locator";
        PointsInTransaction: Decimal;
        IsHandled: Boolean;
        MemberPointBalanceMsg: Label 'Member Points Balance is not enough.';
    begin
        POSTransactionEvents.OnBeforeCheckPointBalance(Rec, LineRec, CurrInput, IsHandled);
        if IsHandled then
            exit(true);

        if REC."Sale Is Return Sale" then
            exit(true);

        PointsInTransaction := PosFunctions.PointsUsedInTransaction(0);
        if PointsInTransaction = 0 then
            exit(true);

        if PointsInTransaction <= PosFunctions.GetMemberPointBalance() then
            exit(true);

        ServiceLocator.TransactionGui.ErrorBeep(MemberPointBalanceMsg);
    end;
}
