codeunit 99001451 "LSC Actions Management"
{
    Permissions = TableData "LSC Initial Entry No. in Loc." = rimd,
                  TableData "LSC Table Specific Infocode" = rimd,
                  TableData "LSC Trans. Inventory Entry" = rimd,
                  TableData "LSC Actions" = rim;

    var
        "Actions": Record "LSC Actions";
        Actions2: Record "LSC Actions";
        LocDistributionList: Record "LSC Distribution List";
        AllObj: Record AllObj;
        SchedulerSetup: Record "LSC Scheduler Setup";
        RetailSetup: Record "LSC Retail Setup";
        BoUtil: Codeunit "LSC BO Utils";
        SessionDataExchangeUtility: Codeunit "LSC Session Data Exchange Util";
        SessionKeyValues: Codeunit "LSC Session Key Values";
        CalledByTableTrigger: Boolean;
        PreactionMgt: Codeunit "LSC Preaction Mgt";

    internal procedure CreateActions(TableNo: Integer; "Key": Text[250]; Type: Integer; LinkDown: Boolean; AdditionalValues: Text[500]): Integer
    var
        TableDistributionSetup: Record "LSC Table Distribution Setup";
        Counters: Record "LSC Action Counters";
        Preaction: Record "LSC Preaction";
        DistList: Record "LSC Distribution List";
    begin
        if not SchedulerSetup.Get() then
            exit;

        // Historical note DK - the CreateActions has used the following types - 1 for insert, 0 for modify and 2
        // for delete. This can cause some confusion since the RecordRef functinos use 0 for insert, 1 for modify
        // and 2 for delete. The code takes care of this conversion, but we still need to be aware of this.

        if (TableDistributionSetup.Get(TableNo, 0)) and (Type = 1) and (not LinkDown) then
            if TableDistributionSetup."Distribution Type" = TableDistributionSetup."Distribution Type"::"All Default" then
                InsertAllDistribution(TableNo, Key, '');

        TableDistributionSetup.SetRange("Table ID", TableNo);
        if TableDistributionSetup.FindFirst() then
            if TableDistributionSetup."No Actions" then
                exit;
        if (TableDistributionSetup.Count = 1) and (TableDistributionSetup."Actions on Linked Tables") then begin
            LinkDown :=
              ((TableDistributionSetup."Linked Actions on Insert") and (Type = 1)) or
              ((TableDistributionSetup."Linked Actions on Modify") and (Type = 0)) or
              ((TableDistributionSetup."Linked Actions on Delete") and (Type = 2));
        end;

        if not Counters.Get() then
            Counters.Insert();

        if not SchedulerSetup."Replicate using Preactions" then begin
            if (Type <> 2) then begin      // Type = 2 is a delete action
                Preaction.SetCurrentKey("Table No.", Key, Action);
                Preaction.SetRange("Table No.", TableNo);
                Preaction.SetRange(Key, Key);
                Preaction.SetFilter(Action, '<>%1', Preaction.Action::Delete);
                Preaction.SetFilter("Entry No.", '>%1', Counters."Action Selected");
                if Preaction.FindFirst() then
                    exit(Preaction."Entry No.");
            end else begin
                Preaction.SetCurrentKey("Table No.", Key, Action);
                Preaction.SetRange("Table No.", TableNo);
                Preaction.SetRange(Key, Key);
                Preaction.SetFilter(Action, '<>%1', Preaction.Action::Delete);
                Preaction.SetFilter("Entry No.", '>%1', Counters."Action Selected");
                if Preaction.FindSet() then
                    repeat
                        Preaction.Delete();
                    until Preaction.Next() = 0;
            end;
        end;

        if (Type = 2) then begin   // Type = 2 is a delete action
            DistList.SetRange("Table ID", TableNo);
            DistList.SetRange(Value, BoUtil.ConvertActKeyToTableKey(Key));
            DistList.DeleteAll();
        end;

        Preaction.Reset();
        Preaction.SetCurrentKey(Preaction."Entry No.");
        Preaction."xTable No." := TableNo;  // this will be removed in a future version.
        Preaction."Table No." := TableNo;
        Preaction.Key := Key;
        Preaction."Additional Values" := AdditionalValues;

        case Type of
            1:
                Preaction.Action := Preaction.Action::Insert;
            0:
                Preaction.Action := Preaction.Action::Update;
            2:
                Preaction.Action := Preaction.Action::Delete;
        end;

        Preaction.Date := Today;
        Preaction.Time := Time;
        Preaction."Link Down" := LinkDown;
        Preaction."User ID" := UserId;

        if SchedulerSetup."Replicate using Preactions" then
            Preaction."Location Group Filter" := GetNoFilter();

        Preaction.Insert();
        exit(Preaction."Entry No.");
    end;

    internal procedure CreateActionsEXP(TableNo: Integer; "Key": Text[250]; PosKey: Text[250]; Type: Integer; Master: Integer; MasterKey: Text[250]): Integer
    begin
        // This function is not used anymore. It is present for compatibility reasons.
        CreateActions(TableNo, Key, Type, false, '');
    end;

    internal procedure CreateLocActions(TableNo: Integer; "Key": Text[250]; PosKey: Text[250]; LocCode: Code[10])
    begin
        Actions.Init();
        Actions.LockTable();
        Actions.Action := Actions.Action::"Update-Add";
        Actions."Table No." := TableNo;
        Actions.Key := Key;
        Actions.Date := Today;
        Actions.Time := Time;
        Actions."User ID" := UserId;
        Actions."Entry No." := NextEntry();
        Actions."Location Group Filter" := BoUtil.CombineTableKey(2, LocCode, LocCode, '', '', '');
        Actions.Insert();
    end;

    internal procedure NewDistribution(LocDistributionList2: Record "LSC Distribution List")
    begin
        Actions.Init();
        Actions.LockTable();
        Actions.Action := Actions.Action::"Update-Add";
        Actions."Table No." := LocDistributionList2."Table ID";
        Actions.Key := BoUtil.ConvertTableKeyToActKey(LocDistributionList2.Value);
        Actions.Date := Today;
        Actions.Time := Time;
        Actions."User ID" := UserId;
        Actions."Entry No." := NextEntry();
        Actions."Location Group Filter" :=
          BoUtil.CombineTableKey(2, LocDistributionList2."Group Code", LocDistributionList2."Subgroup Code",
            '', '', '');
        Actions.Insert();

        Actions.Init();
        Actions.Action := Actions.Action::"Update-Add";
        Actions."Table No." := Database::"LSC Distribution List";
        Actions.Key :=
          BoUtil.CombineActKey(
            4, BoUtil.IntegerToStr(LocDistributionList2."Table ID"), LocDistributionList2.Value,
            LocDistributionList2."Group Code", LocDistributionList2."Subgroup Code", '');
        Actions.Date := Today;
        Actions.Time := Time;
        Actions."User ID" := UserId;
        Actions."Entry No." := NextEntry();
        Actions."Location Group Filter" :=
          BoUtil.CombineTableKey(2, LocDistributionList2."Group Code", LocDistributionList2."Subgroup Code",
            '', '', '');
        Actions.Insert();
    end;

    internal procedure DeleteDistribution(LocDistributionList2: Record "LSC Distribution List")
    begin
        Actions.Init();
        Actions.LockTable();
        Actions.Action := Actions.Action::Delete;
        Actions."Table No." := LocDistributionList2."Table ID";
        Actions.Key := BoUtil.ConvertTableKeyToActKey(LocDistributionList2.Value);
        Actions.Date := Today;
        Actions.Time := Time;
        Actions."User ID" := UserId;
        Actions."Entry No." := NextEntry();
        Actions."Location Group Filter" :=
          BoUtil.CombineTableKey(2, LocDistributionList2."Group Code", LocDistributionList2."Subgroup Code",
            '', '', '');
        Actions.Insert();

        Actions.Action := Actions.Action::"Update-Add";

        LocDistributionList.Reset();
        LocDistributionList.SetRange("Table ID", LocDistributionList2."Table ID");
        LocDistributionList.SetRange(Value, LocDistributionList2.Value);
        if LocDistributionList.FindSet() then
            repeat
                if (LocDistributionList2."Group Code" <> LocDistributionList."Group Code") or
                   (LocDistributionList2."Subgroup Code" <> LocDistributionList."Subgroup Code")
                then begin
                    Actions."Entry No." := NextEntry();
                    Actions."Location Group Filter" :=
                      BoUtil.CombineTableKey(2, LocDistributionList."Group Code", LocDistributionList."Subgroup Code",
                        '', '', '');
                    Actions.Insert();
                end;
            until LocDistributionList.Next() = 0;

        Actions.Init();
        Actions.LockTable();
        Actions.Action := Actions.Action::Delete;
        Actions."Table No." := Database::"LSC Distribution List";
        Actions.Key :=
          BoUtil.CombineActKey(
            4, BoUtil.IntegerToStr(LocDistributionList2."Table ID"), LocDistributionList2.Value,
            LocDistributionList2."Group Code", LocDistributionList2."Subgroup Code", '');
        Actions.Date := Today;
        Actions.Time := Time;
        Actions."User ID" := UserId;
        Actions."Entry No." := NextEntry();
        Actions."Location Group Filter" :=
          BoUtil.CombineTableKey(2, LocDistributionList2."Group Code", LocDistributionList2."Subgroup Code",
            '', '', '');
        Actions.Insert();
    end;

    internal procedure RenameDistribution(TableID: Integer; OldValue: Text[100]; NewValue: Text[100])
    var
        OldLocDistributionList: Record "LSC Distribution List";
        NewLocDistributionList: Record "LSC Distribution List";
        Text000: Label 'Renaming the %1 record %2 could cause problems with data exchange.\';
        Text001: Label 'Do you still want to rename the record?';
        Text002: Label 'The record was not renamed.';
    begin
        if not SchedulerSetup.Get() then
            exit;

        // valid only if table is not master of any others
        AllObj.Get(AllObj."Object Type"::Table, TableID);
        if not Confirm(Text000 + Text001, false, AllObj."Object Name", OldValue) then
            Error(Text002);

        OldLocDistributionList.Reset();
        OldLocDistributionList.SetRange("Table ID", TableID);
        OldLocDistributionList.SetRange(Value, OldValue);
        if OldLocDistributionList.FindSet() then
            repeat
                NewLocDistributionList.Init();
                NewLocDistributionList.TransferFields(OldLocDistributionList);
                NewLocDistributionList.Value := NewValue;
                if NewLocDistributionList.Insert() then begin
                    NewDistribution(NewLocDistributionList);
                end;
                DeleteDistribution(OldLocDistributionList);
                OldLocDistributionList.Delete();
            until OldLocDistributionList.Next() = 0;
    end;

    internal procedure ErrorOnRename(TotalError: Boolean; TableID: Integer; OldValue: Text[100])
    var
        DistributionSetup: Record "LSC Table Distribution Setup";
        DistributionSetup2: Record "LSC Table Distribution Setup";
        IsHandled: Boolean;
        Text003: Label 'You cannot rename the record because the table (%1) has a %2 %3 and not %4';
        Text004: Label 'You cannot rename the record because the table (%1) is a Master Distribution Table';
        Text013: Label 'Renaming of records is not allowed.';
    begin
        OnBeforeErrorOnReName(IsHandled);
        IF IsHandled then
            exit;

        if not SchedulerSetup.Get() then
            exit;

        if not RetailSetup.Get() then
            exit;

        if not RetailSetup."Allow Rename" then
            Error(Text013);

        DistributionSetup.SetRange("Table ID", TableID);
        if DistributionSetup.FindSet() then
            repeat
                AllObj.Get(1, TableID);
                if DistributionSetup."Distribution Type" <> DistributionSetup."Distribution Type"::"No Distribution" then begin
                    DistributionSetup2."Distribution Type" := DistributionSetup2."Distribution Type"::"No Distribution";
                    Error(
                      Text003,
                      AllObj."Object Name", DistributionSetup.FieldCaption("Distribution Type"),
                      DistributionSetup."Distribution Type", DistributionSetup2."Distribution Type");
                end;
            until DistributionSetup.Next() = 0;

        DistributionSetup.Reset();
        DistributionSetup.SetRange("Master Table ID", TableID);
        if DistributionSetup.FindSet() then
            repeat
                AllObj.Get(1, TableID);
                Error(Text004, AllObj."Object Name");
            until DistributionSetup.Next() = 0;
    end;

    internal procedure InsertAllDistribution(TableNo: Integer; "Key": Text[250]; PosKey: Text[250]): Boolean
    var
        MasterLocDistributionList: Record "LSC Distribution List";
        NewLocDistributionList: Record "LSC Distribution List";
        NoFilterLocGrType: Code[10];
        NoFilterLocGr: Code[10];
        NoFilterStoreGr: Code[10];
        valueTxt: Text[250];
    begin
        valueTxt := BoUtil.ConvertActKeyToTableKey(Key);

        MasterLocDistributionList.SetRange("Table ID", TableNo);
        MasterLocDistributionList.SetRange(Value, valueTxt);
        if not MasterLocDistributionList.IsEmpty() then
            exit(true);

        if NoFilterExists(NoFilterLocGrType, NoFilterLocGr, NoFilterStoreGr) then begin
            NewLocDistributionList.Init();
            NewLocDistributionList."Table ID" := TableNo;
            NewLocDistributionList.Value := BoUtil.ConvertActKeyToTableKey(Key);
            NewLocDistributionList."Group Code" := NoFilterLocGrType;
            NewLocDistributionList."Subgroup Code" := NoFilterLocGr;
            NewLocDistributionList."Store Group" := NoFilterStoreGr;
            if NewLocDistributionList.Insert() then;
            exit(true);
        end;

        exit(false);
    end;

    internal procedure InsertMasterDistribution(TableNo: Integer; "Key": Text[250]; PosKey: Text[250]; Master: Integer; MasterKey: Text[250]): Boolean
    var
        MasterLocDistributionList: Record "LSC Distribution List";
        NewLocDistributionList: Record "LSC Distribution List";
        MasterValue1: Text[250];
        MasterValue2: Text[250];
    begin
        if BoUtil.ValueIsCombined(MasterKey) then begin
            MasterValue1 := BoUtil.SeparateCombinedValue(1, MasterKey);
            MasterValue2 := BoUtil.SeparateCombinedValue(2, MasterKey);
        end else
            MasterValue1 := MasterKey;

        MasterLocDistributionList.Reset();
        MasterLocDistributionList.SetRange("Table ID", Master);
        MasterLocDistributionList.SetRange(Value, MasterValue1);
        if MasterLocDistributionList.FindSet() then begin
            repeat
                NewLocDistributionList.Init();
                NewLocDistributionList."Table ID" := TableNo;
                NewLocDistributionList.Value := BoUtil.ConvertActKeyToTableKey(Key);
                NewLocDistributionList."Group Code" := MasterLocDistributionList."Group Code";
                NewLocDistributionList."Subgroup Code" := MasterLocDistributionList."Subgroup Code";
                NewLocDistributionList.Insert();

                Actions.Init();
                Actions.Action := Actions.Action::"Update-Add";
                Actions."Table No." := Database::"LSC Distribution List";
                Actions.Key :=
                  BoUtil.CombineActKey(
                    4, BoUtil.IntegerToStr(NewLocDistributionList."Table ID"), NewLocDistributionList.Value, NewLocDistributionList."Group Code", NewLocDistributionList."Subgroup Code", '');
                Actions.Date := Today;
                Actions.Time := Time;
                Actions."User ID" := UserId;
                Actions."Entry No." := NextEntry();
                Actions."Location Group Filter" :=
                  BoUtil.CombineTableKey(2, NewLocDistributionList."Group Code", NewLocDistributionList."Subgroup Code", '', '', '');
                Actions.Insert();
            until MasterLocDistributionList.Next() = 0;
        end else
            exit(false);
        if MasterValue2 = '' then
            exit(true);
        MasterLocDistributionList.SetRange(Value, MasterValue2);
        if MasterLocDistributionList.FindSet() then begin
            repeat
                NewLocDistributionList.Init();
                NewLocDistributionList."Table ID" := TableNo;
                NewLocDistributionList.Value := BoUtil.ConvertActKeyToTableKey(Key);
                NewLocDistributionList."Group Code" := MasterLocDistributionList."Group Code";
                NewLocDistributionList."Subgroup Code" := MasterLocDistributionList."Subgroup Code";
                if NewLocDistributionList.Insert() then begin
                    Actions.Init();
                    Actions.Action := Actions.Action::"Update-Add";
                    Actions."Table No." := Database::"LSC Distribution List";
                    Actions.Key :=
                      BoUtil.CombineActKey(
                        4, BoUtil.IntegerToStr(NewLocDistributionList."Table ID"), NewLocDistributionList.Value, NewLocDistributionList."Group Code", NewLocDistributionList."Subgroup Code", '');
                    Actions.Date := Today;
                    Actions.Time := Time;
                    Actions."User ID" := UserId;
                    Actions."Entry No." := NextEntry();
                    Actions."Location Group Filter" :=
                      BoUtil.CombineTableKey(2, NewLocDistributionList."Group Code", NewLocDistributionList."Subgroup Code", '', '', '');
                    Actions.Insert();
                end;
            until MasterLocDistributionList.Next() = 0;
        end;

        exit(true);
    end;

    internal procedure CreateLocGroupTypeActions("Key": Code[10]; ActionType: Integer)
    var
        NoFilterLocGrType: Code[10];
        NoFilterLocGr: Code[10];
        NoFilterStoreGr: Code[10];
    begin
        Actions.Init();
        Actions.LockTable();
        if (ActionType = 0) or (ActionType = 1) then
            Actions.Action := Actions.Action::"Update-Add"
        else
            Actions.Action := ActionType;
        Actions."Table No." := Database::"LSC Distribution Group";
        Actions.Key := Key;
        Actions.Date := Today;
        Actions.Time := Time;
        Actions."User ID" := UserId;
        Actions."Entry No." := NextEntry();
        if NoFilterExists(NoFilterLocGrType, NoFilterLocGr, NoFilterStoreGr) then begin
            Actions."Location Group Filter" :=
              BoUtil.CombineTableKey(2, NoFilterLocGrType, NoFilterLocGr, '', '', '');
            Actions.Insert();
        end;
    end;

    internal procedure CreateLocGroupActions("Key": Code[30]; ActionType: Integer)
    var
        NoFilterLocGrType: Code[10];
        NoFilterLocGr: Code[10];
        NoFilterStoreGr: Code[10];
    begin
        Actions.Init();
        Actions.LockTable();
        if (ActionType = 0) or (ActionType = 1) then
            Actions.Action := Actions.Action::"Update-Add"
        else
            Actions.Action := ActionType;
        Actions."Table No." := Database::"LSC Distribution Subgroup";
        Actions.Key := Key;
        Actions.Date := Today;
        Actions.Time := Time;
        Actions."User ID" := UserId;
        Actions."Entry No." := NextEntry();
        if NoFilterExists(NoFilterLocGrType, NoFilterLocGr, NoFilterStoreGr) then begin
            Actions."Location Group Filter" :=
              BoUtil.CombineTableKey(2, NoFilterLocGrType, NoFilterLocGr, '', '', '');
            Actions.Insert();
        end;
    end;

    internal procedure CreateLocGroupMemberActions("Key": Code[40]; ActionType: Integer)
    begin
        Actions.Init();
        Actions.LockTable();
        if (ActionType = 0) or (ActionType = 1) then
            Actions.Action := Actions.Action::"Update-Add"
        else
            Actions.Action := ActionType;
        Actions."Table No." := Database::"LSC Distribution Group Member";
        Actions.Key := Key;
        Actions.Date := Today;
        Actions.Time := Time;
        Actions."User ID" := UserId;
        Actions."Entry No." := NextEntry();
        Actions."Location Group Filter" := GetNoFilter();
        Actions.Insert();
    end;

    internal procedure NewLocGroupMember(NewRetailLocGrMemberList: Record "LSC Distribution Group Member")
    var
        OldLocDistributionList: Record "LSC Distribution List";
        RetailLocGr: Record "LSC Distribution Subgroup";
        NoOfActions: Integer;
        Text005: Label 'Do you want the system to create actions for all records\';
        Text006: Label 'with %1 %2 %3,\';
        Text007: Label 'so that location %4 will receive this data?\';
        Text008: Label 'The no. of actions created will be %5.';
        Text009: Label '%4 Actions have been created to send to location %1 \data with the distribution %2 %3.';
    begin
        if not RetailLocGr.Get(
          NewRetailLocGrMemberList."Distrib. Loc. Code",
          NewRetailLocGrMemberList."Distrib. Loc. Code")
        then
            exit;

        OldLocDistributionList.Reset();
        OldLocDistributionList.SetCurrentKey("Group Code", "Subgroup Code");
        OldLocDistributionList.SetRange("Group Code", NewRetailLocGrMemberList."Group Code");
        OldLocDistributionList.SetRange("Subgroup Code", NewRetailLocGrMemberList."Subgroup Code");
        NoOfActions := OldLocDistributionList.Count * 2;
        if OldLocDistributionList.FindSet() then begin
            if not Confirm(
              Text005 +
              Text006 +
              Text007 +
              Text008,
              false,
              OldLocDistributionList.TableCaption,
              NewRetailLocGrMemberList."Group Code", NewRetailLocGrMemberList."Subgroup Code",
              NewRetailLocGrMemberList."Distrib. Loc. Code", NoOfActions)
            then
                exit;
            repeat
                Actions.Init();
                Actions.LockTable();
                Actions.Action := Actions.Action::"Update-Add";
                Actions."Table No." := OldLocDistributionList."Table ID";
                Actions.Key := BoUtil.ConvertTableKeyToActKey(OldLocDistributionList.Value);
                Actions.Date := Today;
                Actions.Time := Time;
                Actions."User ID" := UserId;
                Actions."Entry No." := NextEntry();
                Actions."Location Group Filter" :=
                  BoUtil.CombineTableKey(2, RetailLocGr."Group Code", RetailLocGr."Subgroup Code", '', '', '');
                Actions.Insert();

                Actions.Init();
                Actions.Action := Actions.Action::"Update-Add";
                Actions."Table No." := Database::"LSC Distribution List";
                Actions.Key :=
                  BoUtil.CombineActKey(
                    4, BoUtil.IntegerToStr(OldLocDistributionList."Table ID"), OldLocDistributionList.Value,
                    OldLocDistributionList."Group Code", OldLocDistributionList."Subgroup Code", '');
                Actions.Date := Today;
                Actions.Time := Time;
                Actions."User ID" := UserId;
                Actions."Entry No." := NextEntry();
                Actions."Location Group Filter" :=
                  BoUtil.CombineTableKey(2, RetailLocGr."Group Code", RetailLocGr."Subgroup Code", '', '', '');
                Actions.Insert();
            until OldLocDistributionList.Next() = 0;
            Message(
              Text009,
              NewRetailLocGrMemberList."Distrib. Loc. Code", NewRetailLocGrMemberList."Group Code",
              NewRetailLocGrMemberList."Subgroup Code", NoOfActions);
        end;
    end;

    internal procedure DeleteLocGroupMember(DelRetailLocGrMemberList: Record "LSC Distribution Group Member")
    var
        OldLocDistributionList: Record "LSC Distribution List";
        RetailLocGr: Record "LSC Distribution Subgroup";
        Text010: Label 'Actions have been created as necessary \to delete in location %1 data with the distribution %2 %3.';
    begin
        if not RetailLocGr.Get(
          DelRetailLocGrMemberList."Distrib. Loc. Code",
          DelRetailLocGrMemberList."Distrib. Loc. Code")
        then
            exit;

        OldLocDistributionList.Reset();
        OldLocDistributionList.SetCurrentKey("Group Code", "Subgroup Code");
        OldLocDistributionList.SetRange("Group Code", DelRetailLocGrMemberList."Group Code");
        OldLocDistributionList.SetRange("Subgroup Code", DelRetailLocGrMemberList."Subgroup Code");
        if OldLocDistributionList.FindSet() then begin
            repeat
                if not RecordInLocation(
                  OldLocDistributionList."Table ID", OldLocDistributionList.Value,
                  DelRetailLocGrMemberList)
                then begin
                    Actions.Init();
                    Actions.LockTable();
                    Actions.Action := Actions.Action::Delete;
                    Actions."Table No." := OldLocDistributionList."Table ID";
                    Actions.Key := BoUtil.ConvertTableKeyToActKey(OldLocDistributionList.Value);
                    Actions.Date := Today;
                    Actions.Time := Time;
                    Actions."User ID" := UserId;
                    Actions."Entry No." := NextEntry();
                    Actions."Location Group Filter" :=
                      BoUtil.CombineTableKey(2, RetailLocGr."Group Code", RetailLocGr."Subgroup Code", '', '', '');
                    Actions.Insert();

                    Actions.Init();
                    Actions.Action := Actions.Action::Delete;
                    Actions."Table No." := Database::"LSC Distribution List";
                    Actions.Key :=
                      BoUtil.CombineActKey(
                        4, BoUtil.IntegerToStr(OldLocDistributionList."Table ID"), OldLocDistributionList.Value,
                        OldLocDistributionList."Group Code", OldLocDistributionList."Subgroup Code", '');
                    Actions.Date := Today;
                    Actions.Time := Time;
                    Actions."User ID" := UserId;
                    Actions."Entry No." := NextEntry();
                    Actions."Location Group Filter" :=
                      BoUtil.CombineTableKey(2, RetailLocGr."Group Code", RetailLocGr."Subgroup Code", '', '', '');
                    Actions.Insert();
                end;
            until OldLocDistributionList.Next() = 0;
            Message(
              Text010,
              DelRetailLocGrMemberList."Distrib. Loc. Code", DelRetailLocGrMemberList."Group Code",
              DelRetailLocGrMemberList."Subgroup Code");
        end;
    end;

    internal procedure RecordInLocation(TableID: Integer; Value: Text[100]; DelRetailLocGrMemberList: Record "LSC Distribution Group Member"): Boolean
    var
        LocDistributionList4: Record "LSC Distribution List";
        RetailLocGrMemberList2: Record "LSC Distribution Group Member";
    begin
        LocDistributionList4.Reset();
        LocDistributionList4.SetRange("Table ID", TableID);
        LocDistributionList4.SetRange(Value, Value);
        LocDistributionList4.SetFilter("Group Code", '<>%1', DelRetailLocGrMemberList."Group Code");
        LocDistributionList4.SetFilter("Subgroup Code", '<>%1', DelRetailLocGrMemberList."Subgroup Code");
        if LocDistributionList4.FindSet() then
            repeat
                if RetailLocGrMemberList2.Get(
                  LocDistributionList4."Group Code", LocDistributionList4."Subgroup Code",
                  DelRetailLocGrMemberList."Distrib. Loc. Code")
                then
                    exit(true);
            until LocDistributionList4.Next() = 0;
        exit(false);
    end;

    internal procedure NextEntry(): Integer
    begin
        Actions2.Reset();
        Actions2.LockTable();
        if Actions2.FindLast() then
            exit(Actions2."Entry No." + 1)
        else
            exit(1);
    end;

    internal procedure GetNoFilter(): Text[30]
    var
        RetailLocGrType: Record "LSC Distribution Group";
        RetailLocGr: Record "LSC Distribution Subgroup";
        Text011: Label 'No record was found in table %1 specified as %2.';
        Text012: Label 'You need to create one such record under the %2 %3.';
    begin
        RetailLocGr.Reset();
        RetailLocGr.SetRange("No Filter", true);
        if not RetailLocGr.FindFirst() then
            Error(
              Text011 +
              Text012,
              RetailLocGr.TableCaption, RetailLocGr.FieldCaption("No Filter"),
              RetailLocGrType.TableCaption);

        exit(BoUtil.CombineTableKey(2, RetailLocGr."Group Code", RetailLocGr."Subgroup Code", '', '', ''));
    end;

    internal procedure NoFilterExists(var LocGrType: Code[10]; var LocGr: Code[10]; var StoreGroupCode: Code[20]): Boolean
    var
        RetailLocGr: Record "LSC Distribution Subgroup";
        StoreGroup: Record "LSC Store Group";
    begin
        RetailLocGr.Reset();
        RetailLocGr.SetRange("No Filter", true);
        if not RetailLocGr.FindFirst() then
            exit(false);
        LocGrType := RetailLocGr."Group Code";
        LocGr := RetailLocGr."Subgroup Code";
        StoreGroup.CalcFields("No Filter");
        StoreGroup.SetRange("No Filter", true);
        StoreGroup.SetRange("Distribution Group Code", LocGrType);
        StoreGroup.SetRange("Distribution Subgroup Code", LocGr);
        if StoreGroup.FindFirst() then
            StoreGroupCode := StoreGroup.Code;
        exit(true);
    end;

    procedure CreateActionsByRecRef(RecRef: RecordRef; xRecRef: RecordRef; Type: Integer)
    var
        BOUtils: Codeunit "LSC BO Utils";
        POSSearch: Codeunit "LSC Search Index";
        FieldR: FieldRef;
        Keyr: KeyRef;
        tmpDate: Date;
        tmpDateTime: DateTime;
        tmpTime: Time;
        txtKey: Text[250];
        addValue: Text[250];
        AdditionalValues: Text[250];
        SeparateChr: Text[1];
        tmpDec: Decimal;
        i: Integer;
        tmpInt: Integer;
        tmpBool: Boolean;
        IsHandled: Boolean;
    begin
        if not SkipUpdatePosSearch() then
            POSSearch.MarkForIndexUpdate(RecRef, xRecRef, Type);

        OnBeforeCreateActionsByRecRef(RecRef, Type, IsHandled, xRecRef);
        if IsHandled then
            exit;

        if RecRef.Number >= 2000100000 then
            exit;

        if not RetailSetup.Get() then
            exit;

        if CalledByTableTrigger then
            exit;

        if Type = 3 then
            ErrorOnRename(true, RecRef.Number, '');

        Keyr := RecRef.KeyIndex(1);
        txtKey := '';
        for i := 1 to Keyr.FieldCount do begin
            FieldR := Keyr.FieldIndex(i);
            case Format(FieldR.Type) of
                'Decimal':
                    begin
                        Evaluate(tmpDec, Format(FieldR.Value));
                        addValue := BOUtils.DecToStr(tmpDec);
                    end;
                'Time':
                    begin
                        tmpTime := FieldR.Value;
                        addValue := BOUtils.STDTimeToString(tmpTime);
                    end;
                'Date':
                    begin
                        Evaluate(tmpDate, Format(FieldR.Value));
                        addValue := BOUtils.STDDateToString(tmpDate);
                    end;
                'Boolean':
                    begin
                        Evaluate(tmpBool, Format(FieldR.Value));
                        addValue := BOUtils.BoolToStr(tmpBool);
                    end;
                'DateTime':
                    begin
                        tmpDateTime := FieldR.Value;
                        addValue := BOUtils.STDDateTimeToString(tmpDateTime);
                    end;
                'Option':
                    begin
                        tmpInt := FieldR.Value;
                        addValue := BOUtils.OptToStr(tmpInt);
                    end;
                else begin
                    SeparateChr := BoUtils.GetSeparateValueChar();
                    addValue := Format(FieldR.Value);
                    addValue := ConvertStr(addValue, ';', SeparateChr);
                end;
            end;
            txtKey += ';' + addValue;
        end;
        txtKey := CopyStr(txtKey, 2);

        DataAccessControlCheck(RecRef, xRecRef, Type, txtKey);

        AdditionalValues := GetAdditionalValues(RecRef);

        case Type of
            0:
                CreateActions(RecRef.Number, txtKey, 1, false, AdditionalValues);
            1:
                CreateActions(RecRef.Number, txtKey, 0, false, AdditionalValues);
            else
                CreateActions(RecRef.Number, txtKey, Type, false, AdditionalValues);
        end;
    end;

    internal procedure xCreateActionFromTable(Type: Integer)
    begin
        //Type: 0 = INSERT, 1 = MODIFY, 2 = DELETE, 3 = RENAME
    end;

    internal procedure DataAccessControlCheck(RecRef: RecordRef; xRecRef: RecordRef; Type: Integer; "Key": Text[250])
    var
        RetailUser: Record "LSC Retail User";
        RetailSetup: Record "LSC Retail Setup";
        Store: Record "LSC Store";
        DataAccessAuthorizations: Record "LSC Data Access Authorizations";
        DataAccessLog: Record "LSC Data Access Log";
        DataAccessTable: Record "LSC Data Access Table";
        BOUtils: Codeunit "LSC BO Utils";
        FieldR: FieldRef;
        xFieldR: FieldRef;
        tmpDate: Date;
        tmpTime: Time;
        StoreCode: Code[10];
        tmpDec: Decimal;
        i: Integer;
        tmpInt: Integer;
        tmpBool: Boolean;
        Text014: Label 'You do not have authorization to change table %1 - %2.';
    begin
        if not DataAccessTable.Get(RecRef.Number) then
            exit;

        if not RetailSetup.Get() then
            exit;

        if RetailUser.Get(UserId) then
            if RetailUser."Store No." <> '' then
                StoreCode := RetailUser."Store No."
            else
                StoreCode := RetailSetup."Local Store No.";

        if StoreCode = '' then
            exit;

        Store.Get(StoreCode);

        if not Store."Data Access Control" then
            exit;

        if not (DataAccessAuthorizations.Get(StoreCode, UserId, RecRef.Number)) then
            Error(Text014, Format(RecRef.Number), RecRef.Name);

        for i := 1 to RecRef.FieldCount do begin
            FieldR := RecRef.FieldIndex(i);
            xFieldR := xRecRef.FieldIndex(i);

            if FieldR.Value <> xFieldR.Value then begin
                DataAccessLog.Init();
                DataAccessLog."Store No." := StoreCode;
                DataAccessLog.DateTime := CurrentDateTime;
                DataAccessLog."Table ID" := RecRef.Number;
                DataAccessLog."Field No." := FieldR.Number;
                DataAccessLog.Key := Key;
                DataAccessLog."Retail User ID" := UserId;

                case Format(xFieldR.Type) of
                    'Decimal':
                        begin
                            Evaluate(tmpDec, Format(xFieldR.Value));
                            DataAccessLog."Old Value" := BOUtils.DecToStr(tmpDec);
                        end;
                    'Time':
                        begin
                            Evaluate(tmpTime, Format(xFieldR.Value));
                            DataAccessLog."Old Value" := BOUtils.STDTimeToString(tmpTime);
                        end;
                    'Date':
                        begin
                            Evaluate(tmpDate, Format(xFieldR.Value));
                            DataAccessLog."Old Value" := BOUtils.STDDateToString(tmpDate);
                        end;
                    'Boolean':
                        begin
                            Evaluate(tmpBool, Format(xFieldR.Value));
                            DataAccessLog."Old Value" := BOUtils.BoolToStr(tmpBool);
                        end;
                    'Option':
                        begin
                            tmpInt := xFieldR.Value;
                            DataAccessLog."Old Value" := BOUtils.OptToStr(tmpInt);
                        end;
                    else
                        DataAccessLog."Old Value" := Format(xFieldR.Value);
                end;

                case Format(FieldR.Type) of
                    'Decimal':
                        begin
                            Evaluate(tmpDec, Format(FieldR.Value));
                            DataAccessLog."New Value" := BOUtils.DecToStr(tmpDec);
                        end;
                    'Time':
                        begin
                            Evaluate(tmpTime, Format(FieldR.Value));
                            DataAccessLog."New Value" := BOUtils.STDTimeToString(tmpTime);
                        end;
                    'Date':
                        begin
                            Evaluate(tmpDate, Format(FieldR.Value));
                            DataAccessLog."New Value" := BOUtils.STDDateToString(tmpDate);
                        end;
                    'Boolean':
                        begin
                            Evaluate(tmpBool, Format(FieldR.Value));
                            DataAccessLog."New Value" := BOUtils.BoolToStr(tmpBool);
                        end;
                    'Option':
                        begin
                            tmpInt := FieldR.Value;
                            DataAccessLog."New Value" := BOUtils.OptToStr(tmpInt);
                        end;
                    else
                        DataAccessLog."New Value" := Format(FieldR.Value);
                end;
                DataAccessLog.Insert(true);
            end;
        end;
    end;

    procedure SetCalledByTableTrigger(NewCalledByTableTrigger: Boolean)
    begin
        CalledByTableTrigger := NewCalledByTableTrigger;
    end;

    local procedure IsCurrentLocationUsingPreactionTimestamp(): Boolean
    var
        PreactionFunc: Codeunit "LSC Preaction Functions";
        TimstampKey: Code[20];
        KeyValue: Text;
    begin
        TimstampKey := CreatePreactionTimestampKey();
        KeyValue := SessionKeyValues.GetValue(TimstampKey);
        IF KeyValue = '' then begin
            IF PreactionFunc.IsCurrentLocationUsingPreactionTimestamp() then
                KeyValue := 'TRUE'
            else
                KeyValue := 'FALSE';
            SessionKeyValues.SetValue(TimstampKey, KeyValue);
        end;
        IF KeyValue = 'TRUE' then
            exit(true)
        else
            exit(false);
    end;

    local procedure CreatePreactionTimestampKey(): Code[20]
    begin
        exit('#PREACTIONTIMESTAMP')
    end;

    local procedure IsLSPreactionCreationActive(): Boolean
    var
        LSRetailSetup: Record "LSC Retail Setup";
        LSActivated: Boolean;
    begin
        IF SkipPreAction() then
            LSActivated := false
        else
            if LSRetailSetup.Get() then
                LSActivated := (LSRetailSetup."Preaction Creation by" = LSRetailSetup."Preaction Creation by"::"Database Triggers")
            else
                LSActivated := false;

        exit(LSActivated);
    end;

    local procedure IsActionMgtSystemTable(TableID: Integer): Boolean
    var
        TableNoList: List of [Integer];
    begin
        IF IsCurrentLocationUsingPreactionTimestamp() then begin
            TableNoList := GetActionMgtTimestampSystemTableNoList();
            Exit(TableNoList.Contains(TableID));
        end else begin
            TableNoList := GetActionMgtSystemTableNoList();
            Exit(TableNoList.Contains(TableID));
        end;
    end;

    local procedure GetActionMgtSystemTableNoList(): List of [Integer]
    var
        TableNoList: List of [Integer];
    begin
        //99001509, 99001527, 99001612, 99001613, 99001614, 99001616, 99001623, 99001671
        TableNoList.Add(Database::"LSC Actions");
        TableNoList.Add(Database::"LSC Preload Action");
        TableNoList.Add(Database::"LSC Preaction");
        TableNoList.Add(Database::"LSC System Preaction");
        TableNoList.Add(Database::"LSC Action Counters");
        TableNoList.Add(Database::"LSC Preaction Setup");
        TableNoList.Add(Database::"LSC Preaction Log");
        TableNoList.Add(Database::"LSC Preaction Creation");
        exit(TableNoList);
    end;

    local procedure GetActionMgtTimestampSystemTableNoList(): List of [Integer]
    var
        TableNoList: List of [Integer];
    begin
        //10000858, 10000859, 10000860, 99001509, 99001527, 99001612, 99001613, 99001614, 99001616, 99001623, 99001671
        TableNoList.Add(Database::"LSC Delete Preaction");
        TableNoList.Add(Database::"LSC Preaction Timestamp");
        TableNoList.Add(Database::"LSC Preaction Skip Log");
        TableNoList.Add(Database::"LSC Actions");
        TableNoList.Add(Database::"LSC Preload Action");
        TableNoList.Add(Database::"LSC Preaction");
        TableNoList.Add(Database::"LSC System Preaction");
        TableNoList.Add(Database::"LSC Action Counters");
        TableNoList.Add(Database::"LSC Preaction Setup");
        TableNoList.Add(Database::"LSC Preaction Log");
        TableNoList.Add(Database::"LSC Preaction Creation");
        exit(TableNoList);
    end;

    local procedure IsLSRecord(TableID: Integer): Boolean
    var
        PreactionCreation: Record "LSC Preaction Creation";
    begin
        if PreactionCreation.Get(TableID) then
            exit(true);

        exit(false);
    end;

    local procedure CreateActionMgtExeID(TableVariant_p: Variant): Text
    var
        WSFunc: Codeunit "LSC WS Functions";
        RecRef: RecordRef;
        RecID: RecordID;
        DTText: Text;
        DIText: Text;
    begin
        if TableVariant_p.IsRecord then
            RecRef.GetTable(TableVariant_p)
        else
            RecRef := TableVariant_p;
        DTText := 'AM=' + Format(RecRef.Number);
        RecID := RecRef.RecordId;
        WSFunc.GetPreactionKeyFromRecID(RecID, DIText);
        exit(SessionDataExchangeUtility.CreateExeID(SessionId(), DTText, DIText));
    end;

    procedure SetSkipCreatePreAction(TableVariant_p: Variant)
    var
        RecRef: RecordRef;
        RecRefTmp: RecordRef;
    begin
        if TableVariant_p.IsRecord then
            RecRef.GetTable(TableVariant_p)
        else
            RecRef := TableVariant_p;
        if IsLSPreactionCreationActive() and IsLSRecord(RecRef.Number) then begin
            RecRefTmp := RecRef.Duplicate();
            RecRefTmp.SetRecFilter();
            IF IsCurrentLocationUsingPreactionTimestamp() then
                PreactionMgt.SetPreactionSkipLog(RecRefTmp)
            else
                SessionDataExchangeUtility.SetData(CreateActionMgtExeID(TableVariant_p), RecRefTmp);
        end;
    end;

    procedure ClearSkipCreatePreAction(TableVariant_p: Variant)
    var
        RecRef: RecordRef;
        RecRefTmp: RecordRef;
        PreactionMgt: Codeunit "LSC Preaction Mgt";
    begin
        IF not IsCurrentLocationUsingPreactionTimestamp() then
            exit;
        if TableVariant_p.IsRecord then
            RecRef.GetTable(TableVariant_p)
        else
            RecRef := TableVariant_p;
        if IsLSPreactionCreationActive() and IsLSRecord(RecRef.Number) then begin
            RecRefTmp := RecRef.Duplicate();
            RecRefTmp.SetRecFilter();
            PreactionMgt.ClearPreactionSkipLog(RecRefTmp);
        end;
    end;

    local procedure SkipCreatePreAction(RecRef: RecordRef): Boolean
    var
        RecRef2: RecordRef;
        ExeID: Text;
    begin
        ExeID := CreateActionMgtExeID(RecRef);
        RecRef2.Open(RecRef.Number, true);
        if SessionDataExchangeUtility.GetDataIfExists(ExeID, RecRef2) then
            exit(true);
        exit(false);
    end;

    procedure SetSkipPreAction()
    var
        SkipPreActionKey: Code[20];
    begin
        SkipPreActionKey := CreateSkipPreActionKey();
        SessionKeyValues.SetValue(SkipPreActionKey, 'TRUE');
    end;

    procedure ClearSkipPreAction()
    var
        SkipPreActionKey: Code[20];
    begin
        SkipPreActionKey := CreateSkipPreActionKey();
        SessionKeyValues.DeleteValue(SkipPreActionKey);
    end;

    local procedure SkipPreAction(): Boolean
    var
        SkipPreActionKey: Code[20];
        KeyValue: Text;
    begin
        SkipPreActionKey := CreateSkipPreActionKey();
        KeyValue := SessionKeyValues.GetValue(SkipPreActionKey);
        IF KeyValue = 'TRUE' then
            exit(true)
        else
            exit(false);
    end;

    local procedure CreateSkipPreActionKey(): Code[20]
    begin
        exit('#SKIPPREACTION')
    end;

    procedure SetSkipUpdatePosSearch()
    var
        SkipUpdatePosSearchKey: Code[20];
    begin
        SkipUpdatePosSearchKey := CreateSkipUpdatePosSearchKey();
        SessionKeyValues.SetValue(SkipUpdatePosSearchKey, 'TRUE');
    end;

    procedure ClearSkipUpdatePosSearch()
    var
        SkipUpdatePosSearchKey: Code[20];
    begin
        SkipUpdatePosSearchKey := CreateSkipUpdatePosSearchKey();
        SessionKeyValues.DeleteValue(SkipUpdatePosSearchKey);
    end;

    local procedure SkipUpdatePosSearch(): Boolean
    var
        SkipUpdatePosSearchKey: Code[20];
        KeyValue: Text;
    begin
        SkipUpdatePosSearchKey := CreateSkipUpdatePosSearchKey();
        KeyValue := SessionKeyValues.GetValue(SkipUpdatePosSearchKey);
        IF KeyValue = 'TRUE' then
            exit(true)
        else
            exit(false);
    end;

    local procedure CreateSkipUpdatePosSearchKey(): Code[20]
    begin
        exit('#SKIPUPDATEPOSSEARCH')
    end;

    local procedure GetAdditionalValues(RecRef: RecordRef): Text
    var
        RetailCommentLineTmp: record "LSC Retail Comment Line" temporary;
        AddValueExeID: Text;
        AdditionalValuesText: Text;
    begin
        AdditionalValuesText := '';
        AddValueExeID := CreateAddValueExeID();
        if SessionDataExchangeUtility.GetDataIfExists(AddValueExeID, RetailCommentLineTmp) then begin
            IF RetailCommentLineTmp.FindFirst() then
                if RetailCommentLineTmp."Table No." = RecRef.Number then
                    AdditionalValuesText := RetailCommentLineTmp.Comment;
        end;
        exit(AdditionalValuesText);
    end;

    local procedure CreateAddValueExeID(): Text
    var
        DTText: Text;
        DIText: Text;
    begin
        DTText := 'AV=F17';
        DIText := 'AM99001451;99001612';
        exit(SessionDataExchangeUtility.CreateExeID(SessionId(), DTText, DIText));
    end;

    Internal procedure SetAdditionalValues(var RetailCommentLineTmp: record "LSC Retail Comment Line" temporary)
    var
        AddValueExeID: Text;
    begin
        AddValueExeID := CreateAddValueExeID();
        SessionDataExchangeUtility.SetData(AddValueExeID, RetailCommentLineTmp);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::GlobalTriggerManagement, OnAfterGetDatabaseTableTriggerSetup, '', false, false)]
    local procedure IsValidForPreActionOnAfterGetDatabaseTableTriggerSetup(TableId: Integer; var OnDatabaseInsert: Boolean; var OnDatabaseModify: Boolean; var OnDatabaseDelete: Boolean; var OnDatabaseRename: Boolean)
    begin
        if IsActionMgtSystemTable(TableId) then
            exit;

        if IsLSRecord(TableId) then begin
            if IsCurrentLocationUsingPreactionTimestamp() then begin
                OnDatabaseInsert := true;
                OnDatabaseDelete := true;
                OnDatabaseRename := true;
            end else begin
                OnDatabaseInsert := true;
                OnDatabaseModify := true;
                OnDatabaseDelete := true;
                OnDatabaseRename := true;
            end;
        end;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::GlobalTriggerManagement, OnAfterOnDatabaseInsert, '', false, false)]
    local procedure CreatePreActionOnAfterOnDatabaseInsert(RecRef: RecordRef)
    var
        RecRef2: RecordRef;
    begin
        if RecRef.IsTemporary then
            exit;

        if not IsLSPreactionCreationActive() then
            exit;

        if IsLSRecord(RecRef.Number) then begin
            RecRef2 := RecRef.Duplicate();
            if not SkipCreatePreAction(RecRef2) then
                if IsCurrentLocationUsingPreactionTimestamp() then
                    PreactionMgt.UpdateTableDistributionSetup(RecRef2)
                else
                    CreateActionsByRecRef(RecRef2, RecRef2, 0);
        end;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::GlobalTriggerManagement, OnAfterOnDatabaseModify, '', false, false)]
    local procedure CreatePreActionOnAfterOnDatabaseModify(RecRef: RecordRef)
    var
        RecRef2: RecordRef;
    begin
        if RecRef.IsTemporary then
            exit;

        if not IsLSPreactionCreationActive() then
            exit;

        if IsCurrentLocationUsingPreactionTimestamp() then
            exit;

        if IsLSRecord(RecRef.Number) then begin
            RecRef2 := RecRef.Duplicate();
            if not SkipCreatePreAction(RecRef2) then
                CreateActionsByRecRef(RecRef2, RecRef2, 1);
        end;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::GlobalTriggerManagement, OnAfterOnDatabaseDelete, '', false, false)]
    local procedure CreatePreActionOnAfterOnDatabaseDelete(RecRef: RecordRef)
    var
        RecRef2: RecordRef;
    begin
        if RecRef.IsTemporary then
            exit;

        if not IsLSPreactionCreationActive() then
            exit;

        if IsLSRecord(RecRef.Number) then begin
            RecRef2 := RecRef.Duplicate();
            if IsCurrentLocationUsingPreactionTimestamp() then
                PreactionMgt.CreateDeletePreactionsByRecRef(RecRef2)
            else
                CreateActionsByRecRef(RecRef2, RecRef2, 2);
        end;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::GlobalTriggerManagement, OnAfterOnDatabaseRename, '', false, false)]
    local procedure CreatePreActionOnAfterOnDatabaseRename(RecRef: RecordRef; xRecRef: RecordRef)
    var
        RecRef2: RecordRef;
        xRecRef2: RecordRef;
    begin
        if RecRef.IsTemporary then
            exit;

        if not IsLSPreactionCreationActive() then
            exit;

        if IsLSRecord(RecRef.Number) then begin
            RecRef2 := RecRef.Duplicate();
            xRecRef2 := xRecRef.Duplicate();
            if IsCurrentLocationUsingPreactionTimestamp() then begin
                ErrorOnRename(true, RecRef.Number, '');
                PreactionMgt.CreateDeletePreactionsByRecRef(xRecRef2);
            end else
                CreateActionsByRecRef(RecRef2, xRecRef2, 3);
        end;
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"System Initialization", OnAfterLogin, '', false, false)]
    local procedure UpdatePreactionCreationOnAfterOpenCompany()
    var
        PreactionCreation: Record "LSC Preaction Creation";
    begin
        if PreactionCreation.IsEmpty then
            PreactionCreation.InsertAllTables();
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeCreateActionsByRecRef(RecRef: RecordRef; Type: Integer; var IsHandled: Boolean; xRecRef: RecordRef)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeErrorOnReName(var IsHandled: Boolean)
    begin
    end;
}
