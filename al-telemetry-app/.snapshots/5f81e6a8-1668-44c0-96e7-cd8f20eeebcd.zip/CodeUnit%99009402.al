codeunit 99009402 "LSC Retail Localization Ext."
{

    var
        ExchangeFactor: Decimal;
        SalesHeaderRead: Boolean;

    procedure SetCurrentyFactor()
    begin
        SalesHeaderRead := true;
        ExchangeFactor := 1
    end;

    [EventSubscriber(ObjectType::Table, Database::"LSC Preaction Creation", OnAfterCreateValidTableNoBuffer, '', false, false)]
    local procedure InsertPreactionCreationOnAfterCreateValidTableNoBuffer(var ValidTableNoBuffer_p: Record "LSC Preaction Creation" temporary)
    begin
        ValidTableNoBuffer_p.InsertTableNoIntoBuffer(322, ValidTableNoBuffer_p);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Release Sales Document", OnAfterReopenSalesDoc, '', false, false)]
    local procedure DeleteSalesOrderSalesTaxEntriesOnReOpenSalesDoc(var SalesHeader: Record "Sales Header"; PreviewMode: Boolean)
    var
        SalesOrderSalesTaxEntry: Record "LSC Sales Order SalesTax Entry";
    begin
        if SalesHeader."Document Type" in [SalesHeader."Document Type"::Order, SalesHeader."Document Type"::"Return Order"] then begin
            SalesOrderSalesTaxEntry.Reset;
            SalesOrderSalesTaxEntry.SetRange("Document Type", SalesHeader."Document Type");
            SalesOrderSalesTaxEntry.SetRange("Document No.", SalesHeader."No.");
            SalesOrderSalesTaxEntry.DeleteAll;
        end;
    end;

    procedure IsNALocalizationEnabled() NAEnabled: Boolean
    var
        ClientSessionUtility: Codeunit "LSC Client Session Utility";
        Localizedversion: Text;
    begin
        Localizedversion := ClientSessionUtility.FindLocalizedVersion;
        if (LocalizedVersion = 'NA') OR (LocalizedVersion = 'US') OR (LocalizedVersion = 'CA') OR (LocalizedVersion = 'MX') then
            exit(true)
        else
            exit(false);
    end;

    procedure IsAULocalizationEnabled() AUEnabled: Boolean
    var
        ClientSessionUtility: Codeunit "LSC Client Session Utility";
    begin
        if (ClientSessionUtility.FindLocalizedVersion = 'AU') then
            exit(true)
        else
            exit(false);
    end;

    [Obsolete('Move to Arabic Receipt for LS Central app.', '25.1')]
    procedure GetVATDimensionCode(DimSetID: Integer): Code[20]
    var
        Dimension: Record Dimension;
        DimSetEntry: Record "Dimension Set Entry";
    begin
        if DimSetID = 0 then
            exit('');

        Dimension.SetRange("LSC VAT Dimension", true);
        if Dimension.FindFirst() then begin
            if DimSetEntry.Get(DimSetID, Dimension.Code) then
                exit(DimSetEntry."Dimension Value Code")
            else
                exit('');
        end else
            exit('');
    end;
}

