codeunit 10000961 "LSC Client Session Utility" implements "LSC IClientSessionUtility"
{

    var
        SessionKeyValues: Codeunit "LSC Session Key Values";

    procedure UpdateReplicationCountersForTable(recordID: RecordID; var replicationCounter: Integer): Boolean;
    var
        skipStdUpdReplCount: Boolean;
    BEGIN
        BeforeUpdateReplicationCountersForTable(recordID.TABLENO, replicationCounter, skipStdUpdReplCount);
        if skipStdUpdReplCount then
            exit(false);

        exit(UpdateReplicationCounters());
    END;

    procedure UpdateReplicationCounters(): Boolean
    var
        RetailSetup: Record "LSC Retail Setup";
        DistributionLocation: Record "LSC Distribution Location";
        "Key": Code[20];
        KeyValue: Text;
    begin
        //UpdateReplicationCounters
        Key := '#REPLCOUNT';
        KeyValue := SessionKeyValues.GetValue(Key);
        if KeyValue = '' then begin
            RetailSetup.Get();
            if DistributionLocation.Get(RetailSetup."Distribution Location") then
                if DistributionLocation."Skip Repl. Counter Update" then
                    KeyValue := 'FALSE'
                else
                    KeyValue := 'TRUE'
            else
                KeyValue := 'TRUE';
            SessionKeyValues.SetValue(Key, KeyValue);
        end;
        if KeyValue = 'TRUE' then
            exit(true)
        else
            exit(false);
    end;

    procedure IsTraningModeValid(): Boolean
    var
        "Key": Code[20];
        KeyValue: Text;
    begin
        //IsTraningModeValid
        Key := '#TRANING';
        KeyValue := SessionKeyValues.GetValue(Key);
        if KeyValue = '' then
            KeyValue := 'TRUE';
        if KeyValue = 'TRUE' then
            exit(true)
        else
            exit(false);
    end;

    procedure MaxReceiptCopies(): Integer
    var
        "Key": Code[20];
        KeyValue: Text;
        MaxCopies: Integer;
    begin
        //MaxReceiptCopies
        MaxCopies := 0;
        Key := '#MAXCOPIES';
        KeyValue := SessionKeyValues.GetValue(Key);
        if KeyValue <> '' then
            if not Evaluate(MaxCopies, KeyValue) then
                MaxCopies := 0;
        exit(MaxCopies);
    end;

    procedure OpenDrawerBlocksSale(): Boolean
    var
        "Key": Code[20];
        KeyValue: Text;
    begin
        //OpenDrawerBlocksSale
        Key := '#OPENDRAWERBLOCKSALE';
        KeyValue := SessionKeyValues.GetValue(Key);
        if KeyValue = '' then
            KeyValue := 'FALSE';
        if KeyValue = 'TRUE' then
            exit(true)
        else
            exit(false);
    end;

    procedure FindLocalizedVersion(): Text
    var
        ApplicationMgt: Codeunit "Application System Constants";
        "Key": Code[20];
        KeyValue: Text;
        ApplicationVersion: Text;
        StrInd: Integer;
    begin
        //FindLocalizedVersion
        Key := '#LOCALIZEDVERSION';
        KeyValue := SessionKeyValues.GetValue(Key);
        if KeyValue = '' then begin
            ApplicationVersion := ApplicationMgt.ApplicationVersion();
            StrInd := StrPos(ApplicationVersion, ' ');
            if StrInd > 0 then
                KeyValue := CopyStr(ApplicationVersion, 1, StrInd - 1);
            if KeyValue <> '' then
                SessionKeyValues.SetValue(Key, KeyValue);
        end;
        exit(KeyValue);
    end;

    procedure IsLocalRequest(): Boolean
    var
        "Key": Code[20];
        KeyValue: Text;
    begin
        //IsLocalRequest
        Key := '#LOCALREQUEST';
        KeyValue := SessionKeyValues.GetValue(Key);
        if KeyValue = '' then
            KeyValue := 'FALSE';
        if KeyValue = 'TRUE' then
            exit(true)
        else
            exit(false);
    end;

    procedure IsReturnInSaleBlocked(): Boolean
    var
        "Key": Code[20];
        KeyValue: Text;
        BlockReturnInSale: Boolean;
    begin
        Key := '#BLOCKRETURNINSALE';
        KeyValue := SessionKeyValues.GetValue(Key);
        BlockReturnInSale := false;
        if KeyValue = 'TRUE' then
            BlockReturnInSale := true;
        exit(BlockReturnInSale);
    end;

    LOCAL PROCEDURE BeforeUpdateReplicationCountersForTable(tableNo: Integer; VAR replicationCounter: Integer; VAR skipStdUpdReplCount: Boolean);
    VAR
        RetailSetup: Record "LSC Retail Setup";
        SchedulerSubjobLinkedTable: Record "LSC Scheduler Subj. Linked Tbl";
        TransactionHeaderReplCount: Record LSCTransactionHeaderReplCount;
        SessionKeyValues: Codeunit "LSC Session Key Values";
        "Key": Code[20];
        Keyvalue: Text;
    BEGIN
        IF not UpdateReplicationCounters() then begin
            skipStdUpdReplCount := false;
            exit;
        end;

        If SkipUpdatingReplicationCounters() then begin
            skipStdUpdReplCount := true;
            exit;
        end;

        IF tableNo = DATABASE::"LSC Transaction Header" THEN BEGIN
            replicationCounter := TransactionHeaderReplCount.GetReplicationCounter();
            skipStdUpdReplCount := TRUE;
            EXIT;
        END;

        "Key" := STRSUBSTNO('UPDREPLCNT-%1', tableNo);
        Keyvalue := SessionKeyValues.GetValue("Key");
        IF Keyvalue <> '' THEN BEGIN
            EVALUATE(skipStdUpdReplCount, Keyvalue);
            EXIT;
        END;

        RetailSetup.Get();
        IF RetailSetup."No Repl.Counter Linked T. Subj" <> '' THEN BEGIN
            SchedulerSubjobLinkedTable.SETRANGE("Subjob ID", RetailSetup."No Repl.Counter Linked T. Subj");
            SchedulerSubjobLinkedTable.SETRANGE("From-Table ID", tableNo);
            skipStdUpdReplCount := NOT SchedulerSubjobLinkedTable.ISEMPTY;
        END else
            skipStdUpdReplCount := FALSE;

        Keyvalue := FORMAT(skipStdUpdReplCount);
        SessionKeyValues.SetValue("Key", Keyvalue);
    END;

    Internal procedure ClearSkipUpdatingReplicationCounters()
    var
        "Key": Code[20];
    begin
        //SetSkipUpdatingReplicationCounters
        Key := '#SKIPREPLCOUNT';
        SessionKeyValues.DeleteValue(Key);
    end;

    Internal procedure SetSkipUpdatingReplicationCounters()
    var
        "Key": Code[20];
        KeyValue: Text;
    begin
        //SetSkipUpdatingReplicationCounters
        Key := '#SKIPREPLCOUNT';
        KeyValue := 'TRUE';
        SessionKeyValues.SetValue(Key, KeyValue);
    end;

    Internal procedure SkipUpdatingReplicationCounters(): Boolean
    var
        "Key": Code[20];
        KeyValue: Text;
    begin
        //SkipUpdatingReplicationCounters
        Key := '#SKIPREPLCOUNT';
        KeyValue := SessionKeyValues.GetValue(Key);
        if KeyValue = '' then begin
            KeyValue := 'FALSE';
            SessionKeyValues.SetValue(Key, KeyValue);
        end;
        if KeyValue = 'TRUE' then
            exit(true)
        else
            exit(false);
    end;
}

