codeunit 99008882 "LSC POS Resource Library"
{
    var
        POSSESSION: Codeunit "LSC POS Session";
        POSUTILS: Codeunit "LSC POS Control Utils";
        _mainStyleProfileID: Text;
        _secondaryStyleProfileID: Text;
        _skins: Record "LSC POS Button Skin";
        _fonts: Record "LSC POS Font";
        _colors: Record "LSC POS Color";

        _defaultFonts: Record "LSC POS Font" temporary;
        _defaultSkins: Record "LSC POS Button Skin" temporary;
        _defaultColors: Record "LSC POS Color" temporary;

    procedure SetMainStyleProfileID(pMainProfileID: Text)
    begin
        if _mainStyleProfileID <> pMainProfileID then begin
            _mainStyleProfileID := pMainProfileID;
        end;
    end;

    procedure SetSecondaryStyleProfileID(pSecondaryProfileID: Text)
    begin
        if _secondaryStyleProfileID <> pSecondaryProfileID then begin
            _secondaryStyleProfileID := pSecondaryProfileID;
        end;
    end;

    procedure MainStyleProfileID(): Text
    begin
        exit(_mainStyleProfileID);
    end;

    procedure SecondaryStyleProfileID(): Text
    begin
        exit(_secondaryStyleProfileID);
    end;

    procedure LoadDefaultFont(pProfileID: Text; pFontID: Text; pFontName: Text; pFontSize: Integer; pColor: Integer; pBold: Boolean)
    begin
        _defaultFonts.Init();
        _defaultFonts."Style Profile ID" := pProfileID;
        _defaultFonts.Code := pFontID;
        if pFontName <> '' then
            _defaultFonts.Name := pFontName;
        if pFontSize > 0 then
            _defaultFonts.Size := pFontSize;
        if pColor >= 0 then
            _defaultFonts.Color := pColor;
        _defaultFonts.Bold := pBold;
        if not _defaultFonts.Insert() then
            _defaultFonts.Modify();
    end;

    procedure LoadDefaultSkin(pProfileID: Text; pSkinID: Text; pBackColor: Integer; pBackColor2: Integer; pTransparency: Integer; pBorderWidth: Integer; pBorderColor: Integer; pGradientVertical: Boolean; pTransparent: Boolean)
    begin
        _defaultSkins.Init();
        _defaultSkins."Style Profile ID" := pProfileID;
        _defaultSkins.Code := pSkinID;
        if pBackColor >= 0 then
            _defaultSkins."Back Color" := pBackColor;
        if pBackColor2 >= 0 then
            _defaultSkins."Back Color 2" := pBackColor2;
        if pTransparency >= 0 then
            _defaultSkins.Transparency := pTransparency;
        if pBorderWidth >= 0 then
            _defaultSkins."Border Width" := pBorderWidth;
        if pBorderColor >= 0 then
            _defaultSkins."Border Color" := pBorderColor;
        if pGradientVertical then
            _defaultSkins."Gradient Mode" := _defaultSkins."Gradient Mode"::Vertical;
        _defaultSkins.Transparent := pTransparent;
        if not _defaultSkins.Insert() then
            _defaultSkins.Modify();
    end;

    procedure LoadDefaultColor(pProfileID: Text; pColorID: Text; pColor: Integer)
    begin
        _defaultColors.Init();
        _defaultColors."Style Profile ID" := pProfileID;
        _defaultColors.Code := pColorID;
        if pColor >= 0 then
            _defaultColors.Color := pColor;
        if not _defaultColors.Insert() then
            _defaultColors.Modify();
    end;

    procedure CreateDefaultResourcesJson(pProfileID: Text)
    var
        Color: Record "LSC POS Color";
        DISABLED: Label '##DISABLED', Locked = true;
        GLYPHID: Label '##GLYPH', Locked = true;
        GLYPHTEXTID: Label '##GLYPHTEXT', Locked = true;
        HEADERARROWID: Label '##HEADERARROW', Locked = true;
        HEADERCOLUMN: Label '#TA_HEADER', Locked = true;
        ACTIVEHEADERCOLUMN: Label '#TA_HEADER_ACTIVE', Locked = true;
        OVERLAYID: Label '#TA_LINES_FOCUS', Locked = true;
        DATAGRIDROW: Label '#TA_LINES', Locked = true;
        MARKEDDATAGRIDROW: Label '#TA_LINES_ACTIVE', Locked = true;
        GRIDLINECOLOR: Label '#GR_GRIDLINECOLOR', Locked = true;
    begin
        _defaultFonts.DeleteAll();
        _defaultSkins.DeleteAll();
        _defaultColors.DeleteAll();

        // ##Default##Default Skin/Font/Color:
        LoadDefaultSkin(Format("LSC POS Profile ID"::DefaultStyle), Format("LSC POS Profile ID"::DefaultStyle), _colors.LightGray, _colors.DarkGray, -1, 1, _colors.LightSlateGray, true, false);
        LoadDefaultFont(Format("LSC POS Profile ID"::DefaultStyle), Format("LSC POS Profile ID"::DefaultStyle), 'Tahoma', 11, -1, false);
        LoadDefaultColor(Format("LSC POS Profile ID"::DefaultStyle), Format("LSC POS Profile ID"::DefaultStyle), _colors.LightGray);

        // Special Fonts/Skins/Colors:
        LoadDefaultFont(Format("LSC POS Profile ID"::DefaultStyle), HEADERARROWID, 'Webdings', 11, -1, false); // pProfileID
        LoadDefaultFont(Format("LSC POS Profile ID"::DefaultStyle), GLYPHID, 'Arial Narrow', 9, -1, false); // pProfileID
        LoadDefaultFont(Format("LSC POS Profile ID"::DefaultStyle), GLYPHTEXTID, 'Arial Narrow', 9, -1, false); // pProfileID
        //LoadDefaultFont(Format("LSC POS Profile ID"::DefaultStyle), PREVIEWID, 'Tahoma', 11, -1, false); // pProfileID
        //LoadDefaultSkin(Format("LSC POS Profile ID"::DefaultStyle), PREVIEWID, -1, -1, -1, -1, -1, false, false);
        //LoadDefaultColor(Format("LSC POS Profile ID"::DefaultStyle), PREVIEWID, Color.White);
        LoadDefaultColor(Format("LSC POS Profile ID"::DefaultStyle), GRIDLINECOLOR, Color.LightGray);
        LoadDefaultSkin(Format("LSC POS Profile ID"::DefaultStyle), OVERLAYID, -1, -1, 75, 1, Color.LightBlue, false, false);
        LoadDefaultSkin(Format("LSC POS Profile ID"::DefaultStyle), HEADERCOLUMN, Color.ButtonShadow, Color.ButtonFace, -1, -1, -1, true, false);
        LoadDefaultFont(Format("LSC POS Profile ID"::DefaultStyle), HEADERCOLUMN, '', -1, Color.White, false);
        LoadDefaultSkin(Format("LSC POS Profile ID"::DefaultStyle), ACTIVEHEADERCOLUMN, Color.ButtonShadow, Color.ControlDarkDark, -1, -1, -1, true, false);
        LoadDefaultFont(Format("LSC POS Profile ID"::DefaultStyle), ACTIVEHEADERCOLUMN, '', -1, Color.White, false);
        //LoadDefaultSkin(Format("LSC POS Profile ID"::DefaultStyle), FONTPREVIEWSKINID, Color.White, -1, -1, -1, -1, false, false);
        //LoadDefaultSkin(Format("LSC POS Profile ID"::DefaultStyle), WHITEFONTPREVIEWSKINID, Color.LightGray, Color.White, -1, -1, -1, false, false);
        LoadDefaultSkin(Format("LSC POS Profile ID"::DefaultStyle), DATAGRIDROW, -1, -1, -1, -1, -1, false, true);
        LoadDefaultFont(Format("LSC POS Profile ID"::DefaultStyle), DATAGRIDROW, '', -1, -1, false);
        LoadDefaultSkin(Format("LSC POS Profile ID"::DefaultStyle), DISABLED, Color.LightGray, -1, 75, 1, Color.Gray, false, false); // pProfileID
        LoadDefaultFont(Format("LSC POS Profile ID"::DefaultStyle), DISABLED, '', -1, Color.LightGray, false); // pProfileID
        LoadDefaultFont(Format("LSC POS Profile ID"::DefaultStyle), MARKEDDATAGRIDROW, '', -1, Color.Navy, true);
    end;

    procedure GetResourcesJson(var pJsonUtil: Codeunit "Json Text Reader/Writer")
    begin
        GetResourcesJson(pJsonUtil, '', '', '', false);
    end;

    procedure GetResourcesJson(var pJsonUtil: Codeunit "Json Text Reader/Writer"; fontIdsFilter: Text; skinIdsFilter: Text; colorIdsFilter: Text; skipDefaultResources: Boolean)
    var
        fontIds: Dictionary of [Text, Text];
        skinIds: Dictionary of [Text, Text];
        colorIds: Dictionary of [Text, Text];
        recref: RecordRef;
        entityRecref: RecordRef;
        fontEntity: Record "LSC POS Font Entity";
        skinEntity: Record "LSC POS Button Skin Entity";
        profileFilter: Text;
    begin
        if not skipDefaultResources then
            CreateDefaultResourcesJson(_mainStyleProfileID);

        profileFilter := POSSESSION.CreateFilter(_mainStyleProfileID, _secondaryStyleProfileID, Format("LSC POS Profile ID"::DefaultStyle));
        pJsonUtil.WriteStartObject(Format("LSC POS String Request Type"::StyleProfile));
        pJsonUtil.WriteStringProperty('PosStyleID', _mainStyleProfileID);
        pJsonUtil.WriteStringProperty('SecondaryPosStyleID', _secondaryStyleProfileID);

        // 1. Execute single FindSet for all filters
        // 2. collect primary key from fallback hierarchy
        // 3. go reverse order and populate json with fields for found entries with highest priority
        // 4. iterate through default ids (if they weren't collected already in steps 2-3)

        pJsonUtil.WriteStartObject('Fonts');
        _fonts.SetFilter("Style Profile ID", profileFilter);
        _fonts.SetFilter("Code", fontIdsFilter);
        if _fonts.FindSet() then begin
            repeat
                AddToCollection(fontIds, _fonts."Code", _fonts."Style Profile ID");
            until _fonts.Next() = 0;
            repeat
                if IsInCollection(fontIds, _fonts."Code", _fonts."Style Profile ID") then begin
                    recref.GetTable(_fonts);
                    entityRecref.GetTable(fontEntity);
                    POSUTILS.WriteRecRefToJSON(_fonts."Code", entityRecref, recref, pJsonUtil);
                end;
            until _fonts.Next(-1) = 0;
        end;
        if _defaultFonts.FindSet() then
            repeat
                if _defaultFonts."Code" <> '' then
                    if not fontIds.ContainsKey(_defaultFonts."Code") then begin
                        recref.GetTable(_defaultFonts);
                        entityRecref.GetTable(fontEntity);
                        POSUTILS.WriteRecRefToJSON(_defaultFonts."Code", entityRecref, recref, pJsonUtil);
                    end;
            until _defaultFonts.Next() = 0;
        pJsonUtil.WriteEndObject(); //Fonts

        pJsonUtil.WriteStartObject('Skins');
        _skins.SetFilter("Style Profile ID", profileFilter);
        _skins.SetFilter("Code", skinIdsFilter);
        if _skins.FindSet() then begin
            repeat
                AddToCollection(skinIds, _skins."Code", _skins."Style Profile ID");
            until _skins.Next() = 0;
            repeat
                if IsInCollection(skinIds, _skins."Code", _skins."Style Profile ID") then begin
                    recref.GetTable(_skins);
                    entityRecref.GetTable(skinEntity);
                    POSUTILS.WriteRecRefToJSON(_skins."Code", entityRecref, recref, pJsonUtil);
                end;
            until _skins.Next(-1) = 0;
        end;
        if _defaultSkins.FindSet() then
            repeat
                if _defaultSkins."Code" <> '' then
                    if not skinIds.ContainsKey(_defaultSkins."Code") then begin
                        recref.GetTable(_defaultSkins);
                        entityRecref.GetTable(skinEntity);
                        POSUTILS.WriteRecRefToJSON(_defaultSkins."Code", entityRecref, recref, pJsonUtil);
                    end;
            until _defaultSkins.Next() = 0;
        pJsonUtil.WriteEndObject(); // Skins

        pJsonUtil.WriteStartObject('Colors');
        _colors.SetFilter("Style Profile ID", profileFilter);
        _colors.SetFilter("Code", colorIdsFilter);
        if _colors.FindSet() then begin
            repeat
                AddToCollection(colorIds, _colors."Code", _colors."Style Profile ID");
            until _colors.Next() = 0;
            repeat
                if IsInCollection(colorIds, _colors."Code", _colors."Style Profile ID") then
                    pJsonUtil.WriteNumberProperty(_colors."Code", _colors.Color);
            until _colors.Next(-1) = 0;
        end;
        if _defaultColors.FindSet() then
            repeat
                if _defaultColors."Code" <> '' then
                    if not colorIds.ContainsKey(_defaultColors."Code") then
                        pJsonUtil.WriteNumberProperty(_defaultColors."Code", _defaultColors.Color);
            until _defaultColors.Next() = 0;
        pJsonUtil.WriteEndObject(); // Colors
        pJsonUtil.WriteEndObject(); // StyleProfile
    end;

    local procedure AddToCollection(var d: Dictionary of [Text, Text]; pID: Text; pProfileID: Text)
    var
        prevProfileID: Text;
    begin
        if not d.ContainsKey(pID) then begin
            d.Add(pID, pProfileID);
            exit;
        end;
        prevProfileID := d.Get(pID);
        if true in [
            prevProfileID = _mainStyleProfileID, // if main profile is already loaded, skip
            prevProfileID = pProfileID // if same profile id, skip
        ] then
            exit;
        if pProfileID = Format("LSC POS Profile ID"::DefaultStyle) then
            if pProfileID <> _mainStyleProfileID then
                exit; // if main=DEFAULT and secondary=LOWERPRIORIY -> overwrite
        d.Set(pId, pProfileID); // pProfileID must be main/secondary (and secondary is not overwriting main)
    end;

    local procedure IsInCollection(var d: Dictionary of [Text, Text]; pId: Text; pProfileID: Text): Boolean
    begin
        if not d.ContainsKey(pId) then
            exit(false);
        exit(d.Get(pId) = pProfileID);
    end;
}
