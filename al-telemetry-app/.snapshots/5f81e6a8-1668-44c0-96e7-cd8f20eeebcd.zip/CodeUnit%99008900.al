codeunit 99008900 "LSC POS Functions" implements "LSC IFunctions"
{
    SingleInstance = true;

    var
        PosTrGuestInfo1: Record "LSC POS Trans. Guest Info";
        LastCouponPOSTransLine_Temp: Record "LSC POS Trans. Line" temporary;
        TmpPOSTransLine: Record "LSC POS Trans. Line" temporary;
        POSTransLineTemp: Record "LSC POS Trans. Line" temporary;
        POSTransLineTemp2: Record "LSC POS Trans. Line" temporary;
        DealPosTransLineTmp: Record "LSC POS Trans. Line" temporary;
        TmpPosTrInfoEntry: Record "LSC POS Trans. Infocode Entry" temporary;
        TmpPeriodicDiscountLine: Record "LSC Periodic Discount Line" temporary;
        TmpPreDiscAmountToTrigger: Record "LSC Periodic Discount" temporary;
        PreLoadDiscTmp: Record "LSC Periodic Discount" temporary;
        PreLoadDiscLineTmp: Record "LSC Periodic Discount Line" temporary;
        ValidationPeriodBuffer: Record "LSC Validation Period" temporary;
        TSUtil: Codeunit "LSC POS Trans. Server Utility";
        _Formatting: Codeunit "LSC POS Formatting";
        RboPriceUtil: Codeunit "LSC Retail Price Utils";
        PosSession: Codeunit "LSC POS Session";
        CustomerOrderSession: Codeunit "LSC Customer Order Session";
        PosCtrl: Codeunit "LSC POS Control Interface";
        BOUtils: Codeunit "LSC BO Utils";
        ItemTrack: Codeunit "LSC Retail Item Tracking";
        POSMemberMgt: Codeunit "LSC POS Member Mgt.";
        POSScanDataUtils: Codeunit "LSC POS Scan Data Utils";
        DiscLedgerMgt: Codeunit "LSC Discount Ledger Mgt.";
        LSHelper: Codeunit "LSC Helper";
        POSOfferMgt: Codeunit "LSC POS Offer Mgt";
        PosTransDisc: Codeunit "LSC POS Trans. Discounts";
        PostingExceptionUtility: Codeunit "LSC Posting Exception Utility";
        POSTransactionImpl: Codeunit "LSC POS Transaction Impl";
        ServiceLocator: Codeunit "LSC Service Locator";
        HospServiceLocator: Codeunit "LSC Hosp. Service Locator";
        LastOfferLoadTime: DateTime;
        BarcItem, BarcCoupRef, BarcCustomer : Code[20];
        BarcUOM, BarcStaff, BarcVariantCode : Code[10];
        BarcEANOrg: Code[13];
        BarcSerialNo, BarcLotNo : Code[50];
        BarcDataEntry: Code[22];
        BarcLineDiscount, BarcPrice, BarcQty : Decimal;
        OriginalRefundTransactionNo: Integer;
        SkipIncrementSlipno, PaymentState : Boolean;
        BarcPriceSpec, BarcQtySpec : Boolean;
        TransactionServerConnFailedErr: Label 'Transaction Server connection failed';
        TableMsg: Label 'Table %1';
        DoUseNumAnywayQst: Label 'Do you want to use the number anyway?';

    procedure ReadLocalVar(var LastSlipNo: Code[20])
    var
        Transaction: Record "LSC Transaction Header";
        PosTrans: Record "LSC POS Transaction";
        TmpLastSlip: Text[30];
        FilterFrom: Text[30];
        FilterTo: Text[30];
        ExistingReceiptNo: Code[20];
    begin
        LastSlipNo := POSSESSION.GetValue("LSC POS Tag"::"LastSlipNo_");
        if LastSlipNo = '' then
            LastSlipNo := '0';

        TmpLastSlip := ZeroPad(POSSESSION.TerminalNo, 10) +
          ZeroPad(LastSlipNo, 9);
        OnAfterSetLastSlip(TmpLastSlip, LastSlipNo);
        Transaction.SetCurrentKey("Receipt No.");

        FilterFrom := ZeroPad(POSSESSION.TerminalNo, 10) + ZeroPad('0', 9);
        FilterTo := ZeroPad(POSSESSION.TerminalNo, 10) + NumberPad('9', 9);
        OnBeforeApplyFilterToTransaction(Transaction, FilterFrom, FilterTo);
        Transaction.SetRange("Receipt No.", FilterFrom, FilterTo);

        ExistingReceiptNo := '';
        if Transaction.FindLast then
            if Transaction."Receipt No." > TmpLastSlip then
                ExistingReceiptNo := Transaction."Receipt No.";

        if ExistingReceiptNo <> '' then
            POSSESSION.SetValue("LSC POS Tag"::"LAST_POSTED_RECEIPT", ExistingReceiptNo);

        PosTrans.Reset;
        PosTrans.SetRange("Receipt No.", FilterFrom, FilterTo);
        if PosTrans.FindLast then
            if PosTrans."Receipt No." > TmpLastSlip then
                if PosTrans."Receipt No." > ExistingReceiptNo then
                    ExistingReceiptNo := PosTrans."Receipt No.";

        if ExistingReceiptNo <> '' then begin
            LastSlipNo := ExistingReceiptNo;
            SkipIncrementSlipno := false;
        end;

        FiscalProcessAtStart();
    end;

    procedure WriteLocalVar(LastSlipNo: Code[20])
    begin
        POSSESSION.SetValue("LSC POS Tag"::"LastSlipNo_", LastSlipNo);
    end;

    procedure InitPosFunctions()
    var
        PosFuncProfile: Record "LSC POS Func. Profile";
        BackgroundMgt: Codeunit "LSC Background Mgt";
        PostExStoreGr: Code[20];
        ErrorMessage: text;
    begin
        _Formatting.Init();
        PostingExceptionUtility.InitPostException;
        if PostingExceptionUtility.FindPostExStoreGroup(PosSession.Store."No.", PostExStoreGr) then
            PostingExceptionUtility.SetPostExStoreGroup(PostExStoreGr);
        //TransServer
        if not TSUtil.Initialize then;
        //Background Session
        PosFuncProfile := PosSession.FunctionalityProfile();
        if PosFuncProfile."Use Background Session" then begin
            BackgroundMgt.SendTransaction;
            ErrorMessage := BackgroundMgt.GetSendTransactionLastStatus;
            if ErrorMessage <> '' then
                POSSESSION.SetValue("LSC POS Tag"::"TS_ERROR", CopyStr(ErrorMessage, 1, 250));
        end;
        If PosFuncProfile."Run AzS Repl. In Background" then begin
            BackgroundMgt.AzureStorageReplUpdateSession();
            ErrorMessage := BackgroundMgt.GetAzSReplUpdateLastStatus();
            IF ErrorMessage <> '' then
                POSSESSION.SetValue("LSC POS Tag"::"AZS_ERROR", CopyStr(ErrorMessage, 1, 250));
        end;
        If PosFuncProfile."Keep Sch. Job Queue Entr Ready" then begin
            BackgroundMgt.JobQueueUpdateSession();
            ErrorMessage := BackgroundMgt.GetJobQueueLastStatus();
            IF ErrorMessage <> '' then
                POSSESSION.SetValue("LSC POS Tag"::"JQ_ERROR", CopyStr(ErrorMessage, 1, 250));
        end;
    end;

    procedure CalcInfoCodeDisc(Transaction: Record "LSC POS Transaction")
    var
        Line: Record "LSC POS Trans. Line";
    begin
        Line.SetCurrentKey("Receipt No.", "Entry Type", Number, "Variant Code");
        Line.SetRange("Receipt No.", Transaction."Receipt No.");
        Line.SetRange("Entry Type", Line."Entry Type"::Item);
        if Line.FindSet then
            repeat
                Line.Validate("Item Disc. Group");
                Line.Modify;
            until Line.Next = 0;
    end;

    procedure RecalcSlip(Transaction: Record "LSC POS Transaction")
    var
        Line: Record "LSC POS Trans. Line";
        Item: Record Item;
        DT: Record "LSC POS Trans. Per. Disc. Type";
        RetailPriceUtils: Codeunit "LSC Retail Price Utils";
        POSPriceUtil: Codeunit "LSC POS Price Utility";
        PosOfferExt: Codeunit "LSC POS Offer Ext. Utility";
        UOM: Code[10];
        Qty: Decimal;
        UnitPrice: Decimal;
        CustDiscPer: Decimal;
        UnitPriceToUse: Decimal;
        LineDiscount: Decimal;
        IsHandled: Boolean;
    begin
        InitPosFunctions;
        Line.SetCurrentKey("Receipt No.", "Entry Type", Number, "Variant Code");
        Line.SetRange("Receipt No.", Transaction."Receipt No.");
        Line.SetRange("Entry Type", Line."Entry Type"::Item);
        Line.SetRange("Entry Status", Line."Entry Status"::" ");
        Line.SetRange("Exchange Line", false);
        if POSTransactionImpl.IsCollectingOrder() then
            Line.setrange("Customer order line", false);

        if Line.FindSet(true) then
            repeat
                Line.Validate("Item Disc. Group");
                Line.Modify();
                if (Transaction."Customer No." <> '') or (Transaction."Member Price Group" <> '')
                   or ((Transaction."Member Card No." <> '') and (Transaction."Customer Disc. Group" <> ''))
                then begin
                    Line.SetRange(Number, Line.Number);
                    Line.SetRange("Variant Code", Line."Variant Code");
                    Line.SetRange("Unit of Measure", Line."Unit of Measure");
                    UOM := Line."Unit of Measure";
                    Item.Get(Line.Number);
                    if (Line."Unit of Measure" = '') or (Line."Unit of Measure" = Item."Sales Unit of Measure") then begin
                        Line.SetFilter("Unit of Measure", '%1|%2', '', Item."Sales Unit of Measure");
                        Line.CalcSums(Quantity);
                        Line.SetRange("Unit of Measure", Line."Unit of Measure");
                        UOM := Item."Sales Unit of Measure";
                    end else
                        Line.CalcSums(Quantity);
                    Qty := Line.Quantity;
                    LineDiscount := 0;
                    if Transaction."Customer No." <> '' then
                        UnitPrice := RetailPriceUtils.GetStandardCustomerPrice(Transaction."Customer No.", Line.Number, Line."Variant Code",
                  UOM, Qty, Transaction."Trans. Date", Transaction."Trans. Currency Code", LineDiscount)
                    else
                        UnitPrice := RetailPriceUtils.GetStandardMemberPrice(Transaction."Member Price Group", Transaction."Customer Disc. Group",
                  Line.Number, Line."Variant Code",
                  UOM, Qty, Line."Org. Price Exc. VAT", Transaction."Trans. Date", Transaction."Trans. Currency Code", LineDiscount);
                    OnAfterCalculateUnitPrice(Transaction, Line, UnitPrice);
                    Item.Get(Line.Number);
                    if not PosSession.FunctionalityProfile."No VAT Used" and not PosSession.FunctionalityProfile."Add VAT to Prices" then
                        UnitPrice := RetailPriceUtils.CalcPriceInclVat(Item, UnitPrice, Line."Vat Bus. Posting Group");

                    Line.FindSet;
                    repeat
                        if (Line."Price Change") or (Line."System-Unchangable Price") then
                            UnitPriceToUse := 0
                        else
                            UnitPriceToUse := UnitPrice;
                        Line.Validate("Customer Price", UnitPriceToUse);
                        Line.Validate("Item Disc. Group");
                        Line.Modify(true);
                    until Line.Next = 0;
                    Line.SetRange(Number);
                    Line.SetRange("Variant Code");
                    Line.SetRange("Unit of Measure");
                end;
            until Line.Next = 0;

        if (Transaction."Customer No." <> '') or (Transaction."Member Price Group" <> '') or (Transaction."Customer Disc. Group" <> '') then
            if Line.FindSet then
                repeat
                    if not PosSession.FunctionalityProfile."Disable Customer Prices" then begin
                        OnBeforeApplyCustomerDiscount(Transaction, Line, IsHandled);
                        if not IsHandled then begin
                            POSPriceUtil.GetTransDisc(Line, false, DT.DiscType::"Periodic Disc.");
                            if POSPriceUtil.IsPerDiscType(Line, DT."Periodic Disc. Type"::"Mix&Match") then begin
                                if (Line.Quantity > Line."Quantity Discounted") and (Line."Customer Price" < Line.Price)
                                and (Line."Customer Price" <> 0)
                                then begin
                                    Line."Customer Qty Used" := Line.Quantity - Line."Quantity Discounted";

                                    CustDiscPer := (1 - Line."Customer Price" / Line.Price) * 100 * Line."Customer Qty Used" / Line.Quantity;
                                    POSPriceUtil.InsertTransDiscPercent(Line, CustDiscPer, DT.DiscType::Customer, '');

                                    Line.CalcPrices;
                                    Line.Modify;
                                    Line.ReCalcTotalDiscount;
                                end;
                            end
                            else begin
                                if ((Line."Customer Price" <> 0) or (LineDiscount = 100)) and
                                (Round(Line."Customer Price", PosSession.FunctionalityProfile."Price Rounding to") < Line.Price * (100 - Line."Periodic Disc. %") / 100)
                                then begin
                                    if Line."Periodic Disc. %" <> 0 then begin
                                        POSPriceUtil.InsertTransDiscPercent(Line, 0, DT.DiscType::"Periodic Disc.", '');

                                        Line."Quantity Discounted" := 0;
                                        Line.Modify;
                                        Line.UpdatePerDiscInfoLine;
                                    end;
                                    Line."Customer Qty Used" := Line.Quantity;

                                    CustDiscPer := (1 - Line."Customer Price" / Line.Price) * 100;
                                    POSPriceUtil.InsertTransDiscPercent(Line, CustDiscPer, DT.DiscType::Customer, '');

                                    Line.CalcPrices;
                                    Line.Modify;
                                    Line.ReCalcTotalDiscount;
                                end;
                            end;
                            Line.Modify;
                        end;
                    end;
                until Line.Next = 0;

        if Line.FindSet then
            repeat
                PosOfferExt.ProcessLinePreTotal(Transaction, Line, '');
            until Line.Next = 0;
    end;

    procedure Suspend(var SlipNumber: Code[20]; POSTransaction: Record "LSC POS Transaction"; var PaymentSlip: Code[20]; var TmpPosItemTransLines: Record "LSC POS Trans. Line" temporary; var LastSlipNo: Code[20]; var SendPOSTransSuccess: Boolean)
    var
        SuspPOSTransaction: Record "LSC POS Transaction";
        TransLine: Record "LSC POS Trans. Line";
        SuspTransLine: Record "LSC POS Trans. Line";
        InfoEntry: Record "LSC POS Trans. Infocode Entry";
        VoucherEntry: Record "LSC Voucher Entries";
        DataEntry: Record "LSC POS Data Entry";
        TmpPaymentTransLine: Record "LSC POS Trans. Line" temporary;
        TmpInfoEntry: Record "LSC POS Trans. Infocode Entry" temporary;
        TmpVoucherEntry: Record "LSC Voucher Entries" temporary;
        TmpDataEntry: Record "LSC POS Data Entry" temporary;
        SalesType: Record "LSC Sales Type";
        DataEntry2: Record "LSC POS Data Entry";
        TransLine2: Record "LSC POS Trans. Line";
        PaymentPOSTransaction: Record "LSC POS Transaction";
        TotAmount: Decimal;
        LineNo: Integer;
        InsertSuspLine: Boolean;
        TrainingActive: Boolean;
        Handled: Boolean;
        Text261: Label 'Prepayment - %1';
    begin
        ClearTransBenefitBuffer;

        OnBeforeSuspended(SlipNumber, POSTransaction, PaymentSlip, tmpPosItemTransLines, LastSlipNo, SendPOSTransSuccess, Handled);
        if Handled then
            Exit;

        TransLine.Reset;
        TransLine.SetCurrentKey("Receipt No.", "Entry Type", "Entry Status");
        TransLine.SetRange("Receipt No.", POSTransaction."Receipt No.");
        TransLine.SetRange("Entry Type", TransLine."Entry Type"::Item);
        TransLine.SetRange("Entry Status", TransLine."Entry Status"::" ");
        TransLine.SetRange("Benefit Item", true);
        if TransLine.FindSet then
            repeat
                if TransLine2.Get(POSTransaction."Receipt No.", TransLine."Line No.") then
                    TransLine2.VoidLine;
            until TransLine.Next = 0;

        TotAmount := 0;
        TmpPaymentTransLine.DeleteAll;
        TmpInfoEntry.DeleteAll;
        TmpDataEntry.DeleteAll;
        PaymentSlip := '';

        SuspPOSTransaction.TransferFields(POSTransaction);
        if SlipNumber <> '' then
            SuspPOSTransaction."Receipt No." := SlipNumber
        else
            SuspPOSTransaction."Receipt No." := POSTransaction."Receipt No.";
        SuspPOSTransaction."POS Terminal No." := '';
        SuspPOSTransaction."Retrieved from Receipt No." := POSTransaction."Retrieved from Receipt No.";
        SuspPOSTransaction."Retrieved from Store No." := POSTransaction."Retrieved from Store No.";
        SuspPOSTransaction."Retrieved from POS Term. No." := POSTransaction."Retrieved from POS Term. No.";
        SuspPOSTransaction."Retrieved from Trans. No." := POSTransaction."Retrieved from Trans. No.";
        SuspPOSTransaction."Entry Status" := SuspPOSTransaction."Entry Status"::Suspended;
        SuspPOSTransaction."Customer Order" := POSTransaction."Customer Order";

        TransLine.Reset;
        TransLine.SetRange("Receipt No.", POSTransaction."Receipt No.");
        if TransLine.FindSet then
            repeat
                InsertSuspLine := false;
                if TransLine."Entry Type" <> TransLine."Entry Type"::Payment then begin
                    SuspTransLine.TransferFields(TransLine, true);
                    SuspTransLine."Receipt No." := SuspPOSTransaction."Receipt No.";
                    SuspTransLine."POS Terminal No." := SuspPOSTransaction."POS Terminal No.";
                    SuspTransLine."Customer Order Line" := TransLine."Customer Order Line";
                    SuspTransLine.Marked := TransLine.Marked;
                    InsertSuspLine := true;
                end
                else begin
                    TmpPaymentTransLine.TransferFields(TransLine);
                    TmpPaymentTransLine.Insert;
                    if TmpPaymentTransLine."Entry Status" = TmpPaymentTransLine."Entry Status"::" " then
                        TotAmount += TmpPaymentTransLine.Amount;
                end;
                if (TransLine."Entry Type" = TransLine."Entry Type"::Item) or
                    (TransLine."Entry Type" = TransLine."Entry Type"::IncomeExpense)
                then begin
                    TmpPosItemTransLines := TransLine;
                    TmpPosItemTransLines.Insert;
                end;
                TransLine2.Get(TransLine."Receipt No.", TransLine."Line No.");
                TransLine2.Delete;
                if InsertSuspLine then
                    SuspTransLine.Insert;
            until TransLine.Next = 0;

        InfoEntry.SetRange("Receipt No.", POSTransaction."Receipt No.");
        if InfoEntry.FindSet then
            repeat
                if TmpPaymentTransLine.Get(POSTransaction."Receipt No.", InfoEntry."Line No.") then begin
                    TmpInfoEntry := InfoEntry;
                    TmpInfoEntry.Insert;
                    InfoEntry.Delete;
                end;
            until InfoEntry.Next = 0;

        VoucherEntry.SetRange("Receipt Number", POSTransaction."Receipt No.");
        if VoucherEntry.FindSet then
            repeat
                if TmpPaymentTransLine.Get(POSTransaction."Receipt No.", VoucherEntry."Line No.") then begin
                    TmpVoucherEntry := VoucherEntry;
                    TmpVoucherEntry.Insert;
                    VoucherEntry.Delete;
                end;
            until VoucherEntry.Next = 0;

        DataEntry.SetCurrentKey("Created by Receipt No.");
        DataEntry.SetRange("Created by Receipt No.", POSTransaction."Receipt No.");
        if DataEntry.FindSet then
            repeat
                if TmpPaymentTransLine.Get(POSTransaction."Receipt No.", DataEntry."Created by Line No.") then begin
                    TmpDataEntry := DataEntry;
                    TmpDataEntry.Insert;
                end;
            until DataEntry.Next = 0;

        DataEntry.SetCurrentKey("Applied by Receipt No.");
        DataEntry.SetRange("Applied by Receipt No.", POSTransaction."Receipt No.");
        if DataEntry.FindSet then
            repeat
                if TmpPaymentTransLine.Get(POSTransaction."Receipt No.", DataEntry."Applied by Line No.") then begin
                    TmpDataEntry := DataEntry;
                    TmpDataEntry.Insert;
                end;
            until DataEntry.Next = 0;

        if TotAmount <> 0 then begin
            //Create Payment POS Transaction Header
            if POSTransaction."Entry Status" = POSTransaction."Entry Status"::Training then
                TrainingActive := true;

            PaymentSlip := InsertTmpTrans(LastSlipNo, '', '', 0, TrainingActive, '');
            SelectLatestVersion;
            PaymentPOSTransaction.Get(PaymentSlip);
            PaymentPOSTransaction.TransferFields(POSTransaction, false);
            PaymentPOSTransaction."Receipt No." := PaymentSlip;
            PaymentPOSTransaction.Modify;

            SalesType.Get(SuspPOSTransaction."Sales Type");
            SuspTransLine.SetRange("Receipt No.", SuspPOSTransaction."Receipt No.");
            if SuspTransLine.FindLast then;
            SuspTransLine.Init;
            SuspTransLine."Receipt No." := SuspPOSTransaction."Receipt No.";
            SuspTransLine."Line No." += 10000;
            SuspTransLine."Parent Line" := SuspTransLine."Line No.";
            SuspTransLine."Store No." := SuspPOSTransaction."Store No.";
            SuspTransLine."POS Terminal No." := SuspPOSTransaction."POS Terminal No.";
            SuspTransLine."Entry Type" := SuspTransLine."Entry Type"::IncomeExpense;
            SuspTransLine.Validate(Number, SalesType."Prepayment Account No.");
            SuspTransLine.Validate(Amount, -TotAmount);
            OnBeforeSuspTransLineInsert(SuspTransLine);
            SuspTransLine.InsertLine;
            SuspTransLine.Description := StrSubstNo(Text261, Today);
            SuspTransLine."Parent Transaction Doc. No." := POSTransaction."Receipt No.";
            OnBeforeModifyPrepayIncExpLineOnSuspPOSTrans(PaymentSlip, SuspTransLine);
            SuspTransLine.Modify;

            TmpPosItemTransLines := SuspTransLine;
            TmpPosItemTransLines.Insert;

            LineNo := 10000;
            TransLine.Init;
            TransLine."Receipt No." := PaymentSlip;
            TransLine."Line No." := LineNo;
            TransLine."Parent Line" := LineNo;
            TransLine."Store No." := POSTransaction."Store No.";
            TransLine."POS Terminal No." := POSTransaction."POS Terminal No.";
            TransLine."Entry Type" := TransLine."Entry Type"::IncomeExpense;
            TransLine.Validate(Number, SalesType."Prepayment Account No.");
            TransLine.Validate(Amount, TotAmount);
            OnBeforeTransLineInsert(TransLine);
            TransLine.InsertLine;
            TransLine.Description := StrSubstNo(Text261, Today);
            TransLine.Modify;
            if TmpPaymentTransLine.FindSet then
                repeat
                    LineNo += 10000;
                    TransLine := TmpPaymentTransLine;
                    TransLine."Receipt No." := PaymentSlip;
                    TransLine."Line No." := LineNo;
                    TransLine."Parent Line" := LineNo;
                    TransLine.Insert;

                    InfoEntry.Reset;
                    TmpInfoEntry.SetRange("Line No.", TmpPaymentTransLine."Line No.");
                    if TmpInfoEntry.FindSet then
                        repeat
                            InfoEntry := TmpInfoEntry;
                            InfoEntry."Receipt No." := PaymentSlip;
                            InfoEntry."Line No." := TransLine."Line No.";
                            InfoEntry.Insert;
                        until TmpInfoEntry.Next = 0;

                    VoucherEntry.Reset;
                    TmpVoucherEntry.SetRange("Line No.", TmpPaymentTransLine."Line No.");
                    if TmpVoucherEntry.FindSet then
                        repeat
                            VoucherEntry := TmpVoucherEntry;
                            VoucherEntry."Receipt Number" := PaymentSlip;
                            VoucherEntry."Line No." := TransLine."Line No.";
                            VoucherEntry.Insert;
                        until TmpVoucherEntry.Next = 0;

                    DataEntry.Reset;
                    TmpDataEntry.SetRange("Created by Line No.", TmpPaymentTransLine."Line No.");
                    if TmpDataEntry.FindSet then
                        repeat
                            DataEntry := TmpDataEntry;
                            DataEntry2."Created by Receipt No." := PaymentSlip;
                            DataEntry."Created by Line No." := TransLine."Line No.";
                            DataEntry.Modify;
                        until TmpDataEntry.Next = 0;

                    DataEntry.Reset;
                    TmpDataEntry.SetRange("Applied by Line No.", TmpPaymentTransLine."Line No.");
                    if TmpDataEntry.FindSet then
                        repeat
                            DataEntry := TmpDataEntry;
                            DataEntry2."Applied by Receipt No." := PaymentSlip;
                            DataEntry."Applied by Line No." := TransLine."Line No.";
                            DataEntry.Modify;
                        until TmpDataEntry.Next = 0;
                until TmpPaymentTransLine.Next = 0;
        end;
        POSTransaction.Delete;
        SuspPOSTransaction.Insert;
        SlipNumber := SuspPOSTransaction."Receipt No.";

        if PosSession.FunctionalityProfile."TS Susp./Retrieve" then
            if not TSUtil.SendPOSTrans(SuspPOSTransaction, '', 'SendPosTransSusp') then
                SendPOSTransSuccess := false;

        OnAfterSuspend(SuspPOSTransaction, SendPOSTransSuccess);
    end;

    procedure RetrieveSusp(SlipNumber: Code[20]; var POSTransaction: Record "LSC POS Transaction"; var ErrorText: Text): Boolean
    var
        SuspPosTransaction: Record "LSC POS Transaction";
        SuspTransLine: Record "LSC POS Trans. Line";
        POSTransactionTemp: Record "LSC POS Transaction" temporary;
        POSTransLineTemp: Record "LSC POS Trans. Line" temporary;
        POSTransPeriodicDiscTemp: Record "LSC POS Trans. Per. Disc. Type" temporary;
        POSTransInfocodeEntryTemp: Record "LSC POS Trans. Infocode Entry" temporary;
        POSDataEntryTemp: Record "LSC POS Data Entry" temporary;
        VoucherEntriesTemp: Record "LSC Voucher Entries" temporary;
        OfferPosCalculationTemp: Record "LSC Offer Pos Calculation" temporary;
        POSOrderHeaderTemp: Record "LSC POS Order Header" temporary;
        POSOrderLineTemp: Record "LSC POS Order Line" temporary;
        OptionTypeValueHeaderTemp: Record "LSC Option Type Value Header" temporary;
        OptionTypeValueEntryTemp: Record "LSC Option Type Value Entry" temporary;
        POSTransInfoDataEntryTemp: Record "LSC POS Trans. InfoData Entry" temporary;
        POSTransAddSalespersonTemp: Record "LSC POS Trans. Add. Salesp." temporary;
        RetailCalendar: Record "LSC Retail Calendar";
        POSOrderHeader: Record "LSC POS Order Header";
        POSOrderLine: Record "LSC POS Order Line";
        RetailCalendarManagement: Codeunit "LSC Retail Calendar Management";
        GetPosTransSuspUtils: Codeunit LSCGetPosTransSuspUtils;
        ProcessCode: Code[30];
        ModifyOk, Result, IsHandled : Boolean;
        MemberErrorText: Label 'Member removed from suspended transaction due to - %1';
    begin
        Commit;
        CurrentTransactionType(TRANSACTIONTYPE::Update);
        OnBeforeRetriveSusp(SlipNumber, POSTransaction, ErrorText, Result, IsHandled);
        if IsHandled then
            exit(Result);

        if PosSession.FunctionalityProfile."TS Susp./Retrieve" then begin
            OnBeforeGetPosTransSusp(PosSession.FunctionalityProfile."Profile ID", SlipNumber, POSTransactionTemp, POSTransLineTemp, POSTransPeriodicDiscTemp,
                                   POSTransInfocodeEntryTemp, POSDataEntryTemp, VoucherEntriesTemp, OfferPosCalculationTemp, POSOrderHeaderTemp,
                                   POSOrderLineTemp, OptionTypeValueHeaderTemp, OptionTypeValueEntryTemp, POSTransInfoDataEntryTemp,
                                   POSTransAddSalespersonTemp, ProcessCode, ErrorText, IsHandled);
            if not IsHandled then begin
                GetPosTransSuspUtils.SetPosFunctionalityProfile(PosSession.FunctionalityProfile."Profile ID");
                GetPosTransSuspUtils.SendRequest(SlipNumber, POSTransactionTemp, POSTransLineTemp, POSTransPeriodicDiscTemp, POSTransInfocodeEntryTemp, POSDataEntryTemp, VoucherEntriesTemp, OfferPosCalculationTemp, POSOrderHeaderTemp, POSOrderLineTemp, OptionTypeValueHeaderTemp, OptionTypeValueEntryTemp, POSTransInfoDataEntryTemp, POSTransAddSalespersonTemp, ProcessCode, ErrorText);
            end;
            if ErrorText <> '' then
                exit(false);
        end;

        if not SuspPosTransaction.Get(SlipNumber) then
            exit(false);

        POSTransaction := SuspPosTransaction;
        POSTransaction."Trans. Date" := Today;
        POSTransaction."Trans Time" := Time;
        POSTransaction."Entry Status" := POSTransaction."Entry Status"::" ";
        POSTransaction."Trans. Date" :=
          RetailCalendarManagement.GetStoreTransactionDate(
            PosSession.Store."No.", RetailCalendar."Calendar Type"::"Opening Hours",
            POSTransaction."Trans. Date", POSTransaction."Trans Time");

        POSTransaction."Store No." := POSSESSION.StoreNo;
        POSTransaction."POS Terminal No." := POSSESSION.TerminalNo;
        POSTransaction."Staff ID" := POSSESSION.StaffID;

        POSTransaction.Modify;

        if POSOrderHeader.Get(SuspPosTransaction."Receipt No.") then begin
            POSOrderHeader."Store No." := POSSESSION.StoreNo;
            POSOrderHeader."POS No." := POSSESSION.TerminalNo;
            POSOrderHeader.Modify;
        end;

        SuspTransLine.Reset;
        SuspTransLine.SetRange("Receipt No.", POSTransaction."Receipt No.");
        if SuspTransLine.FindSet then
            repeat
                ModifyOk := false;
                if SuspTransLine."Store No." <> POSSESSION.StoreNo then begin
                    SuspTransLine."Store No." := POSSESSION.StoreNo;
                    ModifyOk := true;
                end;
                if SuspTransLine."POS Terminal No." <> POSSESSION.TerminalNo then begin
                    SuspTransLine."POS Terminal No." := POSSESSION.TerminalNo;
                    ModifyOk := true;
                end;
                if ModifyOk then
                    SuspTransLine.Modify;
            until SuspTransLine.Next = 0;

        if POSOrderHeader.Get(SlipNumber) then
            if (POSOrderHeader."Store No." <> POSSESSION.StoreNo) or (POSOrderHeader."POS No." <> POSSESSION.TerminalNo) then begin
                POSOrderHeader."Store No." := POSSESSION.StoreNo;
                POSOrderHeader."POS No." := POSSESSION.TerminalNo;
                POSOrderHeader.Modify;
                POSOrderLine.SetRange("Receipt No.", SlipNumber);
                POSOrderLine.ModifyAll("Store No.", POSSESSION.StoreNo);
                POSOrderLine.ModifyAll("POS Terminal No.", POSSESSION.TerminalNo);
            end;

        if PosSession.FunctionalityProfile."TS Susp./Retrieve" then
            TSUtil.DeletePOSTrans(SlipNumber);
        if POSTransaction."Member Card No." <> '' then
            if not GetMemberInfoForPos(POSTransaction."Member Card No.", ProcessCode, ErrorText) then begin
                ClearMemberInfo();
                POSTransaction."Member Card No." := '';
                POSTransaction."Member Price Group" := '';
                POSTransaction.Modify();
                SuspTransLine.Reset;
                SuspTransLine.SetRange("Receipt No.", POSTransaction."Receipt No.");
                SuspTransLine.SetRange("Text Type", SuspTransLine."Text Type"::"Member Text");
                if SuspTransLine.FindFirst then
                    SuspTransLine.Delete();
                PosCtrl.PosMessage(StrSubstNo(MemberErrorText, ErrorText))
            end;
        SkipIncrementSlipno := true;

        exit(true);
    end;

    procedure CopyToVoidedTrans(SlipHeader: Record "LSC POS Transaction")
    var
        SlipLine: Record "LSC POS Trans. Line";
        InfoCodeEntry: Record "LSC POS Trans. Infocode Entry";
        VoidedHeader: Record "LSC POS Voided Transaction";
        VoidedLine: Record "LSC POS Voided Trans. Line";
        VoidedInfoCodeEntry: Record "LSCPOSVoidedInfocodeEntry";
    begin
        SlipHeader.Get(SlipHeader."Receipt No.");
        VoidedHeader.TransferFields(SlipHeader);
        VoidedHeader.Insert(true);
        SlipLine.SetRange("Receipt No.", SlipHeader."Receipt No.");
        if SlipLine.FindSet then
            repeat
                VoidedLine.TransferFields(SlipLine);
                if (SlipLine."Trans. Date" = 0D) and (SlipLine."Trans. Time" = 0T) then begin
                    VoidedLine."Trans. Date" := SlipHeader."Trans. Date";
                    VoidedLine."Trans. Time" := SlipHeader."Trans Time";
                end;
                OnBeforeInsertPOSVoidedTransLine(VoidedLine, SlipHeader);
                if VoidedLine.Insert(true) then
                    SlipLine.VoidApplInfo(false);
            until SlipLine.Next = 0;

        InfoCodeEntry.SetRange("Receipt No.", SlipHeader."Receipt No.");
        if InfoCodeEntry.FindSet then
            repeat
                VoidedInfoCodeEntry.init;
                VoidedInfoCodeEntry."Entry No." := 0;
                VoidedInfoCodeEntry.TransferFields(InfoCodeEntry);
                VoidedInfoCodeEntry.Insert(true);
            until InfoCodeEntry.Next = 0;
    end;

    procedure LoadItem(var Line: Record "LSC POS Trans. Line"): Boolean
    var
        Barcode: Record "LSC Barcodes";
        Item: Record Item;
        BarcodeMask: Record "LSC Barcode Mask";
        ItemStatusLink: Record "LSC Item Status Link";
        BcUtil: Codeunit "LSC Barcode Management";
        IsHandled, ReturnValue : Boolean;
    begin
        OnBeforeLoadItem(Line, IsHandled, ReturnValue);
        if IsHandled then
            exit(ReturnValue);

        if Barcode.Get(Line.Number) then begin
            if Item.Get(Barcode."Item No.") then begin
                Line."Barcode No." := Line.Number;
                Line.Number := Barcode."Item No.";
                Line."Variant Code" := Barcode."Variant Code";
                Line."Unit of Measure" := Barcode."Unit of Measure Code";
                Line."Scale Item" := Item."LSC Scale Item";
                Line."System-Block Manual Discount" := Item."LSC No Discount Allowed";
                Line.Description := Barcode.Description;
                if BOUtils.IsBlockManualDiscount(Item."No.", '', Line."Variant Code", PosSession.Store."No.", PosSession.Store."Location Code", Today, ItemStatusLink) then
                    Line."System-Block Manual Discount" := true;
                if BOUtils.IsBlockPromotionDiscount(Item."No.", '', Line."Variant Code", PosSession.Store."No.", PosSession.Store."Location Code", Today, ItemStatusLink) then
                    Line."System-Block Promotion Price" := true;
                if BOUtils.IsBlockOfferDiscount(Item."No.", '', Line."Variant Code", PosSession.Store."No.", PosSession.Store."Location Code", Today, ItemStatusLink) then
                    Line."System-Exclude from Offers" := true;
                if BOUtils.IsBlockManualPriceChange(Item."No.", '', Line."Variant Code", PosSession.Store."No.", PosSession.Store."Location Code", Today, ItemStatusLink) then
                    Line."System-Unchangable Price" := true;
                OnAfterLoadItem(Line, Item);
                exit(true);
            end else
                exit(false);
        end else
            if not Item.Get(Line.Number) then
                if BcUtil.FindBarcodeMask(Line.Number, BarcodeMask) and (BarcodeMask.Type = BarcodeMask.Type::Item) then begin
                    BarcodeMask.CalcFields(Length);
                    if StrLen(Line.Number) = (BarcodeMask.Length + StrLen(BarcodeMask.Prefix)) then begin
                        ProcessMaskSegments(Line.Number, BarcodeMask);
                        if BarcItem = '' then
                            exit(false);
                        Item.Get(BarcItem);
                        Line."Barcode No." := Line.Number;
                        Line.Number := BarcItem;
                        if BarcUOM = '' then
                            BarcUOM := Item."Sales Unit of Measure";
                        Line."Unit of Measure" := BarcUOM;
                        if BarcQty <> 0 then begin
                            Line.Quantity := BarcQty;
                            Line."Quantity in Barcode" := true;
                        end;
                        if BarcPrice <> 0 then begin
                            Line.Amount := BarcPrice;
                            Line."Price in Barcode" := true;
                        end;
                        if BarcLineDiscount <> 0 then
                            Line."Line Disc. %" := BarcLineDiscount;

                        if BarcSerialNo <> '' then
                            Line."Serial No." := BarcSerialNo;
                        if BarcLotNo <> '' then
                            Line."Lot No." := BarcLotNo;

                        if BarcVariantCode <> '' then
                            Line."Variant Code" := BarcVariantCode;
                    end else
                        exit(false);
                end else
                    exit(false);

        if Item."LSC Scale Item" then begin
            Line."Scale Item" := Item."LSC Scale Item";
            Line."Unit of Measure" := Item."Sales Unit of Measure";
        end;

        Line."System-Block Manual Discount" := Item."LSC No Discount Allowed";
        if BOUtils.IsBlockManualDiscount(Item."No.", '', Line."Variant Code", PosSession.Store."No.", PosSession.Store."Location Code", Today, ItemStatusLink) then
            Line."System-Block Manual Discount" := true;
        if BOUtils.IsBlockPromotionDiscount(Item."No.", '', Line."Variant Code", PosSession.Store."No.", PosSession.Store."Location Code", Today, ItemStatusLink) then
            Line."System-Block Promotion Price" := true;
        if BOUtils.IsBlockOfferDiscount(Item."No.", '', Line."Variant Code", PosSession.Store."No.", PosSession.Store."Location Code", Today, ItemStatusLink) then
            Line."System-Exclude from Offers" := true;
        if BOUtils.IsBlockManualPriceChange(Item."No.", '', Line."Variant Code", PosSession.Store."No.", PosSession.Store."Location Code", Today, ItemStatusLink) then
            Line."System-Unchangable Price" := true;
        OnAfterDirectLoadItem(Line, Item);
        exit(true);
    end;

    internal procedure FindVariant(var PosVariant: Record "Item Variant"; ItemNo: Code[20]): Integer
    begin
        PosVariant.SetCurrentKey("Item No.");
        PosVariant.SetRange("Item No.", ItemNo);
        if PosVariant.FindFirst then;
        exit(PosVariant.Count);
    end;

    local procedure ProcessMaskSegments(Barcode: Text[22]; Mask: Record "LSC Barcode Mask"): Boolean
    var
        Segment: Record "LSC Barcode Mask Segment";
        BarcodeRec: Record "LSC Barcodes";
        Item: Record Item;
        Customer: Record Customer;
        Staff: Record "LSC Staff";
        LDataEntry: Record "LSC POS Data Entry Type";
        Chr: Text[1];
        TmpCode: Code[22];
        TmpInt: Integer;
        Chk: Integer;
        Pos: Integer;
    begin
        Clear(BarcQty);
        Clear(BarcPrice);
        Clear(BarcItem);
        Clear(BarcUOM);
        Clear(BarcEANOrg);
        Clear(BarcCustomer);
        Clear(BarcStaff);
        Clear(BarcQtySpec);
        Clear(BarcPriceSpec);
        Clear(BarcCoupRef);
        Clear(BarcSerialNo);
        Clear(BarcLotNo);
        Clear(BarcLineDiscount);
        Clear(BarcVariantCode);
        Clear(BarcDataEntry);
        Pos := StrLen(Mask.Prefix) + 1;
        Segment.SetRange("Mask Entry No.", Mask."Entry No.");
        if Segment.FindSet then
            repeat
                case Segment.Type of
                    Segment.Type::Quantity:
                        begin
                            if Evaluate(BarcQty, CopyStr(Barcode, Pos, Segment.Length)) then begin
                                BarcQty := BarcQty / Power(10, Segment.Decimals);
                                BarcQtySpec := true;
                            end;
                        end;
                    Segment.Type::Price:
                        begin
                            if Evaluate(BarcPrice, CopyStr(Barcode, Pos, Segment.Length)) then begin
                                BarcPrice := BarcPrice / Power(10, Segment.Decimals);
                                BarcPriceSpec := true;
                            end;
                        end;
                    Segment.Type::"Lot No.":
                        BarcLotNo := CopyStr(Barcode, Pos, Segment.Length);
                    Segment.Type::"Serial No.":
                        BarcSerialNo := CopyStr(Barcode, Pos, Segment.Length);
                    Segment.Type::"Item No.", Segment.Type::"Number Series":
                        begin
                            TmpCode := CopyStr(CopyStr(Barcode, 1, Pos + Segment.Length - 1) + '0000000000000000000000', 1, StrLen(Mask.Prefix) + Mask.Length);
                            if not BarcodeRec.Get(TmpCode) then
                                if StrLen(TmpCode) = 13 then begin
                                    TmpCode := CopyStr(TmpCode, 1, 12);
                                    Chk := 1 + StrCheckSum(CopyStr(TmpCode, 1, 12), '131313131313');
                                    Chr := SelectStr(Chk, '0,1,2,3,4,5,6,7,8,9');
                                    TmpCode := TmpCode + Chr;
                                    if not BarcodeRec.Get(TmpCode) then
                                        Clear(BarcodeRec);
                                end else
                                    Clear(BarcodeRec);

                            if Item.Get(BarcodeRec."Item No.") then begin
                                BarcItem := Item."No.";
                                BarcUOM := BarcodeRec."Unit of Measure Code";
                                BarcLineDiscount := BarcodeRec."Discount %";
                                BarcVariantCode := BarcodeRec."Variant Code";
                            end else
                                OnNotFindItemViaBarcode(Barcode, Pos, Segment, BarcItem);
                        end;
                    Segment.Type::"EAN License No.":
                        BarcEANOrg := CopyStr(Barcode, Pos, Segment.Length);
                    Segment.Type::"Coupon reference":
                        BarcCoupRef := CopyStr(Barcode, Pos, Segment.Length);
                    Segment.Type::Customer:
                        begin
                            TmpCode := CopyStr(Barcode, Pos, Segment.Length);
                            if Customer.Get(TmpCode) or (Evaluate(TmpInt, TmpCode) and Customer.Get(Format(TmpInt))) then
                                BarcCustomer := Customer."No.";
                        end;
                    Segment.Type::Employee:
                        begin
                            TmpCode := CopyStr(Barcode, Pos, Segment.Length);
                            if Staff.Get(TmpCode) then
                                BarcStaff := Staff.ID
                            else
                                if Staff.Get(DelChr(TmpCode, '<', '0')) then
                                    BarcStaff := Staff.ID;
                        end;
                    Segment.Type::"Data Entry":
                        begin
                            BarcDataEntry := CopyStr(Barcode, Pos, Segment.Length);
                            LDataEntry.SetRange("Barcode Mask Entry No", Mask."Entry No.");
                            if LDataEntry.FindFirst then
                                if not ProcessDataEntryMask(LDataEntry, Barcode, Pos, Segment.Length) and not LDataEntry."Keep Leading Zeroes in Barc." then
                                    BarcDataEntry := DelChr(CopyStr(Barcode, Pos, Segment.Length), '<', '0');
                        end;
                end;
                Pos := Pos + Segment.Length;
            until Segment.Next = 0;
    end;

    local procedure ProcessDataEntryMask(LDataEntry: Record "LSC POS Data Entry Type"; Barcode: Text[22]; Pos: Integer; SegmentLength: Integer): Boolean
    var
        RetailSetup: Record "LSC Retail Setup";
        DataEntryNoSeries: Record "No. Series";
        DataEntryNoSeriesLine: Record "No. Series Line";
        NoSeries: Codeunit "No. Series";
        DataEntryLength: Integer;
        IsHandled: Boolean;
        ReturnValue: Boolean;
    begin
        OnBeforeProcessDataEntryMask(LDataEntry, Barcode, Pos, SegmentLength, IsHandled, ReturnValue);
        if IsHandled then
            exit(ReturnValue);

        if not RetailSetup.Get() then
            RetailSetup.Init();
        if (LDataEntry.Numbering <> LDataEntry.Numbering::"No. Series") or (LDataEntry."No. Series Code" = '') then
            exit(false);
        if not DataEntryNoSeries.Get(LDataEntry."No. Series Code") then
            exit(false);

        DataEntryNoSeriesLine.SetRange("Series Code", DataEntryNoSeries.Code);
        DataEntryNoSeriesLine.SetRange(Open, true);
        DataEntryNoSeriesLine.SetFilter("Starting Date", '<=%1', Today);
        if DataEntryNoSeriesLine.FindLast then begin
            if DataEntryNoSeries."LSC Dist. Location Prefix" or DataEntryNoSeries."LSC POS Prefix" and DataEntryNoSeries."Default Nos." then begin
                if DataEntryNoSeries."LSC Dist. Location Prefix" then begin
                    if DataEntryNoSeries."LSC POS Prefix" then
                        DataEntryLength := StrLen(RetailSetup."Distribution Location") + StrLen(POSSESSION.Terminal()."No.") + StrLen(NoSeries.GetLastNoUsed(DataEntryNoSeries.Code))
                    else
                        DataEntryLength := StrLen(RetailSetup."Distribution Location") + StrLen(NoSeries.GetLastNoUsed(DataEntryNoSeries.Code));
                end else
                    if DataEntryNoSeries."LSC POS Prefix" then
                        DataEntryLength := StrLen(POSSESSION.Terminal()."No.") + StrLen(NoSeries.GetLastNoUsed(DataEntryNoSeries.Code));

                if DataEntryLength > 0 then begin
                    BarcDataEntry := DelStr(BarcDataEntry, 1, SegmentLength - DataEntryLength);
                    exit(true);
                end else begin
                    BarcDataEntry := DelChr(CopyStr(Barcode, Pos, SegmentLength), '<', '0');
                    exit(true);
                end;
            end;
            if Format(DataEntryNoSeriesLine."Starting No.").StartsWith('0') then
                exit(true);
        end;
        exit(false);
    end;

    procedure LoadCoupon(var Line: Record "LSC POS Trans. Line"; Barcode: Code[22]; var CouponCode: Code[22]): Boolean
    var
        BarcodeMask: Record "LSC Barcode Mask";
        CouponHeader: Record "LSC Coupon Header";
        PosTrans: Record "LSC POS Transaction";
        BcUtil: Codeunit "LSC Barcode Management";
        lCouponCode: Code[22];
        IsHandled: Boolean;
    begin
        if BcUtil.FindBarcodeMask(Barcode, BarcodeMask) and
           (BarcodeMask.Type = BarcodeMask.Type::Coupon)
        then begin
            ProcessMaskSegments(Barcode, BarcodeMask);
            CouponHeader.SetCurrentKey("Coupon Issuer", "Coupon Reference No.");
            CouponHeader.SetRange("Coupon Issuer", BarcEANOrg);
            CouponHeader.SetRange("Coupon Reference No.", BarcCoupRef);
            if not CouponHeader.FindFirst then
                exit(false);
            if CouponHeader.Affects = CouponHeader.Affects::"Next Item Line" then begin
                if CouponCode = '' then begin
                    CouponCode := Barcode;
                    exit(true);
                end;
                CouponCode := '';
            end;
            if CouponHeader.Value <> 0 then
                BarcPrice := CouponHeader.Value;
        end else begin

            lCouponCode := CouponCode;

            if StrLen(Barcode) > 10 then
                exit(false);

            if CouponHeader.Get(Barcode) then begin
                if CouponHeader.Affects = CouponHeader.Affects::"Next Item Line" then begin
                    if CouponCode = '' then begin
                        CouponCode := CouponHeader.Code;
                        exit(true);
                    end;
                    CouponCode := '';
                end;

                BarcPrice := CouponHeader.Value;
                BarcEANOrg := CouponHeader."Coupon Issuer";
            end else
                exit(false);
        end;

        if CouponHeader."Multiply Value" <> 0 then begin
            PosTrans.Get(Line."Receipt No.");
            if RboPriceUtil.DiscValPerValid(CouponHeader."Multiply Value Period ID", PosTrans."Trans. Date", PosTrans."Trans Time") then
                BarcPrice := BarcPrice * CouponHeader."Multiply Value";
        end;

        if BarcPrice <> 0 then begin
            Line."Barcode No." := Barcode;
            Line."Card/Customer/Coup.Item No" := CouponHeader."Coupon Reference No.";
            Line."Coupon EAN Org." := CouponHeader."Coupon Issuer";
            Line."Entry Type" := Line."Entry Type"::Payment;
            Line.Amount := BarcPrice;
            Line.Description := CouponHeader.Description;
            exit(true);
        end;

        OnAfterLoadCoupon(Line, CouponHeader, CouponCode, lCouponCode, Barcode, IsHandled);
        if IsHandled then
            exit(true);

        exit(false);
    end;

    internal procedure GetBarcCustomer(Barcode: Code[22]; Mask: Record "LSC Barcode Mask"): Code[20]
    begin
        ProcessMaskSegments(Barcode, Mask);
        exit(BarcCustomer);
    end;

    procedure GetBarcStaff(Barcode: Code[22]; Mask: Record "LSC Barcode Mask"): Code[20]
    begin
        ProcessMaskSegments(Barcode, Mask);
        exit(BarcStaff);
    end;

    internal procedure PermissionTender(TenderType: Record "LSC Tender Type"; MgrKey: Boolean; var MessageTxt: Text[50]): Boolean
    var
        Text036: Label 'It is not allowed to use this tendertype';
        Text037: Label 'Manager key is required to use this tendertype';
    begin
        if not TenderType."May Be Used" then begin
            MessageTxt := Text036;
            exit(false);
        end;
        if TenderType."Manager Key Control" and not MgrKey then begin
            MessageTxt := Text037;
            exit(false);
        end;
        exit(true);
    end;

    internal procedure ValidateTender(TenderType: Record "LSC Tender Type"; Total: Decimal; Balance: Decimal; Payment: Decimal; RefundSale: Boolean; ManualInput: Boolean; var MessageTxt: Text): Boolean
    var
        Sign: Decimal;
        RoundedBalance: Decimal;
        ReturnValue: Boolean;
        Handled: Boolean;
        Text038: Label 'The setup for tender type is marking only';
        Text039: Label 'Keyboard entry is not allowed for this tender type';
        Text040: Label 'Keyboard entry is required for this tender type';
        Text041: Label 'Return/minus not allowed for this tender type';
        Text042: Label 'Max. amount allowed for this tender type is %1';
        Text043: Label 'Max. amount to enter for this tender type is %1';
        Text044: Label 'Min. amount allowed for this tender type is %1';
        Text045: Label 'Min. amount to enter for this tender type is %1';
        Text046: Label 'Overtender is not allowed for this tender type';
        Text047: Label 'Overtender max. amount is %1';
        Text048: Label 'Undertender is not allowed for this tender type.';
    begin
        OnBeforeValidateTender(TenderType, Total, Balance, Payment, RefundSale, ManualInput, MessageTxt, ReturnValue, Handled);
        if handled then
            exit(ReturnValue);

        if RefundSale then
            Sign := -1
        else
            Sign := 1;
        if TenderType."Marking Only" and (Payment <> 0) then begin
            MessageTxt := Text038;
            exit(false);
        end;
        if ManualInput and not TenderType."Keyboard Entry Allowed" then begin
            MessageTxt := Text039;
            exit(false);
        end;
        if not ManualInput and TenderType."Keyboard Entry Required" then begin
            MessageTxt := Text040;
            exit(false);
        end;
        if not TenderType."Return/Minus Allowed" then
            if Payment * Sign < 0 then begin
                MessageTxt := Text041;
                exit(false);
            end;

        if TenderType."Max. Amount Allowed" <> 0 then
            if (Abs(Payment) + TotalPaymentPrTenderType(TenderType)) > TenderType."Max. Amount Allowed" then begin
                MessageTxt := StrSubstNo(Text042, TenderType."Max. Amount Allowed");
                exit(false);
            end;

        if ManualInput and (TenderType."Max. Amount Entered" <> 0) then
            if Abs(Payment) > TenderType."Max. Amount Entered" then begin
                MessageTxt := StrSubstNo(Text043, TenderType."Max. Amount Entered");
                exit(false);
            end;
        if TenderType."Min. Amount Allowed" <> 0 then
            if Abs(Payment) < TenderType."Min. Amount Allowed" then begin
                MessageTxt := StrSubstNo(Text044, TenderType."Min. Amount Allowed");
                exit(false);
            end;
        if ManualInput and (TenderType."Min. Amount Entered" <> 0) then
            if Abs(Payment) < TenderType."Min. Amount Entered" then begin
                MessageTxt := StrSubstNo(Text045, TenderType."Min. Amount Entered");
                exit(false);
            end;

        case TenderType.Rounding of
            TenderType.Rounding::Nearest:
                RoundedBalance := Round(Balance, TenderType."Rounding To", '=');
            TenderType.Rounding::Up:
                RoundedBalance := Round(Balance, TenderType."Rounding To", '>');
            TenderType.Rounding::Down:
                RoundedBalance := Round(Balance, TenderType."Rounding To", '<');
            else
                RoundedBalance := Balance;
        end;
        if RoundedBalance < Payment then begin
            if not TenderType."Overtender Allowed" then begin
                MessageTxt := Text046;
                exit(false);
            end;
            if TenderType."Overtender Max. Amt." <> 0 then
                if TenderType."Overtender Max. Amt." < (Payment - RoundedBalance) then begin
                    MessageTxt := StrSubstNo(Text047, TenderType."Overtender Max. Amt.");
                    exit(false);
                end;
        end;
        if RoundedBalance > Payment then
            if not TenderType."Undertender Allowed" then begin
                MessageTxt := Text048;
                exit(false);
            end;
        exit(true);
    end;

    internal procedure ValidateCustomer(var Customer: Record Customer; MgrKey: Boolean; RefundSale: Boolean; Payment: Decimal; var ErrorText: Text): Boolean
    var
        TmpCustomer: Record Customer temporary;
        BillToCustomer: Record Customer;
        Sign: Decimal;
        CBalanceOverLimit: Decimal;
        ExitValue: Boolean;
        IsHandled: Boolean;
        Text049: Label 'Customer %1 is blocked';
        Text050: Label 'Customer %1 is over credit limit';
        Text051: Label 'Customer %1 is over credit limit.\Do you want to continue?';
        Text058: Label 'Connection to Transaction server failed.\Contact Manager.';
    begin
        OnBeforeValidateCustomer(Customer, MgrKey, RefundSale, Payment, ErrorText, ExitValue, IsHandled);
        if IsHandled then
            exit(ExitValue);
        if PosSession.FunctionalityProfile."TS Customer" then begin
            if TSUtil.GetCustomer(TmpCustomer, Customer."No.", ErrorText) then
                Customer := TmpCustomer
            else
                if (ErrorText <> '') and not MgrKey then begin
                    ErrorText := Text058;
                    exit(false);
                end;
        end else
            Customer.CalcFields("LSC Amt. Charged On POS", "LSC Amt. Charged Posted", "Balance (LCY)");

        if (Customer."Bill-to Customer No." <> '') and (Customer."Bill-to Customer No." <> Customer."No.") then begin
            if PosSession.FunctionalityProfile."TS Customer" then begin
                if TSUtil.GetCustomer(TmpCustomer, Customer."Bill-to Customer No.", ErrorText) then
                    BillToCustomer := TmpCustomer
                else
                    if (ErrorText <> '') and not MgrKey then begin
                        ErrorText := Text058;
                        exit(false);
                    end;
            end else begin
                BillToCustomer.Get(Customer."Bill-to Customer No.");
                BillToCustomer.CalcFields("LSC Amt. Charged On POS", "LSC Amt. Charged Posted", "Balance (LCY)");
            end;
            Customer."LSC Other Tender in Finalizing" := BillToCustomer."LSC Other Tender in Finalizing";
            if BillToCustomer.Blocked.AsInteger() <> 0 then begin
                ErrorText := StrSubstNo(Text049, BillToCustomer."No.");
                exit(false);
            end;
            if RefundSale then
                Sign := -1
            else
                Sign := 1;
            if (Payment * Sign) <= 0 then
                exit(true);
            if BillToCustomer."Credit Limit (LCY)" <> 0 then begin
                CBalanceOverLimit := (BillToCustomer."Balance (LCY)" + Customer."LSC Amt. Charged On POS" +
                  BillToCustomer."LSC Amt. Charged On POS" - Customer."LSC Amt. Charged Posted" -
                  BillToCustomer."LSC Amt. Charged Posted" + Payment) - BillToCustomer."Credit Limit (LCY)";
                if CBalanceOverLimit > 0 then begin
                    OnBalanceOverCreditLimit(Customer, MgrKey, RefundSale, Payment, ErrorText, ExitValue, IsHandled);
                    if IsHandled then
                        exit(ExitValue);

                    if not MgrKey then begin
                        ErrorText := StrSubstNo(Text050, Customer."Bill-to Customer No.");
                        exit(false);
                    end;
                    if not PosCtrl.PosConfirm(StrSubstNo(Text051, Customer."Bill-to Customer No."), false) then begin
                        ErrorText := StrSubstNo(Text050, Customer."Bill-to Customer No.");
                        exit(false);
                    end;
                end;
            end;
            exit(true);
        end;

        if Customer.Blocked.AsInteger() <> 0 then begin
            ErrorText := StrSubstNo(Text049, Customer."No.");
            exit(false);
        end;
        if RefundSale then
            Sign := -1
        else
            Sign := 1;
        if (Payment * Sign) <= 0 then
            exit(true);
        if Customer."Credit Limit (LCY)" <> 0 then begin
            CBalanceOverLimit := (Customer."Balance (LCY)" + Customer."LSC Amt. Charged On POS" - Customer."LSC Amt. Charged Posted" + Payment) - Customer."Credit Limit (LCY)";
            if CBalanceOverLimit > 0 then begin
                OnBalanceOverCreditLimitCustomer(Customer, MgrKey, RefundSale, Payment, ErrorText, ExitValue, IsHandled);
                if IsHandled then
                    exit(ExitValue);

                if not MgrKey then begin
                    ErrorText := StrSubstNo(Text050, Customer."No.");
                    exit(false);
                end;
                if not PosCtrl.PosConfirm(StrSubstNo(Text051, Customer."No.", CBalanceOverLimit), false) then begin
                    ErrorText := StrSubstNo(Text050, Customer."No.");
                    exit(false);
                end;
            end;
        end;
        OnAfterValidateCustomer(Customer, MgrKey, RefundSale, Payment, ErrorText, ExitValue, IsHandled);
        if IsHandled then
            exit(ExitValue);
        exit(true);
    end;

    procedure ZeroPad(Str: Text[30]; Len: Integer): Text[30]
    var
        WrkString: Text[250];
    begin
        WrkString := PadStr('0', Len, '0') + Str;
        Str := CopyStr(WrkString, StrLen(WrkString) - Len + 1, Len);
        exit(Str);
    end;

    internal procedure IsPurgeOverDue(): Boolean
    var
        Trans: Record "LSC Transaction Header";
        PosTrans: Record "LSC POS Transaction";
        SaleType: Record "LSC Sales Type";
        RetailCalendarManagement: Codeunit "LSC Retail Calendar Management";
        RefDate: Date;
        IsHandled: Boolean;
        ReturnValue: Boolean;
    begin
        OnBeforeIsPurgeOverDue(PosTrans, IsHandled, ReturnValue);
        if IsHandled then
            exit(ReturnValue);

        SaleType.SetFilter("Days Open Trans. Exist", '>%1', 0);
        if SaleType.FindSet then begin
            RefDate := RetailCalendarManagement.GetStoreTransactionDate(POSSESSION.StoreNo, "LSC Retail Calendar Type"::"Opening Hours", TODAY, Time);
            repeat
                PosTrans.SetRange("Store No.", POSSESSION.StoreNo);
                PosTrans.SetRange("Sales Type", SaleType.Code);
                PosTrans.SetRange("Trans. Date", 0D, RefDate - SaleType."Days Open Trans. Exist" - SaleType."Trans. Delete Reminder");
                PosTrans.SetRange("Transaction Type", PosTrans."Transaction Type"::Sales);
                if not PosTrans.IsEmpty() then
                    exit(true);
            until SaleType.Next = 0;
        end;
        if PosSession.FunctionalityProfile."Days Transactions Exists" <> 0 then begin
            RefDate := Today;
            Trans.Reset;
            Trans.SetRange("Store No.", POSSESSION.StoreNo);
            Trans.SetRange("POS terminal No.", POSSESSION.TerminalNo());
            Trans.SetRange(Date, 0D, RefDate - PosSession.FunctionalityProfile."Days Transactions Exists" - PosSession.FunctionalityProfile."Trans. Delete Reminder");
            exit(not Trans.IsEmpty());
        end;
    end;

    internal procedure Purge()
    var
        Trans: Record "LSC Transaction Header";
        VoidedTrans: Record "LSC POS Voided Transaction";
        CardEntries: Record "LSC POS Card Entry";
        POSLog: Record "LSC POS Log";
        PosTrans: Record "LSC POS Transaction";
        SaleType: Record "LSC Sales Type";
        RetailCalendarManagement: Codeunit "LSC Retail Calendar Management";
        RefDate: Date;
    begin
        SaleType.SetFilter("Days Open Trans. Exist", '>%1', 0);
        if SaleType.FindSet then begin
            RefDate := RetailCalendarManagement.GetStoreTransactionDate(POSSESSION.StoreNo, "LSC Retail Calendar Type"::"Opening Hours", TODAY, Time);
            repeat
                PosTrans.SetAutoCalcFields(Payment);
                PosTrans.SetRange("Store No.", POSSESSION.StoreNo);
                PosTrans.SetRange("Sales Type", SaleType.Code);
                PosTrans.SetRange("Trans. Date", 0D, RefDate - SaleType."Days Open Trans. Exist");
                PosTrans.SetRange("Transaction Type", PosTrans."Transaction Type"::Sales);
                PosTrans.SetRange(Payment, 0);
                if not PosTrans.IsEmpty() then
                    Postrans.DeleteAll(true);
            until SaleType.Next = 0;
        end;
        if PosSession.FunctionalityProfile."Days Transactions Exists" > 0 then begin
            RefDate := Today;
            Trans.Reset;
            Trans.SetRange("Store No.", POSSESSION.StoreNo());
            Trans.SetRange("POS terminal No.", POSSESSION.TerminalNo());
            if Trans.FindLast() then
                Trans.SetFilter("Transaction No.", '<>%1', Trans."Transaction No.");
            Trans.SetRange(Date, 0D, RefDate - PosSession.FunctionalityProfile."Days Transactions Exists");
            if not Trans.IsEmpty() then
                Trans.DeleteAll(true);

            VoidedTrans.SetRange("Store No.", POSSESSION.StoreNo());
            VoidedTrans.SetRange("POS Terminal No.", POSSESSION.TerminalNo());
            VoidedTrans.SetRange("Trans. Date", 0D, RefDate - PosSession.FunctionalityProfile."Days Transactions Exists");
            if not VoidedTrans.IsEmpty() then
                VoidedTrans.DeleteAll(true);

            CardEntries.SetRange("Store No.", POSSESSION.StoreNo());
            CardEntries.SetRange("POS Terminal No.", POSSESSION.TerminalNo());
            if CardEntries.FindLast() then
                CardEntries.SetFilter("Entry No.", '<>%1', CardEntries."Entry No.");
            CardEntries.SetRange(Date, 0D, RefDate - PosSession.FunctionalityProfile."Days Transactions Exists");
            if not CardEntries.IsEmpty() then
                CardEntries.DeleteAll(true);

            POSLog.Reset;
            POSLog.SetRange("Entry Date", 0D, RefDate - PosSession.FunctionalityProfile."Days Transactions Exists");
            POSLog.SetRange("Store No.", PosSession.Store."No.");
            POSLog.SetRange("Terminal No.", PosSession.Terminal."No.");
            if not POSLog.IsEmpty() then
                POSLog.DeleteAll(true);
            OnAfterPurge();
        end;

        Commit;
    end;

    procedure RoundAmount(Dec: Decimal): Decimal
    begin
        exit(Round(Dec, PosSession.FunctionalityProfile."Amount Rounding to"));
    end;

    procedure RoundTender(TenderType: Record "LSC Tender Type"; Amount: Decimal): Decimal
    var
        POSTransactionRecord: Record "LSC POS Transaction";
        TenderRoundingDirection: Text;
        RoundFactor: Decimal;
        Result: Decimal;
        IsHandled: Boolean;
    begin
        OnBeforeRoundTender(TenderType, Amount, Result, IsHandled);
        if IsHandled then
            exit(Result);

        if (TenderType.Rounding <> TenderType.Rounding::None) and (TenderType."Rounding To" <> 0) then begin
            if Amount < 0 then begin
                POSTransactionImpl.GetPOSTransaction(POSTransactionRecord);
                if not POSTransactionRecord."Customer Order" then
                    if TenderType.Rounding = TenderType.Rounding::Up then
                        TenderType.Rounding := TenderType.Rounding::Down
                    else
                        if TenderType.Rounding = TenderType.Rounding::Down then
                            TenderType.Rounding := TenderType.Rounding::Up;
            end;
            TenderRoundingDirection := SelectStr(TenderType.Rounding, '=,>,<');
            if TenderType.Rounding = TenderType.Rounding::Nearest then begin
                RoundFactor := TenderType."Rounding To" / 2;
                if Amount mod RoundFactor = 0 then
                    if Amount < 0 then
                        TenderRoundingDirection := '<'
                    else
                        TenderRoundingDirection := '=';
            end;
            OnAfterTenderRoundingDirection(TenderType, TenderRoundingDirection);
            exit(Round(Amount, TenderType."Rounding To", TenderRoundingDirection));
        end;
        exit(RoundAmount(Amount));
    end;

    [Obsolete('Not used, use POS Formatting instead', '26.0')]
    procedure FormatAmount(Dec: Decimal): Text[30]
    begin
        exit(_Formatting.FormatAmount(Dec));
    end;

    [Obsolete('Not used, use POS Formatting instead', '26.0')]
    procedure FormatPrice(Dec: Decimal): Text[30]
    begin
        exit(_Formatting.FormatPrice(Dec));
    end;

    [Obsolete('Not used, use POS Formatting instead', '26.0')]
    procedure FormatQty(Dec: Decimal): Text[30]
    begin
        exit(_Formatting.FormatQty(Dec));
    end;

    [Obsolete('Not used, use POS Formatting instead', '26.0')]
    procedure FormatPriceWithCurrencySymbol(DecimalValue: Decimal): Text
    begin
        exit(_Formatting.FormatPriceWithCurrencySymbol(DecimalValue));
    end;

    [Obsolete('Not used, use POS Formatting instead', '26.0')]
    procedure FormatCurrency(Value: Decimal; CurrCode: Code[10]): Text[30]
    begin
        exit(_Formatting.FormatCurrency(Value, CurrCode));
    end;

    [Obsolete('Not used, use POS Formatting instead', '26.0')]
    procedure FormatAmountToShow(Value: Decimal): Text[30]
    begin
        exit(_Formatting.FormatAmountToShow(Value));
    end;

    internal procedure ValidateCoupon(var Line: Record "LSC POS Trans. Line"; CouponTenderType: Code[10]; var Description: Text[30]): Boolean
    var
        CouponHeader: Record "LSC Coupon Header";
        CouponLine: Record "LSC Coupon Line";
        POSTransLine: Record "LSC POS Trans. Line";
        CouponIssuer: Record "LSC Coupon Issuer";
        PosTrans: Record "LSC POS Transaction";
        QtyNeeded: Decimal;
        LineQty: Decimal;
        TotAmount: Decimal;
        LineNo: Integer;
        Found: Boolean;
        IsHandled, ReturnValue : Boolean;
        Text055: Label 'Coupon %1 is not recognized.\Unkonwn %2.';
        Text056: Label '%1 is Blocked';
        Text057: Label 'Not enough items to trigger Coupon.';
        Text063: Label 'The Coupon is not valid in this store';
        Text064: Label 'The Coupon''s is not valid at this time';
        Text065: Label 'Coupon only valid for next/last item line. Item not found.';
    begin
        InitPosFunctions;
        OnBeforeValidateCoupon(Line, IsHandled);
        if IsHandled then begin
            if (Line."Coupon EAN Org." <> '') and not CouponIssuer.Get(Line."Coupon EAN Org.") then begin
                Description := StrSubstNo(Text055, Line."Barcode No.", Line.FieldCaption("Coupon EAN Org."));
                exit(false);
            end;
            if CouponIssuer.Blocked then begin
                Description := StrSubstNo(Text056, CouponIssuer.TableCaption);
                exit(false);
            end;
            CouponHeader.SetCurrentKey("Coupon Issuer", "Coupon Reference No.");
            CouponHeader.SetRange("Coupon Issuer", Line."Coupon EAN Org.");
            CouponHeader.SetRange("Coupon Reference No.", Line."Card/Customer/Coup.Item No");
            if not CouponHeader.FindFirst then begin
                Description := StrSubstNo(Text055, Line."Barcode No.", CouponHeader.FieldCaption("Coupon Reference No."));
                exit(false);
            end;
        end;
        if CouponHeader.Status = "LSC Toggle Status"::Disabled then begin
            Description := StrSubstNo(Text056, CouponHeader.TableCaption);
            exit(false);
        end;
        if not BOUtils.PriceGroupValidInStore2(CouponHeader."Price Group", Line."Store No.") then begin
            Description := StrSubstNo(Text063);
            exit(false);
        end;
        PosTrans.Get(Line."Receipt No.");
        if not RboPriceUtil.DiscValPerValid(CouponHeader."Validation Period ID", PosTrans."Trans. Date", PosTrans."Trans Time") then begin
            Description := StrSubstNo(Text064);
            exit(false);
        end;

        IsHandled := false;
        OnAfterDiscValPerValid_ValidateCoupon(CouponHeader, PosTrans, Line, Description, ReturnValue, IsHandled);
        if IsHandled then
            exit(ReturnValue);

        if CouponHeader.Type = CouponHeader.Type::"Return Coupon" then
            exit(true);

        LineNo := 0;

        if (CouponHeader.Affects <> CouponHeader.Affects::"Any Item Line") and
           (CouponHeader.Handling = CouponHeader.Handling::Discount)
        then begin
            POSTransLine.SetRange("Receipt No.", Line."Receipt No.");
            PosTransLine.Ascending(false);
            if POSTransLine.FindSet() then
                repeat
                    Found := (POSTransLine."Entry Type" = Line."Entry Type"::Item) and (not POSTransLine."Linked No. not Orig.");
                    LineNo := POSTransLine."Line No.";
                until (POSTransLine.Next() = 0) or Found;
            if not Found then begin
                Description := Text065;
                exit(false);
            end;
        end;

        TmpPOSTransLine.DeleteAll;
        CouponLine.SetRange("Coupon Code", CouponHeader.Code);
        QtyNeeded := CouponHeader."No. of Items to Trigger";
        if CouponLine.FindSet() then
            repeat
                POSTransLine.Reset;
                case CouponLine.Type of
                    CouponLine.Type::Item:
                        begin
                            POSTransLine.SetCurrentKey("Receipt No.", "Entry Type", Number);
                            POSTransLine.SetRange("Receipt No.", Line."Receipt No.");
                            POSTransLine.SetRange("Entry Type", POSTransLine."Entry Type"::Item);
                            POSTransLine.SetRange(Number, CouponLine."No.");
                        end;

                    CouponLine.Type::"Product Group":
                        begin
                            POSTransLine.SetCurrentKey("Receipt No.", "Entry Type", "Item Category Code", "Retail Product Code");
                            POSTransLine.SetRange("Receipt No.", Line."Receipt No.");
                            POSTransLine.SetRange("Entry Type", POSTransLine."Entry Type"::Item);
                            POSTransLine.SetRange("Retail Product Code", CouponLine."No.");
                        end;

                    CouponLine.Type::"Item Category":
                        begin
                            POSTransLine.SetCurrentKey("Receipt No.", "Entry Type", "Item Category Code", "Retail Product Code");
                            POSTransLine.SetRange("Receipt No.", Line."Receipt No.");
                            POSTransLine.SetRange("Entry Type", POSTransLine."Entry Type"::Item);
                            POSTransLine.SetRange("Item Category Code", CouponLine."No.");
                        end;

                    CouponLine.Type::"Special Group":
                        begin
                            POSTransLine.SetCurrentKey("Receipt No.", "Entry Type", "Entry Status");
                            POSTransLine.SetRange("Receipt No.", Line."Receipt No.");
                            POSTransLine.SetRange("Entry Type", POSTransLine."Entry Type"::Item);
                            POSTransLine.SetRange("Entry Status", POSTransLine."Entry Status"::" ");
                        end;
                end;

                if LineNo <> 0 then
                    POSTransLine.SetRange("Line No.", LineNo);
                TotAmount := 0;
                if POSTransLine.FindFirst then
                    repeat
                        if POSTransLine."Entry Status" = POSTransLine."Entry Status"::" " then begin
                            if POSTransLine."Scale Item" or POSTransLine."Price in Barcode" then
                                LineQty := 1
                            else
                                LineQty := POSTransLine.Quantity - POSTransLine."Coupon Qty Used";

                            if LineQty > 0 then
                                if LineQty >= QtyNeeded then begin
                                    if POSTransLine."Scale Item" or POSTransLine."Price in Barcode" then
                                        QtyNeeded := POSTransLine.Quantity;
                                    POSTransLine."Coupon Qty Used" += QtyNeeded;
                                    POSTransLine.Modify;
                                    LastCouponPOSTransLine_Temp := POSTransLine;
                                    LastCouponPOSTransLine_Temp."Coupon Qty Used" := QtyNeeded;
                                    LastCouponPOSTransLine_Temp.Amount := Line.Amount;
                                    LastCouponPOSTransLine_Temp."Parent Line" := LineNo;
                                    TotAmount += QtyNeeded * POSTransLine.Price;
                                    if TmpPOSTransLine.FindSet then
                                        repeat
                                            POSTransLine.Get(TmpPOSTransLine."Receipt No.", TmpPOSTransLine."Line No.");
                                            POSTransLine."Coupon Qty Used" := POSTransLine.Quantity;
                                            POSTransLine.Modify;
                                        until TmpPOSTransLine.Next = 0;
                                    if CouponHeader."Discount Type" = CouponHeader."Discount Type"::"Discount %" then begin
                                        Line.Amount := RoundAmount(TotAmount * BarcPrice / 100);
                                        if CouponHeader."Multiply Value" <> 0 then
                                            if RboPriceUtil.DiscValPerValid(CouponHeader."Multiply Value Period ID",
                                               PosTrans."Trans. Date", PosTrans."Trans Time")
                                            then
                                                Line.Amount := RoundAmount(Line.Amount * CouponHeader."Multiply Value");
                                    end;
                                    if LineNo <> 0 then begin
                                        POSTransLine."Coupon Discount Amount" += Line.Amount;
                                        POSTransLine."Coupon Amt. For Printing" += Line.Amount;
                                        POSTransLine.Modify;
                                    end;
                                    exit(true);
                                end else
                                    if not TmpPOSTransLine.Get(POSTransLine."Receipt No.", POSTransLine."Line No.") then begin
                                        TmpPOSTransLine := POSTransLine;
                                        TmpPOSTransLine.Insert;
                                        QtyNeeded := QtyNeeded - LineQty;
                                        if POSTransLine."Scale Item" or POSTransLine."Price in Barcode" then
                                            TotAmount += POSTransLine.Quantity * POSTransLine.Price
                                        else
                                            TotAmount += LineQty * POSTransLine.Price;
                                    end;
                        end;
                    until POSTransLine.Next = 0;
            until CouponLine.Next = 0;

        if LineNo = 0 then
            Description := Text057
        else
            Description := Text065;
        exit(false);
    end;

    procedure GetBarcItemInfo(Barcode: Code[22]; Mask: Record "LSC Barcode Mask"; var ItemNo: Code[20]; var PriceInBarcode: Boolean; var QtyInBarcode: Boolean; var UOM: Code[10])
    begin
        ProcessMaskSegments(Barcode, Mask);
        ItemNo := BarcItem;
        UOM := BarcUOM;
        PriceInBarcode := BarcPriceSpec;
        QtyInBarcode := BarcQtySpec;
    end;

    procedure GetBarcDataEntryCode(Barcode: Code[22]; Mask: Record "LSC Barcode Mask"): Code[20]
    begin
        ProcessMaskSegments(Barcode, Mask);
        exit(BarcDataEntry);
    end;

    procedure CopyMarkedLines(var SrcPosTrans: Record "LSC POS Transaction"; var DstPosTrans: Record "LSC POS Transaction"; DelLines: Boolean; SetCoverNo: Integer; CopyMarked: Boolean)
    var
        SrcTransLine: Record "LSC POS Trans. Line";
        TmpLine: Record "LSC POS Trans. Line";
        NewTotDiscPOSTransLineTmp: Record "LSC POS Trans. Line" temporary;
        InfoEntry: Record "LSC POS Trans. Infocode Entry";
        TmpInfoEntry: Record "LSC POS Trans. Infocode Entry";
        DataEntry: Record "LSC POS Data Entry";
        TmpDataEntry: Record "LSC POS Data Entry";
        OfferPosCalc: Record "LSC Offer Pos Calculation";
        TmpOfferPosCalc: Record "LSC Offer Pos Calculation";
        PosMixMatchEntry: Record "LSC POS Mix & Match Entry";
        PosMixMatchEntry2: Record "LSC POS Mix & Match Entry";
        PosTrPerDisc: Record "LSC POS Trans. Per. Disc. Type";
        PosTrPerDisc2: Record "LSC POS Trans. Per. Disc. Type";
        PosTrGuestInfo2: Record "LSC POS Trans. Guest Info";
        VoucherEntries: Record "LSC Voucher Entries";
        VoucherEntries2: Record "LSC Voucher Entries";
        PosTrLineDisplStatRouting: Record "LSC POS Tr. Line Dis. Stat. R.";
        PosTrLineDisplStatRouting2: Record "LSC POS Tr. Line Dis. Stat. R.";
        LineOfs: Integer;
        RoundNo: Integer;
        MaxCoverNo: Integer;
        GuestTransfers: array[150] of Integer;
        InfoEntryOffset: Integer;
    begin
        Clear(GuestTransfers);
        Clear(PosTrGuestInfo2);

        SrcTransLine.SetRange("Receipt No.", SrcPosTrans."Receipt No.");
        if CopyMarked then
            SrcTransLine.SetRange(Marked, true);
        if not SrcTransLine.FindFirst then
            exit;

        TmpLine.SetRange("Receipt No.", DstPosTrans."Receipt No.");
        MaxCoverNo := 0;
        LineOfs := 0;
        if TmpLine.FindSet then begin
            repeat
                if MaxCoverNo < TmpLine."Guest/Seat No." then
                    MaxCoverNo := TmpLine."Guest/Seat No.";
            until TmpLine.Next = 0;
            LineOfs := TmpLine."Line No.";
        end;

        Clear(NewTotDiscPOSTransLineTmp);
        NewTotDiscPOSTransLineTmp.DeleteAll;

        RoundNo := TmpLine."Round No." + 1;
        if SrcTransLine.FindSet then begin
            PosTransDiscLoad(SrcTransLine."Receipt No.");
            repeat
                TmpLine.TransferFields(SrcTransLine);
                TmpLine."Round No." := RoundNo;
                case SetCoverNo of
                    0:
                        TmpLine."Guest/Seat No." := 0;
                    1:
                        TmpLine."Guest/Seat No." := SrcTransLine."Guest/Seat No.";  //already set
                end;

                TmpLine."Line No." := SrcTransLine."Line No." + LineOfs;
                if SrcTransLine."Parent Line" <> 0 then
                    TmpLine."Parent Line" := SrcTransLine."Parent Line" + LineOfs;
                if SrcTransLine."Disc. Info Line No." <> 0 then
                    TmpLine."Disc. Info Line No." := SrcTransLine."Disc. Info Line No." + LineOfs;
                if SrcTransLine."Split Origin Line No." <> 0 then
                    TmpLine."Split Origin Line No." := SrcTransLine."Split Origin Line No." + LineOfs;
                if SrcTransLine."Mix & Match Line No." <> 0 then
                    TmpLine."Mix & Match Line No." := SrcTransLine."Mix & Match Line No." + LineOfs;

                if SrcTransLine."Tot. Disc Info Line No." <> 0 then begin
                    TmpLine."Tot. Disc Info Line No." := SrcTransLine."Tot. Disc Info Line No." + LineOfs;
                    if CopyMarked then begin
                        if not NewTotDiscPOSTransLineTmp.Get(DstPosTrans."Receipt No.", TmpLine."Tot. Disc Info Line No.") then begin
                            NewTotDiscPOSTransLineTmp."Receipt No." := DstPosTrans."Receipt No.";
                            NewTotDiscPOSTransLineTmp."Line No." := TmpLine."Tot. Disc Info Line No.";
                            NewTotDiscPOSTransLineTmp."Tot. Disc Info Line No." := SrcTransLine."Tot. Disc Info Line No.";
                            NewTotDiscPOSTransLineTmp.Insert;
                        end;
                        NewTotDiscPOSTransLineTmp."Total Disc. Amount" += SrcTransLine."Total Disc. Amount";
                        NewTotDiscPOSTransLineTmp.Modify;
                    end;
                end;

                TmpLine."Receipt No." := DstPosTrans."Receipt No.";
                TmpLine."POS Terminal No." := DstPosTrans."POS Terminal No.";
                TmpLine."Store No." := DstPosTrans."Store No.";
                TmpLine.Marked := false;
                TmpLine."Remaining Quantity" := 0;
                TmpLine.Insert;

                if DelLines then begin
                    PosTrLineDisplStatRouting.Reset;
                    PosTrLineDisplStatRouting.SetRange("Receipt No.", SrcTransLine."Receipt No.");
                    PosTrLineDisplStatRouting.SetRange("Pos Trans. Line No.", SrcTransLine."Line No.");
                    if PosTrLineDisplStatRouting.FindSet then begin
                        repeat
                            PosTrLineDisplStatRouting2.TransferFields(PosTrLineDisplStatRouting, true);
                            PosTrLineDisplStatRouting2."Receipt No." := TmpLine."Receipt No.";
                            PosTrLineDisplStatRouting2."Pos Trans. Line No." += LineOfs;
                            PosTrLineDisplStatRouting2.Insert;
                        until PosTrLineDisplStatRouting.Next = 0;
                        PosTrLineDisplStatRouting.DeleteAll;
                    end;
                end;

                if not CopyMarked then begin  //all lines are copied
                    InfoEntry.Reset;
                    InfoEntry.SetRange("Receipt No.", SrcPosTrans."Receipt No.");
                    InfoEntry.SetRange("Transaction Type", InfoEntry."Transaction Type"::Header);
                    if InfoEntry.FindSet then begin
                        InfoEntryOffset := 0;
                        TmpInfoEntry.SetRange("Receipt No.", DstPosTrans."Receipt No.");
                        TmpInfoEntry.SetRange("Transaction Type", TmpInfoEntry."Transaction Type"::Header);
                        if TmpInfoEntry.FindLast() then
                            InfoEntryOffset := TmpInfoEntry."Entry Line No." + 10000;
                        repeat
                            TmpInfoEntry.init;
                            TmpInfoEntry.TransferFields(InfoEntry, true);
                            TmpInfoEntry."Receipt No." := DstPosTrans."Receipt No.";
                            TmpInfoEntry."Entry Line No." := InfoEntry."Entry Line No." + InfoEntryOffset;
                            TmpInfoEntry.Insert;
                        until InfoEntry.Next = 0;

                        InfoEntry.DeleteAll;
                    end;
                end;

                InfoEntry.Reset;
                InfoEntry.SetRange("Receipt No.", SrcPosTrans."Receipt No.");
                InfoEntry.SetRange("Line No.", SrcTransLine."Line No.");
                if InfoEntry.FindSet then begin
                    repeat
                        TmpInfoEntry := InfoEntry;
                        TmpInfoEntry."Receipt No." := DstPosTrans."Receipt No.";
                        TmpInfoEntry."Line No." += LineOfs;
                        TmpInfoEntry.Insert;
                    until InfoEntry.Next = 0;
                    InfoEntry.DeleteAll;
                end;

                DataEntry.Reset;
                DataEntry.SetCurrentKey("Created by Receipt No.", "Created by Line No.");
                DataEntry.SetRange("Created by Receipt No.", SrcPosTrans."Receipt No.");
                DataEntry.SetRange("Created by Line No.", SrcTransLine."Line No.");
                if DataEntry.FindSet then
                    repeat
                        TmpDataEntry.TransferFields(DataEntry);
                        TmpDataEntry."Created by Receipt No." := DstPosTrans."Receipt No.";
                        TmpDataEntry."Created by Line No." += LineOfs;
                        TmpDataEntry.Modify;
                    until DataEntry.Next = 0;

                DataEntry.Reset;
                DataEntry.SetCurrentKey("Applied by Receipt No.", "Applied by Line No.");
                DataEntry.SetRange("Applied by Receipt No.", SrcPosTrans."Receipt No.");
                DataEntry.SetRange("Applied by Line No.", SrcTransLine."Line No.");
                if DataEntry.FindSet then
                    repeat
                        TmpDataEntry.TransferFields(DataEntry);
                        TmpDataEntry."Applied by Receipt No." := DstPosTrans."Receipt No.";
                        TmpDataEntry."Applied by Line No." += LineOfs;
                        TmpDataEntry.Modify;
                    until DataEntry.Next = 0;

                OfferPosCalc.Reset;
                OfferPosCalc.SetRange("Receipt No.", SrcPosTrans."Receipt No.");
                OfferPosCalc.SetRange("Trans. Line No.", SrcTransLine."Line No.");
                if OfferPosCalc.FindSet then begin
                    repeat
                        TmpOfferPosCalc := OfferPosCalc;
                        TmpOfferPosCalc."Receipt No." := DstPosTrans."Receipt No.";
                        TmpOfferPosCalc."Trans. Line No." += LineOfs;
                        TmpOfferPosCalc.Insert;
                    until OfferPosCalc.Next = 0;
                    OfferPosCalc.DeleteAll;
                end;

                PosMixMatchEntry.Reset;
                PosMixMatchEntry.SetRange("Receipt No.", SrcPosTrans."Receipt No.");
                PosMixMatchEntry.SetRange(PosMixMatchEntry."Line No.", SrcTransLine."Line No.");
                if PosMixMatchEntry.FindSet then begin
                    repeat
                        PosMixMatchEntry2 := PosMixMatchEntry;
                        PosMixMatchEntry2."Receipt No." := DstPosTrans."Receipt No.";
                        PosMixMatchEntry2."Line No." += LineOfs;
                        PosMixMatchEntry2.Insert;
                    until PosMixMatchEntry.Next = 0;
                    PosMixMatchEntry.DeleteAll;
                end;

                PosTrPerDisc.Reset;
                PosTrPerDisc.SetRange("Receipt No.", SrcPosTrans."Receipt No.");
                PosTrPerDisc.SetRange("Line No.", SrcTransLine."Line No.");
                PosTransDiscSetTableFilter(1, PosTrPerDisc);
                if PosTransDiscFindSetRec(1, PosTrPerDisc) then
                    repeat
                        PosTrPerDisc2 := PosTrPerDisc;
                        PosTrPerDisc2."Receipt No." := DstPosTrans."Receipt No.";
                        PosTrPerDisc2."Line No." := TmpLine."Line No.";
                        if PosTrPerDisc2.Insert(true) then;
                    until PosTransDiscNextRec(1, 1, PosTrPerDisc) = 0;

                VoucherEntries.Reset;
                VoucherEntries.SetRange("Receipt Number", SrcPosTrans."Receipt No.");
                if VoucherEntries.FindSet then begin
                    VoucherEntries2 := VoucherEntries;
                    VoucherEntries.Delete;
                    VoucherEntries2."Receipt Number" := DstPosTrans."Receipt No.";
                    VoucherEntries2.Insert;
                end;
                SrcTransLine."Entry Status" := SrcTransLine."Entry Status"::Voided;
            until SrcTransLine.Next = 0;
        end;

        PosTransDiscFlush;

        if SrcTransLine.FindSet then begin
            repeat
                if DelLines then begin
                    SrcTransLine.Quantity := 0;
                    SrcTransLine.Delete(true)
                end else begin
                    if CopyMarked then begin
                        SrcTransLine.Marked := false;
                        SrcTransLine.Modify;
                    end;
                end;
            until SrcTransLine.Next = 0;
        end;
        if NewTotDiscPOSTransLineTmp.FindSet then begin
            repeat
                if SrcTransLine.Get(SrcTransLine."Receipt No.", NewTotDiscPOSTransLineTmp."Tot. Disc Info Line No.") then begin
                    TmpLine.TransferFields(SrcTransLine);
                    TmpLine."Round No." := RoundNo;
                    TmpLine."Receipt No." := NewTotDiscPOSTransLineTmp."Receipt No.";
                    TmpLine."Line No." := NewTotDiscPOSTransLineTmp."Line No.";
                    TmpLine."POS Terminal No." := DstPosTrans."POS Terminal No.";
                    TmpLine."Store No." := DstPosTrans."Store No.";
                    TmpLine.Marked := false;
                    if NewTotDiscPOSTransLineTmp."Total Disc. Amount" <> 0 then begin
                        TmpLine.Amount := -NewTotDiscPOSTransLineTmp."Total Disc. Amount";
                        SrcTransLine.Amount := SrcTransLine.Amount + NewTotDiscPOSTransLineTmp."Total Disc. Amount";
                        OnBeforeModifySrcTransLine(SrcTransLine, TmpLine);
                        SrcTransLine.Modify;
                    end;
                    TmpLine.Insert;
                end;
            until NewTotDiscPOSTransLineTmp.Next = 0;
        end;
    end;

    procedure FindLastTrans(var Trans: Record "LSC Transaction Header"): Boolean
    var
        IsHandled, ReturnValue : Boolean;
    begin
        OnBeforeFindLastTrans(PosSession.Terminal, Trans, ReturnValue, IsHandled);
        if IsHandled then
            exit(ReturnValue);

        Trans.Reset;
        Trans.SetRange("POS Terminal No.", PosSession.Terminal."No.");
        Trans.SetFilter("Transaction Type", '%1|%2|%3|%4', Trans."Transaction Type"::Sales, Trans."Transaction Type"::Payment,
        Trans."Transaction Type"::Voided, Trans."Transaction Type"::Cancelation);
        if POSTransactionImpl.GetTrainingMode() then
            Trans.SetRange("Entry Status", Trans."Entry Status"::Training)
        else
            Trans.SetRange("Entry Status", Trans."Entry Status"::" ");
        if Trans.IsEmpty() then
            exit(false);
        exit(Trans.FindLast);
    end;

    procedure GetStatementCode(): Code[20]
    var
        PosTerminal: Record "LSC POS Terminal";
    begin
        PosTerminal := PosSession.Terminal;
        if not PosTerminal."Terminal Statement" then
            PosTerminal."Statement Method" := PosSession.Store."Statement Method";
        case PosTerminal."Statement Method" of
            PosTerminal."Statement Method"::Staff:
                exit(PosSession.Staff.ID);
            PosTerminal."Statement Method"::"POS Terminal":
                exit(PosTerminal."No.");
            PosTerminal."Statement Method"::Total:
                exit(PosSession.Store."No.");
        end;
    end;

    procedure ChangeVATBusOnLine(POSTransaction: Record "LSC POS Transaction")
    var
        POSTransLine: Record "LSC POS Trans. Line";
        tmpPOSTransLineOfferUpd: Record "LSC POS Trans. Line" temporary;
        VatSetup: Record "VAT Posting Setup";
        Item: Record Item;
        PriceListLineTmp: Record "Price List Line" temporary;
        MembershipCardTemp: Record "LSC Membership Card" temporary;
        MemberAttributeListTemp: Record "LSC Member Attribute List" temporary;
        PosPrice: Codeunit "LSC POS Price Utility";
        UOM: Code[10];
        Price: Decimal;
        IsHandled: Boolean;
    begin
        OnBeforeChangeVATBusOnLine(POSTransaction, IsHandled);
        if IsHandled then
            exit;

        if POSTransaction."Member Card No." <> '' then begin
            if PosPrice.ValidateOfferMemberInfo(POSTransaction, 0) then begin
                GetMemberShipCardInfo(MembershipCardTemp);
                GetMemberAttributeList(MemberAttributeListTemp);
                RboPriceUtil.SetMemberInfo(MembershipCardTemp, MemberAttributeListTemp);
            end;
        end;

        tmpPOSTransLineOfferUpd.DeleteAll;
        POSTransLine.SetCurrentKey("Receipt No.", "Entry Type", Number, "Variant Code");
        POSTransLine.SetRange("Receipt No.", POSTransaction."Receipt No.");
        POSTransLine.SetRange("Entry Type", POSTransLine."Entry Type"::Item);
        if POSTransLine.FindSet then begin
            repeat
                VatSetup.Get(POSTransaction."VAT Bus.Posting Group", POSTransLine."Vat Prod. Posting Group");
                if POSTransLine."Vat Bus. Posting Group" <> POSTransaction."VAT Bus.Posting Group" then begin
                    POSTransLine."Vat Bus. Posting Group" := POSTransaction."VAT Bus.Posting Group";
                    POSTransLine."VAT Code" := VatSetup."LSC POS Terminal VAT Code";
                    POSTransLine.Modify;
                end;
                Item.Get(POSTransLine.Number);
                if POSTransLine."Unit of Measure" <> '' then
                    UOM := POSTransLine."Unit of Measure"
                else
                    UOM := Item."Sales Unit of Measure";
                if (POSTransLine."Price Change") or (POSTransLine."System-Unchangable Price") then
                    Price := POSTransLine.Price
                else
                    Price := RboPriceUtil.GetValidRetailPrice2Trans(POSTransLine."Store No.", POSTransLine.Number,
                      POSTransaction."Trans. Date", POSTransaction."Trans Time", UOM, POSTransLine."Variant Code",
                      POSTransLine."Vat Bus. Posting Group", POSTransaction."Trans. Currency Code",
                      POSTransaction."Price Group Code", POSTransLine."Sales Type", POSTransaction."Customer Disc. Group",
                      POSTransLine);
                if (POSTransLine.Price <> Price) or (POSTransLine."VAT %" <> VatSetup."VAT %") or (VatSetup."VAT Calculation Type" = VatSetup."VAT Calculation Type"::"Reverse Charge VAT") then begin
                    if POSTransLine."Quantity Discounted" <> 0 then begin
                        tmpPOSTransLineOfferUpd := POSTransLine;
                        tmpPOSTransLineOfferUpd.Insert;
                    end;
                    POSTransLine.Price := Price;
                    if VatSetup."VAT Calculation Type" = VatSetup."VAT Calculation Type"::"Normal VAT" then
                        POSTransLine."VAT %" := VatSetup."VAT %"
                    else begin
                        POSTransLine."VAT %" := 0;
                        if (POSTransLine."Price Change") or (POSTransLine."System-Unchangable Price") then
                            POSTransLine.Price := POSTransLine."Net Price"
                    end;
                    POSTransLine."Net Price" := Round(POSTransLine.Price / (1 + POSTransLine."VAT %" / 100), PosSession.FunctionalityProfile."Price Rounding to");

                    if not PosSession.FunctionalityProfile."No VAT Used" and not PosSession.FunctionalityProfile."Add VAT to Prices" and (POSTransaction."Price Group Code" <> '')
                    and (RboPriceUtil.GetRetailSalesPrice(POSTransLine.Number, POSTransaction."Price Group Code", POSTransaction."Trans. Date", POSTransaction."Trans. Currency Code", POSTransLine."Variant Code", UOM, PriceListLineTmp)) then
                        POSTransLine.Price := Round(RboPriceUtil.CalcPriceInclVat(Item, Round(POSTransLine."Net Price"), POSTransLine."Vat Bus. Posting Group"), PosSession.FunctionalityProfile."Price Rounding to");

                    POSTransLine.CalcPrices;
                    POSTransLine.Modify;
                end;
            until POSTransLine.Next = 0;
        end;

        if tmpPOSTransLineOfferUpd.FindSet then
            repeat
                POSTransLine.Get(tmpPOSTransLineOfferUpd."Receipt No.", tmpPOSTransLineOfferUpd."Line No.");
                PosPrice.CalcPeriodicDisc(POSTransLine, false);
            until tmpPOSTransLineOfferUpd.Next = 0;

        OnAfterChangeVATBusOnLine(POSTransaction);
    end;

    internal procedure ChangeGenBusPostingGroup(POSTransaction: Record "LSC POS Transaction")
    var
        POSTransLine: Record "LSC POS Trans. Line";
    begin
        POSTransLine.SetRange("Receipt No.", POSTransaction."Receipt No.");
        POSTransLine.SetRange("Entry Type", POSTransLine."Entry Type"::Item);
        if POSTransLine.FindSet() then begin
            if POSTransLine."Gen. Bus. Posting Group" = POSTransaction."Gen. Bus. Posting Group" then
                exit;
            repeat
                POSTransLine."Gen. Bus. Posting Group" := POSTransaction."Gen. Bus. Posting Group";
                POSTransLine.Modify();
            until POSTransLine.Next() = 0;
        end;
    end;

    internal procedure LogStaffInOut(StaffID: Code[20]; ActionInt: Integer; var Msg: Text[120])
    var
        TimeEntry: Record "LSC Time Registration Entry";
        TimeRegUtils: Codeunit "LSC Time Reg. Utils";
        BeginEntry: Integer;
        ErrorCode: Integer;
        Bool: Boolean;
    begin
        InitPosFunctions;
        if not PosSession.FunctionalityProfile."TS Login Staff" then begin
            TimeRegUtils.PosLogInOut(StaffID, ActionInt, Msg);
            exit;
        end;

        TimeEntry.SetRange("Staff ID", StaffID);
        if TimeEntry.FindLast then
            BeginEntry := TimeEntry."Entry No."
        else
            BeginEntry := 0;

        TSUtil.GetTimeReg(StaffID, ErrorCode);
        if ErrorCode <> 0 then begin
            Msg := TransactionServerConnFailedErr;
            exit;
        end;

        Bool := TimeRegUtils.PosLogInOut(StaffID, ActionInt, Msg);

        TimeEntry.SetFilter("Entry No.", '>=%1', BeginEntry);
        if Bool then
            if not TSUtil.UpdateTimeReg(TimeEntry) then
                Msg := TransactionServerConnFailedErr;

        TimeEntry.SetFilter("Entry No.", '>%1', BeginEntry);
        TimeEntry.DeleteAll;
    end;

    internal procedure CorrectStaffTimeReg(StaffID: Code[20]; var Msg: Text[120])
    var
        TimeEntry: Record "LSC Time Registration Entry";
        tmpTimeEntry: Record "LSC Time Registration Entry" temporary;
        beginEntry: Integer;
        ErrorCode: Integer;
        Text061: Label 'No Record found to correct';
    begin
        TimeEntry.SetRange("Staff ID", StaffID);
        InitPosFunctions;
        if PosSession.FunctionalityProfile."TS Login Staff" then begin
            if TimeEntry.FindLast then
                beginEntry := TimeEntry."Entry No."
            else
                beginEntry := 0;
            TSUtil.GetTimeReg(StaffID, ErrorCode);
            if ErrorCode <> 0 then begin
                Msg := TransactionServerConnFailedErr;
                exit;
            end;
        end;

        if TimeEntry.FindLast then begin
            tmpTimeEntry := TimeEntry;
            tmpTimeEntry.Insert;
            Commit;
            Page.RunModal(Page::"LSC Time Reg. Correction", tmpTimeEntry);
            tmpTimeEntry.Get(tmpTimeEntry."Staff ID", tmpTimeEntry."Entry No.");
            TimeEntry := tmpTimeEntry;
            TimeEntry.Modify;
        end else
            Msg := Text061;

        if PosSession.FunctionalityProfile."TS Login Staff" then begin
            TimeEntry.SetFilter("Entry No.", '=%1', TimeEntry."Entry No.");
            if not TSUtil.UpdateTimeReg(TimeEntry) then
                Msg := TransactionServerConnFailedErr;
            TimeEntry.SetFilter("Entry No.", '>%1', beginEntry);
            TimeEntry.DeleteAll;
        end;
    end;

    internal procedure RetBarcPriceAndQty(var RetBarcPrice: Decimal; var RetBarcQty: Decimal)
    begin
        RetBarcPrice := BarcPrice;
        RetBarcQty := BarcQty;
    end;

    procedure POSlog(var MenuLine: Record "LSC POS Menu Line"; CurrReceipt: Code[20])
    var
        "Pos Log": Record "LSC POS Log";
        NextSeq: Integer;
    begin
        "Pos Log".SetRange("Pos Log"."Entry Date", Today);
        "Pos Log".SetRange("Pos Log"."Entry Time", Time());
        "Pos Log".SetRange("Store No.", PosSession.Terminal."Store No.");
        "Pos Log".SetRange("Pos Log"."Terminal No.", PosSession.Terminal."No.");
        "Pos Log".SetRange("Pos Log"."Staff ID", POSSESSION.StaffID);
        "Pos Log".SetRange("Pos Log"."Receipt No.", CurrReceipt);

        if "Pos Log".FindLast then
            NextSeq := "Pos Log".Sequence + 1
        else
            NextSeq := 1;

        "Pos Log".Init;
        "Pos Log"."Entry Date" := Today;
        "Pos Log"."Entry Time" := Time;
        "Pos Log"."Terminal No." := POSSESSION.TerminalNo;
        "Pos Log"."Staff ID" := POSSESSION.StaffID;
        "Pos Log"."Receipt No." := CurrReceipt;
        "Pos Log"."Store No." := PosSession.Terminal."Store No.";
        "Pos Log".Sequence := NextSeq;
        "Pos Log"."Menu ID" := MenuLine."Menu ID";
        "Pos Log"."POS Command" := MenuLine.Command;
        "Pos Log"."POS Parameter" := MenuLine.Parameter;
        "Pos Log".Insert(true);
    end;

    procedure InsertTmpTrans(var LastSlipNo: Code[20]; ShiftNo: Code[1]; SetSalesType: Code[20]; TableNo: Integer; TrainingActive: Boolean; TableDescr: Text) NewSlipNo: Code[20]
    var
        TmpTrans: Record "LSC POS Transaction";
        SalesTypes: Record "LSC Sales Type";
        Seq: Integer;
        LoopCount: Integer;
        InsertOK: Boolean;
        ReUseOk: Boolean;
    begin
        ReadLocalVar(LastSlipNo);
        if (SkipIncrementSlipno) then
            ReUseOk := true
        else
            LastSlipNo := IncStr(LastSlipNo);

        SkipIncrementSlipno := false;

        if not TmpTrans.RecordLevelLocking then
            TmpTrans.LockTable(true, true);

        TmpTrans."Receipt No." := ZeroPad(POSSESSION.TerminalNo, 10) + ZeroPad(LastSlipNo, 9);
        TmpTrans."New Transaction" := true;
        TmpTrans."Store No." := POSSESSION.StoreNo;
        TmpTrans."POS Terminal No." := POSSESSION.TerminalNo;
        TmpTrans."Created on POS Terminal" := POSSESSION.TerminalNo;
        TmpTrans."Staff ID" := POSSESSION.StaffID;
        TmpTrans."Shift No." := ShiftNo;
        TmpTrans."Gen. Bus. Posting Group" := PosSession.Store."Gen. Bus. Post. Gr.";
        TmpTrans."VAT Bus.Posting Group" := PosSession.Store."Store VAT Bus. Post. Gr.";
        OnAfterInitTmpTransFromStoreSetup(TmpTrans, PosSession.Store);
        TmpTrans."Sale Is Return Sale" := false;
        TmpTrans."Sales Type" := SetSalesType;
        TmpTrans."Table No." := TableNo;

        if POSSession.Store."Kitchen Prod. System in Use" = "LSC Store KitchenPrintingInUse"::"Yes" then begin
            TmpTrans."Active Kitchen Service" := POSSession.Store."Store KDS in Use";
        end;

        if TableNo <> 0 then
            TmpTrans.Comment := StrSubstNo(TableMsg, Format(TableNo));
        TmpTrans."Dining Tbl. Description" := TableDescr;

        if TrainingActive then
            TmpTrans."Entry Status" := TmpTrans."Entry Status"::Training
        else
            TmpTrans."Entry Status" := TmpTrans."Entry Status"::" ";

        if SetSalesType <> '' then
            if SalesTypes.Get(SetSalesType) then begin
                if SalesTypes."VAT Bus. Posting Group" <> '' then
                    TmpTrans.Validate("VAT Bus.Posting Group", SalesTypes."VAT Bus. Posting Group");
                if SalesTypes."Price Group" <> '' then
                    TmpTrans.Validate(TmpTrans."Price Group Code", SalesTypes."Price Group");
            end;

        TmpTrans."Hosp. Type Sequence" := 0;
        if Evaluate(Seq, POSSESSION.GetValue("LSC POS Tag"::"HOSTYPSEQ")) then
            TmpTrans."Hosp. Type Sequence" := Seq;

        LoopCount := 0;
        InsertOK := false;

        if not TmpTrans.Insert then begin
            IF ReUseOk then begin
                IF TmpTrans.modify then
                    InsertOK := true;
            end
            ELSE
                while (not InsertOK) and (LoopCount < 2) do begin
                    LoopCount += 1;
                    Sleep(100);
                    LastSlipNo := IncStr(LastSlipNo);
                    TmpTrans."Receipt No." :=
                    ZeroPad(POSSESSION.TerminalNo, 10) +
                    ZeroPad(LastSlipNo, 9);
                    if TmpTrans.Insert then
                        InsertOK := true;
                end;
        end else
            InsertOK := true;

        if not InsertOK then
            TmpTrans.Insert;

        if (TableNo > 0) or PosSession.FunctionalityProfile."Print Copy No. on Pre-Receipt" then begin
            Clear(PosTrGuestInfo1);
            if PosTrGuestInfo1.Get(TmpTrans."Receipt No.", 0) then begin
                PosTrGuestInfo1."Table No." := TableNo;
                PosTrGuestInfo1.Modify;
            end else begin
                PosTrGuestInfo1.Init;
                PosTrGuestInfo1."Receipt No." := TmpTrans."Receipt No.";
                PosTrGuestInfo1."Table No." := TableNo;
                PosTrGuestInfo1.Insert(true);
            end;
        end;

        Commit;
        WriteLocalVar(LastSlipNo);

        exit(TmpTrans."Receipt No.");
    end;

    internal procedure InitReusedTrans(var ExistingPosTrans: Record "LSC POS Transaction"; ShiftNo: Code[1]; SetSalesType: Code[20]; TableNo: Integer; TrainingActive: Boolean; TableDescr: Text) NewSlipNo: Code[20]
    var
        SalesTypes: Record "LSC Sales Type";
        Seq: Integer;
    begin
        ExistingPosTrans."New Transaction" := true;
        ExistingPosTrans."Store No." := POSSESSION.StoreNo;
        ExistingPosTrans."POS Terminal No." := POSSESSION.TerminalNo;
        ExistingPosTrans."Created on POS Terminal" := POSSESSION.TerminalNo;
        ExistingPosTrans."Staff ID" := POSSESSION.StaffID;
        ExistingPosTrans."Shift No." := ShiftNo;
        ExistingPosTrans."Gen. Bus. Posting Group" := PosSession.Store."Gen. Bus. Post. Gr.";
        ExistingPosTrans."VAT Bus.Posting Group" := PosSession.Store."Store VAT Bus. Post. Gr.";
        ExistingPosTrans."Sale Is Return Sale" := false;
        ExistingPosTrans."Sales Type" := SetSalesType;
        ExistingPosTrans."Table No." := TableNo;
        if TableNo <> 0 then
            ExistingPosTrans.Comment := StrSubstNo(TableMsg, Format(TableNo));
        ExistingPosTrans."Dining Tbl. Description" := TableDescr;

        if TrainingActive then
            ExistingPosTrans."Entry Status" := ExistingPosTrans."Entry Status"::Training
        else
            ExistingPosTrans."Entry Status" := ExistingPosTrans."Entry Status"::" ";

        if SetSalesType <> '' then
            if SalesTypes.Get(SetSalesType) then begin
                if SalesTypes."VAT Bus. Posting Group" <> '' then
                    ExistingPosTrans.Validate("VAT Bus.Posting Group", SalesTypes."VAT Bus. Posting Group");
                if SalesTypes."Price Group" <> '' then
                    ExistingPosTrans.Validate(ExistingPosTrans."Price Group Code", SalesTypes."Price Group");
            end;

        ExistingPosTrans."Hosp. Type Sequence" := 0;
        if Evaluate(Seq, POSSESSION.GetValue("LSC POS Tag"::"HOSTYPSEQ")) then
            ExistingPosTrans."Hosp. Type Sequence" := Seq;

        ExistingPosTrans.Modify;

        if (TableNo > 0) or PosSession.FunctionalityProfile."Print Copy No. on Pre-Receipt" then begin
            Clear(PosTrGuestInfo1);
            if PosTrGuestInfo1.Get(ExistingPosTrans."Receipt No.", 0) then begin
                PosTrGuestInfo1."Table No." := TableNo;
                PosTrGuestInfo1.Modify;
            end else begin
                PosTrGuestInfo1.Init;
                PosTrGuestInfo1."Receipt No." := ExistingPosTrans."Receipt No.";
                PosTrGuestInfo1."Table No." := TableNo;
                PosTrGuestInfo1.Insert(true);
            end;
        end;

        Commit;
    end;

    internal procedure ProcessMSRStaffLogin(pMSRTrack: Text; var pStaffID: Text): Boolean
    var
        msrCards: Record "LSC MSR Card Link Setup";
        MSRDevice: Record "LSC POS MSR";
        deviceID: Code[20];
        Text301: Label '%1 must not be %2 in %3 %4';
    begin
        if not PosSession.FunctionalityProfile."Allow MSR Cards" then begin
            PosCtrl.PosMessage(
              StrSubstNo(
                Text301, PosSession.FunctionalityProfile.FieldCaption("Allow MSR Cards"), PosSession.FunctionalityProfile."Allow MSR Cards",
                PosSession.FunctionalityProfile.TableCaption, PosSession.FunctionalityProfile."Profile ID"));
        end
        else begin
            deviceID := PosSession.HardwareProfile().GetHardwareProfileDeviceId("LSC Hardware Profile Devices"::MSR);
            if MSRDevice.Get(deviceID) then begin
                if MSRDevice."Use Non-Payment Track Handling" then
                    pMSRTrack := MSRDevice.EditNonPaymentTrack(pMSRTrack);

                if StrLen(pMSRTrack) <= MaxStrLen(msrCards."Card Number") then
                    if msrCards.Get(pMSRTrack) then begin
                        if msrCards."Link Type" = msrCards."Link Type"::Cashier then begin
                            pStaffID := msrCards."Link No.";
                            exit(true);
                        end
                    end
            end
        end;

        exit(false);
    end;

    internal procedure GetSuggestedQty(Item: Record Item): Decimal
    var
        ItemCategory: Record "Item Category";
        ProductGroup: Record "LSC Retail Product Group";
        SuggestedQty: Decimal;
    begin
        SuggestedQty := Item."LSC Suggested Qty. on POS";

        if SuggestedQty = 0 then
            if (Item."Item Category Code" <> '') and (Item."LSC Retail Product Code" <> '') then
                if ProductGroup.Get(Item."Item Category Code", Item."LSC Retail Product Code") then
                    SuggestedQty := ProductGroup."Suggested Qty. on POS";

        if SuggestedQty = 0 then
            if Item."Item Category Code" <> '' then
                if ItemCategory.Get(Item."Item Category Code") then
                    SuggestedQty := ItemCategory."LSC Suggested Qty. on POS";

        exit(SuggestedQty);
    end;

    procedure GetTransInUseOnPos(ReceiptNo: Code[20]): Code[20]
    var
        TableInUseOnPos: Record "LSC Transaction in Use on POS";
    begin
        if not BOUtils.IsHospitalityPermitted then
            exit('');

        if TableInUseOnPos.Get(ReceiptNo) then
            exit(TableInUseOnPos."In Use on POS Terminal");

        exit('');
    end;

    internal procedure InsertTransInUseOnPos(ReceiptNo: Code[20]; InUseOnPos: Code[10]; CommitOk: Boolean; Lock: Boolean): Boolean
    var
        TableInUseOnPos: Record "LSC Transaction in Use on POS";
    begin
        if not BOUtils.IsHospitalityPermitted then
            exit(false);
        if InUseOnPos = '' then
            exit(false);

        if Lock then begin
            if TableInUseOnPos.Get(ReceiptNo) then begin
                if (TableInUseOnPos."In Use on POS Terminal" <> '') then
                    if (TableInUseOnPos."In Use on POS Terminal" <> InUseOnPos) then  //already locked, cannot lock
                        exit(false);
                if (TableInUseOnPos."In Use on POS Terminal" <> InUseOnPos) then begin
                    TableInUseOnPos."In Use on POS Terminal" := InUseOnPos;
                    TableInUseOnPos."Staff ID" := POSSESSION.StaffID;
                    TableInUseOnPos."User ID" := UserId;
                    TableInUseOnPos."Date-Time Set" := CurrentDateTime;
                    TableInUseOnPos.Modify;
                end;
            end else begin
                TableInUseOnPos."Receipt No." := ReceiptNo;
                TableInUseOnPos."In Use on POS Terminal" := InUseOnPos;
                TableInUseOnPos."Staff ID" := POSSESSION.StaffID;
                TableInUseOnPos."User ID" := UserId;
                TableInUseOnPos."Date-Time Set" := CurrentDateTime;
                TableInUseOnPos.Insert;
                if CommitOk then
                    Commit;
            end;
        end else begin
            if TableInUseOnPos.Get(ReceiptNo) then begin
                if TableInUseOnPos."In Use on POS Terminal" = InUseOnPos then begin  //unlock only if locked by this terminal
                    TableInUseOnPos."In Use on POS Terminal" := '';
                    TableInUseOnPos."Staff ID" := POSSESSION.StaffID;
                    TableInUseOnPos."User ID" := UserId;
                    TableInUseOnPos."Date-Time Released" := CurrentDateTime;
                    TableInUseOnPos.Modify;
                end else
                    exit(false);
            end;
        end;
        exit(true);
    end;

    procedure InsertTransInUseOnPosStaff(ReceiptNo: Code[20]; InUseOnPos: Code[10]; StaffID: Code[20]; CommitOk: Boolean; Lock: Boolean): Boolean
    var
        TableInUseOnPos: Record "LSC Transaction in Use on POS";
    begin
        if not BOUtils.IsHospitalityPermitted then
            exit(false);
        if InUseOnPos = '' then
            exit(false);

        if Lock then begin
            if TableInUseOnPos.Get(ReceiptNo) then begin
                if (TableInUseOnPos."In Use on POS Terminal" <> '') then
                    if (TableInUseOnPos."In Use on POS Terminal" <> InUseOnPos) then
                        if TableInUseOnPos."Staff ID" <> StaffID then                    //already locked, cannot lock
                            exit(false);
                TableInUseOnPos."In Use on POS Terminal" := InUseOnPos;
                TableInUseOnPos."Staff ID" := StaffID;
                TableInUseOnPos."User ID" := UserId;
                TableInUseOnPos."Date-Time Set" := CurrentDateTime;
                TableInUseOnPos.Modify;
            end else begin
                TableInUseOnPos."Receipt No." := ReceiptNo;
                TableInUseOnPos."In Use on POS Terminal" := InUseOnPos;
                TableInUseOnPos."Staff ID" := StaffID;
                TableInUseOnPos."User ID" := UserId;
                TableInUseOnPos."Date-Time Set" := CurrentDateTime;
                TableInUseOnPos.Insert;
                if CommitOk then
                    Commit;
            end;
        end else begin
            if TableInUseOnPos.Get(ReceiptNo) then begin
                if (TableInUseOnPos."In Use on POS Terminal" = '') and (TableInUseOnPos."Staff ID" = '') then
                    exit(true);
                if (TableInUseOnPos."In Use on POS Terminal" = InUseOnPos) or (TableInUseOnPos."Staff ID" = StaffID) then begin
                    //unlock only if locked by this terminal or staff
                    TableInUseOnPos."In Use on POS Terminal" := '';
                    TableInUseOnPos."Staff ID" := '';
                    TableInUseOnPos."User ID" := UserId;
                    TableInUseOnPos."Date-Time Released" := CurrentDateTime;
                    TableInUseOnPos.Modify;
                end else
                    exit(false);
            end;
        end;
        exit(true);
    end;

    procedure UpdateTransPrices(PosTrans: Record "LSC POS Transaction")
    var
        PosSL: Record "LSC POS Trans. Line";
        splitline: Record "LSC POS Trans. Line";
        PosTransLineTemp1: Record "LSC POS Trans. Line" temporary;
        PosPriceUtil: Codeunit "LSC POS Price Utility";
        PerDiscType: Option "' ",Multibuy,"Mix&Match","Disc. Offer","Item Point'";
    begin
        PosSL.Reset;
        PosSL.SetRange("Receipt No.", PosTrans."Receipt No.");
        PosSL.SetRange("Entry Type", PosSL."Entry Type"::Item);

        if PosSL.FindSet(true) then
            repeat
                PosPriceUtil.UpdatePrice(PosSL);
                PosSL.CalcPrices;
                PosPriceUtil.CalcPeriodicDisc(PosSL, true);
                PosSL.Modify;
            until PosSL.Next = 0;

        PosPriceUtil.CalcPeriodicOnTotalPressed(PosTrans);
        if PosPriceUtil.IsTransPerDiscType(PosTrans, PerDiscType::"Mix&Match") then begin
            splitline.Reset;
            splitline.SetFilter("Receipt No.", PosTrans."Receipt No.");
            if splitline.FindSet then
                repeat
                    PosPriceUtil.SplitMixMatchLine(splitline, PosTransLineTemp1);
                until splitline.Next = 0;
        end;
        RecalcSlip(PosTrans);
    end;

    procedure CopyItemsFromPostTrans(var PosTr: Record "LSC POS Transaction"; TransHdr: Record "LSC Transaction Header")
    var
        PosTrLine: Record "LSC POS Trans. Line";
        TransSalesEntry: Record "LSC Trans. Sales Entry";
        PosTrInfocodeEntry: Record "LSC POS Trans. Infocode Entry";
        ParentTransInfoEntry: Record "LSC Trans. Infocode Entry";
        TextTransInfoEntry: Record "LSC Trans. Infocode Entry";
        PosVariant: Record "Item Variant";
        DealModItem: Record "LSC Deal Modifier Item";
        BomComp: Record "BOM Component";
        splitline: Record "LSC POS Trans. Line";
        PosTransLineTemp1: Record "LSC POS Trans. Line" temporary;
        Item: Record Item;
        InfoSubcode: Record "LSC Information Subcode";
        ParentInfoSubcode: Record "LSC Information Subcode";
        PosPriceUtil: Codeunit "LSC POS Price Utility";
        UnitOfMeasureMgt: Codeunit "Unit of Measure Management";
        ItemUOM: Code[10];
        TransDate: Date;
        TransTime: Time;
        UOMFactor: Decimal;
        ItemPrice: Decimal;
        ItemQty: Decimal;
        PerDiscType: Option "' ",Multibuy,"Mix&Match","Disc. Offer","Item Point'";
        CurrParentLine: Integer;
        LinkedParentNo: Integer;
        SkipLine: Boolean;
        PriceUpdated: Boolean;
        SetPrice: Boolean;
    begin
        PosTrLine.Reset;
        CurrParentLine := 0;
        Clear(DealPosTransLineTmp);
        DealPosTransLineTmp.DeleteAll;
        Clear(POSTransLineTemp);
        POSTransLineTemp.DeleteAll;
        Clear(POSTransLineTemp2);
        POSTransLineTemp2.DeleteAll;
        Clear(TmpPosTrInfoEntry);
        TmpPosTrInfoEntry.DeleteAll;

        PosTransDiscFlush;
        PosTransDiscLoadData(PosTr."Receipt No.", true);

        TransDate := Today;
        TransTime := Time;

        TransSalesEntry.SetRange("Store No.", TransHdr."Store No.");
        TransSalesEntry.SetRange("POS Terminal No.", TransHdr."POS Terminal No.");
        TransSalesEntry.SetRange("Transaction No.", TransHdr."Transaction No.");
        if TransSalesEntry.FindSet then begin
            repeat
                POSTransLineTemp.Init;
                POSTransLineTemp."Receipt No." := PosTr."Receipt No.";
                POSTransLineTemp."Store No." := PosTr."Store No.";
                POSTransLineTemp."POS Terminal No." := PosTr."POS Terminal No.";
                POSTransLineTemp."Entry Type" := PosTrLine."Entry Type"::Item;
                POSTransLineTemp."Line No." := TransSalesEntry."Line No.";
                POSTransLineTemp."Parent Line" := TransSalesEntry."Line No.";
                POSTransLineTemp."Barcode No." := TransSalesEntry."Barcode No.";
                POSTransLineTemp."Entry Status" := 0;
                POSTransLineTemp."Sales Type" := PosTr."Sales Type";
                if Item.Get(TransSalesEntry."Item No.") then begin
                    POSTransLineTemp.Validate(Number, TransSalesEntry."Item No.");
                    POSTransLineTemp."Variant Code" := TransSalesEntry."Variant Code";
                    if PosVariant.Get(POSTransLineTemp.Number, POSTransLineTemp."Variant Code") then
                        POSTransLineTemp.Description :=
                          CopyStr(
                            PosVariant.Description + ' ' + PosVariant."Description 2", 1, MaxStrLen(POSTransLineTemp.Description));

                    if TransSalesEntry."Unit of Measure" <> Item."Base Unit of Measure" then begin
                        if TransSalesEntry."Unit of Measure" <> Item."Sales Unit of Measure" then begin
                            POSTransLineTemp.Validate("Unit of Measure", TransSalesEntry."Unit of Measure");
                            POSTransLineTemp.Validate(Quantity, -TransSalesEntry."UOM Quantity");
                        end else begin
                            UOMFactor := UnitOfMeasureMgt.GetQtyPerUnitOfMeasure(Item, TransSalesEntry."Unit of Measure");
                            if UOMFactor <> 0 then
                                POSTransLineTemp.Validate(Quantity, Round(-TransSalesEntry.Quantity / UOMFactor, 0.00001))
                            else
                                POSTransLineTemp.Validate(Quantity, -TransSalesEntry.Quantity);
                        end;
                    end else
                        POSTransLineTemp.Validate(Quantity, -TransSalesEntry.Quantity);
                    if (TransSalesEntry."Orig. of a Linked Item List" = true) then begin
                        POSTransLineTemp."Orig. of a Linked Item List" := true;
                        LinkedParentNo := TransSalesEntry."Line No.";
                    end;
                    if (TransSalesEntry."Linked No. not Orig." = true) then begin
                        POSTransLineTemp."Linked No. not Orig." := true;
                        POSTransLineTemp."Parent Line" := LinkedParentNo;
                    end;
                    if Item."LSC Qty. Becomes Negative" then
                        POSTransLineTemp."Item/Dept. Negative" := true;
                    SkipLine := false;
                    PriceUpdated := false;

                    if TransSalesEntry."Deal Line" and (TransSalesEntry."Promotion No." <> '') then begin
                        PosTransLineTemp."Trans. Date" := TransDate;
                        PosTransLineTemp."Trans. Time" := TransTime;
                        if not CheckIfDealValid(TransSalesEntry, POSTransLineTemp) then
                            SkipLine := true
                        else begin
                            POSTransLineTemp."Disc. Info Line No." := TransSalesEntry."Deal Header Line No.";
                            POSTransLineTemp."Deal Line" := true;
                            POSTransLineTemp."Deal Modifier Line No." := TransSalesEntry."Deal Modifier Line No.";
                            POSTransLineTemp."Deal Line No." := TransSalesEntry."Deal Line No.";
                            PosPriceUtil.UpdatePrice(POSTransLineTemp);
                            PriceUpdated := true;
                            POSTransLineTemp."Promotion No." := TransSalesEntry."Promotion No.";
                            POSTransLineTemp."Parent Line" := TransSalesEntry."Deal Header Line No.";
                            if DealModItem.Get(POSTransLineTemp."Promotion No.", POSTransLineTemp."Deal Line No.", POSTransLineTemp."Deal Modifier Line No.") then begin
                                POSTransLineTemp."Deal Added Amount" := DealModItem."Added Amount" * POSTransLineTemp.Quantity;
                                POSTransLineTemp."Unit of Measure" := DealModItem."Unit of Measure";
                            end;
                        end;
                    end;

                    SetPrice := false;
                    ItemPrice := 0;
                    if TransSalesEntry."Excluded BOM Line No." <> 0 then begin
                        if not BomComp.Get(TransSalesEntry."Parent Item No.", TransSalesEntry."Excluded BOM Line No.") then
                            SkipLine := true
                        else begin
                            if BomComp."No." <> TransSalesEntry."Item No." then
                                SkipLine := true
                            else begin
                                if BomComp."LSC Exclusion" = BomComp."LSC Exclusion"::"Price Reduces" then begin
                                    if BomComp."LSC Price on Exclusion" = 0 then begin
                                        if TransSalesEntry.Price = 0 then begin
                                            SetPrice := true;
                                            ItemPrice := 0;
                                        end else
                                            SetPrice := false;
                                    end else begin
                                        if TransSalesEntry.Price = 0 then begin
                                            SetPrice := true;
                                            ItemPrice := 0;
                                        end else begin
                                            SetPrice := true;
                                            ItemPrice := BomComp."LSC Price on Exclusion" / BomComp."Quantity per";
                                        end;
                                    end;
                                end else begin
                                    SetPrice := true;
                                    ItemPrice := 0;
                                end;
                                if SetPrice then begin
                                    POSTransLineTemp.Validate(Price, ItemPrice);
                                    PriceUpdated := true;
                                end;
                            end;
                        end;
                    end;

                    SetPrice := false;
                    ItemPrice := 0;
                    if TransSalesEntry."Orig. from Infocode" <> '' then begin
                        if InfoSubcode.Get(TransSalesEntry."Orig. from Infocode", TransSalesEntry."Orig. from Subcode") then begin
                            if CurrParentLine <> TransSalesEntry."Parent Line No." then begin
                                POSTransLineTemp2.Get(PosTr."Receipt No.", TransSalesEntry."Parent Line No.");
                                CurrParentLine := TransSalesEntry."Parent Line No.";
                                ItemPrice := POSTransLineTemp2.Price;
                            end;
                            if not ParentTransInfoEntry.Get(
                                     TransSalesEntry."Store No.", TransSalesEntry."POS Terminal No.", TransSalesEntry."Transaction No.",
                                     ParentTransInfoEntry."Transaction Type"::"Sales Entry", TransSalesEntry."Parent Line No.",
                                     TransSalesEntry."Orig. from Infocode", TransSalesEntry."Infocode Entry Line No.")
                            then
                                SkipLine := true;
                            if not SkipLine then begin
                                SetPrice := false;
                                PopUpFunctions().GetItemSubcodeItemInfo(InfoSubcode, ItemPrice, SetPrice, ItemQty, ItemUOM, PosTr."Trans. Currency Code");
                                if TransSalesEntry.Price = 0 then begin
                                    SetPrice := true;
                                    ItemPrice := 0;
                                end;
                                TmpPosTrInfoEntry.Init;
                                TmpPosTrInfoEntry."Receipt No." := PosTr."Receipt No.";
                                TmpPosTrInfoEntry."Transaction Type" := TmpPosTrInfoEntry."Transaction Type"::"Sales Entry";
                                TmpPosTrInfoEntry."Line No." := POSTransLineTemp2."Line No.";
                                TmpPosTrInfoEntry.Infocode := ParentTransInfoEntry.Infocode;
                                TmpPosTrInfoEntry."Entry Line No." := ParentTransInfoEntry."Entry Line No.";
                                TmpPosTrInfoEntry."Store No." := PosTr."Store No.";
                                TmpPosTrInfoEntry.Information := ParentTransInfoEntry.Information;
                                TmpPosTrInfoEntry."Info. Amt." := ParentTransInfoEntry."Info. Amt.";
                                TmpPosTrInfoEntry.Date := TransDate;
                                TmpPosTrInfoEntry.Time := TransTime;
                                TmpPosTrInfoEntry."POS Terminal No." := PosTr."POS Terminal No.";
                                TmpPosTrInfoEntry."Staff ID" := PosTr."Staff ID";
                                TmpPosTrInfoEntry."No." := ParentTransInfoEntry."No.";
                                TmpPosTrInfoEntry."Variant Code" := ParentTransInfoEntry."Variant Code";
                                TmpPosTrInfoEntry.Amount := ParentTransInfoEntry.Amount;
                                TmpPosTrInfoEntry."Type of Input" := ParentTransInfoEntry."Type of Input";
                                TmpPosTrInfoEntry.Subcode := ParentTransInfoEntry.Subcode;
                                TmpPosTrInfoEntry."Entry Variant Code" := ParentTransInfoEntry."Entry Variant Code";
                                TmpPosTrInfoEntry."Entry Trigger Function" := ParentTransInfoEntry."Entry Trigger Function";
                                TmpPosTrInfoEntry."Entry Trigger Code" := ParentTransInfoEntry."Entry Trigger Code";
                                TmpPosTrInfoEntry."Source Code" := ParentTransInfoEntry."Source Code";
                                TmpPosTrInfoEntry."Selected Quantity" := ParentTransInfoEntry."Selected Quantity";
                                TmpPosTrInfoEntry.Counter := ParentTransInfoEntry.Counter;
                                TmpPosTrInfoEntry.Status := TmpPosTrInfoEntry.Status::Processed;
                                TmpPosTrInfoEntry."Set Price" := SetPrice;
                                TmpPosTrInfoEntry."New Price" := ItemPrice;
                                TmpPosTrInfoEntry."Skip Posting to Info. Entry" := false;
                                TmpPosTrInfoEntry."Line Inserted and Linked" := true;
                                TmpPosTrInfoEntry."Sel. Qty. (Set Price)" := 0;
                                TmpPosTrInfoEntry.Insert;
                            end;
                        end else
                            SkipLine := true;

                        if not SkipLine then begin
                            if ItemUOM <> '' then
                                POSTransLineTemp.Validate("Unit of Measure", ItemUOM);
                            if SetPrice then
                                POSTransLineTemp.Validate(Price, ItemPrice)
                            else
                                PosPriceUtil.UpdatePrice(POSTransLineTemp);
                            PriceUpdated := true;
                            POSTransLineTemp."Parent Line" := TransSalesEntry."Parent Line No.";
                            POSTransLineTemp."Orig. from Infocode" := TransSalesEntry."Orig. from Infocode";
                            POSTransLineTemp."Orig. from Subcode" := TransSalesEntry."Orig. from Subcode";
                            POSTransLineTemp."Infocode Entry Line No." := TransSalesEntry."Infocode Entry Line No.";
                            POSTransLineTemp."Infocode Selected Qty." := TransSalesEntry."Infocode Selected Qty.";
                        end;
                    end;

                    if not PriceUpdated then
                        PosPriceUtil.UpdatePrice(POSTransLineTemp);

                    if not SkipLine then begin
                        POSTransLineTemp.CalcPrices;
                        POSTransLineTemp.Insert;
                        POSTransLineTemp2 := POSTransLineTemp;
                        POSTransLineTemp2.Insert;
                    end;
                end;
            until TransSalesEntry.Next = 0;

            SkipLine := true;
            TextTransInfoEntry.Reset;
            TextTransInfoEntry.SetCurrentKey("Store No.", "POS Terminal No.", "Transaction No.", "Transaction Type", Infocode);
            TextTransInfoEntry.SetRange("Store No.", TransHdr."Store No.");
            TextTransInfoEntry.SetRange("POS Terminal No.", TransHdr."POS Terminal No.");
            TextTransInfoEntry.SetRange("Transaction No.", TransHdr."Transaction No.");
            TextTransInfoEntry.SetRange("Transaction Type", TextTransInfoEntry."Transaction Type"::"Sales Entry");
            TextTransInfoEntry.SetRange(Infocode, 'TEXT');
            IF TextTransInfoEntry.FindSet then
                repeat
                    SkipLine := true;
                    ParentTransInfoEntry.Reset;
                    ParentTransInfoEntry.SetCurrentKey("Store No.", "POS Terminal No.", "Transaction No.", "Line No.", "Transaction Type");
                    ParentTransInfoEntry.SetRange("Store No.", TransHdr."Store No.");
                    ParentTransInfoEntry.SetRange("POS Terminal No.", TransHdr."POS Terminal No.");
                    ParentTransInfoEntry.SetRange("Transaction No.", TransHdr."Transaction No.");
                    ParentTransInfoEntry.SetRange("Line No.", TextTransInfoEntry.ParentLine);
                    ParentTransInfoEntry.SetRange("Transaction Type", ParentTransInfoEntry."Transaction Type"::"Sales Entry");
                    if ParentTransInfoEntry.FindSet then begin
                        repeat
                            if ParentInfoSubcode.Get(ParentTransInfoEntry.Infocode, ParentTransInfoEntry.Subcode) then
                                if TextTransInfoEntry.Information = ParentInfoSubcode.Description then
                                    SkipLine := false;
                        until (ParentTransInfoEntry.Next = 0) or (SkipLine = false);
                    end;

                    if not SkipLine then begin
                        POSTransLineTemp.Init;
                        POSTransLineTemp."Receipt No." := PosTr."Receipt No.";
                        POSTransLineTemp."Store No." := PosTr."Store No.";
                        POSTransLineTemp."POS Terminal No." := PosTr."POS Terminal No.";
                        POSTransLineTemp."Entry Type" := PosTransLineTemp."Entry Type"::FreeText;
                        POSTransLineTemp.Description := TextTransInfoEntry.Information;
                        POSTransLineTemp."Line No." := TextTransInfoEntry."Line No.";
                        PosTransLineTemp."Parent Line" := TextTransInfoEntry.ParentLine;
                        PosTransLineTemp."Kitchen Routing" := PosTransLineTemp."Kitchen Routing"::"Follow Parent";
                        POSTransLineTemp."Entry Status" := 0;
                        POSTransLineTemp."Sales Type" := PosTr."Sales Type";
                        PosTransLineTemp."Orig. from Infocode" := ParentTransInfoEntry.Infocode;
                        PosTransLineTemp."Orig. from Subcode" := ParentTransInfoEntry.Subcode;

                        TmpPosTrInfoEntry.Init;
                        TmpPosTrInfoEntry."Receipt No." := PosTr."Receipt No.";
                        TmpPosTrInfoEntry."Transaction Type" := TmpPosTrInfoEntry."Transaction Type"::"Sales Entry";
                        TmpPosTrInfoEntry."Line No." := TextTransInfoEntry."Line No.";
                        TmpPosTrInfoEntry.Infocode := TextTransInfoEntry.Infocode;
                        TmpPosTrInfoEntry."Entry Line No." := TextTransInfoEntry."Entry Line No.";
                        TmpPosTrInfoEntry."Store No." := PosTr."Store No.";
                        TmpPosTrInfoEntry.Information := TextTransInfoEntry.Information;
                        TmpPosTrInfoEntry."Info. Amt." := TextTransInfoEntry."Info. Amt.";
                        TmpPosTrInfoEntry.Date := TransDate;
                        TmpPosTrInfoEntry.Time := TransTime;
                        TmpPosTrInfoEntry."POS Terminal No." := PosTr."POS Terminal No.";
                        TmpPosTrInfoEntry."Staff ID" := PosTr."Staff ID";
                        TmpPosTrInfoEntry."No." := TextTransInfoEntry."No.";
                        TmpPosTrInfoEntry."Variant Code" := TextTransInfoEntry."Variant Code";
                        TmpPosTrInfoEntry.Amount := TextTransInfoEntry.Amount;
                        TmpPosTrInfoEntry."Type of Input" := TextTransInfoEntry."Type of Input";
                        TmpPosTrInfoEntry.Subcode := TextTransInfoEntry.Subcode;
                        TmpPosTrInfoEntry."Entry Variant Code" := TextTransInfoEntry."Entry Variant Code";
                        TmpPosTrInfoEntry."Entry Trigger Function" := TextTransInfoEntry."Entry Trigger Function";
                        TmpPosTrInfoEntry."Entry Trigger Code" := TextTransInfoEntry."Entry Trigger Code";
                        TmpPosTrInfoEntry."Source Code" := TextTransInfoEntry."Source Code";
                        TmpPosTrInfoEntry."Selected Quantity" := TextTransInfoEntry."Selected Quantity";
                        TmpPosTrInfoEntry.Counter := TextTransInfoEntry.Counter;
                        TmpPosTrInfoEntry.Status := TmpPosTrInfoEntry.Status::Processed;
                        TmpPosTrInfoEntry."Set Price" := false;
                        TmpPosTrInfoEntry."New Price" := 0;
                        TmpPosTrInfoEntry."Skip Posting to Info. Entry" := false;
                        TmpPosTrInfoEntry."Line Inserted and Linked" := true;
                        TmpPosTrInfoEntry."Sel. Qty. (Set Price)" := 0;
                        TmpPosTrInfoEntry.Insert;

                        POSTransLineTemp.Insert;
                    end;
                until TextTransInfoEntry.Next = 0;

            PosTr.Get(PosTr."Receipt No.");
            PosTr."Trans. Date" := TransDate;
            PosTr."Original Date" := TransDate;
            PosTr."Trans Time" := TransTime;
            PosTr.Modify;

            POSTransLineTemp.Reset;
            if POSTransLineTemp.FindSet then
                repeat
                    PosTrLine.Init;
                    PosTrLine := POSTransLineTemp;
                    PosTrLine.InsertLine(POSTransLineTemp."Line No.");
                    OnAfterPosTrLineInsertLine(PosTrLine);
                    if PosTransLineTemp."Entry Type" <> PosTransLineTemp."Entry Type"::FreeText then
                        PosPriceUtil.CalcPeriodicDisc(PosTrLine, true);
                until POSTransLineTemp.Next = 0;

            PosTrLine.Reset;
            PosTrLine.SetRange("Receipt No.", PosTr."Receipt No.");
            PosTrLine.SetRange("Text Type", PosTrLine."Text Type"::"Deal Header");
            if PosTrLine.FindSet then
                repeat
                    PosPriceUtil.RegisterDeal(PosTrLine);
                until PosTrLine.Next = 0;
            PosPriceUtil.CalcPeriodicOnTotalPressed(PosTr);
            if PosPriceUtil.IsTransPerDiscType(PosTr, PerDiscType::"Mix&Match") then begin
                splitline.Reset;
                splitline.SetFilter("Receipt No.", PosTr."Receipt No.");
                if splitline.FindSet then
                    repeat
                        PosPriceUtil.SplitMixMatchLine(splitline, PosTransLineTemp1);
                    until splitline.Next = 0;
            end;
            TmpPosTrInfoEntry.Reset;
            if TmpPosTrInfoEntry.FindSet then
                repeat
                    PosTrInfocodeEntry.Init;
                    PosTrInfocodeEntry := TmpPosTrInfoEntry;
                    PosTrInfocodeEntry.Insert(true);
                until TmpPosTrInfoEntry.Next = 0;
        end;
    end;

    local procedure CheckIfDealValid(TrSalesEntry: Record "LSC Trans. Sales Entry"; NewPOSTransLine: Record "LSC POS Trans. Line"): Boolean
    var
        DealPosTrLine: Record "LSC POS Trans. Line";
        Deal: Record "LSC Offer";
        DealTransEntry: Record "LSC Trans. Sales Entry";
        DealModItem: Record "LSC Deal Modifier Item";
        DealEntry: Record "LSC Trans. Deal Entry";
        RetailPriceUtils: Codeunit "LSC Retail Price Utils";
        InvalidDeal, IsHandled : Boolean;
        Text326: Label 'Deal';
    begin
        if DealPosTransLineTmp.Get(NewPOSTransLine."Receipt No.", TrSalesEntry."Deal Header Line No.") then
            exit(false);

        if DealPosTrLine.Get(NewPOSTransLine."Receipt No.", TrSalesEntry."Deal Header Line No.") then
            exit(true);
        DealPosTransLineTmp.Init;
        DealPosTransLineTmp."Receipt No." := NewPOSTransLine."Receipt No.";
        DealPosTransLineTmp."Line No." := TrSalesEntry."Deal Header Line No.";

        if not Deal.Get(TrSalesEntry."Promotion No.") then begin
            DealPosTransLineTmp.Insert;
            exit(false);
        end;

        if not (RetailPriceUtils.OfferFiltersPassed(
                  Deal, NewPOSTransLine."Store No.", NewPOSTransLine."Sales Type", NewPOSTransLine."Price Group Code") and
           RetailPriceUtils.DiscValPerValid(Deal."Validation Period ID", Today, Time) and
           RetailPriceUtils.MemberFilterPassed(Deal."Member Type", Deal."Member Value") and
           RetailPriceUtils.MemberAttrFilterPassed(Deal."Member Attribute", Deal."Member Attribute Value"))
        then begin
            OnAfterCheckFilterPassed(IsHandled, Deal);
            if not IsHandled then begin
                DealPosTransLineTmp.Insert;
                exit(false);
            end;
        end;

        InvalidDeal := false;
        DealTransEntry.Reset;
        DealTransEntry.SetRange("Store No.", TrSalesEntry."Store No.");
        DealTransEntry.SetRange("POS Terminal No.", TrSalesEntry."POS Terminal No.");
        DealTransEntry.SetRange("Transaction No.", TrSalesEntry."Transaction No.");
        DealTransEntry.SetRange("Deal Header Line No.", TrSalesEntry."Deal Header Line No.");
        DealTransEntry.SetFilter("Deal Modifier Line No.", '<>%1', 0);
        if DealTransEntry.FindSet then
            repeat
                if not DealModItem.Get(Deal."No.", DealTransEntry."Deal Line No.", DealTransEntry."Deal Modifier Line No.") then
                    InvalidDeal := true
                else
                    if DealTransEntry."Item No." <> DealModItem."Item No." then
                        InvalidDeal := true
            until (DealTransEntry.Next = 0) or InvalidDeal;

        if InvalidDeal then begin
            DealPosTransLineTmp.Insert;
            exit(false);
        end;

        DealEntry.Reset;
        DealEntry.SetRange("Store No.", TrSalesEntry."Store No.");
        DealEntry.SetRange("POS Terminal No.", TrSalesEntry."POS Terminal No.");
        DealEntry.SetRange("Transaction No.", TrSalesEntry."Transaction No.");
        DealEntry.SetRange("Deal Header Line No.", TrSalesEntry."Deal Header Line No.");
        if not DealEntry.FindFirst then
            Clear(DealEntry);

        DealPosTrLine.Init;
        DealPosTrLine."Receipt No." := NewPOSTransLine."Receipt No.";
        DealPosTrLine."Store No." := NewPOSTransLine."Store No.";
        DealPosTrLine."POS Terminal No." := NewPOSTransLine."POS Terminal No.";
        DealPosTrLine."Line No." := TrSalesEntry."Deal Header Line No.";
        DealPosTrLine."Entry Type" := DealPosTrLine."Entry Type"::FreeText;
        DealPosTrLine."Text Type" := DealPosTrLine."Text Type"::"Deal Header";
        if Deal.OfferDescription = '' then
            DealPosTrLine.Description := Text326 + ' : ' + Deal."No."
        else
            DealPosTrLine.Description := Deal.OfferDescription;
        DealPosTrLine."Promotion No." := Deal."No.";
        DealPosTrLine."Deal Line" := true;
        DealPosTrLine.Quantity := -DealEntry.Quantity;
        DealPosTrLine."Kitchen Routing" := DealPosTrLine."Kitchen Routing"::Yes;
        DealPosTrLine."Trans. Date" := NewPOSTransLine."Trans. Date";
        DealPosTrLine."Trans. Time" := NewPOSTransLine."Trans. Time";
        DealPosTrLine."Price Group Code" := TrSalesEntry."Price Group Code";
        DealPosTrLine."Sales Type" := TrSalesEntry."Sales Type";
        DealPosTrLine.Insert;

        exit(true);
    end;

    internal procedure PadCardNo(pText: Text[30]): Text[22]
    var
        lTmpLength: Integer;
    begin
        lTmpLength := StrLen(pText);
        if lTmpLength > 4 then
            exit(CopyStr(pText, lTmpLength - 3));

        exit(pText);
    end;

    procedure DeleteCouponQtyUsed()
    var
        POSTransLine: Record "LSC POS Trans. Line";
    begin
        if POSTransLine.Get(LastCouponPOSTransLine_Temp."Receipt No.", LastCouponPOSTransLine_Temp."Line No.") then begin
            POSTransLine."Coupon Qty Used" -= LastCouponPOSTransLine_Temp."Coupon Qty Used";
            if LastCouponPOSTransLine_Temp."Parent Line" <> 0 then begin
                POSTransLine."Coupon Discount Amount" -= LastCouponPOSTransLine_Temp.Amount;
                POSTransLine."Coupon Amt. For Printing" -= LastCouponPOSTransLine_Temp.Amount;
            end;
            POSTransLine.Modify;
        end;

        if TmpPOSTransLine.FindSet then
            repeat
                POSTransLine.Get(TmpPOSTransLine."Receipt No.", TmpPOSTransLine."Line No.");
                POSTransLine."Coupon Qty Used" := 0;
                POSTransLine.Modify;
            until TmpPOSTransLine.Next = 0;
    end;

    procedure AstrxPad(pText: Text[100]) retval: Text[100]
    var
        len: Integer;
    begin
        retval := pText;
        len := StrLen(pText);
        if len > 4 then begin
            while len > 4 do begin
                retval[len - 4] := '*';
                len -= 1;
            end;
        end;
    end;

    procedure NumberPad(Str: Text[30]; Len: Integer): Text[30]
    var
        i: Integer;
        Str2: Text[30];
    begin
        for i := 1 to 10 do
            Str2 += Str;
        Str := Str2 + Str;
        Str := CopyStr(Str, StrLen(Str) - Len + 1, Len);
        exit(Str);
    end;

    internal procedure GetSerialLotSalesQty(var pPOSTransLine: Record "LSC POS Trans. Line"; pSerialNo: Code[50]; pLotNo: Code[50]): Decimal
    var
        POSTransLine: Record "LSC POS Trans. Line";
        POSTrans: Record "LSC POS Transaction";
        QtyOnPos: Decimal;
        IsHandled: Boolean;
    begin
        OnBeforeGetSerialLotSalesQty(pPOSTransLine, pSerialNo, pLotNo, IsHandled, QtyOnPos);
        if IsHandled then
            exit(QtyOnPos);

        QtyOnPos := 0;
        Clear(POSTrans);

        POSTransLine.Reset;
        POSTransLine.SetCurrentKey("Receipt No.", "Entry Type", Number, "Variant Code", "Unit of Measure", "Entry Status");
        POSTransLine.SetRange("Entry Type", POSTransLine."Entry Type"::Item);
        POSTransLine.SetRange(Number, pPOSTransLine.Number);
        POSTransLine.SetRange("Variant Code", pPOSTransLine."Variant Code");
        POSTransLine.SetFilter("Entry Status", '<>%1', POSTransLine."Entry Status"::Voided);
        POSTransline.SetRange("Store No.", pPOSTransLine."Store No.");
        POSTransline.SetRange("Unit of Measure", pPOSTransLine."Unit of Measure");
        if pSerialNo <> '' then
            POSTransLine.SetRange("Serial No.", pSerialNo);
        if pLotNo <> '' then
            POSTransLine.SetRange("Lot No.", pLotNo);
        if POSTransLine.FindSet then
            repeat
                if POSTransLine."Receipt No." <> POSTrans."Receipt No." then
                    POSTrans.Get(POSTransLine."Receipt No.");
                if (POSTrans."Transaction Type" <> POSTrans."Transaction Type"::Voided) and
                   (POSTrans."Entry Status" <> POSTrans."Entry Status"::Voided) then begin
                    if POSTrans."Sale Is Return Sale" then
                        POSTransLine.Quantity := -POSTransLine.Quantity;
                    QtyOnPos := QtyOnPos + POSTransLine.Quantity;
                end;
            until POSTransLine.Next = 0;

        exit(QtyOnPos);
    end;

    local procedure GetSerialLotSalesQtyExclCurr(var pPOSTransLine: Record "LSC POS Trans. Line"; pSerialNo: Code[50]; pLotNo: Code[50]): Decimal
    var
        POSTrans: Record "LSC POS Transaction";
        QtyOnPos: Decimal;
        QtyCurrLine: Decimal;
        QtyOnPosExclCurr: Decimal;
        ExclCurrLine: Boolean;
        IsHandled: Boolean;
    begin
        OnBeforeGetSerialLotSalesQtyExclCurr(pPOSTransLine, pSerialNo, pLotNo, IsHandled, QtyOnPosExclCurr);
        if IsHandled then
            exit(QtyOnPosExclCurr);

        QtyOnPos := 0;
        QtyCurrLine := 0;
        QtyOnPosExclCurr := 0;

        ExclCurrLine := false;
        if (pPOSTransLine."Serial No." <> '') or (pPOSTransLine."Lot No." <> '') then begin
            ExclCurrLine := true;
            if pPOSTransLine."Entry Status" = pPOSTransLine."Entry Status"::Voided then
                ExclCurrLine := false;
            if (pSerialNo <> '') and (pSerialNo <> pPOSTransLine."Serial No.") then
                ExclCurrLine := false;
            if (pLotNo <> '') and (pLotNo <> pPOSTransLine."Lot No.") then
                ExclCurrLine := false;
            POSTrans.Get(pPOSTransLine."Receipt No.");
            if (POSTrans."Transaction Type" = POSTrans."Transaction Type"::Voided) or
               (POSTrans."Entry Status" = POSTrans."Entry Status"::Voided)
            then
                ExclCurrLine := false;
        end;
        if ExclCurrLine then begin
            if POSTrans."Sale Is Return Sale" then
                QtyCurrLine := -pPOSTransLine.Quantity
            else
                QtyCurrLine := pPOSTransLine.Quantity;
        end;

        QtyOnPos := GetSerialLotSalesQty(pPOSTransLine, pSerialNo, pLotNo);
        QtyOnPosExclCurr := QtyOnPos - QtyCurrLine;

        exit(QtyOnPosExclCurr);
    end;

    local procedure UpdateInvLookup(var pPOSTransLine: Record "LSC POS Trans. Line"; pTSActive: Boolean)
    var
        InvLookupTable: Record "LSC Inventory Lookup Table";
        SerialLotInBuffer: Record "LSC Inventory Lookup Table" temporary;
        InvLookupTableTmp: Record "LSC Inventory Lookup Table" temporary;
        NetInventory: Decimal;
    begin
        if not pTSActive then
            ItemTrack.GetItemInvBuffeByVariantSerialLot(pPOSTransLine.Number, pPOSTransLine."Store No.", SerialLotInBuffer);
        InvLookupTable.Reset;
        InvLookupTable.SetRange("Item No.", pPOSTransLine.Number);
        InvLookupTable.SetRange("Variant Code", pPOSTransLine."Variant Code");
        if pPOSTransLine."Store No." <> '' then
            InvLookupTable.SetRange("Store No.", pPOSTransLine."Store No.");
        if InvLookupTable.FindSet then
            repeat
                NetInventory := InvLookupTable."Net Inventory";
                if pTSActive then
                    InvLookupTable.UpdateInventory(pTSActive)
                else begin
                    if SerialLotInBuffer.Get(InvLookupTable."Item No.", InvLookupTable."Variant Code", InvLookupTable."Store No.",
                       InvLookupTable."Lot No.", InvLookupTable."Serial No.")
                    then
                        InvLookupTable."Net Inventory" := SerialLotInBuffer."Net Inventory"
                    else
                        InvLookupTable."Net Inventory" := 0;
                end;
                if InvLookupTable."Net Inventory" <> NetInventory then begin
                    InvLookupTableTmp.Init;
                    InvLookupTableTmp := InvLookupTable;
                    InvLookupTableTmp.Insert;
                end;
            until InvLookupTable.Next = 0;

        InvLookupTableTmp.Reset;
        if not InvLookupTableTmp.IsEmpty then begin
            if InvLookupTableTmp.FindSet then
                repeat
                    if InvLookupTable.Get(InvLookupTableTmp."Item No.", InvLookupTableTmp."Variant Code", InvLookupTableTmp."Store No.",
                       InvLookupTableTmp."Lot No.", InvLookupTableTmp."Serial No.")
                    then begin
                        InvLookupTable."Net Inventory" := InvLookupTableTmp."Net Inventory";
                        InvLookupTable.Modify;
                    end;
                until InvLookupTableTmp.Next = 0;
        end;
    end;

    internal procedure SerialNoIsValid(var pPOSTransLine: Record "LSC POS Trans. Line"; pSerialNo: Code[50]; pItemTrackingCode: Code[10]; pSaleIsReturnSale: Boolean; var pErrorText: Text[250]): Boolean
    var
        ItemTrackingCodeRec: Record "Item Tracking Code";
        ProductGroup: Record "LSC Retail Product Group";
        AvailQty: Decimal;
        ExpDate: Date;
        InvtoryTesting: Boolean;
        ExitValue: Boolean;
        Proceed: Boolean;
        LocalText001: Label 'Item Tracking Code %1 does not exist.';
        LocalText002: Label 'Serial No. %1 does not exist.';
        LocalText006: Label 'Serial No. %1 already exists.';
        LocalText008: Label 'Expiration Date not Specified for Serial No. %1.';
        LocalText009: Label 'Serial No. %1 has expired.';
        LocalText011: Label 'Serial No. Item Tracking not Supported without "Inventory Lookup".';
        LocalText012: Label 'Serial No. can not be empty ';
    begin
        Proceed := true;
        OnBeforeSerialNoIsValid(pPOSTransLine, pSerialNo, ExitValue, Proceed);
        if not Proceed then
            exit(ExitValue);

        if not ItemTrackingCodeRec.Get(pItemTrackingCode) then begin
            pErrorText := StrSubstNo(LocalText001, pItemTrackingCode);
            exit(false);
        end;

        if ItemTrackingCodeRec."SN Specific Tracking" then begin
            if not ProductGroup.Get(pPOSTransLine."Item Category Code", pPOSTransLine."Retail Product Code") then
                Clear(ProductGroup);
            if PosSession.Store."POS Inventory Lookup" and ProductGroup."POS Inventory Lookup" then
                InvtoryTesting := true
            else
                InvtoryTesting := false;
            if InvtoryTesting then begin
                AvailQty := GetAvailSerialLotQty(pPOSTransLine, pSerialNo, '');
                if ((pSaleIsReturnSale) and (pPOSTransLine.Quantity >= 0)) or
                   ((not pSaleIsReturnSale) and (pPOSTransLine.Quantity < 0))
                then begin
                    if AvailQty > 0 then begin
                        pErrorText := StrSubstNo(LocalText006, pSerialNo);
                        exit(false);
                    end;
                end else begin
                    if AvailQty < 1 then begin
                        pErrorText := StrSubstNo(LocalText002, pSerialNo);
                        exit(false);
                    end;
                    if ItemTrackingCodeRec."Strict Expiration Posting" then begin
                        ExpDate := GetSerialLotExpDate(pPOSTransLine, pSerialNo, '');
                        if ExpDate = 0D then begin
                            pErrorText := StrSubstNo(LocalText008, pSerialNo);
                            exit(false);
                        end else
                            if ExpDate < Today then begin
                                pErrorText := StrSubstNo(LocalText009, pSerialNo);
                                exit(false);
                            end;
                    end;
                end;
            end else begin
                pErrorText := LocalText011;
                exit(false);
            end;
        end;

        if (pSerialNo = '') and ItemTrackingCodeRec."SN Sales Outbound Tracking" then begin
            pErrorText := StrSubstNo(LocalText012, pSerialNo);
            exit(false);
        end;

        exit(true);
    end;

    internal procedure LotNoIsValid(var pPOSTransLine: Record "LSC POS Trans. Line"; pSerialNo: Code[50]; pLotNo: Code[50]; pItemTrackingCode: Code[10]; pSaleIsReturnSale: Boolean; pQuantity: Decimal; var pErrorText: Text[250]): Boolean
    var
        ItemTrackingCodeRec: Record "Item Tracking Code";
        ProductGroup: Record "LSC Retail Product Group";
        AvailQty: Decimal;
        ExpDate: Date;
        InvtoryTesting: Boolean;
        LocalText001: Label 'Item Tracking Code %1 does not exist.';
        LocalText002: Label 'Lot No. %1 does not exist or quantity %2 is not available.';
        LocalText008: Label 'Expiration Date not Specified for Lot No. %1.';
        LocalText009: Label 'Lot No. %1 has expired.';
        LocalText011: Label 'Lot No. Item Tracking not Supported without "Inventory Lookup".';
    begin
        if not ItemTrackingCodeRec.Get(pItemTrackingCode) then begin
            pErrorText := StrSubstNo(LocalText001, pItemTrackingCode);
            exit(false);
        end;

        if ItemTrackingCodeRec."Lot Specific Tracking" then begin
            if not ProductGroup.Get(pPOSTransLine."Item Category Code", pPOSTransLine."Retail Product Code") then
                Clear(ProductGroup);
            if PosSession.Store."POS Inventory Lookup" and ProductGroup."POS Inventory Lookup" then
                InvtoryTesting := true
            else
                InvtoryTesting := false;
            if InvtoryTesting then begin
                AvailQty := GetAvailSerialLotQty(pPOSTransLine, pSerialNo, pLotNo);
                if ((not pSaleIsReturnSale) and (pQuantity >= 0)) or
                   ((pSaleIsReturnSale) and (pQuantity < 0))
                then begin
                    if AvailQty < pQuantity then begin
                        pErrorText := StrSubstNo(LocalText002, pLotNo, pQuantity);
                        exit(false);
                    end;
                    if ItemTrackingCodeRec."Strict Expiration Posting" then begin
                        ExpDate := GetSerialLotExpDate(pPOSTransLine, pSerialNo, pLotNo);
                        if ExpDate = 0D then begin
                            pErrorText := StrSubstNo(LocalText008, pLotNo);
                            exit(false);
                        end else
                            if ExpDate < Today then begin
                                pErrorText := StrSubstNo(LocalText009, pLotNo);
                                exit(false);
                            end;
                    end;
                end;
            end else begin
                pErrorText := LocalText011;
                exit(false);
            end;
        end;

        exit(true);
    end;

    internal procedure UpdateSerialLotInvLookup(var pPOSTransLine: Record "LSC POS Trans. Line"; pItemTrackingCode: Code[10]; var pErrorText: Text[250]): Boolean
    var
        ItemTrackingCodeRec: Record "Item Tracking Code";
        ProductGroup: Record "LSC Retail Product Group";
        InvtoryTesting: Boolean;
        POSIsOnLine: Boolean;
        IsHandled, ReturnValue : Boolean;
        LocalText001: Label 'Item Tracking Code %1 does not exist.';
    begin
        OnBeforeUpdateSerialLotInvLookup(pPOSTransLine, pItemTrackingCode, pErrorText, IsHandled, ReturnValue);
        if IsHandled then
            exit(ReturnValue);

        if not ItemTrackingCodeRec.Get(pItemTrackingCode) then begin
            pErrorText := StrSubstNo(LocalText001, pItemTrackingCode, pPOSTransLine.Number);
            exit(false);
        end;

        if (ItemTrackingCodeRec."SN Specific Tracking") or (ItemTrackingCodeRec."Lot Specific Tracking") then begin
            if not ProductGroup.Get(pPOSTransLine."Item Category Code", pPOSTransLine."Retail Product Code") then
                Clear(ProductGroup);
            if PosSession.Store."POS Inventory Lookup" and ProductGroup."POS Inventory Lookup" then
                InvtoryTesting := true
            else
                InvtoryTesting := false;
            if InvtoryTesting then begin
                POSIsOnLine := PosSession.Terminal."Terminal Connection" = PosSession.Terminal."Terminal Connection"::OnLine;
                if (POSIsOnLine) or (not PosSession.FunctionalityProfile."TS Inv. Lookup") then begin
                    UpdateInvLookup(pPOSTransLine, false);
                end else
                    if not TSUtil.GetItemInventoryLookupTable(pPOSTransLine.Number, pPOSTransLine."Variant Code", pPOSTransLine."Store No.", '', pErrorText) then
                        if pErrorText <> '' then
                            exit(false);
            end;
        end;

        exit(true);
    end;

    internal procedure GetAvailSerialLotQty(var pPOSTransLine: Record "LSC POS Trans. Line"; pSerialNo: Code[50]; pLotNo: Code[50]): Decimal
    var
        InvLookupTable: Record "LSC Inventory Lookup Table";
        NetInv: Decimal;
        AvailQty: Decimal;
        IsHandled: Boolean;
    begin
        OnBeforeGetSerialLotSalesQuantity(pPOSTransLine, pSerialNo, pLotNo, IsHandled, AvailQty);
        if not IsHandled then begin
            NetInv := 0;
            InvLookupTable.Reset;
            InvLookupTable.SetRange("Item No.", pPOSTransLine.Number);
            InvLookupTable.SetRange("Variant Code", pPOSTransLine."Variant Code");
            InvLookupTable.SetRange("Store No.", pPOSTransLine."Store No.");
            if pSerialNo <> '' then
                InvLookupTable.SetRange("Serial No.", pSerialNo);
            if pLotNo <> '' then
                InvLookupTable.SetRange("Lot No.", pLotNo);
            if InvLookupTable.FindSet then
                repeat
                    NetInv := NetInv + InvLookupTable."Net Inventory";
                until InvLookupTable.Next = 0;

            OnAfterGetSerialLotSalesQuantity(pPOSTransLine, pSerialNo, pLotNo, NetInv, IsHandled, AvailQty);
            if not IsHandled then
                AvailQty := NetInv - GetSerialLotSalesQtyExclCurr(pPOSTransLine, pSerialNo, pLotNo);
        end;

        exit(AvailQty);
    end;

    internal procedure GetSerialLotExpDate(var pPOSTransLine: Record "LSC POS Trans. Line"; pSerialNo: Code[50]; pLotNo: Code[50]): Date
    var
        InvLookupTable: Record "LSC Inventory Lookup Table";
        ExpDate: Date;
    begin
        ExpDate := 0D;
        InvLookupTable.Reset;
        InvLookupTable.SetRange("Item No.", pPOSTransLine.Number);
        InvLookupTable.SetRange("Variant Code", pPOSTransLine."Variant Code");
        InvLookupTable.SetRange("Store No.", pPOSTransLine."Store No.");
        if pSerialNo <> '' then
            InvLookupTable.SetRange("Serial No.", pSerialNo);
        if pLotNo <> '' then
            InvLookupTable.SetRange("Lot No.", pLotNo);
        if InvLookupTable.FindFirst then
            ExpDate := InvLookupTable."Expiration Date";

        exit(ExpDate);
    end;

    internal procedure ValidateLotNoQty(var pPOSTransLine: Record "LSC POS Trans. Line"; pSaleIsReturnSale: Boolean; pQuantity: Decimal; var pErrorText: Text[250]): Boolean
    var
        ProductGroup: Record "LSC Retail Product Group";
        AvailQty: Decimal;
        InvtoryTesting: Boolean;
        LocalText001: Label 'Quantity %1 not available for Lot No. %2';
    begin
        if ItemTrack.IsItemLotTracking(pPOSTransLine.Number) then begin
            if not ProductGroup.Get(pPOSTransLine."Item Category Code", pPOSTransLine."Retail Product Code") then
                Clear(ProductGroup);
            if PosSession.Store."POS Inventory Lookup" and ProductGroup."POS Inventory Lookup" then
                InvtoryTesting := true
            else
                InvtoryTesting := false;

            if InvtoryTesting then begin
                AvailQty := GetAvailSerialLotQty(pPOSTransLine, pPOSTransLine."Serial No.", pPOSTransLine."Lot No.");
                OnBeforeLotNoIsValid(pQuantity, pPOSTransLine);
                if ((not pSaleIsReturnSale) and (pQuantity >= 0)) or
                   ((pSaleIsReturnSale) and (pQuantity < 0))
                then begin
                    OnBeforeValidateLotNoQtyCheckQuantity(pQuantity, pPOSTransLine);
                    if AvailQty < pQuantity then begin
                        OnBeforeValidateLotNoQtyCheckQuantity(pQuantity, pPOSTransLine);
                        pErrorText := StrSubstNo(LocalText001, pQuantity, pPOSTransLine."Lot No.");
                        exit(false);
                    end;
                end;
            end;
        end;

        exit(true);
    end;

    internal procedure SerialNoLookupFromPopup(ItemNo: Code[20]; MgrKey: Boolean; CurrVarCode: Code[10]; var ErrorText: Text; var WaitingForInput: Boolean; var InputValue: Text; var LotTracking: Boolean): Boolean
    var
        ItemIn: Record Item;
        PosTransLineUpd: Record "LSC POS Trans. Line";
        LookupErrText: Text[250];
        SerTracking: Boolean;
        LookupOK: Boolean;
    begin
        if ItemNo = '' then
            exit(false);
        ErrorText := '';
        WaitingForInput := false;

        ItemIn.Get(ItemNo);
        Clear(PosTransLineUpd);
        PosTransLineUpd.Number := ItemIn."No.";
        PosTransLineUpd."Variant Code" := CurrVarCode;
        PosTransLineUpd."Store No." := PosSession.Terminal."Store No.";
        PosTransLineUpd."Item Category Code" := ItemIn."Item Category Code";
        PosTransLineUpd."Retail Product Code" := ItemIn."LSC Retail Product Code";
        PosTransLineUpd.Quantity := 1;

        GetSerialOrLotTrackingPopup(PosTransLineUpd, LotTracking, SerTracking);
        if UpdateSerialLotInvLookupPopup(PosTransLineUpd, ItemIn."Item Tracking Code", LookupErrText, LotTracking, SerTracking) then begin
            SetSerialPopupParameters(PosTransLineUpd, LotTracking, MgrKey);
            LookupOK := LookupSerialLotNoFromPopup(LotTracking, PosTransLineUpd, MgrKey, ErrorText, WaitingForInput);
            if not LookupOK then
                exit(false);
            if WaitingForInput then
                exit(true);
            if InputValue = '' then begin
                SerialNoEnterManuallyFromPopup(MgrKey, LotTracking, true, LookupErrText, WaitingForInput);
                exit(WaitingForInput);
            end;
            exit(true);
        end else begin
            SerialNoEnterManuallyFromPopup(MgrKey, LotTracking, false, LookupErrText, WaitingForInput);
            exit(WaitingForInput);
        end;
    end;

    local procedure SerialNoEnterManuallyFromPopup(MgrKey: Boolean; LotTracking: Boolean; MissingValue: Boolean; ErrorText: Text; var WaitingForInput: Boolean)
    var
        POSTransLine: Record "LSC POS Trans. Line";
        SerialText: Text[30];
        EnterSerialText: Text[80];
        PText030: Label 'Enter %1 for the item';
        Text020: Label 'Would you like to enter the %1 manually?';
        ErrorLookupSerialMissing: Label '%1 is needed. ';
    begin
        WaitingForInput := false;
        if not MgrKey then
            exit;

        SerialText := POSTransLine.FieldCaption("Serial No.");
        if LotTracking then
            SerialText := POSTransLine.FieldCaption("Lot No.");
        EnterSerialText := StrSubstNo(PText030, SerialText);
        if MissingValue then
            ErrorText := StrSubstNo(ErrorLookupSerialMissing, SerialText);

        if PosCtrl.PosConfirm(ErrorText + ' ' + StrSubstNo(Text020, SerialText), false) then begin
            WaitingForInput := true;
            AskForSerialNo(EnterSerialText, false);
        end;
    end;

    internal procedure ContinueProcessSerialNoLookupFromPopupOnClose(LookupID: Text; ResultOK: Boolean; var InputValue: Text; var PosMenuLine: Record "LSC POS Menu Line"): Boolean
    var
        PosTransLineUpd: Record "LSC POS Trans. Line";
        ItemIn: Record Item;
        ErrorText: Text;
        LotTracking: Boolean;
        MgrKey: Boolean;
        WaitingForInput: Boolean;
    begin
        InputValue := '';
        PosMenuLine."Input Process" := PosMenuLine."Input Process"::"Input Canceled";

        if not ResultOK then
            exit(true);

        InputValue := CopyStr(PosCtrl.GetLookupKeyValue(LookupID), 1, 20);
        GetSerialPopupParameters(PosTransLineUpd, LotTracking, MgrKey);

        if InputValue = '' then begin
            SerialNoEnterManuallyFromPopup(MgrKey, LotTracking, true, '', WaitingForInput);
            if WaitingForInput then
                exit(false);
            exit(true);
        end;
        ItemIn.Get(PosTransLineUpd.Number);
        if ValidateSerialLotNo(LotTracking, PosTransLineUpd, ItemIn, MgrKey, InputValue) then begin
            PosMenuLine."Input Process" := PosMenuLine."Input Process"::"Input OK";
            exit(true);
        end;
        LookupSerialLotNoFromPopup(LotTracking, PosTransLineUpd, MgrKey, ErrorText, WaitingForInput);
        exit(WaitingForInput);
    end;

    local procedure UpdateSerialLotInvLookupPopup(POSTransLine1: Record "LSC POS Trans. Line"; ItemTrackCode: Code[10]; var ErrorText: Text[250]; LotNoTracking: Boolean; SerNoTracking: Boolean): Boolean
    begin
        if not (SerNoTracking or LotNoTracking) then
            exit(true);
        if SerNoTracking and LotNoTracking then
            LotNoTracking := false;

        ErrorText := '';
        if not UpdateSerialLotInvLookup(POSTransLine1, ItemTrackCode, ErrorText) then
            exit(false);

        exit(true);
    end;

    local procedure GetSerialOrLotTrackingPopup(POSTransLine1: Record "LSC POS Trans. Line"; var LotNoTracking: Boolean; var SerNoTracking: Boolean)
    begin
        SerNoTracking := ItemTrack.IsItemSNTracking(POSTransLine1.Number);
        LotNoTracking := ItemTrack.IsItemLotTracking(POSTransLine1.Number);
    end;

    local procedure ValidateSerialNoPopup(PosTransLineIn: Record "LSC POS Trans. Line"; ItemRec: Record Item; SerialNo: Code[50]; var ErrorText: Text[250]; MgrKey: Boolean): Boolean
    begin
        ErrorText := '';
        if not SerialNoIsValid(PosTransLineIn, SerialNo, ItemRec."Item Tracking Code", false, ErrorText) then begin
            if MgrKey then begin
                if PosCtrl.PosConfirm(ErrorText + '\' + DoUseNumAnywayQst, false) then
                    exit(true)
                else begin
                    SerialNo := '';
                    exit(false);
                end
            end else begin
                PosCtrl.PosMessage(ErrorText);
                SerialNo := '';
                exit(false);
            end;
        end else
            exit(true);
    end;

    local procedure ValidateLotNoPopup(PosTransLineIn: Record "LSC POS Trans. Line"; ItemRec: Record Item; SerialNo: Code[50]; LotNo: Code[50]; var ErrorText: Text[250]; MgrKey: Boolean): Boolean
    var
        Quantity: Decimal;
    begin
        ErrorText := '';
        if PosTransLineIn.Quantity = 0 then
            Quantity := 1
        else
            Quantity := PosTransLineIn.Quantity;
        if not LotNoIsValid(PosTransLineIn, SerialNo, LotNo, ItemRec."Item Tracking Code", false, Quantity, ErrorText) then begin
            if MgrKey then begin
                if PosCtrl.PosConfirm(ErrorText + '\' + DoUseNumAnywayQst, false) then
                    exit(true)
                else begin
                    LotNo := '';
                    exit(false);
                end
            end else begin
                PosCtrl.PosMessage(ErrorText);
                LotNo := '';
                exit(false);
            end;
        end else
            exit(true);
    end;

    local procedure AskForSerialNo(TextHeading: Text[50]; Lookup: Boolean)
    begin
        PosCtrl.OpenAlphabeticKeyboard(TextHeading, '', Lookup, PopupFunctions().GetKeyboardPayload('SERIALPOPUP'), 20);
    end;

    internal procedure ValidateSerialNoKeyboardInputFromPopup(ResultOK: Boolean; InputValue: Text; var PosMenuLine: Record "LSC POS Menu Line"): Boolean
    begin
        if (not ResultOK) or (InputValue = '') then
            PosMenuLine."Input Process" := PosMenuLine."Input Process"::"Input Canceled"
        else
            PosMenuLine."Input Process" := PosMenuLine."Input Process"::"Input OK";
        exit(true);
    end;

    local procedure LookupSerialLotNoFromPopup(LotTr: Boolean; PosTrLine2: Record "LSC POS Trans. Line"; MgrKey: Boolean; var ErrorText: Text; var WaitingForInput: Boolean): Boolean
    var
        CurrlineTemp: Record "LSC POS Trans. Line" temporary;
        PosLookup: Record "LSC POS Lookup";
        DummyFlowFieldBuffer: Record "LSC FlowField Buffer" temporary;
        LookupRecRef: RecordRef;
        FormID: Code[10];
        FilterCodeStr: Code[20];
        ErrorLookupRecNotFound: Label 'Lookup %1 not found.';
    begin
        FormID := Format("LSC POS Lookup Id"::"SERIAL_LU");
        if LotTr then
            FormID := Format("LSC POS Lookup Id"::"LOT_LU");

        WaitingForInput := false;

        if POSSESSION.GetPosLookupRec(FormID, PosLookup) then begin
            Commit;
            CurrlineTemp := PosTrLine2;
            if not PrepareInvLookup(CurrlineTemp, true, '', FilterCodeStr) then
                exit(false);

            PosCtrl.Lookup(PosLookup, 'SERIALPOPUP', CurrlineTemp, MgrKey, '', LookupRecRef, DummyFlowFieldBuffer);
            WaitingForInput := true;
            exit(true);
        end;
        ErrorText := StrSubstNo(ErrorLookupRecNotFound, FormID);
        exit(false);
    end;

    local procedure ValidateSerialLotNo(LotTr: Boolean; PosTrLine2: Record "LSC POS Trans. Line"; SerialItem: Record Item; ManKey: Boolean; CurrInput: Text): Boolean
    var
        LookupErrText: Text[250];
    begin
        if LotTr then begin
            if not ValidateLotNoPopup(PosTrLine2, SerialItem, '', CurrInput, LookupErrText, ManKey) then begin
                CurrInput := '';
                exit(false);
            end;
        end else begin
            if not ValidateSerialNoPopup(PosTrLine2, SerialItem, CurrInput, LookupErrText, ManKey) then begin
                CurrInput := '';
                exit(false);
            end;
        end;
        exit(true);
    end;

    local procedure SetSerialPopupParameters(ParameterPosTransLine: Record "LSC POS Trans. Line"; LotTracking: Boolean; MangerKey: Boolean)
    begin
        POSSESSION.SetValue("LSC POS Tag"::"SER-NUMBER", ParameterPosTransLine.Number);
        POSSESSION.SetValue("LSC POS Tag"::"SER-VARIANT", ParameterPosTransLine."Variant Code");
        POSSESSION.SetValue("LSC POS Tag"::"SER-STORE", ParameterPosTransLine."Store No.");
        POSSESSION.SetValue("LSC POS Tag"::"SER-ITEMCAT", ParameterPosTransLine."Item Category Code");
        POSSESSION.SetValue("LSC POS Tag"::"SER-PRODGR", ParameterPosTransLine."Retail Product Code");
        POSSESSION.SetValue("LSC POS Tag"::"SER-QUANTITY", Format(ParameterPosTransLine.Quantity));
        POSSESSION.SetValue("LSC POS Tag"::"SER-MANKEY", Format(MangerKey));
        POSSESSION.SetValue("LSC POS Tag"::"SER-LOTTRACK", Format(LotTracking));
    end;

    local procedure GetSerialPopupParameters(var ParameterPosTransLine: Record "LSC POS Trans. Line"; var LotTracking: Boolean; var MangerKey: Boolean)
    var
        ManKey: Text;
        LotTr: Text;
    begin
        ParameterPosTransLine.Number := POSSESSION.GetValue("LSC POS Tag"::"SER-NUMBER");
        ParameterPosTransLine."Variant Code" := POSSESSION.GetValue("LSC POS Tag"::"SER-VARIANT");
        ParameterPosTransLine."Store No." := POSSESSION.GetValue("LSC POS Tag"::"SER-STORE");
        ParameterPosTransLine."Item Category Code" := POSSESSION.GetValue("LSC POS Tag"::"SER-ITEMCAT");
        ParameterPosTransLine."Retail Product Code" := POSSESSION.GetValue("LSC POS Tag"::"SER-PRODGR");
        if Evaluate(ParameterPosTransLine.Quantity, POSSESSION.GetValue("LSC POS Tag"::"SER-QUANTITY")) then;
        ManKey := POSSESSION.GetValue("LSC POS Tag"::"SER-MANKEY");
        LotTr := POSSESSION.GetValue("LSC POS Tag"::"SER-LOTTRACK");
        MangerKey := (ManKey = 'Yes');
        LotTracking := (LotTr = 'Yes');
    end;

    internal procedure PosTransInfoExists(ReceiptNo: Code[20]; LineNo: Integer): Boolean
    var
        PosTransInfoLine: Record "LSC POS Trans. InfoData Entry";
    begin
        PosTransInfoLine.SetRange("Receipt No.", ReceiptNo);
        PosTransInfoLine.SetRange("Receipt Line No.", LineNo);
        exit(not PosTransInfoLine.IsEmpty());
    end;

    internal procedure ValidateCustInvoiceNo(DocumentNo: Code[20]; var ErrorText: Text[250]; var MsgText: Text[250]; var CustomerNo: Code[20]): Boolean
    var
        CustLedgEntry: Record "Cust. Ledger Entry";
        TmpCustLedgEntry: Record "Cust. Ledger Entry" temporary;
        InvoicePaymentAmount: Decimal;
        UnpostedInvoicePaid: Decimal;
        Text308: Label 'Invoice No. %1 is closed ';
        Text309: Label 'Invoice No %1 cannot be found.';
        Text310: Label 'Total Remaining Amount is %1';
        Text311: Label 'Invoice Payment Amount %1 is greater than Remaining Amount %2.';
    begin
        InitPosFunctions;
        InvoicePaymentAmount := POSTransactionImpl.GetValidateCusInvNoInp_InvPmtAmt;
        if PosSession.FunctionalityProfile."TS Customer Invoice" then begin
            if TSUtil.GetCustSpecInvoice(DocumentNo, TmpCustLedgEntry, ErrorText) then begin
                if ErrorText = '' then
                    if TmpCustLedgEntry.FindFirst then begin
                        if not TmpCustLedgEntry.Open then begin
                            ErrorText := StrSubstNo(Text308, DocumentNo);
                            exit(false);
                        end;
                        if TmpCustLedgEntry.Open then begin
                            if (TmpCustLedgEntry."LSC Remaining Amount Int" < InvoicePaymentAmount) then begin
                                ErrorText := StrSubstNo(Text311, InvoicePaymentAmount, TmpCustLedgEntry."LSC Remaining Amount Int");
                                exit(false);
                            end;

                            CustomerNo := TmpCustLedgEntry."Customer No.";
                            OnFindOpenCustLedgEntry(TmpCustLedgEntry);
                            //In the Profit (LCY) field is the value from "Remaining Amount"
                            MsgText := StrSubstNo(Text310, Format(TmpCustLedgEntry."Profit (LCY)"));
                            exit(true);
                        end;
                    end;
            end else
                ErrorText := StrSubstNo(Text309, DocumentNo);
            exit(false);
        end else begin
            CustLedgEntry.SetCurrentKey("Document No.");
            CustLedgEntry.SetRange("Document No.", DocumentNo);
            CustLedgEntry.SetRange("Document Type", CustLedgEntry."Document Type"::Invoice);
            if CustLedgEntry.FindFirst then begin
                if not CustLedgEntry.Open then begin
                    ErrorText := StrSubstNo(Text308, DocumentNo);
                    exit(false);
                end;
                if CustLedgEntry.Open then begin
                    CustLedgEntry.CalcFields("Remaining Amount");
                    OnFindOpenCustLedgEntry(CustLedgEntry);
                    UnpostedInvoicePaid := GetUnpostedInvoicePaid(DocumentNo);
                    if CustLedgEntry."Remaining Amount" + UnpostedInvoicePaid < InvoicePaymentAmount then begin
                        ErrorText := StrSubstNo(Text311, InvoicePaymentAmount, CustLedgEntry."Remaining Amount" + UnpostedInvoicePaid);
                        exit(false);
                    end;
                    CustomerNo := CustLedgEntry."Customer No.";
                    MsgText := StrSubstNo(Text310, Format(CustLedgEntry."Remaining Amount"));
                    exit(true);
                end;
            end else begin
                ErrorText := StrSubstNo(Text309, DocumentNo);
                exit(false);
            end;
        end;
    end;

    procedure GetUnpostedInvoicePaid(DocumentNo: Code[20]): Decimal
    var
        TransHeader: Record "LSC Transaction Header";
        TransPaymentEntry: Record "LSC Trans. Payment Entry";
        CustomerTenderType: Record "LSC Tender Type";
        TenderType: Record "LSC Tender Type";
        UnpostedInvoicePaid: Decimal;
    begin
        TransHeader.SetRange("Apply to Doc. No.", DocumentNo);
        TransHeader.SetRange("Transaction Type", TransHeader."Transaction Type"::Payment);
        TransHeader.SetRange("Statement No.", '');
        if TransHeader.Findset then
            repeat
                TransPaymentEntry.SetRange("Transaction No.", TransHeader."Transaction No.");
                TransPaymentEntry.SetRange("Store No.", TransHeader."Store No.");
                TransPaymentEntry.SetRange("POS Terminal No.", TransHeader."POS Terminal No.");
                if TransPaymentEntry.FindFirst then
                    if TenderType.Get(TransPaymentEntry."Store No.", TransPaymentEntry."Tender Type") then
                        if TenderType.Function = TenderType.Function::Customer then
                            UnpostedInvoicePaid += TransPaymentEntry."Amount Tendered";
            until TransHeader.Next = 0;
        exit(UnpostedInvoicePaid);
    end;

    internal procedure FindReturnPolicy(PosTrLine: Record "LSC POS Trans. Line"; MgrKey: Boolean; DatePurchased: Date; var pReturnPolicy: Record "LSC ReturnPolicy"; var pMessageText: Text[250]; var pErrorText: Text[250]): Integer
    var
        lRetPolicy: Record "LSC ReturnPolicy";
        lItemRec: Record Item;
        StoreGroupSetup: Record "LSC Store Group Setup";
        ItemVariantRegistration: Record "LSC Item Variant Registration";
        Priority: Integer;
    begin
        //*********************************
        //* Return
        //*   0 => return policy not found
        //*   1 => message
        //*   2 => question to continue
        //*   3 => error
        //*********************************
        Clear(pReturnPolicy);
        Clear(pMessageText);
        Clear(pErrorText);

        if (PosTrLine.Number <> '') then begin
            if not lItemRec.Get(PosTrLine.Number) then
                exit(0);

            //Priority
            //    1) ItemNo,VariantCode,StoreNo.
            //    2) ItemNo,VariantCode,StoreGroup
            //    3) ItemNo,VariantCode
            //    4) ItemNo,VariantDim1Code,StoreNo
            //    5) ItemNo,VariantDim1Code,StoreGroup
            //    6) ItemNo,VariantDim1Code
            //    7) ItemNo,StoreNo
            //    8) ItemNo,StoreGroup
            //    9) ItemNo
            //   10) ProductGroup,StoreNo
            //   11) ProductGroup,StoreGroup
            //   12) ProductGroup
            //   13) ItemCategory,StoreNo
            //   14) ItemCategory,StoreGroup
            //   15) ItemCategory
            //   16) VariantDim1Code
            //   17) StoreNo

            for Priority := 1 to 17 do begin
                lRetPolicy.Reset;
                lRetPolicy.SetFilter("Store No.", '%1', '');
                lRetPolicy.SetFilter("Store Group Code", '%1', '');
                lRetPolicy.SetFilter("Item No.", '%1', '');
                lRetPolicy.SetFilter("Variant Code", '%1', '');
                lRetPolicy.SetFilter("Variant Dimension 1 Code", '%1', '');
                case Priority of
                    1:  //ItemNo,VariantCode,StoreNo.
                        if (PosTrLine.Number <> '') and (PosTrLine."Variant Code" <> '') and (PosTrLine."Store No." <> '') then begin
                            lRetPolicy.SetRange("Item No.", PosTrLine.Number);
                            lRetPolicy.SetRange("Variant Code", PosTrLine."Variant Code");
                            lRetPolicy.SetRange("Store No.", PosTrLine."Store No.");
                            if lRetPolicy.FindLast then begin
                                pReturnPolicy := lRetPolicy;
                                exit(ReturnPolicyAction(PosTrLine, pReturnPolicy, MgrKey, DatePurchased, pMessageText, pErrorText));
                            end;
                        end;
                    2:  //ItemNo,VariantCode,StoreGroup
                        if (PosTrLine.Number <> '') and (PosTrLine."Variant Code" <> '') and (PosTrLine."Store No." <> '') then begin
                            lRetPolicy.SetRange("Item No.", PosTrLine.Number);
                            lRetPolicy.SetRange("Variant Code", PosTrLine."Variant Code");
                            StoreGroupSetup.Reset;
                            StoreGroupSetup.SetCurrentKey("Store Code", Level);
                            StoreGroupSetup.Ascending := false;
                            StoreGroupSetup.SetRange("Store Code", PosTrLine."Store No.");
                            if StoreGroupSetup.FindSet then
                                repeat
                                    lRetPolicy.SetRange("Store Group Code", StoreGroupSetup."Store Group");
                                    if lRetPolicy.FindLast then begin
                                        pReturnPolicy := lRetPolicy;
                                        exit(ReturnPolicyAction(PosTrLine, pReturnPolicy, MgrKey, DatePurchased, pMessageText, pErrorText));
                                    end;
                                until StoreGroupSetup.Next = 0;
                        end;
                    3:  //ItemNo,VariantCode
                        if (PosTrLine.Number <> '') and (PosTrLine."Variant Code" <> '') then begin
                            lRetPolicy.SetRange("Item No.", PosTrLine.Number);
                            lRetPolicy.SetRange("Variant Code", PosTrLine."Variant Code");
                            if lRetPolicy.FindLast then begin
                                pReturnPolicy := lRetPolicy;
                                exit(ReturnPolicyAction(PosTrLine, pReturnPolicy, MgrKey, DatePurchased, pMessageText, pErrorText));
                            end;
                        end;
                    4:  //ItemNo,VariantDim1Code,StoreNo
                        if (PosTrLine.Number <> '') and (PosTrLine."Variant Code" <> '') and (PosTrLine."Store No." <> '') then begin
                            lRetPolicy.SetRange("Item No.", PosTrLine.Number);
                            lRetPolicy.SetRange("Store No.", PosTrLine."Store No.");
                            lRetPolicy.SetFilter("Variant Dimension 1 Code", '<>%1', '');
                            if lRetPolicy.FindLast then
                                repeat
                                    ItemVariantRegistration.Reset;
                                    ItemVariantRegistration.SetRange("Item No.", PosTrLine.Number);
                                    ItemVariantRegistration.SetRange("Variant Dimension 1", lRetPolicy."Variant Dimension 1 Code");
                                    ItemVariantRegistration.SetRange(Variant, PosTrLine."Variant Code");
                                    if ItemVariantRegistration.FindFirst then begin
                                        pReturnPolicy := lRetPolicy;
                                        exit(ReturnPolicyAction(PosTrLine, pReturnPolicy, MgrKey, DatePurchased, pMessageText, pErrorText));
                                    end;
                                until lRetPolicy.Next(-1) = 0;
                        end;
                    5:  //ItemNo,VariantDim1Code,StoreGroup
                        if (PosTrLine.Number <> '') and (PosTrLine."Variant Code" <> '') and (PosTrLine."Store No." <> '') then begin
                            lRetPolicy.SetRange("Item No.", PosTrLine.Number);
                            StoreGroupSetup.Reset;
                            StoreGroupSetup.SetCurrentKey("Store Code", Level);
                            StoreGroupSetup.Ascending := false;
                            StoreGroupSetup.SetRange("Store Code", PosTrLine."Store No.");
                            if StoreGroupSetup.FindSet then
                                repeat
                                    lRetPolicy.SetRange("Store Group Code", StoreGroupSetup."Store Group");
                                    lRetPolicy.SetFilter("Variant Dimension 1 Code", '<>%1', '');
                                    lRetPolicy.Ascending(false);
                                    if lRetPolicy.FindSet() then
                                        repeat
                                            ItemVariantRegistration.Reset;
                                            ItemVariantRegistration.SetRange("Item No.", PosTrLine.Number);
                                            ItemVariantRegistration.SetRange("Variant Dimension 1", lRetPolicy."Variant Dimension 1 Code");
                                            ItemVariantRegistration.SetRange(Variant, PosTrLine."Variant Code");
                                            if ItemVariantRegistration.FindFirst then begin
                                                pReturnPolicy := lRetPolicy;
                                                exit(ReturnPolicyAction(PosTrLine, pReturnPolicy, MgrKey, DatePurchased, pMessageText, pErrorText));
                                            end;
                                        until lRetPolicy.Next() = 0;
                                until StoreGroupSetup.Next = 0;
                        end;
                    6:  //ItemNo,VariantDim1Code
                        if (PosTrLine.Number <> '') and (PosTrLine."Variant Code" <> '') then begin
                            lRetPolicy.SetRange("Item No.", PosTrLine.Number);
                            lRetPolicy.SetFilter("Variant Dimension 1 Code", '<>%1', '');
                            lRetPolicy.Ascending(false);
                            if lRetPolicy.FindSet() then
                                repeat
                                    ItemVariantRegistration.Reset;
                                    ItemVariantRegistration.SetRange("Item No.", PosTrLine.Number);
                                    ItemVariantRegistration.SetRange("Variant Dimension 1", lRetPolicy."Variant Dimension 1 Code");
                                    ItemVariantRegistration.SetRange(Variant, PosTrLine."Variant Code");
                                    if ItemVariantRegistration.FindFirst then begin
                                        pReturnPolicy := lRetPolicy;
                                        exit(ReturnPolicyAction(PosTrLine, pReturnPolicy, MgrKey, DatePurchased, pMessageText, pErrorText));
                                    end;
                                until lRetPolicy.Next() = 0;
                        end;
                    7:  //ItemNo,StoreNo.
                        if (PosTrLine.Number <> '') and (PosTrLine."Store No." <> '') then begin
                            lRetPolicy.SetRange("Item No.", PosTrLine.Number);
                            lRetPolicy.SetRange("Store No.", PosTrLine."Store No.");
                            if lRetPolicy.FindLast then begin
                                pReturnPolicy := lRetPolicy;
                                exit(ReturnPolicyAction(PosTrLine, pReturnPolicy, MgrKey, DatePurchased, pMessageText, pErrorText));
                            end;
                        end;
                    8:  //ItemNo,StoreGroup
                        if (PosTrLine.Number <> '') and (PosTrLine."Store No." <> '') then begin
                            lRetPolicy.SetRange("Item No.", PosTrLine.Number);
                            StoreGroupSetup.Reset;
                            StoreGroupSetup.SetCurrentKey("Store Code", Level);
                            StoreGroupSetup.Ascending := false;
                            StoreGroupSetup.SetRange("Store Code", PosTrLine."Store No.");
                            if StoreGroupSetup.FindSet then
                                repeat
                                    lRetPolicy.SetRange("Store Group Code", StoreGroupSetup."Store Group");
                                    if lRetPolicy.FindLast then begin
                                        pReturnPolicy := lRetPolicy;
                                        exit(ReturnPolicyAction(PosTrLine, pReturnPolicy, MgrKey, DatePurchased, pMessageText, pErrorText));
                                    end;
                                until StoreGroupSetup.Next = 0;
                        end;
                    9:  //ItemNo
                        if PosTrLine.Number <> '' then begin
                            lRetPolicy.SetRange("Item No.", PosTrLine.Number);
                            if lRetPolicy.FindLast then begin
                                pReturnPolicy := lRetPolicy;
                                exit(ReturnPolicyAction(PosTrLine, pReturnPolicy, MgrKey, DatePurchased, pMessageText, pErrorText));
                            end;
                        end;
                    10:  //ProductGroup,StoreNo
                        if (lItemRec."LSC Retail Product Code" <> '') and (PosTrLine."Store No." <> '') then begin
                            lRetPolicy.SetRange("Retail Product Code", lItemRec."LSC Retail Product Code");
                            lRetPolicy.SetRange("Store No.", PosTrLine."Store No.");
                            if lRetPolicy.FindLast then begin
                                pReturnPolicy := lRetPolicy;
                                exit(ReturnPolicyAction(PosTrLine, pReturnPolicy, MgrKey, DatePurchased, pMessageText, pErrorText));
                            end;
                        end;
                    11:  //ProductGroup,StoreGroup
                        if (lItemRec."LSC Retail Product Code" <> '') and (PosTrLine."Store No." <> '') then begin
                            lRetPolicy.SetRange("Retail Product Code", lItemRec."LSC Retail Product Code");
                            StoreGroupSetup.Reset;
                            StoreGroupSetup.SetCurrentKey("Store Code", Level);
                            StoreGroupSetup.Ascending := false;
                            StoreGroupSetup.SetRange("Store Code", PosTrLine."Store No.");
                            if StoreGroupSetup.FindSet then
                                repeat
                                    lRetPolicy.SetRange("Store Group Code", StoreGroupSetup."Store Group");
                                    if lRetPolicy.FindLast then begin
                                        pReturnPolicy := lRetPolicy;
                                        exit(ReturnPolicyAction(PosTrLine, pReturnPolicy, MgrKey, DatePurchased, pMessageText, pErrorText));
                                    end;
                                until StoreGroupSetup.Next = 0;
                        end;
                    12:  //RetailProductGroup
                        if lItemRec."LSC Retail Product Code" <> '' then begin
                            lRetPolicy.SetRange("Retail Product Code", lItemRec."LSC Retail Product Code");
                            if lRetPolicy.FindLast then begin
                                pReturnPolicy := lRetPolicy;
                                exit(ReturnPolicyAction(PosTrLine, pReturnPolicy, MgrKey, DatePurchased, pMessageText, pErrorText));
                            end;
                        end;
                    13:  //ItemCagegory,StoreNo
                        if (lItemRec."Item Category Code" <> '') and (PosTrLine."Store No." <> '') then begin
                            lRetPolicy.SetRange("Item Category Code", lItemRec."Item Category Code");
                            lRetPolicy.SetFilter("Retail Product Code", '%1', '');
                            lRetPolicy.SetRange("Store No.", PosTrLine."Store No.");
                            if lRetPolicy.FindLast then begin
                                pReturnPolicy := lRetPolicy;
                                exit(ReturnPolicyAction(PosTrLine, pReturnPolicy, MgrKey, DatePurchased, pMessageText, pErrorText));
                            end;
                        end;
                    14:  //ItemCategory,StoreGroup
                        if (lItemRec."Item Category Code" <> '') and (PosTrLine."Store No." <> '') then begin
                            lRetPolicy.SetRange("Item Category Code", lItemRec."Item Category Code");
                            lRetPolicy.SetFilter("Retail Product Code", '%1', '');
                            StoreGroupSetup.Reset;
                            StoreGroupSetup.SetCurrentKey("Store Code", Level);
                            StoreGroupSetup.Ascending := false;
                            StoreGroupSetup.SetRange("Store Code", PosTrLine."Store No.");
                            if StoreGroupSetup.FindSet then
                                repeat
                                    lRetPolicy.SetRange("Store Group Code", StoreGroupSetup."Store Group");
                                    if lRetPolicy.FindLast then begin
                                        pReturnPolicy := lRetPolicy;
                                        exit(ReturnPolicyAction(PosTrLine, pReturnPolicy, MgrKey, DatePurchased, pMessageText, pErrorText));
                                    end;
                                until StoreGroupSetup.Next = 0;
                        end;
                    15:  //ItemCagegory
                        if lItemRec."Item Category Code" <> '' then begin
                            lRetPolicy.SetRange("Item Category Code", lItemRec."Item Category Code");
                            lRetPolicy.SetFilter("Retail Product Code", '%1', '');
                            if lRetPolicy.FindLast then begin
                                pReturnPolicy := lRetPolicy;
                                exit(ReturnPolicyAction(PosTrLine, pReturnPolicy, MgrKey, DatePurchased, pMessageText, pErrorText));
                            end;
                        end;
                    16:  //VariantDim1Code
                        if (PosTrLine.Number <> '') and (PosTrLine."Variant Code" <> '') then begin
                            lRetPolicy.SetFilter("Variant Dimension 1 Code", '<>%1', '');
                            lRetPolicy.SetFilter("Item Category Code", '%1', '');
                            lRetPolicy.SetFilter("Retail Product Code", '%1', '');
                            lRetPolicy.Ascending(false);
                            if lRetPolicy.FindSet() then
                                repeat
                                    ItemVariantRegistration.Reset;
                                    ItemVariantRegistration.SetRange("Item No.", PosTrLine.Number);
                                    ItemVariantRegistration.SetRange("Variant Dimension 1", lRetPolicy."Variant Dimension 1 Code");
                                    ItemVariantRegistration.SetRange(Variant, PosTrLine."Variant Code");
                                    if ItemVariantRegistration.FindFirst then begin
                                        pReturnPolicy := lRetPolicy;
                                        exit(ReturnPolicyAction(PosTrLine, pReturnPolicy, MgrKey, DatePurchased, pMessageText, pErrorText));
                                    end;
                                until lRetPolicy.Next() = 0;
                        end;
                    17: //StoreNo
                        if (PosTrLine."Store No." <> '') then begin
                            lRetPolicy.SetFilter("Store No.", '%1', PosTrLine."Store No.");
                            lRetPolicy.SetFilter("Item Category Code", '%1', '');
                            lRetPolicy.SetFilter("Retail Product Code", '%1', '');
                            if lRetPolicy.FindFirst then begin
                                pReturnPolicy := lRetPolicy;
                                exit(ReturnPolicyAction(PosTrLine, pReturnPolicy, MgrKey, DatePurchased, pMessageText, pErrorText));
                            end;
                        end;
                end;
            end;
        end;

        exit(0);
    end;

    local procedure ReturnPolicyAction(PosTrLine: Record "LSC POS Trans. Line"; RetPolicy: Record "LSC ReturnPolicy"; MgrKey: Boolean; DatePurchased: Date; var pMessageText: Text[250]; var pErrorText: Text[250]): Integer
    var
        ItemRec: Record Item;
        LastReturnDate: Date;
        Days: Integer;
        ReturnInt: Integer;
        Text311: Label 'Refund not allowed for Item %1 %2';
        Text312: Label 'Manager key is required for refunding Item %1 %2';
        Text313: Label 'Item %1 %2 was purchased %3. The refund period is %4 days. Do you want to continue?';
    begin
        Clear(ItemRec);
        ReturnInt := 0;

        if (DatePurchased <> 0D) and (DatePurchased < Today) then begin
            if Format(RetPolicy."Refund Period Length") <> '' then begin
                LastReturnDate := CalcDate(RetPolicy."Refund Period Length", DatePurchased);
                if (LastReturnDate < Today) then begin
                    if ItemRec.Get(PosTrLine.Number) then;
                    Days := LastReturnDate - DatePurchased;
                    pMessageText := StrSubstNo(Text313, ItemRec."No.", ItemRec.Description, DatePurchased, Days);
                    ReturnInt := 2;
                end;
            end;
        end
        else
            if Format(RetPolicy."Refund Period Length") <> '' then begin
                if DatePurchased = 0D then
                    DatePurchased := WorkDate;
                if ItemRec.Get(PosTrLine.Number) then;
                LastReturnDate := CalcDate(RetPolicy."Refund Period Length", DatePurchased);
                Days := LastReturnDate - DatePurchased;
                if Days < 0 then
                    pMessageText := StrSubstNo(Text313, ItemRec."No.", ItemRec.Description, DatePurchased, Days);
                ReturnInt := 2;
            end;

        if pMessageText = '' then begin
            pMessageText := RetPolicy."Message 1";
            if (RetPolicy."Message 2" <> '') then begin
                if pMessageText <> '' then
                    pMessageText := pMessageText + '\' + RetPolicy."Message 2"
                else
                    pMessageText := RetPolicy."Message 2";
            end;
            if (pMessageText <> '') then
                ReturnInt := 1;
        end;

        if RetPolicy."Refund not Allowed" then begin
            if ItemRec.Get(PosTrLine.Number) then;
            pErrorText := StrSubstNo(Text311, PosTrLine.Number, ItemRec.Description);
            ReturnInt := 3;
        end;

        if RetPolicy."Manager Privileges" and not MgrKey then begin
            if ItemRec.Get(PosTrLine.Number) then;
            pErrorText := StrSubstNo(Text312, PosTrLine.Number, ItemRec.Description);
            ReturnInt := 3;
        end;

        OnAfterReturnPolicyAction2(RetPolicy, PosTrLine, ItemRec, MgrKey, pErrorText, pMessageText, ReturnInt);
        exit(ReturnInt);
    end;

    procedure InsertLinkToLastParent(ReceiptNo: Code[20]; LastChildLineNo: Integer; FromLineNo: Integer; LastLineNo: Integer; ParentLineNo: Integer; NewPrice: Decimal; SetPrice: Boolean; LinkedUOM: Code[10]; LinkedQty: Decimal)
    begin
        ShiftLinesDown(ReceiptNo, LastChildLineNo, 1);
        InsertLinkedLine(
          ReceiptNo, FromLineNo, LastLineNo,
          ParentLineNo, NewPrice, SetPrice, LinkedUOM, LinkedQty);
    end;

    procedure ShiftLinesDown(ReceiptNo: Code[20]; LastParentLineNo: Integer; NoOfLinesToShift: Integer)
    var
        LineOffset: Integer;
    begin
        ShiftLinesDown(ReceiptNo, LastParentLineNo, NoOfLinesToShift, LineOffset);
    end;

    procedure ShiftLinesDown(ReceiptNo: Code[20]; LastParentLineNo: Integer; NoOfLinesToShift: Integer; var LineOffset: Integer)
    var
        POSTransLine: Record "LSC POS Trans. Line";
        POSTransLine2: Record "LSC POS Trans. Line";
        POSTransactionImpl: Codeunit "LSC POS Transaction Impl";
    begin
        //down x * 10000 to make space for new lines at the end of the parent group.
        POSTransLineTemp.Reset;
        POSTransLineTemp.DeleteAll;

        POSTransLine.SetRange("Receipt No.", ReceiptNo);
        POSTransLine.FindLast();

        LineOffset := NoOfLinesToShift * 10000;

        repeat
            POSTransLineTemp.Init;
            POSTransLineTemp."Receipt No." := POSTransLine."Receipt No.";
            POSTransLineTemp."Line No." := POSTransLine."Line No.";
            POSTransLineTemp."Parent Line" := POSTransLine."Line No." + LineOffset;  //new number
            POSTransLineTemp.Insert;

            POSTransLine.Delete;

            POSTransLine2 := POSTransLine;
            POSTransLine2."Line No." := POSTransLineTemp."Parent Line";
            if POSTransLine2."Parent Line" <> 0 then
                if POSTransLine2."Parent Line" > LastParentLineNo then
                    POSTransLine2."Parent Line" := POSTransLine2."Parent Line" + LineOffset;
            if POSSESSION.GetValue("LSC POS Tag"::"OFFL_CALLCENTER") = 'SENT' then begin
                if POSTransLine."Shifted from Line No." <> 0 then
                    POSTransLine2."Shifted from Line No." := POSTransLine."Shifted from Line No."
                else
                    POSTransLine2."Shifted from Line No." := POSTransLine."Line No.";
            end;

            POSTransLine2.Insert;
            MoveLinkedLines(POSTransLineTemp);
        until (POSTransLine.Next(-1) = 0) or (POSTransLine."Line No." <= LastParentLineNo);

        POSTransactionImpl.InfocodeBuffer_UpdateShiftLineOffset(LineOffset);

        CorrectLineNumbers(ReceiptNo);
    end;

    local procedure MoveLinkedLines(var pPOSTransLine: Record "LSC POS Trans. Line")
    var
        POSTransInfoEntry: Record "LSC POS Trans. Infocode Entry";
        POSTransInfoEntry2: Record "LSC POS Trans. Infocode Entry";
        POSMixMatchEntry: Record "LSC POS Mix & Match Entry";
        POSMixMatchEntry2: Record "LSC POS Mix & Match Entry";
        OfferPosCalculations: Record "LSC Offer Pos Calculation";
        OfferPosCalculations2: Record "LSC Offer Pos Calculation";
        PosTrPerDisc: Record "LSC POS Trans. Per. Disc. Type";
        PosTrPerDisc2: Record "LSC POS Trans. Per. Disc. Type";
        DataEntry: Record "LSC POS Data Entry";
        tmpDataEntry: Record "LSC POS Data Entry";
        KotTransLineMapping: Record "LSC KOT Trans. Line Mapping";
        KotTransLineMapping2: Record "LSC KOT Trans. Line Mapping";
        KotTransLineModMapping: Record "LSC KOT Trans. Ln Mod. Mapping";
        KotTransLineModMapping2: Record "LSC KOT Trans. Ln Mod. Mapping";
        PosTrLineDisplStatRout: Record "LSC POS Tr. Line Dis. Stat. R.";
        PosTrLineDisplStatRout2: Record "LSC POS Tr. Line Dis. Stat. R.";
    begin
        //Move lines in trans. lines linked tables.
        POSTransInfoEntry.Reset;
        POSTransInfoEntry.SetRange(POSTransInfoEntry."Receipt No.", pPOSTransLine."Receipt No.");
        POSTransInfoEntry.SetRange(POSTransInfoEntry."Transaction Type", POSTransInfoEntry."Transaction Type"::"Sales Entry");
        POSTransInfoEntry.SetRange(POSTransInfoEntry."Line No.", pPOSTransLine."Line No.");
        if POSTransInfoEntry.FindSet then begin
            repeat
                POSTransInfoEntry.Delete;
                POSTransInfoEntry2 := POSTransInfoEntry;
                POSTransInfoEntry2."Line No." := pPOSTransLine."Parent Line";
                POSTransInfoEntry2.Insert;
            until POSTransInfoEntry.Next = 0;
        end;

        POSMixMatchEntry.Reset;
        POSMixMatchEntry.SetRange(POSMixMatchEntry."Receipt No.", pPOSTransLine."Receipt No.");
        POSMixMatchEntry.SetRange(POSMixMatchEntry."Line No.", pPOSTransLine."Line No.");
        if POSMixMatchEntry.FindSet then begin
            repeat
                POSMixMatchEntry.Delete;
                POSMixMatchEntry2 := POSMixMatchEntry;
                POSMixMatchEntry2."Line No." := pPOSTransLine."Parent Line";
                POSMixMatchEntry2.Insert;
            until POSMixMatchEntry.Next = 0;
        end;

        OfferPosCalculations.Reset;
        OfferPosCalculations.SetRange(OfferPosCalculations."Receipt No.", pPOSTransLine."Receipt No.");
        OfferPosCalculations.SetRange(OfferPosCalculations."Trans. Line No.", pPOSTransLine."Line No.");
        if OfferPosCalculations.FindSet then begin
            repeat
                OfferPosCalculations.Delete;
                OfferPosCalculations2 := OfferPosCalculations;
                OfferPosCalculations2."Trans. Line No." := pPOSTransLine."Parent Line";
                OfferPosCalculations2.Insert;
            until OfferPosCalculations.Next = 0;
        end;

        PosTrPerDisc.Reset;
        PosTrPerDisc.SetRange("Receipt No.", pPOSTransLine."Receipt No.");
        PosTrPerDisc.SetRange("Line No.", pPOSTransLine."Line No.");
        PosTransDiscSetTableFilter(1, PosTrPerDisc);
        if PosTransDiscFindSetRec(1, PosTrPerDisc) then begin
            repeat
                PosTransDiscDeleteRec(PosTrPerDisc);
                PosTrPerDisc2 := PosTrPerDisc;
                PosTrPerDisc2."Line No." := pPOSTransLine."Parent Line";
                PosTransDiscUpdateRec(PosTrPerDisc2);
            until PosTransDiscNextRec(1, 1, PosTrPerDisc) = 0;
        end;

        DataEntry.Reset;
        DataEntry.SetCurrentKey("Created by Receipt No.", "Created by Line No.");
        DataEntry.SetRange("Created by Receipt No.", pPOSTransLine."Receipt No.");
        DataEntry.SetRange("Created by Line No.", pPOSTransLine."Line No.");
        if DataEntry.FindSet then
            repeat
                tmpDataEntry.TransferFields(DataEntry);
                tmpDataEntry."Created by Line No." := pPOSTransLine."Parent Line";
                tmpDataEntry.Modify;
            until DataEntry.Next = 0;

        DataEntry.Reset;
        DataEntry.SetCurrentKey("Applied by Receipt No.", "Applied by Line No.");
        DataEntry.SetRange("Applied by Receipt No.", pPOSTransLine."Receipt No.");
        DataEntry.SetRange("Applied by Line No.", pPOSTransLine."Line No.");
        if DataEntry.FindSet then
            repeat
                tmpDataEntry.TransferFields(DataEntry);
                tmpDataEntry."Applied by Line No." := pPOSTransLine."Parent Line";
                tmpDataEntry.Modify;
            until DataEntry.Next = 0;

        if not BOUtils.IsHospitalityPermitted then
            exit;

        PosTrLineDisplStatRout.Reset;
        PosTrLineDisplStatRout.SetRange("Receipt No.", pPOSTransLine."Receipt No.");
        PosTrLineDisplStatRout.SetRange("Pos Trans. Line No.", pPOSTransLine."Line No.");
        if PosTrLineDisplStatRout.FindSet then
            repeat
                PosTrLineDisplStatRout.Delete;
                PosTrLineDisplStatRout2 := PosTrLineDisplStatRout;
                PosTrLineDisplStatRout2."Pos Trans. Line No." := pPOSTransLine."Parent Line";
                PosTrLineDisplStatRout2.Insert;
            until PosTrLineDisplStatRout.Next = 0;

        KotTransLineMapping.Reset;
        KotTransLineMapping.SetCurrentKey("Receipt No.", "POS Trans. Line No.");
        KotTransLineMapping.SetRange("Receipt No.", pPOSTransLine."Receipt No.");
        KotTransLineMapping.SetRange("POS Trans. Line No.", pPOSTransLine."Line No.");
        if KotTransLineMapping.FindSet(true) then
            repeat
                KotTransLineMapping2 := KotTransLineMapping;
                KotTransLineMapping2."POS Trans. Line No." := pPOSTransLine."Parent Line";
                KotTransLineMapping2.Modify;
            until KotTransLineMapping.Next = 0;

        KotTransLineModMapping.Reset;
        KotTransLineModMapping.SetCurrentKey("Receipt No.", "POS Trans. Line No.");
        KotTransLineModMapping.SetRange("Receipt No.", pPOSTransLine."Receipt No.");
        KotTransLineModMapping.SetRange("POS Trans. Line No.", pPOSTransLine."Line No.");
        if KotTransLineModMapping.FindSet(true) then
            repeat
                KotTransLineModMapping2 := KotTransLineModMapping;
                KotTransLineModMapping2."POS Trans. Line No." := pPOSTransLine."Parent Line";
                KotTransLineModMapping2.Modify;
            until KotTransLineModMapping.Next = 0;
    end;

    local procedure CorrectLineNumbers(RcptNo: Code[20])
    var
        POStrans3: Record "LSC POS Trans. Line";
        ModifyNeeded: Boolean;
    begin
        //Correct "Disc. Info Line No.", according to moved lines.
        POStrans3.Reset;
        POStrans3.SetRange("Receipt No.", RcptNo);
        if POStrans3.FindSet then
            repeat
                if POStrans3."Disc. Info Line No." <> 0 then begin
                    if POSTransLineTemp.Get(POStrans3."Receipt No.", POStrans3."Disc. Info Line No.") then begin
                        POStrans3."Disc. Info Line No." := POSTransLineTemp."Parent Line";
                        ModifyNeeded := true;
                    end;
                end;
                if POStrans3."Mix & Match Line No." <> 0 then begin
                    if POSTransLineTemp.Get(POStrans3."Receipt No.", POStrans3."Mix & Match Line No.") then begin
                        POStrans3."Mix & Match Line No." := POSTransLineTemp."Parent Line";
                        ModifyNeeded := true;
                    end;
                end;
                if POStrans3."Tot. Disc Info Line No." <> 0 then begin
                    if POSTransLineTemp.Get(POStrans3."Receipt No.", POStrans3."Tot. Disc Info Line No.") then begin
                        POStrans3."Tot. Disc Info Line No." := POSTransLineTemp."Parent Line";
                        ModifyNeeded := true;
                    end;
                end;
                if POStrans3."Split Origin Line No." <> 0 then begin
                    if POSTransLineTemp.Get(POStrans3."Receipt No.", POStrans3."Split Origin Line No.") then begin
                        POStrans3."Split Origin Line No." := POSTransLineTemp."Parent Line";
                        ModifyNeeded := true;
                    end;
                end;
                if ModifyNeeded then
                    POStrans3.Modify(true);
            until POStrans3.Next = 0;
    end;

    local procedure InsertLinkedLine(ReceiptNo: Code[20]; FromLineNo: Integer; LastLineNo: Integer; ParentLineNo: Integer; NewPrice: Decimal; SetPrice: Boolean; LinkedUOM: Code[10]; LinkedQty: Decimal)
    var
        POStrans2: Record "LSC POS Trans. Line";
        POStrans3: Record "LSC POS Trans. Line";
        POSPriceUtil: Codeunit "LSC POS Price Utility";
    begin
        //Attach to Last Parent command
        //Move last lines to the created space, last in the parent group.
        POSTransLineTemp.Get(ReceiptNo, LastLineNo);         //linked line with old line no.
        repeat
            POStrans2.Get(ReceiptNo, POSTransLineTemp."Parent Line");  //linked line with new line no.
            POStrans2.Delete;

            POStrans3 := POStrans2;
            POStrans3."Line No." := FromLineNo;
            if POStrans3."Parent Line" <> 0 then
                POStrans3."Parent Line" := ParentLineNo;

            if LinkedUOM <> '' then
                POStrans3.Validate("Unit of Measure", LinkedUOM);

            if SetPrice then
                POStrans3.Validate(POStrans3.Price, NewPrice)
            else
                POSPriceUtil.UpdatePrice(POStrans3);

            POStrans3.Validate(Quantity, POStrans3.Quantity * LinkedQty);
            POStrans3.Insert;

            POSTransLineTemp."Parent Line" := FromLineNo;
            POSTransLineTemp.Modify;
            POStrans2."Parent Line" := FromLineNo;
            MoveLinkedLines(POStrans2);
        until POSTransLineTemp.Next = 0;
    end;

    internal procedure SplitPosTransLineByQty(var OrgPosTransLine: Record "LSC POS Trans. Line"; var NewLineNo: Integer; QtyToSplit: Decimal)
    begin
        NewLineNo := SplitPOSTransLine_GetNewLine(OrgPosTransLine);

        SplitPosTransLine_Insert(OrgPosTransLine, NewLineNo, QtyToSplit);
    end;

    internal procedure SplitPOSTransLine_GetNewLine(var OrgPosTransLine: Record "LSC POS Trans. Line"): Integer
    var
        PosTransLine: Record "LSC POS Trans. Line";
    begin
        PosTransLine.SetRange("Receipt No.", OrgPosTransLine."Receipt No.");
        PosTransLine.SetFilter(
          "Entry Type", '%1..%2|%3..',
          PosTransLine."Entry Type"::Item,
          PosTransLine."Entry Type"::Payment,
          PosTransLine."Entry Type"::IncomeExpense);
        PosTransLine.FindLast();
        exit(PosTransLine."Line No." + 10000);
    end;

    internal procedure SplitPosTransLine_Insert(var OrgPosTransLine: Record "LSC POS Trans. Line"; NewLineNo: Integer; QtyToSplit: Decimal)
    var
        NewPosTransLine: Record "LSC POS Trans. Line";
        PosPriceUtility: Codeunit "LSC POS Price Utility";
        OrgQty: Decimal;
    begin
        PosPriceUtility.GetTransDisc(OrgPosTransLine, true, Enum::"LSC POS Trans. Per. Disc. Type"::"Periodic Disc.");
        OrgQty := OrgPosTransLine.Quantity;

        NewPosTransLine.Init;
        NewPosTransLine := OrgPosTransLine;

        NewPosTransLine."Line No." := NewLineNo;
        NewPosTransLine."Parent Line" := NewLineNo;
        NewPosTransLine.Quantity := QtyToSplit;
        NewPosTransLine."Parent Compression" := NewPosTransLine."Parent Compression"::"Split Parent Line";
        NewPosTransLine."Shifted from Line No." := 0;
        NewPosTransLine."Split from Line No." := 0;
        NewPosTransLine."Split from Line No. Qty." := 0;
        NewPosTransLine."Kitchen Routing" := NewPosTransLine."Kitchen Routing"::No;

        if POSSESSION.GetValue("LSC POS Tag"::"OFFL_CALLCENTER") = 'SENT' then begin
            if OrgPosTransLine."Shifted from Line No." <> 0 then
                NewPosTransLine."Split from Line No." := OrgPosTransLine."Shifted from Line No."
            else
                NewPosTransLine."Split from Line No." := OrgPosTransLine."Line No.";
            NewPosTransLine."Split from Line No. Qty." := OrgPosTransLine.Quantity;
        end;
        CopyTransPerDiscLines(OrgPosTransLine, NewPosTransLine);
        NewPosTransLine.CalcPrices;
        NewPosTransLine.Insert(true);

        OrgPosTransLine.Quantity := OrgPosTransLine.Quantity - QtyToSplit;
        OrgPosTransLine.CalcPrices;
        ChangeTransPerDiscLines(OrgPosTransLine, OrgQty, OrgPosTransLine.Quantity);
        OrgPosTransLine.Modify(true);
    end;

    internal procedure CopyTransPerDiscLines(OrgLine: Record "LSC POS Trans. Line"; NewLine: Record "LSC POS Trans. Line")
    var
        OrgPerDiscLine: Record "LSC POS Trans. Per. Disc. Type";
        NewPerDiscLine: Record "LSC POS Trans. Per. Disc. Type";
    begin
        if (OrgLine."Line No." = NewLine."Line No.") then
            exit;
        OrgPerDiscLine.Reset;
        OrgPerDiscLine.SetRange("Receipt No.", OrgLine."Receipt No.");
        OrgPerDiscLine.SetRange("Line No.", OrgLine."Line No.");
        PosTransDiscSetTableFilter(1, OrgPerDiscLine);
        if not PosTransDiscFindSetRec(1, OrgPerDiscLine) then
            exit;
        repeat
            NewPerDiscLine := OrgPerDiscLine;
            NewPerDiscLine."Line No." := NewLine."Line No.";

            if (OrgLine.Quantity <> NewLine.Quantity) then
                NewPerDiscLine."Discount Amount" := NewPerDiscLine."Discount Amount" * (NewLine.Quantity / OrgLine.Quantity);

            PosTransDiscUpdateRec(NewPerDiscLine);
        until PosTransDiscNextRec(1, 1, OrgPerDiscLine) = 0;
    end;

    procedure PublicCopyTransPerDiscLines(OrgLine: Record "LSC POS Trans. Line"; NewLine: Record "LSC POS Trans. Line")
    begin
        CopyTransPerDiscLines(OrgLine, NewLine);
    end;

    procedure ChangeTransPerDiscLines(PosTrLine: Record "LSC POS Trans. Line"; OrgQty: Decimal; NewQty: Decimal)
    var
        PerDiscLine: Record "LSC POS Trans. Per. Disc. Type";
    begin
        if OrgQty = 0 then
            exit;
        if OrgQty = NewQty then
            exit;
        PerDiscLine.Reset;
        PerDiscLine.SetRange("Receipt No.", PosTrLine."Receipt No.");
        PerDiscLine.SetRange("Line No.", PosTrLine."Line No.");
        PosTransDiscSetTableFilter(1, PerDiscLine);
        if not PosTransDiscFindRec(1, '-', PerDiscLine) then
            exit;
        repeat
            PerDiscLine."Discount Amount" := PerDiscLine."Discount Amount" * (NewQty / OrgQty);
            PosTransDiscUpdateRec(PerDiscLine);
        until PosTransDiscNextRec(1, 1, PerDiscLine) = 0;
    end;

    internal procedure DeleteTransPerDiscLines(PosTrLine: Record "LSC POS Trans. Line")
    var
        PerDiscLine: Record "LSC POS Trans. Per. Disc. Type";
    begin
        PerDiscLine.Reset;
        PerDiscLine.SetRange("Receipt No.", PosTrLine."Receipt No.");
        PerDiscLine.SetRange("Line No.", PosTrLine."Line No.");
        PosTransDiscSetTableFilter(1, PerDiscLine);
        if not PosTransDiscFindRec(1, '-', PerDiscLine) then
            exit;
        repeat
            PosTransDiscDeleteRec(PerDiscLine);
        until PosTransDiscNextRec(1, 1, PerDiscLine) = 0;
    end;

    procedure DiscReset(var LineRec: Record "LSC POS Trans. Line")
    var
        PosTrans: Record "LSC POS Transaction";
        OfferPoscalculations: Record "LSC Offer Pos Calculation";
        PosTransPerDisc: Record "LSC POS Trans. Per. Disc. Type";
        PerDisc: Record "LSC Periodic Discount";
        PosTransPerDisc2: Record "LSC POS Trans. Per. Disc. Type";
        splitline: Record "LSC POS Trans. Line";
        PosTransLineTemp1: Record "LSC POS Trans. Line" temporary;
        PosPriceUtil: Codeunit "LSC POS Price Utility";
        DiscountOfferList: List of [Code[20]];
        IsHandled: Boolean;
    begin
        OnBeforeDiscReset(LineRec, IsHandled);
        if IsHandled then
            exit;

        InitPosFunctions;

        PosTrans.Get(LineRec."Receipt No.");
        PosTransPerDisc2.Init;
        PosTransPerDisc2.SetRange("Receipt No.", LineRec."Receipt No.");
        PosTransPerDisc2.SetRange("Line No.", LineRec."Line No.");
        PosTransPerDisc2.SetFilter(DiscType, 'Periodic Disc.');
        PosTransDiscSetTableFilter(1, PosTransPerDisc2);
        if PosTransDiscFindFirstRec(1, PosTransPerDisc2) then begin
            if PerDisc.Get(PosTransPerDisc2."Periodic Disc. Group") then
                if PerDisc."Coupon Code" <> '' then begin
                    LineRec."System-Block Periodic Discount" := true;
                    LineRec."System-Exclude from Offers" := true;
                end;
        end;
        PosTransPerDisc.SetRange("Receipt No.", LineRec."Receipt No.");
        PosTransPerDisc.SetRange("Line No.", LineRec."Line No.");
        PosTransPerDisc.SetFilter(DiscType, 'Line|Line Discount|Total');
        PosTransDiscSetTableFilter(1, PosTransPerDisc);
        if PosTransDiscFindRec(1, '-', PosTransPerDisc) then
            repeat
                PosTransPerDisc."Discount %" := 0;
                PosTransPerDisc."Discount Amount" := 0;
                PosTransPerDisc."Total Disc. Amount" := 0;
                PosTransPerDisc."Periodic Discount Amount" := 0;
                PosTransDiscUpdateRec(PosTransPerDisc);
                PosTransPerDisc.AddOfferNoToList(DiscountOfferList);
            until PosTransDiscNextRec(1, 1, PosTransPerDisc) = 0;

        LineRec."Discount Triggered" := false;
        LineRec."Quantity Discounted" := 0;
        LineRec."InfoCode Disc. Disable" := false;
        LineRec."InfoCode Disc. %" := 0;
        LineRec."Periodic Disc. %" := 0;
        LineRec."Mix & Match Line No." := 0;
        LineRec."Periodic Discount Amount" := 0;
        LineRec.Validate(LineRec."Line Disc. %", 0);
        LineRec.Modify;

        OfferPoscalculations.SetRange("Receipt No.", LineRec."Receipt No.");
        OfferPoscalculations.SetRange("Trans. Line No.", LineRec."Line No.");
        if OfferPoscalculations.FindFirst then
            OfferPoscalculations.DeleteAll;

        LineRec.UpdatePerDiscInfoLine;

        LineRec.BlockAutomaticLineDiscount(DiscountOfferList);
        PosPriceUtil.SetPosTransLineOfferBlocked(LineRec, Enum::"LSC Discount Blocking Type"::InfoCode);
        if not PosSession.FunctionalityProfile."Period Disc. on Total Pressed" then
            if PosPriceUtil.IsTransPerDiscType(PosTrans, PerDisc.Type::"Mix&Match") then begin
                splitline.Reset;
                splitline.SetFilter("Receipt No.", PosTrans."Receipt No.");
                if splitline.FindSet then
                    repeat
                        PosPriceUtil.SplitMixMatchLine(splitline, PosTransLineTemp1);
                    until splitline.Next = 0;
            end;

        PosTransPerDisc.Reset;
        PosTransPerDisc.SetRange("Receipt No.", LineRec."Receipt No.");
        PosTransPerDisc.SetRange("Line No.", LineRec."Line No.");
        PosTransPerDisc.SetFilter("No.", '<>%1', 0);
        PosTransDiscSetTableFilter(1, PosTransPerDisc);
        PosTransDiscDeleteAllRec(1);
        LineRec.CalcPrices;
        LineRec.Modify(true);
    end;

    procedure MarkLine(var pPosTransLine: Record "LSC POS Trans. Line")
    var
        MarkPosTransLine: Record "LSC POS Trans. Line" temporary;
        COSetup: Record "LSC Customer Order Setup";
        LineReceiptNoTmp: Code[20];
        LineNoTmp: Integer;
        DiscLineNoTmp: Integer;
        ParentLineNo: Integer;
        LineNoOfParent: Integer;
        Marked: Boolean;
        DealLine: Boolean;
        IsHandled: Boolean;
    begin
        if (pPosTransLine."Entry Type" = pPosTransLine."Entry Type"::FreeText) and
            (pPosTransLine."Text Type" = pPosTransLine."Text Type"::"Pre-Auth Text") and
            (pPosTransLine."Text Type" = pPosTransLine."Text Type"::"Card On File Text") then
            exit;

        OnBeforeMarkLine(pPosTransLine, IsHandled);
        if IsHandled then
            exit;

        LineNoTmp := pPosTransLine."Line No.";
        LineReceiptNoTmp := pPosTransLine."Receipt No.";
        DiscLineNoTmp := pPosTransLine."Disc. Info Line No.";
        DealLine := pPosTransLine."Deal Line";
        ParentLineNo := pPosTransLine."Parent Line";

        LineNoOfParent := pPosTransLine."Line No.";

        Marked := not pPosTransLine.Marked;
        Clear(MarkPosTransLine);
        MarkPosTransLine.DeleteAll;
        // find and mark parent
        if pPosTransLine."Parent Line" = 0 then
            pPosTransLine.SetMark(Marked)
        else begin
            if pPosTransLine."Parent Line" = pPosTransLine."Line No." then
                pPosTransLine.SetMark(Marked)
            else begin   // 2nd level
                pPosTransLine.Reset;
                pPosTransLine.SetRange("Receipt No.", LineReceiptNoTmp);
                pPosTransLine.SetRange("Line No.", ParentLineNo);
                pPosTransLine.SetRange("Entry Status", 0);
                if pPosTransLine.FindFirst then begin
                    LineNoOfParent := pPosTransLine."Line No.";
                    if pPosTransLine."Parent Line" = 0 then
                        pPosTransLine.SetMark(Marked)
                    else begin
                        if pPosTransLine."Parent Line" = pPosTransLine."Line No." then
                            pPosTransLine.SetMark(Marked)
                        else begin   // 3rd level
                            ParentLineNo := pPosTransLine."Parent Line";
                            pPosTransLine.Reset;
                            pPosTransLine.SetRange("Receipt No.", LineReceiptNoTmp);
                            pPosTransLine.SetRange("Line No.", ParentLineNo);
                            pPosTransLine.SetRange("Entry Status", 0);
                            if pPosTransLine.FindFirst then begin
                                LineNoOfParent := pPosTransLine."Line No.";
                                pPosTransLine.SetMark(Marked);
                            end else
                                pPosTransLine.SetMark(Marked);
                        end;
                    end;
                end else
                    pPosTransLine.SetMark(Marked);
            end;
        end;
        // mark children
        pPosTransLine.Reset;
        pPosTransLine.SetCurrentKey("Receipt No.", "Parent Line");
        pPosTransLine.SetRange("Receipt No.", LineReceiptNoTmp);
        pPosTransLine.SetRange("Parent Line", LineNoOfParent);
        pPosTransLine.SetFilter("Line No.", '<>%1', LineNoOfParent);
        pPosTransLine.SetRange("Entry Status", 0);
        if pPosTransLine.FindSet then
            repeat
                pPosTransLine.SetMark(Marked);
                MarkPosTransLine := pPosTransLine;
                MarkPosTransLine.Insert;
            until pPosTransLine.Next = 0;

        // mark grandchildren
        if MarkPosTransLine.FindSet then
            repeat
                pPosTransLine.Reset;
                pPosTransLine.SetCurrentKey("Receipt No.", "Parent Line");
                pPosTransLine.SetRange("Receipt No.", LineReceiptNoTmp);
                pPosTransLine.SetRange("Parent Line", MarkPosTransLine."Line No.");
                pPosTransLine.SetRange("Entry Status", 0);
                if pPosTransLine.FindSet then
                    repeat
                        pPosTransLine.SetMark(Marked);
                    until pPosTransLine.Next = 0;
            until MarkPosTransLine.Next = 0;

        if DealLine then
            exit;

        pPosTransLine.Reset;
        pPosTransLine.SetRange("Receipt No.", LineReceiptNoTmp);
        pPosTransLine.SetRange("Disc. Info Line No.", LineNoTmp);
        pPosTransLine.SetRange("Entry Status", 0);
        if pPosTransLine.FindSet then
            repeat
                pPosTransLine.SetMark(Marked);
            until pPosTransLine.Next = 0;

        if DiscLineNoTmp <> 0 then begin
            pPosTransLine.Reset;
            pPosTransLine.SetRange("Receipt No.", LineReceiptNoTmp);
            pPosTransLine.SetRange("Line No.", DiscLineNoTmp);
            pPosTransLine.SetRange("Entry Status", 0);
            if pPosTransLine.FindFirst then begin
                pPosTransLine.SetMark(Marked);
                LineNoTmp := pPosTransLine."Line No.";
                COSetup.Get();
                if not COSetup."CO Discount Item Line Split" then begin
                    pPosTransLine.Reset;
                    pPosTransLine.SetRange("Receipt No.", LineReceiptNoTmp);
                    pPosTransLine.SetRange("Disc. Info Line No.", LineNoTmp);
                    pPosTransLine.SetRange("Entry Status", 0);
                    if pPosTransLine.FindSet then
                        repeat
                            pPosTransLine.SetMark(Marked);
                        until pPosTransLine.Next = 0;
                end;
            end;
        end;
    end;

    procedure GetMemberInfoForPosMemberTender(CardNo: Text; var ResponseCode: Code[30]; var ErrorText: Text; RunGetMemberInfoForPOS: Boolean): Boolean
    var
        IsHandled, ReturnValue : Boolean;
    begin
        POSSESSION.SetValue("LSC POS Tag"::TS_ERROR, '');
        OnBeforeGetMemberInfoForPos(CardNo, ResponseCode, ErrorText, IsHandled, ReturnValue, RunGetMemberInfoForPOS);
        if IsHandled then
            exit(ReturnValue)
        else begin
            if not POSMemberMgt.GetMemberInfoForPos(CardNo, ResponseCode, ErrorText, RunGetMemberInfoForPOS) then begin
                if (ResponseCode = '0098') or (ResponseCode = '0099') then
                    POSSESSION.SetValue("LSC POS Tag"::TS_ERROR, LSHelper.Trim(ErrorText, 250));
                exit(false);
            end;
        end;
        exit(true);
    end;

    procedure ClearMemberInfo()
    begin
        POSMemberMgt.ClearMemberInfo;
        POSMemberMgt.ClearMemberDirectMarketingInfo;
    end;

    procedure GetMemberInfoForPos(CardNo: Text; var ResponseCode: Code[30]; var ErrorText: Text): Boolean
    begin
        exit(GetMemberInfoForPOS(CardNo, ResponseCode, ErrorText, false));
    end;

    procedure GetMemberInfoForPos(CardNo: Text; var ResponseCode: Code[30]; var ErrorText: Text; RunGetMemberInfo: Boolean): Boolean
    var
        IsHandled, ReturnValue : Boolean;
    begin
        POSSESSION.SetValue("LSC POS Tag"::"TS_ERROR", '');
        OnBeforeGetMemberInfoForPos(CardNo, ResponseCode, ErrorText, IsHandled, ReturnValue, RunGetMemberInfo);
        if IsHandled then
            exit(ReturnValue);
        if not POSMemberMgt.GetMemberInfoForPos(CardNo, ResponseCode, ErrorText, RunGetMemberInfo) then begin
            if (ResponseCode = '0098') or (ResponseCode = '0099') then
                POSSESSION.SetValue("LSC POS Tag"::"TS_ERROR", LSHelper.Trim(ErrorText, 250));
            exit(false);
        end;
        exit(true);
    end;

    internal procedure GetMemberDirectMarketingInfoForPos(CardNo: Text; var ResponseCode: Code[30]; var ErrorText: Text): Boolean
    begin
        POSSESSION.SetValue("LSC POS Tag"::"TS_ERROR", '');
        if not POSMemberMgt.GetMemberDirectMarketingInfoForPos(CardNo, ResponseCode, ErrorText) then begin
            if (ResponseCode = '0098') or (ResponseCode = '0099') then
                POSSESSION.SetValue("LSC POS Tag"::"TS_ERROR", LSHelper.Trim(ErrorText, 250));
            exit(false);
        end;
        exit(true);
    end;

    internal procedure GetMemberPublishedOffers(var PublishedOffer: Record "LSC Published Offer"): Boolean
    begin
        exit(POSMemberMgt.GetMemberPublishedOffers(PublishedOffer));
    end;

    internal procedure GetMemberSalesHistory(var MemberSalesEntryTemp: Record "LSC Member Sales Entry" temporary): Boolean
    begin
        exit(POSMemberMgt.GetMemberSalesHistory(MemberSalesEntryTemp));
    end;

    procedure GetMemberShipCardInfo(var pMembershipCardTemp: Record "LSC Membership Card" temporary): Boolean
    begin
        exit(POSMemberMgt.GetMemberShipCardInfo(pMembershipCardTemp));
    end;

    procedure GetMemberAccountInfo(var pMemberAccount: Record "LSC Member Account" temporary): Boolean
    begin
        exit(POSMemberMgt.GetMemberAccountInfo(pMemberAccount));
    end;

    procedure GetMemberClubInfo(var pMemberClubTemp: Record "LSC Member Club" temporary): Boolean
    begin
        exit(POSMemberMgt.GetMemberClubInfo(pMemberClubTemp));
    end;

    procedure GetMemberSchemeInfo(var pMemberSchemeTemp: Record "LSC Member Scheme" temporary): Boolean
    begin
        exit(POSMemberMgt.GetMemberSchemeInfo(pMemberSchemeTemp));
    end;

    internal procedure GetMemberMgtSetupInfo(var pMemberMgtSetupTemp: Record "LSC Member Management Setup" temporary): Boolean
    begin
        exit(POSMemberMgt.GetMemberMgtSetupInfo(pMemberMgtSetupTemp));
    end;

    procedure GetMemberPointSetupInfo(var pMemberPointSetupTemp: Record "LSC Member Point Setup" temporary): Boolean
    begin
        exit(POSMemberMgt.GetMemberPointSetupInfo(pMemberPointSetupTemp));
    end;

    procedure GetMemberAttributeList(var pAttributeListList: Record "LSC Member Attribute List" temporary): Boolean
    begin
        exit(POSMemberMgt.GetAttributeList(pAttributeListList));
    end;

    internal procedure GetMemberCustomerDiscountGroup(): Code[10]
    begin
        exit(POSMemberMgt.GetMemberCustomerDiscountGroup);
    end;

    internal procedure GetMemberPriceGroup(): Code[10]
    begin
        exit(POSMemberMgt.GetMemberPriceGroup);
    end;

    internal procedure ChangeStaff(PosTransIn: Record "LSC POS Transaction")
    var
        HospitalityType: Record "LSC Hospitality Type";
        KDSFunc: Codeunit "LSC KDS Functions";
        HospFunc: Codeunit "LSC Hospitality Functions";
        HospDiningTblMgmtFunc: Codeunit "LSC Hosp. DIN Tbl. Mgt. Func.";
        PrintWhenPosting: Boolean;
        MarkKOTWithStaffLogin: Boolean;
    begin
        PosSession.Store.Get(POSSESSION.StoreNo);

        PosTransIn.CalcFields("Staff Receipt Name");

        if PosTransIn."Table No." <> 0 then
            HospDiningTblMgmtFunc.SetDiningTblOwner(PosTransIn);

        if POSSession.Store."Kitchen Prod. System in Use" = "LSC Store KitchenPrintingInUse"::No then
            exit;

        if not HospFunc.KitchenStatusInUse(PosTransIn, PrintWhenPosting) then
            exit;

        if not HospitalityType.Get(PosTransIn."Store No.", PosTransIn."Hosp. Type Sequence", PosTransIn."Sales Type") then
            exit;

        MarkKOTWithStaffLogin := KDSFunc.GetKOTStaffMarking(HospitalityType."Service Flow ID");
        if MarkKOTWithStaffLogin then //only change the staff in KOT tables if marked with transaction staff
            exit;
        KDSFunc.UpdateStaffID(PosTransIn."Receipt No.", PosTransIn."Staff ID", PosTransIn."Staff Receipt Name");
    end;

    internal procedure SetPosTransDiscEntryBuffer(var pPosTransPerDiscTmp: Record "LSC POS Trans. Per. Disc. Type" temporary)
    begin
        DiscLedgerMgt.SavePosTransDiscBuffer(pPosTransPerDiscTmp);
    end;

    procedure ClearPosTransDiscEntryBuffer()
    begin
        DiscLedgerMgt.DelerePosTransDiscBuffer;
    end;

    internal procedure InsertPosTransDiscEntryBuffer(var pPosTransLine: Record "LSC POS Trans. Line")
    var
        PosTransPerDiscTmp: Record "LSC POS Trans. Per. Disc. Type" temporary;
        PosTransPerDisc: Record "LSC POS Trans. Per. Disc. Type";
    begin
        DiscLedgerMgt.GetPosTransDiscBuffer(PosTransPerDiscTmp);

        PosTransPerDiscTmp.Reset;
        if PosTransPerDiscTmp.FindSet then
            repeat
                PosTransPerDisc.Init;
                PosTransPerDisc := PosTransPerDiscTmp;
                PosTransPerDisc."Line No." := pPosTransLine."Line No.";
                PosTransPerDisc."Entry Status" := pPosTransLine."Entry Status";
                PosTransDiscUpdateRec(PosTransPerDisc);
            until PosTransPerDiscTmp.Next = 0;
    end;

    internal procedure GetMemberLimitation(pLimitationCode: Code[10]; var pLimitationValue: Decimal; var pLimitationType: Enum "LSC Discount Limitation Type"): Boolean
    var
        ErrorText: Text[1024];
    begin
        exit(POSMemberMgt.GetLimitationValue(pLimitationCode, pLimitationValue, pLimitationType, ErrorText));
    end;

    procedure InitTrackingInstanceID(var pPOSTrans: Record "LSC POS Transaction")
    begin
        POSMemberMgt.InitTrackingInstanceID(pPOSTrans);
    end;

    internal procedure IncTrackingInstanceID()
    begin
        POSMemberMgt.IncTrackingInstanceID;
    end;

    internal procedure GetCurrTrackingInstanceID(): Integer
    begin
        exit(POSMemberMgt.GetCurrTrackingInstanceID);
    end;

    procedure GetCurrMemberContact(var pMemberContact: Record "LSC Member Contact" temporary): Boolean
    begin
        exit(POSMemberMgt.GetMemberContactInfo(pMemberContact));
    end;

    internal procedure GetMemberPointBalance(): Decimal
    begin
        exit(POSMemberMgt.GetMemberBalance);
    end;

    internal procedure SetTransBenefitBuffer(var pTransDiscBenefitTmp: Record "LSC Trans. Disc. Benefit Entry" temporary)
    begin
        DiscLedgerMgt.SaveTransBenefitBuffer(pTransDiscBenefitTmp);
    end;

    internal procedure ClearTransBenefitBuffer()
    begin
        DiscLedgerMgt.ClearBenefitProcessFlag;
        DiscLedgerMgt.DelereTransBenefitBuffer;
    end;

    internal procedure GetTransBenefitBuffer(var pTransDiscBenefitTmp: Record "LSC Trans. Disc. Benefit Entry" temporary)
    begin
        DiscLedgerMgt.GetTransBenefitBuffer(pTransDiscBenefitTmp);
    end;

    internal procedure SetPaymentState(pPaymentState: Boolean)
    begin
        PaymentState := pPaymentState;
    end;

    internal procedure VoidBenefitLines(var pPosTrans: Record "LSC POS Transaction")
    var
        PosTransLine: Record "LSC POS Trans. Line";
        PosTransLine2: Record "LSC POS Trans. Line";
    begin
        ClearTransBenefitBuffer;

        PosTransLine.Reset;
        PosTransLine.SetCurrentKey("Receipt No.", "Entry Type", "Entry Status");
        PosTransLine.SetRange("Receipt No.", pPosTrans."Receipt No.");
        PosTransLine.SetRange("Entry Type", PosTransLine."Entry Type"::Item);
        PosTransLine.SetRange("Entry Status", PosTransLine."Entry Status"::" ");
        PosTransLine.SetRange("Benefit Item", true);
        if PosTransLine.FindSet then
            repeat
                if PosTransLine2.Get(PosTransLine."Receipt No.", PosTransLine."Line No.") then
                    PosTransLine2.VoidLine;
            until PosTransLine.Next = 0;
    end;

    internal procedure IsInPaymentState(): Boolean
    begin
        exit(PaymentState);
    end;

    procedure LoadOfferTables(pStartup: Boolean)
    begin
        if PosSession.FunctionalityProfile."Pre Load Offers" = PosSession.FunctionalityProfile."Pre Load Offers"::" " then
            exit;

        if PosSession.FunctionalityProfile."Pre Load Offers" = PosSession.FunctionalityProfile."Pre Load Offers"::"At Start" then
            LoadOfferTablesAtStart(pStartup)
        else
            LoadOfferTablesByDemand(pStartup);
    end;

    local procedure PeriodActive(ValidationPeriodID: Code[10]): Boolean
    var
        ValidationPeriod: Record "LSC Validation Period";
    begin
        if not ValidationPeriod.Get(ValidationPeriodID) then
            exit(true);

        if (ValidationPeriod."Starting Date" <> 0D) and (ValidationPeriod."Starting Date" > Today) then
            exit(false);

        if (ValidationPeriod."Ending Date" <> 0D) and (ValidationPeriod."Ending Date" < Today) then
            exit(false);

        exit(true);
    end;

    internal procedure GetActivePerDisc4Item(var TmpPeriodicDiscRec: Record "LSC Periodic Discount" temporary; ItemNo: Code[20])
    begin
        if PosSession.FunctionalityProfile."Pre Load Offers" = PosSession.FunctionalityProfile."Pre Load Offers"::"At Start" then
            GetDisc4ItemAtStart(TmpPeriodicDiscRec, ItemNo)
        else
            GetDisc4ItemByDemand(TmpPeriodicDiscRec, ItemNo)
    end;

    internal procedure GetActiveItemPointOfferLines(CurrLine: Record "LSC POS Trans. Line"; var TmpItemPointOfferLine: Record "LSC Periodic Discount Line" temporary; PromptAtScan: Boolean): Boolean
    var
        Item: Record Item;
        ItemSpecialGroupLink: Record "LSC Item/Special Group Link";
        PeriodicDiscountLine: Record "LSC Periodic Discount Line";
        TmpPerDiscount: Record "LSC Periodic Discount" temporary;
        TmpPerDiscount2: Record "LSC Periodic Discount" temporary;
        PeriodicDiscount: Record "LSC Periodic Discount";
        RecRef: RecordRef;
        FldRef: FieldRef;
        PromptAtScanLine: Boolean;
    begin
        if CurrLine."Entry Type" <> CurrLine."Entry Type"::Item then
            exit(false);

        if CurrLine."Entry Status" <> CurrLine."Entry Status"::" " then
            exit(false);

        Item.Get(CurrLine.Number);
        PromptAtScanLine := false;
        if PosSession.FunctionalityProfile."Pre Load Offers" > 0 then begin
            TmpPerDiscount2.Reset;
            TmpPerDiscount2.DeleteAll;
            GetActivePerDisc4Item(TmpPerDiscount2, CurrLine.Number);
            RecRef.GetTable(TmpPerDiscount2);
        end else
            RecRef.GetTable(PeriodicDiscount);

        RecRef.CurrentKeyIndex(2);
        FldRef := RecRef.Field(3);
        FldRef.SetRange(TmpPerDiscount2.Status::Enabled);
        FldRef := RecRef.Field(4);
        FldRef.SetRange(TmpPerDiscount2.Type::"Item Point");

        PeriodicDiscountLine.SetCurrentKey("Offer No.", Type, "No.", "Variant Code", "Unit of Measure", "Prod. Group Category");
        OnAfterSetKey_GetActiveItemPointOfferLines(PeriodicDiscountLine);
        if RecRef.FindSet then
            repeat
                RecRef.SetTable(TmpPerDiscount);

                if PeriodActive2(TmpPerDiscount."Validation Period ID") then begin
                    PeriodicDiscountLine.SetRange("Offer No.", TmpPerDiscount."No.");
                    PeriodicDiscountLine.SetRange(Type, PeriodicDiscountLine.Type::Item);
                    PeriodicDiscountLine.SetRange("No.", Item."No.");
                    OnBeforeCheckPeriodicDiscount_GetActiveItemPointOfferLines(PeriodicDiscountLine, Item);
                    if PeriodicDiscountLine.FindSet then
                        repeat
                            TmpItemPointOfferLine := PeriodicDiscountLine;
                            TmpItemPointOfferLine.Insert;
                            if TmpItemPointOfferLine."Prompt at Scan" then
                                PromptAtScanLine := true;
                        until PeriodicDiscountLine.Next = 0;

                    OnAfterCheckPeriodicDiscount_GetActiveItemPointOfferLines(PeriodicDiscountLine);

                    PeriodicDiscountLine.SetRange(Type, PeriodicDiscountLine.Type::"Product Group");
                    PeriodicDiscountLine.SetRange("No.", Item."LSC Retail Product Code");
                    OnBeforeCheckPeriodicDiscount_GetActiveItemPointOfferLines(PeriodicDiscountLine, Item);
                    if PeriodicDiscountLine.FindSet then
                        repeat
                            TmpItemPointOfferLine := PeriodicDiscountLine;
                            TmpItemPointOfferLine.Insert;
                            if TmpItemPointOfferLine."Prompt at Scan" then
                                PromptAtScanLine := true;
                        until PeriodicDiscountLine.Next = 0;

                    OnAfterCheckPeriodicDiscount_GetActiveItemPointOfferLines(PeriodicDiscountLine);

                    PeriodicDiscountLine.SetRange(Type, PeriodicDiscountLine.Type::"Item Category");
                    PeriodicDiscountLine.SetRange("No.", Item."Item Category Code");
                    OnBeforeCheckPeriodicDiscount_GetActiveItemPointOfferLines(PeriodicDiscountLine, Item);
                    if PeriodicDiscountLine.FindSet then
                        repeat
                            TmpItemPointOfferLine := PeriodicDiscountLine;
                            TmpItemPointOfferLine.Insert;
                            if TmpItemPointOfferLine."Prompt at Scan" then
                                PromptAtScanLine := true;
                        until PeriodicDiscountLine.Next = 0;

                    OnAfterCheckPeriodicDiscount_GetActiveItemPointOfferLines(PeriodicDiscountLine);

                    ItemSpecialGroupLink.SetRange("Item No.", Item."No.");
                    if ItemSpecialGroupLink.FindSet then
                        repeat
                            PeriodicDiscountLine.SetRange(Type, PeriodicDiscountLine.Type::"Special Group");
                            PeriodicDiscountLine.SetRange("No.", ItemSpecialGroupLink."Special Group Code");
                            OnBeforeCheckPeriodicDiscount_GetActiveItemPointOfferLines(PeriodicDiscountLine, Item);
                            if PeriodicDiscountLine.FindSet then
                                repeat
                                    TmpItemPointOfferLine := PeriodicDiscountLine;
                                    TmpItemPointOfferLine.Insert;
                                    if TmpItemPointOfferLine."Prompt at Scan" then
                                        PromptAtScanLine := true;
                                until PeriodicDiscountLine.Next = 0;
                        until ItemSpecialGroupLink.Next = 0;

                    OnAfterCheckPeriodicDiscount_GetActiveItemPointOfferLines(PeriodicDiscountLine);

                    PeriodicDiscountLine.SetRange(Type, PeriodicDiscountLine.Type::All);
                    PeriodicDiscountLine.SetRange("No.");
                    OnBeforeCheckPeriodicDiscount_GetActiveItemPointOfferLines(PeriodicDiscountLine, Item);
                    if PeriodicDiscountLine.FindSet then
                        repeat
                            TmpItemPointOfferLine := PeriodicDiscountLine;
                            TmpItemPointOfferLine.Insert;
                            if TmpItemPointOfferLine."Prompt at Scan" then
                                PromptAtScanLine := true;
                        until PeriodicDiscountLine.Next = 0;

                    OnAfterCheckPeriodicDiscount_GetActiveItemPointOfferLines(PeriodicDiscountLine);
                end;
                OnAfterPeriodActive2_GetActiveItemPointOfferLines(CurrLine, PeriodicDiscountLine, TmpPerDiscount, TmpItemPointOfferLine, PromptAtScan, PromptAtScanLine);
            until RecRef.Next = 0;

        if (PromptAtScan) and (not PromptAtScanLine) then
            exit(false);

        TmpItemPointOfferLine.Reset;

        exit(TmpItemPointOfferLine.FindFirst);
    end;

    internal procedure PointsUsedInTransaction(ExcludeLineNo: Integer): Decimal
    var
        MemberClubTemp: Record "LSC Member Club" temporary;
        TransLine: Record "LSC POS Trans. Line";
        TransDiscLine: Record "LSC POS Trans. Per. Disc. Type";
        POSTransaction: Codeunit "LSC POS Transaction";
        PointsUsed: Decimal;
    begin
        PointsUsed := 0;
        if not GetMemberClubInfo(MemberClubTemp) then
            exit(0);

        TransLine.SetRange("Receipt No.", POSTransaction.GetReceiptNo);
        TransLine.SetRange("Entry Status", TransLine."Entry Status"::" ");
        TransLine.SetRange("Entry Type", TransLine."Entry Type"::Payment);
        TransLine.SetRange(Number, MemberClubTemp."Member Point Tender Type");
        if TransLine.FindSet then
            repeat
                PointsUsed := PointsUsed + TransLine."Amount In Currency";
            until TransLine.Next = 0;

        TransDiscLine.SetRange("Receipt No.", POSTransaction.GetReceiptNo);
        TransDiscLine.SetRange("Periodic Disc. Type", TransDiscLine."Periodic Disc. Type"::"Item Point");
        TransDiscLine.SetFilter("Entry Status", '<>%1', TransDiscLine."Entry Status"::Voided);
        if ExcludeLineNo <> 0 then
            TransDiscLine.SetFilter("Line No.", '<>%1', ExcludeLineNo);
        PosTransDiscSetTableFilter(1, TransDiscLine);
        if PosTransDiscFindSetRec(1, TransDiscLine) then
            repeat
                PointsUsed := PointsUsed - TransDiscLine.Points;
            until PosTransDiscNextRec(1, 1, TransDiscLine) = 0;

        exit(PointsUsed);
    end;

    procedure PrepareInvLookup(var pCurrLine: Record "LSC POS Trans. Line"; pSerialLotLookup: Boolean; pLocationProfile: Code[30]; var pFilter: Code[20]): Boolean
    var
        Helper: Codeunit "LSC Helper";
        ErrorText: Text;
        TransServerLookup: Boolean;
        PosIsOnLine: Boolean;
    begin
        PosIsOnLine := PosSession.Terminal."Terminal Connection" = PosSession.Terminal."Terminal Connection"::OnLine;

        if pSerialLotLookup then begin
            if (PosIsOnLine) or (not PosSession.FunctionalityProfile."TS Inv. Lookup") then
                TransServerLookup := false
            else
                TransServerLookup := true;
        end else begin
            if PosSession.FunctionalityProfile."TS Inv. Lookup" then
                TransServerLookup := true
            else
                TransServerLookup := false;
        end;

        if pSerialLotLookup then begin  //Updating Inventory Lookup not needed, done before calling the form when Serial/Lot lookup.
            pCurrLine."Receipt No." := 'SL';
            pCurrLine."Store No." := POSSESSION.StoreNo;
        end else begin
            if TransServerLookup then begin
                if not TSUtil.GetItemInventoryLookupTable(pCurrLine.Number, pCurrLine."Variant Code", '', pLocationProfile, ErrorText) then
                    exit(false);
                pCurrLine."Store No." := POSSESSION.StoreNo;
            end else begin
                pCurrLine."Store No." := POSSESSION.StoreNo;
            end;

            if ItemTrack.IsItemSNTracking(pCurrLine.Number) or ItemTrack.IsItemLotTracking(pCurrLine.Number) then begin
                pCurrLine."Receipt No." := 'SL';
            end;
        end;

        pFilter := '';
        if TransServerLookup then
            pFilter := Helper.CatStr(pFilter, ';', '[TRANS]');
        if PosIsOnLine then
            pFilter := Helper.CatStr(pFilter, ';', '[ONLINE]');

        exit(true);
    end;

    internal procedure ClearQRCode(): Text[30]
    begin
        POSScanDataUtils.ClearQRCode;
    end;

    internal procedure LoadQRTextData(pQRCode: Text)
    begin
        POSScanDataUtils.LoadTextData(pQRCode);
    end;

    internal procedure QueueMobileLoyaltyQRCode(var pErrorMessage: Text): Boolean
    begin
        exit(POSScanDataUtils.QueueMobileLoyaltyQRCode(pErrorMessage));
    end;

    internal procedure QRCardNo(): Text[30]
    begin
        exit(POSScanDataUtils.QRCardNo);
    end;

    internal procedure GetCouponsFromQR(var pTmpMobileOfferQRCode: Record "LSC Mobile Loyalty QR Code" temporary)
    begin
        POSScanDataUtils.GetCouponsFromQR(pTmpMobileOfferQRCode);
    end;

    internal procedure ItemInQR(pItemNo: Code[20]; var pOfferNo: Code[20]): Boolean
    begin
        exit(POSScanDataUtils.ItemInQR(pItemNo, pOfferNo));
    end;

    procedure CheckValidEmailAddresses(var Recipients: Text): Boolean
    var
        MailManagement: Codeunit "Mail Management";
        TmpRecipients: Text;
    begin
        if Recipients = '' then
            exit(false);

        TmpRecipients := Recipients;
        while StrPos(TmpRecipients, ';') > 1 do begin
            if not MailManagement.CheckValidEmailAddress(CopyStr(TmpRecipients, 1, StrPos(TmpRecipients, ';') - 1)) then
                exit(false);
            TmpRecipients := CopyStr(TmpRecipients, StrPos(TmpRecipients, ';') + 1);
        end;
        if not MailManagement.CheckValidEmailAddress(TmpRecipients) then
            exit(false);
        exit(true);
    end;

    local procedure LoadOfferTablesAtStart(pStartup: Boolean)
    var
        PeriodicDiscount: Record "LSC Periodic Discount";
        PeriodicDiscountLine: Record "LSC Periodic Discount Line";
        PeriodicDiscParm: Record "LSC Periodic Discount";
        PeriodicDiscLineParm: Record "LSC Periodic Discount Line";
        QueryMgt: Codeunit "LSC POS Query Mgt";
        UseQuery: Boolean;
        IsHandled: Boolean;
    begin
        if not pStartup then
            if PosSession.FunctionalityProfile."Offer Load Interval In Min." <> 0 then
                if LastOfferLoadTime + (PosSession.FunctionalityProfile."Offer Load Interval In Min." * 60000) > CurrentDateTime then
                    exit;

        TmpPeriodicDiscountLine.Reset;
        TmpPeriodicDiscountLine.DeleteAll;
        TmpPreDiscAmountToTrigger.Reset;
        TmpPreDiscAmountToTrigger.DeleteAll;
        ValidationPeriodBuffer.Reset;
        ValidationPeriodBuffer.DeleteAll;

        OnBeforeLoadOfferTablesAtStart(PeriodicDiscount, TmpPreDiscAmountToTrigger, TmpPeriodicDiscountLine, IsHandled);
        if IsHandled then
            exit;

        UseQuery := QueryMgt.QueryAllowed;
        if UseQuery then begin
            QueryMgt.PeriodicDiscOpen(PeriodicDiscParm);
            while QueryMgt.PeriodicDiscRead(PeriodicDiscount) do begin
                if PeriodicDiscount."Amount to Trigger" <> 0 then begin
                    TmpPreDiscAmountToTrigger.Init;
                    TmpPreDiscAmountToTrigger."No." := PeriodicDiscount."No.";
                    if TmpPreDiscAmountToTrigger.Insert then;
                end;
                PeriodicDiscLineParm."Offer No." := PeriodicDiscount."No.";
                QueryMgt.PeriodicDiscLineOpen(PeriodicDiscLineParm);
                while QueryMgt.PeriodicDiscLineRead(PeriodicDiscountLine) do begin
                    TmpPeriodicDiscountLine := PeriodicDiscountLine;
                    TmpPeriodicDiscountLine."Header Type" := PeriodicDiscount.Type;
                    TmpPeriodicDiscountLine.Insert;
                end;
                QueryMgt.PeriodicDiscLineClose;
            end;
            QueryMgt.PeriodicDiscClose;
        end else begin
            PeriodicDiscount.SetCurrentKey(Status);
            PeriodicDiscount.SetRange(Status, PeriodicDiscount.Status::Enabled);
            OnAfterSetFilters_LoadOfferTablesAtStart(PeriodicDiscount);
            if PeriodicDiscount.FindSet then
                repeat
                    if PeriodActive2(PeriodicDiscount."Validation Period ID") then begin
                        if PeriodicDiscount."Amount to Trigger" <> 0 then begin
                            TmpPreDiscAmountToTrigger.Init;
                            TmpPreDiscAmountToTrigger."No." := PeriodicDiscount."No.";
                            if TmpPreDiscAmountToTrigger.Insert then;
                        end;
                        PeriodicDiscountLine.SetRange("Offer No.", PeriodicDiscount."No.");
                        if PeriodicDiscountLine.FindSet then
                            repeat
                                TmpPeriodicDiscountLine := PeriodicDiscountLine;
                                TmpPeriodicDiscountLine."Header Type" := PeriodicDiscount.Type;
                                TmpPeriodicDiscountLine.Insert;
                            until PeriodicDiscountLine.Next = 0;
                    end;
                until PeriodicDiscount.Next = 0;
        end;

        LastOfferLoadTime := CurrentDateTime;
    end;

    local procedure LoadOfferTablesByDemand(pStartup: Boolean)
    var
        PeriodicDiscount: Record "LSC Periodic Discount";
        PeriodicDiscParm: Record "LSC Periodic Discount";
        QueryMgt: Codeunit "LSC POS Query Mgt";
        UseQuery: Boolean;
    begin
        if not pStartup then
            if PosSession.FunctionalityProfile."Offer Load Interval In Min." <> 0 then
                if LastOfferLoadTime + (PosSession.FunctionalityProfile."Offer Load Interval In Min." * 60000) > CurrentDateTime then
                    exit;

        TmpPeriodicDiscountLine.Reset;
        TmpPeriodicDiscountLine.DeleteAll;
        TmpPreDiscAmountToTrigger.Reset;
        TmpPreDiscAmountToTrigger.DeleteAll;
        PreLoadDiscTmp.Reset;
        PreLoadDiscTmp.DeleteAll;
        PreLoadDiscLineTmp.Reset;
        PreLoadDiscLineTmp.DeleteAll;
        ValidationPeriodBuffer.Reset;
        ValidationPeriodBuffer.DeleteAll;

        UseQuery := QueryMgt.QueryAllowed;
        if UseQuery then begin
            QueryMgt.PeriodicDiscOpen(PeriodicDiscParm);
            while QueryMgt.PeriodicDiscRead(PeriodicDiscount) do begin
                if PeriodicDiscount."Amount to Trigger" <> 0 then begin
                    TmpPreDiscAmountToTrigger.Init;
                    TmpPreDiscAmountToTrigger."No." := PeriodicDiscount."No.";
                    if TmpPreDiscAmountToTrigger.Insert then;
                end;
                if not PreLoadDiscTmp.Get(PeriodicDiscount."No.") then begin
                    PreLoadDiscTmp.Init;
                    PreLoadDiscTmp := PeriodicDiscount;
                    PreLoadDiscTmp.Insert;
                end;
            end;
            QueryMgt.PeriodicDiscClose;
        end else begin
            PeriodicDiscount.SetCurrentKey(Status);
            PeriodicDiscount.SetRange(Status, PeriodicDiscount.Status::Enabled);
            OnAfterSetFilters_LoadOfferTablesByDemand(PeriodicDiscount);
            if PeriodicDiscount.FindSet then
                repeat
                    if PeriodActive2(PeriodicDiscount."Validation Period ID") then begin
                        if PeriodicDiscount."Amount to Trigger" <> 0 then begin
                            if not TmpPreDiscAmountToTrigger.Get(PeriodicDiscount."No.") then begin
                                TmpPreDiscAmountToTrigger.Init;
                                TmpPreDiscAmountToTrigger."No." := PeriodicDiscount."No.";
                                TmpPreDiscAmountToTrigger.Insert;
                            end;
                        end;
                        if not PreLoadDiscTmp.Get(PeriodicDiscount."No.") then begin
                            PreLoadDiscTmp.Init;
                            PreLoadDiscTmp := PeriodicDiscount;
                            PreLoadDiscTmp.Insert;
                        end;
                    end;
                until PeriodicDiscount.Next = 0;
        end;

        LastOfferLoadTime := CurrentDateTime;
    end;

    local procedure PeriodActive2(pValidationPeriodID: Code[10]): Boolean
    begin
        if ValidationPeriodBuffer.Get(pValidationPeriodID) then
            exit(ValidationPeriodBuffer."Time within Bounds")
        else begin
            if PeriodActive(pValidationPeriodID) then begin
                ValidationPeriodBuffer.Init;
                ValidationPeriodBuffer.ID := pValidationPeriodID;
                ValidationPeriodBuffer."Time within Bounds" := true;
                ValidationPeriodBuffer.Insert;
            end else begin
                ValidationPeriodBuffer.Init;
                ValidationPeriodBuffer.ID := pValidationPeriodID;
                ValidationPeriodBuffer."Time within Bounds" := false;
                ValidationPeriodBuffer.Insert;
            end;
            exit(ValidationPeriodBuffer."Time within Bounds");
        end;
    end;

    local procedure GetDisc4ItemAtStart(var TmpPeriodicDiscRec: Record "LSC Periodic Discount" temporary; ItemNo: Code[20])
    var
        Item: Record Item;
        PeriodicDiscount: Record "LSC Periodic Discount";
        ItemSpecialGroupLink: Record "LSC Item/Special Group Link";
    begin
        TmpPeriodicDiscRec.Reset;
        TmpPeriodicDiscRec.DeleteAll;
        if not Item.Get(ItemNo) then
            exit;

        TmpPreDiscAmountToTrigger.Reset;
        OnBeforeCheckTmpPreDiscAmountToTrigger_GetDisc4ItemAtStart(TmpPreDiscAmountToTrigger);
        if TmpPreDiscAmountToTrigger.FindSet then
            repeat
                if PeriodicDiscount.Get(TmpPreDiscAmountToTrigger."No.") then begin
                    TmpPeriodicDiscRec := PeriodicDiscount;
                    if TmpPeriodicDiscRec.Insert then;
                end;
            until TmpPreDiscAmountToTrigger.Next = 0;

        TmpPeriodicDiscountLine.Reset;
        TmpPeriodicDiscountLine.SetCurrentKey(Type, "No.");
        OnBeforeSetFilters_GetDisc4ItemAtStart(TmpPeriodicDiscountLine);
        TmpPeriodicDiscountLine.SetRange(Type, TmpPeriodicDiscountLine.Type::Item);
        TmpPeriodicDiscountLine.SetRange("No.", ItemNo);
        OnBeforeCheckPeriodicDiscount_GetDisc4ItemAtStart(TmpPeriodicDiscountLine, Item);
        if TmpPeriodicDiscountLine.FindSet then
            repeat
                if PeriodicDiscount.Get(TmpPeriodicDiscountLine."Offer No.") then begin
                    TmpPeriodicDiscRec := PeriodicDiscount;
                    if TmpPeriodicDiscRec.Insert then;
                end;
            until TmpPeriodicDiscountLine.Next = 0;

        OnAfterCheckPeriodicDiscount_GetDisc4ItemAtStart(TmpPeriodicDiscountLine);

        TmpPeriodicDiscountLine.SetRange(Type, TmpPeriodicDiscountLine.Type::"Product Group");
        TmpPeriodicDiscountLine.SetRange("No.", Item."LSC Retail Product Code");
        OnBeforeCheckPeriodicDiscount_GetDisc4ItemAtStart(TmpPeriodicDiscountLine, Item);
        if TmpPeriodicDiscountLine.FindSet then
            repeat
                if PeriodicDiscount.Get(TmpPeriodicDiscountLine."Offer No.") then begin
                    TmpPeriodicDiscRec := PeriodicDiscount;
                    if TmpPeriodicDiscRec.Insert then;
                end;
            until TmpPeriodicDiscountLine.Next = 0;

        OnAfterCheckPeriodicDiscount_GetDisc4ItemAtStart(TmpPeriodicDiscountLine);

        TmpPeriodicDiscountLine.SetRange(Type, TmpPeriodicDiscountLine.Type::"Item Category");
        TmpPeriodicDiscountLine.SetRange("No.", Item."Item Category Code");
        OnBeforeCheckPeriodicDiscount_GetDisc4ItemAtStart(TmpPeriodicDiscountLine, Item);
        if TmpPeriodicDiscountLine.FindSet then
            repeat
                if PeriodicDiscount.Get(TmpPeriodicDiscountLine."Offer No.") then begin
                    TmpPeriodicDiscRec := PeriodicDiscount;
                    if TmpPeriodicDiscRec.Insert then;
                end;
            until TmpPeriodicDiscountLine.Next = 0;

        OnAfterCheckPeriodicDiscount_GetDisc4ItemAtStart(TmpPeriodicDiscountLine);

        ItemSpecialGroupLink.SetRange("Item No.", ItemNo);
        if ItemSpecialGroupLink.FindSet then
            repeat
                TmpPeriodicDiscountLine.SetRange(Type, TmpPeriodicDiscountLine.Type::"Special Group");
                TmpPeriodicDiscountLine.SetRange("No.", ItemSpecialGroupLink."Special Group Code");
                OnBeforeCheckPeriodicDiscount_GetDisc4ItemAtStart(TmpPeriodicDiscountLine, Item);
                if TmpPeriodicDiscountLine.FindSet then
                    repeat
                        if PeriodicDiscount.Get(TmpPeriodicDiscountLine."Offer No.") then begin
                            TmpPeriodicDiscRec := PeriodicDiscount;
                            if TmpPeriodicDiscRec.Insert then;
                        end;
                    until TmpPeriodicDiscountLine.Next = 0;
            until ItemSpecialGroupLink.Next = 0;

        OnAfterCheckPeriodicDiscount_GetDisc4ItemAtStart(TmpPeriodicDiscountLine);

        TmpPeriodicDiscountLine.SetRange(Type, TmpPeriodicDiscountLine.Type::All);
        TmpPeriodicDiscountLine.SetRange("No.");
        OnBeforeCheckPeriodicDiscount_GetDisc4ItemAtStart(TmpPeriodicDiscountLine, Item);
        if TmpPeriodicDiscountLine.FindSet then
            repeat
                if PeriodicDiscount.Get(TmpPeriodicDiscountLine."Offer No.") then begin
                    TmpPeriodicDiscRec := PeriodicDiscount;
                    if TmpPeriodicDiscRec.Insert then;
                end;
            until TmpPeriodicDiscountLine.Next = 0;

        OnAfterCheckPeriodicDiscount_GetDisc4ItemAtStart(TmpPeriodicDiscountLine);

        TmpPeriodicDiscountLine.Reset;
        OnAfterGetDisc4ItemAtStart(TmpPeriodicDiscountLine, TmpPeriodicDiscRec, ItemNo);
    end;

    local procedure GetDisc4ItemByDemand(var TmpPeriodicDiscRec: Record "LSC Periodic Discount" temporary; ItemNo: Code[20])
    var
        Item: Record Item;
        PeriodicDiscount: Record "LSC Periodic Discount";
        ItemSpecialGroupLink: Record "LSC Item/Special Group Link";
        PeriodicDiscLineParm: Record "LSC Periodic Discount Line";
        LastLineNo: Integer;
    begin
        TmpPeriodicDiscRec.Reset;
        TmpPeriodicDiscRec.DeleteAll;
        if not Item.Get(ItemNo) then
            exit;

        TmpPreDiscAmountToTrigger.Reset;
        OnBeforeCheckTmpPreDiscAmountToTrigger_GetDisc4ItemByDemand(TmpPreDiscAmountToTrigger);
        if TmpPreDiscAmountToTrigger.FindSet then
            repeat
                if PeriodicDiscount.Get(TmpPreDiscAmountToTrigger."No.") then begin
                    if not TmpPeriodicDiscRec.Get(PeriodicDiscount."No.") then begin
                        TmpPeriodicDiscRec.Init;
                        TmpPeriodicDiscRec := PeriodicDiscount;
                        TmpPeriodicDiscRec.Insert;
                    end;
                end;
            until TmpPreDiscAmountToTrigger.Next = 0;

        PreLoadDiscLineTmp.Reset;
        if PreLoadDiscLineTmp.FindLast then
            LastLineNo := PreLoadDiscLineTmp."Line No."
        else
            LastLineNo := 0;

        PeriodicDiscLineParm.Type := PreLoadDiscLineTmp.Type::Item;
        PeriodicDiscLineParm."No." := ItemNo;
        PreLoadDicLines(PeriodicDiscLineParm, LastLineNo);
        OnAfterPreLoadDicLines_GetDisc4ItemByDemand(ItemNo, LastLineNo, PeriodicDiscLineParm);

        PeriodicDiscLineParm.Type := PreLoadDiscLineTmp.Type::"Product Group";
        PeriodicDiscLineParm."No." := Item."LSC Retail Product Code";
        PreLoadDicLines(PeriodicDiscLineParm, LastLineNo);
        OnAfterPreLoadDicLines_GetDisc4ItemByDemand(ItemNo, LastLineNo, PeriodicDiscLineParm);

        PeriodicDiscLineParm.Type := PreLoadDiscLineTmp.Type::"Item Category";
        PeriodicDiscLineParm."No." := Item."Item Category Code";
        PreLoadDicLines(PeriodicDiscLineParm, LastLineNo);
        OnAfterPreLoadDicLines_GetDisc4ItemByDemand(ItemNo, LastLineNo, PeriodicDiscLineParm);

        ItemSpecialGroupLink.SetRange("Item No.", ItemNo);
        if ItemSpecialGroupLink.FindSet then
            repeat
                PeriodicDiscLineParm.Type := PreLoadDiscLineTmp.Type::"Special Group";
                PeriodicDiscLineParm."No." := ItemSpecialGroupLink."Special Group Code";
                PreLoadDicLines(PeriodicDiscLineParm, LastLineNo);
                OnAfterPreLoadDicLines_GetDisc4ItemByDemand(ItemNo, LastLineNo, PeriodicDiscLineParm);
            until ItemSpecialGroupLink.Next = 0;

        PeriodicDiscLineParm.Type := PreLoadDiscLineTmp.Type::All;
        PeriodicDiscLineParm."No." := '';
        PreLoadDicLines(PeriodicDiscLineParm, LastLineNo);
        OnAfterPreLoadDicLines_GetDisc4ItemByDemand(ItemNo, LastLineNo, PeriodicDiscLineParm);

        TmpPeriodicDiscountLine.Reset;
        TmpPeriodicDiscountLine.SetCurrentKey(Type, "No.");
        OnBeforeSetFilters_GetDisc4ItemByDemand(TmpPeriodicDiscountLine);
        TmpPeriodicDiscountLine.SetRange(Type, TmpPeriodicDiscountLine.Type::Item);
        TmpPeriodicDiscountLine.SetRange("No.", ItemNo);
        OnBeforeCheckPeriodicDiscount_GetDisc4ItemByDemand(TmpPeriodicDiscountLine, Item);
        if TmpPeriodicDiscountLine.FindSet then
            repeat
                if PeriodicDiscount.Get(TmpPeriodicDiscountLine."Offer No.") then begin
                    if not TmpPeriodicDiscRec.Get(PeriodicDiscount."No.") then begin
                        TmpPeriodicDiscRec.Init;
                        TmpPeriodicDiscRec := PeriodicDiscount;
                        TmpPeriodicDiscRec.Insert;
                    end;
                end;
            until TmpPeriodicDiscountLine.Next = 0;

        OnAfterCheckPeriodicDiscount_GetDisc4ItemByDemand(TmpPeriodicDiscountLine);

        TmpPeriodicDiscountLine.SetRange(Type, TmpPeriodicDiscountLine.Type::"Product Group");
        TmpPeriodicDiscountLine.SetRange("No.", Item."LSC Retail Product Code");
        OnBeforeCheckPeriodicDiscount_GetDisc4ItemByDemand(TmpPeriodicDiscountLine, Item);
        if TmpPeriodicDiscountLine.FindSet then
            repeat
                if PeriodicDiscount.Get(TmpPeriodicDiscountLine."Offer No.") then begin
                    if not TmpPeriodicDiscRec.Get(PeriodicDiscount."No.") then begin
                        TmpPeriodicDiscRec.Init;
                        TmpPeriodicDiscRec := PeriodicDiscount;
                        TmpPeriodicDiscRec.Insert;
                    end;
                end;
            until TmpPeriodicDiscountLine.Next = 0;

        OnAfterCheckPeriodicDiscount_GetDisc4ItemByDemand(TmpPeriodicDiscountLine);

        TmpPeriodicDiscountLine.SetRange(Type, TmpPeriodicDiscountLine.Type::"Item Category");
        TmpPeriodicDiscountLine.SetRange("No.", Item."Item Category Code");
        OnBeforeCheckPeriodicDiscount_GetDisc4ItemByDemand(TmpPeriodicDiscountLine, Item);
        if TmpPeriodicDiscountLine.FindSet then
            repeat
                if PeriodicDiscount.Get(TmpPeriodicDiscountLine."Offer No.") then begin
                    if not TmpPeriodicDiscRec.Get(PeriodicDiscount."No.") then begin
                        TmpPeriodicDiscRec.Init;
                        TmpPeriodicDiscRec := PeriodicDiscount;
                        TmpPeriodicDiscRec.Insert;
                    end;
                end;
            until TmpPeriodicDiscountLine.Next = 0;

        OnAfterCheckPeriodicDiscount_GetDisc4ItemByDemand(TmpPeriodicDiscountLine);

        ItemSpecialGroupLink.SetRange("Item No.", ItemNo);
        if ItemSpecialGroupLink.FindSet then
            repeat
                TmpPeriodicDiscountLine.SetRange(Type, TmpPeriodicDiscountLine.Type::"Special Group");
                TmpPeriodicDiscountLine.SetRange("No.", ItemSpecialGroupLink."Special Group Code");
                OnBeforeCheckPeriodicDiscount_GetDisc4ItemByDemand(TmpPeriodicDiscountLine, Item);
                if TmpPeriodicDiscountLine.FindSet then
                    repeat
                        if PeriodicDiscount.Get(TmpPeriodicDiscountLine."Offer No.") then begin
                            if not TmpPeriodicDiscRec.Get(PeriodicDiscount."No.") then begin
                                TmpPeriodicDiscRec.Init;
                                TmpPeriodicDiscRec := PeriodicDiscount;
                                TmpPeriodicDiscRec.Insert;
                            end;
                        end;
                    until TmpPeriodicDiscountLine.Next = 0;
            until ItemSpecialGroupLink.Next = 0;

        OnAfterCheckPeriodicDiscount_GetDisc4ItemByDemand(TmpPeriodicDiscountLine);

        TmpPeriodicDiscountLine.SetRange(Type, TmpPeriodicDiscountLine.Type::All);
        TmpPeriodicDiscountLine.SetRange("No.");
        OnBeforeCheckPeriodicDiscount_GetDisc4ItemByDemand(TmpPeriodicDiscountLine, Item);
        if TmpPeriodicDiscountLine.FindSet then
            repeat
                if PeriodicDiscount.Get(TmpPeriodicDiscountLine."Offer No.") then begin
                    if not TmpPeriodicDiscRec.Get(PeriodicDiscount."No.") then begin
                        TmpPeriodicDiscRec.Init;
                        TmpPeriodicDiscRec := PeriodicDiscount;
                        TmpPeriodicDiscRec.Insert;
                    end;
                end;
            until TmpPeriodicDiscountLine.Next = 0;

        OnAfterCheckPeriodicDiscount_GetDisc4ItemByDemand(TmpPeriodicDiscountLine);

        TmpPeriodicDiscountLine.Reset;

        OnAfterGetDisc4ItemByDemand(TmpPeriodicDiscountLine, TmpPeriodicDiscRec, ItemNo);
    end;

    procedure PreLoadDicLines(var pPeriodicDiscLineParm: Record "LSC Periodic Discount Line"; var pLastLineNo: Integer)
    var
        IsHandled: Boolean;
    begin
        OnBeforePreLoadDicLines(pPeriodicDiscLineParm, pLastLineNo, PreLoadDiscTmp, PreLoadDiscLineTmp, TmpPeriodicDiscountLine, IsHandled);
        if IsHandled then
            exit;

        PreLoadDicLinesEx(pPeriodicDiscLineParm, pLastLineNo);
    end;

    local procedure PreLoadDicLinesEx(var pPeriodicDiscLineParm: Record "LSC Periodic Discount Line"; var pLastLineNo: Integer)
    var
        PeriodicDiscountLine: Record "LSC Periodic Discount Line";
        PeriodicDiscLineParm: Record "LSC Periodic Discount Line";
        QueryMgt: Codeunit "LSC POS Query Mgt";
        UseQuery: Boolean;
    begin
        PreLoadDiscLineTmp.Reset;
        PreLoadDiscLineTmp.SetCurrentKey(Type, "No.");
        OnAfterSetKey_PreLoadDicLines(PreLoadDiscLineTmp);
        PreLoadDiscLineTmp.SetRange(Type, pPeriodicDiscLineParm.Type);
        PreLoadDiscLineTmp.SetRange("No.", pPeriodicDiscLineParm."No.");
        if not PreLoadDiscLineTmp.FindSet then begin
            UseQuery := QueryMgt.QueryAllowed;
            PreLoadDiscTmp.Reset;
            if PreLoadDiscTmp.FindSet then
                repeat
                    if UseQuery then begin
                        PeriodicDiscLineParm."Offer No." := PreLoadDiscTmp."No.";
                        PeriodicDiscLineParm.Type := pPeriodicDiscLineParm.Type;
                        PeriodicDiscLineParm."No." := pPeriodicDiscLineParm."No.";
                        OnBeforePeriodicDiscLineOpen_PreLoadDicLines(PeriodicDiscLineParm, pPeriodicDiscLineParm);
                        QueryMgt.PeriodicDiscLineOpen(PeriodicDiscLineParm);
                        while QueryMgt.PeriodicDiscLineRead(PeriodicDiscountLine) do begin
                            TmpPeriodicDiscountLine := PeriodicDiscountLine;
                            TmpPeriodicDiscountLine."Header Type" := PreLoadDiscTmp.Type;
                            TmpPeriodicDiscountLine.Insert;
                        end;
                        QueryMgt.PeriodicDiscLineClose;
                    end else begin
                        OnBeforeSetPeriodicDiscountLineFilters_PreLoadDicLines(PeriodicDiscountLine);
                        PeriodicDiscountLine.SetRange("Offer No.", PreLoadDiscTmp."No.");
                        PeriodicDiscountLine.SetRange(Type, pPeriodicDiscLineParm.Type);
                        PeriodicDiscountLine.SetRange("No.", pPeriodicDiscLineParm."No.");
                        OnAfterSetPeriodicDiscountLineFilters_PreLoadDicLines(PeriodicDiscountLine);
                        if pPeriodicDiscLineParm.Type = pPeriodicDiscLineParm.Type::All then
                            PeriodicDiscountLine.SetRange("No.");
                        if PeriodicDiscountLine.FindSet then
                            repeat
                                TmpPeriodicDiscountLine := PeriodicDiscountLine;
                                TmpPeriodicDiscountLine."Header Type" := PreLoadDiscTmp.Type;
                                TmpPeriodicDiscountLine.Insert;
                            until PeriodicDiscountLine.Next = 0;
                    end;
                until PreLoadDiscTmp.Next = 0;

            pLastLineNo := pLastLineNo + 1;
            PreLoadDiscLineTmp.Init;
            PreLoadDiscLineTmp."Line No." := pLastLineNo;
            PreLoadDiscLineTmp.Type := pPeriodicDiscLineParm.Type;
            PreLoadDiscLineTmp."No." := pPeriodicDiscLineParm."No.";
            PreLoadDiscLineTmp.Insert;
        end;
    end;

    procedure ClearOfferBuffer()
    begin
        POSOfferMgt.ClearOfferBuffer;
    end;

    procedure AddPosTransLineOffers(var pPosTransLine: Record "LSC POS Trans. Line")
    begin
        POSOfferMgt.AddPosTransLineOffers(pPosTransLine);
    end;

    internal procedure GetPosTransLineOffers(var pPosTransLine: Record "LSC POS Trans. Line"; var pOfferCalcBuffer: Record "LSC Offer Pos Calculation" temporary): Boolean
    begin
        exit(POSOfferMgt.GetPosTransLineOffers(pPosTransLine, pOfferCalcBuffer));
    end;

    procedure ClearPosTransLineOffers(var pPosTransLine: Record "LSC POS Trans. Line")
    begin
        POSOfferMgt.ClearPosTransLineOffers(pPosTransLine);
    end;

    procedure PosTransDiscLoadData(pReceiptNo: Code[20]; pTempAccess: Boolean)
    begin
        PosTransDisc.LoadData(pReceiptNo, pTempAccess);
    end;

    procedure PosTransDiscFlushDataUpdate()
    begin
        PosTransDisc.FlushDataUpdate;
    end;

    procedure PosTransDiscGetRec(var pPosTransDisc: Record "LSC POS Trans. Per. Disc. Type"): Boolean
    begin
        exit(PosTransDisc.GetRec(pPosTransDisc));
    end;

    procedure PosTransDiscSetTableFilter(pSetIndex: Integer; var pPosTransDisc: Record "LSC POS Trans. Per. Disc. Type")
    begin
        PosTransDisc.SetTableFilter(pSetIndex, pPosTransDisc);
    end;

    procedure PosTransDiscFindRec(pSetIndex: Integer; pWhich: Text[1024]; var pPosTransDisc: Record "LSC POS Trans. Per. Disc. Type"): Boolean
    begin
        exit(PosTransDisc.FindRec(pSetIndex, pWhich, pPosTransDisc));
    end;

    procedure PosTransDiscFindFirstRec(pSetIndex: Integer; var pPosTransDisc: Record "LSC POS Trans. Per. Disc. Type"): Boolean
    begin
        exit(PosTransDisc.FindFirstRec(pSetIndex, pPosTransDisc));
    end;

    procedure PosTransDiscFindLastRec(pSetIndex: Integer; var pPosTransDisc: Record "LSC POS Trans. Per. Disc. Type"): Boolean
    begin
        exit(PosTransDisc.FindLastRec(pSetIndex, pPosTransDisc));
    end;

    procedure PosTransDiscFindSetRec(pSetIndex: Integer; var pPosTransDisc: Record "LSC POS Trans. Per. Disc. Type"): Boolean
    begin
        exit(PosTransDisc.FindSetRec(pSetIndex, pPosTransDisc));
    end;

    procedure PosTransDiscNextRec(pSetIndex: Integer; pSteps: Integer; var pPosTransDisc: Record "LSC POS Trans. Per. Disc. Type"): Integer
    begin
        exit(PosTransDisc.NextRec(pSetIndex, pSteps, pPosTransDisc));
    end;

    procedure PosTransDiscIsEmptyRec(pSetIndex: Integer): Boolean
    begin
        exit(PosTransDisc.IsEmptyRec(pSetIndex));
    end;

    procedure PosTransDiscCountRec(pSetIndex: Integer): Integer
    begin
        exit(PosTransDisc.CountRec(pSetIndex));
    end;

    procedure PosTransDiscUpdateRec(var pPosTransDisc: Record "LSC POS Trans. Per. Disc. Type")
    begin
        PosTransDisc.UpdateRec(pPosTransDisc);
    end;

    procedure PosTransDiscDeleteRec(var pPosTransDisc: Record "LSC POS Trans. Per. Disc. Type")
    begin
        PosTransDisc.DeleteRec(pPosTransDisc);
    end;

    procedure PosTransDiscDeleteAllRec(pSetIndex: Integer)
    begin
        PosTransDisc.DeleteAllRec(pSetIndex);
    end;

    procedure PosTransDiscLoad(pReceiptNo: Code[20])
    begin
        if pReceiptNo = '' then
            PosTransDiscLoadData(pReceiptNo, false)
        else
            PosTransDiscLoadData(pReceiptNo, true);
    end;

    procedure PosTransDiscFlush()
    begin
        PosTransDiscFlushDataUpdate;
    end;

    procedure PosTransDiscDataHasBeenLoaded(): Boolean
    begin
        exit(PosTransDisc.DataHasBeenLoaded);
    end;

    internal procedure QueueHospLoyalty(var pErrorMessage: Text): Boolean
    begin
        exit(POSScanDataUtils.QueueHospLoyalty(pErrorMessage));
    end;

    internal procedure GetHospLoyalty(var pHospLoyalty: Record "LSC Hosp. Loyalty XML Code" temporary): Boolean
    begin
        exit(POSScanDataUtils.GetHospLoyalty(pHospLoyalty));
    end;

    procedure GetCustomerOrder(DocumentStatus: code[20]; DocumentID: Code[20]; var CustomerOrderHeaderTemp: Record "LSC Customer Order Header" temporary; var CustomerOrderLineTemp: Record "LSC Customer Order Line" temporary; var CustomerOrderDiscountLineTemp: Record "LSC CO Discount Line" temporary; var CustomerOrderPaymentTemp: Record "LSC Customer Order Payment" temporary; var ErrorText: Text): Boolean
    var
        POSDataEntryTemp: Record "LSC POS Data Entry" temporary;
    begin
        exit(GetCustomerOrder(DocumentStatus, DocumentID, CustomerOrderHeaderTemp, CustomerOrderLineTemp, CustomerOrderDiscountLineTemp, CustomerOrderPaymentTemp, ErrorText, POSDataEntryTemp));
    end;

    procedure GetCustomerOrder(DocumentStatus: code[20]; DocumentID: Code[20]; var CustomerOrderHeaderTemp: Record "LSC Customer Order Header" temporary; var CustomerOrderLineTemp: Record "LSC Customer Order Line" temporary; var CustomerOrderDiscountLineTemp: Record "LSC CO Discount Line" temporary; var CustomerOrderPaymentTemp: Record "LSC Customer Order Payment" temporary; var ErrorText: Text; var POSDataEntryTemp: Record "LSC POS Data Entry" temporary): Boolean
    //Option TO_PICK,TO_COLLECT,TO_PUT_BACK,LOOKUP,TO_RECEIVE,VOIDCOLLECT,CANCEL
    var
        SalesShipmentHeaderTemp: Record "Sales Shipment Header" temporary;
        SalesShipmentLineTemp: Record "Sales Shipment Line" temporary;
        GeneralCommentTemp: Record "LSC Retail Comment Line" temporary;
        DeliveryCommentTemp: Record "LSC Retail Comment Line" temporary;
        CustomerOrderGetV3Utils: Codeunit LSCCustomerOrderGetV3Utils;
        ResponseCode: Code[30];
        PointsEarned: Decimal;
        PointsUsed: Decimal;
        IsHandled: Boolean;
    begin
        OnBeforeGetCustomerOrder(DocumentStatus, DocumentID, CustomerOrderHeaderTemp, CustomerOrderLineTemp, CustomerOrderDiscountLineTemp, CustomerOrderPaymentTemp, ErrorText, IsHandled);
        if IsHandled then
            exit(ErrorText = '');
        CustomerOrderGetV3Utils.SetPosFunctionalityProfile(PosSession.FunctionalityProfile."Profile ID");
        CustomerOrderGetV3Utils.SendRequest(DocumentStatus, DocumentID, POSSESSION.TerminalNo, CustomerOrderHeaderTemp, CustomerOrderLineTemp, CustomerOrderDiscountLineTemp, CustomerOrderPaymentTemp, SalesShipmentHeaderTemp, SalesShipmentLineTemp, GeneralCommentTemp, DeliveryCommentTemp, ResponseCode, ErrorText, PointsEarned, PointsUsed, POSDataEntryTemp);
        CustomerOrderGetV3Utils.SetCommunicationError(ResponseCode, ErrorText);
        // Do a Find on all temp records to make sure that they are available for later processes that do not issue a find.
        PopulateCustomerOrderTempTables(CustomerOrderHeaderTemp, CustomerOrderLineTemp, CustomerOrderDiscountLineTemp, CustomerOrderPaymentTemp, SalesShipmentHeaderTemp, SalesShipmentLineTemp, GeneralCommentTemp, DeliveryCommentTemp, POSDataEntryTemp);
        exit(ErrorText = '');
    end;

    local procedure PopulateCustomerOrderTempTables(var CustomerOrderHeaderTemp: Record "LSC Customer Order Header" temporary; var CustomerOrderLineTemp: Record "LSC Customer Order Line" temporary; var CustomerOrderDiscountLineTemp: Record "LSC CO Discount Line" temporary; var CustomerOrderPaymentTemp: Record "LSC Customer Order Payment" temporary; var SalesShipmentHeaderTemp: Record "Sales Shipment Header" temporary; var SalesShipmentLineTemp: Record "Sales Shipment Line" temporary; var GeneralCommentTemp: Record "LSC Retail Comment Line" temporary; var DeliveryCommentTemp: Record "LSC Retail Comment Line" temporary; var POSDataEntryTemp: Record "LSC POS Data Entry" temporary)
    begin
        // Do a Find on all temp records to make sure that they are available for later processes that do not issue a find.
        CustomerOrderHeaderTemp.Reset();
        if CustomerOrderHeaderTemp.FindFirst() then;
        CustomerOrderLineTemp.Reset();
        if CustomerOrderLineTemp.FindFirst() then;
        CustomerOrderDiscountLineTemp.Reset();
        if CustomerOrderDiscountLineTemp.FindFirst() then;
        CustomerOrderPaymentTemp.Reset();
        if CustomerOrderPaymentTemp.FindFirst() then;
        SalesShipmentHeaderTemp.Reset();
        if SalesShipmentHeaderTemp.FindFirst() then;
        SalesShipmentLineTemp.Reset();
        if SalesShipmentLineTemp.FindFirst() then;
        GeneralCommentTemp.Reset();
        if GeneralCommentTemp.FindFirst() then;
        DeliveryCommentTemp.Reset();
        if DeliveryCommentTemp.FindFirst() then;
        POSDataEntryTemp.Reset();
        if POSDataEntryTemp.FindFirst() then;
    end;

    procedure GetCustomerOrder(DocumentStatus: code[20]; DocumentID: Code[20]; var CustomerOrderHeaderTemp: Record "LSC Customer Order Header" temporary; var CustomerOrderLineTemp: Record "LSC Customer Order Line" temporary; var CustomerOrderDiscountLineTemp: Record "LSC CO Discount Line" temporary; var CustomerOrderPaymentTemp: Record "LSC Customer Order Payment" temporary; var SalesShipmentHeaderTemp: Record "Sales Shipment Header" temporary; var SalesShipmentLineTemp: Record "Sales Shipment Line" temporary; var GeneralCommentTemp: Record "LSC Retail Comment Line" temporary; var DeliveryCommentTemp: Record "LSC Retail Comment Line" temporary; var ErrorText: Text): Boolean
    var
        POSDataEntryTemp: Record "LSC POS Data Entry" temporary;
    begin
        exit(GetCustomerOrder(DocumentStatus, DocumentID, CustomerOrderHeaderTemp, CustomerOrderLineTemp, CustomerOrderDiscountLineTemp, CustomerOrderPaymentTemp, SalesShipmentHeaderTemp, SalesShipmentLineTemp, GeneralCommentTemp, DeliveryCommentTemp, ErrorText, POSDataEntryTemp));
    end;

    procedure GetCustomerOrder(DocumentStatus: code[20]; DocumentID: Code[20]; var CustomerOrderHeaderTemp: Record "LSC Customer Order Header" temporary; var CustomerOrderLineTemp: Record "LSC Customer Order Line" temporary; var CustomerOrderDiscountLineTemp: Record "LSC CO Discount Line" temporary; var CustomerOrderPaymentTemp: Record "LSC Customer Order Payment" temporary; var SalesShipmentHeaderTemp: Record "Sales Shipment Header" temporary; var SalesShipmentLineTemp: Record "Sales Shipment Line" temporary; var GeneralCommentTemp: Record "LSC Retail Comment Line" temporary; var DeliveryCommentTemp: Record "LSC Retail Comment Line" temporary; var ErrorText: Text; var POSDataEntryTemp: Record "LSC POS Data Entry" temporary): Boolean
    //Option TO_PICK,TO_COLLECT,TO_PUT_BACK,LOOKUP,TO_RECEIVE,VOIDCOLLECT,CANCEL
    var
        CustomerOrderGetV3Utils: Codeunit LSCCustomerOrderGetV3Utils;
        ResponseCode: Code[30];
        PointsEarned: Decimal;
        PointsUsed: Decimal;
    begin
        CustomerOrderGetV3Utils.SetPosFunctionalityProfile(PosSession.FunctionalityProfile."Profile ID");
        CustomerOrderGetV3Utils.SendRequest(DocumentStatus, DocumentID, POSSESSION.TerminalNo, CustomerOrderHeaderTemp, CustomerOrderLineTemp, CustomerOrderDiscountLineTemp, CustomerOrderPaymentTemp, SalesShipmentHeaderTemp, SalesShipmentLineTemp, GeneralCommentTemp, DeliveryCommentTemp, ResponseCode, ErrorText, PointsEarned, PointsUsed, POSDataEntryTemp);
        CustomerOrderGetV3Utils.SetCommunicationError(ResponseCode, ErrorText);
        exit(ErrorText = '');
    end;

    procedure GetCustomerOrderPutBack(StoreNo: Code[20]; var PostedCustomerOrderLineTemp: Record "LSC Posted Customer Order Line" temporary; var ErrorText: Text): Boolean
    var
        COGetPutBackItemsUtils: Codeunit LSCCOGetPutBackItemsUtils;
        ResponseCode: Code[30];
    begin
        COGetPutBackItemsUtils.SetPosFunctionalityProfile(PosSession.FunctionalityProfile."Profile ID");
        COGetPutBackItemsUtils.SendRequest(StoreNo, PostedCustomerOrderLineTemp, ResponseCode, ErrorText);
        COGetPutBackItemsUtils.SetCommunicationError(ResponseCode, ErrorText);
        exit(ErrorText = '');
    end;

    [Obsolete('Use UpdateOrder in codeunit CO POS Functions instead', '26.0')]
    procedure UpdateCustomerOrder(DocId: Code[20]; var COLineTemp: Record "LSC Customer Order Line" temporary; var COStatusLogTemp: Record "LSC Customer Order Status Log" temporary; var SalesShipmentHeaderTemp: Record "Sales Shipment Header" temporary; var ErrorText: Text)
    var
        COPaymentTemp: Record "LSC Customer Order Payment" temporary;  //Dummy
        CustomerOrderUpdateV4Utils: Codeunit LSCCustomerOrderUpdateV4Utils;
        ResponseCode: Code[30];
        WebPreAuthNotAuthorized: Boolean; //Dummy
    begin
        CustomerOrderUpdateV4Utils.SetPosFunctionalityProfile(PosSession.FunctionalityProfile."Profile ID");
        CustomerOrderUpdateV4Utils.SendRequest(DocId, POSSESSION.TerminalNo, COLineTemp, COPaymentTemp, SalesShipmentHeaderTemp, COStatusLogTemp, false, WebPreAuthNotAuthorized, ResponseCode, ErrorText);
        CustomerOrderUpdateV4Utils.SetCommunicationError(ResponseCode, ErrorText);
    end;

    internal procedure UpdateCustomerOrderPutBack(var PostedCOLineTemp: Record "LSC Posted Customer Order Line"; var ErrorText: Text)
    var
        COPutbackUpdateUtils: Codeunit LSCCOPutbackUpdateUtils;
        ResponseCode: Code[30];
    begin
        COPutbackUpdateUtils.SetPosFunctionalityProfile(PosSession.FunctionalityProfile."Profile ID");
        COPutbackUpdateUtils.SendRequest(PostedCOLineTemp, ResponseCode, ErrorText);
        COPutbackUpdateUtils.SetCommunicationError(ResponseCode, ErrorText);
    end;

    internal procedure GetCustomerOrderStatus(CustomerOrderDocumentID: Code[20]; var StatusLogTemp: Record "LSC Customer Order Status Log" temporary; var StatusLineLogTemp: Record "LSC Customer Order Status Log" temporary; var ErrorText: Text): Boolean
    var
        CustomerOrderStatusUtils: Codeunit LSCCustomerOrderStatusUtilsV2;
        ResponseCode: Code[30];
    begin
        CustomerOrderStatusUtils.SetPosFunctionalityProfile(PosSession.FunctionalityProfile."Profile ID");
        CustomerOrderStatusUtils.SendRequest(CustomerOrderDocumentID, StatusLogTemp, StatusLineLogTemp, ResponseCode, ErrorText);
        CustomerOrderStatusUtils.SetCommunicationError(ResponseCode, ErrorText);
        exit(ErrorText = '');
    end;

    internal procedure QueueCOQRCode(var pErrorMessage: Text): Boolean
    begin
        exit(POSScanDataUtils.QueueCOQRCode(pErrorMessage));
    end;

    internal procedure GetCODataFromQR(var pDocStatus: Option "To Pick","To Collect"; var pDocumentId: Code[40]): Boolean
    begin
        exit(POSScanDataUtils.GetCODataFromQR(pDocStatus, pDocumentId));
    end;

    procedure QueueSPGQRCode(var pErrorMessage: Text): Boolean
    begin
        exit(POSScanDataUtils.QueueSPGQRCode(pErrorMessage));
    end;

    internal procedure GetSPGDataFromQR(var pDocumentId: Code[20]): Boolean
    begin
        exit(POSScanDataUtils.GetSPGDataFromQR(pDocumentId));
    end;

    internal procedure GetActiveRetailMessageList(UserName_p: Code[50]; StoreNo_p: Code[10]; PosTerminalNo_p: Code[10]; StaffNo_p: Code[20]; var RetailMessageHeaderTemp_p: Record "LSC Retail Message Header" temporary; var ErrorText_p: Text): Boolean
    var
        RetailMessageGetActiveListUtil: Codeunit LSCRetailMSGGetActiveListUtil;
        ProcessCode: Code[30];
        ErrorText: Text;
    begin
        ErrorText_p := '';
        POSSESSION.SetValue("LSC POS Tag"::"TS_ERROR", '');
        RetailMessageGetActiveListUtil.SetPosFunctionalityProfile(PosSession.FunctionalityProfile."Profile ID");
        RetailMessageGetActiveListUtil.SendRequest(UserName_p, StoreNo_p, PosTerminalNo_p, StaffNo_p, RetailMessageHeaderTemp_p, ProcessCode, ErrorText);
        if ErrorText <> '' then begin
            POSSESSION.SetValue("LSC POS Tag"::"TS_ERROR", LSHelper.Trim(ErrorText, 250));
            ErrorText_p := ErrorText;
            exit(false);
        end;

        exit(true);
    end;

    internal procedure RetailMessageUpdRecipientStatus(RetailMessageID_p: Code[20]; UserName_p: Code[50]; StoreNo_p: Code[10]; PosTerminalNo_p: Code[10]; StaffNo_p: Code[20]; NewStatus_p: Code[50]; var ErrorText_p: Text[1024]): Boolean
    var
        RetailMSGUpdRcpStatusUtils: Codeunit LSCRetailMSGUpdRcpStatusUtils;
        ResponseCode: Code[30];
        ErrorText: Text;
    begin
        ErrorText_p := '';
        POSSESSION.SetValue("LSC POS Tag"::"TS_ERROR", '');
        RetailMSGUpdRcpStatusUtils.SetPosFunctionalityProfile(PosSession.FunctionalityProfile."Profile ID");
        RetailMSGUpdRcpStatusUtils.SendRequest(RetailMessageID_p, UserName_p, StoreNo_p, PosTerminalNo_p, StaffNo_p, NewStatus_p, ResponseCode, ErrorText);
        RetailMSGUpdRcpStatusUtils.SetCommunicationError(ResponseCode, ErrorText);
        if ErrorText <> '' then begin
            ErrorText_p := ErrorText;
            exit(false);
        end;
        exit(true);
    end;

    internal procedure RetailMessageRead(RetailMessageID_p: Code[20]; UserName_p: Code[50]; StoreNo_p: Code[10]; PosTerminalNo_p: Code[10]; StaffNo_p: Code[20]; var RetailMessageLineTemp_p: Record "LSC Retail Message Line" temporary; var ErrorText_p: Text): Boolean
    var
        RetailMessageReadUtils: Codeunit LSCRetailMessageReadUtils;
        ResponseCode: Code[30];
        ErrorText: Text;
    begin
        ErrorText_p := '';
        POSSESSION.SetValue("LSC POS Tag"::"TS_ERROR", '');
        RetailMessageReadUtils.SetPosFunctionalityProfile(PosSession.FunctionalityProfile."Profile ID");
        RetailMessageReadUtils.SendRequest(RetailMessageID_p, UserName_p, StoreNo_p, PosTerminalNo_p, StaffNo_p, RetailMessageLineTemp_p, ResponseCode, ErrorText);
        if ErrorText <> '' then begin
            ErrorText_p := ErrorText;
            exit(false);
        end;

        exit(true);
    end;

    internal procedure WebReplication(ShowStatus_p: Boolean; var ErrorText_p: Text[1024]): Boolean
    var
        SBWebReplication: Codeunit "LSC Web Replication";
        ErrorText: Text[1024];
    begin
        ErrorText_p := '';
        POSSESSION.SetValue("LSC POS Tag"::"TS_ERROR", '');
        if not SBWebReplication.WebReplManually(PosSession.FunctionalityProfile."Profile ID", ShowStatus_p, ErrorText) then begin
            POSSESSION.SetValue("LSC POS Tag"::"TS_ERROR", LSHelper.Trim(ErrorText, 250));
            ErrorText_p := ErrorText;
            exit(false);
        end;

        exit(true);
    end;

    internal procedure GetMemberFrequentBuyerProgramStatuses(var FBPWSBuffer: Record "LSC FBP WS Buffer"): Boolean
    begin
        exit(POSMemberMgt.GetMemberFrequentBuyerProgramStatuses(FBPWSBuffer));
    end;

    internal procedure GetMemberCoupons(var MemberCouponBuffer: Record "LSC Member Coupon Buffer"): Boolean
    begin
        exit(POSMemberMgt.GetMemberCouponList(MemberCouponBuffer));
    end;

    internal procedure GetPostExStoreGroup(): Code[20]
    begin
        exit(PostingExceptionUtility.PostExStoreGroup);
    end;

    internal procedure FindItemPostException(StoreGroup_p: Code[20]; ItemNo_p: Code[20]; var PostingException_p: Record "LSC Posting Exception" temporary): Boolean
    begin
        exit(PostingExceptionUtility.FindItemPostException(StoreGroup_p, ItemNo_p, PostingException_p));
    end;

    internal procedure POSSalesTransExistInStore(StoreNo: Code[10]): Integer
    var
        POSTransaction: Record "LSC POS Transaction";
    begin
        POSTransaction.SetCurrentKey("Store No.", "Sales Type", "Transaction Type");
        POSTransaction.SetRange("Store No.", StoreNo);
        POSTransaction.SetRange("Transaction Type", POSTransaction."Transaction Type"::Sales);
        if not PosSession.Terminal."Terminal Statement" then begin
            PosSession.Terminal."Statement Method" := PosSession.Store."Statement Method";
            if PosSession.Terminal."Statement Method" = PosSession.Terminal."Statement Method"::"POS Terminal" then
                POSTransaction.SetRange("Created on POS Terminal", POSSESSION.TerminalNo);
            if PosSession.Terminal."Statement Method" = PosSession.Terminal."Statement Method"::Staff then
                POSTransaction.SetRange("Staff ID", POSSESSION.StaffID);
        end else
            POSTransaction.SetRange("POS Terminal No.", POSSESSION.TerminalNo);
        OnAfterPOSSalesTransExistInStore(POSTransaction, StoreNo);
        exit(POSTransaction.Count);
    end;

    internal procedure UseBackgroundSession(): Boolean
    begin
        if PosSession.FunctionalityProfile."Use Background Session" and TSUtil.TSInUse(PosSession.FunctionalityProfile) then
            exit(true)
        else
            exit(false);
    end;

    internal procedure GetCustomerOrderInventoryStatus(var CustomerOrderHeaderTemp_p: Record "LSC Customer Order Header" temporary; var CustomerOrderLineTemp_p: Record "LSC Customer Order Line" temporary; var WSInventoryBufferTemp_p: Record "LSC WS Inventory Buffer" temporary; var ErrorText_p: Text): Boolean
    var
        COQtyAvailabilityV2Utils: Codeunit LSCCOQtyAvailabilityV2Utils;
        ErrorText: Text[1024];
        ResponseCode: Code[30];
        PreferredSourcingLocation: Code[10];
        NoInventory: Label 'Items not on inventory';
    begin
        ErrorText := '';
        COQtyAvailabilityV2Utils.SetPosFunctionalityProfile(PosSession.FunctionalityProfile."Profile ID");
        COQtyAvailabilityV2Utils.SendRequest(CustomerOrderHeaderTemp_p, CustomerOrderLineTemp_p, PreferredSourcingLocation, WSInventoryBufferTemp_p, ResponseCode, ErrorText);
        if ErrorText <> '' then begin
            ErrorText_p := ErrorText;
            if ErrorText_p <> NoInventory then
                exit(false)
            else
                exit(true);
        end;
        exit(true);
    end;

    internal procedure GetCustomerOrderSourcingLocations(var CustomerOrderHeaderTemp_p: Record "LSC Customer Order Header" temporary; var CustomerOrderLineTemp_p: Record "LSC Customer Order Line" temporary; var COSourcingLocationsTemp_p: Record "LSC CO Sourcing Locations" temporary; var ErrorText_p: Text): Boolean
    var
        COHeaderTemp: Record "LSC Customer Order Header" temporary;
        COSourcingLocationListV3Utils: Codeunit LSCCOSourcingLocListV3Utils;
        COSession: Codeunit "LSC Customer Order Session";
        ResponseCode: Code[30];
        ErrorText: Text[1024];
    begin
        ErrorText := '';
        COHeaderTemp := CustomerOrderHeaderTemp_p;
        COSourcingLocationListV3Utils.SetPosFunctionalityProfile(PosSession.FunctionalityProfile."Profile ID");
        if CustomerOrderLineTemp_p.FindFirst then begin
            COSourcingLocationListV3Utils.SendRequest(CustomerOrderHeaderTemp_p, CustomerOrderLineTemp_p, COSourcingLocationsTemp_p, ResponseCode, ErrorText);
            if ErrorText <> '' then begin
                ErrorText_p := ErrorText;
                exit(false);
            end;
        end;
        if CustomerOrderHeaderTemp_p.FindFirst() then
            if CustomerOrderHeaderTemp_p."Compressed Lines (Int)" then
                COSession.SetCOLineCompressed(true);
        CustomerOrderHeaderTemp_p := COHeaderTemp;
        exit(true);
    end;

    procedure GetFilteredCustomerOrderList(var CustomerOrderHeaderTemp: Record "LSC Customer Order Header" temporary; IncludePostedCustomerOrders: Boolean; var ErrorText: Text): Boolean
    var
        COFilteredListV2Utils: Codeunit LSCCOFilteredListV2Utils;
        COSession: Codeunit "LSC Customer Order Session";
        ResponseCode: Code[20];
        IsHandled: Boolean;
        ReturnValue: Boolean;
    begin
        OnBeforeGetFilteredCustomerOrderList(CustomerOrderHeaderTemp, IncludePostedCustomerOrders, ErrorText, IsHandled, ReturnValue);
        if IsHandled then
            exit(ReturnValue);
        COFilteredListV2Utils.SetPosFunctionalityProfile(PosSession.FunctionalityProfile."Profile ID");
        COFilteredListV2Utils.SendRequest(IncludePostedCustomerOrders, CustomerOrderHeaderTemp, ResponseCode, ErrorText);
        if ErrorText <> '' then begin
            COFilteredListV2Utils.SetCommunicationError(ResponseCode, ErrorText);
            exit(false);
        end;
        if CustomerOrderHeaderTemp.FindFirst() then
            COSession.SetCOLineCompressed(CustomerOrderHeaderTemp."Compressed Lines (Int)");
        exit(true);
    end;

    internal procedure GetCoStatusExists(StoreNo: Code[10]; CustomerOrderStatus: Integer; var CustomerOrdersExist: Boolean; var ErrorText: Text): Boolean
    var
        GetCoStatusExistsUtils: Codeunit LSCGetCoStatusExistsUtils;
        ResponseCode: Code[20];
    begin
        GetCoStatusExistsUtils.SetPosFunctionalityProfile(PosSession.FunctionalityProfile."Profile ID");
        GetCoStatusExistsUtils.SendRequest(StoreNo, CustomerOrderStatus, CustomerOrdersExist, ResponseCode, ErrorText);
        if ErrorText <> '' then begin
            GetCoStatusExistsUtils.SetCommunicationError(ResponseCode, ErrorText);
            exit(false);
        end;
        exit(true);
    end;

    internal procedure GetCustomerOrderInventoryMultiple(var CustomerOrderLineTemp_p: Record "LSC Customer Order Line" temporary; var WSInventoryBufferTemp_p: Record "LSC WS Inventory Buffer" temporary; var ErrorText_p: Text): Boolean
    var
        InventoryBufferTemp: Record "Inventory Buffer" temporary;
        GetInventoryMultipleUtils: Codeunit LSCGetInventoryMultipleUtils;
        ErrorText: Text;
        ResponseCode: Code[30];
    begin
        ErrorText := '';
        GetInventoryMultipleUtils.SetPosFunctionalityProfile(PosSession.FunctionalityProfile."Profile ID");
        CustomerOrderLineTemp_p.Reset;
        CustomerOrderLineTemp_p.SetRange("Line Type", CustomerOrderLineTemp_p."Line Type"::Item);
        CustomerOrderLineTemp_p.SetRange("Service Item", false);
        if CustomerOrderLineTemp_p.FindSet() then begin
            InventoryBufferTemp.DeleteAll;
            repeat
                if not InventoryBufferTemp.get(CustomerOrderLineTemp_p.Number, CustomerOrderLineTemp_p."Variant Code", 0, '', '', '', '') then begin
                    InventoryBufferTemp."Item No." := CustomerOrderLineTemp_p.Number;
                    InventoryBufferTemp."Variant Code" := CustomerOrderLineTemp_p."Variant Code";
                    InventoryBufferTemp.Insert
                end;
            until CustomerOrderLineTemp_p.Next = 0;

            GetInventoryMultipleUtils.SendRequest('', '', InventoryBufferTemp, WSInventoryBufferTemp_p, ResponseCode, ErrorText);
            if ErrorText <> '' then begin
                ErrorText_p := ErrorText;
                exit(false)
            end;
        end;

        exit(true);
    end;

    internal procedure ProcessMarkParameter(var POSTransaction_p: Record "LSC POS Transaction"; var PosTransLineTemp_p: Record "LSC POS Trans. Line" temporary; POSMenuLine_p: Record "LSC POS Menu Line"; var pErrorCode: Code[30]; var pErrorText: Text)
    Var
        PosTransLine: Record "LSC POS Trans. Line";
        DepositError: Label 'Cannot mark as Customer Order Line while Depositting into Customer Order';
        CollectError: Label 'Cannot mark as Customer Order Line while Collecting Customer Order';
        StateError: Label 'Line can not be marked as Customer Order line in %1 state.';
        QuantityError: Label 'You can not mark a line with negative quantity as Customer Order line.';
        ReturnError: Label 'You can not mark a Return Order as Customer Order line.';
        COQuantityReturnError: Label 'You can not mix return quantity and Customer Order in the same Transaction.';
    begin
        if (POSMenuLine_p.Parameter = 'CUSTOMERORDER') or (PosTransLineTemp_p."Customer Order Line" and not PosTransLineTemp_p.Marked) then begin
            if (POSTransactionImpl.GetPosState() <> Format("LSC POS Transaction State"::SALES)) and PosTransLineTemp_p.Marked then begin
                pErrorText := StrSubstNo(StateError, POSTransactionImpl.GetPosState());
                exit;
            end;
            if PosTransLineTemp_p.Quantity < 0 then begin
                pErrorText := StrSubstNo(QuantityError, POSTransactionImpl.GetPosState());
                exit;
            end;
            if POSTransaction_p."Sale Is Return Sale" then begin
                pErrorText := ReturnError;
                exit;
            end;

            PosTransLine.SetRange("Receipt No.", POSTransaction_p."Receipt No.");
            PosTransLine.SetRange("Entry Type", PosTransLine."Entry Type"::Item);
            POSTransLine.SetFilter("Entry Status", '<>%1', PosTransLine."Entry Status"::Voided);
            PosTransLine.SetFilter(Quantity, '<0');
            if not PosTransLine.IsEmpty then begin
                pErrorText := COQuantityReturnError;
                exit;
            end;

            if POSTransaction_p."Customer Order ID" = '' then
                SetCustomerOrder(POSTransaction_p, PosTransLineTemp_p, pErrorCode, pErrorText)
            else
                if CustomerOrderSession.IsCustomerOrderEdit() then begin
                    if POSTransaction_p."Customer Order ID" <> '' then begin
                        PosTransLineTemp_p."Customer Order Line" := true;
                        PosTransLineTemp_p.Modify();
                    end;
                    exit;
                end
                else
                    if POSTransaction_p."Customer Order Deposit" then
                        pErrorText := DepositError
                    else
                        pErrorText := CollectError;
        end;
    end;

    internal procedure SetCustomerOrder(var POSTransaction_p: Record "LSC POS Transaction"; var POSTransLineTemp: Record "LSC POS Trans. Line" temporary; var pErrorCode: code[30]; var pErrorText: Text)
    var
        POSTransLine: Record "LSC POS Trans. Line";
        POSTransLine2: Record "LSC POS Trans. Line";
        CustomerOrderHeaderTemp: Record "LSC Customer Order Header" temporary;
        CustomerOrderLineTemp: Record "LSC Customer Order Line" temporary;
        CONotInTrainingMode: Label 'Customer Order functions are not accessible in Training Mode.';
    begin
        if POSTransaction_p."Entry Status" = POSTransaction_p."Entry Status"::Training then begin
            pErrorText := CONotInTrainingMode;
            exit;
        end;

        if POSTransLineTemp.Marked = false then begin
            POSTransLineTemp."Customer Order Line" := false;
            POSTransLineTemp.Modify();
            POSTransLine.SetRange("Receipt No.", POSTransaction_p."Receipt No.");
            POSTransLine.SetFilter("Entry Status", '<>%1', POSTransLine."Entry Status"::Voided);
            POSTransLine.SetRange("Entry Type", POSTransLine."Entry Type"::Item);
            POSTransLine.SetRange(Marked, true);
            POSTransLine2.SetRange("Receipt No.", POSTransaction_p."Receipt No.");
            POSTransLine2.SetFilter("Entry Status", '<>%1', POSTransLine."Entry Status"::Voided);
            POSTransLine2.SetRange("Entry Type", POSTransLine."Entry Type"::Item);
            POSTransLine2.SetRange("Customer Order Line", true);
            if POSTransLine.IsEmpty() and POSTransLine2.IsEmpty() then begin
                POSTransaction_p."Customer Order" := false;
            end;
        end else begin
            CustomerOrderHeaderTemp.Init();
            CustomerOrderHeaderTemp.Insert();
            CustomerOrderLineTemp.DeleteAll();
            CustomerOrderLineTemp.Init();
            CustomerOrderLineTemp.Number := POSTransLineTemp.Number;
            CustomerOrderLineTemp."Line Type" := POSTransLineTemp."Entry Type".AsInteger();
            CustomerOrderLineTemp."Variant Code" := POSTransLineTemp."Variant Code";
            CustomerOrderLineTemp.Insert();
            if CustomerOrderLineTemp.ItemLinesErrorCheck(CustomerOrderHeaderTemp, CustomerOrderLineTemp, pErrorCode, pErrorText) then begin
                POSTransaction_p."Customer Order" := true;
                POSTransLineTemp."Customer Order Line" := true;
            end;
        end;
        if (pErrorCode = '') and (POSTransLineTemp."Entry Status" <> POSTransLineTemp."Entry Status"::Voided) then begin
            POSTransaction_p.Modify();
            POSTransLineTemp.Modify();
        end;
    end;

    procedure GetCustomerOrderAmountFromPOSTransaction(var POSTransaction_p: Record "LSC POS Transaction" temporary): Decimal
    var
        POSTransLine: Record "LSC POS Trans. Line";
        COSession: Codeunit "LSC Customer Order Session";
    begin
        POSTransLine.SetRange("Receipt No.", POSTransaction_p."Receipt No.");
        POSTransLine.SetFilter("Entry Status", '<>%1', POSTransLine."Entry Status"::Voided);
        if not COSession.IsCOLineCompressed() then
            POSTransLine.SetRange("Entry Type", POSTransLine."Entry Type"::Item);
        POSTransLine.SetRange(Marked, true);
        POSTransLine.CalcSums(Amount);
        exit(POSTransLine.Amount);
    end;

    internal procedure GetMemberPointValuesCalculate(var MobileTransactionTemp: Record LSCMobileTransaction temporary; var MobileTransactionLineTemp: Record LSCMobileTransactionLine temporary; POSTransaction: Record "LSC POS Transaction")
    var
        Currency: Record Currency;
        TenderType: Record "LSC Tender Type";
        POSTransLine: Record "LSC POS Trans. Line";
        MemberPointSetupTemp: Record "LSC Member Point Setup" temporary;
        POSExchangerateconversion: Codeunit "LSC POS Exch. rate conversion";
        CurrCode: Code[20];
        Balance: Decimal;
        PointBalance: Decimal;
        PointsUsedInBasket: Decimal;
        AmountRemaining: Decimal;
        BasketInPoints: Decimal;
        IssuedPoints: Decimal;
    begin
        IssuedPoints := GetPointsEarnedMobileTransaction(POSTransaction, MemberPointSetupTemp);
        if MemberPointSetupTemp."Currency Code" = '' then
            CurrCode := 'LOY'
        else
            CurrCode := MemberPointSetupTemp."Currency Code";
        if not Currency.Get(CurrCode) then
            exit;
        //PointsUsedInBasket
        POSTransLine.SetRange("Receipt No.", POSTransaction."Receipt No.");
        POSTransLine.SetRange("Entry Type", POSTransLine."Entry Type"::Payment);
        TenderType.SetRange("Store No.", POSTransaction."Store No.");
        TenderType.SetRange("Function", TenderType."Function"::Member);
        if not TenderType.FindFirst then
            PointsUsedInBasket := 0;
        POSTransLine.SetRange(Number, TenderType.Code);
        if POSTransLine.FindSet then
            repeat
                PointsUsedInBasket := PointsUsedInBasket + Round(POSExchangerateconversion.POSExchangeLCYToFCY(DT2Date(MobileTransactionTemp.TransDate),
                  Currency.Code, POSTransLine.Amount), Currency."Amount Rounding Precision");
            until POSTransLine.Next = 0;

        //PointBalance
        PointBalance := POSMemberMgt.GetMemberBalance;

        //BasketInPoints
        Balance := MobileTransactionTemp.GrossAmount + MobileTransactionTemp.IncomeExpAmount;
        BasketInPoints := Round(POSExchangerateconversion.POSExchangeLCYToFCY(DT2Date(MobileTransactionTemp.TransDate), Currency.Code, Balance),
          Currency."Amount Rounding Precision");

        MobileTransactionTemp.PointBalance := PointBalance;
        MobileTransactionTemp.BasketInPoints := BasketInPoints;
        if MobileTransactionTemp.PointsUsedInBasket > 0 then
            if MobileTransactionTemp.PointsUsedInBasket < PointBalance then begin
                PointsUsedInBasket := MobileTransactionTemp.PointsUsedInBasket;
                MobileTransactionTemp.BasketInPoints := BasketInPoints - PointsUsedInBasket;
                PointBalance := PointsUsedInBasket;
            end;

        //AmountMissing
        if BasketInPoints > PointBalance then
            AmountRemaining := Round(POSExchangerateconversion.POSExchangeFCYToLCY(DT2Date(MobileTransactionTemp.TransDate), Currency.Code,
              BasketInPoints - PointBalance), Currency."Amount Rounding Precision")
        else
            AmountRemaining := 0;

        MobileTransactionTemp.PointsUsedInBasket := PointsUsedInBasket;
        MobileTransactionTemp.AmountRemaining := AmountRemaining;
        MobileTransactionTemp.IssuedPoints := IssuedPoints;
        MobileTransactionTemp.Modify;
    end;

    local procedure GetPointsEarnedMobileTransaction(var POSTransaction: Record "LSC POS Transaction"; var MemberPointSetupTemp_l: Record "LSC Member Point Setup" temporary): Decimal
    var
        MembershipCardTemp: Record "LSC Membership Card" temporary;
        MemberAccountTemp: Record "LSC Member Account" temporary;
        MemberClubTemp: Record "LSC Member Club" temporary;
        MemberSchemeTemp: Record "LSC Member Scheme" temporary;
        MemberMgtSetupTemp_l: Record "LSC Member Management Setup" temporary;
        POSTransLine: Record "LSC POS Trans. Line";
        POSCalcMemberPoints: Codeunit "LSC POS Calc. Member Points";
        ActivePriceGroup_l: Code[10];
        ItemPoints_l: Decimal;
        AmountBase: Decimal;
    begin
        GetMemberShipCardInfo(MembershipCardTemp);
        GetMemberAccountInfo(MemberAccountTemp);
        GetMemberClubInfo(MemberClubTemp);
        GetMemberSchemeInfo(MemberSchemeTemp);
        ActivePriceGroup_l := '';
        ItemPoints_l := 0;
        if MemberAccountTemp."Price Group" <> '' then
            ActivePriceGroup_l := MemberAccountTemp."Price Group"
        else
            if MemberSchemeTemp."Default Price Group" <> '' then
                ActivePriceGroup_l := MemberSchemeTemp."Default Price Group"
            else
                if MemberClubTemp."Default Price Group" <> '' then
                    ActivePriceGroup_l := MemberClubTemp."Default Price Group";
        GetMemberMgtSetupInfo(MemberMgtSetupTemp_l);
        GetMemberPointSetupInfo(MemberPointSetupTemp_l);

        POSTransLine.SetRange("Store No.", POSTransaction."Store No.");
        POSTransLine.SetRange("POS Terminal No.", POSTransaction."POS Terminal No.");
        POSTransLine.SetRange("Receipt No.", POSTransaction."Receipt No.");
        POSTransLine.SetRange("Entry Type", POSTransLine."Entry Type"::Item);
        if POSTransLine.FindSet then
            repeat
                if not POSTransLine."Offer Blocked Points" then begin
                    PosSession.Store.Get(POSTransLine."Store No.");
                    if POSCalcMemberPoints.CalcPoints(PosSession.Store."Currency Code", POSTransLine."Trans. Date", POSTransLine."Item Category Code", POSTransLine."Retail Product Code",
                      POSTransLine.Number, MembershipCardTemp, ActivePriceGroup_l, MemberPointSetupTemp_l) then begin
                        AmountBase := POSCalcMemberPoints.GetAmountBase(MemberMgtSetupTemp_l, POSTransLine."Net Amount", POSTransLine."VAT Amount", POSTransaction."Currency Factor");
                        ItemPoints_l := ItemPoints_l + (-POSCalcMemberPoints.GetItemPoints(MemberPointSetupTemp_l, AmountBase, POSTransLine.Quantity));
                    end;
                end;
            until POSTransLine.Next = 0;
        exit(ItemPoints_l);
    end;

    local procedure TotalPaymentPrTenderType(TenderType: Record "LSC Tender Type") PaymentAmount: Decimal
    var
        POSTransaction: Record "LSC POS Transaction";
        POSTransLine: Record "LSC POS Trans. Line";
    begin
        PaymentAmount := 0;
        POSTransaction.Reset;
        POSTransaction.SetCurrentKey("Store No.", "POS Terminal No.", "Staff ID");
        POSTransaction.SetRange("Store No.", POSSESSION.StoreNo);
        POSTransaction.SetRange("POS Terminal No.", POSSESSION.TerminalNo);
        POSTransaction.SetRange("Staff ID", POSSESSION.StaffID);
        if POSTransaction.FindLast then begin
            POSTransLine.Reset;
            POSTransLine.SetRange("Receipt No.", POSTransaction."Receipt No.");
            POSTransLine.SetRange("Entry Type", POSTransLine."Entry Type"::Payment);
            POSTransLine.SetRange(Number, TenderType.Code);
            POSTransLine.SetFilter("Entry Status", '<>%1', POSTransLine."Entry Status"::Voided);
            if POSTransLine.FindSet then
                repeat
                    PaymentAmount += POSTransLine.Amount;
                until POSTransLine.Next = 0;
        end;
    end;

    procedure ValidateEmailAddresses(var TempEmailItem_p: Record "Email Item"; var ErrorText_p: Text): Boolean
    var
        EmailAccount: Record "Email Account";
        EmailScenario: Codeunit "Email Scenario";
        EmailAccountOK: Boolean;
        InvalidEmailAddressErr: Label 'The email address "%1" is not valid.';
        EmailAccountError: Label 'Email Account is not set up correctly.';
    begin
        EmailAccountOK := false;
        if EmailScenario.GetEmailAccount("Email Scenario"::Default, EmailAccount) then
            if EmailAccount."Email Address" <> '' then
                if CheckValidEmailAddresses(EmailAccount."Email Address") then
                    EmailAccountOK := true;

        if not EmailAccountOK then begin
            ErrorText_p := EmailAccountError;
            exit(false);
        end;

        if not CheckValidEmailAddresses(TempEmailItem_p."From Address") then begin
            ErrorText_p := StrSubstNo(InvalidEmailAddressErr, TempEmailItem_p."From Address");
            exit(false);
        end;
        if TempEmailItem_p."Send to" <> '' then begin
            if not CheckValidEmailAddresses(TempEmailItem_p."Send to") then begin
                ErrorText_p := StrSubstNo(InvalidEmailAddressErr, TempEmailItem_p."Send to");
                exit(false);
            end;
        end;
        if TempEmailItem_p."Send CC" <> '' then begin
            if not CheckValidEmailAddresses(TempEmailItem_p."Send CC") then begin
                ErrorText_p := StrSubstNo(InvalidEmailAddressErr, TempEmailItem_p."Send CC");
                exit(false);
            end;
        end;
        if TempEmailItem_p."Send BCC" <> '' then begin
            if not CheckValidEmailAddresses(TempEmailItem_p."Send BCC") then begin
                ErrorText_p := StrSubstNo(InvalidEmailAddressErr, TempEmailItem_p."Send BCC");
                exit(false);
            end;
        end;

        exit(true);
    end;

    procedure FiscalProcessAtStart()
    var
        FiscalProcessActive: Boolean;
        FiscalProcessOk: Boolean;
    begin
        OnFiscalProcessAtStart(POSSESSION.StoreNo, POSSESSION.TerminalNo, FiscalProcessActive, FiscalProcessOk);
        if (FiscalProcessActive) then
            if FiscalProcessOk then
                POSSESSION.DeleteValue("LSC POS Tag"::"FISCALERROR")
            else
                POSSESSION.SetValue("LSC POS Tag"::"FISCALERROR", 'TRUE');
    end;

    procedure FiscalProcessAtNewTransaction(var FiscalProcessError: Boolean; var MessageText: Text)
    var
        PosStopOnFiscalProcessError: Boolean;
    begin
        FiscalProcessError := false;
        PosStopOnFiscalProcessError := false;
        MessageText := '';
        if POSSESSION.GetValue("LSC POS Tag"::"FISCALERROR") <> '' then begin
            OnFiscalProcessAtNewTransaction(POSSESSION.StoreNo, POSSESSION.TerminalNo, FiscalProcessError, PosStopOnFiscalProcessError, MessageText);
            IF FiscalProcessError then begin
                POSSESSION.SetValue("LSC POS Tag"::"FISCALERROR", 'TRUE');
                if PosStopOnFiscalProcessError then
                    POSSESSION.SetValue("LSC POS Tag"::"FISCALERRORSTOP", 'TRUE');
            end else begin
                POSSESSION.DeleteValue("LSC POS Tag"::"FISCALERROR");
                POSSESSION.DeleteValue("LSC POS Tag"::"FISCALERRORSTOP");
            end;
        end;
    end;

    procedure GetCOSalesShipments(DocumentID: Code[20]; var SalesShipmentHeaderTemp: Record "Sales Shipment Header" temporary; var ErrorText: Text): Boolean
    var
        SalesShipmentLineTemp: Record "Sales Shipment Line" temporary;
        SalesShipmentListGetUtils: Codeunit LSCSalesShipmentListGetUtils;
        ResponseCode: Code[30];
    begin
        SalesShipmentListGetUtils.SetPosFunctionalityProfile(PosSession.FunctionalityProfile."Profile ID");
        SalesShipmentListGetUtils.SendRequest(DocumentID, SalesShipmentHeaderTemp, SalesShipmentLineTemp, ResponseCode, ErrorText);
        SalesShipmentListGetUtils.SetCommunicationError(ResponseCode, ErrorText);

        exit(ErrorText = '');
    end;

    procedure UpdateSalesShipment(DocId: Code[20]; var SalesShipmentHeaderTemp: Record "Sales Shipment Header" temporary; var ErrorText: Text)
    var
        SalesShipmentUpdateUtils: Codeunit LSCSalesShipmentUpdateUtils;
        ResponseCode: Code[30];
    begin
        SalesShipmentUpdateUtils.SetPosFunctionalityProfile(PosSession.FunctionalityProfile."Profile ID");
        SalesShipmentUpdateUtils.SendRequest(DocId, SalesShipmentHeaderTemp, ResponseCode, ErrorText);
        SalesShipmentUpdateUtils.SetCommunicationError(ResponseCode, ErrorText);
    end;

    procedure Text_DivideTextIntoEvenLengthParts(OriginalText: text; PartCharLength: Integer; var PrintPart: array[50] of text; var NoOfParts: Integer)
    var
        LeftOverText: Text;
    begin
        clear(PrintPart);
        NoOfParts := 1;
        if OriginalText = '' then begin
            PrintPart[NoOfParts] := '';
            exit;
        end;
        LeftOverText := OriginalText;
        PrintPart[NoOfParts] := copystr(LeftOverText, 1, PartCharLength);
        while strlen(LeftOverText) > PartCharLength do begin
            NoOfParts += 1;
            LeftOverText := copystr(LeftOverText, PartCharLength + 1);
            PrintPart[NoOfParts] := copystr(LeftOverText, 1, PartCharLength);
        end;
    end;

    // Internal in 18.4
    procedure PublicLoadItem(var Line: Record "LSC POS Trans. Line"): Boolean
    begin
        exit(LoadItem(Line));
    end;

    procedure PublicDiscReset(var LineRec: Record "LSC POS Trans. Line")
    begin
        DiscReset(LineRec);
    end;

    [Obsolete('Not used, use POS Formatting instead', '26.0')]
    procedure PublicAdjustAmount(var Value: Decimal)
    begin
        _Formatting.AdjustAmount(Value);
    end;

    procedure PublicValidateCustomer(var Customer: Record Customer; MgrKey: Boolean; RefundSale: Boolean; Payment: Decimal; var ErrorText: Text): Boolean
    begin
        exit(ValidateCustomer(Customer, MgrKey, RefundSale, Payment, ErrorText));
    end;

    procedure PublicGetMemberCustomerDiscountGroup(): Code[10]
    begin
        exit(GetMemberCustomerDiscountGroup());
    end;

    procedure PublicGetMemberPriceGroup(): Code[10]
    begin
        exit(GetMemberPriceGroup());
    end;

    procedure PublicLotNoIsValid(var pPOSTransLine: Record "LSC POS Trans. Line"; pSerialNo: Code[50]; pLotNo: Code[50]; pItemTrackingCode: Code[10]; pSaleIsReturnSale: Boolean; pQuantity: Decimal; var pErrorText: Text[250]): Boolean
    begin
        exit(LotNoIsValid(pPOSTransLine, pSerialNo, pLotNo, pItemTrackingCode, pSaleIsReturnSale, pQuantity, pErrorText));
    end;

    procedure PublicSetPosTransDiscEntryBuffer(var pPosTransPerDiscTmp: Record "LSC POS Trans. Per. Disc. Type" temporary)
    begin
        SetPosTransDiscEntryBuffer(pPosTransPerDiscTmp);
    end;

    procedure PublicInsertPosTransDiscEntryBuffer(var pPosTransLine: Record "LSC POS Trans. Line")
    begin
        InsertPosTransDiscEntryBuffer(pPosTransLine);
    end;

    procedure PublicGetMemberPointBalance(): Decimal
    begin
        exit(GetMemberPointBalance);
    end;

    [Obsolete('Not used, use POS Formatting instead', '26.0')]
    procedure PublicFormatWeight(Dec: Decimal; UOM: Code[10]): Text[30]
    var
        Formatting: Codeunit "LSC POS Formatting";
    begin
        exit(Formatting.FormatWeight(Dec, UOM));
    end;

    [Obsolete('Not used, use POS Formatting instead', '26.0')]
    procedure PublicFormatPricePrUnit(Dec: Decimal; UOM: Code[10]): Text[30]
    var
        Formatting: Codeunit "LSC POS Formatting";
    begin
        exit(Formatting.FormatPricePrUnit(Dec, UOM));
    end;

    procedure PostInvoiceErrorCheck(PosTransaction: Record "LSC POS Transaction"; State: Code[10]; var InfoTextDescription: Text; var InfoTextDescription2: Text; var ErrorText: Text): Boolean
    var
        Customer: Record Customer;
        InfocodeEntries: Record "LSC POS Trans. Infocode Entry";
        DataEntries: Record "LSC POS Data Entry";
        VoucherEntries: Record "LSC Voucher Entries";
        CouponEntries: Record "LSC POS Trans. Line";
        SalesInvNotAllowedErr: Label 'Sales Invoice is not allowed in this state!';
        SaleIsReturnSaleErr: Label 'Sales invoice cannot be created from refund sales!';
        SelectOtherPaymOrCustMsg: Label 'Select other Payment or Customer';
        OnlyBasicSales: Label 'Only basic Pos Transactions with no linked entries can be posted to Invoice.';
        IsMissingErr: Label '%1 is missing';
    begin
        if State = Format("LSC POS Transaction State"::TENDOP) then begin
            ErrorText := SalesInvNotAllowedErr;
            exit(false);
        end;

        if PosTransaction."Sale Is Return Sale" then begin
            ErrorText := SaleIsReturnSaleErr;
            exit(false);
        end;

        if not POSSESSION.Permission(Enum::"LSC POS Command"::SUSPEND, InfoTextDescription) then begin
            ErrorText := InfoTextDescription;
            exit(false);
        end;

        if PosTransaction."Customer No." = '' then begin
            ErrorText := StrSubstNo(IsMissingErr, Customer.TableCaption);
            InfoTextDescription2 := SelectOtherPaymOrCustMsg;
            exit(false);
        end;

        DataEntries.SetRange("Created by Receipt No.", PosTransaction."Receipt No.");
        InfocodeEntries.SetRange("Receipt No.", PosTransaction."Receipt No.");
        VoucherEntries.SetRange("Receipt Number", PosTransaction."Receipt No.");
        CouponEntries.SetRange("Receipt No.", PosTransaction."Receipt No.");
        CouponEntries.SetFilter("Coupon Code", '<>%1', '');
        if (not DataEntries.IsEmpty) or (not InfocodeEntries.IsEmpty)
            or (not VoucherEntries.IsEmpty) or (not CouponEntries.IsEmpty) then begin
            ErrorText := OnlyBasicSales;
            exit(false);
        end;

        exit(true);
    end;

    internal procedure SetOriginalRefundTransactionNo(pOriginalRefundTransactionNo: Integer)
    begin
        OriginalRefundTransactionNo := pOriginalRefundTransactionNo;
    end;

    internal procedure GetOriginalRefundTransactionNo(): Integer
    begin
        exit(OriginalRefundTransactionNo);
    end;

    internal procedure ShouldAddItemOnEnter(PosMenuLine: Record "LSC POS Menu Line"; LastItemNo: Code[20]; LineRec: Record "LSC POS Trans. Line"; var ErrorMessage: Text): Boolean
    var
        ReturnValue: Boolean;
        IsHandled: Boolean;
        CannotRepeatItemFromMixMatchErr: Label 'Cannot repeat item from Mix & Match';
        CannotRepeatItemFromCustomerOrderErr: Label 'Cannot repeat item from Customer Order';
        CannotRepeatItemFromInfocodeErr: Label 'Cannot repeat item from Infocode';
    begin
        ErrorMessage := '';
        OnBeforeShouldAddItemOnEnter(PosMenuLine, LastItemNo, LineRec, IsHandled, ReturnValue, ErrorMessage);
        if IsHandled then
            exit(ReturnValue);
        if PosMenuLine."Pos Event Type" <> PosMenuLine."Pos Event Type"::BUTTONPRESS then
            exit(false);
        if PosMenuLine.Command <> 'ITEMNO' then
            exit(false);
        if (LastItemNo = '') then
            exit(false);
        if LineRec."Mix & Match Line No." <> 0 then begin
            ErrorMessage := CannotRepeatItemFromMixMatchErr;
            exit(false);
        end;
        if LineRec."Customer Order Line" then begin
            ErrorMessage := CannotRepeatItemFromCustomerOrderErr;
            exit(false);
        end;
        if LineRec."Orig. from Infocode" <> '' then begin
            ErrorMessage := CannotRepeatItemFromInfocodeErr;
            exit(false);
        end;
        OnAfterCheckConditionsOnShouldAddItemOnEnter(PosMenuLine, LastItemNo, LineRec, IsHandled, ReturnValue, ErrorMessage);
        if IsHandled then
            exit(ReturnValue);
        exit(true);
    end;

    procedure FindReturnPolicyPublic(PosTrLine: Record "LSC POS Trans. Line"; MgrKey: Boolean; DatePurchased: Date; var pReturnPolicy: Record "LSC ReturnPolicy"; var pMessageText: Text[250]; var pErrorText: Text[250]): Integer
    begin
        exit(FindReturnPolicy(PosTrLine, MgrKey, DatePurchased, pReturnPolicy, pMessageText, pErrorText));
    end;

    local procedure PopupFunctions(): Interface "LSC IPopupFunctions"
    begin
        exit(ServiceLocator.PopupFunctions);
    end;

    local procedure KDSFunctions(): Interface "LSC IKDSFunctions"
    begin
        exit(HospServiceLocator.KDSFunctions);
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeSerialNoIsValid(var pPOSTransLine: Record "LSC POS Trans. Line"; var pSerialNo: Code[50]; var ExitValue: Boolean; var Proceed: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterReturnPolicyAction2(RetPolicy: Record "LSC ReturnPolicy"; PosTrLine: Record "LSC POS Trans. Line"; ItemRec: Record Item; MgrKey: Boolean; var pErrorText: Text[250]; var pMessageText: Text[250]; var ReturnInt: Integer)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeValidateTender(TenderType: Record "LSC Tender Type"; Total: Decimal; Balance: Decimal; Payment: Decimal; RefundSale: Boolean; ManualInput: Boolean; var MessageTxt: Text; var ReturnValue: Boolean; var Handled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeIsPurgeOverDue(PosTrans: Record "LSC POS Transaction"; var IsHandled: Boolean; var ReturnValue: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnFiscalProcessAtStart(StoreNo: Code[10]; PosTerminalNo: code[10]; var FiscalProcessActive: Boolean; var FiscalProcessOk: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnFiscalProcessAtNewTransaction(StoreNo: Code[10]; PosTerminalNo: code[10]; var FiscalProcessError: Boolean; var PosStopOnFiscalProcessError: Boolean; var FiscalProcessMessage: Text)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterLoadCoupon(var Line: Record "LSC POS Trans. Line"; var CouponHeader: Record "LSC Coupon Header"; var CouponCode: code[22]; lCouponCode: code[22]; Barcode: code[22]; var IsHandled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeValidateCoupon(var Line: Record "LSC POS Trans. Line"; var IsHandled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeLoadItem(var Line: Record "LSC POS Trans. Line"; var IsHandled: Boolean; var ReturnValue: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeMarkLine(var pPosTransLine: Record "LSC POS Trans. Line"; var IsHandled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBalanceOverCreditLimit(Customer: Record Customer; MgrKey: Boolean; RefundSale: Boolean; Payment: Decimal; var ErrorText: Text; var ExitValue: Boolean; var IsHandled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBalanceOverCreditLimitCustomer(Customer: Record Customer; MgrKey: Boolean; RefundSale: Boolean; Payment: Decimal; var ErrorText: Text; var ExitValue: Boolean; var IsHandled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeChangeVATBusOnLine(var POSTransaction: Record "LSC POS Transaction"; var IsHandled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterChangeVATBusOnLine(var POSTransaction: Record "LSC POS Transaction")
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnNotFindItemViaBarcode(Barcode: Text[22]; var Pos: Integer; var Segment: Record "LSC Barcode Mask Segment"; var BarcItem: Code[20])
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterCalculateUnitPrice(POSTransaction: Record "LSC POS Transaction"; TransLine: Record "LSC POS Trans. Line"; var UnitPrice: Decimal)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeGetSerialLotSalesQuantity(POSTransLine: Record "LSC POS Trans. Line"; SerialNo: Code[50]; LotNo: Code[50]; var IsHandled: Boolean; var AvailableQty: Decimal)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterGetSerialLotSalesQuantity(POSTransLine: Record "LSC POS Trans. Line"; SerialNo: Code[50]; LotNo: Code[50]; NetInventory: Decimal; var IsHandled: Boolean; var AvailableQty: Decimal)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterLoadItem(var POSTransLine: Record "LSC POS Trans. Line"; var Item: Record Item)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterDirectLoadItem(var POSTransLine: Record "LSC POS Trans. Line"; var Item: Record Item)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeRoundTender(TenderType: Record "LSC Tender Type"; Amount: Decimal; var Result: Decimal; var IsHandled: Boolean);
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterTenderRoundingDirection(TenderType: Record "LSC Tender Type"; var TenderRoundingDirection: Text)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterSuspend(SuspPOSTransaction: Record "LSC POS Transaction"; var SendPOSTransSuccess: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeGetPosTransSusp(POSFuncProfileID: Code[10]; ReceiptNo: Code[20]; var POSTransactionTemp: Record "LSC POS Transaction" temporary;
                    var POSTransLineTemp: Record "LSC POS Trans. Line" temporary; var POSTransPeriodicDiscTemp: Record "LSC POS Trans. Per. Disc. Type" temporary;
                    var POSTransInfocodeEntryTemp: Record "LSC POS Trans. Infocode Entry" temporary; var POSDataEntryTemp: Record "LSC POS Data Entry" temporary;
                    var VoucherEntriesTemp: Record "LSC Voucher Entries" temporary; var OfferPosCalculationTemp: Record "LSC Offer Pos Calculation" temporary;
                    var POSOrderHeaderTemp: Record "LSC POS Order Header" temporary; var POSOrderLineTemp: Record "LSC POS Order Line" temporary;
                    var OptionTypeValueHeaderTemp: Record "LSC Option Type Value Header" temporary; var OptionTypeValueEntryTemp: Record "LSC Option Type Value Entry" temporary;
                    var POSTransInfoDataEntryTemp: Record "LSC POS Trans. InfoData Entry" temporary; var POSTransAddSalespersonTemp: Record "LSC POS Trans. Add. Salesp." temporary;
                    var ResponseCode: Code[30]; var ErrorText: Text; var IsHandled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeGetMemberInfoForPos(CardNo: Text; var ResponseCode: Code[30]; var ErrorText: Text; var IsHandled: Boolean; var ReturnValue: Boolean; RunGetMemberInfo: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeFindLastTrans(PosTerminal: Record "LSC POS Terminal"; var TransactionHeader: Record "LSC Transaction Header"; var ReturnValue: Boolean; var IsHandled: Boolean);
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeInsertPOSVoidedTransLine(var VoidedLine: Record "LSC POS Voided Trans. Line"; SlipHeader: Record "LSC POS Transaction")
    begin
    end;

    [IntegrationEvent(false, false)]
    internal procedure OnBeforeAdjustAmount(var Value: Decimal)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeApplyFilterToTransaction(var Transaction: Record "LSC Transaction Header"; var FilterFrom: Text[30]; var FilterTo: Text[30])
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterSetLastSlip(var TmpLastSlip: Text[30]; LastSlipNo: Code[20])
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeValidateLotNoQtyCheckQuantity(var pQuantity: Decimal; var pPOSTransLine: Record "LSC POS Trans. Line")
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeLotNoIsValid(var pQuantity: Decimal; var pPOSTransLine: Record "LSC POS Trans. Line")
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeUpdateSerialLotInvLookup(var pPOSTransLine: Record "LSC POS Trans. Line"; var pItemTrackingCode: Code[10]; var pErrorText: Text[250]; var IsHandled: Boolean; var ReturnValue: Boolean)
    begin
    end;

    [IntegrationEvent(true, false)]
    local procedure OnBeforeGetSerialLotSalesQtyExclCurr(var pPOSTransLine: Record "LSC POS Trans. Line"; var pSerialNo: Code[50]; var pLotNo: Code[50]; var IsHandled: Boolean; var QtyOnPosExclCurr: Decimal)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeGetSerialLotSalesQty(var pPOSTransLine: Record "LSC POS Trans. Line"; var pSerialNo: Code[50]; var pLotNo: Code[50]; var IsHandled: Boolean; var QtyOnPos: Decimal)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeDiscReset(var LineRec: Record "LSC POS Trans. Line"; var IsHandled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeValidateCustomer(var Customer: Record Customer; var MgrKey: Boolean; var RefundSale: Boolean; var Payment: Decimal; ErrorText: Text; var ExitValue: Boolean; var IsHandled: Boolean);
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterValidateCustomer(var Customer: Record Customer; var MgrKey: Boolean; var RefundSale: Boolean; var Payment: Decimal; ErrorText: Text; var ExitValue: Boolean; var IsHandled: Boolean);
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterPurge()
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeRetriveSusp(SlipNumber: Code[20]; var POSTransaction: Record "LSC POS Transaction"; var ErrorText: Text; var Result: Boolean; var IsHandled: Boolean);
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeGetFilteredCustomerOrderList(var CustomerOrderHeaderTemp: Record "LSC Customer Order Header" temporary; var IncludePostedCustomerOrders: Boolean; var ErrorText: Text; var IsHandled: Boolean; var ReturnValue: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeGetCustomerOrder(DocumentStatus: code[20]; DocumentID: Code[20]; var CustomerOrderHeaderTemp: Record "LSC Customer Order Header" temporary; var CustomerOrderLineTemp: Record "LSC Customer Order Line" temporary; var CustomerOrderDiscountLineTemp: Record "LSC CO Discount Line" temporary; var CustomerOrderPaymentTemp: Record "LSC Customer Order Payment" temporary; var ErrorText: Text; var IsHandled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeSuspTransLineInsert(var SuspTransLine: Record "LSC POS Trans. Line")
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeTransLineInsert(var TransLine: Record "LSC POS Trans. Line")
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeModifySrcTransLine(var SrcTransLine: Record "LSC POS Trans. Line"; var TmpLine: Record "LSC POS Trans. Line")
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterInitTmpTransFromStoreSetup(var TmpTrans: Record "LSC POS Transaction"; StoreSetup: Record "LSC Store")
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterCheckFilterPassed(var IsHandled: Boolean; var Deal: Record "LSC Offer")
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterDiscValPerValid_ValidateCoupon(CouponHeader: Record "LSC Coupon Header"; PosTrans: Record "LSC POS Transaction"; var Line: Record "LSC POS Trans. Line"; var Description: Text[30]; var ReturnValue: Boolean; var IsHandled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterPeriodActive2_GetActiveItemPointOfferLines(CurrLine: Record "LSC POS Trans. Line"; var PeriodicDiscountLine: Record "LSC Periodic Discount Line"; var TmpPerDiscount: Record "LSC Periodic Discount" temporary; var TmpItemPointOfferLine: Record "LSC Periodic Discount Line" temporary; PromptAtScan: Boolean; var PromptAtScanLine: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterGetDisc4ItemAtStart(var TmpPeriodicDiscountLine: Record "LSC Periodic Discount Line" temporary; var TmpPeriodicDiscRec: Record "LSC Periodic Discount" temporary; ItemNo: Code[20])
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterPreLoadDicLines_GetDisc4ItemByDemand(ItemNo: Code[20]; var LastLineNo: Integer; var pPeriodicDiscLineParm: Record "LSC Periodic Discount Line")
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterGetDisc4ItemByDemand(var TmpPeriodicDiscountLine: Record "LSC Periodic Discount Line" temporary; var TmpPeriodicDiscRec: Record "LSC Periodic Discount" temporary; ItemNo: Code[20])
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforePreLoadDicLines(var pPeriodicDiscLineParm: Record "LSC Periodic Discount Line"; var pLastLineNo: Integer; var PreLoadDiscTmp: Record "LSC Periodic Discount" temporary; var PreLoadDiscLineTmp: Record "LSC Periodic Discount Line" temporary; var TmpPeriodicDiscountLine: Record "LSC Periodic Discount Line" temporary; var IsHandled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeSetFilters_GetDisc4ItemByDemand(var TmpPeriodicDiscountLine: Record "LSC Periodic Discount Line" temporary)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeSetFilters_GetDisc4ItemAtStart(var TmpPeriodicDiscountLine: Record "LSC Periodic Discount Line" temporary)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeCheckPeriodicDiscount_GetDisc4ItemByDemand(var TmpPeriodicDiscountLine: Record "LSC Periodic Discount Line" temporary; Item: Record Item)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeCheckPeriodicDiscount_GetDisc4ItemAtStart(var TmpPeriodicDiscountLine: Record "LSC Periodic Discount Line" temporary; Item: Record Item)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterCheckPeriodicDiscount_GetDisc4ItemByDemand(var TmpPeriodicDiscountLine: Record "LSC Periodic Discount Line" temporary)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterCheckPeriodicDiscount_GetDisc4ItemAtStart(var TmpPeriodicDiscountLine: Record "LSC Periodic Discount Line" temporary)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterSetKey_GetActiveItemPointOfferLines(var PeriodicDiscountLine: Record "LSC Periodic Discount Line")
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeCheckPeriodicDiscount_GetActiveItemPointOfferLines(var PeriodicDiscountLine: Record "LSC Periodic Discount Line"; Item: Record Item)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterCheckPeriodicDiscount_GetActiveItemPointOfferLines(var PeriodicDiscountLine: Record "LSC Periodic Discount Line")
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterSetKey_PreLoadDicLines(var PreLoadDiscLineTmp: Record "LSC Periodic Discount Line" temporary)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforePeriodicDiscLineOpen_PreLoadDicLines(var PeriodicDiscLineParm: Record "LSC Periodic Discount Line"; var pPeriodicDiscLineParm: Record "LSC Periodic Discount Line")
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeSetPeriodicDiscountLineFilters_PreLoadDicLines(var PeriodicDiscountLine: Record "LSC Periodic Discount Line")
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterSetPeriodicDiscountLineFilters_PreLoadDicLines(var PeriodicDiscountLine: Record "LSC Periodic Discount Line")
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeModifyPrepayIncExpLineOnSuspPOSTrans(PaymentSlip: Code[20]; var SuspPOSTransLine: Record "LSC POS Trans. Line")
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeProcessDataEntryMask(LDataEntry: Record "LSC POS Data Entry Type"; Barcode: Text[22]; Pos: Integer; SegmentLength: Integer; var IsHandled: Boolean; var ReturnValue: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeShouldAddItemOnEnter(PosMenuLine: Record "LSC POS Menu Line"; LastItemNo: Code[20]; LineRec: Record "LSC POS Trans. Line"; var IsHandled: Boolean; var ReturnValue: Boolean; var ErrorMessage: Text)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterPOSSalesTransExistInStore(var POSTransaction: Record "LSC POS Transaction"; StoreNo: Code[10])
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterCheckConditionsOnShouldAddItemOnEnter(PosMenuLine: Record "LSC POS Menu Line"; LastItemNo: Code[20]; LineRec: Record "LSC POS Trans. Line"; var IsHandled: Boolean; var ReturnValue: Boolean; var ErrorMessage: Text)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeSuspended(var SlipNumber: Code[20]; POSTransaction: Record "LSC POS Transaction"; var PaymentSlip: Code[20]; var POSTransLineTemp: Record "LSC POS Trans. Line" temporary; var LastSlipNo: Code[20]; var SendPOSTransSuccess: Boolean; var Handled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterPosTrLineInsertLine(var PosTrLine: Record "LSC POS Trans. Line")
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnFindOpenCustLedgEntry(var CustLedgEntry: Record "Cust. Ledger Entry")
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeLoadOfferTablesAtStart(var PeriodicDiscount: Record "LSC Periodic Discount"; var TmpPreDiscAmountToTrigger: Record "LSC Periodic Discount" temporary; var TmpPeriodicDiscountLine: Record "LSC Periodic Discount Line" temporary; var IsHandled: Boolean);
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeApplyCustomerDiscount(var POSTransaction: Record "LSC POS Transaction"; var TransLine: Record "LSC POS Trans. Line"; var IsHandled: Boolean)
    begin
    end;
                                           
    [IntegrationEvent(false, false)]
    local procedure OnAfterSetFilters_LoadOfferTablesAtStart(var LSCPeriodicDiscount: Record "LSC Periodic Discount")
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterSetFilters_LoadOfferTablesByDemand(var LSCPeriodicDiscount: Record "LSC Periodic Discount")
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeCheckTmpPreDiscAmountToTrigger_GetDisc4ItemAtStart(var TempLSCPeriodicDiscount: Record "LSC Periodic Discount" temporary)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeCheckTmpPreDiscAmountToTrigger_GetDisc4ItemByDemand(var TempLSCPeriodicDiscount: Record "LSC Periodic Discount" temporary)
    begin
    end;
}
