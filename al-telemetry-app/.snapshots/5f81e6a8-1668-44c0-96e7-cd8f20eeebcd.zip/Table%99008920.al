table 99008920 "LSC POS Command"
{
    Caption = 'POS Command';
    LookupPageID = "LSC POS Commands";
    DataClassification = CustomerContent;

    fields
    {
        field(1; "Function Code"; Code[20])
        {
            Caption = 'Function Code';
            DataClassification = CustomerContent;
            ToolTip = 'Specifies the code of the POS command. This field cannot be edited. The table nproverview_99008901 explains the properties of and/or method of use for each LS POS command.';
        }
        field(2; Prompt; Text[30])
        {
            Caption = 'Prompt';
            DataClassification = CustomerContent;
            ToolTip = 'Specifies a text that appears on the display when the command prompts for information or action. This field is editable.';
        }
        field(3; Description; Text[100])
        {
            Caption = 'Description';
            DataClassification = CustomerContent;
            ToolTip = 'Specifies the description of the command. This field cannot be edited.';
        }
        field(4; "Menu Function"; Boolean)
        {
            Caption = 'Menu Function';
            DataClassification = CustomerContent;
            ToolTip = 'Specifies whether the command can be used in a menu. Otherwise it is an internal command. This field cannot be edited.';
        }
        field(6; "Parameter Type"; enum "LSC POS Command Parameter Type")
        {
            Caption = 'Parameter Type';
            DataClassification = CustomerContent;
        }
        field(15; "Manager Key"; Boolean)
        {
            Caption = 'Manager Key';
            DataClassification = CustomerContent;
            ToolTip = 'Specifies whether you need to have manager rights to use this command. This field is editable.';
        }
        field(20; "Scanner Action"; Option)
        {
            Caption = 'Scanner Action';
            OptionCaption = ' ,Enable,Disable';
            OptionMembers = " ",Enable,Disable;
            DataClassification = CustomerContent;
            ToolTip = 'Specifies the status of the scanner during the command. Blank: The command has no effect on the status of the scanner. Enable: The command enables the scanner. This is recommended if the command requires input from the scanner. Disable: The command disables the scanner. This is recommended if the command requires input from, and enables, another device.';
        }
        field(21; "MSR Action"; Option)
        {
            Caption = 'MSR Action';
            OptionCaption = ' ,Enable,Disable';
            OptionMembers = " ",Enable,Disable;
            DataClassification = CustomerContent;
        }
        field(22; "Function Type"; Option)
        {
            Caption = 'Function Type';
            OptionCaption = 'POS Internal,POS External,POS Action';
            OptionMembers = "POS Internal","POS External","POS Action";
            DataClassification = CustomerContent;
            ToolTip = 'Specifies the function type of the POS Command. POS Internal: A command created by LS Retail. POS External: A customization or functionality that is added to the Standard POS Commands. A codeunit is specified for executing an external command.';
        }
        field(23; "Description Text"; Text[200])
        {
            Caption = 'Description Text';
            DataClassification = CustomerContent;
            ToolTip = 'Specifies a text that describes the functionality of the POS Command.';
        }
        field(24; "Run Codeunit"; Integer)
        {
            Caption = 'Run Codeunit';
            TableRelation = AllObj."Object ID" WHERE("Object Type" = CONST(Codeunit));
            DataClassification = CustomerContent;
            ToolTip = 'Specifies the number of the Codeunit that executes the POS Command if it is an External command.';
            trigger OnValidate()
            begin
                calcfields("Codeunit Name");
            end;
        }
        field(25; "POS Panel ID"; Code[20])
        {
            Caption = 'POS Panel ID';
            TableRelation = "LSC POS Panel"."Control ID";
            DataClassification = CustomerContent;
            ToolTip = 'Specifies the ID of the panel shown for this pop-up that displays selection buttons.';
        }
        field(26; "Set POS State"; Code[20])
        {
            Caption = 'Set POS State';
            DataClassification = CustomerContent;
            ToolTip = 'The program uses this field internally.';
        }
        field(27; "Table Link"; Integer)
        {
            BlankZero = true;
            Caption = 'Table Link';
            TableRelation = AllObj."Object ID" WHERE("Object Type" = CONST(Table));
            DataClassification = CustomerContent;
            ToolTip = 'Specifies the number of the table that this parameter is linked to. If a parameter is linked to a table and field, you can look up the value from that table/field when setting up the parameter values.';
        }
        field(28; "Field Link"; Integer)
        {
            BlankZero = true;
            Caption = 'Field Link';
            TableRelation = Field."No." WHERE(TableNo = FIELD("Table Link"),
                                               Enabled = CONST(true),
                                               Class = CONST(Normal),
                                               Type = FILTER(<> BLOB));
            DataClassification = CustomerContent;
            ToolTip = 'Specifies the number of the field that this parameter is linked to. If a parameter is linked to a table and field you can look up the value from that table/field when setting up the parameter values.';
        }
        field(30; "Codeunit Name"; Text[30])
        {
            CalcFormula = Lookup(AllObj."Object Name" WHERE("Object Type" = CONST(Codeunit),
                                                             "Object ID" = FIELD("Run Codeunit")));
            Caption = 'Codeunit Name';
            Editable = false;
            FieldClass = FlowField;
            ToolTip = 'Specifies the description of the codeunit that executes the POS command.';
        }
        field(34; Blocking; Boolean)
        {
            Caption = 'Blocking';
            DataClassification = CustomerContent;
            ToolTip = 'Specifies if the command should block the User Interface until the server has finished handling it (by default, button clicks are non-blocking). This is useful when operations on the server take a long time, e.g. for slow network connections. Use POS Interface Profile to apply this setting to all commands.';
        }
        field(38; "POS Help ID"; Code[20])
        {
            Caption = 'POS Help ID';
            TableRelation = "LSC POS Help Text".ID WHERE(ID = FIELD("POS Help ID"));
            DataClassification = CustomerContent;
        }
        field(39; "POS Module"; Code[20])
        {
            Caption = 'POS Module';
            TableRelation = "LSC Retail Module".Code;
            DataClassification = CustomerContent;
            ToolTip = 'Specifies the POS Module that this parameter applies to.';
        }
        field(40; "Scanner Action 2"; Option)
        {
            Caption = 'Scanner Post Action';
            OptionCaption = ' ,Enable,Disable';
            OptionMembers = " ",Enable,Disable;
            DataClassification = CustomerContent;
        }
        field(41; "MSR Action 2"; Option)
        {
            Caption = 'MSR Post Action';
            OptionCaption = ' ,Enable,Disable';
            OptionMembers = " ",Enable,Disable;
            DataClassification = CustomerContent;
        }
        field(42; "RFID Action"; Enum "LSC RFID Action")
        {
            Caption = 'RFID Action';
            DataClassification = CustomerContent;
            ToolTip = 'Specifies the status of the RFID reader during the command. None: The command has no effect on the status of the RFID reader. Enable: The command enables the RFID reader. This is recommended if the command requires input from the RFID reader. Disable: The command disables the RFID reader. This is recommended if the command requires input from, and enables, another device.';
        }
        field(43; "RFID Post Action"; Enum "LSC RFID Action")
        {
            Caption = 'RFID Post Action';
            DataClassification = CustomerContent;
            ToolTip = 'Specifies the status of the RFID reader after the command has finished. None: The command has no effect on the status of the RFID reader. Enable: The command enables the RFID reader after finishing. This is recommended if functionality after command requires input from the RFID reader. Disable: The command disables the RFID reader after the command finishes. This is recommended if the functionality after the command does not require input from a RFID device.';
        }
        field(50; "Background Fading"; Boolean)
        {
            Caption = 'Background Fading';
            DataClassification = CustomerContent;
        }
        field(59; "Pop-up Main Handler"; Enum "LSC Popup Main Handler")
        {
            Caption = 'Pop-up Main Handler';
            DataClassification = CustomerContent;
            ToolTip = 'Specifies the main handler of the pop-up window.';
        }
        field(60; "Pop-up Function"; Boolean)
        {
            Caption = 'Pop-up Function';
            DataClassification = CustomerContent;
        }
        field(61; "Forecourt Action"; Option)
        {
            Caption = 'Forecourt Action';
            OptionCaption = ' ,Enable,Disable';
            OptionMembers = " ",Enable,Disable;
            DataClassification = CustomerContent;
            ObsoleteState = Removed;
            ObsoleteReason = 'Forecourt moved to a separate extension.';
            ObsoleteTag = '25.0'; // Pending='21.1'
        }
        field(62; "Forecourt Action 2"; Option)
        {
            Caption = 'Forecourt Action 2';
            OptionCaption = ' ,Enable,Disable';
            OptionMembers = " ",Enable,Disable;
            DataClassification = CustomerContent;
            ObsoleteState = Removed;
            ObsoleteReason = 'Forecourt moved to a separate extension.';
            ObsoleteTag = '25.0'; // Pending='21.1'
        }
        field(70; Skin; Code[20])
        {
            Caption = 'Skin';
            TableRelation = "LSC POS Button Skin".Code;
            ValidateTableRelation = false;
            DataClassification = CustomerContent;

            trigger OnValidate()
            var
                ButtonSkin: Record "LSC POS Button Skin";
            begin
                ButtonSkin.ValidateButtonSkin(Skin);
            end;
        }
        field(71; Font; Code[20])
        {
            Caption = 'Font';
            TableRelation = "LSC POS Font".Code;
            ValidateTableRelation = false;
            DataClassification = CustomerContent;

            trigger OnValidate()
            var
                POSFont: Record "LSC POS Font";
            begin
                POSFont.ValidateFont(Font);
            end;
        }
        field(80; "POS Button Description"; Text[100])
        {
            Caption = 'POS Button Description';
            DataClassification = CustomerContent;
            ToolTip = 'Specifies the text that is entered as Description when the command is assigned to a POS Menu Line. This is used for example when a POS Tag is used to vary the description of the command on a button.';
        }
        field(2100; "Outbound Code"; Text[30])
        {
            Caption = 'Outbound Code';
            DataClassification = CustomerContent;
        }
    }

    keys
    {
        key(Key1; "Function Code")
        {
            Clustered = true;
        }
        key(Key2; "POS Module", "Function Code")
        {
        }
    }

    trigger OnDelete()
    var
        PosCommParam: Record "LSC POS Parameter Setup";
    begin
        PosCommParam.SetRange("Code Type", PosCommParam."Code Type"::"POS Command");
        PosCommParam.SetRange(Code, "Function Code");
        PosCommParam.DeleteAll(true);
    end;

    var
        POSSession: Codeunit "LSC POS Session";

    internal procedure ParameterLookup(var Param: Text[100]; ParamType: enum "LSC POS Command Parameter Type"; var ProfileID: Code[10]; Command: Code[20])
    var
        HardwareProfile: Record "LSC POS Hardware Profile";
        Attribute: Record "LSC Attribute";
        AttributeGroup: Record "LSC Attribute Group";
        Currency: Record Currency;
        Customer: Record Customer;
        Infocode: Record "LSC Infocode";
        InformationSubcode: Record "LSC Information Subcode";
        Item: Record Item;
        ItemFinderSetup: Record "LSC Item Finder Setup";
        HospStandardText: Record "LSC Hosp. Standard Text";
        IncomeExpenseAccount: Record "LSC Income/Expense Account";
        LineDiscountOfferGroup: Record "LSC Line Discount Offer Group";
        MealPlanMenu: Record "LSC Meal Plan Menu";
        Offer: Record "LSC Offer";
        POSLookup: Record "LSC POS Lookup";
        POSMacroHeader: Record "LSC POS Macro Header";
        POSRunObjects: Record "LSC POS Run Objects";
        POSDataEntryType: Record "LSC POS Data Entry Type";
        POSDataGridControl: Record "LSC POS Data Grid Control";
        POSDataTable: Record "LSC POS Data Table";
        POSDynamicMenu: Record "LSC POS Dynamic Menu";
        POSMenuHeader: Record "LSC POS Menu Header";
        POSPanel: Record "LSC POS Panel";
        POSSearch: Record "LSC POS Search";
        RestaurantMenuType: Record "LSC Restaurant Menu Type";
        RetailCharge: Record "LSC Retail Charge";
        SalesType: Record "LSC Sales Type";
        Staff: Record "LSC Staff";
        Store: Record "LSC Store";
        TenderTypeCardSetup: Record "LSC Tender Type Card Setup";
        TenderTypeSetup: Record "LSC Tender Type Setup";
        UnitOfMeasure: Record "Unit of Measure";
        DiningArea: Record "LSC Dining Area";
        LSCCommentCategory: Record "LSC Comment Category";
        BOUtils: Codeunit "LSC BO Utils";
        ActResourceGroup: Record "LSC Activity Resource Group";
        ReservationType: Record "LSC Reservation Type";
        ActivityTypes: Record "LSC Activity Type";
        AccessTypeTempRec: Record "LSC ACT Access Type" temporary;
    begin
        case ParamType of
            ParamType::Menu:    //Menu
                begin
                    POSMenuHeader.Reset;
                    if Param <> '' then
                        POSMenuHeader.SetRange("Menu ID", Param);
                    if PAGE.RunModal(BOUtils.getLookupPage(Database::"LSC POS Menu Header"), POSMenuHeader) = ACTION::LookupOK then begin
                        Param := POSMenuHeader."Menu ID";
                        ProfileID := CopyStr(Format(POSMenuHeader."Profile ID"), 1, 10);
                    end;
                end;
            ParamType::Item:    //Item
                begin
                    if Item.Get(Param) then;
                    if PAGE.RunModal(BOUtils.getLookupPage(Database::Item), Item) = ACTION::LookupOK then
                        Param := Item."No.";
                end;
            ParamType::"Tender Type":    //Tender Type
                begin
                    if TenderTypeSetup.Get(Param) then;
                    if PAGE.RunModal(BOUtils.getLookupPage(Database::"LSC Tender Type Setup"), TenderTypeSetup) = ACTION::LookupOK then
                        Param := TenderTypeSetup.Code;
                end;
            ParamType::Currency:    //Currency
                begin
                    if Currency.Get(Param) then;
                    if PAGE.RunModal(BOUtils.getLookupPage(Database::Currency), Currency) = ACTION::LookupOK then
                        Param := Currency.Code;
                end;
            ParamType::Infocode:    //Infocode
                begin
                    if Infocode.Get(Param) then;
                    if PAGE.RunModal(BOUtils.getLookupPage(Database::"LSC Infocode"), Infocode) = ACTION::LookupOK then
                        Param := Infocode.Code;
                end;
            ParamType::Customer:    //Customer
                begin
                    if Customer.Get(Param) then;
                    if PAGE.RunModal(BOUtils.getLookupPage(Database::Customer), Customer) = ACTION::LookupOK then
                        Param := Customer."No.";
                end;
            ParamType::Lookups:    //Lookup
                begin
                    POSLookup.Reset;
                    if PAGE.RunModal(BOUtils.getLookupPage(Database::"LSC POS Lookup"), POSLookup) = ACTION::LookupOK then
                        Param := POSLookup."Lookup ID";
                end;
            ParamType::Macro:    //Macro
                begin
                    if POSMacroHeader.Get(ProfileID, Param) then;
                    POSMacroHeader.SetRange("Profile ID", ProfileID);
                    if PAGE.RunModal(BOUtils.getLookupPage(Database::"LSC POS Menu Header"), POSMacroHeader) = ACTION::LookupOK then
                        Param := POSMacroHeader."Macro ID";
                end;
            ParamType::"Card Type":    //Card Type
                begin
                    TenderTypeCardSetup.SetRange("Card No.", Param);
                    if TenderTypeCardSetup.FindFirst then;
                    if PAGE.RunModal(BOUtils.getLookupPage(Database::"LSC Tender Type Card Setup"), TenderTypeCardSetup) = ACTION::LookupOK then
                        Param := TenderTypeCardSetup."Card No.";
                end;
            ParamType::Objects:    //Objects
                begin
                    if POSRunObjects.Get(Param) then;
                    if PAGE.RunModal(BOUtils.getLookupPage(Database::"LSC POS Run Objects"), POSRunObjects) = ACTION::LookupOK then
                        Param := POSRunObjects."Object Code";
                end;
            ParamType::"Income/Expense Account":    //Income/Expense Account
                begin
                    if (POSSession.StoreNo <> '') then
                        IncomeExpenseAccount.SetRange("Store No.", POSSession.StoreNo);
                    IncomeExpenseAccount.SetRange("No.", Param);
                    if IncomeExpenseAccount.FindFirst then;
                    IncomeExpenseAccount.SetRange("No.");
                    if PAGE.RunModal(BOUtils.getLookupPage(Database::"LSC Income/Expense Account"), IncomeExpenseAccount) = ACTION::LookupOK then
                        Param := IncomeExpenseAccount."No.";
                end;
            ParamType::UOM:    //UOM
                begin
                    if UnitOfMeasure.Get(Param) then;
                    if PAGE.RunModal(BOUtils.getLookupPage(Database::"Unit of Measure"), UnitOfMeasure) = ACTION::LookupOK then
                        Param := UnitOfMeasure.Code;
                end;
            ParamType::"Sales Type":    //Sales Type
                begin
                    if SalesType.Get(Param) then;
                    if PAGE.RunModal(BOUtils.getLookupPage(Database::"LSC Sales Type"), SalesType) = ACTION::LookupOK then
                        Param := SalesType.Code;
                end;
            ParamType::Staff:    //Staff
                begin
                    if Staff.Get(Param) then;
                    if PAGE.RunModal(BOUtils.getLookupPage(Database::"LSC Staff"), Staff) = ACTION::LookupOK then
                        Param := Staff.ID;
                end;
            ParamType::Deal:    //Deal
                begin
                    if Offer.Get(Param) then;
                    Offer.SetRange(Type, Offer.Type::Deal);
                    if PAGE.RunModal(BOUtils.getLookupPage(Database::"LSC Offer"), Offer) = ACTION::LookupOK then
                        Param := Offer."No.";
                end;
            ParamType::"Info Subcode":    //Info Subcode
                begin
                    InformationSubcode.SetRange(InformationSubcode.Subcode, Param);
                    if InformationSubcode.FindFirst then;
                    if PAGE.RunModal(BOUtils.getLookupPage(Database::"LSC Information Subcode"), InformationSubcode) = ACTION::LookupOK then
                        Param := InformationSubcode.Subcode;
                end;
            ParamType::"Item Finder Setup":    //Item Finder Setup
                begin
                    if PAGE.RunModal(BOUtils.getLookupPage(Database::"LSC Item Finder Setup"), ItemFinderSetup) = ACTION::LookupOK then
                        Param := ItemFinderSetup.Code;
                end;
            ParamType::Zoom:    //Zoom
                begin
                    POSLookup.SetRange("Use As Zoom", true);
                    if POSLookup.FindFirst then;
                    if PAGE.RunModal(BOUtils.getLookupPage(Database::"LSC POS Data Table Columns"), POSLookup) = ACTION::LookupOK then
                        Param := POSLookup."Lookup ID";
                end;
            ParamType::"Meal Menu":    //Meal Menu
                begin
                    if MealPlanMenu.Get(Param) then;
                    if PAGE.RunModal(BOUtils.getLookupPage(Database::"LSC Product Nutrition Group"), MealPlanMenu) = ACTION::LookupOK then
                        Param := MealPlanMenu.Code;
                end;
            ParamType::"Data Entry":    //Data Entry
                begin
                    POSDataEntryType.SetRange("Data Entry Only Allowed", true);
                    if POSDataEntryType.FindFirst then;
                    if PAGE.RunModal(BOUtils.getLookupPage(Database::"LSC POS Data Entry Type"), POSDataEntryType) = ACTION::LookupOK then
                        Param := POSDataEntryType.Code;
                end;
            ParamType::"Line Disc. Offer":    //Line Discount Offer
                begin
                    if LineDiscountOfferGroup.Get(Param) then;
                    if PAGE.RunModal(BOUtils.getLookupPage(Database::"LSC Line Discount Offer Group"), LineDiscountOfferGroup) = ACTION::LookupOK then
                        Param := LineDiscountOfferGroup.Code;
                end;
            ParamType::"POS Panel":    //POS Panel
                begin
                    POSPanel.Reset;
                    if PAGE.RunModal(BOUtils.getLookupPage(Database::"LSC POS Panel"), POSPanel) = ACTION::LookupOK then
                        Param := POSPanel."Control ID";
                end;
            ParamType::"POS Data Table":    //POS Data Table
                begin
                    POSDataTable.Reset;
                    if PAGE.RunModal(BOUtils.getLookupPage(Database::"LSC POS Data Table"), POSDataTable) = ACTION::LookupOK then
                        Param := POSDataTable."Data Table ID";
                end;
            ParamType::"POS Data Grid":    //POS Data Grid
                begin
                    POSDataGridControl.Reset;
                    if PAGE.RunModal(BOUtils.getLookupPage(Database::"LSC POS Data Grid Control"), POSDataGridControl) = ACTION::LookupOK then
                        Param := POSDataGridControl."Control ID";
                end;
            ParamType::Store:    //Store
                begin
                    Store.Reset;
                    if PAGE.RunModal(BOUtils.getLookupPage(Database::"LSC Store"), Store) = ACTION::LookupOK then
                        Param := Store."No.";
                end;
            ParamType::MenuType:    //Menu Type
                begin
                    if POSSession.StoreNo <> '' then
                        RestaurantMenuType.SetRange("Restaurant No.", POSSession.StoreNo);
                    RestaurantMenuType.SetRange("Code on POS", Param);
                    if RestaurantMenuType.FindFirst then;
                    RestaurantMenuType.SetRange("Code on POS");
                    if PAGE.RunModal(Page::"LSC Restaurant Menu Types", RestaurantMenuType) = ACTION::LookupOK then
                        Param := RestaurantMenuType."Code on POS";
                end;
            ParamType::StandardText:    //StandardText
                begin
                    HospStandardText.SetRange(Description, Param);
                    if HospStandardText.FindFirst then;
                    HospStandardText.SetRange(Description);
                    if PAGE.RunModal(Page::"LSC Hosp. Standard Texts", HospStandardText) = ACTION::LookupOK then
                        Param := HospStandardText.Description;
                end;
            ParamType::"POS Search":    //POS Search
                begin
                    if PAGE.RunModal(Page::"LSC POS Search List", POSSearch) = ACTION::LookupOK then
                        Param := POSSearch."Search ID";
                end;
            ParamType::RetailCharge:    //RetailCharge
                begin
                    if RetailCharge.Get(Param) then;
                    if PAGE.RunModal(Page::"LSC Retail Charge List", RetailCharge) = ACTION::LookupOK then
                        Param := RetailCharge."Charge Code";
                end;
            ParamType::"POS Dyn. Menu":    //POS Dyn. Menu
                begin
                    if POSDynamicMenu.Get(Param) then;
                    if PAGE.RunModal(Page::"LSC POS Dynamic Menus", POSDynamicMenu) = ACTION::LookupOK then
                        Param := POSDynamicMenu.ID;
                end;
            ParamType::Attribute:    //Attribute
                begin
                    if StrPos(Param, '|') = 0 then
                        if Attribute.Get(Param) then;
                    if PAGE.RunModal(Page::"LSC Attributes", Attribute) = ACTION::LookupOK then
                        if StrPos(Param, '|') = StrLen(Param) then
                            Param := Param + Attribute.Code
                        else
                            if StrLen(Param) > 0 then
                                Param := Param + '|' + Attribute.Code
                            else
                                Param := Attribute.Code;
                end;
            ParamType::"Attribute Group":    //AttributeGroup
                begin
                    if AttributeGroup.Get(Param) then;
                    if PAGE.RunModal(Page::"LSC Attribute Groups", AttributeGroup) = ACTION::LookupOK then
                        Param := AttributeGroup.Code;
                end;

            ParamType::"Hardware Profile":    //Hardware Profile
                begin
                    if HardwareProfile.Get(Param) then;
                    if PAGE.RunModal(Page::"LSC POS Hardware Profile List", HardwareProfile) = ACTION::LookupOK then
                        Param := HardwareProfile."Profile ID";
                end;

            ParamType::"Dining Area":    //Dining Area
                begin
                    if DiningArea.Get(Param) then;
                    if PAGE.RunModal(Page::"LSC Dining Areas", DiningArea) = ACTION::LookupOK then
                        Param := DiningArea.ID;
                end;
            ParamType::"LSC Comment Category":
                begin
                    if LSCCommentCategory.Get(Param) then;
                    if PAGE.RunModal(Page::"LSC Comment Categories", LSCCommentCategory) = ACTION::LookupOK then
                        Param := LSCCommentCategory.Code;
                end;
            ParamType::"LSC Activity Resource Group":
                begin
                    if ActResourceGroup.Get(Param) then;
                    if PAGE.RunModal(Page::"LSC Activity Resource Groups", ActResourceGroup) = ACTION::LookupOK then
                        Param := ActResourceGroup.Code;
                end;
            ParamType::"LSC Reservation Type":
                begin
                    if ReservationType.Get(Param) then;
                    if Page.RunModal(Page::"LSC Reservation Types", ReservationType) = ACTION::LookupOK then
                        Param := ReservationType.Code;
                end;
            ParamType::"LSC Activity Type":
                begin
                    if PAGE.RunModal(Page::"LSC Activity Types", ActivityTypes) = ACTION::LookupOK then
                        Param := ActivityTypes.Code;
                end;
            ParamType::"LSC Activity Access Type":
                begin
                    AccessTypeTempRec.BuildRecord(AccessTypeTempRec);

                    if PAGE.RunModal(Page::"LSC ACT Access Types", AccessTypeTempRec) = ACTION::LookupOK then
                        Param := AccessTypeTempRec."Access Link Type";
                end;
            else
                Param := DynamicLookup(Command, Param);
        end;
    end;

    local procedure DynamicLookup(Command: Code[20]; Param: Text[100]): Text[100]
    var
        AttribOptionsTMP: Record "LSC Attribute Option Value" temporary;
        TableLink: RecordRef;
        FieldLink: FieldRef;
        NxtSeq: Integer;
        PosCommand: Record "LSC POS Command";
    begin
        if PosCommand.Get(Command) then
            if PosCommand."Table Link" > 0 then begin
                NxtSeq := 1000;
                TableLink.Open(PosCommand."Table Link");
                if TableLink.FindSet then
                    repeat
                        FieldLink := TableLink.FieldIndex(1);
                        AttribOptionsTMP."Attribute Code" := Format(FieldLink.Value);
                        if PosCommand."Field Link" = 0 then
                            FieldLink := TableLink.FieldIndex(2)
                        else
                            FieldLink := TableLink.FieldIndex(PosCommand."Field Link");
                        AttribOptionsTMP."Option Value" := Format(FieldLink.Value);
                        AttribOptionsTMP.Sequence := NxtSeq;
                        AttribOptionsTMP.Insert(false);
                        NxtSeq := NxtSeq + 1000;
                    until TableLink.Next = 0;
                TableLink.Close;
                if AttribOptionsTMP.FindFirst then begin
                    Commit;
                    if PAGE.RunModal(Page::"LSC Attr. Options Lookup", AttribOptionsTMP) = ACTION::LookupOK then
                        exit(AttribOptionsTMP."Option Value");
                end;
            end;
        exit(Param);
    end;

    internal procedure ValidateParameter(Param: Text[100]; ParameterType: Enum "LSC POS Command Parameter Type"; Command: Code[20])
    var
        RestaurantMenuType: Record "LSC Restaurant Menu Type";
        POSParameterSetup: Record "LSC POS Parameter Setup";
        InParameterSetup: Boolean;
        MenuTypeValidationError: Label 'There is no %1 with %2 %3.';
    begin
        if Param = '' then
            exit;
        case ParameterType of
            ParameterType::MenuType: //Menu Type
                begin
                    POSParameterSetup.SetRange("Code Type", POSParameterSetup."Code Type"::"POS Command");
                    POSParameterSetup.SetRange(Code, Command);
                    POSParameterSetup.SetRange("Parameter Code", Param);
                    InParameterSetup := not POSParameterSetup.IsEmpty;

                    if POSSession.StoreNo <> '' then
                        RestaurantMenuType.SetRange("Restaurant No.", POSSession.StoreNo);
                    RestaurantMenuType.SetRange("Code on POS", Param);
                    if RestaurantMenuType.IsEmpty then
                        if not InParameterSetup then
                            Error(MenuTypeValidationError, RestaurantMenuType.TableCaption, RestaurantMenuType.FieldCaption("Code on POS"), Param);
                end;
        end;
    end;

    internal procedure LookupParameterSetup(POSCommandCode: Code[20]): Code[20]
    var
        POSParameterSetup: Record "LSC POS Parameter Setup";
        ParameterPage: Page "LSC POS Parameter Setup";
        Result: Action;
    begin
        Clear(ParameterPage);

        POSParameterSetup.SetRange("Code Type", POSParameterSetup."Code Type"::"POS Command");
        POSParameterSetup.SetRange(Code, POSCommandCode);
        ParameterPage.SetTableView(POSParameterSetup);
        ParameterPage.LookupMode(true);
        Result := ParameterPage.RunModal;
        if Result = ACTION::LookupOK then begin
            ParameterPage.GetRecord(POSParameterSetup);
            exit(POSParameterSetup."Parameter Code");
        end;
        exit('');
    end;

    procedure ParameterLookupFromDataGrid(POSDataTableColumn: Record "LSC POS Data Table Columns"): text
    var
        POSDataTableColParamPage: Page "LSC POS Data Table Col. Params";
        POSDataTableColParam: Record "LSC POS Data Table Col. Param";
        Result: Action;
    begin
        Clear(POSDataTableColParamPage);

        POSDataTableColParam.SetRange("Data Table ID", POSDataTableColumn."Data Table ID");
        POSDataTableColParam.SetRange("Table No.", POSDataTableColumn."Table No.");
        POSDataTableColParam.SetRange("Column No.", POSDataTableColumn."Column No.");

        POSDataTableColParamPage.SetTableView(POSDataTableColParam);
        POSDataTableColParamPage.LookupMode(true);
        Result := POSDataTableColParamPage.RunModal;
        if Result = ACTION::LookupOK then begin
            POSDataTableColParamPage.GetRecord(POSDataTableColParam);
            exit(POSDataTableColParam."Parameter Code")
        end;
    end;

    internal procedure ParameterLookupFromPOSMenuLine(var POSMenuLine: record "LSC POS Menu Line"; CommandSeq: Integer)
    var
        POSButtonParametersPage: Page "LSC POS Button Parameters";
        POSButtonParameter: Record "LSC POS Button Parameters";
        Result: Action;
    begin
        Clear(POSButtonParametersPage);

        POSButtonParameter.SetRange(POSButtonParameter."Menu ID", POSMenuLine."Menu ID");
        POSButtonParameter.SetRange(POSButtonParameter."POS Menu Profile ID", POSMenuLine."Profile ID");

        case CommandSeq of
            0:
                POSButtonParameter.SetRange(POSButtonParameter."POS Command", POSMenuLine.Command);
            1:
                POSButtonParameter.SetRange(POSButtonParameter."POS Command", POSMenuLine."Post Command");
        end;

        POSButtonParameter.SetRange(POSButtonParameter."Key No.", POSMenuLine."Key No.");

        POSButtonParametersPage.SetTableView(POSButtonParameter);
        POSButtonParametersPage.LookupMode(true);
        Result := POSButtonParametersPage.RunModal;
        if Result = ACTION::LookupOK then begin
            POSButtonParametersPage.GetRecord(POSButtonParameter);
            case CommandSeq of
                0:
                    begin
                        if (POSMenuLine."Parameter Type" = POSMenuLine."Parameter Type"::" ") or (POSMenuLine.Parameter = '') then //don't overwrite the lookup parameter
                            POSMenuLine.Parameter := POSButtonParameter."Parameter Code";
                    end;
                1:
                    POSMenuLine."Post Parameter" := POSButtonParameter."Parameter Code";
            end;
        end;
        OnAfterParameterLookupFromPOSMenuLine(POSMenuLine, CommandSeq, POSButtonParameter);
    end;

    internal procedure CommandFromEnum(CommandEnum: Enum "LSC POS Command") CommandCode: Code[20]
    begin
        CommandCode := Format(CommandEnum);
        if not CommandExists(CommandCode) then
            exit(''); // Invalid Enums, like Format(-1) -> '-1', instead we return ''
    end;

    procedure CommandToEnum(CommandCode: Code[20]) CommandEnum: Enum "LSC POS Command"
    begin
        CommandExists(CommandCode, CommandEnum);
    end;

    procedure CommandExists(CommandCode: Code[20]): Boolean
    var
        CommandEnum: Enum "LSC POS Command";
    begin
        exit(CommandExists(CommandCode, CommandEnum))
    end;

    internal procedure CommandExists(CommandCode: Code[20]; var CommandEnum: Enum "LSC POS Command"): Boolean
    var
        Idx: Integer;
    begin
        CommandEnum := Enum::"LSC POS Command"::" ";
        if Format(CommandCode).Trim() = '' then
            exit; // ' ' -> '' (value 0)
        Idx := CommandEnum.Names.IndexOf(CommandCode);
        if Idx <= 0 then
            exit;
        CommandEnum := Enum::"LSC Pos Command".FromInteger(CommandEnum.Ordinals.Get(Idx));
        exit(true);
    end;

    [InternalEvent(true)]
    local procedure OnAfterParameterLookupFromPOSMenuLine(var POSMenuLine: record "LSC POS Menu Line"; CommandSeq: Integer; POSButtonParameter: Record "LSC POS Button Parameters")
    begin
    end;
}

