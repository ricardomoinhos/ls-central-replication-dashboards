codeunit 10016139 "LSC POS Formatting"
{
    SingleInstance = True;

    var
        PosSession: Codeunit "LSC POS Session";
        AppMan: Codeunit "LSC AutoFormatMgt Ext.";
        AmountDisplayFormat: Text[80];
        QtyDisplayFormat: Text[80];
        PriceDisplayFormat: Text[80];
        WeightDisplayFormat: Text[80];

    procedure Init()
    begin
        AmountDisplayFormat := '';
        WeightDisplayFormat := '';
        PriceDisplayFormat := '';
        QtyDisplayFormat := '';
    end;

    procedure FormatAmount(Dec: Decimal): Text[30]
    begin
        if AmountDisplayFormat = '' then
            AmountDisplayFormat := AppMan.DoAutoFormatTranslateExt("Auto Format"::"LSC Pos Amount", PosSession.Store."No.");
        exit(Format(Dec, 0, AmountDisplayFormat));
    end;

    procedure FormatPrice(Dec: Decimal): Text[30]
    begin
        if PriceDisplayFormat = '' then
            PriceDisplayFormat := AppMan.DoAutoFormatTranslateExt("Auto Format"::"LSC Pos Price", PosSession.Store."No.");
        exit(Format(Dec, 0, PriceDisplayFormat));
    end;

    procedure FormatQty(Dec: Decimal): Text[30]
    begin
        if QtyDisplayFormat = '' then
            QtyDisplayFormat := AppMan.DoAutoFormatTranslateExt("Auto Format"::"LSC Pos Qty", '');
        exit(Format(Dec, 0, QtyDisplayFormat));
    end;

    procedure FormatWeight(Dec: Decimal; UOM: Code[10]): Text[30]
    begin
        if WeightDisplayFormat = '' then
            WeightDisplayFormat := AppMan.DoAutoFormatTranslateExt("Auto Format"::"LSC Pos Qty", UOM);
        exit(Format(Dec, 0, WeightDisplayFormat) + LowerCase(UOM));
    end;

    procedure FormatPricePrUnit(Dec: Decimal; UOM: Code[10]): Text[30]
    begin
        exit(FormatPriceWithCurrencySymbol(Dec) + '/' + LowerCase(UOM));
    end;

    procedure FormatPriceWithCurrencySymbol(DecimalValue: Decimal): Text
    begin
        if PosSession.FunctionalityProfile."Placement of LCY in Weight" = PosSession.FunctionalityProfile."Placement of LCY in Weight"::"After the Amount" then
            exit(FormatPrice(DecimalValue) + PosSession.GetValue("LSC POS Tag"::"CURRSYM"));
        exit(PosSession.GetValue("LSC POS Tag"::"CURRSYM") + FormatPrice(DecimalValue));
    end;

    procedure FormatCurrency(Value: Decimal; CurrCode: Code[10]): Text[30]
    begin
        exit(Format(Value, 0, AppMan.DoAutoFormatTranslateExt(1, CurrCode)));
    end;

    procedure AdjustAmount(var Value: Decimal)
    var
        PosFunc: Codeunit "LSC POS Functions";
    begin
        PosFunc.OnBeforeAdjustAmount(Value);
        if PosSession.FunctionalityProfile."Decimal Places in Entry" = 0 then
            exit;

        AdjustAmount(Value, -PosSession.FunctionalityProfile."Decimal Places in Entry");
    end;

    internal procedure AdjustAmount(var Value: Decimal; Decimals: Integer)
    begin
        Value := Round(Value * Power(10, Decimals));
    end;

    procedure AdjustAmountToShow(var Value: Decimal)
    begin
        if PosSession.FunctionalityProfile."Decimal Places in Entry" = 0 then
            exit;

        AdjustAmount(Value, PosSession.FunctionalityProfile."Decimal Places in Entry");
    end;

    procedure FormatAmountToShow(Value: Decimal): Text[30]
    var
        xAmount: Decimal;
        xAmountTxt: Text[30];
        xThousandToken: Text[1];
    begin
        if PosSession.FunctionalityProfile."Decimal Places in Entry" = 0 then
            exit(Format(Value, 0, StrSubstNo('<Precision,%1><Standard Format,0>', PosSession.FunctionalityProfile."Price Decimal Places")));

        xAmount := 1000;
        xAmountTxt := Format(xAmount);
        xThousandToken := DelChr(xAmountTxt, '=', '0123456789');
        exit(DelChr(Format(Value), '=', xThousandToken))
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"LSC POS Session", OnStoreChanged, '', false, false)]
    local procedure OnStoreChanged(oldStoreNo: Text; newStoreNo: Text)
    begin
        if newStoreNo = '' then
            exit;
        AmountDisplayFormat := '';
        PriceDisplayFormat := '';
    end;
}