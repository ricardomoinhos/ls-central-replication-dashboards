codeunit 99008880 "LSC DataSet"
{
    var
        _containsSkins: Boolean;
        _containsFonts: Boolean;
        _containsSelectable: Boolean;
        _containsRecIds: Boolean;
        _firstColumnIndex: Integer;
        _goToRowIndex: Integer;
        _startPageNo: Integer;
        _pageCount: Integer;
        _markMode: Integer;
        _maxMarkCount: Integer;
        _prefix: Text;
        _tableName: Text;
        _mergData: Boolean;

        _rows: JsonArray;
        _columns: JsonArray;

        _workRowIndex: Integer;

        _filters: JsonObject;// Dictionary of [Integer, Text];

        _id: Text;
        _tableNo: Integer;
        _dbTableRowCount: Integer;
        _dbTablePageSize: Integer;
        _visibleColumns: Integer;
        _defaultColumn: Integer;
        _sortColumn: Integer;
        _sortAscending: Boolean;

        _tagText: Text;
        _dataSetName: Text;

    procedure GetRows(): Integer
    begin
        exit(_rows.Count);
    end;

    procedure GetDataRows(): JsonArray
    begin
        exit(_rows);
    end;

    procedure GetColumns(): Integer
    begin
        exit(_columns.Count);
    end;

    procedure Id(pNewValue: Text)
    begin
        _id := pNewValue;
    end;

    procedure GetId(): Text
    begin
        exit(_id);
    end;

    procedure TableNo(pNewValue: Integer)
    begin
        _tableNo := pNewValue;
    end;

    procedure GetTableNo(): Integer
    begin
        exit(_tableNo);
    end;

    procedure DBTableRowCount(pNewValue: Integer)
    begin
        _dbTableRowCount := pNewValue;
    end;

    procedure GetDBTableRowCount(): Integer
    begin
        exit(_dbTableRowCount);
    end;

    procedure DBTablePageSize(pNewValue: Integer)
    begin
        _dbTablePageSize := pNewValue;
    end;

    procedure GetDBTablePageSize(): Integer
    begin
        exit(_dbTablePageSize);
    end;

    procedure VisibleColumns(pNewValue: Integer)
    begin
        _visibleColumns := pNewValue;
    end;

    procedure DefaultColumn(pNewValue: Integer)
    begin
        _defaultColumn := pNewValue;
    end;

    procedure SortColumn(pNewValue: Integer)
    begin
        _sortColumn := pNewValue;
    end;

    procedure GetSortColumn(): Integer
    begin
        exit(_sortColumn);
    end;

    procedure SortAscending(pNewValue: Boolean)
    begin
        _sortAscending := pNewValue;
    end;

    procedure GetSortAscending(): Boolean
    begin
        exit(_sortAscending);
    end;

    procedure GoToRowIndex(pNewValue: Integer)
    begin
        _goToRowIndex := pNewValue + 1; //This is initalized as 0 but we want to return -1 if not set
    end;

    procedure GetGoToRowIndex(): Integer
    begin
        exit(_goToRowIndex - 1); //This is initalized as 0 but we want to return -1 if not set
    end;

    procedure StartPageNo(pNewValue: Integer)
    begin
        _startPageNo := pNewValue;
    end;

    procedure GetStartPageNo(): Integer
    begin
        exit(_startpageNo);
    end;

    procedure PageCount(pNewValue: Integer)
    begin
        _pageCount := pNewValue;
    end;

    procedure GetPageCount(): Integer
    begin
        exit(_pageCount);
    end;

    procedure MarkMode(pNewValue: Integer)
    begin
        _markMode := pNewValue;
    end;

    procedure MergeData(pNewValue: Boolean)
    begin
        _mergData := pNewValue;
    end;

    procedure MaxMarkCount(pNewValue: Integer)
    begin
        _maxMarkCount := pNewValue;
    end;

    procedure Prefix(pNewValue: Text)
    begin
        _prefix := pNewValue;
    end;

    procedure TagText(pNewValue: Text)
    begin
        _tagText := pNewValue;
    end;

    procedure GetTagText(): Text
    begin
        exit(_tagText);
    end;

    procedure DataSetName(pNewValue: Text)
    begin
        _dataSetName := pNewValue;
    end;

    procedure GetDataSetName(): Text
    begin
        exit(_dataSetName);
    end;

    procedure SelectRow(pZeroBasedRowIndex: Integer)
    begin
        _workRowIndex := pZeroBasedRowIndex;
    end;
    /*procedure ContainsRecIDs(pNewValue: Boolean)
    begin
        _containsRecIds := pNewValue;
    end;*/
    procedure GetColumnName(columnZeroBasedIndex: Integer): Text
    var
        tableColumn: JsonToken;
        columnName: JsonToken;
    begin
        if not _columns.Get(columnZeroBasedIndex, tableColumn) then
            exit('');

        if not tableColumn.AsObject().Get('ColumnName', columnName) then
            exit('');

        exit(columnName.AsValue().AsText());
    end;

    procedure GetColumnFieldNo(columnZeroBasedIndex: Integer): Integer
    var
        tableColumn: JsonToken;
        columnFieldNo: JsonToken;
    begin
        if not _columns.Get(columnZeroBasedIndex, tableColumn) then
            exit(0);

        if not tableColumn.AsObject().Get('ColumnNo', columnFieldNo) then begin
            if not tableColumn.AsObject().Get('ExtendedProperties', columnFieldNo) then
                exit(0);
            if not columnFieldNo.AsObject().Get('ColumnNo', columnFieldNo) then
                exit(0);
        end;

        exit(columnFieldNo.AsValue().AsInteger());
    end;

    procedure GetColumnType(columnZeroBasedIndex: Integer): Integer
    var
        tableColumn: JsonToken;
        columnType: JsonToken;
    begin
        if not _columns.Get(columnZeroBasedIndex, tableColumn) then
            exit(0);

        if not tableColumn.AsObject().Get('DataType', columnType) then
            exit(0);

        exit(VerifyColumnTypeInteger(columnType));
    end;

    local procedure VerifyColumnTypeInteger(columnType: JsonToken): Integer
    var
        typeValue: JsonValue;
        txt: Text;
        int: Integer;
    begin
        typeValue := columnType.AsValue();
        txt := typeValue.AsText();
        if Evaluate(int, txt) then
            exit(typeValue.AsInteger());

        case True of
            txt.StartsWith('System.String'):
                exit(0);
            txt.StartsWith('System.Int32'):
                exit(1);
            txt.StartsWith('System.Double'):
                exit(2);
            txt.StartsWith('System.DateTime'):
                exit(3);
            txt.StartsWith('System.Boolean'):
                exit(4);
            txt.StartsWith('System.Byte[]'):
                exit(5);
            else
                exit(0);
        end;
    end;

    procedure FilterString(pNewValue: Text)
    var
        filters: List of [Text];
        i: Integer;
        tmpText: Text;
    begin
        filters := pNewValue.Split('§');
        for i := 1 to filters.Count do begin
            if (_columns.Count = 0) OR (i <= _columns.Count) then begin
                filters.Get(i, tmpText);
                if _filters.Keys.Contains(FORMAT(i - 1)) then
                    _filters.Replace(FORMAT(i - 1), tmpText)
                else
                    _filters.Add(FORMAT(i - 1), tmpText);
            end;
        end;
    end;

    procedure FixedFilterString(pNewValue: Text)
    var
        filters: List of [Text];
        i: Integer;
        tmpText: Text;
    begin
        filters := pNewValue.Split('§');
        for i := 1 to filters.Count do begin
            filters.Get(i, tmpText);
            if tmpText <> '' then
                if _filters.Keys.Contains(FORMAT(i - 1)) then
                    _filters.Replace(FORMAT(i - 1), tmpText)
                else
                    _filters.Add(FORMAT(i - 1), tmpText);
        end;
    end;

    procedure GetFilterString() retval: Text
    begin
        _filters.WriteTo(retval);
    end;

    procedure GetColumnFilter(columnZeroBasedIndex: Integer): Text
    var
        token: JsonToken;
    begin
        if not _filters.Keys.Contains(FORMAT(columnZeroBasedIndex)) then
            exit('');

        _filters.Get(FORMAT(columnZeroBasedIndex), token);
        exit(token.AsValue().AsText());
    end;

    local procedure ClearTable()
    begin
        Clear(_rows);
        Clear(_columns);
    end;

    procedure ClearDataSet()
    begin
        ClearTable();
        Clear(_filters);
        _containsSkins := false;
        _containsFonts := false;
        _containsSelectable := false;
        _goToRowIndex := 0;
        _markMode := 0;
        _maxMarkCount := 0;
        _visibleColumns := 0;
    end;

    procedure FromJSON(pJson: Text)
    var
        json: JsonObject;
        token: JsonToken;
        tables: JsonObject;
    begin
        json.ReadFrom(pJson);
        ClearDataSet();

        json.Get('Id', token);
        _id := token.AsValue().AsText();
        json.Get('TableNo', token);
        _tableNo := token.AsValue().AsInteger();
        json.Get('DbTableRowCount', token);
        _dbTableRowCount := token.AsValue().AsInteger();
        json.Get('DbTablePageSize', token);
        _dbTablePageSize := token.AsValue().AsInteger();
        json.Get('VisibleColumns', token);
        _visibleColumns := token.AsValue().AsInteger();
        json.Get('DefaultColumn', token);
        _defaultColumn := token.AsValue().AsInteger();
        json.Get('SortColumn', token);
        _sortColumn := token.AsValue().AsInteger();
        json.Get('SortAscending', token);
        _sortAscending := token.AsValue().AsBoolean();
        json.Get('TagText', token);
        _tagText := token.AsValue().AsText();
        json.Get('DataSetName', token);
        _dataSetName := token.AsValue().AsText();
        json.Get('ContainsSkins', token);
        _containsSkins := token.AsValue().AsBoolean();
        json.Get('ContainsFonts', token);
        _containsFonts := token.AsValue().AsBoolean();
        json.Get('ContainsSelectable', token);
        _containsSelectable := token.AsValue().AsBoolean();
        json.Get('ContainsRecIDs', token);
        _containsRecIds := token.AsValue().AsBoolean();
        json.Get('FirstColumnIndex', token);
        _firstColumnIndex := token.AsValue().AsInteger();
        json.Get('GoToRowIndex', token);
        GoToRowIndex(token.AsValue().AsInteger());
        json.Get('StartPageNo', token);
        _startPageNo := token.AsValue().AsInteger();
        json.Get('PageCount', token);
        _pageCount := token.AsValue().AsInteger();
        json.Get('MarkMode', token);
        _markMode := token.AsValue().AsInteger();
        json.Get('MaxMarkCount', token);
        _maxMarkCount := token.AsValue().AsInteger();
        json.Get('Prefix', token);
        _prefix := token.AsValue().AsText();
        json.Get('MergeData', token);
        _mergData := token.AsValue().AsBoolean();

        json.Get('m_filters', token);
        _filters := token.AsObject();

        json.Get('Tables', token);
        token.AsArray().Get(0, token);
        tables := token.AsObject();
        tables.Get('Columns', token);
        _columns := token.AsArray();
        tables.Get('Rows', token);
        _rows := token.AsArray();
    end;

    procedure ToJSON(pWithSchema: Boolean) retVal: Text
    begin
        ToJSONObject(pWithSchema).WriteTo(retVal);
    end;

    procedure ToJSONObject(pWithSchema: Boolean) retVal: JSonObject
    var
        json: JsonObject;
        datatable: JsonObject;
        tables: JsonArray;
    begin
        if _dbTablePageSize = 0 then
            _dbTablePageSize := 10;

        json.Add('Id', _id);
        json.Add('TableNo', _tableNo);
        json.Add('DbTableRowCount', _dbTableRowCount);
        json.Add('DbTablePageSize', _dbTablePageSize);
        json.Add('VisibleColumns', _visibleColumns);
        json.Add('DefaultColumn', _defaultColumn);
        json.Add('SortColumn', _sortColumn);
        json.Add('SortAscending', _sortAscending);
        json.Add('TagText', _tagText);
        json.Add('DataSetName', _dataSetName);
        json.Add('ContainsSkins', _containsSkins);
        json.Add('ContainsFonts', _containsFonts);
        json.Add('ContainsSelectable', _containsSelectable);
        json.Add('ContainsRecIDs', _containsRecIds);
        json.Add('FirstColumnIndex', _firstColumnIndex);
        json.Add('GoToRowIndex', GetGoToRowIndex());
        json.Add('StartPageNo', _startPageNo);
        json.Add('PageCount', _pageCount);
        json.Add('MarkMode', _markMode);
        json.Add('MergeData', _mergData);
        json.Add('MaxMarkCount', _maxMarkCount);
        json.Add('Prefix', _prefix);
        json.Add('Columns', (_columns.Count - 1));
        json.Add('Rows', _rows.Count);

        json.Add('m_filters', _filters);

        datatable.Add('TableName', _tableName);
        datatable.Add('Columns', _columns);
        datatable.Add('Rows', _rows);
        tables.Add(datatable);
        json.Add('Tables', tables);

        exit(json);
    end;

    procedure CreateTable(tableName: Text)
    var
        columnType: Enum "LSC ColumnType";
    begin
        _tableName := tableName;
        ClearTable();
        AddColumn('#KEY', columnType::Integer);
        _firstColumnIndex := 1;
    end;

    procedure AddColumn(columnName: Text; columnTypeInt: Integer)
    begin
        AddColumnEx(columnName, "LSC ColumnType".FromInteger(columnTypeInt), columnName, 0);
    end;

    procedure AddColumn(columnName: Text; columnType: Enum "LSC ColumnType")
    begin
        AddColumnEx(columnName, columnType, columnName, 0);
    end;

    procedure AddColumnEx(columnName: Text; columnTypeInt: Integer; columnCaption: Text; columnNo: Integer)
    begin
        AddColumnEx(columnName, "LSC ColumnType".FromInteger(columnTypeInt), columnCaption, columnNo);
    end;

    procedure AddColumnEx(columnName: Text; columnType: Enum "LSC ColumnType"; columnCaption: Text; columnNo: Integer)
    var
        tableColumn: JsonObject;
        extendedProps: JsonObject;
    begin
        case columnName of
            '#SELECTABLE#':
                _containsSelectable := true;
            '#SKIN_ID#':
                _containsSkins := true;
            '#FONT_ID#':
                _containsFonts := true;
            '#REC_ID#':
                _containsRecIds := true;
        end;

        tableColumn.Add('ColumnName', columnName);
        tableColumn.Add('DataType', columnType.AsInteger());
        tableColumn.Add('Caption', columnCaption);
        tableColumn.Add('ColumnNo', columnNo);

        extendedProps.Add('ColumnNo', columnNo);
        extendedProps.Add('ColumnType', columnType.AsInteger());

        tableColumn.add('ExtendedProperties', extendedProps);

        _columns.Add(tableColumn);
    end;

    procedure SetGlyphDataColumn(colIndex: integer; glyphDataColumn: integer)
    begin
        CheckSetColumnExtendedAttribute(colIndex, 'GlyphDataColumn', glyphDataColumn);
    end;

    procedure SetOptionMembersColumn(colIndex: integer; OptionMembers: Text)
    begin
        CheckSetColumnExtendedAttribute(colIndex, 'OptionMembers', OptionMembers);
    end;

    procedure SetColumnAttribute(columnZeroBasedIndex: Integer; pName: Text; pValue: Variant)
    var
        tableColumn: JsonToken;
        pValueInt: integer;
        pValueBool: boolean;
        pValueText: text;
    begin
        if CheckSetColumnExtendedAttribute(columnZeroBasedIndex, pName, pValue) then
            exit;

        if not _columns.Get(columnZeroBasedIndex, tableColumn) then
            exit;

        case true of
            pValue.IsInteger,
            pValue.IsBigInteger:
                begin
                    pValueInt := pValue;
                    if tableColumn.AsObject().Contains(pName) then
                        tableColumn.AsObject().Replace(pName, pValueInt)
                    else
                        tableColumn.AsObject().Add(pName, pValueInt);
                end;
            pValue.IsBoolean:
                begin
                    pValueBool := pValue;
                    if tableColumn.AsObject().Contains(pName) then
                        tableColumn.AsObject().Replace(pName, pValueBool)
                    else
                        tableColumn.AsObject().Add(pName, pValueBool);
                end
            else begin
                pValueText := pValue;
                if tableColumn.AsObject().Contains(pName) then
                    tableColumn.AsObject().Replace(pName, pValueText)
                else
                    tableColumn.AsObject().Add(pName, pValueText);
            end
        end;
    end;

    local procedure CheckSetColumnExtendedAttribute(columnZeroBasedIndex: Integer; pName: Text; pValue: Variant): boolean
    var
        tableColumn: JsonToken;
        extended: JsonToken;
        pValueInt: integer;
        pValueBool: boolean;
        pValueText: text;
    begin
        if not (pName in [
            'POSTAG',
            'ISIMAGE',
            'KeyNo',
            'ColumnEditable',
            'ColumnAlignment',
            'ColumnWidth',
            'OptionMembers',
            'GlyphDataColumn'
        ]) then
            exit(false);

        if not _columns.Get(columnZeroBasedIndex, tableColumn) then
            exit(true);//if I cannot get column return true so we dont continue

        if not tableColumn.AsObject().Contains('ExtendedProperties') then
            tableColumn.AsObject().Add('ExtendedProperties', extended);

        if tableColumn.AsObject().SelectToken('ExtendedProperties', extended) then begin
            case true of
                pValue.IsInteger,
                pValue.IsBigInteger:
                    begin
                        pValueInt := pValue;
                        if extended.AsObject().Contains(pName) then
                            extended.AsObject().Replace(pName, pValueInt)
                        else
                            extended.AsObject().Add(pName, pValueInt);
                    end;
                pValue.IsBoolean:
                    begin
                        pValueBool := pValue;
                        if extended.AsObject().Contains(pName) then
                            extended.AsObject().Replace(pName, pValueBool)
                        else
                            extended.AsObject().Add(pName, pValueBool);
                    end
                else begin
                    pValueText := pValue;
                    if extended.AsObject().Contains(pName) then
                        extended.AsObject().Replace(pName, pValueText)
                    else
                        extended.AsObject().Add(pName, pValueText);
                end
            end;
            exit(true);
        end;
        exit(false);
    end;

    procedure InsertRow(pKey: Integer): Boolean
    var
        tableRow: JsonObject;
        //tmpColumn: JsonToken;
        //tmpColumnName: JsonToken;
        emptyToken: JsonToken;
        i: Integer;
    begin
        tableRow.Add('0', pKey);

        for i := 1 to _columns.Count - 1 do begin
            tableRow.Add(FORMAT(i), emptyToken);
        end;

        _rows.Add(tableRow);
        _workRowIndex := _rows.Count - 1;
    end;

    procedure NewRow()
    begin
        InsertRow(_Rows.Count);
    end;

    procedure SetJsonValue(columnZeroBasedIndex: Integer; pNewValue: JSonValue): Boolean //CAN WE PASS VARIANT to this?
    var
        token: JsonToken;
        tableRow: JsonObject;
    begin
        if columnZeroBasedIndex > 0 then begin  //0 index preserved for #KEY
            if not _rows.Get(_workRowIndex, token) then
                exit;
            tableRow := token.AsObject();

            //exit(tableRow.Replace(GetColumnName(columnZeroBasedIndex), pNewValue));
            exit(tableRow.Replace(FORMAT(columnZeroBasedIndex), pNewValue));
        end;
    end;

    procedure SetValue(columnZeroBasedIndex: Integer; pNewValue: Text): Boolean
    var
        v: JsonValue;
    begin
        v.SetValue(pNewValue);
        exit(SetJsonValue(columnZeroBasedIndex, v));
    end;

    procedure SetValue(columnZeroBasedIndex: Integer; pNewValue: Integer): Boolean
    var
        v: JsonValue;
    begin
        v.SetValue(pNewValue);
        exit(SetJsonValue(columnZeroBasedIndex, v));
    end;

    procedure SetValue(columnZeroBasedIndex: Integer; pNewValue: Decimal): Boolean
    var
        v: JsonValue;
    begin
        v.SetValue(pNewValue);
        exit(SetJsonValue(columnZeroBasedIndex, v));
    end;

    procedure SetValue(columnZeroBasedIndex: Integer; pNewValue: DateTime): Boolean
    var
        v: JsonValue;
    begin
        v.SetValue(pNewValue);
        exit(SetJsonValue(columnZeroBasedIndex, v));
    end;

    procedure SetValue(columnZeroBasedIndex: Integer; pNewValue: Date): Boolean
    var
        v: JsonValue;
    begin
        v.SetValue(pNewValue);
        exit(SetJsonValue(columnZeroBasedIndex, v));
    end;

    procedure GetValue(columnZeroBasedIndex: Integer; var pValue: Variant): Boolean
    var
        token: JsonToken;
        tableRow: JsonObject;
    begin
        if columnZeroBasedIndex <= 0 then //0 index preserved for #KEY
            exit(false);

        if not _rows.Get(_workRowIndex, token) then
            exit(false);

        tableRow := token.AsObject();

        if not tableRow.Get(format(columnZeroBasedIndex), token) then begin
            //get ColumnName if row data is not index based but ColumnName key based
            if _columns.Get(columnZeroBasedIndex, token) then begin
                if token.AsObject().Get('ColumnName', token) then begin
                    if tableRow.Get(token.AsValue().AsText(), token) then begin
                        if token.AsValue().IsNull OR token.AsValue().IsUndefined then begin
                            pValue := '';
                            exit(true);
                        end;
                        pValue := token.AsValue().AsText();
                        exit(true);
                    end;
                end;
            end;
            exit(false);
        end;

        if token.AsValue().IsNull OR token.AsValue().IsUndefined then begin
            pValue := '';
            exit(true);
        end;
        pValue := token.AsValue().AsText();
        exit(true);
    end;

    procedure GetValueAsString(columnZeroBasedIndex: Integer; var pValue: Text): Boolean
    var
        token: JsonToken;
        tableRow: JsonObject;
        intPlaceHolder: Integer;
    begin
        if columnZeroBasedIndex <= 0 then //0 index preserved for #KEY
            exit(false);

        if not _rows.Get(_workRowIndex, token) then
            exit(false);

        tableRow := token.AsObject();

        if (Evaluate(intPlaceHolder, tableRow.Keys().Get(1))) then begin
            if not tableRow.Get(format(columnZeroBasedIndex), token) then
                exit(false);
        end
        else begin
            if not tableRow.Get(GetColumnName(columnZeroBasedIndex), token) then //supporting json key as column name
                exit(false);
        end;

        pValue := token.AsValue().AsText();
        exit(true);
    end;

    procedure GetUpdatedRecordID(OldRecordID: Text) UpdatedRecordID: RecordId
    var
        Position: integer;
        RecordKey: Text;
        TableName: Text;
        RecRef: RecordRef;
    begin
        Position := StrPos(OldRecordID, ':');
        RecordKey := CopyStr(OldRecordID, Position);

        RecRef.Open(_tableNo);
        TableName := RecRef.Name;

        Evaluate(UpdatedRecordID, TableName + RecordKey);
    end;
}