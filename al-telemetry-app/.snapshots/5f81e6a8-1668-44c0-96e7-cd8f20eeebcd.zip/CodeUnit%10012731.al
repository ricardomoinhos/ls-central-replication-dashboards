codeunit 10012731 "LSC POS Hardware Interface"
{
    SingleInstance = true;
    TableNo = "LSC POS Menu Line";

    var
        iPOS: Interface "LSC IEPOSControl";

    internal procedure SetClient(var pClient: Interface "LSC IEPOSControl")
    begin
        iPOS := pClient;
    end;

    procedure Print(var pPrintBufferRecRef: RecordRef): Boolean
    var
        Success: Boolean;
    begin
        LSN_POS_Devices_OnBeforePrint('', '', pPrintBufferRecRef);
        Success := iPOS.Print(pPrintBufferRecRef);
        LSN_POS_Devices_OnAfterPrint('', '', Success, '');
        exit(Success);
    end;

    procedure PrintEx(pPrinterID: Text; var pPrintBufferRecRef: RecordRef; var pErrorText: Text; pShowDialog: Boolean; pPrintJobID: Text): Boolean
    var
        Success: Boolean;
    begin
        LSN_POS_Devices_OnBeforePrint(pPrinterID, pPrintJobID, pPrintBufferRecRef);
        Success := iPOS.PrintEx(pPrinterID, pPrintBufferRecRef, pErrorText, pShowDialog, pPrintJobID);
        LSN_POS_Devices_OnAfterPrint(pPrinterID, pPrintJobID, Success, pErrorText);
        exit(Success);
    end;

    internal procedure OpenDrawer(deviceID: Text; suppressAlerts: Boolean; RunDialog: Boolean): Boolean
    begin
        LSN_POS_Devices_OnBeforeOpenDrawer(deviceID);

        exit(iPOS.OpenDrawer(deviceID, suppressAlerts, RunDialog))
    end;

    internal procedure ClearLineDisplay(deviceID: Text[20]): Boolean
    begin
        exit(iPOS.ClearLineDisplay(deviceID))
    end;

    internal procedure DisplayTextAt(deviceID: Text[20]; row: Integer; column: Integer; text: Text[30]; attribute: Integer): Boolean
    var
        EmptyTextVar: Text;
    begin
        LSN_POS_Devices_OnBeforeDisplayText2(deviceID, row, column, text, EmptyTextVar, attribute);
        exit(iPOS.DisplayTextAt(deviceID, row, column, text, attribute))
    end;

    internal procedure DisplayText(deviceID: Text[20]; txt: Text[30]; attribute: Integer): Boolean
    var
        EmptyTextVar: Text;
    begin
        LSN_POS_Devices_OnBeforeDisplayText2(deviceID, 1, 1, txt, EmptyTextVar, attribute);
        exit(iPOS.DisplayText(deviceID, txt, attribute))
    end;

    internal procedure DisplayTextEx(deviceID: Text[20]; text1: Text; text2: Text; attribute: Integer): Boolean
    begin
        LSN_POS_Devices_OnBeforeDisplayText2(deviceID, 1, 1, text1, text2, attribute);
        exit(iPOS.DisplayTextEx(deviceID, text1, text2, attribute))
    end;

    internal procedure CheckPrinterHealth(): Boolean
    begin
        exit(iPOS.CheckPrinterHealth())
    end;

    internal procedure Sound(numberOfCycles: Integer; interSoundWait: Integer): Boolean
    begin
        exit(iPOS.Sound(numberOfCycles, interSoundWait))
    end;

    internal procedure SoundImmediate(): Boolean
    begin
        exit(iPOS.SoundImmediate())
    end;

    procedure DirectIO(hwstHost: Text; hwstHttps: Boolean; deviceType: Enum "LSC Hardware Profile Devices"; deviceID: Text; command: Integer; data: Integer; stringData: Text; payload: Text)
    begin
        iPOS.DirectIO(hwstHost, hwstHttps, deviceType, deviceID, command, data, stringData, payload);
    end;

    procedure SetKeyLockState(KeyLockState: Integer)
    var
        PosSession: Codeunit "LSC POS Session";
    begin
        if KeyLockState < 0 then
            PosSession.SetValue("LSC POS Tag"::KEYLOCK, '')
        else
            PosSession.SetValue("LSC POS Tag"::KEYLOCK, Format(KeyLockState));
    end;

    procedure GetKeyLockState(): Integer
    var
        PosSession: Codeunit "LSC POS Session";
        KeyLockState: Integer;
    begin
        if Evaluate(KeyLockState, PosSession.GetValue("LSC POS Tag"::KEYLOCK)) then;
        exit(KeyLockState);
    end;

    procedure GetPrinterBitmapNo(): Integer
    var
        PosSession: Codeunit "LSC POS Session";
    begin
        if PosSession.Terminal()."Print Receipt Bitmap No." > 0 then
            exit(PosSession.Terminal()."Print Receipt Bitmap No.");
        exit(PosSession.Store()."Print Receipt Bitmap No.");
    end;

    procedure GetPrinterLogo(): Text
    var
        PosSession: Codeunit "LSC POS Session";
    begin
        if PosSession.Terminal()."Print Receipt Logo" <> '' then
            exit(PosSession.Terminal()."Print Receipt Logo");
        exit(PosSession.Store()."Print Receipt Logo");
    end;


    procedure GetDeviceAsJson(DeviceType: Enum "LSC Hardware Profile Devices"; DeviceID: Text): Text
    var
        Printer: Record "LSC POS Printer";
        Drawer: Record "LSC POS Drawer";
        Display: Record "LSC POS Display";
        MSR: Record "LSC POS MSR";
        Scanner: Record "LSC POS Scanner";
        Scale: Record "LSC POS Scale";
        EFT: Record "LSC POS EFT";
        Serial: Record "LSC POS Serial Device";
        DallasKey: Record "LSC POS Dallas Key";
        Authentication: Record "LSC POS Auth. Device";
        RFID: Record "LSC POS RFID";
        DeviceConfig: Text;
    begin
        case DeviceType of
            DeviceType::Printer:
                if Printer.Get(DeviceID) then
                    exit(Printer.AsJson());
            DeviceType::Drawer:
                if Drawer.Get(DeviceID) then
                    exit(Drawer.AsJson());
            DeviceType::Display:
                if Display.Get(DeviceID) then
                    exit(Display.AsJson());
            DeviceType::MSR:
                if MSR.Get(DeviceID) then
                    exit(MSR.AsJson());
            DeviceType::Scanner:
                if Scanner.Get(DeviceID) then
                    exit(Scanner.AsJson());
            DeviceType::Scale:
                if Scale.Get(DeviceID) then
                    exit(Scale.AsJson());
            DeviceType::Serial:
                if Serial.Get(DeviceID) then
                    exit(Serial.AsJson());
            DeviceType::DallasKey:
                if DallasKey.Get(DeviceID) then
                    exit(DallasKey.AsJson());
            DeviceType::Authentication:
                if Authentication.Get(DeviceID) then
                    exit(Authentication.AsJson());
            DeviceType::RFID:
                if RFID.Get(DeviceID) then
                    exit(RFID.AsJson());
            DeviceType::EFT:
                if EFT.Get(DeviceID) then
                    exit(EFT.AsJson());
            else
                OnGetDeviceConfigDeviceTypeNotFound(DeviceType, DeviceID, DeviceConfig);
                exit(DeviceConfig);
        end;
    end;

    [IntegrationEvent(false, false)]
    internal procedure OnDirectIOCallback(deviceType: Text; deviceID: Text; command: Integer; data: Integer; stringData: Text; error: Boolean; payload: Text)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure LSN_POS_Devices_OnBeforePrint(DeviceID: Text; PrintJobID: Text; var PrintBufferRecRef: RecordRef)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure LSN_POS_Devices_OnAfterPrint(DeviceID: Text; PrintJobID: Text; PrintSuccessful: Boolean; ErrorMessage: Text)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure LSN_POS_Devices_OnBeforeOpenDrawer(DeviceID: Text)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure LSN_POS_Devices_OnBeforeDisplayText2(DeviceID: Text; Row: Integer; Column: Integer; var Text1: Text; var Text2: Text; var Attribute: Integer)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnGetDeviceConfigDeviceTypeNotFound(DeviceType: Enum "LSC Hardware Profile Devices"; DeviceID: Code[20]; var DeviceConfig: Text)
    begin
    end;
}
