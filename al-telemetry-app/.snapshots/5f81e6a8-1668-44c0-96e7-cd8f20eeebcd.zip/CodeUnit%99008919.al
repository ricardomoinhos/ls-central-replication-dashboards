/// <summary>Manages the active Staff/Terminal/Store and their active Language/Profiles and Context values (Tags).</summary>
codeunit 99008919 "LSC POS Session" implements "LSC IPosSessionMenu", "LSC IPOSSession"
{
    SingleInstance = true;

    #region Variables 

    var
        // Store/Terminal/Staff Records:
        _Store: Record "LSC Store";
        _Terminal: Record "LSC POS Terminal";
        _Staff: Record "LSC Staff";
        _StaffStoreLink: Record "LSC STAFF Store Link";
        _ManagerRec: Record "LSC Staff";

        // Manager/Permissions:
        _PermissionGroupRec: Record "LSC STAFF PER Group";
        _ManagerPermRec: Record "LSC STAFF PER Group";
        _KeyLockPermRec: Record "LSC STAFF PER Group";

        // Menu Profile:
        _MenuType: Enum "LSC Menu Types";
        _SelectedMenu: Code[20];
        _LanguageCode: Code[10]; // Active Language from Staff/Store/Global
        _OriginalLanguageID, _LanguageID : Integer;

        // Temporary Stores/Terminals/Profiles:
        _FixedInterfaceProfileID, _FixedMenuProfileID, _OriginalStoreSet, _OriginalTerminalSet : Code[10];

        // Profiles:
        _HardwareProfile: Record "LSC POS Hardware Profile";
        _FunctionalityProfile: Record "LSC POS Func. Profile";
        _MenuProfile: Record "LSC POS Menu Profile";
        _InterfaceProfile: Record "LSC POS Interface Profile";
        _StyleProfile: Record "LSC POS Style Profile";

        // SingleInstance/Helpers:
        _PosCtrl: Codeunit "LSC POS Control Interface";
        _BOUtils: Codeunit "LSC BO Utils";

    // POS - Internal in 18.4
    procedure Init()
    begin
        Clear(_Staff);
        Clear(_Terminal);
        Clear(_Store);

        Clear(_HardwareProfile);
        Clear(_FunctionalityProfile);
        Clear(_MenuProfile);
        Clear(_InterfaceProfile);
        Clear(_StyleProfile);

        Clear(_MenuType);
        Clear(_SelectedMenu);
        Clear(_FixedInterfaceProfileID);
        Clear(_FixedMenuProfileID);
        Clear(_OriginalStoreSet);
        Clear(_OriginalTerminalSet);

        ClearManagerID();
        SetStore(_Store); // Clears dependencies, like Profiles
        SetTerminal(_Terminal);
        SetStaff(_Staff);

        SetHardwareProfile(_HardwareProfile);
        SetFunctionalityProfile(_FunctionalityProfile);
        SetMenuProfile(_MenuProfile);
        SetInterfaceProfile(_InterfaceProfile);
        SetStyleProfile(_StyleProfile);

        _LanguageCode := '';
        _LanguageID := System.GlobalLanguage();
        if _OriginalLanguageID = 0 then
            _OriginalLanguageID := _LanguageID;
        OnAfterInit();
    end;

    #endregion Variables 

    #region POS Context 

    /// <summary>Prefer SetValue(pKey: Enum "LSC POS Tag"; pValue: Text). This procedure is provided for backwards-compatability and generic keys.</summary>
    procedure SetValue(pKey: Text; pValue: Text) oldValue: Text
    begin
        oldValue := _PosCtrl.SetValue(pKey, pValue);
    end;

    /// <summary>
    ///   <para>SetValue: Sets a value of a key-value pair in a dictionary.</para>
    ///   <para>If key exists the value is updated otherwise created if the value is not empty.</para>
    ///   <para>* IGNORE: 00 oldValue =  '', value =  '', oldValue = value</para>
    ///   <para>* INSERT: 01 oldValue =  '', value &lt;&gt; '', oldValue &lt;&gt; value</para>
    ///   <para>* REMOVE: 10 oldValue &lt;&gt; '', value =  '', oldValue &lt;&gt; value</para>
    ///   <para>* MODIFY: 11 oldValue &lt;&gt; '', value &lt;&gt; '', oldValue &lt;&gt; value</para>
    /// </summary>
    procedure SetValue(pKey: Enum "LSC POS Tag"; pValue: Text) oldValue: Text
    begin
        oldValue := _PosCtrl.SetValue(pKey, pValue);
    end;

    /// <summary>Prefer GetValue(pKey: Enum "LSC POS Tag"). This procedure is provided for backwards-compatability and generic keys.</summary>
    procedure GetValue(pKey: Text): Text
    begin
        exit(_PosCtrl.GetValue(pKey));
    end;

    /// <summary>Gets the value of a key-value pair in a dictionary. Returns empty string if the value was not found.</summary>
    procedure GetValue(pKey: Enum "LSC POS Tag"): Text
    begin
        exit(_PosCtrl.GetValue(pKey));
    end;

    /// <summary>Prefer DeleteValue(pKey: Enum "LSC POS Tag"). This procedure is provided for backwards-compatability and generic keys.</summary>
    procedure DeleteValue(pKey: Text): Boolean
    begin
        exit(_PosCtrl.ClearValue(pKey));
    end;

    /// <summary>DelValue: Deletes a key-value pair in a dictionary. Returns true if the key was found in the Context.</summary>
    procedure DeleteValue(pKey: Enum "LSC POS Tag"): Boolean
    begin
        exit(_PosCtrl.ClearValue(pKey));
    end;

    procedure UpdateTagExpressions(var dict: Dictionary of [Text, Text])
    begin
        _PosCtrl.UpdateTagExpressions(dict);
    end;

    #endregion POS Context

    #region Store 

    procedure Store() r: Record "LSC Store"
    begin
        r := _Store;
    end;

    /// <summary> Sets the active Store for the session </summary>
    procedure SetStore(r: Record "LSC Store")
    var
        StoreGroup: Record "LSC Store Group";
        oldStoreNo: Text;
    begin
        oldStoreNo := _Store."No.";
        Clear(StoreGroup);

        if r."No." = '' then begin
            Clear(_Store);
            SetDefaultStoreProfileIDs();
            if oldStoreNo <> r."No." then
                SignalOnStoreChanged(oldStoreNo, r."No.");
            exit;
        end;

        _Store := r;
        SetDefaultStoreProfileIDs();

        if oldStoreNo <> _Store."No." then
            SignalOnStoreChanged(oldStoreNo, _Store."No.");

        if _Store."Functionality Profile" <> '' then
            SetFunctionalityProfile(_Store."Functionality Profile");

        if _Store."Menu Profile" <> '' then
            SetMenuProfile(_Store."Menu Profile");

        if _Store."Interface Profile" <> '' then
            SetInterfaceProfile(_Store."Interface Profile");

        if _Store."Style Profile" <> '' then
            SetStyleProfile(_Store."Style Profile");

        UpdateLanguage;

        _Store.VerifyPostingSetup();
        SetPosPicture(_Store.RecordId);
    end;

    /// <summary> Use SetStore(r) instead </summary>
    procedure SetStore(pStoreNo: Code[10])
    var
        r: Record "LSC Store";
    begin
        if not r.Get(pStoreNo) then
            r."No." := pStoreNo;
        SetStore(r);
    end;

    /// <summary> Use PosSession.Store."No." instead </summary>
    procedure StoreNo(): Code[10]
    begin
        exit(_Store."No.");
    end;

    local procedure SetDefaultStoreProfileIDs()
    begin
        if _Store."Hardware Profile" = '' then
            _Store."Hardware Profile" := Format("LSC POS Profile ID"::DefaultHardware);
        if _Store."Functionality Profile" = '' then
            _Store."Functionality Profile" := Format("LSC POS Profile ID"::DefaultFunctionality);
        if _Store."Menu Profile" = '' then
            _Store."Menu Profile" := Format("LSC POS Profile ID"::DefaultMenu);
        if _Store."Interface Profile" = '' then
            _Store."Interface Profile" := Format("LSC POS Profile ID"::DefaultInterface);
        if _Store."Style Profile" = '' then
            _Store."Style Profile" := Format("LSC POS Profile ID"::DefaultStyle);
    end;

    [Obsolete('Not used, set the Pos Tag value instead', '27.0')]
    procedure SetTransPostingSource(PostingSourceIn: Integer)
    begin
        SetValue("LSC POS Tag"::"Posting_Source", Format(PostingSourceIn));
    end;

    [Obsolete('Not used, get the Pos Tag value instead', '27.0')]
    procedure GetTransPostingSource() PosingSourceOut: Integer
    var
        PostingSource: Text;
    begin
        PostingSource := GetValue("LSC POS Tag"::"Posting_Source");
        if not Evaluate(PosingSourceOut, PostingSource) then
            _PosCtrl.LogDebug(StrSubstNo('Posting source: "%1" is not a number in PosSession.GetValue()', PostingSource));
    end;

    // POS - Internal in 18.4
    [Obsolete('Not used. Use Store.VerifyPostingSetup instead', '27.0')]
    procedure VerifyStorePostingSetup(Store: Record "LSC Store")
    var
        Ishandled: Boolean;
    begin
#pragma warning disable AL0432
        OnBeforeVerifyStorePostingSetup(Store, Ishandled);
#pragma warning restore AL0432
        if Ishandled then
            exit;
        _Store.VerifyPostingSetup();
    end;

    #endregion Store 

    #region Terminal 

    procedure Terminal() r: Record "LSC POS Terminal"
    begin
        r := _Terminal;
    end;

    /// <summary> Sets the active Terminal for the session </summary>
    procedure SetTerminal(r: Record "LSC POS Terminal")
    var
        tmpProfileID: Code[20]; // See SetStaff approach
        oldTerminalNo, oldFuncProfileID : Text;
        NoSpecifiedErr: Label 'No %1 Specified';
        Text004: Label 'POS Terminal %1 not found in Store %2';
    begin
        oldTerminalNo := _Terminal."No.";
        oldFuncProfileID := _FunctionalityProfile."Profile ID";

        Clear(_KeyLockPermRec);

        if r."No." = '' then begin
            Clear(_Terminal);
            if oldTerminalNo <> r."No." then
                SignalOnTerminalChanged(oldTerminalNo, r."No.");
            exit;
        end;

        _Terminal := r;

        if _Terminal."Store No." <> _Store."No." then
            Error(Text004, _Terminal."No.", _Store."No.");

        _PosCtrl.SetAutoLogoffTimeout(_Terminal."AutoLogoff After (Min.)");

        if true in [
            AssignAndCheckHasValue(tmpProfileID, _Terminal."Hardware Profile"),
            AssignAndCheckHasValue(tmpProfileID, _Store."Hardware Profile")
        ] then
            if not SetHardwareProfile(tmpProfileID) then
                Error(StrSubstNo(NoSpecifiedErr, _Terminal.FieldCaption("Hardware Profile")));

        if AssignAndCheckHasValue(tmpProfileID, _Terminal."Menu Profile") then
            SetMenuProfile(tmpProfileID);

        if true in [
            AssignAndCheckHasValue(tmpProfileID, _Terminal."Functionality Profile"),
            AssignAndCheckHasValue(tmpProfileID, _Store."Functionality Profile")
        ] then
            if not SetFunctionalityProfile(tmpProfileID) then
                Error(StrSubstNo(NoSpecifiedErr, _Terminal.FieldCaption("Functionality Profile")));

        if _Staff."Store No." in ['', _Terminal."Store No."] then begin
            if _Terminal."Style Profile" <> '' then
                if _StaffStoreLink."POS Style Profile" = '' then
                    if _Staff."POS Style Profile" = '' then
                        SetStyleProfile(_Terminal."Style Profile");
            if _Terminal."Interface Profile" <> '' then
                if _StaffStoreLink."POS Interface Profile" = '' then
                    if _Staff."POS Interface Profile" = '' then
                        SetInterfaceProfile(_Terminal."Interface Profile");
        end;

        if _Terminal."KeyLock Staff Perm. Group" <> '' then
            _KeyLockPermRec.Get(_Terminal."KeyLock Staff Perm. Group");

        UpdateLanguage;

        if oldTerminalNo <> _Terminal."No." then
            SignalOnTerminalChanged(oldTerminalNo, _Terminal."No.");

        if oldFuncProfileID <> _FunctionalityProfile."Profile ID" then
            OnFunctionalityProfileChanged(oldFuncProfileID, _FunctionalityProfile."Profile ID");
    end;

    /// <summary> Use SetTerminal(r) instead </summary>
    procedure SetTerminal(pTerminalNo: Code[10])
    var
        r: Record "LSC POS Terminal";
    begin
        if not r.Get(pTerminalNo) then
            r."No." := pTerminalNo;
        SetTerminal(r);
    end;

    /// <summary> Use PosSession.Terminal."No." instead </summary>
    procedure TerminalNo(): Code[10]
    begin
        exit(_Terminal."No.");
    end;

    #endregion Terminal 

    #region FunctionalityProfile 

    procedure FunctionalityProfile() r: Record "LSC POS Func. Profile"
    begin
        r := _FunctionalityProfile;
    end;

    procedure SetFunctionalityProfile(r: Record "LSC POS Func. Profile")
    begin
        _FunctionalityProfile := r;
        SetValue("LSC POS Tag"::FUNCTIONALITY_PROFILE, _FunctionalityProfile."Profile ID");
        SetValue("LSC POS Tag"::"LSFUNCPROFILE", _FunctionalityProfile."Profile ID"); // Note: Legacy (from EposController.LoadBaseTables)
    end;

    /// <summary> Use FunctionalityProfile(r) instead </summary>
    procedure SetFunctionalityProfile(pProfileID: Code[10]) Found: Boolean
    var
        r: Record "LSC POS Func. Profile";
    begin
        Found := r.Get(pProfileID);
        if not Found then
            exit;
        SetFunctionalityProfile(r);
    end;

    /// <summary> Use FunctionalityProfile."Profile ID" instead </summary>
    procedure FunctionalityProfileID(): Code[10]
    begin
        exit(_FunctionalityProfile."Profile ID");
    end;

    [Obsolete('Will be removed, use PosSession.Store."Currency Code instead', '26.0')]
    procedure ActiveCurrencyCode(): Code[10]
    var
        EftFunc: Codeunit "LSC POS EFT Functions";
    begin
        exit(EftFunc.ActiveCurrencyCode());
    end;

    #endregion FunctionalityProfile 

    #region MenuProfile 

    procedure MenuProfile() r: Record "LSC POS Menu Profile"
    begin
        r := _MenuProfile;
    end;

    // POS - Internal in 18.4
    /// <summary> Use MenuProfile.ID instead </summary>
    procedure MenuProfileID(): Code[10]
    begin
        exit(_MenuProfile.ID);
    end;

    // POS - Internal in 18.4
    /// <summary> Use SetMenuProfile(r) instead </summary>
    procedure SetMenuProfile(pProfileID: Code[10])
    var
        r: Record "LSC POS Menu Profile";
    begin
        if not r.Get(pProfileID) then
            exit;
        SetMenuProfile(r);
    end;

    procedure SetMenuProfile(r: Record "LSC POS Menu Profile")
    begin
        _MenuProfile := r;

        if r.ID <> '' then begin
            _MenuProfile.TestField("Start Menu");
            _MenuProfile.TestField("Sales Menu");
            _MenuProfile.TestField("Payment Menu");
        end;

        SetValue("LSC POS Tag"::MENU_PROFILE, _MenuProfile.ID);
    end;

    // POS - Internal in 18.4
    procedure SetFixedMenuProfile(pProfileID: Code[10])
    begin
        if pProfileID = '' then begin
            _FixedMenuProfileID := '';
            SetStaff(StaffID);
        end else begin
            SetMenuProfile(pProfileID);
            _FixedMenuProfileID := pProfileID;
        end;
    end;

    procedure GetFixedMenuProfile(): Code[10]
    begin
        exit(_FixedMenuProfileID);
    end;

    #endregion MenuProfile 

    #region StyleProfile 

    procedure StyleProfile() r: Record "LSC POS Style Profile"
    begin
        r := _StyleProfile;
    end;

    procedure SetStyleProfile(r: Record "LSC POS Style Profile")
    begin
        _StyleProfile := r;
        SetValue("LSC POS Tag"::POS_STYLE, _StyleProfile.ID);
    end;

    /// <summary> Use SetStyleProfile(r) instead </summary>
    local procedure SetStyleProfile(pStyleProfileID: Text)
    var
        r: Record "LSC POS Style Profile";
    begin
        if not r.Get(pStyleProfileID) then
            exit;
        SetStyleProfile(r);
    end;

    // POS - Internal in 18.4
    /// <summary> Use StyleProfile.ID instead </summary>
    procedure PosStyleID(): Code[20]
    begin
        exit(_StyleProfile.ID);
    end;

    #endregion StyleProfile 

    #region InterfaceProfile 

    procedure InterfaceProfile() r: Record "LSC POS Interface Profile"
    begin
        r := _InterfaceProfile;
    end;

    procedure SetInterfaceProfile(r: Record "LSC POS Interface Profile")
    var
        oldProfileID: Text;
    begin
        oldProfileID := _InterfaceProfile.ID;

        _InterfaceProfile := r;

        if oldProfileID <> _InterfaceProfile.ID then begin
            SetValue("LSC POS Tag"::"INTERFACE_PROFILE", _InterfaceProfile.ID);
            OnInterfaceProfileChanged(oldProfileID, _InterfaceProfile.ID);
        end;
    end;

    // POS - Internal in 18.4
    /// <summary> Use SetInterfaceProfile(r) instead </summary>
    procedure SetInterfaceProfile(pProfileID: Code[10])
    var
        r: Record "LSC POS Interface Profile";
    begin
        if not r.Get(pProfileID) then
            exit;
        SetInterfaceProfile(r);
    end;

    // POS - Internal in 18.4
    /// <summary> Use InterfaceProfile.ID instead </summary>
    procedure InterfaceProfileID(): Code[10]
    begin
        exit(_InterfaceProfile.ID);
    end;

    procedure GetFixedInterfaceProfile(): Code[10]
    begin
        exit(_FixedInterfaceProfileID);
    end;

    // POS - Internal in 18.4
    procedure SetFixedInterfaceProfile(pProfileID: Code[10])
    begin
        if pProfileID = '' then begin
            _FixedInterfaceProfileID := '';
            SetStaff(StaffID);
        end else begin
            SetInterfaceProfile(pProfileID);
            _FixedInterfaceProfileID := pProfileID;
        end;
    end;

    #endregion InterfaceProfile 

    #region HardwareProfile 

    procedure HardwareProfile() r: Record "LSC POS Hardware Profile"
    begin
        r := _HardwareProfile;
    end;

    procedure SetHardwareProfile(r: Record "LSC POS Hardware Profile")
    begin
        _HardwareProfile := r;
        SetValue("LSC POS Tag"::HARDWARE_PROFILE, _HardwareProfile."Profile ID");
    end;

    // POS - Internal in 18.4
    /// <summary> Use SetHardwareProfile(r) instead </summary>
    procedure SetHardwareProfile(pProfileID: Code[10]) Found: Boolean
    var
        r: Record "LSC POS Hardware Profile";
    begin
        Found := r.Get(pProfileID);
        if not Found then
            exit;
        SetHardwareProfile(r);
    end;

    // POS - Internal in 18.4
    /// <summary> Use HardwareProfile."Profile ID" instead </summary>
    procedure HardwareProfileID(): Code[10]
    begin
        exit(_HardwareProfile."Profile ID");
    end;

    // POS - Internal in 18.4
    [Obsolete('Use HardwareProfile().DeviceIsActive instead', '27.0')]
    procedure PrinterActive(): Boolean
    begin
        exit(HardwareProfile().DeviceIsActive("LSC Hardware Profile Devices"::Printer));
    end;

    [Obsolete('Use HardwareProfile().DeviceIsActive instead', '27.0')]
    procedure EFTActive(): Boolean
    begin
        exit(HardwareProfile().DeviceIsActive("LSC Hardware Profile Devices"::EFT));
    end;

    [Obsolete('Use HardwareProfile().DeviceIsActive instead', '27.0')]
    procedure AuthDeviceActive(): Boolean
    begin
        exit(HardwareProfile().DeviceIsActive("LSC Hardware Profile Devices"::Authentication));
    end;

    // POS - Internal in 18.4
    [Obsolete('Use HardwareProfile().GetHardwareProfileDeviceId instead', '27.0')]
    procedure GetHardwareProfileDevice(deviceType: Enum "LSC Hardware Profile Devices"): Code[20]
    begin
        exit(HardwareProfile().GetHardwareProfileDeviceId(deviceType));
    end;

    // POS - Internal in 18.4
    [Obsolete('Use "LSC POS Hardware Interface".SetKeyLockState instead', '27.0')]
    procedure SetKeyLockState(NewState: Integer)
    var
        PosHardwareInterface: Codeunit "LSC POS Hardware Interface";
    begin
        PosHardwareInterface.SetKeyLockState(NewState);
    end;

    [Obsolete('Use "LSC POS Hardware Interface".GetPrinterBitmapNo instead', '27.0')]
    procedure GetPrinterBitmapNo(): Integer
    var
        PosHardwareInterface: Codeunit "LSC POS Hardware Interface";
    begin
        exit(PosHardwareInterface.GetPrinterBitmapNo());
    end;

    [Obsolete('Use "LSC POS Hardware Interface".GetPrinterLogo instead', '27.0')]
    procedure GetPrinterLogo(): Text
    var
        PosHardwareInterface: Codeunit "LSC POS Hardware Interface";
    begin
        exit(PosHardwareInterface.GetPrinterLogo());
    end;

    procedure GetEFTUtility(var iEFTUtil: interface "LSC IEFTUtility")
    var
        eftutil: Codeunit "LSC POS EFT Utility";
        UsageTelemetry: Codeunit "LSC Telemetry Usage Event";
        ishandled: Boolean;
    begin
        SetValue('_eft_v1_set', '1'); // temp. until v2 has fully replaced v1.
        OnGetEFTUtility(iEFTUtil, ishandled);
        if ishandled then begin
            UsageTelemetry.LogUsageEvent(Enum::"LSC Telemetry Event"::"LSC EFT Utility Usage");
            exit;
        end;
        iEFTUtil := eftutil;
    end;

    procedure GetEFTUtility2(var iEFTUtil2: interface "LSC IEFTUtility2")
    var
        eftutil: Codeunit "LSC POS EFT Utility";
        UsageTelemetry: Codeunit "LSC Telemetry Usage Event";
        ishandled: Boolean;
    begin
        OnGetEFTUtility2(iEFTUtil2, ishandled);
        if ishandled then begin
            UsageTelemetry.LogUsageEvent(Enum::"LSC Telemetry Event"::"LSC EFT Utility2 Usage");
            exit;
        end;
        iEFTUtil2 := eftutil;
    end;

    procedure GetEFTTokenUtility(var iTokenUtility: Interface "LSC IToken Utility")
    var
        eftutil: Codeunit "LSC POS EFT Utility";
        UsageTelemetry: Codeunit "LSC Telemetry Usage Event";
        IsHandled: Boolean;
    begin
        OnGetTokenUtility(iTokenUtility, IsHandled);
        if IsHandled then begin
            UsageTelemetry.LogUsageEvent(Enum::"LSC Telemetry Event"::"LSC EFT Token Utility Usage");
            exit;
        end;

        iTokenUtility := eftutil;
    end;

    procedure GetReferencedReturnsUtility(var iReferencedReturns: Interface "LSC IReferenced Returns")
    var
        eftutil: Codeunit "LSC POS EFT Utility";
        UsageTelemetry: Codeunit "LSC Telemetry Usage Event";
        IsHandled: Boolean;
    begin
        OnGetReferencedReturns(iReferencedReturns, IsHandled);
        if IsHandled then begin
            UsageTelemetry.LogUsageEvent(Enum::"LSC Telemetry Event"::"LSC EFT Referenced Return Usage");
            exit;
        end;

        iReferencedReturns := eftutil;
    end;

    procedure GetEFTPrinter(var iEFTPrinter: interface "LSC IEFTPrinter")
    var
        eftutil: Codeunit "LSC POS EFT Utility";
        UsageTelemetry: Codeunit "LSC Telemetry Usage Event";
        ishandled: Boolean;
    begin
        OnGetEFTPrinter(iEFTPrinter, ishandled);
        if ishandled then begin
            UsageTelemetry.LogUsageEvent(Enum::"LSC Telemetry Event"::"LSC EFT Printer Usage");
            exit;
        end;
        iEFTPrinter := eftutil;
    end;

    #endregion HardwareProfile 

    #region Staff 

    procedure Staff() r: Record "LSC Staff"
    begin
        r := _Staff;
    end;

    local procedure AssignAndCheckHasValue(var tmpTxt: Code[20]; comparisonTxt: Text): Boolean
    begin
        tmpTxt := comparisonTxt;
        exit(tmpTxt <> '');
    end;

    procedure SetStaff(r: Record "LSC Staff")
    var
        tmpProfileID: Code[20]; // Note: Profile IDs are Code[10], like Staff."POS Style Profile", but at some point some fields increased to Code[20], like Terminal."Style Profile", even when StyleProfile.ID is still only Code[10]
        oldStaffID: Text;
    begin
        oldStaffID := _Staff.ID;
        Clear(_Staff);
        Clear(_StaffStoreLink);

        if Store."No." <> '' then
            if _Staff.Get(r.ID) then
                if _StaffStoreLink.Get(_Staff.ID, Store."No.") then; // Note: Rec-based  Set- procedures in PosSession should not include Rec.Get

        _Staff := r;

        if oldStaffID <> _Staff.ID then
            UpdateLanguage;

        if GetFixedInterfaceProfile() = '' then
            if true in [
                AssignAndCheckHasValue(tmpProfileID, _StaffStoreLink."POS Interface Profile"),
                AssignAndCheckHasValue(tmpProfileID, _Staff."POS Interface Profile"),
                AssignAndCheckHasValue(tmpProfileID, _Terminal."Interface Profile"),
                AssignAndCheckHasValue(tmpProfileID, _Store."Interface Profile")
            ] then
                if tmpProfileID <> _InterfaceProfile.ID then
                    SetInterfaceProfile(tmpProfileID);

        if true in [
            AssignAndCheckHasValue(tmpProfileID, _StaffStoreLink."POS Style Profile"),
            AssignAndCheckHasValue(tmpProfileID, _Staff."POS Style Profile"),
            AssignAndCheckHasValue(tmpProfileID, _Terminal."Style Profile"),
            AssignAndCheckHasValue(tmpProfileID, _Store."Style Profile")
        ] then
            if tmpProfileID <> _StyleProfile.ID then
                SetStyleProfile(tmpProfileID);

        if GetFixedMenuProfile() = '' then
            if true in [
                AssignAndCheckHasValue(tmpProfileID, _StaffStoreLink."POS Menu Profile"),
                AssignAndCheckHasValue(tmpProfileID, _Staff."POS Menu Profile"),
                AssignAndCheckHasValue(tmpProfileID, _Terminal."Menu Profile"),
                AssignAndCheckHasValue(tmpProfileID, _Store."Menu Profile")
            ] then
                if tmpProfileID <> _MenuProfile.ID then
                    SetMenuProfile(tmpProfileID);

        if _HardwareProfile."Profile ID" = '' then
            SetHardwareProfile(_Store."Hardware Profile");
        if _FunctionalityProfile."Profile ID" = '' then
            SetFunctionalityProfile(_Store."Functionality Profile");

        _PermissionGroupRec.Init;
        if _StaffStoreLink."Permission Grp" <> '' then
            _PermissionGroupRec.Get(_StaffStoreLink."Permission Grp")
        else
            if _Staff."Permission Group" <> '' then
                _PermissionGroupRec.Get(_Staff."Permission Group");
        StaffLoadPermissions(_StaffStoreLink."Permission Grp" <> '');

        RefreshMgrStatus;

        if oldStaffID <> _Staff.ID then
            SignalOnStaffChanged(oldStaffID, _Staff.ID);

        OnAfterSetStaff(_Staff.ID);
    end;

    /// <summary> Use SetStaff(r) instead </summary>
    procedure SetStaff(pStaffID: Code[20])
    var
        r: Record "LSC Staff";
    begin
        if not r.Get(pStaffID) then
            r.ID := pStaffID;
        SetStaff(r);
    end;

    /// <summary> Use Staff.ID instead </summary>
    procedure StaffID(): Code[20]
    begin
        exit(_Staff.ID);
    end;

    // POS - Internal in 18.4
    procedure StaffPermissionGroup(): Code[10]
    begin
        if _StaffStoreLink."Permission Grp" <> '' then
            exit(_StaffStoreLink."Permission Grp");
        exit(_Staff."Permission Group");
    end;

    // POS - Internal in 18.4
    procedure StaffReturnInTransaction(): Boolean
    var
        ReturnValue, IsHandled : Boolean;
    begin
        OnBeforeStaffReturnInTransaction(_PermissionGroupRec, ReturnValue, IsHandled);
        if IsHandled then
            exit(ReturnValue);

        if StaffHasManagerPrivileges then
            exit(true);

        exit(StaffIsPermitted(_PermissionGroupRec."Return in Transaction"));
    end;

    // POS - Internal in 18.4
    procedure StaffCanCreateCustomer(): Boolean
    begin
        if StaffHasManagerPrivileges then
            exit(true);

        exit(StaffIsPermitted(_PermissionGroupRec."Create Customers"));
    end;

    procedure StaffCanUpdateCustomer(): Boolean
    begin
        if StaffHasManagerPrivileges then
            exit(true);

        exit(StaffIsPermitted(_PermissionGroupRec."Update Customers"));
    end;

    // POS - Internal in 18.4
    procedure StaffCanViewSalesHist(): Boolean
    begin
        if StaffHasManagerPrivileges then
            exit(true);

        exit(StaffIsPermitted(_PermissionGroupRec."View Sales History"));
    end;

    // POS - Internal in 18.4
    procedure StaffCanViewComments(): Integer
    begin
        exit(_PermissionGroupRec."Customer Comments");
    end;

    // POS - Internal in 18.4
    procedure StaffHasManagerPrivileges(): Boolean
    begin
        exit(StaffIsPermitted(_PermissionGroupRec."Manager Privileges"));
    end;

    // POS - Internal in 18.4
    procedure StaffShowTransAmt(): Boolean
    begin
        exit(StaffIsPermitted(_PermissionGroupRec."Show Trans. Amount"));
    end;

    // POS - Internal in 18.4
    procedure StaffShowDifferenceWarning(): Boolean
    begin
        exit(StaffIsPermitted(_PermissionGroupRec."Show Difference in Warning"));
    end;

    // POS - Internal in 18.4
    procedure StaffActAfterDiffWarning(): Integer
    begin
        exit(_PermissionGroupRec."Action After Diff. Warning");
    end;

    // POS - Internal in 18.4
    procedure StaffMaxWarningCount(): Integer
    begin
        exit(_PermissionGroupRec."Max. Warning Count");
    end;

    // POS - Internal in 18.4
    procedure StaffMaxTenderDeclDiff(): Decimal
    begin
        exit(_PermissionGroupRec."Max. Tender Decl. Difference");
    end;

    // POS - Internal in 18.4
    procedure StaffIsPermitted(lStaffPerm: Integer): Boolean
    begin
        exit(lStaffPerm = 1);
    end;

    procedure StaffOpenDinTblLockedByStaff(): Boolean
    begin
        exit(StaffIsPermitted(_PermissionGroupRec."Open Din. Tbl. Locked by Staff"));
    end;

    // POS - Internal in 18.4
    procedure StaffReturnPermission(lStaffPerm: Integer; lStaffPermGrPerm: Integer): Boolean
    begin
        if lStaffPerm = 2 then
            exit(StaffIsPermitted(lStaffPermGrPerm));
        exit(StaffIsPermitted(lStaffPerm));
    end;

    // POS - Internal in 18.4
    procedure StaffLoadPermissions(PermGrFromStaffStoreLink: Boolean)
    begin
        if PermGrFromStaffStoreLink then
            exit;
        if _Staff."Permission Group" = '' then begin
            _PermissionGroupRec.TransferFields(_Staff, false);
        end else begin
            if _Staff."Void Transaction" <> _Staff."Void Transaction"::" " then
                _PermissionGroupRec."Void Transaction" := _Staff."Void Transaction";
            if _Staff."Manager Privileges" <> _Staff."Manager Privileges"::" " then
                _PermissionGroupRec."Manager Privileges" := _Staff."Manager Privileges";
            if _Staff."XZY-Report Printing" <> _Staff."XZY-Report Printing"::" " then
                _PermissionGroupRec."XZY-Report Printing" := _Staff."XZY-Report Printing";
            if _Staff."Tender Declaration" <> _Staff."Tender Declaration"::" " then
                _PermissionGroupRec."Tender Declaration" := _Staff."Tender Declaration";
            if _Staff."Floating Declaration" <> _Staff."Floating Declaration"::" " then
                _PermissionGroupRec."Floating Declaration" := _Staff."Floating Declaration";
            if _Staff."Price Override" <> _Staff."Price Override"::" " then
                _PermissionGroupRec."Price Override" := _Staff."Price Override";

            if _Staff."Discount from Perm. Group" = _Staff."Discount from Perm. Group"::No then begin
                _PermissionGroupRec."Max. Discount to Give %" := _Staff."Max. Discount to Give %";
                _PermissionGroupRec."Max. Total Discount %" := _Staff."Max. Total Discount %";
            end;

            if _Staff."Suspend Transaction" <> _Staff."Suspend Transaction"::" " then
                _PermissionGroupRec."Suspend Transaction" := _Staff."Suspend Transaction";
            if _Staff."Open Draw. without Sale" <> _Staff."Open Draw. without Sale"::" " then
                _PermissionGroupRec."Open Draw. without Sale" := _Staff."Open Draw. without Sale";
            if _Staff."Return in Transaction" <> _Staff."Return in Transaction"::" " then
                _PermissionGroupRec."Return in Transaction" := _Staff."Return in Transaction";
            if _Staff."Void Prepayment" <> _Staff."Void Prepayment"::" " then
                _PermissionGroupRec."Void Prepayment" := _Staff."Void Prepayment";
            if _Staff."Void Prepayment Line" <> _Staff."Void Prepayment Line"::" " then
                _PermissionGroupRec."Void Prepayment Line" := _Staff."Void Prepayment Line";
            if _Staff."Change Prepayment Amt." <> _Staff."Change Prepayment Amt."::" " then
                _PermissionGroupRec."Change Prepayment Amt." := _Staff."Change Prepayment Amt.";
            if _Staff."Add Prepayment Amt." <> _Staff."Add Prepayment Amt."::" " then
                _PermissionGroupRec."Add Prepayment Amt." := _Staff."Add Prepayment Amt.";
            if _Staff."Void Line" <> _Staff."Void Line"::" " then
                _PermissionGroupRec."Void Line" := _Staff."Void Line";
            if _Staff."Add Payment" <> _Staff."Add Payment"::" " then
                _PermissionGroupRec."Add Payment" := _Staff."Add Payment";
            if _Staff."Transfer Orders" <> _Staff."Transfer Orders"::" " then
                _PermissionGroupRec."Transfer Orders" := _Staff."Transfer Orders";
            if _Staff."Split Bills" <> _Staff."Split Bills"::" " then
                _PermissionGroupRec."Split Bills" := _Staff."Split Bills";
            if _Staff."Switch Dining Table Layout" <> _Staff."Switch Dining Table Layout"::" " then
                _PermissionGroupRec."Switch Dining Table Layout" := _Staff."Switch Dining Table Layout";
            if _Staff."Adjust Dining Tables" <> _Staff."Adjust Dining Tables"::" " then
                _PermissionGroupRec."Adjust Dining Tables" := _Staff."Adjust Dining Tables";
            if _Staff."Design Dining Table Layout" <> _Staff."Design Dining Table Layout"::" " then
                _PermissionGroupRec."Design Dining Table Layout" := _Staff."Design Dining Table Layout";
            if _Staff."Seat Guests" <> _Staff."Seat Guests"::" " then
                _PermissionGroupRec."Seat Guests" := _Staff."Seat Guests";
            if _Staff."View Kitchen Status" <> _Staff."View Kitchen Status"::" " then
                _PermissionGroupRec."View Kitchen Status" := _Staff."View Kitchen Status";
            if _Staff."Change Staff" <> _Staff."Change Staff"::" " then
                _PermissionGroupRec."Change Staff" := _Staff."Change Staff";
            if _Staff."Add Start Float" <> _Staff."Add Start Float"::" " then
                _PermissionGroupRec."Add Start Float" := _Staff."Add Start Float";
            if _Staff."Create Customers" <> _Staff."Create Customers"::" " then
                _PermissionGroupRec."Create Customers" := _Staff."Create Customers";
            if _Staff."View Sales History" <> _Staff."View Sales History"::" " then
                _PermissionGroupRec."View Sales History" := _Staff."View Sales History";
            if _Staff."Customer Comments" <> _Staff."Customer Comments"::" " then
                _PermissionGroupRec."Customer Comments" := _Staff."Customer Comments";
            if _Staff."Open Sales POS Directly" <> _Staff."Open Sales POS Directly"::" " then
                _PermissionGroupRec."Open Sales POS Directly" := _Staff."Open Sales POS Directly";
            if _Staff."Open Sales POS" <> _Staff."Open Sales POS"::" " then
                _PermissionGroupRec."Open Sales POS" := _Staff."Open Sales POS";
            if _Staff."Open Din. Tbl. Locked by Staff" <> _Staff."Open Din. Tbl. Locked by Staff"::" " then
                _PermissionGroupRec."Open Din. Tbl. Locked by Staff" := _Staff."Open Din. Tbl. Locked by Staff";
            if _Staff."Change Dining Tbl. Status" <> _Staff."Change Dining Tbl. Status"::" " then
                _PermissionGroupRec."Change Dining Tbl. Status" := _Staff."Change Dining Tbl. Status";
            if _Staff."Reset Dining Tbl. Status" <> _Staff."Reset Dining Tbl. Status"::" " then
                _PermissionGroupRec."Reset Dining Tbl. Status" := _Staff."Reset Dining Tbl. Status";
            if _Staff."Rush Order in Kitchen" <> _Staff."Rush Order in Kitchen"::" " then
                _PermissionGroupRec."Rush Order in Kitchen" := _Staff."Rush Order in Kitchen";
            if _Staff."Edit Available Qty." <> _Staff."Edit Available Qty."::" " then
                _PermissionGroupRec."Edit Available Qty." := _Staff."Edit Available Qty.";
            if _Staff."Max. Diff./Warn. from Perm. Gr" = _Staff."Max. Diff./Warn. from Perm. Gr"::No then begin
                _PermissionGroupRec."Max. Tender Decl. Difference" := _Staff."Max. Tender Decl. Difference";
                _PermissionGroupRec."Max. Warning Count" := _Staff."Max. Warning Count";
            end;

            if _Staff."Show Difference in Warning" <> _Staff."Show Difference in Warning"::" " then
                _PermissionGroupRec."Show Difference in Warning" := _Staff."Show Difference in Warning";
            if _Staff."Action After Diff. Warning" <> _Staff."Action After Diff. Warning"::" " then
                _PermissionGroupRec."Action After Diff. Warning" := _Staff."Action After Diff. Warning";
            if _Staff."CID-Report Printing" <> _Staff."CID-Report Printing"::" " then
                _PermissionGroupRec."CID-Report Printing" := _Staff."CID-Report Printing";
            if _Staff."TIPS Handling" <> _Staff."TIPS Handling"::" " then
                _PermissionGroupRec."TIPS Handling" := _Staff."TIPS Handling";
            if _Staff."Show Trans. Amount" <> _Staff."Show Trans. Amount"::" " then
                _PermissionGroupRec."Show Trans. Amount" := _Staff."Show Trans. Amount";
            if _Staff."Update Customers" <> _Staff."Update Customers"::" " then
                _PermissionGroupRec."Update Customers" := _Staff."Update Customers";
        end;

        OnAfterStaffLoadPermissions(_PermissionGroupRec, _Staff);
    end;

    // POS - Internal in 18.4
    procedure Login(pManager: Boolean; pStaffID: Code[20]; pPassword: Text; pShiftNo: Code[1]; var pReasonText: Text[80]): Boolean
    var
        Staff_l: Record "LSC Staff";
        Staff2_l: Record "LSC Staff";
        WorkShiftSetup_l: Record "LSC Work Shift Setup";
        MSRLinks: Record "LSC MSR Card Link Setup";
        StaffStoreLink: Record "LSC STAFF Store Link";
        TSUtil: Codeunit "LSC POS Trans. Server Utility";
        tmpPOS: Code[10];
        TSErr: Integer;
        StaffStoreOk, Ok, IsError : Boolean;
        ErrorText: Text;
        StaffAlreadyLoggedErr: Label 'Staff %1 is already logged into terminal %2';
        StaffIsBlockedErr: Label '%1 %2 is blocked!';
        StaffIdPwdInvalidErr: Label 'The combination of Staff ID and password entered is invalid !';
        WorkshiftInvalidErr: Label 'Invalid Work Shift entry!';
        StaffIdNotInStoreErr: Label 'The Staff ID does not belong to this store !';
        CantOperatePosErr: Label '%1 %2 is a %3 and can not operate the POS';
        TransServerNoAuthStaffErr: Label 'Trans.Server cannot authorize  Staff %1 login.';
    begin
        if _FunctionalityProfile."Staff Barcode Logon" then begin
            if not Staff_l.Get(pStaffID) then begin
                MSRLinks.SetRange(MSRLinks."Card Number", pStaffID);
                MSRLinks.SetRange(MSRLinks."Link Type", MSRLinks."Link Type"::Cashier);
                if MSRLinks.FindFirst() then
                    pStaffID := MSRLinks."Link No.";
            end;
        end;

        Ok := TSUtil.Initialize;
        if not (Ok and TSUtil.GetStaffV2(Staff_l, StaffStoreLink, pStaffID, ErrorText)) then begin
            if not Staff_l.Get(pStaffID) then begin
                pReasonText := StaffIdPwdInvalidErr;
                exit(false);
            end
            else
                if (_FunctionalityProfile."TS Staff") and (not Staff_l."Continue on TS errors") then begin
                    pReasonText := StrSubstNo(TransServerNoAuthStaffErr, pStaffID);
                    exit(false);
                end;
        end
        else begin
            if not Staff_l.Insert then begin
                Staff_l.Modify;
                Commit;
            end;

            SelectLatestVersion;
            Clear(Staff2_l);
            Staff2_l.Init;
            Staff2_l.TransferFields(Staff_l, true);
            if Staff_l.Get(Staff_l.ID) then
                Staff_l.Delete;
            Staff2_l.Insert;
            Commit;
        end;

        if not Staff_l.Get(pStaffID) then begin
            pReasonText := StaffIdPwdInvalidErr;
            exit(false);
        end;

        if not Staff_l.IsPassWordValid(pPassword) then begin
            OnAfterPasswordValidityFail(Staff_l, _FunctionalityProfile);
            pReasonText := StaffIdPwdInvalidErr;
            exit(false);
        end;

        OnAfterPasswordValidityPass(Staff_l, _FunctionalityProfile, pReasonText, IsError);
        if IsError then
            exit(false);

        tmpPOS := TSUtil.GetStaffLoginStatus(pStaffID, TSErr);
        if ((tmpPOS <> '') and (tmpPOS <> TerminalNo)) then begin
            pReasonText := StrSubstNo(StaffAlreadyLoggedErr, pStaffID, tmpPOS);
            exit(false);
        end;

        if (Staff_l."Employment Type" = Staff_l."Employment Type"::"Sales Person") then begin
            pReasonText := StrSubstNo(CantOperatePosErr, Staff_l.TableCaption, pStaffID, Staff_l."Employment Type");
            exit(false);
        end;

        if Staff_l.Blocked then begin
            pReasonText := StrSubstNo(StaffIsBlockedErr, Staff_l.TableCaption, pStaffID);
            exit(false);
        end;

        if _Store."Closing Method" = _Store."Closing Method"::Shift then begin
            // Note: Rec-based  Set- procedures in PosSession should not include Rec.Get
            if not WorkShiftSetup_l.Get(_Store."No.", pShiftNo) then begin
                SetValue("LSC POS Tag"::SHIFT_NO, '');
                pReasonText := WorkshiftInvalidErr;
                exit(false);
            end;
            SetValue("LSC POS Tag"::SHIFT_NO, pShiftNo);
        end;

        OnValidateLogin(_Store, pShiftNo, pReasonText);
        if pReasonText <> '' then
            exit(false);

        StaffStoreOk := false;
        if Staff_l."Store No." = '' then
            StaffStoreOk := true;
        if (not StaffStoreOk) and (Staff_l."Store No." <> '') and (Staff_l."Store No." = StoreNo) then
            StaffStoreOk := true;
        StaffStoreLink.SetRange("Store No.", StoreNo());
        StaffStoreLink.SetRange("Staff ID", Staff_l.ID);

        if not StaffStoreOk then
            if not StaffStoreLink.IsEmpty() then
                StaffStoreOk := true;

        if (not StaffStoreOk) then begin
            pReasonText := StaffIdNotInStoreErr;
            exit(false);
        end;

        exit(true);
    end;

    // POS - Internal in 18.4
    procedure WorkShiftNo(): Code[1]
    begin
        exit(GetValue("LSC POS Tag"::SHIFT_NO));
    end;

    // POS - Internal in 18.4
    procedure SetManagerID(pStaff: Record "LSC Staff"; var pReasonText: Text[80]): Boolean
    var
        ManStaffPermGroup: Record "LSC STAFF PER Group";
        ManStaffStoreLink: Record "LSC STAFF Store Link";
        FromStoreLink: Boolean;
        IsHandled: Boolean;
        ReturnValue: Boolean;
        Text154: Label 'Staff %1 has no manager privileges';
    begin
        OnBeforeSetManagerID(pStaff, IsHandled, ReturnValue);
        if IsHandled then
            exit(ReturnValue);
        Clear(ManStaffPermGroup);
        FromStoreLink := false;
        if StoreNo <> '' then
            if ManStaffStoreLink.Get(pStaff.ID, StoreNo) then
                if ManStaffStoreLink."Permission Grp" <> '' then begin
                    if ManStaffPermGroup.Get(ManStaffStoreLink."Permission Grp") then begin
                        if ManStaffPermGroup."Manager Privileges" = ManStaffPermGroup."Manager Privileges"::No then begin
                            pReasonText := StrSubstNo(Text154, pStaff.ID);
                            exit(false);
                        end;
                        FromStoreLink := true;
                    end;
                end;

        if not FromStoreLink then begin
            Clear(ManStaffPermGroup);
            if pStaff."Permission Group" <> '' then begin
                ManStaffPermGroup.Get(pStaff."Permission Group");
                if pStaff."Discount from Perm. Group" = pStaff."Discount from Perm. Group"::No then begin
                    ManStaffPermGroup."Max. Discount to Give %" := pStaff."Max. Discount to Give %";
                    ManStaffPermGroup."Max. Total Discount %" := pStaff."Max. Total Discount %";
                end;
            end else begin
                ManStaffPermGroup."Max. Discount to Give %" := pStaff."Max. Discount to Give %";
                ManStaffPermGroup."Max. Total Discount %" := pStaff."Max. Total Discount %";
                ManStaffPermGroup."Manager Privileges" := pStaff."Manager Privileges";
            end;

            if ManStaffPermGroup."Manager Privileges" = ManStaffPermGroup."Manager Privileges"::No then begin
                pReasonText := StrSubstNo(Text154, pStaff.ID);
                exit(false);
            end;
        end;

        _ManagerRec := pStaff;
        _ManagerPermRec := ManStaffPermGroup;
        RefreshMgrStatus;

        exit(true);
    end;

    // POS - Internal in 18.4
    procedure ManagerID(): Code[20]
    begin
        exit(_ManagerRec.ID);
    end;

    procedure ClearManagerID()
    begin
        Clear(_ManagerRec);
        Clear(_ManagerPermRec);
        RefreshMgrStatus;
    end;

    // POS - Internal in 18.4
    procedure RefreshMgrStatus()
    var
        PosHardwareInterface: Codeunit "LSC POS Hardware Interface";
        mgrKeyLoc, mgrKeyTmp : Boolean;
    begin
        mgrKeyLoc := PosHardwareInterface.GetKeyLockState() = 3;

        if _ManagerPermRec."Manager Privileges" = _ManagerPermRec."Manager Privileges"::Yes then
            mgrKeyLoc := true
        else
            if StaffHasManagerPrivileges then
                mgrKeyLoc := true;

        SetValue("LSC POS Tag"::MGRKEY, Format(mgrKeyLoc));
        if mgrKeyLoc then
            SetValue("LSC POS Tag"::MGRKEY_ACTIVE, '1')
        else
            SetValue("LSC POS Tag"::MGRKEY_ACTIVE, '0');
        SetValue("LSC POS Tag"::ManagerID, ManagerID());

        mgrKeyTmp := mgrKeyLoc;
        OnAfterRefreshMgrStatus(mgrKeyLoc);
        if mgrKeyTmp <> mgrKeyLoc then begin
            if mgrKeyLoc then
                SetValue("LSC POS Tag"::MGRKEY_ACTIVE, '1')
            else
                SetValue("LSC POS Tag"::MGRKEY_ACTIVE, '0');
        end;
    end;

    procedure MgrKey(): Boolean
    begin
        exit(GetValue("LSC POS Tag"::MGRKEY_ACTIVE) = '1');
    end;

    procedure SetTrainingStatus(TrainingOn: Boolean)
    var
        __TRAINING: Label 'TRAINING';
    begin
        SetValue("LSC POS Tag"::TRAINING_STATUS, TrainingOn ? __TRAINING : '');
    end;

    procedure GetTrainingStatus(): Text
    begin
        exit(GetValue("LSC POS Tag"::TRAINING_STATUS));
    end;

    // POS - Internal in 18.4
    procedure SetTooltipActive(b: Boolean)
    var
        valTxt: Text;
    begin
        if b then
            valTxt := '1';
        SetValue("LSC POS Tag"::TOOLTIP_ACTIVE, valTxt); // Tooltips are disabled by default until tag has been set
    end;

    procedure GetTooltipActive(): Boolean
    begin
        exit(GetValue("LSC POS Tag"::TOOLTIP_ACTIVE) <> '');
    end;

    /// <summary>
    ///   <para>Sets the number of pixels a XY layout button can move in each direction when dragged (0 locks the axis, 1 is free movement)</para>
    ///   <para>It's recommended to round the positions to the nearest grid value when enabling a drag grid,</para>
    ///   <para>so if a button has XPOS = 8 but drag grid is [10,1], then XPOS should be set to 10 to match the grid.</para>
    /// </summary>
    procedure SetDragGrid(x: Integer; y: Integer)
    begin
        if (x > -1) and (y > -1) then
            SetValue("LSC POS TAG"::DND_GRID, StrSubstNo('[%1,%2]', x, y));
    end;

    /// <summary>Returns a Text with the format [x,y], e.g. [10,10]</summary>
    procedure GetDragGrid(): Text
    begin
        exit(GetValue("LSC POS TAG"::DND_GRID));
    end;

    // POS - Internal in 18.4
    procedure ValidateWorkShift(pStoreNo: Code[10]; pShiftNo: Code[10]; var pErrorText: Text[80]): Boolean
    var
        WorkShiftSetup: Record "LSC Work Shift Setup";
        WorkShift: Record "LSC Work Shift RBO";
        WorkShiftTemp: Record "LSC Work Shift RBO" temporary;
        GetWorkShiftUtils: Codeunit LSCGetWorkShiftUtils;
        lText000: Label 'Work Shift Setup %1 for store %2 not found';
        lText001: Label 'Shift %1 for date %2 has already been closed';
        ErrorText: Text;
        ResponseCode: Code[30];
    begin
        if not WorkShiftSetup.Get(pStoreNo, pShiftNo) then begin
            pErrorText := StrSubstNo(lText000, pShiftNo, pStoreNo);
            exit(false);
        end;

        Clear(WorkShift);
        WorkShift."Store No." := pStoreNo;
        WorkShift."Shift No." := pShiftNo;
        WorkShift."Shift Date" := Today;

        if WorkShiftSetup."Start Time" > WorkShiftSetup."End Time" then begin
            if Time > WorkShiftSetup."End Time" then begin
                if WorkShiftSetup."Date Reference" <> WorkShiftSetup."Date Reference"::"Start Time" then
                    WorkShift."Shift Date" := WorkShift."Shift Date" + 1;
            end
            else begin
                if WorkShiftSetup."Date Reference" = WorkShiftSetup."Date Reference"::"Start Time" then
                    WorkShift."Shift Date" := WorkShift."Shift Date" - 1;
            end;
        end;

        if _FunctionalityProfile."TS Send Transactions" then begin
            GetWorkShiftUtils.SetPosFunctionalityProfile(_FunctionalityProfile."Profile ID");
            GetWorkShiftUtils.SendRequest(Workshift."Store No.", workshift."Shift Date", WorkShift."Shift No.", ResponseCode, ErrorText, WorkShiftTemp);
            GetWorkShiftUtils.SetCommunicationError(ResponseCode, ErrorText);
            if ErrorText <> '' then begin
                pErrorText := CopyStr(ErrorText, 1, MaxStrLen(pErrorText));
                exit(false);
            end;
        end else
            if WorkShift.Get(WorkShift."Store No.", WorkShift."Shift Date", WorkShift."Shift No.") then begin
                WorkShiftTemp.Init;
                WorkShiftTemp := WorkShift;
                WorkShiftTemp.Insert;
            end;

        if WorkShiftTemp.Get(WorkShift."Store No.", WorkShift."Shift Date", WorkShift."Shift No.") then
            if (WorkShiftTemp.Status <> WorkShiftTemp.Status::Open) then begin
                pErrorText := StrSubstNo(lText001, WorkShift."Shift No.", WorkShift."Shift Date");
                exit(false);
            end;

        exit(true);
    end;

    #endregion Staff 

    #region Obsolete 

    // POS - Internal in 18.4
    procedure SetTempStoreTerminal(TempStoreNo: Code[10]; TempPosTerminalNo: Code[10]; SalesType: Code[20])
    var
        HospType: Record "LSC Hospitality Type";
    begin
        if TempStoreNo = '' then begin
            SetStore(_OriginalStoreSet);
            _OriginalStoreSet := '';
            SetTerminal(_OriginalTerminalSet);
            _OriginalTerminalSet := '';
            SetStaff(StaffID);
            _PosCtrl.SetPosCtrlActiveMenuProfile(MenuProfileID, Store."Menu Profile"); //change the active menu profile
            _PosCtrl.SetPosCtrlActiveInterfaceProfile(InterfaceProfileID, Store."Interface Profile");
        end else begin
            _OriginalStoreSet := StoreNo;
            _OriginalTerminalSet := TerminalNo;
            SetStore(TempStoreNo);
            SetTerminal(TempPosTerminalNo);
            SetStaff(StaffID);
            _PosCtrl.SetPosCtrlActiveMenuProfile(MenuProfileID, Store."Menu Profile");
            _PosCtrl.SetPosCtrlActiveInterfaceProfile(InterfaceProfileID, Store."Interface Profile");
        end;
        HospType.Reset;
        HospType.SetRange("Restaurant No.", _Store."No.");
        HospType.SetRange("Sales Type", SalesType);
        if HospType.FindFirst then;
        if HospType."Active KDS Load Config." <> '' then
            SetValue("LSC POS Tag"::CURRLOADCONFIG, HospType."Active KDS Load Config.")
        else
            SetValue("LSC POS Tag"::CURRLOADCONFIG, _Store."Active KDS Load Config.");
    end;

    // POS - Internal in 18.4
    procedure TempStoreTerminalIsSet(): Boolean
    begin
        exit(_OriginalStoreSet <> '');
    end;

    procedure GetOriginalTerminalNo(): Code[10]
    begin
        if _OriginalTerminalSet <> '' then
            exit(_OriginalTerminalSet);
        exit(TerminalNo);
    end;

    #endregion Obsolete 

    #region POS Controls 
    procedure GetPosPanelRec(PanelID: Code[20]; var PosPanel: Record "LSC POS Panel"): Boolean
    begin
        if PanelID = '' then
            exit(false);

        if not PosPanel.Get(InterfaceProfileID, PanelID) then
            if not PosPanel.Get(_Store."Interface Profile", PanelID) then
                if not PosPanel.Get(Format("LSC POS Profile ID"::DefaultInterface), PanelID) then begin
                    exit(false);
                end;

        exit(true);
    end;

    procedure GetPosMediaCtrlRec(CtrID: Code[20]; var POSMediaControl: Record "LSC POS Media Control"): Boolean
    begin
        if CtrID = '' then
            exit(false);

        if not POSMediaControl.Get(InterfaceProfileID, CtrID) then
            if not POSMediaControl.Get(_Store."Interface Profile", CtrID) then
                if not POSMediaControl.Get(Format("LSC POS Profile ID"::DefaultInterface), CtrID) then begin
                    exit(false);
                end;

        exit(true);
    end;

    procedure GetPosBrowserCtrlRec(CtrID: Code[20]; var POSBrowserControl: Record "LSC POS Browser Control"): Boolean
    begin
        if CtrID = '' then
            exit(false);

        if not POSBrowserControl.Get(InterfaceProfileID, CtrID) then
            if not POSBrowserControl.Get(_Store."Interface Profile", CtrID) then
                if not POSBrowserControl.Get(Format("LSC POS Profile ID"::DefaultInterface), CtrID) then begin
                    exit(false);
                end;

        exit(true);
    end;

    procedure GetPosInputCtrlRec(ControlID: Code[20]; var PosInputCtrl: Record "LSC POS Input Control"): Boolean
    begin
        if ControlID = '' then
            exit(false);

        if not PosInputCtrl.Get(InterfaceProfileID, ControlID) then
            if not PosInputCtrl.Get(_Store."Interface Profile", ControlID) then
                if not PosInputCtrl.Get(Format("LSC POS Profile ID"::DefaultInterface), ControlID) then begin
                    exit(false);
                end;

        exit(true);
    end;

    procedure GetPosInputCtrlRecInPanel(PosPanel: Record "LSC POS Panel"; ControlID: Code[20]; var PosInputCtrl: Record "LSC POS Input Control"): Boolean
    var
        PosPanelCtrlLine: Record "LSC POS Panel Control Line";
    begin
        PosPanelCtrlLine.Reset;
        PosPanelCtrlLine.SetRange("Interface Profile ID", PosPanel."Interface Profile ID");
        PosPanelCtrlLine.SetRange("Panel Control ID", PosPanel."Control ID");
        PosPanelCtrlLine.SetRange("Control Type", PosPanelCtrlLine."Control Type"::Input);
        PosPanelCtrlLine.SetRange("Control ID", ControlID);
        if not PosPanelCtrlLine.FindFirst then begin
            exit(false);
        end;
        if not GetPosInputCtrlRec(PosPanelCtrlLine."Control ID", PosInputCtrl) then begin
            exit(false);
        end;

        exit(true);
    end;

    procedure GetPosDataGridCtrlRec(ControlID: Code[20]; var PosDataGridCtrl: Record "LSC POS Data Grid Control"): Boolean
    begin
        if ControlID = '' then
            exit(false);

        if not PosDataGridCtrl.Get(InterfaceProfileID, ControlID) then
            if not PosDataGridCtrl.Get(_Store."Interface Profile", ControlID) then
                if not PosDataGridCtrl.Get(Format("LSC POS Profile ID"::DefaultInterface), ControlID) then begin
                    exit(false);
                end;

        exit(true);
    end;

    procedure GetPosRecordZoomCtrlRec(ControlID: Code[20]; var PosRecordZoomCtrl: Record "LSC POS Record Zoom Control"): Boolean
    begin
        if ControlID = '' then
            exit(false);

        if not PosRecordZoomCtrl.Get(InterfaceProfileID, ControlID) then
            if not PosRecordZoomCtrl.Get(_Store."Interface Profile", ControlID) then
                if not PosRecordZoomCtrl.Get(Format("LSC POS Profile ID"::DefaultInterface), ControlID) then begin
                    exit(false);
                end;

        exit(true);
    end;

    procedure GetPosLookupRec(ID: Code[20]; var PosLookup: Record "LSC POS Lookup"): Boolean
    begin
        if ID = '' then
            exit(false);

        if not PosLookup.Get(InterfaceProfileID, ID) then
            if not PosLookup.Get(_Store."Interface Profile", ID) then
                if not PosLookup.Get(Format("LSC POS Profile ID"::DefaultInterface), ID) then begin
                    exit(false);
                end;

        exit(true);
    end;

    procedure GetDataTableInDataGrid(PosPanel: Record "LSC POS Panel"; ControlID: Code[20]; var POSDataTable: Record "LSC POS Data Table"): Boolean
    var
        PosPanelCtrlLine: Record "LSC POS Panel Control Line";
        PosDataGridCtrl: Record "LSC POS Data Grid Control";
        DataTableID: Code[20];
    begin
        PosPanelCtrlLine.Reset;
        PosPanelCtrlLine.SetRange("Interface Profile ID", PosPanel."Interface Profile ID");
        PosPanelCtrlLine.SetRange("Panel Control ID", PosPanel."Control ID");
        PosPanelCtrlLine.SetRange("Control Type", PosPanelCtrlLine."Control Type"::"Data Grid");
        PosPanelCtrlLine.SetRange("Control ID", ControlID);
        if not PosPanelCtrlLine.FindFirst then begin
            exit(false);
        end;

        DataTableID := PosPanelCtrlLine."Dynamic Ctrl. Assignm.";
        if DataTableID = '' then begin
            GetPosDataGridCtrlRec(PosPanelCtrlLine."Control ID", PosDataGridCtrl);
            DataTableID := PosDataGridCtrl."Data Table ID";
        end;

        if not POSDataTable.Get(DataTableID) then begin
            exit(false);
        end;

        exit(true);
    end;

    procedure GetPosButtonPadCtrlRec(ControlID: Code[20]; var PosButtonPadCtrl: Record "LSC POS ButtonPad Control"): Boolean
    begin
        if ControlID = '' then
            exit(false);

        if not PosButtonPadCtrl.Get(InterfaceProfileID, ControlID) then
            if not PosButtonPadCtrl.Get(_Store."Interface Profile", ControlID) then
                if not PosButtonPadCtrl.Get(Format("LSC POS Profile ID"::DefaultInterface), ControlID) then begin
                    exit(false);
                end;

        exit(true);
    end;

    procedure GetMenuInButtonPad(PosPanel: Record "LSC POS Panel"; ControlID: Code[20]; var PosMenuHdr: Record "LSC POS Menu Header"): Boolean
    var
        PosPanelCtrlLine: Record "LSC POS Panel Control Line";
        ButtPadCtrl: Record "LSC POS ButtonPad Control";
        MenuID: Code[20];
    begin
        PosPanelCtrlLine.Reset;
        PosPanelCtrlLine.SetRange("Interface Profile ID", PosPanel."Interface Profile ID");
        PosPanelCtrlLine.SetRange("Panel Control ID", PosPanel."Control ID");
        PosPanelCtrlLine.SetRange("Control Type", PosPanelCtrlLine."Control Type"::"Button Pad");
        PosPanelCtrlLine.SetRange("Control ID", ControlID);
        if not PosPanelCtrlLine.FindFirst then begin
            exit(false);
        end;

        MenuID := PosPanelCtrlLine."Dynamic Ctrl. Assignm.";
        if MenuID = '' then begin
            GetPosButtonPadCtrlRec(PosPanelCtrlLine."Control ID", ButtPadCtrl);
            MenuID := ButtPadCtrl."Menu ID";
        end;

        if not GetPosMenuRec(MenuID, PosMenuHdr) then
            exit(false);

        exit(true);
    end;

    procedure GetPosMenuRec(MenuID: Code[20]; var PosMenuHdr: Record "LSC POS Menu Header"): Boolean
    begin
        if MenuID = '' then
            exit(false);

        if not PosMenuHdr.Get(MenuProfileID, MenuID) then
            if not PosMenuHdr.Get(_Store."Menu Profile", MenuID) then
                if not PosMenuHdr.Get(Format("LSC POS Profile ID"::DefaultMenu), MenuID) then begin
                    exit(false);
                end;

        exit(true);
    end;

    procedure GetPosButtonSkinRec(SkinCode: Code[20]; var PosButtonSkin: Record "LSC POS Button Skin"): Boolean
    begin
        if SkinCode = '' then
            exit(false);

        if not PosButtonSkin.Get(PosStyleID, SkinCode) then
            if not PosButtonSkin.Get(_Store."Style Profile", SkinCode) then
                if not PosButtonSkin.Get(Format("LSC POS Profile ID"::DefaultStyle), SkinCode) then begin
                    exit(false);
                end;

        exit(true);
    end;

    // POS - Internal in 18.4
    procedure IsControlInPanel(PosPanel: Record "LSC POS Panel"; ControlType: Integer; ControlID: Code[20]): Boolean
    var
        PosPanelCtrlLine: Record "LSC POS Panel Control Line";
    begin
        PosPanelCtrlLine.Reset;
        PosPanelCtrlLine.SetRange("Interface Profile ID", PosPanel."Interface Profile ID");
        PosPanelCtrlLine.SetRange("Panel Control ID", PosPanel."Control ID");
        PosPanelCtrlLine.SetRange("Control Type", ControlType);
        PosPanelCtrlLine.SetRange("Control ID", ControlID);
        if PosPanelCtrlLine.IsEmpty then
            exit(false);
        exit(true);
    end;

    // POS - Internal in 18.4
    procedure CreateFilter(Filter1: Text; Filter2: Text; Filter3: Text): Text
    var
        ResultFilter: Text;
    begin
        ResultFilter := '';
        if Filter1 <> '' then
            ResultFilter := Filter1;
        if not (Filter2 in ['', Filter1]) then
            ResultFilter += '|' + Filter2;
        if not (Filter3 in ['', Filter1, Filter2]) then
            ResultFilter += '|' + Filter3;
        if CopyStr(ResultFilter, 1, 1) = '|' then
            ResultFilter := CopyStr(ResultFilter, 2);
        exit(ResultFilter);
    end;

    #endregion POS Controls 

    #region Permissions 


    // POS - Internal in 18.4
    procedure MenuPermission(var MenuLine: Record "LSC POS Menu Line"; FuncCode: Code[20]; var MessageTxt: Text): Boolean
    var
        StoreGroups: Record "LSC Store Group Setup";
        Utils: Codeunit "LSC Retail Price Utils";
        PosComm: Record "LSC POS Command";
        IncExpAcc_l: Record "LSC Income/Expense Account";
        MenuHdr: Record "LSC POS Menu Header";
        BtnAccessSettingsMsg: Label 'The button has access settings ';
        IsHandled, ReturnValue : Boolean;
    begin
        OnBeforeMenuPermission(MenuLine, FuncCode, MessageTxt, ReturnValue, IsHandled);
        if IsHandled then
            exit(ReturnValue);

        if not MgrKey then begin
            if not Permission(FuncCode, MessageTxt) then
                exit(false);
            if (MenuLine.Command in [Format("LSC POS Command"::POPUP), Format("LSC POS Command"::IMENU)]) then begin
                if GetPosMenuRec(MenuLine.Parameter, MenuHdr) then
                    if MenuHdr."Manager Key" then
                        exit(false);
            end;
            if (MenuLine."Post Command" in [Format("LSC POS Command"::POPUP), Format("LSC POS Command"::IMENU)]) then begin
                if GetPosMenuRec(MenuLine."Post Parameter", MenuHdr) then
                    if MenuHdr."Manager Key" then
                        exit(false);
            end;
        end;

        if MenuLine.Command = Format("LSC POS Command"::INCEXP) then begin
            if IncExpAcc_l.Get(_Store."No.", MenuLine.Parameter) then
                if IncExpAcc_l."Account Type" = IncExpAcc_l."Account Type"::Expense then
                    if IncExpAcc_l."Gratuity Type" = IncExpAcc_l."Gratuity Type"::Tips then
                        if not Permission("LSC POS Command"::PRINT_TIPS, MessageTxt) then
                            exit(false);
        end;

        if MenuLine."Staff Group Access" <> '' then
            if (MenuLine."Staff Group Access" <> _PermissionGroupRec.Code) and (MenuLine."Staff Group Access" <> _ManagerRec."Permission Group") then begin
                MessageTxt := BtnAccessSettingsMsg;
                exit(false);
            end;

        if MenuLine."Store Group Access" <> '' then
            if not StoreGroups.Get(StoreNo, MenuLine."Store Group Access") then begin
                MessageTxt := BtnAccessSettingsMsg;
                exit(false);
            end;

        if MenuLine."Store Access" <> '' then
            if MenuLine."Store Access" <> StoreNo then begin
                MessageTxt := BtnAccessSettingsMsg;
                exit(false);
            end;

        if MenuLine."Pos Access" <> '' then
            if MenuLine."Pos Access" <> TerminalNo then begin
                MessageTxt := BtnAccessSettingsMsg;
                exit(false);
            end;

        if MenuLine."Period Access" <> '' then
            if not Utils.DiscValPerValid(MenuLine."Period Access", Today(), Time()) then begin
                MessageTxt := BtnAccessSettingsMsg;
                exit(false);
            end;

        if (MenuLine."Sales Type Access" <> '') and (MenuLine."Current-SALESTYPE" <> '') then
            if MenuLine."Sales Type Access" <> MenuLine."Current-SALESTYPE" then begin
                MessageTxt := BtnAccessSettingsMsg;
                exit(false);
            end;

        if not MgrKey then
            if not StaffHasManagerPrivileges then
                if PosComm.Get(FuncCode) then
                    if PosComm."Manager Key" then begin
                        MessageTxt := BtnAccessSettingsMsg;
                        exit(false);
                    end;
        exit(true);
    end;

    /// <summary>Checks if current session has permission to execute a POS Command, providing a Message back if not.</summary>
    procedure Permission(FuncCode: Enum "LSC POS Command"; var MessageTxt: Text): Boolean
    begin
        exit(Permission(Format(FuncCode), MessageTxt));
    end;

    /// <summary>Prefer Permission(FuncCode: Enum "LSC POS Command") instead. This procedure is provided for backwards-compatability and generic keys.</summary>
    procedure Permission(FuncCode: Code[20]; var MessageTxt: Text): Boolean
    var
        PosCommandRec: Record "LSC POS Command";
        PosCommand: Enum "LSC POS Command";
        Text006: Label 'Manager key is required for open drawer';
        Text007: Label 'Manager key is required for returns';
        Text026: Label 'Not allowed to Float/Remove Tender';
        Text316: Label 'Not allowed to change amount on Prepayment line.';
        Text317: Label 'Not allowed to add Prepayment amount to the line.';
        Text321: Label 'Not allowed to switch/save layout as design layout';
        Text400: Label 'Not allowed to view comments';
        Text401: Label 'Not allowed to insert comments';
        Text405: Label 'Not allowed to %1';
        Text406: Label '%1 not allowed';
        IsHandled, Returnvalue : Boolean;
    begin
        if MgrKey then
            exit(true);
        OnBeforeCheckPermission(FuncCode, _PermissionGroupRec, _Staff, MessageTxt, IsHandled, Returnvalue);
        if IsHandled then
            exit(ReturnValue);

        if not PosCommandRec.CommandExists(FuncCode, PosCommand) then
            exit(true);

        case PosCommand of
            PosCommand::OPEN_DR:
                if not StaffIsPermitted(_PermissionGroupRec."Open Draw. without Sale") then begin
                    MessageTxt := Text006;
                    exit(false);
                end;
            PosCommand::REFUND,
            PosCommand::EXCHANGE:
                if _Terminal."Manager Key on Return" then begin
                    MessageTxt := Text007;
                    exit(false);
                end;
            PosCommand::PRINT_X,
            PosCommand::PRINT_Z,
            PosCommand::PRINT_Y:
                if not StaffIsPermitted(_PermissionGroupRec."XZY-Report Printing") then begin
                    MessageTxt := StrSubstNo(Text406, _Staff.FieldCaption("XZY-Report Printing"));
                    exit(false);
                end;
            PosCommand::SUSPEND:
                if not StaffIsPermitted(_PermissionGroupRec."Suspend Transaction") then begin
                    MessageTxt := StrSubstNo(Text405, _Staff.FieldCaption("Suspend Transaction"));
                    exit(false);
                end;
            PosCommand::TD_ENDDAY:
                if not StaffIsPermitted(_PermissionGroupRec."Tender Declaration") then begin
                    MessageTxt := StrSubstNo(Text406, _Staff.FieldCaption("Tender Declaration"));
                    exit(false);
                end;
            PosCommand::FLOAT_ENT,
            PosCommand::REM_TENDER:
                if not StaffIsPermitted(_PermissionGroupRec."Floating Declaration") then begin
                    MessageTxt := Text026;
                    exit(false);
                end;
            PosCommand::VOID:
                if not StaffIsPermitted(_PermissionGroupRec."Void Transaction") then begin
                    MessageTxt := StrSubstNo(Text405, _Staff.FieldCaption("Void Transaction"));
                    exit(false);
                end;
            PosCommand::KITCHEN_RUSHINKDS:
                if not StaffIsPermitted(_PermissionGroupRec."Rush Order in Kitchen") then begin
                    MessageTxt := StrSubstNo(Text405, _Staff.FieldCaption("Rush Order in Kitchen"));
                    exit(false);
                end;
            PosCommand::VOID_L:
                if not StaffIsPermitted(_PermissionGroupRec."Void Line") then begin
                    MessageTxt := StrSubstNo(Text405, _Staff.FieldCaption("Void Line"));
                    exit(false);
                end;
            PosCommand::PRINT_CID:
                if not StaffIsPermitted(_PermissionGroupRec."CID-Report Printing") then begin
                    MessageTxt := StrSubstNo(Text405, _Staff.FieldCaption("CID-Report Printing"));
                    exit(false);
                end;
            PosCommand::PRINT_TIPS:
                if not StaffIsPermitted(_PermissionGroupRec."TIPS Handling") then begin
                    MessageTxt := StrSubstNo(Text405, _Staff.FieldCaption("TIPS Handling"));
                    exit(false);
                end;
            PosCommand::VOIDPP:
                if not StaffIsPermitted(_PermissionGroupRec."Void Prepayment") then begin
                    MessageTxt := StrSubstNo(Text405, _Staff.FieldCaption("Void Prepayment"));
                    exit(false);
                end;
            PosCommand::VOIDPP_L:
                if not StaffIsPermitted(_PermissionGroupRec."Void Prepayment Line") then begin
                    MessageTxt := StrSubstNo(Text405, _Staff.FieldCaption("Void Prepayment Line"));
                    exit(false);
                end;
            PosCommand::CHGPP_L:
                if not StaffIsPermitted(_PermissionGroupRec."Change Prepayment Amt.") then begin
                    MessageTxt := Text316;
                    exit(false);
                end;
            PosCommand::ADDPP_L:
                if not StaffIsPermitted(_PermissionGroupRec."Add Prepayment Amt.") then begin
                    MessageTxt := Text317;
                    exit(false);
                end;
            PosCommand::TENDER_K:
                if not StaffIsPermitted(_PermissionGroupRec."Add Payment") then begin
                    MessageTxt := StrSubstNo(Text405, _Staff.FieldCaption("Add Payment"));
                    exit(false);
                end;
            PosCommand::TRTBL_PART,
            PosCommand::TRANS_TBL,
            PosCommand::TRTBL_CANCEL:
                if not StaffIsPermitted(_PermissionGroupRec."Transfer Orders") then begin
                    MessageTxt := StrSubstNo(Text405, _Staff.FieldCaption("Transfer Orders"));
                    exit(false);
                end;
            PosCommand::SPLITBILL:
                if not StaffIsPermitted(_PermissionGroupRec."Split Bills") then begin
                    MessageTxt := StrSubstNo(Text405, _Staff.FieldCaption("Split Bills"));
                    exit(false);
                end;
            PosCommand::LAY_USEASDESIGN,
            PosCommand::LAY_DESIGN_ALL,
            PosCommand::LAY_CHANGE:
                if not StaffIsPermitted(_PermissionGroupRec."Switch Dining Table Layout") then begin
                    MessageTxt := Text321;
                    exit(false);
                end;
            PosCommand::LAY_ADJUSTMODE:
                if not StaffIsPermitted(_PermissionGroupRec."Adjust Dining Tables") then begin
                    MessageTxt := StrSubstNo(Text405, _Staff.FieldCaption("Adjust Dining Tables"));
                    exit(false);
                end;
            PosCommand::LAY_DESIGNMODE:
                if not StaffIsPermitted(_PermissionGroupRec."Design Dining Table Layout") then begin
                    MessageTxt := StrSubstNo(Text405, _Staff.FieldCaption("Design Dining Table Layout"));
                    exit(false);
                end;
            PosCommand::CH_STAFF:
                if not StaffIsPermitted(_PermissionGroupRec."Change Staff") then begin
                    MessageTxt := StrSubstNo(Text405, _Staff.FieldCaption("Change Staff"));
                    exit(false);
                end;
            PosCommand::SEAT_GUESTS:
                if not StaffIsPermitted(_PermissionGroupRec."Seat Guests") then begin
                    MessageTxt := StrSubstNo(Text405, _Staff.FieldCaption("Seat Guests"));
                    exit(false);
                end;
            PosCommand::KITCHEN_MYKOTS,
            PosCommand::KITCHEN_ORDERSTATUS:
                if not StaffIsPermitted(_PermissionGroupRec."View Kitchen Status") then begin
                    MessageTxt := StrSubstNo(Text405, _Staff.FieldCaption("View Kitchen Status"));
                    exit(false);
                end;
            PosCommand::"HOSP-OPEN-POS-DIR":
                if not StaffIsPermitted(_PermissionGroupRec."Open Sales POS Directly") then begin
                    MessageTxt := StrSubstNo(Text405, _Staff.FieldCaption("Open Sales POS Directly"));
                    exit(false);
                end;
            PosCommand::"HOSP-OPEN-POS",
            PosCommand::"HOSP-OPEN-NEWORDER",
            PosCommand::"HOSP-ORDEREDIT",
            PosCommand::"FAB-NEWORDER",
            PosCommand::"FAB-OPENORDER":
                if not StaffIsPermitted(_PermissionGroupRec."Open Sales POS") then begin
                    MessageTxt := StrSubstNo(Text405, _Staff.FieldCaption("Open Sales POS"));
                    exit(false);
                end;
            PosCommand::HOSPSTATUS_CHANGE:
                if not StaffIsPermitted(_PermissionGroupRec."Change Dining Tbl. Status") then begin
                    MessageTxt := StrSubstNo(Text405, _Staff.FieldCaption("Change Dining Tbl. Status"));
                    exit(false);
                end;
            PosCommand::HOSPSTATUS_RESET,
            PosCommand::OPEN_TABLE:
                if not StaffIsPermitted(_PermissionGroupRec."Reset Dining Tbl. Status") then begin
                    MessageTxt := StrSubstNo(Text405, _Staff.FieldCaption("Reset Dining Tbl. Status"));
                    exit(false);
                end;
            PosCommand::SET_ITEMSTOCKRESTR:
                if not StaffIsPermitted(_PermissionGroupRec."Edit Available Qty.") then begin
                    MessageTxt := StrSubstNo(Text405, _Staff.FieldCaption("Edit Available Qty."));
                    exit(false);
                end;
            PosCommand::CUSTCOMMENTSHOW:
                if _PermissionGroupRec."Customer Comments" = 0 then begin
                    MessageTxt := Text400;
                    exit(false);
                end;
            PosCommand::CUSTCOMMENTNEW:
                if _PermissionGroupRec."Customer Comments" <> _PermissionGroupRec."Customer Comments"::"View & Edit" then begin
                    MessageTxt := Text401;
                    exit(false);
                end;
            PosCommand::CUSTUPDATE:
                if not StaffIsPermitted(_PermissionGroupRec."Update Customers") then begin
                    MessageTxt := StrSubstNo(Text405, _Staff.FieldCaption("Update Customers"));
                    exit(false);
                end;
            PosCommand::CUSTCREATE:
                if not StaffIsPermitted(_PermissionGroupRec."Create Customers") then begin
                    MessageTxt := StrSubstNo(Text405, _Staff.FieldCaption("Create Customers"));
                    exit(false);
                end;
            PosCommand::CUSTHISTORY:
                if not StaffIsPermitted(_PermissionGroupRec."View Sales History") then begin
                    MessageTxt := StrSubstNo(Text405, _Staff.FieldCaption("View Sales History"));
                    exit(false);
                end;
        end;

        exit(true);
    end;

    // POS - Internal in 18.4
    procedure PermissionItem(FuncCode: Code[20]; ItemNo: Code[20]; Value: Decimal; OrgPrice: Decimal; var MessageTxt: Text; StaffIDOfMgr: Code[20]; ManualQty: Boolean): Boolean
    var
        Item: Record Item;
        MaxDiscPercentage: Decimal;
        ManTotalDisc: Decimal;
        PriceChangeLowerAllowed: Boolean;
        PriceChangeHigherAllowed: Boolean;
        ReturnValue: Boolean;
        IsHandled: Boolean;
        Text000: Label 'Price change is not allowed';
        Text027: Label 'The price has to be higher';
        Text028: Label 'The price has to be lower';
        Text029: Label 'Price change is not allowed';
        KeyInQuantityErr: Label 'It is not allowed to key in quantity for this item';
        Text033: Label 'No discount is allowed for this item';
        Text059: Label 'Max Total discount to give is %1 %';
        AvoidNegativePrice: Label 'Item price cannot be changed from positive to negative';
    begin
        IsHandled := false;
        OnBeforePermissionItem(ReturnValue, FuncCode, IsHandled);
        if IsHandled then
            exit(ReturnValue);

        if MgrKey and not (FuncCode in ['QTY', 'DISC', 'TDISC', 'PRICE', 'PRICECH']) then
            exit(true);

        Item.Get(ItemNo);
        case FuncCode of
            'PRICE', 'PRICECH':
                begin
                    if (OrgPrice > 0) and (Value < 0) then begin
                        MessageTxt := AvoidNegativePrice;
                        exit(false);
                    end;

                    case Item."LSC Keying in Price" of
                        Item."LSC Keying in Price"::"Must not Key in Price":
                            begin
                                MessageTxt := Text000;
                                exit(false);
                            end;
                        Item."LSC Keying in Price"::"Must Key in Higher/Equal Price":
                            if OrgPrice > Value then begin
                                MessageTxt := Text027;
                                exit(false);
                            end;
                        Item."LSC Keying in Price"::"Must Key in Lower/Equal Price":
                            if OrgPrice < Value then begin
                                MessageTxt := Text028;
                                exit(false);
                            end;
                    end;

                    if Item."LSC Keying in Price" <> Item."LSC Keying in Price"::"Not Mandatory" then
                        exit(true);

                    if (not StaffHasManagerPrivileges) and MgrKey then begin
                        if ManagerID <> '' then begin //Manager Login
                            PriceChangeHigherAllowed := _ManagerPermRec."Price Override" in [_ManagerPermRec."Price Override"::"Higher and Lower", _ManagerPermRec."Price Override"::"Higher only"];
                            PriceChangeLowerAllowed := _ManagerPermRec."Price Override" in [_ManagerPermRec."Price Override"::"Higher and Lower", _ManagerPermRec."Price Override"::"Lower only"];
                        end else begin //KEYLOCK (might be empty)
                            PriceChangeHigherAllowed := _KeyLockPermRec."Price Override" in [_KeyLockPermRec."Price Override"::"Higher and Lower", _KeyLockPermRec."Price Override"::"Higher only"];
                            PriceChangeLowerAllowed := _KeyLockPermRec."Price Override" in [_KeyLockPermRec."Price Override"::"Higher and Lower", _KeyLockPermRec."Price Override"::"Lower only"];
                        end;
                    end;

                    if not PriceChangeHigherAllowed then
                        PriceChangeHigherAllowed := _PermissionGroupRec."Price Override" in [_PermissionGroupRec."Price Override"::"Higher and Lower", _PermissionGroupRec."Price Override"::"Higher only"];

                    if not PriceChangeLowerAllowed then
                        PriceChangeLowerAllowed := _PermissionGroupRec."Price Override" in [_PermissionGroupRec."Price Override"::"Higher and Lower", _PermissionGroupRec."Price Override"::"Lower only"];

                    if Value > OrgPrice then begin
                        if (not PriceChangeHigherAllowed) then begin
                            if PriceChangeLowerAllowed then
                                MessageTxt := Text028
                            else
                                MessageTxt := Text029;

                            exit(false);
                        end;
                    end;

                    if Value < OrgPrice then begin
                        if (not PriceChangeLowerAllowed) then begin
                            if PriceChangeHigherAllowed then
                                MessageTxt := Text027
                            else
                                MessageTxt := Text029;
                            exit(false);
                        end;
                    end;
                end;
            'QTY':
                begin
                    if not ManualQty then
                        exit(true);
                    if Item."LSC Keying in Quantity" <> Item."LSC Keying in Quantity"::"Must not Key in Quantity" then
                        exit(true);
                    MessageTxt := KeyInQuantityErr;
                    exit(false);
                end;
            'DISC':
                begin
                    IsHandled := false;
                    OnBeforePermissionItemDISC(Item, MessageTxt, IsHandled, ReturnValue);
                    if IsHandled then
                        exit(ReturnValue);
                    if Item."LSC No Discount Allowed" then begin
                        MessageTxt := Text033;
                        exit(false);
                    end;

                    if not PermissionDealSub(Value, MessageTxt) then
                        exit(false);
                end;
            'TDISC':
                begin
                    IsHandled := false;
                    OnBeforePermissionItemTDISC(Item, MessageTxt, IsHandled, ReturnValue);
                    if IsHandled then
                        exit(ReturnValue);
                    if Item."LSC No Discount Allowed" then begin
                        MessageTxt := Text033;
                        exit(false);
                    end;

                    if (not StaffHasManagerPrivileges) and MgrKey then begin
                        if ManagerID <> '' then //Manager Login
                            ManTotalDisc := _ManagerPermRec."Max. Total Discount %"
                        else
                            ManTotalDisc := _KeyLockPermRec."Max. Total Discount %"; //KEYLOCK: Might be empty
                    end;

                    if (_PermissionGroupRec."Max. Total Discount %" < abs(Value)) and (ManTotalDisc < abs(Value)) then begin
                        MaxDiscPercentage := _PermissionGroupRec."Max. Total Discount %";
                        if ManTotalDisc > MaxDiscPercentage then
                            MaxDiscPercentage := ManTotalDisc;
                        MessageTxt := StrSubstNo(Text059, MaxDiscPercentage);
                        exit(false);
                    end;
                end;
        end;
        exit(true);
    end;

    // POS - Internal in 18.4

    procedure ManualQuantityPermitted(POSTransLine: Record "LSC POS Trans. Line"; var MessageTxt: Text): Boolean
    begin
        if POSTransLine."Entry Type" = "LSC POS Trans. Line Entry Type"::Item then
            exit(PermissionItem('QTY', POSTransLine.Number, 0, 0, MessageTxt, '', true));

        if POSTransLine."Text Type" = "LSC POS Trans. Line Text Type"::"Deal Header" then
            exit(PermissionDeal('QTY', POSTransLine."Promotion No.", 0, 0, MessageTxt, '', true));
        exit(true);
    end;

    procedure PermissionDeal(FuncCode: Code[20]; DealNo: Code[20]; Value: Decimal; OrgPrice: Decimal; var MessageTxt: Text; StaffIDOfMgr: Code[20]; ManualQty: Boolean): Boolean
    var
        Deal: Record "LSC Offer";
        RetailSetup: Record "LSC Retail Setup";
        LineDiscountErr: Label 'Line Discount is not allowed for this deal';
        KeyInQuantityErr: Label 'It is not allowed to key in quantity for this deal';
        KeyInQuantityOnDealsErr: Label 'It is not allowed to key in quantity for deals';
    begin
        if not Deal.Get(DealNo) then
            exit(true);
        case FuncCode of
            Format("LSC POS Command"::DISC):
                begin
                    if Deal."Block Line Discount" then begin
                        MessageTxt := LineDiscountErr;
                        exit(false);
                    end;
                    exit(PermissionDealSub(Value, MessageTxt));
                end;
            'QTY':
                begin
                    if not RetailSetup.Popup_NewFunctionality() then begin
                        MessageTxt := KeyInQuantityOnDealsErr;
                        exit(false);
                    end;
                    if not ManualQty then
                        exit(true);
                    if Deal."Keying in Quantity" <> Deal."Keying in Quantity"::NotAllowed then
                        exit(true);
                    MessageTxt := KeyInQuantityErr;
                    exit(false);
                end;
        end;
    end;

    local procedure PermissionDealSub(Val: Decimal; var MessageTxt: Text): Boolean
    var
        MaxDiscPercentage: Decimal;
        MaxDiscountMsg: Label 'Max discount to give is %1 %';
    begin
        if (not StaffHasManagerPrivileges) and MgrKey then begin
            if ManagerID <> '' then //Manager Login
                MaxDiscPercentage := _ManagerPermRec."Max. Discount to Give %"
            else
                MaxDiscPercentage := _KeyLockPermRec."Max. Discount to Give %"; //KEYLOCK: Might be empty
        end;

        if (_PermissionGroupRec."Max. Discount to Give %" < abs(Val)) and (MaxDiscPercentage < abs(Val)) then begin
            MaxDiscPercentage := _PermissionGroupRec."Max. Discount to Give %";
            MessageTxt := StrSubstNo(MaxDiscountMsg, MaxDiscPercentage);
            exit(false);
        end;

        exit(true);
    end;

    #endregion Permissions 

    #region POS Language 

    procedure ButtonTranslate(var MenuLine: Record "LSC POS Menu Line")
    var
        ButtonTranslate: Record "LSC POS Button Translation";
    begin
        if _LanguageCode = '' then
            exit;
        if ButtonTranslate.Get(MenuLine."Profile ID", MenuLine."Menu ID", MenuLine."Key No.", _LanguageCode) then
            MenuLine.Description := ButtonTranslate.Description;
    end;

    /// <summary>
    /// Updates the language of the POS session. Called whenever Staff/Store change or when language has potentially changed. Shouldn't be called directly, listen to OnBeforeUpdateLanguageCode to impact the active language.
    /// </summary>
    procedure UpdateLanguage()
    var
        CurrLanguageCode: Code[10];
        LanguageCu: Codeunit "Language";
        cultureinfo: Codeunit DotNet_CultureInfo; // lang: Codeunit Language;
        TypeHelper: Codeunit "Type Helper";
        WinLang: Record "Windows Language";
        SessionSettingsType: SessionSettings;
        TimeZoneOffset: Duration;
        GlobalLang: Integer;
    begin
        GlobalLang := System.GlobalLanguage();
        if _OriginalLanguageID = 0 then
            _OriginalLanguageID := GlobalLang;

        CurrLanguageCode := _LanguageCode;

        // Staff > Store > GlobalLang
        if _Staff.Language <> '' then
            _LanguageCode := _Staff.Language
        else
            if _Store."Language Code" <> '' then
                _LanguageCode := _Store."Language Code"
            else
                _LanguageCode := LanguageCu.GetLanguageCode(_OriginalLanguageID);


        // Use fallback (1033) if LanguageId or ParentLanguage not found (some languages have "Window Language"."Language ID" but no Language.Code)
        if _LanguageCode = '' then
            if CurrLanguageCode = '' then begin
                if WinLang.Get(_OriginalLanguageID) then
                    _LanguageCode := LanguageCu.GetLanguageCode(WinLang."Primary Language ID"); // Try parent/primary language
                if _LanguageCode = '' then
                    _LanguageCode := LanguageCu.GetLanguageCode(LanguageCu.GetDefaultApplicationLanguageId());
                if _LanguageCode = '' then
                    _LanguageCode := 'ENU';
            end;

        OnBeforeUpdateLanguageCode(_LanguageCode);
        if CurrLanguageCode = _LanguageCode then
            exit;

        _LanguageID := LanguageCu.GetLanguageId(_LanguageCode);
        System.GlobalLanguage(_LanguageID);
        SetValue("LSC POS Tag"::LANGUAGE_CODE, _LanguageCode);
        SetValue("LSC POS Tag"::LANGUAGE_REGION, Format(System.WindowsLanguage()));
        SetValue("LSC POS Tag"::LANG_BOOL1, Format(true));
        SetValue("LSC POS Tag"::LANG_BOOL0, Format(false));
        cultureinfo.GetCultureInfoById(_LanguageID);
        SetValue('lscust_culture', cultureinfo.Name()); // CultureInfo.CurrentCulture.Name
        SetValue('_lang_iso', cultureinfo.TwoLetterISOLanguageName().ToUpper()); // RegionInfo.CurrentRegion.Name
        SetValue('_lang_global', Format(System.GlobalLanguage()));
        SetValue('_lang_last_id', Format(GlobalLang));
        SetValue('_lang_name', cultureinfo.Name());
        SetValue('_lang_win', cultureinfo.ThreeLetterWindowsLanguageName().ToUpper());
        SetValue('_lang_winlang', Format(System.WindowsLanguage()));
        SetValue('_lang_formatregion', LanguageCu.GetFormatRegionOrDefault(''));
        SetValue('_lang_id', Format(_LanguageID));
        if TypeHelper.GetUserTimezoneOffset(TimeZoneOffset) then;
        SetValue('_lang_timezone', Format(TimeZoneOffset));
        SetValue('_lang_stimezone', SessionSettingsType.TimeZone());
        SetValue('_lang_sid', Format(SessionSettingsType.LanguageId()));
        SetValue('_lang_slocale', Format(SessionSettingsType.LocaleId()));
        SetValue('_lang_staff', _Staff.Language);
        SetValue('_lang_staff_name', LanguageCu.GetCultureName(LanguageCu.GetLanguageIdOrDefault(_Staff.Language)));
        SetValue('_lang_store', _Store."Language Code");
        SetValue('_lang_store_name', LanguageCu.GetCultureName(LanguageCu.GetLanguageIdOrDefault(_Store."Language Code")));
        SetValue('_lang_init', LanguageCu.GetLanguageCode(_OriginalLanguageID));
        SetValue('_lang_init_id', Format(_OriginalLanguageID));
        SetValue('_lang_init_name', _OriginalLanguageID <> 0 ? LanguageCu.GetCultureName(_OriginalLanguageID) : '');
        _PosCtrl.UploadTranslations();
    end;

    /// <summary>
    /// Returns the language code of the POS session. Usually Staff."Language Code", Store."Language Code" or a Code based on the GlobalLanguage ID, if found.
    /// </summary>
    /// <returns>BC Users have more language options based on the ID from the virtual table "Windows Language" rather then the Code from the data-based Language table in BC</returns>
    procedure GetLanguageID(): Integer
    begin
        if _LanguageID = 0 then
            exit(System.GlobalLanguage());
        exit(_LanguageID);
    end;

    /// <summary>
    /// Returns the language code of the POS session. Usually Staff."Language Code", Store."Language Code" or a Code based on the GlobalLanguage ID, if found.
    /// </summary>
    /// <returns>BC Users have more language options based on the ID from the virtual table "Windows Language" rather then the Code from the data-based Language table in BC</returns>
    procedure GetLanguageCode(): Code[10]
    var
        LanguageCu: Codeunit "Language";
    begin
        if _LanguageCode = '' then
            exit(LanguageCu.GetLanguageCode(System.GlobalLanguage()));
        exit(_LanguageCode);
    end;

    /// <summary>
    /// Returns the original language ID of the POS session. This is usually the language ID of the BC user session. Note: The Language.ID is from "Windows Language" table while Language.Code is from "Language" table, so there are more IDs that exist than Codes.
    /// </summary>
    /// <returns>The original language id of the Singleinstance session, before UpdateLanguage affected System.GlobalLanguage</returns>
    procedure GetOriginalLanguageID(): Integer
    begin
        exit(_OriginalLanguageID);
    end;

    /// <summary>
    /// NOTE: Only for Tests, should remain internal. Sets the "original" language ID of the session. Original Language ID should always be the GlobalLanguage from when the session was initialized, before the language was changed. Usually SessionSettings.LanguageId().
    /// </summary>
    /// <param name="id">The new LanguageId</param>
    internal procedure Testing_SetOriginalLanguageID(id: Integer)
    begin
        _OriginalLanguageID := id;
    end;

    [Obsolete('Not used', '26.0')]
    procedure IsLanguageProfileSet(): boolean
    begin
    end;

    [Obsolete('Not used', '26.0')]
    procedure SetLanguageForProfile(LanguageCodeSet: code[10]): boolean
    begin
        SetValue('_langprofileobsolete', LanguageCodeSet); // temporarily support public api
    end;

    [Obsolete('Not used', '26.0')]
    procedure GetLanguageForProfile(): code[10]
    begin
        exit(GetValue('_langprofileobsolete')); // temporarily support public api
    end;

    #endregion POS Language 

    #region POS Image 

    /// <summary> Used to provide an empty recID for methods like SetImage </summary>
    procedure EmptyRecordId() recID: RecordId
    begin
    end;

    /// <summary>
    /// Images should be set via LSC Retail Image Link. If the control is created on-the-fly as a temporary record, this method can be used to link an image to it.
    /// </summary>
    /// <param name="r">Temporary POS Control Record</param>
    /// <param name="rID">RecordId of the RetailImageLink</param>
    procedure SetImage(var r: Record "LSC POS Media Control"; rID: RecordId)
    var
        PosImgUtils: Codeunit "LSC POS Image Utils";
        imgID: Text;
    begin
        imgID := PosImgUtils.GetImgCode(rID);
        PosImgUtils.SetTempControlImage("LSC POS Control Type"::"Media", r."Control ID", imgID);
    end;

    /// <summary>
    /// Images should be set via LSC Retail Image Link. If the control is created on-the-fly as a temporary record, this method can be used to link an image to it.
    /// </summary>
    /// <param name="r">Temporary POS Control Record</param>
    /// <param name="rID">RecordId of the RetailImageLink</param>
    procedure SetImage(var r: Record "LSC POS Menu Header"; rID: RecordId)
    var
        PosImgUtils: Codeunit "LSC POS Image Utils";
        imgID: Text;
    begin
        imgID := PosImgUtils.GetImgCode(rID);
        PosImgUtils.SetTempControlImage(Enum::"LSC POS Control Type"::Menu, r."Menu ID", imgID);
    end;

    /// <summary>
    /// Images should be set via LSC Retail Image Link. If the control is created on-the-fly as a temporary record, this method can be used to link an image to it.
    /// </summary>
    /// <param name="r">Temporary POS Control Record</param>
    /// <param name="rID">RecordId of the RetailImageLink</param>
    procedure SetImage(var r: Record "LSC POS Menu Line"; rID: RecordId)
    var
        PosImgUtils: Codeunit "LSC POS Image Utils";
        PosCtrlUtils: Codeunit "LSC POS Control Utils";
        imgID: Text;
    begin
        imgID := PosImgUtils.GetImgCode(rID);
        PosImgUtils.SetTempControlImage("LSC POS Control Type"::MenuButton, PosCtrlUtils.GetTextAndNumberControlID(r."Menu ID", r."Key No."), imgID);
    end;

    /// <summary>
    /// Images should be set via LSC Retail Image Link. If the control is created on-the-fly as a temporary record, this method can be used to link an image to it.
    /// </summary>
    /// <param name="r">Temporary POS Control Record</param>
    /// <param name="rID">RecordId of the RetailImageLink</param>
    procedure SetImage(var r: Record "LSC POS Panel"; rID: RecordId)
    var
        PosImgUtils: Codeunit "LSC POS Image Utils";
        imgID: Text;
    begin
        imgID := PosImgUtils.GetImgCode(rID);
        PosImgUtils.SetTempControlImage(Enum::"LSC POS Control Type"::Panel, r."Control ID", imgID);
    end;

    /// <summary>
    /// Makes sure that the first image linked to the recID is available from POS Web Templates.
    /// </summary>
    /// <param name="recID">The RecordId in Retail Image Links.</param>
    /// <param name="imgID">Used to create the final ImageID, like data-ls-pos-img="myimgid", leave it blank to use the default/unnamed ID.</param>
    /// <returns>The final ImageID, which can be used as a parameter to LS.GetImageUrl(data.imgID) in Javascript.</returns>
    procedure AddWebTemplateImage(recID: RecordId; imgID: Code[20]): Text
    begin
        exit(AddWebTemplateImage(recID, imgID, Enum::"LSC Retail Image Link Type"::Image));
    end;

    procedure AddWebTemplateImage(recID: RecordId; imgID: Code[20]; linkType: Enum "LSC Retail Image Link Type"): Text
    begin
        exit(_PosCtrl.GetWebTemplateHandler.AddWebTemplateImage(recID, imgID, linkType));
    end;

    /// <summary>
    /// Makes sure that all images linked to the recID is available from POS Web Templates.
    /// </summary>
    /// <param name="recID">The RecordId in Retail Image Links.</param>
    /// <param name="imgID">Used to create the final ImageIDs (as a prefix), like data-ls-pos-img="myimgid_0", leave it blank to use the default/unnamed ID.</param>
    /// <returns>A List of the final ImageIDs, which can be used as a parameter to LS.GetImageUrl(data.imgID) in Javascript.</returns>
    procedure AddWebTemplateImages(recID: RecordId; imgID: Code[20]) codes: List of [Text]
    begin
        exit(AddWebTemplateImages(recID, imgID, Enum::"LSC Retail Image Link Type"::Image));
    end;

    procedure AddWebTemplateImages(recID: RecordId; imgID: Code[20]; linkType: Enum "LSC Retail Image Link Type") codes: List of [Text]
    begin
        exit(_PosCtrl.GetWebTemplateHandler.AddWebTemplateImages(recID, imgID, linkType));
    end;

    internal procedure SetPosPicture(pRecID: RecordID)
    var
        PosImgUtils: Codeunit "LSC POS Image Utils";
        LinkType: Enum "LSC Retail Image Link Type";
        ImgID: Text;
        IsHandled: Boolean;
    begin
        if pRecID.TableNo = Database::"LSC Store" then
            LinkType := LinkType::Logo;
        OnBeforeSetPosPicture(pRecID, LinkType, IsHandled);
        if IsHandled then
            exit;
        ImgID := PosImgUtils.GetImgCode(pRecID, LinkType);
        PosImgUtils.AddSpecialImage(ImgID);
        SetValue("LSC POS Tag"::POS_PICTURE, ImgID);
    end;

    /// <summary>
    /// Used to change the active image in the session to the image of the lineRec (if enabled in the Terminal). If none is selected, the Store logo is used. Prefer listening to the OnBeforeSetPosPicture event over invoking this method directly.
    /// </summary>
    /// <param name="lineRec">POS Transaction Line. Usually the currently selected line.</param>
    procedure UpdatePosPicture(var lineRec: Record "LSC POS Trans. Line")
    var
        itemVariant: Record "Item Variant";
        item: Record Item;
        recID: RecordId;
    begin
        if not _Terminal."Show Item Image" then begin
            SetPosPicture(EmptyRecordId);
            exit;
        end;
        recID := _Store.RecordId;
        if lineRec."Entry Type" = lineRec."Entry Type"::Item then begin
            if true in [
                lineRec."Entry Status" <> lineRec."Entry Status"::Voided,
                not _InterfaceProfile."Hide Voided Lines"
            ] then begin
                if item.Get(lineRec.Number) then begin
                    recID := item.RecordId;
                    if lineRec."Variant Code" <> '' then
                        if itemVariant.Get(lineRec.Number, lineRec."Variant Code") then
                            recID := itemVariant.RecordId;
                end;
            end;
        end;
        SetPosPicture(recID);
    end;

    procedure SetImageResolution(e: Enum "LSC POS Image Type"; w: Integer) oldVal: Integer
    var
        oldValTxt: Text;
    begin
        oldValTxt := SetValue(StrSubstNo('_IMGRES_%1', e.AsInteger), Format(w)); // Note: w < 0 -> actual 0 (instead of default)
        if true in [
            oldValTxt = '',
            not Evaluate(oldVal, oldValTxt)
        ] then
            exit(0);
    end;

    procedure GetImageResolution(e: Enum "LSC POS Image Type") w: Integer
    var
        t: Text;
    begin
        t := GetValue(StrSubstNo('_IMGRES_%1', e.AsInteger));
        if true in [
            t = '',
            not Evaluate(w, t)
        ] then
            exit(0);
        // w < 0 is supported as a "forced 0" (clamped in client)
    end;

    #endregion POS Image 

    #region POS Browser Control 

    procedure GetHtmlURL(pRecID: RecordID; pFieldNo: Integer): Text
    begin
        exit('lshtml://' + Format(pRecID) + '/' + Format(pFieldNo));
    end;

    procedure SetPosHtmlUrl(pUrl: Text)
    begin
        SetValue("LSC POS Tag"::POS_HTML, pUrl);
    end;

    procedure GetPosHtml(): Text
    begin
        exit(GetValue("LSC POS Tag"::POS_HTML));
    end;

    // POS - Internal in 18.4
    procedure SetPosHtml(var lineRec: Record "LSC POS Trans. Line"): Boolean
    var
        ItemUrls: Record "LSC Item HTML ML";
        OfferUrls: Record "LSC Offer HTML ML";
        Item: Record Item;
        Offer: Record "LSC Offer";
    begin
        SetPosHtmlUrl('');
        if lineRec."Entry Type" = lineRec."Entry Type"::Item then begin
            if Item.Get(lineRec.Number) then begin
                if ItemUrls.Get(lineRec.Number, '') then begin
                    if ItemUrls.URL <> '' then begin
                        SetPosHtmlUrl(ItemUrls.URL);
                        exit(true);
                    end
                    else begin
                        if ItemUrls.Html.HasValue then begin
                            ItemUrls.CalcFields(Html);
                            SetPosHtmlUrl(GetHtmlURL(ItemUrls.RecordId, ItemUrls.FieldNo(Html)));
                            exit(true);
                        end;
                    end;
                end;
            end;
        end
        else
            if lineRec."Text Type" = lineRec."Text Type"::"Deal Header" then begin
                if Offer.Get(lineRec."Promotion No.") then begin
                    if OfferUrls.Get(lineRec."Promotion No.", '') then begin
                        if OfferUrls.URL <> '' then begin
                            SetPosHtmlUrl(OfferUrls.URL);
                            exit(true);
                        end
                        else begin
                            if OfferUrls.Html.HasValue then begin
                                OfferUrls.CalcFields(Html);
                                SetPosHtmlUrl(GetHtmlURL(OfferUrls.RecordId, OfferUrls.FieldNo(Html)));
                                exit(true);
                            end;
                        end;
                    end;
                end;
            end;

        exit(false);
    end;

    #endregion POS Browser Control 

    #region Curr Menu 

    procedure GetActivePermissionGroup(): Code[20]
    var
        ActivePermGroupRec: Code[20];
    begin
        if (not StaffHasManagerPrivileges) and MgrKey then begin
            ActivePermGroupRec := _KeyLockPermRec.Code; //KEYLOCK (might be empty)
            if _ManagerRec.ID <> '' then
                ActivePermGroupRec := _ManagerPermRec.Code; //Manager Login
        end;

        if ActivePermGroupRec = '' then
            ActivePermGroupRec := _PermissionGroupRec.Code;

        exit(ActivePermGroupRec);
    end;

    procedure GetStartMenu(): Code[20]
    var
        ActivePermGroupRec: Code[20];
        StaffPermGroupMenu: Record "LSC STAFF POS PER Grp Menu";
    begin
        OnBeforeGetMenu(_SelectedMenu, _MenuType::Start);
        if _SelectedMenu <> '' then
            exit(_SelectedMenu);

        ActivePermGroupRec := GetActivePermissionGroup();
        if StaffPermGroupMenu.Get(MenuProfileID, ActivePermGroupRec) then
            if StaffPermGroupMenu."Start Menu" <> '' then
                exit(StaffPermGroupMenu."Start Menu");
        exit(_MenuProfile."Start Menu");
    end;

    procedure GetSalesMenu(): Code[20]
    var
        ActivePermGroupRec: Code[20];
        StaffPermGroupMenu: Record "LSC STAFF POS PER Grp Menu";
    begin
        OnBeforeGetMenu(_SelectedMenu, _MenuType::Sales);
        if _SelectedMenu <> '' then
            exit(_SelectedMenu);

        ActivePermGroupRec := GetActivePermissionGroup();
        if StaffPermGroupMenu.Get(MenuProfileID, ActivePermGroupRec) then
            if StaffPermGroupMenu."Sales Menu" <> '' then
                exit(StaffPermGroupMenu."Sales Menu");
        exit(_MenuProfile."Sales Menu");
    end;

    procedure GetPaymentMenu(): Code[20]
    var
        ActivePermGroupRec: Code[20];
        StaffPermGroupMenu: Record "LSC STAFF POS PER Grp Menu";
    begin
        OnBeforeGetMenu(_SelectedMenu, _MenuType::Payment);
        if _SelectedMenu <> '' then
            exit(_SelectedMenu);

        ActivePermGroupRec := GetActivePermissionGroup();
        if StaffPermGroupMenu.Get(MenuProfileID, ActivePermGroupRec) then
            if StaffPermGroupMenu."Payment Menu" <> '' then
                exit(StaffPermGroupMenu."Payment Menu");
        exit(_MenuProfile."Payment Menu");
    end;

    procedure GetRefundMenu(): Code[20]
    var
        ActivePermGroupRec: Code[20];
        StaffPermGroupMenu: Record "LSC STAFF POS PER Grp Menu";
    begin
        OnBeforeGetMenu(_SelectedMenu, _MenuType::Refund);
        if _SelectedMenu <> '' then
            exit(_SelectedMenu);

        ActivePermGroupRec := GetActivePermissionGroup();
        if StaffPermGroupMenu.Get(MenuProfileID, ActivePermGroupRec) then
            if StaffPermGroupMenu."Refund Payment Menu" <> '' then
                exit(StaffPermGroupMenu."Refund Payment Menu");
        exit(_MenuProfile."Refund Payment Menu");
    end;

    procedure GetTenderMenu(): Code[20]
    var
        ActivePermGroupRec: Code[20];
        StaffPermGroupMenu: Record "LSC STAFF POS PER Grp Menu";
    begin
        OnBeforeGetMenu(_SelectedMenu, _MenuType::Tender);
        if _SelectedMenu <> '' then
            exit(_SelectedMenu);

        ActivePermGroupRec := GetActivePermissionGroup();
        if StaffPermGroupMenu.Get(MenuProfileID, ActivePermGroupRec) then
            if StaffPermGroupMenu."Tender Op. Menu" <> '' then
                exit(StaffPermGroupMenu."Tender Op. Menu");
        exit(_MenuProfile."Tender Op. Menu");
    end;

    procedure GetNegAdjMenu(): Code[20]
    var
        ActivePermGroupRec: Code[20];
        StaffPermGroupMenu: Record "LSC STAFF POS PER Grp Menu";
    begin
        OnBeforeGetMenu(_SelectedMenu, _MenuType::NegAdj);
        if _SelectedMenu <> '' then
            exit(_SelectedMenu);

        ActivePermGroupRec := GetActivePermissionGroup();
        if StaffPermGroupMenu.Get(MenuProfileID, ActivePermGroupRec) then
            if StaffPermGroupMenu."Neg. Adj. Menu" <> '' then
                exit(StaffPermGroupMenu."Neg. Adj. Menu");
        exit(_MenuProfile."Neg. Adj. Menu");
    end;

    procedure GetPhysInvMenu(): Code[20]
    var
        ActivePermGroupRec: Code[20];
        StaffPermGroupMenu: Record "LSC STAFF POS PER Grp Menu";
    begin
        OnBeforeGetMenu(_SelectedMenu, _MenuType::PhysInv);
        if _SelectedMenu <> '' then
            exit(_SelectedMenu);

        ActivePermGroupRec := GetActivePermissionGroup();
        if StaffPermGroupMenu.Get(MenuProfileID, ActivePermGroupRec) then
            if StaffPermGroupMenu."Phys. Inv. Menu" <> '' then
                exit(StaffPermGroupMenu."Phys. Inv. Menu");
        exit(_MenuProfile."Phys. Inv. Menu");
    end;

    procedure GetAdd1Menu(): Code[20]
    var
        ActivePermGroupRec: Code[20];
        StaffPermGroupMenu: Record "LSC STAFF POS PER Grp Menu";
    begin
        OnBeforeGetMenu(_SelectedMenu, _MenuType::Add1);
        if _SelectedMenu <> '' then
            exit(_SelectedMenu);

        ActivePermGroupRec := GetActivePermissionGroup();
        if StaffPermGroupMenu.Get(MenuProfileID, ActivePermGroupRec) then
            if StaffPermGroupMenu."Additional menu 1" <> '' then
                exit(StaffPermGroupMenu."Additional menu 1");
        exit(_MenuProfile."Additional Menu 1");
    end;

    procedure GetAdd2Menu(): Code[20]
    var
        ActivePermGroupRec: Code[20];
        StaffPermGroupMenu: Record "LSC STAFF POS PER Grp Menu";
    begin
        OnBeforeGetMenu(_SelectedMenu, _MenuType::Add2);
        if _SelectedMenu <> '' then
            exit(_SelectedMenu);

        ActivePermGroupRec := GetActivePermissionGroup();
        if StaffPermGroupMenu.Get(MenuProfileID, ActivePermGroupRec) then
            if StaffPermGroupMenu."Additional menu 2" <> '' then
                exit(StaffPermGroupMenu."Additional menu 2");
        exit(_MenuProfile."Additional Menu 2");
    end;

    procedure GetAdd3Menu(): Code[20]
    var
        ActivePermGroupRec: Code[20];
        StaffPermGroupMenu: Record "LSC STAFF POS PER Grp Menu";
    begin
        OnBeforeGetMenu(_SelectedMenu, _MenuType::Add3);
        if _SelectedMenu <> '' then
            exit(_SelectedMenu);

        ActivePermGroupRec := GetActivePermissionGroup();
        if StaffPermGroupMenu.Get(MenuProfileID, ActivePermGroupRec) then
            if StaffPermGroupMenu."Additional menu 3" <> '' then
                exit(StaffPermGroupMenu."Additional menu 3");
        exit(_MenuProfile."Additional Menu 3");
    end;

    procedure GetQuickCashMenu(): Code[20]
    begin
        OnBeforeGetMenu(_SelectedMenu, _MenuType::QuickCash);
        if _SelectedMenu <> '' then
            exit(_SelectedMenu);
        exit(_MenuProfile."Quick Cash Menu");
    end;

    #endregion Curr Menu 

    #region Events 

    local procedure SignalOnStaffChanged(oldStaffID: Text; newStaffID: Text)
    begin
        SetValue("LSC POS Tag"::STAFF_ID, _Staff.ID);
        SetValue("LSC POS Tag"::STAFF_FIRSTNAME, _Staff."First Name");
        SetValue("LSC POS Tag"::STAFF_LASTNAME, _Staff."Last Name");
        OnStaffChanged(oldStaffID, newStaffID);
    end;

    local procedure SignalOnStoreChanged(oldStoreID: Text; newStoreID: Text)
    var
        PosHardwareInterface: Codeunit "LSC POS Hardware Interface";
    begin
        SetValue("LSC POS Tag"::STORE_NO, StoreNo());
        SetValue("LSC POS Tag"::STORE_NAME, _Store.Name);
        SetValue("LSC POS Tag"::SECONDARY_POS_STYLE, _Store."Style Profile");
        SetValue("LSC POS Tag"::SECONDARY_INTERFACE_PROFILE, _Store."Interface Profile");
        SetValue("LSC POS Tag"::SECONDARY_MENU_PROFILE, _Store."Menu Profile");
        SetValue("LSC POS Tag"::PRINTER_BITMAP_NO, Format(PosHardwareInterface.GetPrinterBitmapNo()));
        SetValue("LSC POS Tag"::PRINTER_LOGO, PosHardwareInterface.GetPrinterLogo());

        OnStoreChanged(oldStoreID, newStoreID);
    end;

    local procedure SignalOnTerminalChanged(oldTerminalID: Text; newTerminalID: Text)
    var
        PosHardwareInterface: Codeunit "LSC POS Hardware Interface";
    begin
        SetValue("LSC POS Tag"::TERMINAL_NO, _Terminal."No.");
        SetValue("LSC POS Tag"::TERMINAL_DESCRIPTION, _Terminal.Description);
        SetValue("LSC POS Tag"::PRINTER_BITMAP_NO, Format(PosHardwareInterface.GetPrinterBitmapNo()));
        SetValue("LSC POS Tag"::PRINTER_LOGO, PosHardwareInterface.GetPrinterLogo());
        SetValue("LSC POS Tag"::AutoLogoffTimeout, FORMAT(_Terminal."AutoLogoff After (Min.)"));

        OnTerminalChanged(oldTerminalID, newTerminalID);
    end;

    [IntegrationEvent(false, false)]
    local procedure OnStaffChanged(oldStaffID: Text; newStaffID: Text)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnStoreChanged(oldStoreNo: Text; newStoreNo: Text)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnTerminalChanged(oldTerminalNo: Text; newTerminalNo: Text)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnFunctionalityProfileChanged(oldFunctionalityProfileiD: Text; newFunctionalityProfileiD: Text)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnInterfaceProfileChanged(oldInterfaceProfileiD: Text; newInterfaceProfileiD: Text)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnGetEFTUtility(var iEFTUtil: interface "LSC IEFTUtility"; var isHandled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnGetEFTUtility2(var iEFTUtil2: interface "LSC IEFTUtility2"; var isHandled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnGetTokenUtility(var iTokenUtility: interface "LSC IToken Utility"; var IsHandled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnGetReferencedReturns(var iEFTReferencedReturns: interface "LSC IReferenced Returns"; var IsHandled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnGetEFTPrinter(var iEFTPrinter: interface "LSC IEFTPrinter"; var isHandled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterRefreshMgrStatus(var _mgrKey: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeUpdateLanguageCode(var LanguageCode: Code[10])
    begin
    end;

    [IntegrationEvent(false, false)]
    [Obsolete('Not used. Use Store.OnBeforeVerifyStorePostingSetup instead', '27.0')]
    internal procedure OnBeforeVerifyStorePostingSetup(Store: Record "LSC Store"; var Ishandled: boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeSetManagerID(Staff: Record "LSC Staff"; var IsHandled: boolean; var ReturnValue: boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterSetStaff(StaffID: Code[20])
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeGetMenu(var SelectedMenu: Code[20]; MenuType: enum "LSC Menu Types")
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeMenuPermission(var MenuLine: Record "LSC POS Menu Line"; FuncCode: Code[20]; var MessageTxt: Text; var ReturnValue: Boolean; var IsHandled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterStaffLoadPermissions(var StaffPermissionGroup: Record "LSC STAFF PER Group"; Staff: Record "LSC Staff")
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforePermissionItem(var ReturnValue: Boolean; FuncCode: Code[20]; var IsHandled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeStaffReturnInTransaction(PermissionGroupRec: Record "LSC STAFF PER Group"; var ReturnValue: Boolean; var IsHandled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforePermissionItemDISC(var Item: Record Item; var MessageTxt: Text; var IsHandled: Boolean; var ReturnValue: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforePermissionItemTDISC(var Item: Record Item; var MessageTxt: Text; var IsHandled: Boolean; var ReturnValue: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterPasswordValidityPass(var Staff: Record "LSC Staff"; FunctionalityProfile: Record "LSC POS Func. Profile"; var ReasonText: Text[80]; var IsError: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterPasswordValidityFail(var Staff: Record "LSC Staff"; FunctionalityProfile: Record "LSC POS Func. Profile")
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeCheckPermission(FuncCode: Code[20]; PerMissionGroupRec: Record "LSC STAFF PER Group"; Staff: Record "LSC Staff"; var MessageText: Text; var IsHandled: Boolean; var ReturnValue: Boolean)
    begin
    end;

    [IntegrationEvent(true, true, true)]
    local procedure OnTerminalChangedSetValue()
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnValidateLogin(Store: Record "LSC Store"; pShiftNo: Code[1]; var pReasonText: Text[80])
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterInit()
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeSetPosPicture(var pRecID: RecordID; var pLinkType: Enum "LSC Retail Image Link Type"; var IsHandled: Boolean)
    begin
    end;

    #endregion Events 
}
