codeunit 99001452 "LSC BO Utils" implements "LSC IBOUtils"
{

    var
        LSExtUtil: Codeunit "LSC External Functions Util";
        Day: Integer;
        Month: Integer;
        Year: Integer;
        Text005: Label 'String contains less than #1#### substrings.';
        Text006: Label 'String contains less than #1#### commastrings.';

    procedure CalcNewDateTime(var NextDate: Date; var NextTime: Time; Interval: Integer; Unit: Option Second,Minute,Hour,Day)
    var
        DateTimeNow: Decimal;
        DateTimeDec: Decimal;
    begin
        if Interval = 0 then begin
            NextDate := 0D;
            NextTime := 0T;
            exit;
        end;
        if NextDate = 0D then
            exit;
        DateTimeDec := ((NextDate - Today) * 86400) + Round((NextTime - 000000T) / 1000, 1);
        DateTimeNow := Round((Time - 000000T) / 1000, 1);
        case Unit of
            Unit::Second:
                Interval := Interval;
            Unit::Minute:
                Interval := Interval * 60;
            Unit::Hour:
                Interval := Interval * 3600;
            Unit::Day:
                Interval := Interval * 86400;
        end;

        while DateTimeDec <= DateTimeNow do
            DateTimeDec := DateTimeDec + Interval;
        NextDate := Today + Round(DateTimeDec / 86400, 1.0, '<');
        NextTime := 000000T + (DateTimeDec - (Round(DateTimeDec / 86400, 1.0, '<') * 86400)) * 1000;
    end;

    procedure AddIntervalToDateTime(var NextDate: Date; var NextTime: Time; Interval: Decimal; Unit: Option Second,Minute,Hour,Day)
    var
        DateTimeDec: Decimal;
    begin
        if Interval = 0 then begin
            NextDate := 0D;
            NextTime := 0T;
            exit;
        end;
        if NextDate = 0D then
            exit;
        DateTimeDec := ((NextDate - Today) * 86400) + Round((NextTime - 000000T) / 1000, 1);
        case Unit of
            Unit::Second:
                Interval := Interval;
            Unit::Minute:
                Interval := Interval * 60;
            Unit::Hour:
                Interval := Interval * 3600;
            Unit::Day:
                Interval := Interval * 86400;
        end;

        DateTimeDec := DateTimeDec + Interval;

        if DateTimeDec < 0 then
            NextDate := Today + Round(DateTimeDec / 86400, 1.0, '>')
        else
            NextDate := Today + Round(DateTimeDec / 86400, 1.0, '<');

        NextTime := 000000T + (DateTimeDec - (Round(DateTimeDec / 86400, 1.0, '<') * 86400)) * 1000;
    end;

    procedure StrToDec(Str: Text[30]): Decimal
    var
        Dec: Decimal;
    begin
        if not Evaluate(Dec, Str) then
            exit(0)
        else
            exit(Dec);
    end;

    procedure DecToStr(DecIn: Decimal): Text[30]
    begin
        exit(Format(DecIn, 0, '<Sign><Integer><Decimals>'));
    end;

    procedure IntegerToStr(Int: Integer): Text[50]
    begin
        exit(DelChr(Format(Int), '=', ',.'));
    end;

    procedure DateToStr(DateIn: Date; DateFormat: Text[30]): Text[30]
    var
        Txt: Text[30];
    begin
        if DateIn = 0D then
            exit('');
        Day := Date2DMY(DateIn, 1);
        Month := Date2DMY(DateIn, 2);
        Year := Date2DMY(DateIn, 3);
        Txt := '';
        while DateFormat <> '' do begin
            case CopyStr(DateFormat, 1, 1) of
                'Y':
                    begin
                        if StrPos(DateFormat, 'YYYY') <> 0 then begin
                            Txt := Txt + Format(Year);
                            DateFormat := DelStr(DateFormat, 1, 4);
                        end
                        else begin
                            Txt := Txt + CopyStr(Format(Year), 3, 2);
                            DateFormat := DelStr(DateFormat, 1, 2);
                        end;
                    end;
                'M':
                    begin
                        if Month < 10 then
                            Txt := Txt + '0' + Format(Month)
                        else
                            Txt := Txt + Format(Month);
                        DateFormat := DelStr(DateFormat, 1, 2);
                    end;
                'D':
                    begin
                        if Day < 10 then
                            Txt := Txt + '0' + Format(Day)
                        else
                            Txt := Txt + Format(Day);
                        DateFormat := DelStr(DateFormat, 1, 2);
                    end;
                else begin
                    Txt := Txt + CopyStr(DateFormat, 1, 1);
                    DateFormat := DelStr(DateFormat, 1, 1);
                end;
            end;
        end;
        exit(Txt);
    end;

    procedure HourToStr(DecIn: Decimal): Text[4]
    var
        Txt: Text[30];
    begin
        Txt := Format(Round(DecIn, 1.0));
        if StrLen(Txt) = 0 then
            Txt := '00';
        if StrLen(Txt) = 1 then
            Txt := '0' + Txt;
        DecIn := Round(60 * (DecIn - Round(DecIn, 1.0)), 1.0);
        if DecIn < 10 then begin
            if DecIn < 1 then
                Txt := Txt + '00'
            else
                Txt := Txt + '0' + Format(DecIn);
        end else
            Txt := Txt + Format(DecIn);
        exit(Txt);
    end;

    procedure TimeToStr(TimeIn: Time): Text[4]
    var
        Txt: Text[30];
    begin
        Txt := Format(TimeIn, 0, '<hours24,2>:<minutes,2>:<seconds,2>');
        Txt := CopyStr(DelChr(Txt, '=', '-,.:'), 1, 4);
        if CopyStr(Txt, 1, 1) = ' ' then
            Txt := '0' + CopyStr(Txt, 2, 3);
        exit(Txt);
    end;

    procedure BoolToStr(BoolIn: Boolean): Text[30]
    begin
        if BoolIn then
            exit('1')
        else
            exit('0');
    end;

    procedure BoolToDec(BoolIn: Boolean): Decimal
    begin
        if BoolIn then
            exit(1)
        else
            exit(0);
    end;

    procedure OptToStr(OptIn: Integer): Text[30]
    begin
        exit(Format(OptIn));
    end;

    procedure StrToDate(DateTxt: Text[30]; DateFormat: Text[30]): Date
    begin
        if (DateTxt = '') or (DateFormat = '') or (StrLen(DateTxt) <> StrLen(DateFormat)) then
            exit(0D);

        while DateFormat <> '' do begin
            case CopyStr(DateFormat, 1, 1) of
                'Y':
                    begin
                        if StrPos(DateFormat, 'YYYY') <> 0 then begin
                            if not Evaluate(Year, CopyStr(DateTxt, 1, 4)) then
                                Year := 0;
                            DateTxt := DelStr(DateTxt, 1, 4);
                            DateFormat := DelStr(DateFormat, 1, 4);
                        end
                        else begin
                            if not Evaluate(Year, '20' + CopyStr(DateTxt, 1, 2)) then
                                Year := 0;
                            DateTxt := DelStr(DateTxt, 1, 2);
                            DateFormat := DelStr(DateFormat, 1, 2);
                        end;
                    end;
                'M':
                    begin
                        if not Evaluate(Month, CopyStr(DateTxt, 1, 2)) then
                            Month := 0;
                        DateTxt := DelStr(DateTxt, 1, 2);
                        DateFormat := DelStr(DateFormat, 1, 2);
                    end;
                'D':
                    begin
                        if not Evaluate(Day, CopyStr(DateTxt, 1, 2)) then
                            Day := 0;
                        DateTxt := DelStr(DateTxt, 1, 2);
                        DateFormat := DelStr(DateFormat, 1, 2);
                    end;
                else begin
                    DateTxt := DelStr(DateTxt, 1, 1);
                    DateFormat := DelStr(DateFormat, 1, 1);
                end;
            end;
        end;

        exit(DMY2Date(Day, Month, Year));
    end;

    procedure StrToTime(TimeTxt: Text[30]) xTime: Time
    begin
        if not Evaluate(xTime, CopyStr(TimeTxt, 9, StrLen(TimeTxt))) then
            xTime := 0T;
        exit(xTime);
    end;

    procedure CalcMinutesFromDateTimeToDateTime(FromDateTime: DateTime; ToDateTime: DateTime): Integer
    begin
        if FromDateTime = 0DT then
            exit(0);
        if ToDateTime = 0DT then
            exit(0);
        exit(Round(((ToDateTime - FromDateTime) / 60000), 1));
    end;

    procedure CalcDateTimeMinutes(Minutes: Integer): Integer
    begin
        exit(Minutes * 60000);
    end;

    procedure SeparateActKey(Position: Integer; Str: Text[250]): Text[250]
    var
        OutPut: Text[250];
        SearchStr: Text[250];
        CommaPos: Integer;
        I: Integer;
    begin
        SearchStr := Str;
        for I := 1 to Position do begin
            CommaPos := StrPos(SearchStr, ';');
            if CommaPos = 0 then begin
                if I = Position then
                    OutPut := SearchStr
                else
                    Error(Text005, Position);
            end else begin
                if I = Position then
                    OutPut := CopyStr(SearchStr, 1, CommaPos - 1)
                else begin
                    if CommaPos = StrLen(SearchStr) then
                        if I = Position - 1 then
                            SearchStr := ''
                        else
                            Error(Text006, Position)
                    else
                        SearchStr := CopyStr(SearchStr, CommaPos + 1, StrLen(SearchStr));
                end;
            end;
        end;
        exit(OutPut);
    end;

    procedure SeparateTableKey(Position: Integer; Str: Text[250]): Text[250]
    var
        SearchStr: Text[250];
        OutPut: Text[250];
        SeparateChr: Text[1];
        CommaPos: Integer;
        I: Integer;
    begin
        SeparateChr := GetSeparateChar;
        SearchStr := Str;
        for I := 1 to Position do begin

            CommaPos := StrPos(SearchStr, SeparateChr);

            if CommaPos = 0 then begin
                if I = Position then
                    OutPut := SearchStr
                else
                    Error(Text005, Position);
            end else begin
                if I = Position then
                    OutPut := CopyStr(SearchStr, 1, CommaPos - 1)
                else begin
                    if CommaPos = StrLen(SearchStr) then
                        if I = Position - 1 then
                            SearchStr := ''
                        else
                            Error(Text006, Position)
                    else
                        SearchStr := CopyStr(SearchStr, CommaPos + 1, StrLen(SearchStr));
                end;
            end;
        end;
        exit(OutPut);
    end;

    procedure SeparateCombinedValue(Position: Integer; Str: Text[100]): Text[100]
    var
        SearchStr: Text[100];
        OutPut: Text[100];
        SeparateValueChr: Text[1];
        CommaPos: Integer;
        I: Integer;
    begin
        SearchStr := Str;
        SeparateValueChr := GetSeparateValueChar;
        for I := 1 to Position do begin
            CommaPos := StrPos(SearchStr, SeparateValueChr);
            if CommaPos = 0 then begin
                if I = Position then
                    OutPut := SearchStr
                else
                    Error(Text005, Position);
            end else begin
                if I = Position then
                    OutPut := CopyStr(SearchStr, 1, CommaPos - 1)
                else begin
                    if CommaPos = StrLen(SearchStr) then
                        if I = Position - 1 then
                            SearchStr := ''
                        else
                            Error(Text006, Position)
                    else
                        SearchStr := CopyStr(SearchStr, CommaPos + 1, StrLen(SearchStr));
                end;
            end;
        end;
        exit(OutPut);
    end;

    procedure CombineActKey(NoOfValues: Integer; Val1: Text[250]; Val2: Text[250]; Val3: Text[250]; Val4: Text[250]; Val5: Text[250]): Text[250]
    var
        SeparateChr: Text[1];
        Text007: Label 'An action key can only have 5 fields.';
    begin
        SeparateChr := ';';
        case NoOfValues of
            0:
                exit('');
            1:
                exit(Val1);
            2:
                exit(Val1 + SeparateChr + Val2);
            3:
                exit(Val1 + SeparateChr + Val2 + SeparateChr + Val3);
            4:
                exit(Val1 + SeparateChr + Val2 + SeparateChr + Val3 + SeparateChr + Val4);
            5:
                exit(Val1 + SeparateChr + Val2 + SeparateChr + Val3 + SeparateChr + Val4 + SeparateChr + Val5);
            else
                Error(Text007);
        end;
    end;

    procedure CombineTableKey(NoOfValues: Integer; Val1: Text[250]; Val2: Text[250]; Val3: Text[250]; Val4: Text[250]; Val5: Text[250]): Text[250]
    var
        SeparateChr: Text[1];
        Text008: Label 'A primary table key can only have 5 fields.';
    begin

        SeparateChr := GetSeparateChar;

        case NoOfValues of
            0:
                exit('');
            1:
                exit(Val1);
            2:
                exit(Val1 + SeparateChr + Val2);
            3:
                exit(Val1 + SeparateChr + Val2 + SeparateChr + Val3);
            4:
                exit(Val1 + SeparateChr + Val2 + SeparateChr + Val3 + SeparateChr + Val4);
            5:
                exit(Val1 + SeparateChr + Val2 + SeparateChr + Val3 + SeparateChr + Val4 + SeparateChr + Val5);
            else
                Error(Text008);
        end;
    end;

    procedure CombineValue(NoOfValues: Integer; Val1: Text[50]; Val2: Text[50]; Val3: Text[50]; Val4: Text[50]; Val5: Text[50]): Text[250]
    var
        SeparateChr: Text[1];
        Text009: Label 'A combined value can only have 5 fields.';
    begin
        SeparateChr := GetSeparateValueChar;
        case NoOfValues of
            0:
                exit('');
            1:
                exit(Val1);
            2:
                exit(Val1 + SeparateChr + Val2);
            3:
                exit(Val1 + SeparateChr + Val2 + SeparateChr + Val3);
            4:
                exit(Val1 + SeparateChr + Val2 + SeparateChr + Val3 + SeparateChr + Val4);
            5:
                exit(Val1 + SeparateChr + Val2 + SeparateChr + Val3 + SeparateChr + Val4 + SeparateChr + Val5);
            else
                Error(Text009);
        end;
    end;

    procedure ConvertTableKeyToActKey(Value: Text[250]): Text[250]
    var
        TmpValue: Text[250];
        SeparateChr: Text[1];
    begin
        SeparateChr := GetSeparateChar;
        TmpValue := ConvertStr(Value, SeparateChr, ';');
        exit(ConvertCombinedValueToTableKey(TmpValue));
    end;

    procedure ConvertActKeyToTableKey(Value: Text[250]): Text[250]
    var
        TmpValue: Text[250];
        SeparateChr: Text[1];
    begin
        TmpValue := ConvertTableKeyToCombinedValue(Value);
        SeparateChr := GetSeparateChar;
        exit(ConvertStr(TmpValue, ';', SeparateChr));
    end;

    procedure ConvertCombinedValueToTableKey(Value: Text[250]): Text[250]
    var
        SeparateChr: Text[1];
        SeparateValueChr: Text[1];
    begin
        SeparateChr := GetSeparateChar;
        SeparateValueChr := GetSeparateValueChar;
        exit(ConvertStr(Value, SeparateValueChr, SeparateChr));
    end;

    procedure ConvertTableKeyToCombinedValue(Value: Text[250]): Text[250]
    var
        SeparateChr: Text[1];
        SeparateValueChr: Text[1];
    begin
        SeparateChr := GetSeparateChar;
        SeparateValueChr := GetSeparateValueChar;
        exit(ConvertStr(Value, SeparateChr, SeparateValueChr));
    end;

    procedure ValueIsCombined(Value: Text[250]): Boolean
    var
        SeparateValueChr: Text[1];
    begin
        SeparateValueChr := GetSeparateValueChar;
        exit((StrPos(Value, SeparateValueChr) > 0));
    end;

    procedure DelLeadingZeros(Str: Text[50]): Text[50]
    begin
        exit(DelChr(Str, '<', '0'));
    end;

    procedure Sleep(SleepX: Integer)
    var
        SleepStarts: Time;
    begin
        if SleepX < 0 then
            SleepX := 0;
        SleepStarts := Time;
        repeat
        until (Time - SleepStarts) > SleepX;
    end;

    procedure ItemValidInStore(var Item: Record Item; StoreNo: Code[10]): Boolean
    var
        PriceListLineTmp: Record "Price List Line" temporary;
        RetailPriceUtils: Codeunit "LSC Retail Price Utils";
    begin
        RetailPriceUtils.GetItemPriceList(Item."No.", PriceListLineTmp);
        PriceListLineTmp.SetRange("Source Type", PriceListLineTmp."Source Type"::"Customer Price Group");
        IF PriceListLineTmp.FindSet() then begin
            repeat
                if PriceValidInStore(PriceListLineTmp, StoreNo) then
                    exit(true);
            until PriceListLineTmp.Next() = 0;
        end else
            exit(true);

        exit(false);
    end;

    [Obsolete('Removed in favor of new Price Calculation API', '20.5')]
#pragma warning disable AL0432
    procedure PriceValidInStore(var SalesPrice: Record "Sales Price"; StoreNo: Code[10]): Boolean
#pragma warning restore AL0432
    var
        PriceGroup: Record "Customer Price Group";
    begin
        if PriceGroup.Get(SalesPrice."Sales Code") then
            exit(PriceGroupValidInStore2(PriceGroup.Code, StoreNo));
        exit(false);
    end;

    procedure PriceValidInStore(var PriceListLine: Record "Price List Line"; StoreNo: Code[10]): Boolean
    var
        PriceGroup: Record "Customer Price Group";
    begin
        if PriceGroup.Get(PriceListLine."Source No.") then
            exit(PriceGroupValidInStore2(PriceGroup.Code, StoreNo));
        exit(false);
    end;

    procedure PriceGroupValidInStore(PriceGroup: Record "Customer Price Group"; StoreNo: Code[10]): Boolean
    var
        DistLocMembList: Record "LSC Distribution Group Member";
        StoreGroup: Record "LSC Store Group";
    begin
        if (PriceGroup.Code = '') and not PriceGroup.Get then
            exit(true)
        else begin
            if PriceGroup."LSC Store Group" <> '' then begin
                if StoreGroup.Get(PriceGroup."LSC Store Group") then begin
                    exit(DistLocMembList.Get(StoreGroup."Distribution Group Code", StoreGroup."Distribution Subgroup Code", StoreNo));
                end;
            end;
        end;
    end;

    procedure PriceGroupValidInStore2(PriceGroupCode: Code[10]; StoreNo: Code[10]): Boolean
    var
        LocationPriceGroup: Record "LSC Store Price Group";
    begin
        if (PriceGroupCode = '') then
            exit(true)
        else
            exit(LocationPriceGroup.Get(StoreNo, PriceGroupCode));
    end;

    procedure ZeroPad(var Str: Text[50]; Length: Integer)
    var
        TmpStr: Text[50];
        Len: Integer;
    begin
        Len := StrLen(Str);
        TmpStr := '';
        TmpStr := PadStr(TmpStr, Length - Len, '0');
        Str := TmpStr + Str;
    end;

    procedure STDDateToString(DateVal: Date): Text[8]
    var
        Ds: Text[2];
        Ms: Text[2];
        Ys: Text[4];
    begin
        if DateVal = 0D then
            exit('');

        Ds := Format(Date2DMY(DateVal, 1));
        Ms := Format(Date2DMY(DateVal, 2));
        Ys := Format(Date2DMY(DateVal, 3));
        ZeroPad(Ds, 2);
        ZeroPad(Ms, 2);
        ZeroPad(Ys, 4);
        exit(Ds + Ms + Ys);
    end;

    procedure STDStringToDate(Str: Text[8]): Date
    var
        D: Integer;
        M: Integer;
        Y: Integer;
    begin
        if not Evaluate(D, CopyStr(Str, 1, 2)) then
            exit(0D);
        if not Evaluate(M, CopyStr(Str, 3, 2)) then
            exit(0D);
        if not Evaluate(Y, CopyStr(Str, 5, 4)) then
            exit(0D);
        exit(DMY2Date(D, M, Y));
    end;

    procedure STDTimeToString(TimeVal: Time): Text[30]
    var
        H: Text[2];
        M: Text[2];
        S: Text[2];
        T: Text[3];
    begin
        if TimeVal = 0T then
            exit('');

        H := Format(TimeVal, 0, '<Hours24>');
        M := Format(TimeVal, 0, '<Minutes>');
        S := Format(TimeVal, 0, '<Seconds>');
        T := Format(TimeVal, 0, '<Thousands>');
        ZeroPad(H, 2);
        ZeroPad(M, 2);
        ZeroPad(S, 2);
        ZeroPad(T, 3);
        exit(H + M + S + T);
    end;

    procedure STDStringToTime(Str: Text[9]): Time
    var
        TimeVal: Time;
    begin
        if Evaluate(TimeVal, Str) then
            exit(TimeVal);
        exit(0T);
    end;

    procedure ConvertFieldType(SystemType: Integer): Integer
    begin
        //ConvertFieldType
        //01    1,      2,      3,            4,   5,   6,   7,   8,      9,    10,  11,
        //,Option,Boolean,Integer,Short Integer,Text,Code,Date,Time,Decimal,Binary,Blob,
        //         12,         13,      14         15       16   17
        //DateFormula,TableFilter,DateTime,BigInteger,Duration,GUID

        case SystemType of
            35583:
                exit(1);    // Option
            34047:
                exit(2);    // Boolean
            34559:
                exit(3);    // Integer
                            // Short Integer does not exist in Navision anymore
            11519:
                exit(5);    // Text
            35071:
                exit(6);    // Code
            11775:
                exit(7);    // Date
            11776:
                exit(8);    // Time
            12799:
                exit(9);    // Decimal

            33791:
                exit(10);   // Binary

            33793:
                exit(11);   // BLOB
            11797:
                exit(12);   // DateFormula
            4912:
                exit(13);   // TableFilter

            37375:
                exit(14);
            36095:
                exit(15);
            36863:
                exit(16);
            37119:
                exit(17);
            31488:
                exit(5);    //Unicode Text
            31489:
                exit(6);    //Unicode Code
            4988:
                exit(10);   //Binary
            26207:
                exit(19);   //Media - GUID
            26208:
                exit(19);   //MediaSet - GUID
        end;
        exit(SystemType);
    end;

    procedure GetTableName(TableNo: Integer; LocDesign: Code[10]): Text[250]
    var
        AllObj: Record AllObj;
        LocTable: Record "LSC Location Table";
    begin
        if LocDesign = '' then begin
            if AllObj.Get(AllObj."Object Type"::Table, TableNo) then
                exit(AllObj."Object Name");
        end else begin
            if LocTable.Get(LocDesign, TableNo) then
                exit(LocTable."Table Name");
        end;
        exit('');
    end;

    procedure GetFieldName(TableNo: Integer; FieldNo: Integer; LocDesign: Code[10]): Text[50]
    var
        Fld: Record "Field";
        LocField: Record "LSC Location Field";
    begin
        if LocDesign = '' then begin
            if Fld.Get(TableNo, FieldNo) then
                exit(Fld.FieldName);
        end else begin
            if LocField.Get(LocDesign, TableNo, FieldNo) then
                exit(LocField."Field Name");
        end;
        exit('');
    end;

    procedure LookupTableNo(CurrTableNo: Integer; LocDesign: Code[10]): Integer
    var
        AllObjTable: Record AllObj;
        LocTable: Record "LSC Location Table";
    begin
        if LocDesign = '' then begin
            AllObjTable.Reset;
            if not AllObjTable.Get(AllObjTable."Object Type"::Table, CurrTableNo) then
                CurrTableNo := 0;
            AllObjTable.SetRange("Object Type", AllObjTable."Object Type"::Table);
            if Page.RunModal(Page::"LSC Table Object List", AllObjTable) = Action::LookupOK then
                exit(AllObjTable."Object ID");
        end else begin
            LocTable.Reset;
            if not LocTable.Get(LocDesign, CurrTableNo) then
                CurrTableNo := 0;
            LocTable.SetRange("Exchange Location", LocDesign);
            if Page.RunModal(Page::"LSC Location Tables", LocTable) = Action::LookupOK then
                exit(LocTable."Table No.");
        end;
        exit(CurrTableNo);
    end;

    procedure LookupFieldNo(TableNo: Integer; LocDesign: Code[10]): Integer
    var
        Flds: Record "Field";
        LocFields: Record "LSC Location Field";
    begin
        if LocDesign = '' then begin
            Flds.SetRange(TableNo, TableNo);
            if Page.RunModal(Page::"LSC Table Fields", Flds) = Action::LookupOK then
                exit(Flds."No.");
        end else begin
            LocFields.SetRange("Exchange Location", LocDesign);
            LocFields.SetRange(LocFields."Table No.", TableNo);
            if Page.RunModal(Page::"LSC Location Fields", LocFields) = Action::LookupOK then
                exit(LocFields."Field No.");
        end;
    end;

    procedure GetFieldType(TableNo: Integer; FieldNo: Integer; LocDesign: Code[10]): Integer
    var
        Flds: Record "Field";
        LocFields: Record "LSC Location Field";
    begin
        if LocDesign = '' then begin
            if Flds.Get(TableNo, FieldNo) then
                exit(ConvertFieldType(Flds.Type));
        end else begin
            if LocFields.Get(LocDesign, TableNo, FieldNo) then
                exit(LocFields."Field Type");
        end;
        exit(0);
    end;

    procedure FieldTypeToSQL(SystemType: Integer): Integer
    begin
        //FieldTypeToSQL
        //      1,      2,      3,            4,   5,   6,   7,   8,      9,    10,  11,
        //,Option,Boolean,Integer,Short Integer,Text,Code,Date,Time,Decimal,Binary,Blob,
        //         12,         13,      14         15       16   17               19
        //DateFormula,TableFilter,DateTime,BigInteger,Duration,GUID,MediaSet + Media

        case SystemType of
            // Local Types
            1:
                exit(8);     // Option          as Integer
            2:
                exit(2);     // Boolean
            3:
                exit(8);     // Integer
                             // Short Integer does not exist in Navision anymore
            5:
                exit(16);    // Text
            6:
                exit(16);    // Code            as Text
            7:
                exit(5);     // Date
            8:
                exit(12);    // Time
            9:
                exit(6);     // Decimal
            11:
                exit(1);     // Blob
            10:
                exit(4);     // Binary

            12:
                exit(4);     // DateFormula     as Binary   (as Text 12 : EXIT(12);)

            13:
                exit(16);    // TableFilter     as Text
            14:
                exit(17);    // DateTime
            15:
                exit(18);    // BigInteger
            16:
                exit(18);    // Duration        as BigInteger
            17:
                exit(19);     // GUID            as Binary
            19:
                exit(19);     // MediaSet and Media as Binary

            // System Types
            35583:
                exit(8);    // Option        as Integer
            34047:
                exit(2);    // Boolean
            34559:
                exit(8);    // Integer
            11519:
                exit(16);   // Text
            35071:
                exit(16);   // Code          as Text
            11775:
                exit(5);    // Date
            11776:
                exit(12);   // Time
            12799:
                exit(6);    // Decimal
            33793:
                exit(1);    // BLOB

            33791:
                exit(4);    // Binary
            11797:
                exit(16);   // DateFormula   as Text
            4912:
                exit(16);   // TableFilter   as Text
            37375:
                exit(17);   // DateTime
            36095:
                exit(18);   // BigInteger
            36863:
                exit(18);   // Duration      as BigInteger
            37119:
                exit(19);    // GUID          as Binary
            31488:
                exit(16);   // Unicode Code  as Text
            31489:
                exit(16);   // Unicode Text
            4899:
                exit(4);     //Binary
        end;
        exit(SystemType);
    end;

    procedure FilterTypeToOperator(FilterType: Integer): Integer
    begin
        //FieldTypeToOperator
        // Const,Filter,From-Location,To-Location,<,>,[..],min,max

        case FilterType of
            0:
                exit(1);    // const     -> =
            1:
                exit(10);   // filter    -> *
            2:
                exit(1);    // from loc. -> =
            3:
                exit(1);    // to loc.   -> =
            4:
                exit(0);    // less than -> <
            5:
                exit(2);    // greater   -> >
            6:
                exit(3);    // range     -> %
            7:
                exit(4);    // min       -> {
            8:
                exit(5);    // max       -> }
            9:
                exit(3);    // D-Range   -> %
        end;

        exit(1);
    end;

    procedure Str2Hex(InStr: Text[30]) Res: Text[60]
    var
        C1: Char;
        C2: Char;
        I: Integer;
        A: Integer;
        B: Integer;
    begin
        for I := 1 to 30 do
            if I <= StrLen(InStr) then begin
                A := InStr[I] mod 16 + 48;
                B := InStr[I] div 16 + 48;
                if A > 57 then
                    A := A + 7;
                if B > 57 then
                    B := B + 7;
                C1 := B;
                C2 := A;
                Res := Res + Format(C1) + Format(C2);
            end;
    end;

    procedure CreateTimeStamp(DateVal: Date; TimeVal: Time): Integer
    var
        result1: Integer;
        result2: Integer;
    begin
        result1 := (DateVal - 19700101D) * 86400;
        result2 := Round((TimeVal - 010000T) / 1000, 1) + 3600;
        exit(result1 + result2);
    end;

    procedure STDDateTimeToString(DateTimeVal: DateTime): Text[30]
    begin
        exit(STDDateToString(DT2Date(DateTimeVal)) + ':' +
             STDTimeToString(DT2Time(DateTimeVal)));
    end;

    procedure STDStringToDateTime(DateStr: Text[30]): DateTime
    var
        ResDate: Date;
        ResTime: Time;
        Pos: Integer;
    begin
        Pos := StrPos(DateStr, ':');
        if (Pos = 0) then
            exit(0DT);

        ResDate := STDStringToDate(CopyStr(DateStr, 1, Pos - 1));
        ResTime := STDStringToTime(CopyStr(DateStr, Pos + 1));
        exit(CreateDateTime(ResDate, ResTime));
    end;

    procedure STDBigIntToString(BigIntVal: BigInteger): Text[30]
    var
        ResultStr: Text[30];
    begin
        ResultStr := Format(BigIntVal);
        ResultStr := DelChr(ResultStr, '=', '.');
        ResultStr := DelChr(ResultStr, '=', ',');
        exit(ResultStr);
    end;

    procedure STDStringToBigInt(BigIntStr: Text[30]): BigInteger
    var
        BigIntVal: BigInteger;
    begin
        if BigIntStr = '' then
            exit(0);

        Evaluate(BigIntVal, BigIntStr);
        exit(BigIntVal);
    end;

    procedure SplitCode(var TxtPart: Text[250]; var IntPart: BigInteger; CodeValue: Text[250])
    var
        IntPartStr: Text[250];
        i: Integer;
        Done: Boolean;
    begin
        i := StrLen(CodeValue);
        Done := false;

        while (i > 0) and (not Done) do begin
            if (48 <= CodeValue[i]) and (CodeValue[i] <= 57) then
                IntPartStr := StrSubstNo('%1%2', CodeValue[i], IntPartStr)
            else begin
                TxtPart := CopyStr(CodeValue, 1, i);
                Done := true;
            end;
            i := i - 1;
        end;

        if not Evaluate(IntPart, IntPartStr) then
            IntPart := 0;
    end;

    procedure ReturnQtySoldNotPosted(ItemNo: Code[20]; StoreFilter: Code[250]; LocationFilter: Text[250]; VariantFilter: Code[250]; DateFilter: Text[250]) QtySoldNotPosted: Decimal
    var
        TransSalesEntry: Record "LSC Trans. Sales Entry";
        TransSalesEntryStatus: Record "LSC Trans. Sales Entry Status";
        QuantitySold: Decimal;
        QuantityPosted: Decimal;
        IsHandled: Boolean;
    begin
        OnBeforeReturnQtySoldNotPosted(ItemNo, StoreFilter, LocationFilter, VariantFilter, DateFilter, QtySoldNotPosted, IsHandled);
        if IsHandled then
            exit;
        TransSalesEntry.Reset;
        TransSalesEntry.SetCurrentKey("Item No.", "Variant Code", Date);
        TransSalesEntry.SetRange("Item No.", ItemNo);
        if VariantFilter <> '' then
            TransSalesEntry.SetFilter("Variant Code", VariantFilter);
        if StoreFilter <> '' then
            TransSalesEntry.SetFilter("Store No.", StoreFilter);
        if DateFilter <> '' then
            TransSalesEntry.SetFilter(Date, DateFilter);
        TransSalesEntry.CalcSums(Quantity);
        QuantitySold := -TransSalesEntry.Quantity;

        TransSalesEntryStatus.Reset;
        TransSalesEntryStatus.SetCurrentKey("Item No.", "Variant Code", Status, "Store No.", Date);
        TransSalesEntryStatus.SetRange("Item No.", ItemNo);
        if VariantFilter <> '' then
            TransSalesEntryStatus.SetFilter("Variant Code", VariantFilter);
        if DateFilter <> '' then
            TransSalesEntryStatus.SetFilter(Date, DateFilter);
        TransSalesEntryStatus.SetRange(Status, TransSalesEntryStatus.Status::"Items Posted",
          TransSalesEntryStatus.Status::Posted);
        if StoreFilter <> '' then
            TransSalesEntryStatus.SetFilter("Store No.", StoreFilter);
        TransSalesEntryStatus.CalcSums(Quantity);

        QuantityPosted := -TransSalesEntryStatus.Quantity;
        QtySoldNotPosted := QuantitySold - QuantityPosted;

        QtySoldNotPosted := QtySoldNotPosted - ReturnQtyAdjustSoldNotPosted(ItemNo, LocationFilter, VariantFilter, DateFilter);

        QtySoldNotPosted := QtySoldNotPosted + ReturnQtySoldNotPostedBOMComp(ItemNo, StoreFilter, LocationFilter, VariantFilter, DateFilter);

        OnAfterQtySoldNotPostedCalculate(ItemNo, StoreFilter, LocationFilter, VariantFilter, DateFilter, QtySoldNotPosted);
    end;

    procedure QtySoldNotPostedDrillDown(ItemNo: Code[20]; StoreFilter: Code[250]; VariantFilter: Code[250]; DateFilter: Text[250])
    var
        TransSalesEntry: Record "LSC Trans. Sales Entry";
        TransSalesEntryStatus: Record "LSC Trans. Sales Entry Status";
        QtyRemaining: Decimal;
        QtySold: Decimal;
    begin
        TransSalesEntry.Reset;
        TransSalesEntry.SetCurrentKey("Item No.", "Variant Code", Date);
        TransSalesEntry.SetRange("Item No.", ItemNo);
        if VariantFilter <> '' then
            TransSalesEntry.SetFilter("Variant Code", VariantFilter);
        if StoreFilter <> '' then
            TransSalesEntry.SetFilter("Store No.", StoreFilter);
        if DateFilter <> '' then
            TransSalesEntry.SetFilter(Date, DateFilter);

        TransSalesEntry.CalcSums(Quantity);
        QtySold := -TransSalesEntry.Quantity;

        QtyRemaining := QtySold;
        if TransSalesEntry.FindLast() then
            repeat
                if TransSalesEntryStatus.Get(TransSalesEntry."Store No.",
                  TransSalesEntry."POS Terminal No.",
                  TransSalesEntry."Transaction No.",
                  TransSalesEntry."Line No.") then begin
                    if TransSalesEntryStatus.Status = TransSalesEntryStatus.Status::" " then begin
                        QtyRemaining := QtyRemaining + TransSalesEntry.Quantity;
                        TransSalesEntry.Mark := true;
                    end;
                end
                else begin
                    QtyRemaining := QtyRemaining + TransSalesEntry.Quantity;
                    TransSalesEntry.Mark := true;
                end;
            until (TransSalesEntry.Next(-1) = 0) or (QtyRemaining <= 0);
        TransSalesEntry.MarkedOnly(true);
        Page.Run(0, TransSalesEntry);
    end;

    procedure QtySoldNotPostedDrillDown2(ItemNo: Code[20]; StoreFilter: Code[250]; LocationFilter: Text[250]; VariantFilter: Code[250]; DateFilter: Text[250])
    var
        TransSalesEntry: Record "LSC Trans. Sales Entry";
        TransSalesEntryStatus: Record "LSC Trans. Sales Entry Status";
        TransSalesEntryTemp: Record "LSC Trans. Sales Entry" temporary;
        TransCount: Integer;
        TransCountPosted: Integer;
        TransCountNotPosted: Integer;
    begin
        TransSalesEntry.Reset;
        TransSalesEntry.SetCurrentKey("Item No.", "Variant Code", Date);
        TransSalesEntry.SetRange("Item No.", ItemNo);
        if VariantFilter <> '' then
            TransSalesEntry.SetFilter("Variant Code", VariantFilter);
        if StoreFilter <> '' then
            TransSalesEntry.SetFilter("Store No.", StoreFilter);
        if DateFilter <> '' then
            TransSalesEntry.SetFilter(Date, DateFilter);
        TransCount := TransSalesEntry.Count;

        TransSalesEntryStatus.Reset;
        TransSalesEntryStatus.SetCurrentKey("Item No.", "Variant Code", Status, "Store No.", Date);
        TransSalesEntryStatus.SetRange("Item No.", ItemNo);
        if VariantFilter <> '' then
            TransSalesEntryStatus.SetFilter("Variant Code", VariantFilter);
        if DateFilter <> '' then
            TransSalesEntryStatus.SetFilter(Date, DateFilter);
        TransSalesEntryStatus.SetRange(Status, TransSalesEntryStatus.Status::"Items Posted",
          TransSalesEntryStatus.Status::Posted);
        if StoreFilter <> '' then
            TransSalesEntryStatus.SetFilter("Store No.", StoreFilter);
        TransCountPosted := TransSalesEntryStatus.Count;

        TransCountNotPosted := TransCount - TransCountPosted;

        TransCount := 0;
        TransSalesEntry.Ascending(false);
        if TransSalesEntry.FindSet() then
            repeat
                if TransSalesEntryStatus.Get(TransSalesEntry."Store No.", TransSalesEntry."POS Terminal No.",
                  TransSalesEntry."Transaction No.", TransSalesEntry."Line No.")
                then begin
                    if TransSalesEntryStatus.Status = TransSalesEntryStatus.Status::" " then begin
                        TransCount := TransCount + 1;
                        TransSalesEntryTemp.Init;
                        TransSalesEntryTemp := TransSalesEntry;
                        TransSalesEntryTemp.Insert;
                    end;
                end else begin
                    TransCount := TransCount + 1;
                    TransSalesEntryTemp.Init;
                    TransSalesEntryTemp := TransSalesEntry;
                    TransSalesEntryTemp.Insert;
                end;
            until (TransSalesEntry.Next() = 0) or (TransCount >= TransCountNotPosted);

        QtyAjustSoldNotPostedDrillDown2(ItemNo, LocationFilter, VariantFilter, DateFilter, TransSalesEntryTemp);

        Page.Run(0, TransSalesEntryTemp);
    end;

    procedure ReturnCOReservedQty(ItemNo: Code[20]; StoreFilter: Code[250]; LocationFilter: Text[250]; VariantFilter: Code[250]; DateFilter: Text[250]) COReservedQty: Decimal
    var
        COReservations: Record "LSC CO Reservation Entry";
    begin
        COReservations.SetCurrentKey("Item No.", "Variant Code", "Store No.", "Location Code");
        COReservations.SetRange("Item No.", ItemNo);
        if VariantFilter <> '' then
            COReservations.SetFilter("Variant Code", VariantFilter);
        if StoreFilter <> '' then
            COReservations.SetFilter("Store No.", StoreFilter);
        if LocationFilter <> '' then
            COReservations.SetFilter("Location Code", LocationFilter);
        if DateFilter <> '' then
            COReservations.SetFilter("Document Date", DateFilter);
        COReservations.CalcSums("Quantity (Base)");
        COReservedQty := COReservations."Quantity (Base)";
    end;

    procedure COReservedQtyDrillDown(ItemNo: Code[20]; StoreFilter: Code[250]; LocationFilter: Text[250]; VariantFilter: Code[250]; DateFilter: Text[250])
    var
        COReservations: Record "LSC CO Reservation Entry";
    begin
        COReservations.SetCurrentKey("Item No.", "Variant Code", "Store No.", "Location Code");
        COReservations.SetRange("Item No.", ItemNo);
        if VariantFilter <> '' then
            COReservations.SetFilter("Variant Code", VariantFilter);
        if StoreFilter <> '' then
            COReservations.SetFilter("Store No.", StoreFilter);
        if LocationFilter <> '' then
            COReservations.SetFilter("Location Code", LocationFilter);
        if DateFilter <> '' then
            COReservations.SetFilter("Document Date", DateFilter);
        Page.Run(0, COReservations);
    end;

    procedure ReturnEmphasize(): Boolean
    var
        RetailUser: Record "LSC Retail User";
    begin
        if RetailUser.Get(UserId) then
            exit(RetailUser."Emphasize Info Values")
        else
            exit(false);
    end;

    procedure getLookupPage(TableNo: Integer): Integer
    var
        LookupPageNo: Integer;
    begin
        LookupPageNo := 0;
        case TableNo of
            18:
                LookupPageNo := Page::"LSC Retail Customer List";
            23:
                LookupPageNo := Page::"LSC Retail Vendor List";
            27:
                LookupPageNo := Page::"LSC Retail Item List";
            7002:
                LookupPageNo := Page::"LSC Retail Price Groups";
            10000704:
                LookupPageNo := Page::"LSC Item Distribution Lookup";
            10000705:
                LookupPageNo := Page::"LSC Retail Product Groups";
        end;

        exit(LookupPageNo);
    end;

    procedure getCardForm(FormNo: Integer): Integer
    var
        LookupFormNo: Integer;
    begin
        LookupFormNo := 0;
        case FormNo of
            18:
                LookupFormNo := Page::"LSC Retail Customer Card";
            23:
                LookupFormNo := Page::"LSC Retail Vendor Card";
            27:
                LookupFormNo := Page::"LSC Retail Item";
        end;
        exit(LookupFormNo);
    end;

    procedure getLSRetailVersion(): Text[50]
    var
        NAVAppInstalledApp: Record "NAV App Installed App";
        Ver: text[50];
        IsHandeld: Boolean;
    begin
        OnBeforeGetLSRetailVersion(Ver, IsHandeld);
        if IsHandeld then
            exit(Ver);

        NAVAppInstalledApp.SetRange(Name, 'LS Central');
        if NAVAppInstalledApp.findfirst then
            exit(
                CopyStr(NAVAppInstalledApp.Name + ' ' +
                    format(NAVAppInstalledApp."Version Major") + '.' +
                    format(NAVAppInstalledApp."Version Minor") + '.' +
                    format(NAVAppInstalledApp."Version Build") + '.' +
                    format(NAVAppInstalledApp."Version Revision"), 1, 50));
    end;

    procedure getLSRetailCopyright(): Text[50]
    var
        NAVAppInstalledApp: Record "NAV App Installed App";
        Publisher: Text[50];
        Year: Integer;
        IsHandeld: Boolean;
    begin
        OnBeforeGetLSRetailCopyright(Publisher, IsHandeld);
        if IsHandeld then
            exit(Publisher);

        NAVAppInstalledApp.SetRange(Name, 'LS Central');
        if NAVAppInstalledApp.findfirst then begin
            year := Date2DMY(today, 3);
            exit(StrSubstNo('© 1998-%1 %2', Year, NAVAppInstalledApp.Publisher)); // Copyright sign Alt+0169
        end;
    end;

    procedure CheckObjectPermission(pFunction: Code[1]; pObjectType: Option Tabledata,"Table",Form,"Report",Dataport,"Codeunit",System,Fieldnumber; pObjectId: Integer): Boolean
    var
        PermissionRec: Record "License Permission";
        lAnswer: Boolean;
    begin
        //Function to test for object permission

        // R - Read
        // I - Insert
        // M - Modify
        // D - Delete
        // E - Execute

        lAnswer := false;
        if PermissionRec.Get(pObjectType, pObjectId) then begin
            case pFunction of
                'R':
                    if PermissionRec."Read Permission" <> 0 then
                        lAnswer := true;
                'I':
                    if PermissionRec."Insert Permission" <> 0 then
                        lAnswer := true;
                'M':
                    if PermissionRec."Modify Permission" <> 0 then
                        lAnswer := true;
                'D':
                    if PermissionRec."Delete Permission" <> 0 then
                        lAnswer := true;
                'E':
                    if PermissionRec."Execute Permission" <> 0 then
                        lAnswer := true;
            end;
        end;
        exit(lAnswer);
    end;

    procedure IsBlockSaleOnPOS("Item No.": Code[20]; VariantDim1Code: Code[15]; VariantCode: Code[10]; StoreNo: Code[10]; LocationCode: Code[10]; ValidDate: Date; var pItemStatusLink: Record "LSC Item Status Link"): Boolean
    var
        Handled: Boolean;
        ReturnValue: Boolean;
    begin
        OnBeforeFindItemStatusLink("Item No.", VariantDim1Code, VariantCode, StoreNo, LocationCode, ValidDate, pItemStatusLink, ReturnValue, Handled);
        if Handled then
            exit(ReturnValue);
        if FindItemStatusLink("Item No.", VariantDim1Code, VariantCode, StoreNo, LocationCode, ValidDate, pItemStatusLink) then
            exit(pItemStatusLink."Block Sale on POS")
        else
            exit(false);
    end;

    procedure IsBlockPurchasing("Item No.": Code[20]; VariantDim1Code: Code[15]; VariantCode: Code[10]; StoreNo: Code[10]; LocationCode: Code[10]; ValidDate: Date; var pItemStatusLink: Record "LSC Item Status Link"): Boolean
    begin
        if FindItemStatusLink("Item No.", VariantDim1Code, VariantCode, StoreNo, LocationCode, ValidDate, pItemStatusLink) then
            exit(pItemStatusLink."Block Purchasing")
        else
            exit(false);
    end;

    procedure IsBlockTransfering("Item No.": Code[20]; VariantDim1Code: Code[15]; VariantCode: Code[10]; StoreNo: Code[10]; LocationCode: Code[10]; ValidDate: Date; var pItemStatusLink: Record "LSC Item Status Link"): Boolean
    begin
        if FindItemStatusLink("Item No.", VariantDim1Code, VariantCode, StoreNo, LocationCode, ValidDate, pItemStatusLink) then
            exit(pItemStatusLink."Block Transferring")
        else
            exit(false);
    end;

    procedure IsBlockManualDiscount("Item No.": Code[20]; VariantDim1Code: Code[15]; VariantCode: Code[10]; StoreNo: Code[10]; LocationCode: Code[10]; ValidDate: Date; var pItemStatusLink: Record "LSC Item Status Link"): Boolean
    begin
        if FindItemStatusLink("Item No.", VariantDim1Code, VariantCode, StoreNo, LocationCode, ValidDate, pItemStatusLink) then
            exit(pItemStatusLink."Block Discount")
        else
            exit(false);
    end;

    procedure IsBlockPromotionDiscount("Item No.": Code[20]; VariantDim1Code: Code[15]; VariantCode: Code[10]; StoreNo: Code[10]; LocationCode: Code[10]; ValidDate: Date; var pItemStatusLink: Record "LSC Item Status Link"): Boolean
    begin
        if FindItemStatusLink("Item No.", VariantDim1Code, VariantCode, StoreNo, LocationCode, ValidDate, pItemStatusLink) then
            exit(pItemStatusLink."Block Promotion Price")
        else
            exit(false);
    end;

    procedure IsBlockOfferDiscount("Item No.": Code[20]; VariantDim1Code: Code[15]; VariantCode: Code[10]; StoreNo: Code[10]; LocationCode: Code[10]; ValidDate: Date; var pItemStatusLink: Record "LSC Item Status Link"): Boolean
    begin
        if FindItemStatusLink("Item No.", VariantDim1Code, VariantCode, StoreNo, LocationCode, ValidDate, pItemStatusLink) then
            exit(pItemStatusLink."Block Periodic Discount")
        else
            exit(false);
    end;

    procedure IsBlockManualPriceChange("Item No.": Code[20]; VariantDim1Code: Code[15]; VariantCode: Code[10]; StoreNo: Code[10]; LocationCode: Code[10]; ValidDate: Date; var pItemStatusLink: Record "LSC Item Status Link"): Boolean
    begin
        if FindItemStatusLink("Item No.", VariantDim1Code, VariantCode, StoreNo, LocationCode, ValidDate, pItemStatusLink) then
            exit(pItemStatusLink."Block Manual Price Change")
        else
            exit(false);
    end;

    procedure IsHospitalityPermitted(): Boolean
    begin
        //Function to test for system permission
        exit(CheckObjectPermission('E', 1, 10001209));
    end;

    procedure IsInStorePermitted(): Boolean
    begin
        //Function to test for system permission
        exit(CheckObjectPermission('E', 5, 10001320));
    end;

    procedure IsOpenToBuyPermitted(): Boolean
    begin
        //Function to test for system permission
        exit(CheckObjectPermission('E', 5, 10012400));
    end;

    procedure IsReplenishmentPermitted(): Boolean
    begin
        //Function to test for system permission
        exit(CheckObjectPermission('E', 1, 10012200));
    end;

    procedure Is3rdPartyPosPermitted(): Boolean
    begin
        //Function to test for system permission
        exit(CheckObjectPermission('E', 1, 10000900));
    end;

    procedure IsFranchisePermitted(): Boolean
    begin
        //Function to test for system permission
        exit(CheckObjectPermission('E', 1, 10014600));
    end;

    procedure IsOfflineCallCenterPermitted(): Boolean
    begin
        //Function to test for system permission
        exit(CheckObjectPermission('E', 1, 10014800));
    end;

    procedure IsWebIntergrationPermitted(): Boolean
    begin
        //Function to test for system permission
        exit(CheckObjectPermission('E', 1, 10012860));
    end;

    procedure IsStockLedgerReportingPermitt(): Boolean
    begin
        //Function to test for system permission
        exit(false);
    end;

    procedure IsRecipePermitted(): Boolean
    begin
        //Function to test for system permission
        exit(CheckObjectPermission('E', 1, 10012100));
    end;

    procedure IsStaffMgmtPermitted(): Boolean
    begin
        //Function to test for system permission
        exit(CheckObjectPermission('E', 1, 10015000));
    end;

    procedure FieldValueIsValid(pTableNo: Integer; pFieldNo: Integer; pValue: Code[20]): Boolean
    var
        lField: Record "Field";
        BigInteger: BigInteger;
        IsValid: Boolean;
    begin
        IsValid := true;
        if lField.RecordLevelLocking then begin
            lField.Get(pTableNo, pFieldNo);
            if lField.SQLDataType > 0 then
                if (StrLen(pValue) > 19) and (DelChr(pValue, '=', '0123456789') = '') then
                    IsValid := false
                else
                    if Evaluate(BigInteger, pValue) then
                        if BigInteger > 2147483647 then
                            IsValid := false;
        end;
        exit(IsValid);
    end;

    procedure GetLocationFilter(StoreNo: Code[10]): Text[1000]
    var
        Store: Record "LSC Store";
        RestLocLink: Record "LSC Restaurant Location Link";
        FilterStr: Text[250];
        FilterOk: Boolean;
    begin
        if (StoreNo <> '') and IsHospitalityPermitted then begin
            if Store.Get(StoreNo) then begin
                Clear(FilterStr);
                FilterOk := false;
                RestLocLink.Reset;
                RestLocLink.SetRange("Restaurant No.", StoreNo);
                if RestLocLink.FindSet() then begin
                    FilterStr := Store."Location Code";
                    repeat
                        if (RestLocLink."Location Code" <> '') and (RestLocLink."Location Code" <> Store."Location Code") then begin
                            FilterStr := FilterStr + '|' + RestLocLink."Location Code";
                            FilterOk := true;
                        end;
                    until RestLocLink.Next = 0;
                end;

                if FilterOk then
                    exit(FilterStr);
            end;
        end;

        exit('');
    end;

    procedure SwithToDemoMode(pTurnOn: Boolean)
    var
        lRetailSetup: Record "LSC Retail Setup";
    begin
        lRetailSetup.Get;
        lRetailSetup."System In DEMO MODE" := pTurnOn;
        lRetailSetup.Modify;
        if pTurnOn then
            WorkDate := 20070815D //NORMALDATE(GLEntry."Posting Date");
        else
            WorkDate := Today;
    end;

    procedure DemoModeDateProcess()
    var
        lRetailSetup: Record "LSC Retail Setup";
        lRetailSetupOld: Record "LSC Retail Setup";
    begin

        lRetailSetup.Get;
        lRetailSetupOld := lRetailSetup;

        if lRetailSetup."System In DEMO MODE" then begin
            Page.RunModal(Page::"LSC Demo Mode Card");
            if lRetailSetup."System In DEMO MODE" <>
              lRetailSetupOld."System In DEMO MODE" then
                lRetailSetup.Modify;
            Commit;
            lRetailSetup.Get;
        end;

        if lRetailSetup."System In DEMO MODE" then
            WorkDate := 20070815D
        else
            WorkDate := Today;
    end;

    procedure STARTTimerToRetailSystemLog(var pRetailSystemLog: Record "LSC Retail System Log")
    var
        lRetailSetup: Record "LSC Retail Setup";
    begin
        lRetailSetup.Get;
        pRetailSystemLog."Dist. Location" := lRetailSetup."Distribution Location";
        pRetailSystemLog."Event Date Time" := CurrentDateTime;

        pRetailSystemLog."Start Time" := Time;
        pRetailSystemLog.Insert(true);
    end;

    procedure STOPTimerToRetailSystemLog(var pRetailSystemLog: Record "LSC Retail System Log")
    var
        lRetailSystemLog: Record "LSC Retail System Log";
        lSecs: Integer;
        lMins: Integer;
        lHrs: Integer;
    begin
        lRetailSystemLog.Get(pRetailSystemLog."Dist. Location", pRetailSystemLog."Event Date Time", pRetailSystemLog."Line No.");

        lRetailSystemLog."Event End Date Time" := CurrentDateTime;
        lRetailSystemLog."End Time" := Time;

        lSecs := Round((lRetailSystemLog."End Time" - lRetailSystemLog."Start Time") / 1000, 1);
        if lSecs < 0 then
            lSecs := lSecs + 3600 * 24;

        lRetailSystemLog."Event Duration (sec)" := lSecs;

        lHrs := Round(lSecs / 3600, 1, '<');
        lSecs := lSecs - (lHrs * 3600);
        lMins := Round(lSecs / 60, 1, '<');
        lSecs := lSecs - (lMins * 60);
        lRetailSystemLog."Event Duration (text)" := Format(lHrs) + ':' + Format(lMins) + ':' + Format(lSecs);
        lRetailSystemLog.Modify(true);
    end;

    procedure ConvertFieldTypeText(SystemType: Text[30]): Integer
    begin
        //ConvertFieldTypeText

        case UpperCase(SystemType) of
            'OPTION':
                exit(1);    // Option
            'BOOLEAN':
                exit(2);    // Boolean
            'INTEGER':
                exit(3);    // Integer
                            // Short Integer does not exist in Navision anymore
            'TEXT':
                exit(5);    // Text
            'CODE':
                exit(6);    // Code
            'DATE':
                exit(7);    // Date
            'TIME':
                exit(8);    // Time
            'DECIMAL':
                exit(9);    // Decimal
            'BINARY':
                exit(10);   // Binary
            'BLOB':
                exit(11);   // BLOB
            'DATEFORMULA':
                exit(12);   // DateFormula
            'TABLEFILTER':
                exit(13);   // TableFilter
            'DATETIME':
                exit(14);   // DateTime
            'BIGINTEGER':
                exit(15);   // BigInteger
            'DURATION':
                exit(16);   // Duration
            'GUID':
                exit(17);   // GUID
            'MEDIA':
                exit(17);   // Media (GUID)
            'MEDIASET':
                exit(17);   // MediaSet (GUID)
        end;
        exit(0);
    end;

    procedure ReplicateUsingRegEntry()
    var
        ReplReg: Record "LSC Repl. Register Entry";
        SchedulerSetup: Record "LSC Scheduler Setup";
        IctMgt: Codeunit "LSC Retail ICT Processes";
        GLRegNo: Integer;
        ItemRegNo: Integer;
        ICTNo: Integer;
        InStoreNo: Integer;
    begin
        if not SchedulerSetup.Get then
            exit;

        if not SchedulerSetup."Replicate using Register Entry" then
            exit;

        GLRegNo := GetLastGLRegNo();
        ItemRegNo := GetLastItemRegNo();
        ICTNo := IctMgt.GetLastReplCounter();

        if (GLRegNo <= 0) and (ItemRegNo <= 0) and (ICTNo <= 0) and (InStoreNo <= 0) then
            exit;

        if (GLRegNo > 0) then begin
            if ReplReg.Get(Database::"G/L Register") then begin
                if (GLRegNo > ReplReg."Reg. No.") then begin
                    ReplReg."Reg. No." := GLRegNo;
                    ReplReg.Modify;
                end;
            end
            else begin
                ReplReg."Table No." := Database::"G/L Register";
                ReplReg."Reg. No." := GLRegNo;
                ReplReg.Insert;
            end;
        end;

        if (ItemRegNo > 0) then begin
            if ReplReg.Get(Database::"Item Register") then begin
                if (ItemRegNo > ReplReg."Reg. No.") then begin
                    ReplReg."Reg. No." := ItemRegNo;
                    ReplReg.Modify;
                end;
            end
            else begin
                ReplReg."Table No." := Database::"Item Register";
                ReplReg."Reg. No." := ItemRegNo;
                ReplReg.Insert;
            end;
        end;

        if (ICTNo > 0) then begin
            if ReplReg.Get(Database::"LSC Retail ICT Header") then begin
                if (ICTNo > ReplReg."Reg. No.") then begin
                    ReplReg."Reg. No." := ICTNo;
                    ReplReg.Modify;
                end;
            end
            else begin
                ReplReg."Table No." := Database::"LSC Retail ICT Header";
                ReplReg."Reg. No." := ICTNo;
                ReplReg.Insert;
            end;
        end;
    end;

    procedure GetLastGLRegNo(): Integer
    var
        GLReg: Record "G/L Register";
    begin
        GLReg.Reset;
        GLReg.LockTable;
        if not GLReg.FindLast then
            Clear(GLReg);
        exit(GLReg."No.");
    end;

    procedure GetLastItemRegNo(): Integer
    var
        ItemReg: Record "Item Register";
    begin
        ItemReg.Reset;
        ItemReg.LockTable;
        if not ItemReg.FindLast then
            Clear(ItemReg);
        exit(ItemReg."No.");
    end;

    procedure GetLastReplCounter(): Integer
    var
        xICTHeader: Record "LSC Retail ICT Header";
    begin
        xICTHeader.Reset;
        xICTHeader.LockTable;
        xICTHeader.SetCurrentKey(xICTHeader."Replication Counter");
        if not xICTHeader.FindLast then
            Clear(xICTHeader);
        exit(xICTHeader."Replication Counter");
    end;

    procedure InitReplUsingRegEntry()
    var
        ReplReg: Record "LSC Repl. Register Entry";
    begin
        if not ReplReg.Get(Database::"G/L Register") then begin
            Clear(ReplReg);
            ReplReg."Table No." := Database::"G/L Register";
            ReplReg.Insert;
        end;

        if not ReplReg.Get(Database::"Item Register") then begin
            Clear(ReplReg);
            ReplReg."Table No." := Database::"Item Register";
            ReplReg.Insert;
        end;

        if not ReplReg.Get(Database::"LSC Retail ICT Header") then begin
            Clear(ReplReg);
            ReplReg."Table No." := Database::"LSC Retail ICT Header";
            ReplReg.Insert;
        end;

        if not ReplReg.Get(Database::"LSC InStore Header") then begin
            Clear(ReplReg);
            ReplReg."Table No." := Database::"LSC InStore Header";
            ReplReg.Insert;
        end;
    end;

    procedure GetSeparateChar(): Text[1]
    var
        SchedulerSetup: Record "LSC Scheduler Setup";
        SeparateChr: Text[1];
        SeparateChrChar: Char;
    begin
        if not SchedulerSetup.Get then
            Clear(SchedulerSetup);
        SeparateChr := SchedulerSetup."Loc. Group Filter Delimiter";
        if SeparateChr = '' then begin
            SeparateChrChar := 177;
            SeparateChr := Format(SeparateChrChar);
        end;

        exit(SeparateChr);
    end;

    procedure GetSeparateValueChar(): Text[1]
    var
        SeparateChr: Text[1];
        SeparateChrChar: Char;
    begin
        SeparateChrChar := 247; //Divided by character '÷';
        SeparateChr := Format(SeparateChrChar);

        exit(SeparateChr);
    end;

    procedure PasteAttributes(var FromLine: Record "LSC POS Menu Line"; var ToLine: Record "LSC POS Menu Line")
    begin
        ToLine."Caption Alignment" := FromLine."Caption Alignment";
        ToLine."Caption Offset" := FromLine."Caption Offset";
        ToLine."Button Facing" := FromLine."Button Facing";
        ToLine."Button Left Margin" := FromLine."Button Left Margin";
        ToLine."Button Right Margin" := FromLine."Button Right Margin";
        ToLine."Button Top Margin" := FromLine."Button Top Margin";
        ToLine."Button Bottom Margin" := FromLine."Button Bottom Margin";
        ToLine."Click Repeat Interval" := FromLine."Click Repeat Interval";
        ToLine."Glyph Text Font" := FromLine."Glyph Text Font";
        ToLine."Glyph Text 2 Font" := FromLine."Glyph Text 2 Font";
        ToLine."Glyph Text 3 Font" := FromLine."Glyph Text 3 Font";
        ToLine."Glyph Text 4 Font" := FromLine."Glyph Text 4 Font";
        ToLine."Glyph Offset" := FromLine."Glyph Offset";
        ToLine."Glyph 2 Offset" := FromLine."Glyph 2 Offset";
        ToLine."Glyph 3 Offset" := FromLine."Glyph 3 Offset";
        ToLine."Glyph 4 Offset" := FromLine."Glyph 4 Offset";
        ToLine.Font := FromLine.Font;
        ToLine.Skin := FromLine.Skin;
    end;

    procedure PasteAttributesToAll(var FromLine: Record "LSC POS Menu Line"; var ToLine: Record "LSC POS Menu Line")
    var
        PosMenuLine: Record "LSC POS Menu Line";
        PosMenu: Record "LSC POS Menu Header";
        i: Integer;
        ButtonCount: Integer;
    begin
        if not PosMenu.Get(ToLine."Profile ID", ToLine."Menu ID") then
            exit;

        ButtonCount := PosMenu.GetNrOfButtons();

        for i := 1 to ButtonCount do begin
            if not PosMenuLine.Get(ToLine."Profile ID", ToLine."Menu ID", i) then begin
                PosMenuLine.Init;
                PosMenuLine."Profile ID" := ToLine."Profile ID";
                PosMenuLine."Menu ID" := ToLine."Menu ID";
                PosMenuLine."Key No." := i;
            end;

            PasteAttributes(FromLine, PosMenuLine);

            if not PosMenuLine.Insert then
                PosMenuLine.Modify;
        end;
    end;

    procedure Paste(var FromLine: Record "LSC POS Menu Line"; var ToLine: Record "LSC POS Menu Line"; LastButton: Integer)
    var
        PosParam: Record "LSC POS Button Parameters";
        PosParam2: Record "LSC POS Button Parameters";
    begin
        ToLine.TransferFields(FromLine, false);

        PosParam.SetRange("POS Menu Profile ID", FromLine."Profile ID");
        PosParam.SetRange("Menu ID", FromLine."Menu ID");
        PosParam.SetRange("Key No.", FromLine."Key No.");
        if PosParam.FindSet() then
            repeat
                PosParam2 := PosParam;
                PosParam2."Key No." := LastButton;
                if PosParam2.Insert(true) then;
            until PosParam.Next() = 0;
    end;

    procedure PasteToAll(var FromLine: Record "LSC POS Menu Line")
    var
        PosMenuLine: Record "LSC POS Menu Line";
        PosMenu: Record "LSC POS Menu Header";
        i: Integer;
        ButtonCount: Integer;
    begin
        if not PosMenu.Get(FromLine."Profile ID", FromLine."Menu ID") then
            exit;

        ButtonCount := PosMenu.GetNrOfButtons();
        for i := 1 to ButtonCount do begin
            if not PosMenuLine.Get(FromLine."Profile ID", FromLine."Menu ID", i) then begin
                PosMenuLine.Init;
                PosMenuLine."Profile ID" := FromLine."Profile ID";
                PosMenuLine."Menu ID" := FromLine."Menu ID";
                PosMenuLine."Key No." := i;
            end;
            Paste(FromLine, PosMenuLine, i);
            if not PosMenuLine.Insert then
                PosMenuLine.Modify;
        end;
    end;

    procedure LookupLocation(StoreNo: Code[10]; LocationCode: Code[10]): Code[10]
    var
        lStoreLocationRec: Record "LSC Store Location";
        lLocationRec: Record Location;
        lFilterNo: Integer;
    begin
        if (StoreNo = '') then begin
            lLocationRec.Reset;
            if Page.RunModal(0, lLocationRec) = Action::LookupOK then
                exit(lLocationRec.Code);
        end else begin
            lStoreLocationRec.Reset;
            lFilterNo := lStoreLocationRec.FilterGroup;
            lStoreLocationRec.FilterGroup(3);
            lStoreLocationRec.SetRange("Store No.", StoreNo);
            lStoreLocationRec.FilterGroup(lFilterNo);
            if Page.RunModal(0, lStoreLocationRec) = Action::LookupOK then
                exit(lStoreLocationRec."Location Code");
        end;
        exit(LocationCode);
    end;

    procedure StoreLocationOk(StoreNo: Code[10]; LocationCode: Code[10])
    var
        lStore: Record "LSC Store";
        IsHandled: Boolean;
        Text018: Label 'Location for store %1 must be entered';
        Text015: Label 'Location ''%1'' not found in store ''%2''';
    begin
        OnBeforeStoreLocationOk(StoreNo, LocationCode, IsHandled);
        if IsHandled then
            exit;

        if (StoreNo <> '') and (LocationCode = '') then
            Error(Text018, StoreNo);

        if StoreNo <> '' then begin
            lStore.FindStore(LocationCode, lStore);
            if StoreNo <> lStore."No." then begin
                Error(Text015, LocationCode, StoreNo);
            end;
        end;
    end;

    procedure LocationToStore(pLocationCode: Code[10]): Code[10]
    var
        lStoreLocation: Record "LSC Store Location";
        lStore: Record "LSC Store";
    begin
        lStoreLocation.SetCurrentKey("Location Code");
        lStoreLocation.SetRange("Location Code", pLocationCode);
        if lStoreLocation.FindFirst then
            exit(lStoreLocation."Store No.");
        lStore.SetCurrentKey("Location Code");
        lStore.SetRange(lStore."Location Code", pLocationCode);
        if lStore.FindFirst then
            exit(lStore."No.");
        exit('');
    end;

    procedure GetTableKeys(TableNo: Integer) CurrKeyIndex: Integer
    var
        TempTable: Record "LSC Temp Key Lookup" temporary;
        frmTempTable: Page "LSC Temp Key Lookup List";
        MyRecRef: RecordRef;
        MyFieldRef: FieldRef;
        MyKeyRef: KeyRef;
        DummyKeyString: Text[250];
        i: Integer;
        j: Integer;
        Text017: Label '%1 for %2.';
    begin
        CurrKeyIndex := 0;
        MyRecRef.Open(TableNo, false);

        for i := 1 to MyRecRef.KeyCount do begin
            DummyKeyString := '';
            MyKeyRef := MyRecRef.KeyIndex(i);
            if MyKeyRef.Active then begin
                for j := 1 to MyKeyRef.FieldCount do begin
                    MyFieldRef := MyKeyRef.FieldIndex(j);
                    if StrLen(DummyKeyString) <= 250 then
                        DummyKeyString := DummyKeyString + MyFieldRef.Caption + ',';
                end;
            end;

            if MyKeyRef.Active then
                if DummyKeyString <> '' then
                    if CopyStr(DummyKeyString, StrLen(DummyKeyString)) = ',' then
                        DummyKeyString := CopyStr(DummyKeyString, 1, (StrLen(DummyKeyString) - 1));

            if MyKeyRef.Active then begin
                if DummyKeyString <> '' then begin
                    TempTable.Init;
                    TempTable."Primary Key" := StrSubstNo('%1', i);
                    TempTable."Key Index." := i;
                    TempTable."Table No." := TableNo;
                    TempTable."Key Name" := DummyKeyString;
                    TempTable.Insert;
                end;
            end;
        end;

        frmTempTable.SetTempTable(TempTable);
        frmTempTable.Caption(StrSubstNo(Text017, frmTempTable.Caption, MyRecRef.Caption));
        frmTempTable.LookupMode(true);
        if Action::LookupOK = frmTempTable.RunModal then begin
            CurrKeyIndex := frmTempTable.GetCurrKeyIndex;
        end;

        MyRecRef.Close;
    end;

    procedure DefRetailUserStoreLocation(var StoreNo: Code[10]; var LocationCode: Code[10])
    var
        lStore: Record "LSC Store";
        lRetailUser: Record "LSC Retail User";
    begin
        StoreNo := '';
        LocationCode := '';
        if lRetailUser.Get(UserId) then
            if lStore.Get(lRetailUser."Store No.") then begin
                StoreNo := lRetailUser."Store No.";
                if lRetailUser."Location Code" <> '' then
                    LocationCode := lRetailUser."Location Code"
                else
                    LocationCode := lStore."Location Code";
            end;
    end;

    procedure CompareRecords(RecRef: RecordRef; xRecRef: RecordRef): Boolean
    var
        FldRef: FieldRef;
        xFieldRef: FieldRef;
        Flds: Integer;
        xFields: Integer;
        Cnt: Integer;
        i: Integer;
    begin
        Flds := RecRef.FieldCount;
        xFields := xRecRef.FieldCount;

        Cnt := Flds;
        if (Flds > xFields) then
            Cnt := xFields;

        for i := 1 to Cnt do begin
            FldRef := RecRef.FieldIndex(i);
            xFieldRef := xRecRef.FieldIndex(i);

            if (FldRef.Type <> xFieldRef.Type) then
                exit(false);

            if FldRef.Value <> xFieldRef.Value then
                exit(false);
        end;
        exit(true);
    end;

    procedure GetFieldLen(TableNo: Integer; FieldNo: Integer; LocDesign: Code[10]): Integer
    var
        Flds: Record "Field";
        LocFields: Record "LSC Location Field";
    begin
        if LocDesign = '' then begin
            if Flds.Get(TableNo, FieldNo) then
                exit(Flds.Len);
        end else begin
            if LocFields.Get(LocDesign, TableNo, FieldNo) then
                exit(LocFields."Field Length");
        end;
        exit(0);
    end;

    procedure IsBlockSaleInSO("Item No.": Code[20]; VariantDim1Code: Code[15]; VariantCode: Code[10]; StoreNo: Code[10]; LocationCode: Code[10]; ValidDate: Date; var pItemStatusLink: Record "LSC Item Status Link"): Boolean
    begin
        if FindItemStatusLink("Item No.", VariantDim1Code, VariantCode, StoreNo, LocationCode, ValidDate, pItemStatusLink) then
            exit(pItemStatusLink."Block Sale in Sales Order")
        else
            exit(false);
    end;

    procedure IsBlockSalesReturn("Item No.": Code[20]; VariantDim1Code: Code[15]; VariantCode: Code[10]; StoreNo: Code[10]; LocationCode: Code[10]; ValidDate: Date; var pItemStatusLink: Record "LSC Item Status Link"): Boolean
    begin
        if FindItemStatusLink("Item No.", VariantDim1Code, VariantCode, StoreNo, LocationCode, ValidDate, pItemStatusLink) then
            exit(pItemStatusLink."Block Sales Return")
        else
            exit(false);
    end;

    procedure IsBlockNegativeAdjustm("Item No.": Code[20]; VariantDim1Code: Code[15]; VariantCode: Code[10]; StoreNo: Code[10]; LocationCode: Code[10]; ValidDate: Date; var pItemStatusLink: Record "LSC Item Status Link"): Boolean
    begin
        if FindItemStatusLink("Item No.", VariantDim1Code, VariantCode, StoreNo, LocationCode, ValidDate, pItemStatusLink) then
            exit(pItemStatusLink."Block Negative Adjustment")
        else
            exit(false);
    end;

    procedure IsBlockPositiveAdjustm("Item No.": Code[20]; VariantDim1Code: Code[15]; VariantCode: Code[10]; StoreNo: Code[10]; LocationCode: Code[10]; ValidDate: Date; var pItemStatusLink: Record "LSC Item Status Link"): Boolean
    begin
        if FindItemStatusLink("Item No.", VariantDim1Code, VariantCode, StoreNo, LocationCode, ValidDate, pItemStatusLink) then
            exit(pItemStatusLink."Block Positive Adjustment")
        else
            exit(false);
    end;

    procedure IsBlockPurchaseReturn("Item No.": Code[20]; VariantDim1Code: Code[15]; VariantCode: Code[10]; StoreNo: Code[10]; LocationCode: Code[10]; ValidDate: Date; var pItemStatusLink: Record "LSC Item Status Link"): Boolean
    begin
        if FindItemStatusLink("Item No.", VariantDim1Code, VariantCode, StoreNo, LocationCode, ValidDate, pItemStatusLink) then
            exit(pItemStatusLink."Block Purchase Return")
        else
            exit(false);
    end;

    procedure IsBlockFromRecommendation("Item No.": Code[20]; VariantDim1Code: Code[15]; VariantCode: Code[10]; StoreNo: Code[10]; LocationCode: Code[10]; ValidDate: Date; var pItemStatusLink: Record "LSC Item Status Link"): Boolean
    begin
        if FindItemStatusLink("Item No.", VariantDim1Code, VariantCode, StoreNo, LocationCode, ValidDate, pItemStatusLink) then
            exit(pItemStatusLink."Block From Recommendation")
        else
            exit(false);
    end;

    procedure FindItemStatusLink(ItemNo: Code[20]; VariantDim1Code: Code[15]; VariantCode: Code[10]; StoreNo: Code[10]; LocationCode: Code[10]; ValidDate: Date; var pItemStatusLink: Record "LSC Item Status Link"): Boolean
    var
        ItemStatusLink: Record "LSC Item Status Link";
        StoreGroupSetup: Record "LSC Store Group Setup";
        ItemVariantRegistration: Record "LSC Item Variant Registration";
        Store: Record "LSC Store";
        Priority: Integer;
    begin
        //
        //Priority
        //    1) ItemNo,VariantCode,LocationCode
        //    2) ItemNo,VariantCode,StoreGroup
        //    3) ItemNo,VariantCode
        //    4) ItemNo,VariantDim1Code,LocationCode
        //    5) ItemNo,VariantDim1Code,StoreGroup
        //    6) ItemNo,VariantDim1Code
        //    7) ItemNo,LocationCode
        //    8) ItemNo,StoreGroup
        //    9) ItemNo
        //   10) LocationCode
        //   11) StoreGroup
        //   12) VariantDim1Code

        ItemStatusLink.Reset;
        if ItemStatusLink.IsEmpty then begin
            Clear(pItemStatusLink);
            exit(false);
        end;

        if ValidDate = 0D then
            ValidDate := Today;

        if (StoreNo <> '') and (LocationCode = '') then
            if Store.Get(StoreNo) then
                LocationCode := Store."Location Code";

        if (StoreNo = '') and (LocationCode <> '') then begin
            Store.Reset;
            Store.SetCurrentKey("Location Code");
            Store.SetRange("Location Code", LocationCode);
            if Store.FindFirst then
                StoreNo := Store."No.";
        end;

        for Priority := 1 to 12 do begin
            ItemStatusLink.Reset;
            ItemStatusLink.SetFilter("Item No.", '%1', '');
            ItemStatusLink.SetFilter("Variant Code", '%1', '');
            ItemStatusLink.SetFilter("Variant Dimension 1 Code", '%1', '');
            ItemStatusLink.SetFilter("Location Code", '%1', '');
            ItemStatusLink.SetFilter("Store Group Code", '%1', '');
            ItemStatusLink.SetRange("Starting Date", 0D, ValidDate);
            case Priority of
                1:  //ItemNo, VariantCode, LocationCode
                    begin
                        if (ItemNo <> '') and (VariantCode <> '') and (LocationCode <> '') then begin
                            ItemStatusLink.SetRange("Item No.", ItemNo);
                            ItemStatusLink.SetFilter("Variant Code", '%1', VariantCode);
                            ItemStatusLink.SetFilter("Location Code", '%1', LocationCode);
                            if ItemStatusLink.FindLast then begin
                                pItemStatusLink := ItemStatusLink;
                                exit(true);
                            end;
                        end;
                    end;
                2:  //ItemNo, VariantCode, Store Group Code
                    begin
                        if (ItemNo <> '') and (VariantCode <> '') and (StoreNo <> '') then begin
                            ItemStatusLink.SetRange("Item No.", ItemNo);
                            ItemStatusLink.SetFilter("Variant Code", '%1', VariantCode);
                            ItemStatusLink.SetFilter("Location Code", '%1', '');
                            ItemStatusLink.SetFilter("Store Group Code", '<>%1', '');
                            ItemStatusLink.Ascending(false);
                            if ItemStatusLink.FindSet() then
                                repeat
                                    StoreGroupSetup.Reset;
                                    StoreGroupSetup.SetCurrentKey("Store Code", Level);
                                    StoreGroupSetup.SetFilter("Store Code", '%1', StoreNo);
                                    StoreGroupSetup.SetRange("Store Group", ItemStatusLink."Store Group Code");
                                    if StoreGroupSetup.FindLast then begin
                                        pItemStatusLink := ItemStatusLink;
                                        exit(true);
                                    end;
                                until ItemStatusLink.Next() = 0;
                        end;
                    end;
                3:  //ItemNo, VariantCode
                    begin
                        if (ItemNo <> '') and (VariantCode <> '') then begin
                            ItemStatusLink.SetRange("Item No.", ItemNo);
                            ItemStatusLink.SetFilter("Variant Code", '%1', VariantCode);
                            if ItemStatusLink.FindLast then begin
                                pItemStatusLink := ItemStatusLink;
                                exit(true);
                            end;
                        end;
                    end;
                4:  //ItemNo, VariantDim1Code, LocationCode
                    begin
                        if (ItemNo <> '') and (VariantCode <> '') and (LocationCode <> '') then begin
                            ItemStatusLink.SetRange("Item No.", ItemNo);
                            ItemStatusLink.SetFilter("Location Code", '%1', LocationCode);
                            ItemStatusLink.SetFilter("Variant Code", '%1', '');
                            ItemStatusLink.SetFilter("Variant Dimension 1 Code", '<>%1', '');
                            if ItemStatusLink.FindSet then
                                repeat
                                    ItemVariantRegistration.Reset;
                                    ItemVariantRegistration.SetRange("Item No.", ItemNo);
                                    ItemVariantRegistration.SetRange("Variant Dimension 1", ItemStatusLink."Variant Dimension 1 Code");
                                    ItemVariantRegistration.SetRange(Variant, VariantCode);
                                    if ItemVariantRegistration.FindFirst then begin
                                        pItemStatusLink := ItemStatusLink;
                                        exit(true);
                                    end;
                                until ItemStatusLink.Next = 0;
                        end;
                    end;
                5:  //ItemNo, VariantDim1Code, Store Group Code
                    begin
                        if (ItemNo <> '') and (VariantCode <> '') and (StoreNo <> '') then begin
                            ItemStatusLink.SetRange("Item No.", ItemNo);
                            ItemStatusLink.SetFilter("Location Code", '%1', '');
                            ItemStatusLink.SetFilter("Store Group Code", '<>%1', '');
                            ItemStatusLink.SetFilter("Variant Code", '%1', '');
                            ItemStatusLink.SetFilter("Variant Dimension 1 Code", '<>%1', '');
                            ItemStatusLink.Ascending(false);
                            if ItemStatusLink.FindSet() then
                                repeat
                                    ItemVariantRegistration.Reset;
                                    ItemVariantRegistration.SetRange("Item No.", ItemNo);
                                    ItemVariantRegistration.SetRange("Variant Dimension 1", ItemStatusLink."Variant Dimension 1 Code");
                                    ItemVariantRegistration.SetRange(Variant, VariantCode);
                                    if ItemVariantRegistration.FindFirst then begin
                                        StoreGroupSetup.Reset;
                                        StoreGroupSetup.SetCurrentKey("Store Code", Level);
                                        StoreGroupSetup.SetFilter("Store Code", '%1', StoreNo);
                                        StoreGroupSetup.SetRange("Store Group", ItemStatusLink."Store Group Code");
                                        if StoreGroupSetup.FindLast then begin
                                            pItemStatusLink := ItemStatusLink;
                                            exit(true);
                                        end;
                                    end;
                                until ItemStatusLink.Next() = 0;
                        end;
                    end;
                6:  //ItemNo, VariantDim1Code
                    begin
                        if (ItemNo <> '') and (VariantCode <> '') then begin
                            ItemStatusLink.SetRange("Item No.", ItemNo);
                            ItemStatusLink.SetFilter("Variant Code", '%1', '');
                            ItemStatusLink.SetFilter("Variant Dimension 1 Code", '<>%1', '');
                            if ItemStatusLink.FindSet then
                                repeat
                                    ItemVariantRegistration.Reset;
                                    ItemVariantRegistration.SetRange("Item No.", ItemNo);
                                    ItemVariantRegistration.SetRange("Variant Dimension 1", ItemStatusLink."Variant Dimension 1 Code");
                                    ItemVariantRegistration.SetRange(Variant, VariantCode);
                                    if ItemVariantRegistration.FindFirst then begin
                                        pItemStatusLink := ItemStatusLink;
                                        exit(true);
                                    end;
                                until ItemStatusLink.Next = 0;
                        end;
                    end;
                7:  //ItemNo, LocationCode
                    begin
                        if (ItemNo <> '') and (LocationCode <> '') then begin
                            ItemStatusLink.SetRange("Item No.", ItemNo);
                            ItemStatusLink.SetFilter("Variant Code", '%1', '');
                            ItemStatusLink.SetFilter("Variant Dimension 1 Code", '%1', '');
                            ItemStatusLink.SetFilter("Location Code", '%1', LocationCode);
                            ItemStatusLink.SetFilter("Store Group Code", '%1', '');
                            if ItemStatusLink.FindLast then begin
                                pItemStatusLink := ItemStatusLink;
                                exit(true);
                            end;
                        end;
                    end;
                8:  //ItemNo, StoreGroup
                    begin
                        if (ItemNo <> '') and (StoreNo <> '') then begin
                            ItemStatusLink.SetRange("Item No.", ItemNo);
                            ItemStatusLink.SetFilter("Variant Code", '%1', '');
                            ItemStatusLink.SetFilter("Variant Dimension 1 Code", '%1', '');
                            ItemStatusLink.SetFilter("Location Code", '%1', '');
                            ItemStatusLink.SetFilter("Store Group Code", '<>%1', '');
                            ItemStatusLink.Ascending(false);
                            if ItemStatusLink.FindSet() then
                                repeat
                                    StoreGroupSetup.Reset;
                                    StoreGroupSetup.SetCurrentKey("Store Code", Level);
                                    StoreGroupSetup.SetFilter("Store Code", '%1', StoreNo);
                                    StoreGroupSetup.SetRange("Store Group", ItemStatusLink."Store Group Code");
                                    if StoreGroupSetup.FindLast then begin
                                        pItemStatusLink := ItemStatusLink;
                                        exit(true);
                                    end;
                                until ItemStatusLink.Next() = 0;
                        end;
                    end;
                9:  //ItemNo
                    begin
                        if ItemNo <> '' then begin
                            ItemStatusLink.SetRange("Item No.", ItemNo);
                            ItemStatusLink.SetFilter("Variant Code", '%1', '');
                            ItemStatusLink.SetFilter("Variant Dimension 1 Code", '%1', '');
                            ItemStatusLink.SetFilter("Location Code", '%1', '');
                            ItemStatusLink.SetFilter("Store Group Code", '%1', '');
                            if ItemStatusLink.FindLast then begin
                                pItemStatusLink := ItemStatusLink;
                                exit(true);
                            end;
                        end;
                    end;
                10:  //LocationCode
                    begin
                        if LocationCode <> '' then begin
                            ItemStatusLink.SetFilter("Item No.", '%1', '');
                            ItemStatusLink.SetFilter("Variant Code", '%1', '');
                            ItemStatusLink.SetFilter("Variant Dimension 1 Code", '%1', '');
                            ItemStatusLink.SetFilter("Location Code", '%1', LocationCode);
                            ItemStatusLink.SetFilter("Store Group Code", '%1', '');
                            if ItemStatusLink.FindLast then begin
                                pItemStatusLink := ItemStatusLink;
                                exit(true);
                            end;
                        end;
                    end;
                11:  //StoreGroupCode
                    begin
                        if StoreNo <> '' then begin
                            ItemStatusLink.SetFilter("Item No.", '%1', '');
                            ItemStatusLink.SetFilter("Variant Code", '%1', '');
                            ItemStatusLink.SetFilter("Variant Dimension 1 Code", '%1', '');
                            ItemStatusLink.SetFilter("Location Code", '%1', '');
                            ItemStatusLink.SetFilter("Store Group Code", '<>%1', '');
                            ItemStatusLink.Ascending(false);
                            if ItemStatusLink.FindSet() then
                                repeat
                                    StoreGroupSetup.Reset;
                                    StoreGroupSetup.SetCurrentKey("Store Code", Level);
                                    StoreGroupSetup.SetFilter("Store Code", '%1', StoreNo);
                                    StoreGroupSetup.SetRange("Store Group", ItemStatusLink."Store Group Code");
                                    if StoreGroupSetup.FindLast then begin
                                        pItemStatusLink := ItemStatusLink;
                                        exit(true);
                                    end;
                                until ItemStatusLink.Next() = 0;
                        end;
                    end;
                12:  //VariantDim1Code
                    begin
                        if (ItemNo <> '') and (VariantCode <> '') then begin
                            ItemStatusLink.SetFilter("Item No.", '%1', '');
                            ItemStatusLink.SetFilter("Variant Code", '%1', '');
                            ItemStatusLink.SetFilter("Variant Dimension 1 Code", '<>%1', '');
                            ItemStatusLink.SetFilter("Location Code", '%1', '');
                            ItemStatusLink.SetFilter("Store Group Code", '%1', '');
                            ItemStatusLink.Ascending(false);
                            if ItemStatusLink.FindSet() then
                                repeat
                                    ItemVariantRegistration.Reset;
                                    ItemVariantRegistration.SetRange("Item No.", ItemNo);
                                    ItemVariantRegistration.SetRange("Variant Dimension 1", ItemStatusLink."Variant Dimension 1 Code");
                                    ItemVariantRegistration.SetRange(Variant, VariantCode);
                                    if ItemVariantRegistration.FindFirst then begin
                                        pItemStatusLink := ItemStatusLink;
                                        exit(true);
                                    end;
                                until ItemStatusLink.Next() = 0;
                        end;
                    end;
            end;
        end;

        Clear(pItemStatusLink);
        exit(false);
    end;

    procedure EncryptPassword(PasswordIn: Text) PasswordOut: Text
    begin
        PasswordOut := LSExtUtil.Hash(PasswordIn);
        exit(PasswordOut);
    end;

    procedure Hex2Str(HexIn: Text[100]) StringOut: Text[100]
    var
        First: Text[1];
        Second: Text[1];
        Byte: Text[30];
        I: Integer;
        FirstInt: Integer;
        SecondInt: Integer;
    begin
        StringOut := '';
        I := 1;
        repeat
            First := UpperCase(CopyStr(HexIn, I, 1));
            Second := UpperCase(CopyStr(HexIn, I + 1, 1));
            FirstInt := StrPos('0123456789ABCDEF', First) - 1;
            SecondInt := StrPos('0123456789ABCDEF', Second) - 1;
            Byte[1] := (FirstInt * 16) + SecondInt;
            StringOut := StringOut + Byte;
            I := I + 2;
        until I > StrLen(HexIn);
    end;

    procedure IsItemComplex(pItemNo: Code[20]): Boolean
    var
        Item: Record Item;
        TableSpecInfocode: Record "LSC Table Specific Infocode";
        POSActions: Record "LSC POS Actions";
        LinkedItem: Record "LSC Linked Item";
        IsComplex: Boolean;
        IsHandled: Boolean;
    begin
        if not Item.Get(pItemNo) then
            exit(false);

        OnBeforeIsItemComplex(Item, IsComplex, IsHandled);
        if IsHandled then
            exit(IsComplex);

        Item.CalcFields("Assembly BOM");
        OnIsItemComplex(Item, IsComplex);
        if IsComplex then
            exit(true);
        if Item."Assembly BOM" then
            exit(true);
        if Item."Item Tracking Code" <> '' then
            exit(true);
        if Item."LSC Scale Item" then
            exit(true);
        if Item."LSC Keying in Price" > 0 then
            exit(true);
        if Item."LSC Keying in Quantity" > 0 then
            exit(true);
        if Item."LSC BOM Type" > 0 then
            exit(true);

        TableSpecInfocode.Reset;
        TableSpecInfocode.SetRange("Table ID", 27);
        TableSpecInfocode.SetRange(Value, pItemNo);
        if not TableSpecInfocode.IsEmpty then
            exit(true);

        POSActions.Reset;
        POSActions.SetRange("Data Trigger", POSActions."Data Trigger"::Item);
        POSActions.SetRange("Data ID", pItemNo);
        if not POSActions.IsEmpty then
            exit(true);

        LinkedItem.Reset;
        LinkedItem.SetRange("Item No.", pItemNo);
        if not LinkedItem.IsEmpty then
            exit(true);

        exit(false);
    end;

    procedure ConvertDataToDataTime(pDate: Date): DateTime
    var
        NewDateTime: DateTime;
    begin
        NewDateTime := CreateDateTime(pDate, 0T);

        exit(NewDateTime);
    end;

    [Obsolete('Note used, use Language Codeunit instead', '26.0')]
    procedure GetLanguageId(LanguageCode: Text): Integer
    var
        Language: Record Language;
    begin
        Language.SetRange(Code, LanguageCode);
        if Language.FindFirst then begin
            exit(Language."Windows Language ID");
        end;
        exit(GlobalLanguage);
    end;

    [Obsolete('Note used, use Language Codeunit instead', '26.0')]
    procedure GetLanguageCode(LanguageId: Integer): Text
    var
        Language: Record Language;
    begin
        Language.SetRange("Windows Language ID", LanguageId);
        if Language.FindFirst then begin
            exit(Language.Code);
        end;
        exit('');
    end;

    procedure LocationUrlOnStore(StoreNo: Code[10])
    var
        lStoreRec: Record "LSC Store";
        BackOfficeExt: Codeunit "LSC BackOffice Ext.";
        RecRef: RecordRef;
        lUrl: Text[1024];
    begin
        lStoreRec.Reset();
        lStoreRec.SetFilter(lStoreRec."No.", StoreNo);
        lStoreRec.SetFilter("Location Code", '<>%1', '');
        if lStoreRec.FindSet(true) then
            repeat
                lUrl := BackOfficeExt.GetOnlineMapUrl(lStoreRec."No.");
                lStoreRec."Location Url" := lUrl;
                RecRef.GetTable(lStoreRec);
                RecRef.SetTable(lStoreRec);
                lStoreRec.Modify();
            until lStoreRec.Next() = 0;
    end;

    procedure StrToInt(Value: Text; FailValue: Integer): Integer
    var
        IntValue: Integer;
    begin
        if Evaluate(IntValue, Value) then
            exit(IntValue)
        else
            exit(FailValue);
    end;

    procedure ReturnQtySoldNotPostedBOMComp(ItemNo: Code[20]; StoreFilter: Code[250]; LocationFilter: Text[250]; VariantFilter: Code[250]; DateFilter: Text[250]) QtySNP_BOMComp: Decimal
    var
        BOMComponent: Record "BOM Component";
        Item: Record Item;
        ItemUnitofMeasure: Record "Item Unit of Measure";
        ParentItem: Record Item;
        Factor: Decimal;
    begin
        QtySNP_BOMComp := 0;

        if not Item.Get(ItemNo) then
            exit;

        BOMComponent.SetCurrentKey(Type, "No.");
        BOMComponent.SetRange(Type, BOMComponent.Type::Item);
        BOMComponent.SetRange("No.", ItemNo);
        BOMComponent.SetFilter("Quantity per", '<>0');
        if not BOMComponent.FindSet() then
            exit;

        repeat
            if ParentItem.Get(BOMComponent."Parent Item No.") then
                if ParentItem."LSC BOM Method" <> "LSC Replen. BOM Method"::"Explode at Entry" then begin
                    if BOMComponent."Unit of Measure Code" <> Item."Base Unit of Measure" then begin
                        if not (ItemUnitofMeasure.Get(ItemNo, BOMComponent."Unit of Measure Code")) then
                            ItemUnitofMeasure."Qty. per Unit of Measure" := 1;
                        Factor := ItemUnitofMeasure."Qty. per Unit of Measure"
                    end
                    else
                        Factor := 1;
                    Factor := Factor * BOMComponent."Quantity per";
                    QtySNP_BOMComp := QtySNP_BOMComp +
                      Factor * ReturnQtySoldNotPosted(BOMComponent."Parent Item No.", StoreFilter, LocationFilter, VariantFilter, DateFilter);
                end;
        until BOMComponent.Next = 0;
    end;

    procedure RemoveCodeFromFilter(InputFilter: Text; CodeOut: Code[30]): Text
    var
        LastFilter: Text;
        CodePos: Integer;
        CodeLength: Integer;
        InputLength: Integer;
        i: Integer;
    begin
        if (InputFilter = '') or (CodeOut = '') then
            exit(InputFilter);
        if InputFilter = CodeOut then
            exit('');
        CodeLength := StrLen(CodeOut);
        CodePos := StrPos(InputFilter, '|' + CodeOut + '|');

        while CodePos > 0 do begin
            InputFilter := DelStr(InputFilter, CodePos, CodeLength + 1);
            CodePos := StrPos(InputFilter, '|' + CodeOut + '|');
        end;

        if InputFilter = '' then
            exit(InputFilter);

        CodePos := StrPos(InputFilter, CodeOut + '|');
        if CodePos = 1 then  //FIRST
            InputFilter := DelStr(InputFilter, 1, CodeLength + 1);
        if InputFilter = CodeOut then
            exit('');
        if StrPos(InputFilter, '|') = 0 then
            exit(InputFilter);

        InputLength := StrLen(InputFilter);
        LastFilter := CopyStr(InputFilter, InputLength);
        i := 1;
        while CopyStr(LastFilter, 1, 1) <> '|' do begin
            LastFilter := CopyStr(InputFilter, InputLength - i);
            i += 1;
        end;
        if LastFilter = '|' + CodeOut then
            InputFilter := CopyStr(InputFilter, 1, InputLength - StrLen(LastFilter));
        exit(InputFilter);
    end;

    procedure IsCodeInFilter(InputFilter: Text; CodeIn: Text): Boolean
    var
        ReturnValue: boolean;
    begin
        if CheckParameters(InputFilter, CodeIn, ReturnValue) then
            exit(ReturnValue);

        exit(FilterContainsCode(InputFilter, CodeIn));
    end;

    internal procedure CheckParameters(InputFilter: Text; CodeIn: Text; var ReturnValue: boolean): Boolean
    begin
        if InputFilter = CodeIn then begin
            ReturnValue := true;
            exit(true);
        end;
        if InputFilter = '' then begin
            ReturnValue := false;
            exit(true);
        end;

        if CodeIn = '' then begin
            ReturnValue := true;
            exit(true);
        end;
    end;

    internal procedure FilterContainsCode(InputFilter: Text; CodeIn: Text): Boolean
    var
        StringList: List of [Text];
    begin
        StringList := InputFilter.Split('|');

        exit(StringList.Contains(CodeIn));
    end;

    procedure CreateNewTerminal(TerminalNo: Code[10]; TemplateToCopy: Code[10]; StoreId: Code[10]; TerminalDescription: Text) TerminalId: Code[10]
    var
        TermRec: Record "LSC POS Terminal";
    begin
        if not TermRec.Get(TemplateToCopy) then
            exit('');
        TermRec."No." := TerminalNo;
        TermRec."Store No." := StoreId;
        TermRec.Description := TerminalDescription;
        if TermRec.Insert(true) then
            exit(TermRec."No.");
        exit('');
    end;

    procedure ReturnQtyAdjustSoldNotPosted(ItemNo: Code[20]; LocationFilter: Text[250]; VariantFilter: Code[250]; DateFilter: Text[250]) QtyAdjustment: Decimal
    var
        TransInvAdjmtEntry: Record "LSC Trans. Inv. Adjmt. Entry";
        TransInvAdjmtEntrySt: Record "LSC Trans. Inv Adjmt. Entry St";
        QtyAdjust: Decimal;
        QtyAdjustPosted: Decimal;
    begin
        TransInvAdjmtEntry.Reset;
        TransInvAdjmtEntry.SetCurrentKey("Item No.", "Variant Code", "Location Code", Date);
        TransInvAdjmtEntry.SetRange("Item No.", ItemNo);
        if VariantFilter <> '' then
            TransInvAdjmtEntry.SetFilter("Variant Code", VariantFilter);
        if LocationFilter <> '' then
            TransInvAdjmtEntry.SetFilter("Location Code", LocationFilter);
        if DateFilter <> '' then
            TransInvAdjmtEntry.SetFilter(Date, DateFilter);
        TransInvAdjmtEntry.CalcSums(Quantity);
        QtyAdjust := TransInvAdjmtEntry.Quantity;

        TransInvAdjmtEntrySt.Reset;
        TransInvAdjmtEntrySt.SetCurrentKey("Item No.", "Variant Code", Status, "Location Code", Date);
        TransInvAdjmtEntrySt.SetRange("Item No.", ItemNo);
        if VariantFilter <> '' then
            TransInvAdjmtEntrySt.SetFilter("Variant Code", VariantFilter);
        if DateFilter <> '' then
            TransInvAdjmtEntrySt.SetFilter(Date, DateFilter);
        TransInvAdjmtEntrySt.SetRange(Status, TransInvAdjmtEntrySt.Status::"Items Posted",
          TransInvAdjmtEntrySt.Status::Posted);
        if LocationFilter <> '' then
            TransInvAdjmtEntrySt.SetFilter("Location Code", LocationFilter);
        TransInvAdjmtEntrySt.CalcSums(Quantity);
        QtyAdjustPosted := TransInvAdjmtEntrySt.Quantity;

        QtyAdjustment := QtyAdjust - QtyAdjustPosted;
    end;

    internal procedure ReturnSalesHistoryAdjustment(ItemNo: Code[20]; LocationFilter: Text[250]; VariantFilter: Code[250]; DateFilter: Text[250]) QtyAdjusted: Decimal
    var
        SalesHistAdjmtEntry: Record "LSC Replen. Sales Hist. Adj.";
    begin
        QtyAdjusted := 0;
        SalesHistAdjmtEntry.Reset;
        SalesHistAdjmtEntry.SetRange("Item No.", ItemNo);
        if VariantFilter <> '' then
            SalesHistAdjmtEntry.SetFilter("Variant Code", VariantFilter);
        if LocationFilter <> '' then
            SalesHistAdjmtEntry.SetFilter("Location Code", LocationFilter);
        if DateFilter <> '' then
            SalesHistAdjmtEntry.SetFilter(Date, DateFilter);
        SalesHistAdjmtEntry.SetLoadFields("Adjusted Qty");
        if SalesHistAdjmtEntry.FindSet() then begin
            repeat
                QtyAdjusted := QtyAdjusted + SalesHistAdjmtEntry."Adjusted Qty";
            until SalesHistAdjmtEntry.Next() = 0;
        end;
    end;

    procedure QtyAjustSoldNotPostedDrillDown2(ItemNo: Code[20]; LocationFilter: Text[250]; VariantFilter: Code[250]; DateFilter: Text[250]; var TransSalesEntryTemp: Record "LSC Trans. Sales Entry" temporary)
    var
        TransInvAdjmtEntry: Record "LSC Trans. Inv. Adjmt. Entry";
        TransInvAdjmtEntrySt: Record "LSC Trans. Inv Adjmt. Entry St";
        TransSalesEntry: Record "LSC Trans. Sales Entry";
        TransCount: Integer;
        TransCountPosted: Integer;
        TransCountNotPosted: Integer;
    begin
        TransInvAdjmtEntry.Reset;
        TransInvAdjmtEntry.SetCurrentKey("Item No.", "Variant Code", "Location Code", Date);
        TransInvAdjmtEntry.SetRange("Item No.", ItemNo);
        if VariantFilter <> '' then
            TransInvAdjmtEntry.SetFilter("Variant Code", VariantFilter);
        if LocationFilter <> '' then
            TransInvAdjmtEntry.SetFilter("Location Code", LocationFilter);
        if DateFilter <> '' then
            TransInvAdjmtEntry.SetFilter(Date, DateFilter);
        TransCount := TransInvAdjmtEntry.Count;

        TransInvAdjmtEntrySt.Reset;
        TransInvAdjmtEntrySt.SetCurrentKey("Item No.", "Variant Code", Status, "Location Code", Date);
        TransInvAdjmtEntrySt.SetRange("Item No.", ItemNo);
        if VariantFilter <> '' then
            TransInvAdjmtEntrySt.SetFilter("Variant Code", VariantFilter);
        if DateFilter <> '' then
            TransInvAdjmtEntrySt.SetFilter(Date, DateFilter);
        TransInvAdjmtEntrySt.SetRange(Status, TransInvAdjmtEntrySt.Status::"Items Posted",
          TransInvAdjmtEntrySt.Status::Posted);
        if LocationFilter <> '' then
            TransInvAdjmtEntrySt.SetFilter("Location Code", LocationFilter);
        TransCountPosted := TransInvAdjmtEntrySt.Count;

        TransCountNotPosted := TransCount - TransCountPosted;

        TransCount := 0;
        TransInvAdjmtEntry.Ascending(false);
        if TransInvAdjmtEntry.FindSet() then
            repeat
                if TransSalesEntry.Get(TransInvAdjmtEntry."Store No.", TransInvAdjmtEntry."POS Terminal No.",
                  TransInvAdjmtEntry."Transaction No.", TransInvAdjmtEntry."Line No.")
                then begin
                    if TransInvAdjmtEntrySt.Get(TransInvAdjmtEntry."Store No.", TransInvAdjmtEntry."POS Terminal No.",
                      TransInvAdjmtEntry."Transaction No.", TransInvAdjmtEntry."Line No.", TransInvAdjmtEntry."Location Code")
                    then begin
                        if TransInvAdjmtEntrySt.Status = TransInvAdjmtEntrySt.Status::" " then begin
                            TransCount := TransCount + 1;
                            TransSalesEntryTemp.Init;
                            TransSalesEntryTemp := TransSalesEntry;
                            if TransSalesEntryTemp.Insert then;
                        end;
                    end else begin
                        TransCount := TransCount + 1;
                        TransSalesEntryTemp.Init;
                        TransSalesEntryTemp := TransSalesEntry;
                        if TransSalesEntryTemp.Insert then;
                    end;
                end;
            until (TransInvAdjmtEntry.Next() = 0) or (TransCount >= TransCountNotPosted);
    end;

    procedure CreateStoreLocationFilter(var StoreFilter_p: Code[250]; var LocationFilter_p: Code[250])
    var
        Stores: Record "LSC Store";
        Location: Record Location;
    begin
        if StoreFilter_p = '' then begin
            if LocationFilter_p <> '' then begin
                Location.SetFilter(Code, LocationFilter_p);
                if Location.FindSet then
                    repeat
                        if Stores.FindStore(Location.Code, Stores) then
                            if StoreFilter_p = '' then
                                StoreFilter_p := Stores."No."
                            else
                                StoreFilter_p := StoreFilter_p + '|' + Stores."No.";
                    until Location.Next = 0;
                if StoreFilter_p = '' then
                    StoreFilter_p := LocationFilter_p;
            end;
        end else begin
            LocationFilter_p := '';
            Stores.SetFilter("No.", StoreFilter_p);
            if Stores.FindSet then
                repeat
                    if LocationFilter_p = '' then
                        LocationFilter_p := Stores."Location Code"
                    else
                        LocationFilter_p := LocationFilter_p + '|' + Stores."Location Code";
                until Stores.Next = 0
            else
                LocationFilter_p := StoreFilter_p;
        end;
    end;

    procedure GetCrLf(): Text[2]
    var
        CrLf: Text[2];
        Ch: Char;
    begin
        Ch := 13;
        CrLf := Format(Ch);
        Ch := 10;
        CrLf := CrLf + Format(Ch);
        exit(CrLf);
    end;

    procedure Token(var TokenText: Text; Seperator: Text) Token: Text
    var
        Pos: Integer;
    begin
        Pos := StrPos(TokenText, Seperator);
        if Pos > 0 then begin
            Token := CopyStr(TokenText, 1, Pos - 1);
            if Pos + 1 <= StrLen(TokenText) then
                TokenText := CopyStr(TokenText, Pos + 1)
            else
                TokenText := '';
        end else begin
            Token := TokenText;
            TokenText := '';
        end;
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeGetLSRetailVersion(var Version: text[50]; var IsHandled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeGetLSRetailCopyright(var Publisher: text[50]; var IsHandled: Boolean)
    begin
    end;

    procedure UseSalesTax(pStoreNo: Code[20]): Boolean
    var
        Store: Record "LSC Store";
        TaxSetup: Record "VAT Posting Setup";
        SalesTaxActive: Boolean;
        VatActive: Boolean;
        AmbiguousSetup: Boolean;
        lText001: Label 'Ambiguous Tax/VAT setup for store %1';
    begin
        if not Store.Get(pStoreNo) then
            Clear(Store);

        SalesTaxActive := false;
        VatActive := false;
        TaxSetup.Reset;
        TaxSetup.SetRange("VAT Bus. Posting Group", Store."Store VAT Bus. Post. Gr.");
        if TaxSetup.FindSet then
            repeat
                if TaxSetup."VAT Calculation Type" = TaxSetup."VAT Calculation Type"::"Sales Tax" then
                    SalesTaxActive := true
                else
                    VatActive := true;
            until TaxSetup.Next = 0;

        AmbiguousSetup := SalesTaxActive = VatActive;
        if AmbiguousSetup then
            Error(lText001, pStoreNo);

        if SalesTaxActive then
            exit(true)
        else
            exit(false);
    end;

    // AddRetailUser - Args: <UserId>;<Store>;<Location>;<Terminal>
    procedure AddRetailUser(Args: Text)
    var
        RetailUser: Record "LSC Retail User";
        Separators: List of [Text];
        TxtList: List of [Text];
    begin
        Separators.Add(';');
        TxtList := Args.Split(Separators);

        RetailUser.Init();
        RetailUser.ID := ValidateUser(TxtList.Get(1));
        RetailUser."Store No." := DelChr(TxtList.Get(2), '<>', ' ');
        RetailUser."Location Code" := DelChr(TxtList.Get(3), '<>', ' ');
        RetailUser."POS Terminal" := DelChr(TxtList.Get(4), '<>', ' ');
        RetailUser."POS Super User" := true;
        if RetailUser.Modify() then;
        if RetailUser.Insert() then;
    end;

    // AddActivityUser - Args: <UserId>;<Location>;<LocationFilter>;<DefaultMatrixView>
    procedure AddActivityUser(Args: Text)
    var
        LSActivityUser: Record "LSC Activity User";
        Separators: List of [Text];
        TxtList: List of [Text];
    begin
        Separators.Add(';');
        TxtList := Args.Split(Separators);
        LSActivityUser.Init();
        LSActivityUser.User := ValidateUser(TxtList.Get(1));
        LSActivityUser."Default Location" := DelChr(TxtList.Get(2), '<>', ' '); //'MADRID';
        LSActivityUser."Location Filter" := DelChr(TxtList.Get(3), '<>', ' ');
        LSActivityUser."Default Matrix View" := DelChr(TxtList.Get(4), '<>', ' ');
        if LSActivityUser.Modify() then;
        if LSActivityUser.Insert() then;
    end;

    // AddStaffManagementUser - Args: <UserId>;<WorkLocation>
    procedure AddStaffManagementUser(Args: Text)
    var
        StaffMgtUser: Record "LSC STAFF Users";
        Separators: List of [Text];
        TxtList: List of [Text];
    begin
        Separators.Add(';');
        TxtList := Args.Split(Separators);
        StaffMgtUser.Init();
        StaffMgtUser.User := ValidateUser(TxtList.Get(1));
        StaffMgtUser."Work Location" := DelChr(TxtList.Get(2), '<>', ' ');
        if StaffMgtUser.Modify() then;
        if StaffMgtUser.Insert() then;
    end;

    local procedure ValidateUser(UserIdIn: Code[50]): Code[50]
    var
        UserRec: Record "User";
        user: Code[50];
        UserNotExist: Label 'User does not exist: %1';
    begin
        user := DelChr(UserIdIn, '<>', ' '); //trim
        UserRec.SetRange("User Name", user);
        if UserRec.IsEmpty() then
            Error(UserNotExist, UserIdIn);

        exit(user);
    end;

    internal procedure CheckFuelItem(Item: Record Item): Boolean
    var
        FuelItem: Boolean;
    begin
        OnCheckFuelItem(Item, FuelItem);
        exit(FuelItem);
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeFindItemStatusLink("Item No.": Code[20]; VariantDim1Code: Code[15]; VariantCode: Code[10]; StoreNo: Code[10]; LocationCode: Code[10]; ValidDate: Date; var pItemStatusLink: Record "LSC Item Status Link"; Var ReturnValue: Boolean; Var Handled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeStoreLocationOk(var StoreNo: Code[10]; var LocationCode: Code[10]; var IsHandled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeReturnQtySoldNotPosted(ItemNo: Code[20]; StoreFilter: Code[250]; LocationFilter: Text[250]; VariantFilter: Code[250]; DateFilter: Text[250]; var QtySoldNotPosted: Decimal; var IsHandled: boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnIsItemComplex(Item: Record Item; var IsComplex: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnCheckFuelItem(Item: Record Item; var FuelItem: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeIsItemComplex(Item: Record Item; var IsComplex: Boolean; var IsHandled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    internal procedure OnBeforeValidateMemberAccountNo(var Rec: Record "LSC Member Account"; var ValidateConfig: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    internal procedure OnAfterQtySoldNotPostedCalculate(ItemNo: Code[20]; StoreFilter: Code[250]; LocationFilter: Text[250]; VariantFilter: Code[250]; DateFilter: Text[250]; var QtySoldNotPosted: Decimal);
    begin
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Config. Package Management", OnBeforeApplyPackageRecords, '', false, false)]
    local procedure OnBeforeApplyPackageRecords()
    var
        SessionKeyValues: Codeunit "LSC Session Key Values";
        ConfigPackKey: Label 'CONFIG_PACKAGE', Locked = true;
        ConfigPackValue: Label 'True', Locked = true;
    begin
        SessionKeyValues.SetValue(ConfigPackKey, ConfigPackValue);
    end;

    [EventSubscriber(ObjectType::Codeunit, Codeunit::"Config. Package Management", OnAfterApplyPackageRecords, '', false, false)]
    local procedure OnAfterApplyPackageRecords()
    var
        SessionKeyValues: Codeunit "LSC Session Key Values";
        ConfigPackKey: Label 'CONFIG_PACKAGE', Locked = true;
    begin
        SessionKeyValues.DeleteValue(ConfigPackKey);
    end;
}