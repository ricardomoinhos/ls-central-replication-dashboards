codeunit 99008909 "LSC POS Trans. Server Utility"
{
    trigger OnRun()
    begin
        UpdateLookupTableQuery('', '', '', '');
    end;

    var
        PosFuncProfile: Record "LSC POS Func. Profile";
        POSTerminal_g: Record "LSC POS Terminal";
        Store_g: Record "LSC Store";
        TransactionHeaderTemp_g: Record "LSC Transaction Header" temporary;
        BOUtil: Codeunit "LSC BO Utils";
        BufferUtility: Codeunit "LSC Buffer Utility";
        DCUTIL: Codeunit "LSC Data Dir. POS Client Util";
        Globals: Codeunit "LSC POS Session";
        ItemTrack: Codeunit "LSC Retail Item Tracking";
        POSFunc: Codeunit "LSC POS Functions";
        PosCtrl: Codeunit "LSC POS Control Interface";
        WebServicesClient: Codeunit "LSC Web Services Client";
        TSAction_g: Option ,Update,Delete;
        TSErrorFlag: Boolean;
        TSUnsentTransactionsFlag: Boolean;
        InUse: Boolean;
        WorkTableUpdateTemp_g: Boolean;
        Text001: Label 'Request %1 is only available as web request';
        _SendingTxt1: Label 'Sending';
        SendTransactionTxt: Label 'Send Transaction';

    procedure Initialize(): Boolean
    begin
        if PosFuncProfile."Profile ID" = '' then begin
            Store_g.Get(Globals.StoreNo);
            PosFuncProfile.Get(Globals.FunctionalityProfileID);
            POSTerminal_g.Get(Globals.TerminalNo);
        end;

        InUse := TSInUse(PosFuncProfile);

        exit(InUse);
    end;

    local procedure WebOrDDSendTransaction(POSFunctionalityProfile: Record "LSC POS Func. Profile"; VoidTrans: boolean): Boolean
    begin
        exit(POSFunctionalityProfile."TS Send Transactions" or (POSFunctionalityProfile."DD Void Transactions" and VoidTrans) or (POSFunctionalityProfile."DD Send Transaction" and not VoidTrans));
    end;

    procedure SendTransaction(var Trans: Record "LSC Transaction Header"; VoidTrans: Boolean): Boolean
    var
        TransactionHeaderTemp, TransactionHeaderTemp2 : Record "LSC Transaction Header" temporary;
        SendTransactionHeaderUtils: Codeunit LSCSendTransactionHeaderUtils;
        PosTransDataPushUtility: Codeunit "LSC POS Trans. Data Push Util";
        tmpError: Text;
        MsgTxt: Text[30];
        ErrorText: Text;
        ResponseCode: Code[30];
        SenderDistLoc: Code[10];
        ReceiverDistLoc: Code[10];
        VoidPostedTransactionTxt: Label 'Void Posted Transaction';
    begin
        if not Initialize then
            exit(false);

        if not WebOrDDSendTransaction(PosFuncProfile, VoidTrans) then
            exit(false);

        OnBeforePOSTransServerUtilSendTransaction(PosFuncProfile);

        if PosFuncProfile."TS Send Transactions" then begin
            TransactionHeaderTemp.Init;
            TransactionHeaderTemp := Trans;
            TransactionHeaderTemp.Insert;
            SendTransactionHeaderUtils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
            SendTransactionHeaderUtils.SendRequest(ResponseCode, ErrorText, PosFuncProfile.TransUpdateReplCounter, TransactionHeaderTemp);
            if ErrorText <> '' then
                exit(false);
            exit(true);
        end;

        //Data Director Mode
        MsgTxt := '';
        if VoidTrans and PosFuncProfile."DD Void Transactions" then begin
            SenderDistLoc := PosFuncProfile."Void Trans. Sender DD";
            ReceiverDistLoc := PosFuncProfile."Void Trans. Receiver DD";
            MsgTxt := VoidPostedTransactionTxt;
        end else begin
            SenderDistLoc := PosFuncProfile."Trans. Sender DD";
            ReceiverDistLoc := PosFuncProfile."Trans. Receiver DD";
            MsgTxt := SendTransactionTxt;
        end;

        OnBeforeInitializeDDClient(Trans, MsgTxt);

        DCUTIL.Initialize(PosFuncProfile."Profile ID");
        if not (DCUTIL.StartUpdateRequest(SenderDistLoc, false, MsgTxt)) then
            exit(false);

        DCUTIL.AddReceiver(ReceiverDistLoc);

        TransactionHeaderTemp2 := Trans;
        TransactionHeaderTemp2.Insert;

        IF not PosTransDataPushUtility.SendTransaction(TransactionHeaderTemp2, DCUTIL, ErrorText) then begin
            Globals.SetValue("LSC POS Tag"::"TS_ERROR", ErrorText);
            exit(false);
        end;

        OnAfterPOSTransServerUtilSendTransaction(PosFuncProfile);

        exit(DCUTIL.SendAndDisconnect(tmpError, false));
    end;

    local procedure SendWholeTmpTransaction(): Boolean
    var
        Trans: Record "LSC Transaction Header";
        TransactionHeaderTemp: Record "LSC Transaction Header" temporary;
        SendTransactionUtilsV2: Codeunit LSCSendTransactionUtilsV2;
        WebReplClientHandler: Codeunit "LSC Web Replic. Client Handler";
        PosTransDataPushUtility: Codeunit "LSC POS Trans. Data Push Util";
        ClientSessionUtility: Codeunit "LSC Client Session Utility";
        ErrorText: Text;
        tmpError: Text;
        SenderDistLoc: Code[10];
        ResponseCode: Code[30];
        IsHandled: Boolean;
        RetVal: Boolean;
        _PreparingTxt1: Label 'Preparing';
        MsgTxt: Text[30];
    begin
        if not Initialize then
            exit(false);

        IF TransactionHeaderTemp_g.IsEmpty THEN
            exit(true);

        OnBeforeSendWholeTmpTransaction(TransactionHeaderTemp_g, DCUTIL, IsHandled, RetVal);
        if IsHandled then
            exit(RetVal);

        if not WebOrDDSendTransaction(PosFuncProfile, false) then
            exit(false);

        if PosFuncProfile."TS Send Transactions" then begin
            IF PosFuncProfile."Use Web Replication" and PosFuncProfile."Use Background Session" then
                WebReplClientHandler.SetPosFunctionalityProfile(PosFuncProfile."Profile ID")
            else
                SendTransactionUtilsV2.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
            if GuiAllowed then
                PosCtrl.ScreenDisplay(_SendingTxt1 + ' ' + Trans.TableCaption);
            if TransactionHeaderTemp_g.FindSet then
                repeat
                    Trans.Get(TransactionHeaderTemp_g."Store No.", TransactionHeaderTemp_g."POS Terminal No.", TransactionHeaderTemp_g."Transaction No.");
                    if Trans."Entry Status" = Trans."Entry Status"::Training then
                        if TrainingTransHasEntries(Trans) then begin
                            ClientSessionUtility.SetSkipUpdatingReplicationCounters();
                            Trans.Delete(true);
                            ClientSessionUtility.ClearSkipUpdatingReplicationCounters();
                            Trans.Insert(true);
                        end;
                    TransactionHeaderTemp.Reset();
                    TransactionHeaderTemp.DeleteAll();
                    TransactionHeaderTemp.Init;
                    TransactionHeaderTemp := Trans;
                    TransactionHeaderTemp.Insert;
                    IF PosFuncProfile."Use Web Replication" and PosFuncProfile."Use Background Session" then
                        WebReplClientHandler.SendTransaction(ResponseCode, ErrorText, TransactionHeaderTemp."Refund Receipt No." = '', PosFuncProfile.TransUpdateReplCounter, TransactionHeaderTemp)
                    else
                        SendTransactionUtilsV2.SendRequest(ResponseCode, ErrorText, TransactionHeaderTemp."Refund Receipt No." = '', PosFuncProfile.TransUpdateReplCounter, TransactionHeaderTemp);
                    if ErrorText <> '' then begin
                        UpdateTSWTErrorMessage(Database::"LSC Transaction Header", Format(TransactionHeaderTemp."Transaction No."), '', TransactionHeaderTemp."Store No.",
                          TransactionHeaderTemp."POS Terminal No.", TransactionHeaderTemp."Transaction No.", ErrorText);
                        exit(false);
                    end;
                until TransactionHeaderTemp_g.Next = 0;
            exit(true);
        end;

        //Data Director Mode
        SenderDistLoc := PosFuncProfile."Trans. Sender DD";
        if SenderDistLoc = '' then
            exit(false);
        if PosFuncProfile."Trans. Receiver DD" = '' then
            exit(false);

        MsgTxt := SendTransactionTxt;
        OnBeforeInitializeDDClientSendWholeTrans(TransactionHeaderTemp_g, MsgTxt);

        DCUTIL.Initialize(PosFuncProfile."Profile ID");
        if not (DCUTIL.StartUpdateRequest(SenderDistLoc, false, MsgTxt)) then
            exit(false);

        DCUTIL.AddReceiver(PosFuncProfile."Trans. Receiver DD");

        if GuiAllowed then
            PosCtrl.ScreenDisplay(_PreparingTxt1 + ' ' + Trans.TableCaption);

        IF not PosTransDataPushUtility.SendTransaction(TransactionHeaderTemp_g, DCUTIL, ErrorText) then begin
            Globals.SetValue("LSC POS Tag"::"TS_ERROR", ErrorText);
            exit(false);
        end;

        OnAfterSendWholeTmpTransaction(TransactionHeaderTemp_g, DCUTIL);

        if GuiAllowed then
            PosCtrl.ScreenDisplay(_SendingTxt1 + ' ' + Trans.TableCaption);

        exit(DCUTIL.SendAndDisconnect(tmpError, false));
    end;

    procedure SendAtEndOfTransaction(Trans: Record "LSC Transaction Header")
    var
        DataEntry: Record "LSC POS Data Entry";
        InfoEntry: Record "LSC Trans. Infocode Entry";
        InfoCode: Record "LSC Infocode";
        RefTrans: Record "LSC Transaction Header";
        VoucherEntries: Record "LSC Voucher Entries";
        CustomerOrderSession: Codeunit "LSC Customer Order Session";
        IsHandled: Boolean;
        OriginalRefundTransactionNo: Integer;
    begin
        if Trans."Member Card No." <> '' then
            CreateTSRetryEntry(Database::"LSC Member Process Order Entry", Trans."Receipt No.", '0', '', TSAction_g::Update, 0, false,
              Trans."Store No.", Trans."POS Terminal No.", Trans."Transaction No.", '');

        if CustomerOrderSession.GetCustomerOrderIDWhenCollected(Trans."Customer Order ID") then
            CreateTSRetryEntry(Database::"LSC Customer Order Header", Trans."Receipt No.", '0', Trans."Customer Order ID", TSAction_g::Update, 0, false, Trans."Store No.", Trans."POS Terminal No.", Trans."Transaction No.", '');

        OnBeforeSendAtEndOfTransaction(Trans, IsHandled);
        if IsHandled then
            exit;

        if not Initialize then
            exit;

        if PosFuncProfile."TS Send Transactions" or PosFuncProfile."DD Send Transaction" then
            CreateTSRetryEntry(Database::"LSC Transaction Header", Format(Trans."Transaction No."), '', PosFuncProfile."Trans. Receiver DD",
                           TSAction_g::Update, 0, true,
                           Trans."Store No.", Trans."POS Terminal No.", Trans."Transaction No.", '');

        if PosFuncProfile."TS Data Entries" or PosFuncProfile."DD Data Entry" then begin
            InfoEntry.SetRange("Store No.", Trans."Store No.");
            InfoEntry.SetRange("POS Terminal No.", Trans."POS Terminal No.");
            InfoEntry.SetRange("Transaction No.", Trans."Transaction No.");
            InfoEntry.SetFilter(Infocode, '<>%1', 'TEXT');
            if InfoEntry.FindSet then
                repeat
                    DataEntry.Reset();
                    InfoCode.Get(InfoEntry.Infocode);
                    OnBeforeApplyFiltersOnDataEntrySendAtEndOfTransaction(InfoCode, DataEntry, IsHandled);
                    if not IsHandled then
                        DataEntry.SetRange("Entry Type", InfoCode."Data Entry Type");
                    if (InfoCode.Type = InfoCode.Type::"Create Data Entry") then begin
                        DataEntry.SetRange("Created by Receipt No.", Trans."Receipt No.");
                        DataEntry.SetRange("Created in Store No.", Trans."Store No.");
                        DataEntry.SetRange("Created by Line No.", InfoEntry."Line No.");
                        if DataEntry.FindFirst() then
                            CreateTSRetryEntry(Database::"LSC POS Data Entry", BOUtil.CombineTableKey(2, DataEntry."Entry Type", DataEntry."Entry Code", '', '', ''), '', '',
                                TSAction_g::Update, 0, false, Trans."Store No.", Trans."POS Terminal No.", 0, '');
                    end else
                        if (InfoCode.Type = InfoCode.Type::"Apply To Entry") then begin
                            DataEntry.SetRange("Applied by Receipt No.", Trans."Receipt No.");
                            DataEntry.SetRange("Applied by Line No.", InfoEntry."Line No.");
                            if DataEntry.FindFirst() then
                                CreateTSRetryEntry(Database::"LSC POS Data Entry", BOUtil.CombineTableKey(2, DataEntry."Entry Type", DataEntry."Entry Code", '', '', ''), '', '',
                                    TSAction_g::Update, 0, false, Trans."Store No.", Trans."POS Terminal No.", 0, '');
                        end;
                until InfoEntry.Next = 0;

            VoucherEntries.Reset;
            VoucherEntries.SetCurrentKey("Store No.", "POS Terminal No.", "Transaction No.");
            VoucherEntries.SetRange("Store No.", Trans."Store No.");
            VoucherEntries.SetRange("POS Terminal No.", Trans."POS Terminal No.");
            VoucherEntries.SetRange("Transaction No.", Trans."Transaction No.");
            if VoucherEntries.FindSet then
                repeat
                    CreateTSRetryEntry(Database::"LSC Voucher Entries", BOUtil.IntegerToStr(VoucherEntries."Line No."), '', '', TSAction_g::Update, 0, false,
                      VoucherEntries."Store No.", VoucherEntries."POS Terminal No.", VoucherEntries."Transaction No.", '');
                until VoucherEntries.Next = 0;
        end;

        // If a transaction was refunded, update the refunded one
        if (PosFuncProfile."TS Void Transactions" or PosFuncProfile."DD Void Transactions") and
           (Trans."Retrieved from Receipt No." <> '') then begin
            OriginalRefundTransactionNo := POSFunc.GetOriginalRefundTransactionNo();
            RefTrans.SetCurrentKey("Receipt No.");
            RefTrans.SetRange("Receipt No.", Trans."Retrieved from Receipt No.");
            if OriginalRefundTransactionNo <> 0 then
                RefTrans.SetRange("Transaction No.", OriginalRefundTransactionNo);
            if RefTrans.FindLast then
                CreateTSRetryEntry(Database::"LSC Transaction Header", Format(RefTrans."Transaction No."), '', '', TSAction_g::Update, 0, false,
                    RefTrans."Store No.", RefTrans."POS Terminal No.", RefTrans."Transaction No.", '');
        end;
    end;

    procedure UnsentTransactionsExist(): Boolean
    var
        RetryAction: Record "LSC Trans. Server Work Table";
    begin
        RetryAction.SetRange("Created by Store No.", Globals.StoreNo);
        RetryAction.SetRange("Created by POS Terminal No.", Globals.TerminalNo);
        exit(not RetryAction.IsEmpty);
    end;

    internal procedure SendPOSTrans(POSTransaction: Record "LSC POS Transaction"; DistLoc: Code[10]; WebRequestID: Text[30]): Boolean
    var
        POSTransactionTemp: Record "LSC POS Transaction" temporary;
        SendPosTransBackupUtils: Codeunit LSCSendPosTransBackupUtils;
        SendPosTransSuspUtils: Codeunit LSCSendPosTransSuspUtils;
        ErrorText: Text[1024];
        ResponseCode: Code[30];
        IsHandled: Boolean;
    begin
        if not Initialize then
            exit(false);

        if PosFuncProfile."TS Susp./Retrieve" then begin
            if WebRequestID = 'SendPosTransBackup' then begin
                POSTransactionTemp.Init;
                POSTransactionTemp := POSTransaction;
                POSTransactionTemp.Insert;
                SendPosTransBackupUtils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
                SendPosTransBackupUtils.SendRequest(false, POSTransactionTemp, ResponseCode, ErrorText);
                if ErrorText <> '' then
                    exit(false);
                exit(true);
            end else
                if WebRequestID = 'SendPosTransSusp' then begin
                    POSTransactionTemp.Init;
                    POSTransactionTemp := POSTransaction;
                    POSTransactionTemp.Insert;
                    OnBeforeSendPOSTransSusp(PosFuncProfile."Profile ID", ResponseCode, ErrorText, false, POSTransactionTemp, IsHandled);
                    if not IsHandled then begin
                        SendPosTransSuspUtils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
                        SendPosTransSuspUtils.SendRequest(ResponseCode, ErrorText, false, POSTransactionTemp);
                    end;
                    if ErrorText <> '' then begin
                        CreateTSRetryEntry(Database::"LSC POS Transaction", Format(POSTransaction."Receipt No."), '', DistLoc,
                        TSAction_g::Update, 0, false, POSTransaction."Store No.", POSTransaction."POS Terminal No.", 0, 'SendPosTransSusp');
                        exit(false);
                    end;

                    exit(true);
                end;
        end;
    end;

    internal procedure GetPOSTrans(var PosTrans: Record "LSC POS Transaction"; ReceiptNo: Code[20]; var ErrorCode: Integer): Boolean
    begin
        exit(false); // not supported via DD
    end;

    internal procedure GetPOSTransLines(SlipNumber: Code[20]; var ErrorCode: Integer): Boolean
    begin
        exit(false); // not supported via DD
    end;

    internal procedure DeletePOSTrans(SlipNumber: Code[20])
    var
        DeletePOSTransSuspendUtils: Codeunit LSCDeletePOSTransSuspUtils;
        ErrorText: Text;
        ResponseCode: Code[30];
    begin
        if not Initialize then
            exit;

        DeletePOSTransSuspendUtils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
        DeletePOSTransSuspendUtils.SendRequest(SlipNumber, ResponseCode, ErrorText);
        DeletePOSTransSuspendUtils.SetCommunicationError(ResponseCode, ErrorText);
        if ErrorText <> '' then
            CreateTSRetryEntry(Database::"LSC POS Transaction", SlipNumber, '', '', TSAction_g::Delete, 0, true, Globals.StoreNo, Globals.TerminalNo, 0, 'DeletePOSTransSusp');
    end;

    procedure UpdateDataEntry(var DataEntry: Record "LSC POS Data Entry"; var ErrorText: Text): Boolean
    var
        POSDataEntryTemp: Record "LSC POS Data Entry" temporary;
        SendDataEntryUtils: Codeunit LSCSendDataEntryUtils;
        ResponseCode: Code[30];
        IsHandled: Boolean;
        ReturnValue: Boolean;
    begin
        if not Initialize then
            exit(false);

        OnBeforePosDataEntryInsert(DataEntry, ErrorText, IsHandled, ReturnValue);
        if IsHandled then
            exit(ReturnValue);

        if PosFuncProfile."TS Data Entries" then begin
            if not POSDataEntryTemp.Get(DataEntry."Entry Type", DataEntry."Entry Code") then begin
                POSDataEntryTemp.Init;
                POSDataEntryTemp := DataEntry;
                POSDataEntryTemp.Insert;
            end;
            SendDataEntryUtils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
            SendDataEntryUtils.SendRequest(ResponseCode, ErrorText, false, false, POSDataEntryTemp);
            SendDataEntryUtils.SetCommunicationError(ResponseCode, ErrorText);
            if ErrorText <> '' then begin
                DataEntry.Validate("Replication Counter");
                exit(false);
            end else
                exit(true);
        end;
    end;

    [Obsolete('Use GetDataEntry2 instead', '27.0')]
    procedure GetDataEntry(Type: Code[10]; "Code": Code[20]; var DataEntry: Record "LSC POS Data Entry"; var ErrorText: Text): Boolean
    begin
        GetDataEntry2(Type, "Code", DataEntry, ErrorText);
    end;

    procedure GetDataEntry2(Type: Code[10]; InputCode: Code[20]; var DataEntry: Record "LSC POS Data Entry"; var ErrorText: Text): Boolean
    var
        DataEntry2: Record "LSC POS Data Entry";
        DataEntryTemp: Record "LSC POS Data Entry" temporary;
        GetDataEntryUtils: Codeunit LSCGetDataEntryUtils;
        ResponseCode: Code[30];
        IsHandled: Boolean;
        Ok: Boolean;
    begin
        if not Initialize then
            exit(false);

#pragma warning disable AL0432
        OnBeforeGetDataEntry(Type, InputCode, DataEntry, ErrorText, IsHandled, Ok);
#pragma warning restore AL0432
        if IsHandled then
            exit(Ok);
        OnBeforeGetDataEntry2(Type, InputCode, DataEntry, ErrorText, IsHandled, Ok);
        if IsHandled then
            exit(Ok);

        if PosFuncProfile."TS Data Entries" or PosFuncProfile."DD Data Entry" then begin
            if PosFuncProfile."TS Data Entries" then begin
                GetDataEntryUtils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
                GetDataEntryUtils.SendRequest(Type, InputCode, DataEntryTemp, ResponseCode, ErrorText);
                GetDataEntryUtils.SetCommunicationError(ResponseCode, ErrorText);
                if ErrorText <> '' then
                    exit(false);
                if DataEntryTemp.FindFirst then begin
                    DataEntry := DataEntryTemp;
                    DataEntry."Voucher Remaining Amount" := DataEntryTemp."Voucher Remaining Amount (Int)";
                end else begin
                    Clear(DataEntry);
                    exit(false);
                end;
            end else begin
                ErrorText := StrSubstNo(Text001, 'GetDataEntry');
                exit(false);
            end;
        end else
            exit(false);
        if not DataEntry2.Get(Type, InputCode) then
            DataEntry.Insert
        else
            DataEntry.Modify;
        exit(true);
    end;

    internal procedure GetStaffV2(var Staff: Record "LSC Staff"; var StaffStoreLink: Record "LSC STAFF Store Link"; ID: Code[20]; var ErrorText: Text): Boolean
    var
        StaffTemp: Record "LSC Staff" temporary;
        StaffStoreLinkTemp: Record "LSC STAFF Store Link" temporary;
        GetStaffV2Utils: Codeunit LSCGetStaffV2Utils;
        ResponseCode: Code[30];
        IsHandled: Boolean;
    begin
        if not Initialize then
            exit(false);

        if PosFuncProfile."TS Staff" then begin
            OnBeforeGetStaff(PosFuncProfile."Profile ID", ID, ResponseCode, ErrorText, StaffTemp, StaffStoreLinkTemp, IsHandled);
            if not IsHandled then begin
                GetStaffV2Utils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
                GetStaffV2Utils.SendRequest(ID, ResponseCode, ErrorText, StaffTemp, StaffStoreLinkTemp);
                GetStaffV2Utils.SetCommunicationError(ResponseCode, ErrorText);
            end;
            if ErrorText <> '' then
                exit(false);
            if StaffTemp.FindFirst then
                Staff := StaffTemp;
            if StaffStoreLinkTemp.FindSet() then
                repeat
                    StaffStoreLink.Init();
                    StaffStoreLink := StaffStoreLinkTemp;
                    if not StaffStoreLink.Insert() then
                        StaffStoreLink.Modify();
                until StaffStoreLinkTemp.Next() = 0;
            exit(true);
        end;
        exit(false);
    end;

    procedure UpdateStaff(var Staff: Record "LSC Staff"): Boolean
    var
        StaffTemp: Record "LSC Staff" temporary;
        SendStaffUtils: Codeunit LSCSendStaffUtils;
        ErrorText: Text[1024];
        ResponseCode: Code[30];
        IsHandled: Boolean;
    begin
        if not Initialize then
            exit(false);

        if PosFuncProfile."TS Staff" then begin
            StaffTemp.Init;
            StaffTemp := Staff;
            StaffTemp.Insert;

            OnBeforeSendStaffUpdate(PosFuncProfile."Profile ID", ResponseCode, ErrorText, StaffTemp, IsHandled);
            if not IsHandled then begin
                SendStaffUtils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
                SendStaffUtils.SendRequest(ResponseCode, ErrorText, false, StaffTemp);
                SendStaffUtils.SetCommunicationError(ResponseCode, ErrorText);
            end;
            if ErrorText <> '' then begin
                CreateTSRetryEntry(Database::"LSC Staff", Staff.ID, '', '', TSAction_g::Update, 0, false, Globals.StoreNo, Globals.TerminalNo, 0, '');
                exit(false);
            end;
        end;
        exit(true);
    end;

    internal procedure UpdateStaffStatus(StaffID: Code[20]; POS: Code[10]; Login: Boolean): Boolean
    var
        UpdateStaffStatusUtils: Codeunit LSCUpdateStaffStatusUtils;
        UpdateStaffCashStatusUtils: Codeunit LSCUpdateStaffCashStatusUtils;
        ErrorText: Text;
        PosTerminalNo: Code[10];
        ResponseCode: Code[30];
        TsFloatingCashierError: Boolean;
    begin
        if not Initialize then
            exit(false);

        if PosFuncProfile."TS Floating Cashier" then begin
            if Login then
                PosTerminalNo := POS
            else
                PosTerminalNo := '';
            UpdateStaffStatusUtils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
            UpdateStaffStatusUtils.SendRequest(StaffID, PosTerminalNo, ResponseCode, ErrorText);
            UpdateStaffStatusUtils.SetCommunicationError(ResponseCode, ErrorText);
        end;

        TsFloatingCashierError := ErrorText <> '';
        Clear(ErrorText);

        if PosFuncProfile."TS POS Cash Mgt." then
            if (Store_g."Statement Method" = Store_g."Statement Method"::Staff) then begin
                if Login then
                    PosTerminalNo := POS
                else
                    PosTerminalNo := '';
                UpdateStaffCashStatusUtils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
                UpdateStaffCashStatusUtils.SendRequest(StaffID, PosTerminalNo, ResponseCode, ErrorText);
                UpdateStaffCashStatusUtils.SetCommunicationError(ResponseCode, ErrorText);
            end;

        if TsFloatingCashierError or (ErrorText <> '') then
            exit(false)
        else
            exit(true);
    end;

    internal procedure GetStaffLoginStatus(StaffID: Code[20]; var ErrorCode: Integer): Code[10]
    var
        GetStaffStatusUtils: Codeunit LSCGetStaffStatusUtils;
        GetStaffCashStatusUtils: Codeunit LSCGetStaffCashStatusUtils;
        ErrorText: Text[1024];
        PosTerminalNo: Code[10];
        ResponseCode: Code[30];
    begin
        if not Initialize then
            exit('');

        if PosFuncProfile."TS Floating Cashier" then begin
            GetStaffStatusUtils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
            GetStaffStatusUtils.SendRequest(StaffID, ResponseCode, ErrorText, PosTerminalNo);
            GetStaffStatusUtils.SetCommunicationError(ResponseCode, ErrorText);
            if ErrorText = '' then
                exit(PosTerminalNo);
        end;

        if PosFuncProfile."TS POS Cash Mgt." then begin
            GetStaffCashStatusUtils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
            GetStaffCashStatusUtils.SendRequest(StaffID, ResponseCode, ErrorText, PosTerminalNo);
            GetStaffCashStatusUtils.SetCommunicationError(ResponseCode, ErrorText);
            if ErrorText = '' then
                exit(PosTerminalNo);
        end;
        exit('');
    end;

    procedure GetPostedTransaction(ReceiptNo: Code[20]; pStoreNo: Code[10]; pTerminalNo: Code[10]; pTransNo: Integer; var ResponseCode: Code[30]; var ErrorText: Text): Boolean
    var
        GetTransactionV2Utils: Codeunit LSCGetTransactionV2Utils;
        BufferUtility: Codeunit "LSC Buffer Utility";
        IsHandled: Boolean;
        RetVal: Boolean;
    begin
        OnBeforeGetPostedTransaction(ReceiptNo, pStoreNo, pTerminalNo, pTransNo, ResponseCode, ErrorText, IsHandled, RetVal);
        if IsHandled then
            exit(RetVal);

        if PosFuncProfile."TS Void Transactions" then begin
            GetTransactionV2Utils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
            GetTransactionV2Utils.SendRequest(ReceiptNo, pStoreNo, pTerminalNo, pTransNo, ResponseCode, ErrorText, BufferUtility);
            GetTransactionV2Utils.SetCommunicationError(ResponseCode, ErrorText);
            if ErrorText <> '' then begin
                if (ResponseCode = '0098') or (ResponseCode = '0099') then
                    if PosFuncProfile."Show Web Process Messages" then
                        Message(ErrorText);
                exit(false);
            end;
            exit(true);
        end;
    end;

    internal procedure GetCustomer(var Cust: Record Customer; CustNo: Code[20]; var ErrorText: Text): Boolean
    var
        GetCustomerUtils: Codeunit LSCGetCustomerUtils;
        ResponseCode: Code[30];
    begin
        if not Initialize then
            exit(false);
        if PosFuncProfile."TS Customer" then begin
            GetCustomerUtils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
            GetCustomerUtils.SendRequest(CustNo, ResponseCode, ErrorText, Cust);
            GetCustomerUtils.SetCommunicationError(ResponseCode, ErrorText);
            if ErrorText <> '' then
                exit(false);
            if Cust.FindFirst then begin
                Cust."LSC Amt. Charged On POS" := Cust."LSC AmtChargedOnPOSInt";
                Cust."LSC Amt. Charged Posted" := Cust."LSC AmtChargedPostedInt";
                Cust."Balance (LCY)" := Cust."LSC BalanceLCYInt";
            end;
            exit(true);
        end else begin
            ErrorText := StrSubstNo(Text001, 'GetCustomer');
            exit(false);
        end;
    end;

    local procedure UpdateTSContext()
    var
        t: Text[2];
    begin
        t := '  ';
        if GetTSUnsentTransactionsFlag then
            t[1] := 'i';
        if GetTSErrorFlag then
            t[2] := '+';
        PosCtrl.SetValue("LSC POS Tag"::TSSTATUSTXT, t);
    end;

    internal procedure SetTSErrorFlag(pError: Boolean)
    begin
        TSErrorFlag := pError;
        UpdateTSContext();
    end;

    internal procedure GetTSErrorFlag(): Boolean
    begin
        exit(TSErrorFlag);
    end;

    internal procedure SetTSUnsentTransactionsFlag(pUnsent: Boolean)
    begin
        TSUnsentTransactionsFlag := pUnsent;
        UpdateTSContext()
    end;

    internal procedure GetTSUnsentTransactionsFlag(): Boolean
    begin
        exit(TSUnsentTransactionsFlag);
    end;

    internal procedure ReadStatementTransactions(DoZ: Boolean; var ErrorText: Text): Boolean
    var
        SCode: Code[20];
    begin
        if not Initialize then
            exit(false);

        if PosFuncProfile."TS Floating Cashier" and
          (POSTerminal_g."Statement Method" = POSTerminal_g."Statement Method"::Staff) and
          (POSTerminal_g."Terminal Connection" = POSTerminal_g."Terminal Connection"::OffLine)
        then begin
            SCode := POSFunc.GetStatementCode;

            if DoZ then
                ReplaceZReportIDWith(SCode, '', '.');

            if not DoZ then
                if not WebUpdatePOSAfterStatementCode(ErrorText) then
                    exit(false);

            if not WebGetTransByStatmentCode(SCode, ErrorText) then begin
                if DoZ then
                    ReplaceZReportIDWith(SCode, '.', '');
                exit(false);
            end;
        end;
        exit(true);
    end;

    local procedure ReplaceZReportIDWith(SCode: Code[20]; Current: Code[10]; New: Code[10])
    var
        Transaction: Record "LSC Transaction Header";
        Transaction2: Record "LSC Transaction Header";
        PaymEntry: Record "LSC Trans. Payment Entry";
        PaymEntry2: Record "LSC Trans. Payment Entry";
        IncExpEntry: Record "LSC Trans. Inc./Exp. Entry";
        IncExpEntry2: Record "LSC Trans. Inc./Exp. Entry";
        TendDeclEntry: Record "LSC Trans. Tender Declar. Entr";
        TendDeclEntry2: Record "LSC Trans. Tender Declar. Entr";
    begin
        Transaction.SetCurrentKey("Statement Code", "Z-Report ID");
        Transaction.SetRange("Statement Code", SCode);
        Transaction.SetRange("Z-Report ID", Current);
        if Transaction.FindSet then
            repeat
                Transaction2 := Transaction;
                Transaction2."Z-Report ID" := New;
                Transaction2.Modify(true);
            until Transaction.Next = 0;

        PaymEntry.SetCurrentKey("Statement Code", "Z-Report ID");
        PaymEntry.SetRange("Statement Code", SCode);
        PaymEntry.SetRange("Z-Report ID", Current);
        if PaymEntry.FindSet then
            repeat
                PaymEntry2 := PaymEntry;
                PaymEntry2."Z-Report ID" := New;
                PaymEntry2.Modify(true);
            until PaymEntry.Next = 0;

        TendDeclEntry.SetCurrentKey("Statement Code", "Z-Report ID");
        TendDeclEntry.SetRange("Statement Code", SCode);
        TendDeclEntry.SetRange("Z-Report ID", Current);
        if TendDeclEntry.FindSet then
            repeat
                TendDeclEntry2 := TendDeclEntry;
                TendDeclEntry2."Z-Report ID" := New;
                TendDeclEntry2.Modify(true);
            until TendDeclEntry.Next = 0;

        IncExpEntry.SetCurrentKey("Statement Code", "Z-Report ID");
        IncExpEntry.SetRange("Statement Code", SCode);
        IncExpEntry.SetRange("Z-Report ID", Current);
        if IncExpEntry.FindSet then
            repeat
                IncExpEntry2 := IncExpEntry;
                IncExpEntry2."Z-Report ID" := New;
                IncExpEntry2.Modify(true);
            until IncExpEntry.Next = 0;
    end;

    procedure UpdateXZReportInformation(DoZ: Boolean)
    var
        ZReportID: Code[20];
    begin
        if not Initialize then
            exit;

        if PosFuncProfile."TS Floating Cashier" and
           (POSTerminal_g."Statement Method" = POSTerminal_g."Statement Method"::Staff) and
           (POSTerminal_g."Terminal Connection" = POSTerminal_g."Terminal Connection"::OffLine) then begin
            if DoZ then begin
                ZReportID := Globals.GetValue("LSC POS Tag"::"LAST_ZID");
                UpdateStatementTransactions(POSFunc.GetStatementCode, ZReportID);
                CleanupForeignXZTransactions(ZReportID);
            end else
                CleanupForeignXZTransactions('');
        end;
    end;

    local procedure CleanupForeignXZTransactions(ZFilter: Code[20])
    var
        Transaction: Record "LSC Transaction Header";
        PaymEntry: Record "LSC Trans. Payment Entry";
        IncExpEntry: Record "LSC Trans. Inc./Exp. Entry";
        TendDeclEntry: Record "LSC Trans. Tender Declar. Entr";
    begin
        Transaction.SetCurrentKey("Statement Code", "Z-Report ID");
        Transaction.SetRange("Statement Code", POSFunc.GetStatementCode);
        Transaction.SetRange("Z-Report ID", ZFilter);
        Transaction.SetFilter("POS Terminal No.", '<>%1', Globals.TerminalNo);
        Transaction.DeleteAll;

        PaymEntry.SetCurrentKey("Statement Code", "Z-Report ID");
        PaymEntry.SetRange("Statement Code", POSFunc.GetStatementCode);
        PaymEntry.SetRange("Z-Report ID", ZFilter);
        PaymEntry.SetFilter("POS Terminal No.", '<>%1', Globals.TerminalNo);
        PaymEntry.DeleteAll;

        IncExpEntry.SetCurrentKey("Statement Code", "Z-Report ID");
        IncExpEntry.SetRange("Statement Code", POSFunc.GetStatementCode);
        IncExpEntry.SetRange("Z-Report ID", ZFilter);
        IncExpEntry.SetFilter("POS Terminal No.", '<>%1', Globals.TerminalNo);
        IncExpEntry.DeleteAll;

        TendDeclEntry.SetCurrentKey("Statement Code", "Z-Report ID");
        TendDeclEntry.SetRange("Statement Code", POSFunc.GetStatementCode);
        TendDeclEntry.SetRange("Z-Report ID", ZFilter);
        TendDeclEntry.SetFilter("POS Terminal No.", '<>%1', Globals.TerminalNo);
        TendDeclEntry.DeleteAll;
    end;

    local procedure UpdateStatementTransactions(SCode: Code[20]; ZId: Code[20]): Boolean
    var
        Trans: Record "LSC Transaction Header";
        Staff: Record "LSC Staff";
    begin
        if not Initialize then
            exit(false);

        if PosFuncProfile."TS Floating Cashier" and
          (POSTerminal_g."Statement Method" = POSTerminal_g."Statement Method"::Staff) and
          (POSTerminal_g."Terminal Connection" = POSTerminal_g."Terminal Connection"::OffLine)
        then begin
            DCUTIL.Initialize(PosFuncProfile."Profile ID");

            Staff.Get(SCode);
            if UpdateStaff(Staff) then;

            TransactionHeaderTemp_g.DeleteAll;
            Trans.SetCurrentKey("Statement Code", "Z-Report ID");
            Trans.SetRange("Statement Code", SCode);
            Trans.SetRange("Z-Report ID", ZId);
            if Trans.FindSet then
                repeat
                    TransactionHeaderTemp_g."Store No." := Trans."Store No.";
                    TransactionHeaderTemp_g."POS Terminal No." := Trans."POS Terminal No.";
                    TransactionHeaderTemp_g."Transaction No." := Trans."Transaction No.";
                    if TransactionHeaderTemp_g.Insert then;
                until Trans.Next = 0;

            if not SendWholeTmpTransaction() then begin
                CreateTSRetryEntry(Database::"LSC Transaction Header", SCode, ZId, '', TSAction_g::Update, 1, true, Globals.StoreNo, Globals.TerminalNo, 0, '');
                if GuiAllowed then
                    PosCtrl.ScreenDisplay('');
                exit(false);
            end;
            if GuiAllowed then
                PosCtrl.ScreenDisplay('');
            exit(true);
        end;
    end;

    procedure SendTableTransaction(PosTrans: Record "LSC POS Transaction"; TableNo: Integer)
        DistLoc: Code[10];
    begin
        if not Initialize then
            exit;

        if not SendPOSTrans(PosTrans, '', 'SendPosTransBackup') then
            CreateTSRetryEntry(Database::"LSC POS Transaction", Format(PosTrans."Receipt No."), '', '', TSAction_g::Update, TableNo, true,
              PosTrans."Store No.", PosTrans."POS Terminal No.", 0, 'SendPosTransBackup');
    end;

    procedure DeleteTablePOSTrans(PosTrans: Record "LSC POS Transaction"; TableNo: Integer)
    var
        DeletePOSTransBackupUtils: Codeunit LSCDeletePOSTransBackupUtils;
        ErrorText: Text;
        ResponseCode: Code[30];
    begin
        if not Initialize then
            exit;

        DeletePOSTransBackupUtils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
        DeletePOSTransBackupUtils.SendRequest(PosTrans."Receipt No.", ResponseCode, ErrorText);
        if ErrorText <> '' then
            CreateTSRetryEntry(Database::"LSC POS Transaction", Format(PosTrans."Receipt No."), '', '', TSAction_g::Delete, TableNo, true,
                PosTrans."Store No.", PosTrans."POS Terminal No.", 0, 'DeletePOSTransBackup');
    end;

    procedure CreateTSRetryEntry(TableNo: Integer; Key1: Text[250]; Key2: Text[50]; DistLoc: Code[50]; TSAction: Integer; Ext: Integer; Linked: Boolean; StoreNo: Code[10]; POSTerminalNo: Code[10]; TransactionNo: Integer; RequestID: Text[30])
    var
        RetryEntry: Record "LSC Trans. Server Work Table";
        RetryEntry2: Record "LSC Trans. Server Work Table";
    begin
        RetryEntry.Table := TableNo;
        RetryEntry.Key1 := Key1;
        RetryEntry.Key2 := Key2;
        RetryEntry.Code1 := DistLoc;
        RetryEntry.Int1 := TSAction;
        RetryEntry.Int2 := Ext;
        RetryEntry.Bool1 := Linked;
        RetryEntry."Store No." := StoreNo;
        RetryEntry."POS Terminal No." := POSTerminalNo;
        RetryEntry."Transaction No." := TransactionNo;
        RetryEntry."Web Request ID" := RequestID;
        RetryEntry."Created by Store No." := Globals.StoreNo;
        RetryEntry."Created by POS Terminal No." := Globals.TerminalNo;
        if WorkTableUpdateTemp_g then
            SetWorkTableInsertBuffer(RetryEntry)
        else
            if not RetryEntry2.Get(RetryEntry.Table, RetryEntry.Key1, RetryEntry.Key2, RetryEntry."Store No.", RetryEntry."POS Terminal No.",
              RetryEntry."Transaction No.")
            then
                RetryEntry.Insert
            else
                RetryEntry.Modify;
    end;

    internal procedure GetItemInventoryLookupTable(ItemNo: Code[20]; Variant: Code[20]; StoreNo: Code[10]; LocationProfile: Code[30]; var ErrorText: Text): Boolean
    var
        InventoryLookupTableTemp: Record "LSC Inventory Lookup Table" temporary;
        GetInventoryLookupUtil: Codeunit LSCGetInventoryLookupUtils;
        ResponseCode: Code[30];
        ReturnValue, IsHandled : Boolean;
    begin
        if not Initialize then
            exit(false);
        if PosFuncProfile."TS Inv. Lookup" then begin
            OnBeforeGetInventoryLookup(ItemNo, Variant, StoreNo, LocationProfile, InventoryLookupTableTemp, ResponseCode, ErrorText, ReturnValue, IsHandled);
            if IsHandled then
                exit(ReturnValue);

            GetInventoryLookupUtil.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
            GetInventoryLookupUtil.SendRequest(ItemNo, Variant, StoreNo, LocationProfile, InventoryLookupTableTemp, ResponseCode, ErrorText);
            GetInventoryLookupUtil.SetCommunicationError(ResponseCode, ErrorText);
            if ErrorText <> '' then begin
                if PosFuncProfile."Show Web Process Messages" then
                    Message(ErrorText);
                exit(false);
            end;
            exit(true);
        end else begin
            if PosFuncProfile."Show Web Process Messages" then
                Message(ErrorText);
            exit(false);
        end;
    end;

    internal procedure UpdateLookupTable(ExtStoreNo: Code[20]; ExtItemCat: Code[20]; ExtItemGrp: Code[20])
    var
        Store: Record "LSC Store";
        ItemGroup: Record "LSC Retail Product Group";
        Item: Record Item;
        ItemVariant: Record "Item Variant";
        LookUpEntry: Record "LSC Inventory Lookup Table";
        ItemLedgEntry: Record "Item Ledger Entry";
        Window: Dialog;
        SerialLotItem: Boolean;
        ProcessStore: Label 'Processing Store #1####################\';
        ProcessGroup: Label 'Processing Group #2####################\';
        ProcessItem: Label 'Processing Item  #3####################\';
    begin
        if GuiAllowed then
            Window.Open(ProcessStore + ProcessGroup + ProcessItem);

        if ExtStoreNo <> '' then
            Store.SetRange("No.", ExtStoreNo)
        else
            Store.SetRange("POS Inventory Lookup", true);
        if Store.FindSet then
            repeat
                if GuiAllowed then
                    Window.Update(1, Store."No.");

                if ExtItemCat <> '' then
                    ItemGroup.SetRange("Item Category Code", ExtItemCat);

                if ExtItemGrp <> '' then
                    ItemGroup.SetRange(Code, ExtItemGrp);

                ItemGroup.SetRange("POS Inventory Lookup", true);

                ItemLedgEntry.SetCurrentKey("Item No.", Open, "Variant Code", Positive,
                  "Location Code", "Posting Date", "Expiration Date", "Lot No.", "Serial No.");
                ItemLedgEntry.SetRange(Positive, true);
                ItemLedgEntry.SetRange("Location Code", Store."Location Code");

                if ItemGroup.FindSet then
                    repeat
                        if GuiAllowed then
                            Window.Update(2, ItemGroup.Code);
                        Item.SetRange("LSC Retail Product Code", ItemGroup.Code);
                        if Item.FindSet then
                            repeat
                                if GuiAllowed then
                                    Window.Update(3, Item."No.");
                                if ItemTrack.IsItemSNTracking(Item."No.") or ItemTrack.IsItemLotTracking(Item."No.") then
                                    SerialLotItem := true
                                else
                                    SerialLotItem := false;

                                if SerialLotItem then begin
                                    ItemLedgEntry.SetRange("Item No.", Item."No.");
                                    LookUpEntry.SetRange("Item No.", Item."No.");
                                    LookUpEntry.SetRange("Store No.", Store."No.");
                                    if LookUpEntry.IsEmpty then
                                        ItemLedgEntry.SetRange("Posting Date")
                                    else
                                        ItemLedgEntry.SetRange("Posting Date", CalcDate('<-1M>', Today), Today);
                                    if ItemLedgEntry.FindSet then
                                        repeat
                                            if not LookUpEntry.Get(Item."No.", '', Store."No.", ItemLedgEntry."Lot No.", ItemLedgEntry."Serial No.") then begin
                                                if ItemGroup."POS Inventory Lookup" and Store."POS Inventory Lookup" then begin
                                                    Clear(LookUpEntry);
                                                    LookUpEntry."Item No." := Item."No.";
                                                    LookUpEntry.Validate("Store No.", Store."No.");
                                                    LookUpEntry.Location := Store."Location Code";
                                                    LookUpEntry."Lot No." := ItemLedgEntry."Lot No.";
                                                    LookUpEntry."Serial No." := ItemLedgEntry."Serial No.";
                                                    LookUpEntry."Expiration Date" := ItemLedgEntry."Expiration Date";
                                                    LookUpEntry.Insert;
                                                end
                                            end else
                                                if not Store."POS Inventory Lookup" or not ItemGroup."POS Inventory Lookup" then
                                                    LookUpEntry.Delete;
                                        until ItemLedgEntry.Next = 0;
                                    OnAfterUpdateLookupTable(LookUpEntry, Item, ItemVariant, ItemGroup, Store, ItemLedgEntry);
                                end else begin
                                    if not LookUpEntry.Get(Item."No.", '', Store."No.", '', '') then begin
                                        if ItemGroup."POS Inventory Lookup" and Store."POS Inventory Lookup" then begin
                                            Clear(LookUpEntry);
                                            LookUpEntry."Item No." := Item."No.";
                                            LookUpEntry.Validate("Store No.", Store."No.");
                                            LookUpEntry.Location := Store."Location Code";
                                            OnBeforeInsertLookUpEntryforNonSerialLotItem(LookUpEntry, Item, ItemVariant, ItemGroup, Store, ItemLedgEntry);
                                            LookUpEntry.Insert;
                                        end
                                    end else
                                        if not Store."POS Inventory Lookup" or not ItemGroup."POS Inventory Lookup" then
                                            LookUpEntry.Delete;
                                end;

                                ItemVariant.SetRange("Item No.", Item."No.");
                                if ItemVariant.FindSet then
                                    repeat
                                        if SerialLotItem then begin
                                            ItemLedgEntry.SetRange("Item No.", Item."No.");
                                            ItemLedgEntry.SetRange("Variant Code", ItemVariant.Code);
                                            LookUpEntry.SetRange("Item No.", Item."No.");
                                            LookUpEntry.SetRange("Variant Code", ItemVariant.Code);
                                            LookUpEntry.SetRange("Store No.", Store."No.");
                                            if LookUpEntry.IsEmpty then
                                                ItemLedgEntry.SetRange("Posting Date")
                                            else
                                                ItemLedgEntry.SetRange("Posting Date", CalcDate('<-1M>', Today), Today);
                                            if ItemLedgEntry.FindSet then
                                                repeat
                                                    if not LookUpEntry.Get(Item."No.", ItemVariant.Code, Store."No.",
                                                       ItemLedgEntry."Lot No.", ItemLedgEntry."Serial No.")
                                                    then begin
                                                        if ItemGroup."POS Inventory Lookup" and Store."POS Inventory Lookup" then begin
                                                            Clear(LookUpEntry);
                                                            LookUpEntry."Item No." := Item."No.";
                                                            LookUpEntry.Validate("Store No.", Store."No.");
                                                            LookUpEntry.Location := Store."Location Code";
                                                            LookUpEntry."Variant Code" := ItemVariant.Code;
                                                            LookUpEntry."Lot No." := ItemLedgEntry."Lot No.";
                                                            LookUpEntry."Serial No." := ItemLedgEntry."Serial No.";
                                                            LookUpEntry."Expiration Date" := ItemLedgEntry."Expiration Date";
                                                            LookUpEntry.Insert;
                                                        end
                                                    end else
                                                        if not Store."POS Inventory Lookup" or not ItemGroup."POS Inventory Lookup" then
                                                            LookUpEntry.Delete;
                                                until ItemLedgEntry.Next = 0;
                                            OnAfterUpdateLookupTable(LookUpEntry, Item, ItemVariant, ItemGroup, Store, ItemLedgEntry);
                                        end else begin
                                            if not LookUpEntry.Get(Item."No.", ItemVariant.Code, Store."No.", '', '') then begin
                                                if ItemGroup."POS Inventory Lookup" and Store."POS Inventory Lookup" then begin
                                                    Clear(LookUpEntry);
                                                    LookUpEntry."Item No." := Item."No.";
                                                    LookUpEntry.Validate("Store No.", Store."No.");
                                                    LookUpEntry.Location := Store."Location Code";
                                                    LookUpEntry."Variant Code" := ItemVariant.Code;
                                                    OnBeforeInsertLookUpEntryforNonSerialLotItemVar(LookUpEntry, Item, ItemVariant, ItemGroup, Store, ItemLedgEntry);
                                                    LookUpEntry.Insert;
                                                end;
                                            end else
                                                if not Store."POS Inventory Lookup" or not ItemGroup."POS Inventory Lookup" then
                                                    LookUpEntry.Delete;
                                        end;
                                    until ItemVariant.Next = 0;
                            until Item.Next = 0;
                    until ItemGroup.Next = 0;
            until Store.Next = 0;

        if GuiAllowed then
            Window.Close;
    end;

    internal procedure UpdateLookupTableQuery(ItemNo_p: Code[20]; StoreNo_p: Code[20]; ExtItemCat: Code[20]; ExtItemGrp: Code[20])
    var
        Store: Record "LSC Store";
        ItemLedgEntry: Record "Item Ledger Entry";
        ValidItemsTEMP: Record "LSC Inventory Lookup Table" temporary;
        InvLookupTable: Record "LSC Inventory Lookup Table";
        RetailItemTracking: Codeunit "LSC Retail Item Tracking";
        InventoryLookupItemVar: Query "LSC Inventory Lookup - Variant";
        InventoryLookupItemlist: Query "LSC Invt. Lookup - Item list";
        StoreList: Query "LSC Store List";
        ModifyExisting, IsHandled : Boolean;
    begin
        //Get variant items
        Clear(InventoryLookupItemVar);
        ValidItemsTEMP.DeleteAll;
        if ExtItemCat <> '' then
            InventoryLookupItemVar.SetRange(ItemCategoryFilter, ExtItemCat);
        if ExtItemGrp <> '' then
            InventoryLookupItemVar.SetRange(ProductGroupFilter, ExtItemGrp);
        if ItemNo_p <> '' then
            InventoryLookupItemVar.SetRange(ItemNofilter, ItemNo_p);

        InventoryLookupItemVar.Open;
        while InventoryLookupItemVar.Read do
            if not ValidItemsTEMP.Get(InventoryLookupItemVar.ItemNo, InventoryLookupItemVar.VarianCode, '', '', '') then begin
                ValidItemsTEMP.Init;
                ValidItemsTEMP."Item No." := InventoryLookupItemVar.ItemNo;
                ValidItemsTEMP."Variant Code" := InventoryLookupItemVar.VarianCode;
                ValidItemsTEMP."Store No." := '';
                ValidItemsTEMP."Lot No." := '';
                ValidItemsTEMP."Serial No." := '';
                IsHandled := false;
                OnBeforeInsertToValidItemsTEMP(ValidItemsTEMP, IsHandled);
                if not IsHandled then
                    ValidItemsTEMP.Insert;
            end;

        //Get items without variants
        Clear(InventoryLookupItemlist);
        if ExtItemCat <> '' then
            InventoryLookupItemlist.SetRange(ItemCategoryFilter, ExtItemCat);
        if ExtItemGrp <> '' then
            InventoryLookupItemlist.SetRange(ProductGroupFilter, ExtItemGrp);
        if ItemNo_p <> '' then
            InventoryLookupItemlist.SetRange(ItemNofilter, ItemNo_p);

        InventoryLookupItemlist.Open;
        while InventoryLookupItemlist.Read do
            if not ValidItemsTEMP.Get(InventoryLookupItemlist.ItemNo, '', '', '', '') then begin
                ValidItemsTEMP.Init;
                ValidItemsTEMP."Item No." := InventoryLookupItemlist.ItemNo;
                ValidItemsTEMP."Variant Code" := '';
                ValidItemsTEMP."Store No." := '';
                ValidItemsTEMP."Lot No." := '';
                ValidItemsTEMP."Serial No." := '';
                IsHandled := false;
                OnBeforeInsertToValidItemsTEMP(ValidItemsTEMP, IsHandled);
                if not IsHandled then
                    ValidItemsTEMP.Insert;
            end;

        //Get stores
        Clear(StoreList);
        if StoreNo_p <> '' then begin
            if not Store.Get(StoreNo_p) then
                Clear(Store);
            StoreList.SetRange(StoreNoFilter, StoreNo_p);
        end;

        //Create list
        StoreList.Open;
        while StoreList.Read do begin
            Store.Get(StoreList.No);
            ValidItemsTEMP.Reset;
            if ValidItemsTEMP.FindSet then
                repeat
                    ModifyExisting := false;
                    if InvLookupTable.Get(ValidItemsTEMP."Item No.", ValidItemsTEMP."Variant Code", StoreList.No, '', '') then
                        ModifyExisting := true
                    else
                        InvLookupTable.Init;

                    InvLookupTable."Item No." := ValidItemsTEMP."Item No.";
                    InvLookupTable."Variant Code" := ValidItemsTEMP."Variant Code";
                    InvLookupTable.Validate("Store No.", StoreList.No);
                    InvLookupTable.Location := Store."Location Code";
                    InvLookupTable."Location Profile" := Store."Location Profile";
                    InvLookupTable."Lot No." := '';
                    InvLookupTable."Serial No." := '';
                    //Add Serial/Lot items
                    if RetailItemTracking.IsRetailProductGroupTracking(ValidItemsTEMP."Item No.") or
                        RetailItemTracking.IsItemSNTracking(ValidItemsTEMP."Item No.") or
                         RetailItemTracking.IsItemLotTracking(ValidItemsTEMP."Item No.")
                    then begin
                        ItemLedgEntry.Reset;
                        ItemLedgEntry.SetCurrentKey("Item No.", Open, "Variant Code", Positive,
                          "Location Code", "Posting Date", "Expiration Date", "Lot No.", "Serial No.");
                        ItemLedgEntry.SetRange("Item No.", ValidItemsTEMP."Item No.");
                        ItemLedgEntry.SetRange("Variant Code", ValidItemsTEMP."Variant Code");
                        ItemLedgEntry.SetRange(Open, true);
                        ItemLedgEntry.SetRange(Positive, true);
                        ItemLedgEntry.SetRange("Location Code", Store."Location Code");
                        if ItemLedgEntry.FindSet then
                            repeat
                                ModifyExisting := InvLookupTable.Get(ValidItemsTEMP."Item No.", ValidItemsTEMP."Variant Code", StoreList.No, ItemLedgEntry."Lot No.", ItemLedgEntry."Serial No.");
                                InvLookupTable."Lot No." := ItemLedgEntry."Lot No.";
                                InvLookupTable."Serial No." := ItemLedgEntry."Serial No.";
                                InvLookupTable."Expiration Date" := ItemLedgEntry."Expiration Date";
                                if ModifyExisting then
                                    InvLookupTable.Modify
                                else
                                    InvLookupTable.Insert;
                                OnAfterModifyOrInsertInvLookupTable(InvLookupTable, ValidItemsTEMP, Store, StoreList, ModifyExisting);
                            until ItemLedgEntry.Next = 0
                        else
                            if ModifyExisting then
                                InvLookupTable.Modify
                            else
                                InvLookupTable.Insert;
                        OnAfterModifyOrInsertInvLookupTable(InvLookupTable, ValidItemsTEMP, Store, StoreList, ModifyExisting);
                    end else
                        if ModifyExisting then
                            InvLookupTable.Modify
                        else
                            InvLookupTable.Insert;
                    OnAfterModifyOrInsertInvLookupTable(InvLookupTable, ValidItemsTEMP, Store, StoreList, ModifyExisting);
                until ValidItemsTEMP.Next = 0;
        end;
    end;

    internal procedure GetTimeReg(StaffID: Code[20]; var ErrorCode: Integer): Boolean
    var
        ErrorText: Text[1024];
        ProcessError: Boolean;
    begin
        if not Initialize then
            exit(false);

        if PosFuncProfile."TS Login Staff" then begin
            WebServicesClient.SetPosFuncProfile(PosFuncProfile);
            if not WebServicesClient.GetTimeRegEntry(StaffID, ProcessError, ErrorText) then begin
                if ProcessError then begin
                    ErrorCode := 9999;
                    if PosFuncProfile."Show Web Process Messages" then
                        Message(ErrorText);
                end;
                exit(false);
            end;
            exit(true);
        end;
    end;

    internal procedure UpdateTimeReg(var TimeRegEntry: Record "LSC Time Registration Entry"): Boolean
    var
        ErrorText: Text[1024];
        ProcessError: Boolean;
    begin
        if not Initialize then
            exit(false);
        if PosFuncProfile."TS Login Staff" then begin
            WebServicesClient.SetPosFuncProfile(PosFuncProfile);
            if not WebServicesClient.SendTimeRegEntry(TimeRegEntry, ProcessError, ErrorText) then
                exit(false);
            exit(true);
        end;
    end;

    internal procedure MarkWorkShiftEntryForUpdate(var WorkShiftEntry: Record "LSC Work Shift Entry")
    begin
        if not Initialize then
            exit;

        if PosFuncProfile."TS Send Transactions" or PosFuncProfile."DD Send Transaction" then begin
            CreateTSRetryEntry(
              Database::"LSC Work Shift Entry", Format(WorkShiftEntry."Shift Date"),
              WorkShiftEntry."Shift No.", WorkShiftEntry."Statement Code", TSAction_g::Update,
              0, false, WorkShiftEntry."Store No.", Globals.TerminalNo, 0, '');
            CreateTSRetryEntry(
              Database::"LSC Work Shift RBO", Format(WorkShiftEntry."Shift Date"),
              WorkShiftEntry."Shift No.", '', TSAction_g::Update,
              0, false, WorkShiftEntry."Store No.", Globals.TerminalNo, 0, '');
        end;
    end;

    internal procedure GetPosStartStatus(POSStartStatus: Record "LSC POS Start Status"; var ErrorText: Text): Boolean
    var
        POSStartStatusTemp: Record "LSC POS Start Status" temporary;
        POSStartEntryTemp: Record "LSC POS Start Entry" temporary;
        POSStartEntryLineTemp: Record "LSC POS Start Entry Line" temporary;
        RetryAction: Record "LSC Trans. Server Work Table";
        PosStartStat2: Record "LSC POS Start Status";
        GetPosStartStatusUtils: Codeunit LSCGetPosStartStatusUtils;
        SendPosStartStatusUtils: Codeunit LSCSendPosStartStatusUtils;
        ResponseCode: Code[30];
        ok: Boolean;
        stop: Boolean;
        StatusandEntriesTxt: Label 'Status and Entries', Locked = true;
    begin
        if not Initialize then
            exit(false);

        if PosFuncProfile."TS POS Cash Mgt." then begin
            ok := false;
            stop := false;
            Clear(RetryAction);
            RetryAction.SetRange("Created by Store No.", Globals.StoreNo);
            RetryAction.SetRange("Created by POS Terminal No.", Globals.TerminalNo);
            RetryAction.SetRange(Table, Database::"LSC POS Start Status");
            if RetryAction.FindSet() then begin
                repeat
                    Clear(PosStartStat2);
                    PosStartStat2."Store No." := BOUtil.SeparateTableKey(1, RetryAction.Key1);
                    if Evaluate(PosStartStat2.Type, BOUtil.SeparateTableKey(2, RetryAction.Key1)) then;
                    PosStartStat2.ID := BOUtil.SeparateTableKey(3, RetryAction.Key1);
#pragma warning disable AA0181  // Find('=') selects a single record
                    if PosStartStat2.Find() then begin
#pragma warning restore
                        POSStartStatusTemp.Init;
                        POSStartStatusTemp := PosStartStat2;
                        POSStartStatusTemp.Insert;

                        SendPosStartStatusUtils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
                        SendPosStartStatusUtils.SendRequest(ResponseCode, ErrorText, false, POSStartStatusTemp);
                        SendPosStartStatusUtils.SetCommunicationError(ResponseCode, ErrorText);
                        ok := ErrorText = '';
                        stop := not ok;
                    end;
                until stop or (RetryAction.Next = 0);
                if ok then
                    exit(true);
            end;
            if not POSStartStatusTemp.IsEmpty then
                POSStartStatusTemp.DeleteAll;

            GetPosStartStatusUtils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
            GetPosStartStatusUtils.SendRequest(ResponseCode, ErrorText, StatusandEntriesTxt, POSStartStatus."Store No.", Format(POSStartStatus.Type),
              POSStartStatus.ID, '', '', '', '', POSStartStatusTemp, POSStartEntryTemp, POSStartEntryLineTemp);
            GetPosStartStatusUtils.SetCommunicationError(ResponseCode, ErrorText);
            if ErrorText <> '' then begin
                if PosFuncProfile."Show Web Process Messages" then
                    Message(ErrorText);
                exit(false);
            end;
            exit(true);
        end;
        exit(false);
    end;

    internal procedure UpdatePosStartStatus(PosStartStat: Record "LSC POS Start Status"; var ErrorText: Text): Boolean
    var
        POSStartStatusTemp: Record "LSC POS Start Status" temporary;
        SendPosStartStatusUtils: Codeunit LSCSendPosStartStatusUtils;
        ResponseCode: Code[30];
        Ret: Boolean;
    begin
        Ret := true;

        if not Initialize then
            exit(false);

        if PosFuncProfile."TS POS Cash Mgt." then begin
            POSStartStatusTemp.Init;
            POSStartStatusTemp := PosStartStat;
            POSStartStatusTemp.Insert;

            SendPosStartStatusUtils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
            SendPosStartStatusUtils.SendRequest(ResponseCode, ErrorText, false, POSStartStatusTemp);
            if ErrorText <> '' then begin
                if PosFuncProfile."Show Web Process Messages" then
                    Message(ErrorText);
                Ret := false;
            end else
                Ret := true;
        end;

        if not Ret then
            CreateTSRetryEntry(Database::"LSC POS Start Status", BOUtil.CombineTableKey(3, PosStartStat."Store No.", BOUtil.OptToStr(PosStartStat.Type),
              PosStartStat.ID, '', ''), '', '', TSAction_g::Update, 0, false, PosStartStat."Store No.", PosStartStat."POS Terminal No.", 0, '');

        exit(Ret);
    end;

    internal procedure GetPosStartStatAndCalc(var PosStartStat: Record "LSC POS Start Status"; var ErrorCode: Integer): Boolean
    var
        POSStartStatusTemp: Record "LSC POS Start Status" temporary;
        POSStartEntryTemp: Record "LSC POS Start Entry" temporary;
        POSStartEntryLineTemp: Record "LSC POS Start Entry Line" temporary;
        GetPosStartStatusUtils: Codeunit LSCGetPosStartStatusUtils;
        ResponseCode: Code[30];
        ErrorText: Text;
        StatusOnlyTxt: Label 'Status Only', Locked = true;
    begin
        if not Initialize then
            exit(false);

        if PosFuncProfile."TS POS Cash Mgt." then begin
            GetPosStartStatusUtils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
            GetPosStartStatusUtils.SendRequest(ResponseCode, ErrorText, StatusOnlyTxt,
                PosStartStat."Store No.", Format(PosStartStat.Type), PosStartStat.ID,
                '', '', '', '', POSStartStatusTemp, POSStartEntryTemp, POSStartEntryLineTemp);
            if ErrorText <> '' then begin
                if PosFuncProfile."Show Web Process Messages" then
                    Message(ErrorText);
                exit(false);
            end;
            exit(true);
        end;
        exit(false);
    end;

    internal procedure CreateTmpTotalPayment(PosTrans: Record "LSC POS Transaction"; Type: Integer): Boolean
    begin
        exit(DCUTIL.CreateTmpTotalPayment(PosTrans, Type));
    end;

    internal procedure FirstTmpTotalPayment(var PosCashDecl: Record "LSC POS Cash Declaration"): Boolean
    begin
        exit(DCUTIL.FirstTmpTotalPayment(PosCashDecl));
    end;

    internal procedure NextTmpTotalPayment(var PosCashDecl: Record "LSC POS Cash Declaration"): Boolean
    begin
        exit(DCUTIL.NextTmpTotalPayment(PosCashDecl));
    end;

    internal procedure TSInUse(pPosFuncProfile: Record "LSC POS Func. Profile"): Boolean
    begin
        exit(true in [
            pPosFuncProfile."TS Send Transactions",
            pPosFuncProfile."TS Void Transactions",
            pPosFuncProfile."TS Susp./Retrieve",
            pPosFuncProfile."TS Staff",
            pPosFuncProfile."TS Customer",
            pPosFuncProfile."TS Data Entries",
            pPosFuncProfile."TS Floating Cashier",
            pPosFuncProfile."DD Send Transaction",
            pPosFuncProfile."DD Data Entry",
            pPosFuncProfile."DD Void Transactions",
            pPosFuncProfile."TS Inv. Lookup",
            pPosFuncProfile."TS Customer Invoice",
            pPosFuncProfile."TS Online Trans. Backup",
            pPosFuncProfile."TS Login Staff",
            pPosFuncProfile."TS POS Cash Mgt.",
            pPosFuncProfile."TS Sales Document",
            pPosFuncProfile."TS Susp./Retrieve"
        ]);
    end;

    internal procedure GetCustSpecInvoice(InvoiceNo: Code[20]; var CustLedgEntryTemp: Record "Cust. Ledger Entry" temporary; var ErrorText: Text): Boolean
    var
        GetCustomerInvoicesUtils: Codeunit LSCGetCustomerInvoicesUtils;
        ResponseCode: Code[20];
    begin
        if not Initialize then
            exit(false);
        if PosFuncProfile."TS Customer Invoice" and (InvoiceNo <> '') then begin
            GetCustomerInvoicesUtils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
            GetCustomerInvoicesUtils.SendRequest('All', InvoiceNo, '', ResponseCode, ErrorText, CustLedgEntryTemp);
            GetCustomerInvoicesUtils.SetCommunicationError(ResponseCode, ErrorText);
            if ErrorText <> '' then
                exit(false);
        end else begin
            ErrorText := StrSubstNo(Text001, 'GetCustomerInvoices');
            exit(false);
        end;
        exit(true);
    end;

    internal procedure GetOpenVoucherEntry(VoucherNo: Code[20]; Pin: Integer; var TmpVoucherEntries: Record "LSC Voucher Entries"; var ErrorText: Text): Boolean
    var
        GetVoucherEntriesUtils: Codeunit LSCGetVoucherEntriesUtilsV2;
        ResponseCode: Code[30];
    begin
        if not Initialize then
            exit(false);
        if PosFuncProfile."TS Data Entries" then begin
            GetVoucherEntriesUtils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
            GetVoucherEntriesUtils.SendRequest(VoucherNo, 0, ResponseCode, ErrorText, TmpVoucherEntries);
            GetVoucherEntriesUtils.SetCommunicationError(ResponseCode, ErrorText);
            if ErrorText <> '' then
                exit(false);
        end else begin
            ErrorText := StrSubstNo(Text001, 'GetVoucherEntries');
            exit(false);
        end;
        exit(true);
    end;

    internal procedure GetDataEntryBalance(var pDataEntryType: Code[20]; var pDataEntryNo: Code[20]; var TsError: Integer; var pBalance: Decimal; var pExpirationDate: Date; var ErrorText: Text; Pin: Integer): Boolean
    var
        POSDataEntryTemp: Record "LSC POS Data Entry" temporary;
        GetDataEntryBalanceUtils: Codeunit LSCGetDataEntryBalanceUtilsV2;
        POSInfocodeUtils: Codeunit "LSC POS Infocode Utility";
        ResponseCode: Code[30];
        CurrencyFactor: Decimal;
    begin
        if not Initialize then
            exit(false);

        if PosFuncProfile."TS Data Entries" then begin
            GetDataEntryBalanceUtils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
            GetDataEntryBalanceUtils.SendRequest(pDataEntryType, pDataEntryNo, 0, ResponseCode, ErrorText, POSDataEntryTemp);
            GetDataEntryBalanceUtils.SetCommunicationError(ResponseCode, ErrorText);
            pBalance := 0;
            pExpirationDate := 0D;
            if POSDataEntryTemp.FindFirst then begin
                pBalance := POSDataEntryTemp."Data Entry Balance";
                if POSDataEntryTemp."Currency Code" <> '' then
                    CurrencyFactor := POSInfocodeUtils.GetCurrencyFactor(POSDataEntryTemp."Currency Code", '')
                else
                    CurrencyFactor := POSInfocodeUtils.GetCurrencyFactor(POSInfocodeUtils.GetCurrencyDataEntry(POSDataEntryTemp."Created in Store No."), '');
                pBalance := Round(pBalance * CurrencyFactor, PosFuncProfile."Amount Rounding to");
                pExpirationDate := POSDataEntryTemp."Data Entry Expiring Date";
            end;
            if ErrorText <> '' then
                exit(false);
        end;
        exit(true);
    end;

    local procedure WebUpdatePOSAfterStatementCode(var ErrorText: Text): Boolean
    var
        TransactionHeaderTemp: Record "LSC Transaction Header" temporary;
        Trans2: Record "LSC Transaction Header";
        PaymEntry: Record "LSC Trans. Payment Entry";
        IncExpEntry: Record "LSC Trans. Inc./Exp. Entry";
        TendDeclEntry: Record "LSC Trans. Tender Declar. Entr";
        GetTransHeaderListUtils: Codeunit LSCGetTransHeaderListUtils;
        ResponseCode: Code[30];
        FirstTrans: Integer;
        LastTrans: Integer;
    begin
        if (FirstTrans = 0) and (LastTrans = 0) then
            exit(true);

        GetTransHeaderListUtils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
        GetTransHeaderListUtils.SendRequest('By Trans. Range', FirstTrans, LastTrans, '', ResponseCode, ErrorText, TransactionHeaderTemp);
        if ErrorText <> '' then begin
            if PosFuncProfile."Show Web Process Messages" then
                Message(ErrorText);
            exit(false);
        end;

        TransactionHeaderTemp.Reset;
        if TransactionHeaderTemp.FindSet then
            repeat
                if Trans2.Get(TransactionHeaderTemp."Transaction No.") then begin
                    Trans2."Z-Report ID" := TransactionHeaderTemp."Z-Report ID";
                    if not Trans2.Modify(true) then;
                end;
                // Payment Entries
                PaymEntry.SetRange("Transaction No.", TransactionHeaderTemp."Transaction No.");
                if PaymEntry.FindSet then
                    repeat
                        PaymEntry."Z-Report ID" := TransactionHeaderTemp."Z-Report ID";
                        if PaymEntry.Modify(true) then;
                    until PaymEntry.Next = 0;
                // Income Expense Entries
                IncExpEntry.SetRange("Transaction No.", TransactionHeaderTemp."Transaction No.");
                if IncExpEntry.FindSet then
                    repeat
                        IncExpEntry."Z-Report ID" := TransactionHeaderTemp."Z-Report ID";
                        if IncExpEntry.Modify(true) then;
                    until IncExpEntry.Next = 0;
                //Tender Declaration Entries
                TendDeclEntry.SetRange("Transaction No.", TransactionHeaderTemp."Transaction No.");
                if TendDeclEntry.FindSet then
                    repeat
                        TendDeclEntry."Z-Report ID" := TransactionHeaderTemp."Z-Report ID";
                        if TendDeclEntry.Modify(true) then;
                    until TendDeclEntry.Next = 0;
            until TransactionHeaderTemp.Next = 0;
        exit(true);
    end;

    local procedure WebGetTransByStatmentCode(StatementCode: Code[20]; var ErrorText: Text): Boolean
    var
        TransactionHeaderTemp: Record "LSC Transaction Header" temporary;
        TransactionHeaderTemp_r: Record "LSC Transaction Header" temporary;
        TransPaymentEntryTemp_r: Record "LSC Trans. Payment Entry" temporary;
        TransIncomeExpenseEntryTemp_r: Record "LSC Trans. Inc./Exp. Entry" temporary;
        TransTenderDeclarEntryTemp_r: Record "LSC Trans. Tender Declar. Entr" temporary;
        GetTransStatementCodeUtils: Codeunit LSCGetTransStatementCodeUtils;
        GetTransHeaderListUtils: Codeunit LSCGetTransHeaderListUtils;
        ResponseCode: Code[30];
    begin
        GetTransHeaderListUtils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
        GetTransHeaderListUtils.SendRequest('By Statement Code', 0, 0, StatementCode, ResponseCode, ErrorText, TransactionHeaderTemp);
        if ErrorText <> '' then begin
            Message(ErrorText);
            exit(false);
        end;

        TransactionHeaderTemp.Reset;
        if TransactionHeaderTemp.FindSet then
            repeat
                GetTransStatementCodeUtils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
                GetTransStatementCodeUtils.SendRequest(TransactionHeaderTemp."Store No.", TransactionHeaderTemp."POS Terminal No.", TransactionHeaderTemp."Transaction No.",
                  ResponseCode, ErrorText, TransactionHeaderTemp_r, TransPaymentEntryTemp_r, TransIncomeExpenseEntryTemp_r, TransTenderDeclarEntryTemp_r);
                if ErrorText <> '' then begin
                    Message(ErrorText);
                    exit(false);
                end;
            until TransactionHeaderTemp.Next = 0;
        exit(true);
    end;

    procedure SendUnsentTablesDD3(MaxNoOfRecords: Integer; AllTrans: Boolean)
    begin
        SendUnsentTablesExt(MaxNoOfRecords, AllTrans);
    end;

    local procedure UpdateUnsentVoucherEntriesDD3(var pDCUTIL: Codeunit "LSC Data Dir. POS Client Util"; var pRetryAction: Record "LSC Trans. Server Work Table"): Boolean
    var
        VoucherEntries: Record "LSC Voucher Entries";
        IssuedVoucherEntries: Record "LSC Voucher Entries";
        VoucherEntriesTemp: Record "LSC Voucher Entries" temporary;
        SendVoucherEntryUtils: Codeunit LSCSendVoucherEntryUtils;
        ErrorText: Text[1024];
        ResponseCode: Code[30];
        Ok: Boolean;
    begin
        Ok := true;
        VoucherEntries.Reset;
        VoucherEntries.SetRange("Store No.", pRetryAction."Store No.");
        VoucherEntries.SetRange("POS Terminal No.", pRetryAction."POS Terminal No.");
        VoucherEntries.SetRange("Transaction No.", pRetryAction."Transaction No.");
        Evaluate(VoucherEntries."Line No.", pRetryAction.Key1);
        VoucherEntries.SetRange("Line No.", VoucherEntries."Line No.");
        if VoucherEntries.FindFirst then begin
            if GuiAllowed then
                PosCtrl.ScreenDisplay(_SendingTxt1 + ' ' + VoucherEntries.TableCaption);
            if PosFuncProfile."TS Data Entries" then begin
                VoucherEntriesTemp.Init;
                VoucherEntriesTemp := VoucherEntries;
                VoucherEntriesTemp.Insert;
                SendVoucherEntryUtils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
                SendVoucherEntryUtils.SendRequest(ResponseCode, ErrorText, false, false, VoucherEntriesTemp);
                SendVoucherEntryUtils.SetCommunicationError(ResponseCode, ErrorText);
                if ErrorText <> '' then
                    Ok := false
                else
                    Ok := true;

                if Ok and VoucherEntries.Voided then begin
                    IssuedVoucherEntries.Reset;
                    IssuedVoucherEntries.SetCurrentKey("Voucher No.");
                    IssuedVoucherEntries.SetRange("Voucher No.", VoucherEntries."Voucher No.");
                    IssuedVoucherEntries.SetRange("Entry Type", IssuedVoucherEntries."Entry Type"::Issued);
                    if IssuedVoucherEntries.FindFirst then begin
                        SendVoucherEntryUtils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
                        SendVoucherEntryUtils.SendRequest(ResponseCode, ErrorText, false, false, IssuedVoucherEntries);
                        SendVoucherEntryUtils.SetCommunicationError(ResponseCode, ErrorText);
                        Ok := ErrorText = '';
                    end;
                end;
                if not Ok then
                    UpdateTSRetryEntryErrorMessage(pRetryAction, ErrorText);
            end else
                Ok := pDCUTIL.UpdateVoucherEntry(VoucherEntries, true);
        end;
        exit(Ok);
    end;

    local procedure UpdateUnsentWorkShiftEntryDD3(var pDCUTIL: Codeunit "LSC Data Dir. POS Client Util"; var pRetryAction: Record "LSC Trans. Server Work Table"): Boolean
    var
        WorkShiftEntry: Record "LSC Work Shift Entry";
        WorkShiftRBOTemp: Record "LSC Work Shift RBO" temporary;
        WorkShiftEntryTemp: Record "LSC Work Shift Entry" temporary;
        SendWorkShiftUtils: Codeunit LSCSendWorkShiftUtils;
        DateTmp: Date;
        ErrorText: Text;
        ResponseCode: Code[30];
        Ok: Boolean;
    begin
        Ok := true;
        Evaluate(DateTmp, pRetryAction.Key1);
        if WorkShiftEntry.Get(pRetryAction."Store No.", DateTmp, pRetryAction.Key2, pRetryAction.Code1) then begin
            if GuiAllowed then
                PosCtrl.ScreenDisplay(_SendingTxt1 + ' ' + WorkShiftEntry.TableCaption);
            if PosFuncProfile."TS Send Transactions" then begin
                SendWorkShiftUtils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
                WorkShiftEntryTemp.Init;
                WorkShiftEntryTemp := WorkShiftEntry;
                WorkShiftEntryTemp.Insert;
                SendWorkShiftUtils.SendRequest(ResponseCode, ErrorText, false, false, WorkShiftRBOTemp, WorkShiftEntryTemp);
                if ErrorText <> '' then
                    Ok := false
                else
                    Ok := true;
                if not Ok then
                    UpdateTSRetryEntryErrorMessage(pRetryAction, ErrorText);
            end else
                Ok := pDCUTIL.UpdateWorkShiftEntry(WorkShiftEntry, true);
        end;
        exit(Ok);
    end;

    local procedure UpdateUnsentWorkShiftRBODD3(var pDCUTIL: Codeunit "LSC Data Dir. POS Client Util"; var pRetryAction: Record "LSC Trans. Server Work Table"): Boolean
    var
        WorkShiftRBO: Record "LSC Work Shift RBO";
        WorkShiftRBOTemp: Record "LSC Work Shift RBO" temporary;
        WorkShiftEntryTemp: Record "LSC Work Shift Entry" temporary;
        SendWorkShiftUtils: Codeunit LSCSendWorkShiftUtils;
        DateTmp: Date;
        ErrorText: Text;
        ResponseCode: Code[30];
        Ok: Boolean;
    begin
        Ok := true;
        Evaluate(DateTmp, pRetryAction.Key1);
        if WorkShiftRBO.Get(pRetryAction."Store No.", DateTmp, pRetryAction.Key2) then begin
            if GuiAllowed then
                PosCtrl.ScreenDisplay(_SendingTxt1 + ' ' + WorkShiftRBO.TableCaption);
            if PosFuncProfile."TS Send Transactions" then begin
                SendWorkShiftUtils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
                WorkShiftRBOTemp.Init;
                WorkShiftRBOTemp := WorkShiftRBO;
                WorkShiftRBOTemp.Insert;
                SendWorkShiftUtils.SendRequest(ResponseCode, ErrorText, false, false, WorkShiftRBOTemp, WorkShiftEntryTemp);
                if ErrorText <> '' then
                    Ok := false
                else
                    Ok := true;
                if not Ok then
                    UpdateTSRetryEntryErrorMessage(pRetryAction, ErrorText);
            end else
                Ok := pDCUTIL.UpdateWorkShiftRBO(WorkShiftRBO, true);
        end;
        exit(Ok);
    end;

    local procedure UpdUnsendPosStartStatusDD3(pRetryAction: Record "LSC Trans. Server Work Table"): Boolean
    var
        POSStartStatusTemp: Record "LSC POS Start Status" temporary;
        PosStartStat: Record "LSC POS Start Status";
        SendPosStartStatusUtils: Codeunit LSCSendPosStartStatusUtils;
        ErrorText: Text;
        ResponseCode: Code[30];
        Ok: Boolean;
    begin
        PosStartStat."Store No." := BOUtil.SeparateTableKey(1, pRetryAction.Key1);
        Evaluate(PosStartStat.Type, BOUtil.SeparateTableKey(2, pRetryAction.Key1));
        PosStartStat.ID := BOUtil.SeparateTableKey(3, pRetryAction.Key1);
        if PosStartStat.Find then begin
            POSStartStatusTemp.Init;
            POSStartStatusTemp := PosStartStat;
            POSStartStatusTemp.Insert;
            SendPosStartStatusUtils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
            SendPosStartStatusUtils.SendRequest(ResponseCode, ErrorText, false, POSStartStatusTemp);
            Ok := ErrorText = '';
            if not Ok then
                UpdateTSRetryEntryErrorMessage(pRetryAction, ErrorText);
            exit(Ok);
        end;
        exit(false);
    end;

    local procedure UpdateUnsentMemberProcessOrder(var pRetryAction: Record "LSC Trans. Server Work Table"): Boolean
    var
        ProcessOrderEntry_l: Record "LSC Member Process Order Entry";
        ProcessOrderEntryTemp: Record "LSC Member Process Order Entry" temporary;
        SendMemberProcessEntryUtils: Codeunit LSCSendMemberProcessEntrUtils;
        ErrorText: Text;
        ResponseCode: Code[30];
        Ok, IsHandled : Boolean;
    begin
        Ok := true;
        ProcessOrderEntry_l.Reset;
        if ProcessOrderEntry_l.Get(ProcessOrderEntry_l."Document Source"::POS, pRetryAction."Store No.", pRetryAction."POS Terminal No.", pRetryAction."Transaction No.") then begin
            ProcessOrderEntryTemp.Init;
            ProcessOrderEntryTemp := ProcessOrderEntry_l;
            ProcessOrderEntryTemp.Insert;
            if GuiAllowed then
                PosCtrl.ScreenDisplay(_SendingTxt1 + ' ' + ProcessOrderEntry_l.TableCaption);
            OnBeforeSendMemberProcessEntry(PosFuncProfile, ProcessOrderEntryTemp, ResponseCode, ErrorText, IsHandled);
            if not IsHandled then begin
                SendMemberProcessEntryUtils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
                SendMemberProcessEntryUtils.SendRequest(ResponseCode, ErrorText, PosFuncProfile.TransUpdateReplCounter, ProcessOrderEntryTemp);
            end;
            if ErrorText <> '' then begin
                UpdateTSRetryEntryErrorMessage(pRetryAction, ErrorText);
                Ok := false;
            end;
        end else
            Ok := true;

        exit(Ok);
    end;

    local procedure ProcessTransMemberPoints(var pRetryAction: Record "LSC Trans. Server Work Table"): Boolean
    var
        ProcessOrderEntry: Record "LSC Member Process Order Entry";
        ProcessTransMemberPointsUtils: Codeunit LSCProcessTransMemberPtsUtils;
        ErrorText: Text;
        ResponseCode: Code[30];
        Ok: Boolean;
    begin
        Ok := true;

        ProcessOrderEntry.Reset;
        ProcessOrderEntry.SetRange("Store No.", pRetryAction."Store No.");
        ProcessOrderEntry.SetRange("POS Terminal No.", pRetryAction."POS Terminal No.");
        ProcessOrderEntry.SetRange("Transaction No.", pRetryAction."Transaction No.");
        if not ProcessOrderEntry.IsEmpty then
            if PosFuncProfile."TS Send Transactions" then begin
                ProcessTransMemberPointsUtils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
                if GuiAllowed then
                    PosCtrl.ScreenDisplay(_SendingTxt1 + ' ' + ProcessOrderEntry.TableCaption);
                ProcessTransMemberPointsUtils.SendRequest(pRetryAction."Store No.", pRetryAction."POS Terminal No.", pRetryAction."Transaction No.",
                  ResponseCode, ErrorText);
                if ErrorText <> '' then begin
                    Ok := false;
                    UpdateTSRetryEntryErrorMessage(pRetryAction, ErrorText);
                end;
            end else
                Ok := true
        else
            Ok := true;

        exit(Ok);
    end;

    procedure UpdateTSRetryEntryErrorMessage(pRetryEntry: Record "LSC Trans. Server Work Table"; pErrorText: Text[1024])
    begin
        //This function needs to be External for Pharmacy
        UpdateTSWTErrorMessage(pRetryEntry.Table, pRetryEntry.Key1, pRetryEntry.Key2,
          pRetryEntry."Store No.", pRetryEntry."POS Terminal No.", pRetryEntry."Transaction No.", pErrorText);
    end;

    local procedure UpdateTSWTErrorMessage(pTableNo: Integer; pKey1: Text[250]; pKey2: Text[50]; pStoreNo: Code[10]; pPOSTerminalNo: Code[10]; pTransactionNo: Integer; pErrorText: Text[1024])
    var
        RetryEntry: Record "LSC Trans. Server Work Table";
        ErrorMessage: Text[250];
    begin
        if StrLen(pErrorText) > 250 then
            ErrorMessage := CopyStr(pErrorText, 1, 248) + '..'
        else
            ErrorMessage := pErrorText;

        RetryEntry.Reset;
        RetryEntry.SetRange(Table, pTableNo);
        RetryEntry.SetRange(Key1, pKey1);
        RetryEntry.SetRange(Key2, pKey2);
        RetryEntry.SetRange("Store No.", pStoreNo);
        RetryEntry.SetRange("POS Terminal No.", pPOSTerminalNo);
        RetryEntry.SetRange("Transaction No.", pTransactionNo);
        if RetryEntry.FindFirst then
            if ErrorMessage <> RetryEntry."Web Error Message" then begin
                RetryEntry."Web Error Message" := ErrorMessage;
                if WorkTableUpdateTemp_g then
                    SetWorkTableUpdateBuffer(RetryEntry)
                else
                    RetryEntry.Modify;
            end;

        Globals.SetValue("LSC POS Tag"::"TS_ERROR", ErrorMessage);
    end;

    local procedure ProcessCustomerOrder(var pRetryAction: Record "LSC Trans. Server Work Table"): Boolean
    var
        TransSalesEntry: Record "LSC Trans. Sales Entry";
        CnCLineTemp: Record "LSC Customer Order Line" temporary;
        CustomerOrderFinalizeV2Utils: Codeunit LSCCustomerOrdFinalizeV2Utils;
        ErrorText: Text[1024];
        ResponseCode: Code[30];
        DocumentID: Code[20];
        POSTerminalNo: Code[10];
        Ok: Boolean;
    begin
        Ok := true;

        TransSalesEntry.Reset;
        TransSalesEntry.SetRange("Store No.", pRetryAction."Store No.");
        TransSalesEntry.SetRange("POS Terminal No.", pRetryAction."POS Terminal No.");
        TransSalesEntry.SetRange("Transaction No.", pRetryAction."Transaction No.");
        if TransSalesEntry.FindSet then begin
            DocumentID := pRetryAction.Code1;
            POSTerminalNo := pRetryAction."POS Terminal No.";
            repeat
                CnCLineTemp.Init;
                CnCLineTemp."Document ID" := DocumentID;
                CnCLineTemp."Line No." := TransSalesEntry."Line No.";
                CnCLineTemp."Terminal No." := POSTerminalNo;
                CnCLineTemp.Insert;
            until TransSalesEntry.Next = 0;
        end;
        if GuiAllowed then
            PosCtrl.ScreenDisplay(_SendingTxt1 + ' ' + CnCLineTemp.TableCaption);
        CustomerOrderFinalizeV2Utils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
        CustomerOrderFinalizeV2Utils.SendRequest(pRetryAction.Code1, Globals.TerminalNo, pRetryAction."POS Terminal No.", CnCLineTemp, ResponseCode, ErrorText);
        CustomerOrderFinalizeV2Utils.SetCommunicationError(ResponseCode, ErrorText);
        Ok := ResponseCode = '0000';
        if not Ok then
            UpdateTSRetryEntryErrorMessage(pRetryAction, ErrorText);

        exit(Ok);
    end;

    local procedure SendUnsentTablesExt(MaxNoOfRecords: Integer; AllTrans: Boolean)
    var
        WorkTableDeleteTemp: Record "LSC Trans. Server Work Table" temporary;
        WorkTableUpdateTemp: Record "LSC Trans. Server Work Table" temporary;
        WorkTable: Record "LSC Trans. Server Work Table";
        TransHeaderUpdateTemp: Record "LSC Transaction Header" temporary;
        TransHeader: Record "LSC Transaction Header";
    begin
        Initialize;
        WorkTableUpdateTemp_g := true;
        OpenWorkTableBuffer(WorkTableDeleteTemp, 1);
        OpenWorkTableBuffer(WorkTableUpdateTemp, 2);
        OpenWorkTableBuffer(WorkTableUpdateTemp, 3);
        OpenTransHeaderBuffer(TransHeaderUpdateTemp, 1);

        SendUnsentTablesExtPh2(MaxNoOfRecords, AllTrans);

        WorkTableDeleteTemp.Reset;
        SetFilterWorkTableBuffer(WorkTableDeleteTemp, 1);
        if FindSetWorkTableBuffer(WorkTableDeleteTemp, 1) then
            repeat
                if WorkTable.Get(WorkTableDeleteTemp.Table, WorkTableDeleteTemp.Key1, WorkTableDeleteTemp.Key2,
                   WorkTableDeleteTemp."Store No.", WorkTableDeleteTemp."POS Terminal No.", WorkTableDeleteTemp."Transaction No.")
                then
                    WorkTable.Delete;
            until NextWorkTableBuffer(1, WorkTableDeleteTemp, 1) = 0;

        WorkTableUpdateTemp.Reset;
        SetFilterWorkTableBuffer(WorkTableUpdateTemp, 2);
        if FindSetWorkTableBuffer(WorkTableUpdateTemp, 2) then
            repeat
                if WorkTable.Get(WorkTableUpdateTemp.Table, WorkTableUpdateTemp.Key1, WorkTableUpdateTemp.Key2,
                   WorkTableUpdateTemp."Store No.", WorkTableUpdateTemp."POS Terminal No.", WorkTableUpdateTemp."Transaction No.")
                then begin
                    WorkTable."Web Error Message" := WorkTableUpdateTemp."Web Error Message";
                    WorkTable.Modify;
                end;
            until NextWorkTableBuffer(1, WorkTableUpdateTemp, 2) = 0;

        WorkTableUpdateTemp.Reset;
        SetFilterWorkTableBuffer(WorkTableUpdateTemp, 3);
        if FindSetWorkTableBuffer(WorkTableUpdateTemp, 3) then
            repeat
                if WorkTable.Get(WorkTableUpdateTemp.Table, WorkTableUpdateTemp.Key1, WorkTableUpdateTemp.Key2,
                   WorkTableUpdateTemp."Store No.", WorkTableUpdateTemp."POS Terminal No.", WorkTableUpdateTemp."Transaction No.")
                then begin
                    WorkTable.TransferFields(WorkTableUpdateTemp, false);
                    WorkTable.Modify;
                end else begin
                    WorkTable.Init;
                    WorkTable := WorkTableUpdateTemp;
                    WorkTable.Insert
                end;
            until NextWorkTableBuffer(1, WorkTableUpdateTemp, 3) = 0;

        TransHeaderUpdateTemp.Reset;
        SetFilterTransHeaderBuffer(TransHeaderUpdateTemp, 1);
        if FindSetTransHeaderBuffer(TransHeaderUpdateTemp, 1) then
            repeat
                if TransHeader.Get(TransHeaderUpdateTemp."Store No.", TransHeaderUpdateTemp."POS Terminal No.", TransHeaderUpdateTemp."Transaction No.") then begin
                    TransHeader.Replicated := true;
                    TransHeader.Modify(true);
                end;
            until NextTransHeaderBuffer(1, TransHeaderUpdateTemp, 1) = 0;

        CloseWorkTableBuffer(WorkTableDeleteTemp, 1);
        CloseWorkTableBuffer(WorkTableUpdateTemp, 2);
        CloseWorkTableBuffer(WorkTableUpdateTemp, 3);
        CloseTransHeaderBuffer(TransHeaderUpdateTemp, 1);
        WorkTableUpdateTemp_g := false;
    end;

    local procedure SendUnsentTablesExtPh2(MaxNoOfRecords: Integer; AllTrans: Boolean)
    var
        Trans: Record "LSC Transaction Header";
        DataEntry: Record "LSC POS Data Entry";
        POSTrans: Record "LSC POS Transaction";
        Staff: Record "LSC Staff";
        StaffTemp: Record "LSC Staff" temporary;
        TransServerWorkTable: Record "LSC Trans. Server Work Table";
        RetryAction: Record "lsc trans. server work table";
        RetryActionGet: Record "LSC Trans. Server Work Table";
        tmpDataEntry: Record "LSC POS Data Entry" temporary;
        TransactionHeaderOnlyTemp: Record "LSC Transaction Header" temporary;
        DeletePOSTransBackupUtils: Codeunit LSCDeletePOSTransBackupUtils;
        LocalDC3Util1: Codeunit "LSC Data Dir. POS Client Util";
        LocalDC3Util2: Codeunit "LSC Data Dir. POS Client Util";
        GetDataEntryUtils: Codeunit LSCGetDataEntryUtils;
        SendStaffUtils: Codeunit LSCSendStaffUtils;
        SendDataEntryUtils: Codeunit LSCSendDataEntryUtils;
        TimeNow: Time;
        TimeLastSend: Time;
        ErrorText: Text[1024];
        TimeLastSendText: Text[30];
        ResponseCode: Code[30];
        counter: Integer;
        ok: Boolean;
        SendOk: Boolean;
        _DeleteTxt1: Label 'Deleting';
    begin
        RetryAction.SetRange("Created by Store No.", Globals.StoreNo);
        RetryAction.SetRange("Created by POS Terminal No.", Globals.TerminalNo);
        RetryAction.SetRange(Table, Database::"LSC Member Process Order Entry");
        if RetryAction.FindSet then
            repeat
                ok := UpdateUnsentMemberProcessOrder(RetryAction);
                if ok and not PosFuncProfile."Send Process Web Request" then
                    SetWorkTableDeleteBuffer(RetryAction);
            until not ok or (RetryAction.Next = 0);
        RetryAction.SetRange(Table, Database::"LSC Customer Order Header");
        if RetryAction.FindSet then
            repeat
                ok := ProcessCustomerOrder(RetryAction);
                if ok then begin
                    SetWorkTableDeleteBuffer(RetryAction);
                end;
            until not ok or (RetryAction.Next = 0);

        if not Initialize then begin
            if GuiAllowed then
                PosCtrl.ScreenDisplay('');
            exit;
        end;

        OnBeforesendUnsentTables;

        LocalDC3Util1.Initialize(PosFuncProfile."Profile ID");

        ok := true;
        SendOk := true;
        Globals.SetValue("LSC POS Tag"::"TS_ERROR", '');

        RetryAction.SetRange("Created by Store No.", Globals.StoreNo);
        RetryAction.SetRange("Created by POS Terminal No.", Globals.TerminalNo);
        RetryAction.SetRange(Table, Database::"LSC Transaction Header");
        RetryAction.SetRange(Int1, TSAction_g::Update);
        //RetryAction.SetRange(Int2, 0);
        RetryAction.SetFilter(Int2, '%1|%2|%3', 0, 2, 3);

        if PosFuncProfile."DD Send Transaction" then begin
            if (not AllTrans) then begin
                SendOk := (PosFuncProfile."DD Packet size (Trans.)" = 0) and (PosFuncProfile."DD Time Between Send (min)" = 0);
                if not SendOk then begin
                    if (PosFuncProfile."DD Packet size (Trans.)" <> 0) then begin
                        counter := RetryAction.Count;
                        if (counter >= PosFuncProfile."DD Packet size (Trans.)") then
                            SendOk := true;
                    end;
                end;

                if not SendOk then begin
                    if (PosFuncProfile."DD Time Between Send (min)" <> 0) then begin
                        TimeLastSendText := Globals.GetValue("LSC POS Tag"::"TIME_LAST_SEND");
                        if (TimeLastSendText <> '') then begin
                            if not Evaluate(TimeLastSend, TimeLastSendText) then
                                TimeLastSend := 010000T;
                        end
                        else
                            TimeLastSend := 010000T;

                        TimeNow := Time;
                        if ((TimeNow - TimeLastSend) / 60000 > PosFuncProfile."DD Time Between Send (min)") then
                            SendOk := true;
                    end;
                end;
            end;
        end;

        counter := 0;
        if SendOk then begin
            if RetryAction.FindSet then begin
                if (PosFuncProfile."DD Time Between Send (min)" <> 0) then begin
                    TimeLastSendText := Format(TimeNow);
                    Globals.SetValue("LSC POS Tag"::"TIME_LAST_SEND", TimeLastSendText);
                end;

                counter := 0;
                LocalDC3Util1.Initialize(PosFuncProfile."Profile ID");
                TransactionHeaderTemp_g.DeleteAll;
                TransactionHeaderOnlyTemp.DeleteAll;
                repeat
                    Evaluate(TransactionHeaderTemp_g."Transaction No.", RetryAction.Key1);
                    TransactionHeaderTemp_g."Store No." := RetryAction."Store No.";
                    TransactionHeaderTemp_g."POS Terminal No." := RetryAction."POS Terminal No.";
                    if not Trans.Get(TransactionHeaderTemp_g."Store No.", TransactionHeaderTemp_g."POS Terminal No.",
                      TransactionHeaderTemp_g."Transaction No.")
                    then
                        SetWorkTableDeleteBuffer(RetryAction)
                    else
                        IF RetryAction.Int2 >= 2 then begin
                            TransactionHeaderOnlyTemp := TransactionHeaderTemp_g;
                            TransactionHeaderOnlyTemp.Counter := RetryAction.Int2;
                            if TransactionHeaderOnlyTemp.Insert() then;
                        end else
                            if TransactionHeaderTemp_g.Insert then;
                    counter += 1;
                until (RetryAction.Next = 0) or (counter = MaxNoOfRecords);

                ok := SendWholeTmpTransaction();
                if ok and TransactionHeaderTemp_g.FindSet then begin
                    repeat
                        TransServerWorkTable.Get(Database::"LSC Transaction Header", Format(TransactionHeaderTemp_g."Transaction No."), '',
                            TransactionHeaderTemp_g."Store No.", TransactionHeaderTemp_g."POS Terminal No.", TransactionHeaderTemp_g."Transaction No.");
                        SetWorkTableDeleteBuffer(TransServerWorkTable);
                        if Trans.Get(TransactionHeaderTemp_g."Store No.", TransactionHeaderTemp_g."POS Terminal No.", TransactionHeaderTemp_g."Transaction No.") then begin
                            UpdateTransHeaderBuffer(Trans, 1);
                        end;
                    until TransactionHeaderTemp_g.Next = 0;
                end else
                    counter := 0;

                IF ok then begin
                    IF TransactionHeaderOnlyTemp.FindSet() then
                        repeat
                            if Trans.Get(TransactionHeaderOnlyTemp."Store No.", TransactionHeaderOnlyTemp."POS Terminal No.", TransactionHeaderOnlyTemp."Transaction No.") then begin
                                if TransactionHeaderOnlyTemp.Counter = 3 then
                                    ok := SendTransaction(Trans, true)
                                else
                                    ok := SendTransaction(Trans, false);
                            end;
                        until (TransactionHeaderOnlyTemp.Next() = 0) or (not ok);
                    if ok then begin
                        IF TransactionHeaderOnlyTemp.FindSet then
                            repeat
                                TransServerWorkTable.Get(Database::"LSC Transaction Header", Format(TransactionHeaderOnlyTemp."Transaction No."), '',
                                    TransactionHeaderOnlyTemp."Store No.", TransactionHeaderOnlyTemp."POS Terminal No.", TransactionHeaderOnlyTemp."Transaction No.");
                                SetWorkTableDeleteBuffer(TransServerWorkTable);
                            until TransactionHeaderOnlyTemp.Next() = 0;
                    end else
                        counter := counter - TransactionHeaderOnlyTemp.Count;
                end;
            end;
        end;

        if PosFuncProfile."DD Send Transaction" then begin
            RetryAction.SetRange("Created by Store No.");
            RetryAction.SetRange("Created by POS Terminal No.");
        end;

        //This is updating the z-report id of transactions after report has been made.
        //As the Z-reporting is itself a batch work taking some time
        //the system overlooks the max record to send here and updates all the z-report transactions to remote db
        if ok and ((counter <> MaxNoOfRecords) or (MaxNoOfRecords = 0)) then begin
            RetryAction.SetRange(Int2, 1);
            if RetryAction.FindSet then
                repeat
                    if ok then
                        ok := UpdateStatementTransactions(RetryAction.Key1, RetryAction.Key2);
                until RetryAction.Next = 0;

            if ok then begin
                if RetryAction.FindSet then
                    repeat
                        SetWorkTableDeleteBuffer(RetryAction);
                    until RetryAction.Next = 0;
            end else
                exit;
        end;

        //Now we look for other tables needed to be update from the TS work table
        RetryAction.SetFilter(Table, '<>%1', Database::"LSC Transaction Header");
        RetryAction.SetRange(Int1);
        RetryAction.SetRange(Int2);
        if RetryAction.FindSet and ((counter <> MaxNoOfRecords) or (MaxNoOfRecords = 0)) then begin
            LocalDC3Util2.Initialize(PosFuncProfile."Profile ID");
            repeat
                //Skip records already in the delete buffer
                RetryActionGet := RetryAction;
                if GetWorkTableBuffer(RetryActionGet, 1) then
                    RetryAction.Int1 := 0;
                if RetryAction.Int1 <> 0 then begin
                    ok := false;
                    case RetryAction.Table of
                        Database::"LSC POS Data Entry":
                            begin
                                ok := true;
                                DataEntry."Entry Type" := BOUtil.SeparateTableKey(1, RetryAction.Key1);
                                DataEntry."Entry Code" := BOUtil.SeparateTableKey(2, RetryAction.Key1);
                                if DataEntry.Find then begin
                                    if GuiAllowed then
                                        PosCtrl.ScreenDisplay(_SendingTxt1 + ' ' + DataEntry.TableCaption);
                                    if (DataEntry.Amount = 0) then
                                        if PosFuncProfile."TS Data Entries" then begin
                                            GetDataEntryUtils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
                                            GetDataEntryUtils.SendRequest(DataEntry."Entry Type", DataEntry."Entry Code", tmpDataEntry, ResponseCode, ErrorText);
                                            if (ErrorText <> '') then
                                                UpdateTSRetryEntryErrorMessage(RetryAction, ErrorText)
                                            else begin
                                                if tmpDataEntry.FindFirst then begin
                                                    DataEntry.Amount := tmpDataEntry.Amount;
                                                    DataEntry."Created by Receipt No." := tmpDataEntry."Created by Receipt No.";
                                                    DataEntry."Created by Line No." := tmpDataEntry."Created by Line No.";
                                                    OnBeforeModifyDataEntry(DataEntry);
                                                end;
                                            end;
                                        end;
                                    if DataEntry.Unposted then
                                        DataEntry.Unposted := false;

                                    if PosFuncProfile."TS Data Entries" then begin
                                        ok := SendDataEntries(DataEntry, RetryAction, ErrorText, SendDataEntryUtils);

                                        if not ok then
                                            UpdateTSRetryEntryErrorMessage(RetryAction, ErrorText);
                                    end else
                                        ok := LocalDC3Util2.UpdateDataEntry(DataEntry, true);
                                end;
                            end;
                        Database::"LSC POS Transaction":
                            begin
                                ok := true;
                                if RetryAction.Int1 = TSAction_g::Delete then begin
                                    if GuiAllowed then
                                        PosCtrl.ScreenDisplay(_DeleteTxt1 + ' ' + POSTrans.TableCaption);
                                    DeletePOSTransBackupUtils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
                                    DeletePOSTransBackupUtils.SendRequest(RetryAction.Key1, ResponseCode, ErrorText);
                                    if ErrorText <> '' then
                                        UpdateTSRetryEntryErrorMessage(RetryAction, ErrorText);
                                end else begin
                                    if POSTrans.Get(RetryAction.Key1) then begin
                                        if GuiAllowed then
                                            PosCtrl.ScreenDisplay(_SendingTxt1 + ' ' + POSTrans.TableCaption);
                                        ok := SendPOSTrans(POSTrans, RetryAction.Code1, RetryAction."Web Request ID");
                                    end;
                                end;
                            end;
                        Database::"LSC Staff":
                            begin
                                ok := true;
                                Staff.Get(RetryAction.Key1);
                                if PosFuncProfile."TS Staff" then begin
                                    StaffTemp.Init;
                                    StaffTemp := Staff;
                                    StaffTemp.Insert;
                                    SendStaffUtils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
                                    SendStaffUtils.SendRequest(ResponseCode, ErrorText, false, StaffTemp);
                                    ok := ErrorText = '';
                                    if not ok then
                                        UpdateTSRetryEntryErrorMessage(RetryAction, ErrorText);
                                end;
                            end;
                        Database::"LSC Voucher Entries":
                            ok := UpdateUnsentVoucherEntriesDD3(LocalDC3Util2, RetryAction);
                        Database::"LSC POS Start Status":
                            ok := UpdUnsendPosStartStatusDD3(RetryAction);
                        Database::"LSC Work Shift Entry":
                            ok := UpdateUnsentWorkShiftEntryDD3(LocalDC3Util2, RetryAction);
                        Database::"LSC Work Shift RBO":
                            ok := UpdateUnsentWorkShiftRBODD3(LocalDC3Util2, RetryAction);
                        Database::"LSC Member Process Order Entry":
                            ok := ProcessTransMemberPoints(RetryAction);
                    end;
                    OnAfterProcessRetryAction(RetryAction, ok);
                    if ok then
                        SetWorkTableDeleteBuffer(RetryAction);
                    counter := counter + 1;
                end;
            until not ok or (RetryAction.Next = 0) or (counter = MaxNoOfRecords);
        end;

        if GuiAllowed then
            PosCtrl.ScreenDisplay('');
    end;

    internal procedure SendDataEntries(DataEntry: Record "LSC POS Data Entry"; RetryAction: Record "LSC Trans. Server Work Table"; var ErrorText: Text; SendDataEntryUtils: interface "LSC ISendDataEntryUtils"): Boolean
    var
        POSDataEntryTemp: Record "LSC POS Data Entry" temporary;
        ResponseCode: Code[30];
    begin
        POSDataEntryTemp := DataEntry;
        POSDataEntryTemp.Insert();

        SendDataEntryUtils.SetPosFunctionalityProfile(PosFuncProfile."Profile ID");
        SendDataEntryUtils.SendRequest(ResponseCode, ErrorText, false, false, POSDataEntryTemp);
        SendDataEntryUtils.SetCommunicationError(ResponseCode, ErrorText);

        exit(ErrorText = '');
    end;

    local procedure SetWorkTableDeleteBuffer(var WorkTable_p: Record "LSC Trans. Server Work Table" temporary)
    begin
        UpdateWorkTableBuffer(WorkTable_p, 1);
    end;

    local procedure SetWorkTableUpdateBuffer(var WorkTable_p: Record "LSC Trans. Server Work Table" temporary)
    begin
        UpdateWorkTableBuffer(WorkTable_p, 2);
    end;

    local procedure SetWorkTableInsertBuffer(var WorkTable_p: Record "LSC Trans. Server Work Table" temporary)
    begin
        UpdateWorkTableBuffer(WorkTable_p, 3);
    end;

    local procedure OpenWorkTableBuffer(var WorkTable_p: Record "LSC Trans. Server Work Table" temporary; Instance_p: Integer)
    var
        RecRef: RecordRef;
    begin
        RecRef.GetTable(WorkTable_p);
        if BufferUtility.IsBufferOpen(RecRef, Instance_p) then
            BufferUtility.CloseBuffer(RecRef, Instance_p);
        BufferUtility.OpenBuffer(RecRef, Instance_p);
    end;

    local procedure CloseWorkTableBuffer(var WorkTable_p: Record "LSC Trans. Server Work Table" temporary; Instance_p: Integer)
    var
        RecRef: RecordRef;
    begin
        RecRef.GetTable(WorkTable_p);
        if BufferUtility.IsBufferOpen(RecRef, Instance_p) then
            BufferUtility.CloseBuffer(RecRef, Instance_p);
    end;

    local procedure GetWorkTableBuffer(var WorkTable_p: Record "LSC Trans. Server Work Table" temporary; Instance_p: Integer): Boolean
    var
        RecRef: RecordRef;
    begin
        RecRef.GetTable(WorkTable_p);
        if BufferUtility.GetRec(RecRef, Instance_p) then begin
            RecRef.SetTable(WorkTable_p);
            exit(true);
        end else begin
            Clear(WorkTable_p);
            exit(false);
        end;
    end;

    local procedure SetFilterWorkTableBuffer(var WorkTable_p: Record "LSC Trans. Server Work Table" temporary; Instance_p: Integer)
    var
        RecRef: RecordRef;
    begin
        RecRef.GetTable(WorkTable_p);
        BufferUtility.SetTableFilter(1, RecRef, Instance_p);
    end;

    local procedure FindSetWorkTableBuffer(var WorkTable_p: Record "LSC Trans. Server Work Table" temporary; Instance_p: Integer): Boolean
    var
        RecRef: RecordRef;
    begin
        RecRef.GetTable(WorkTable_p);
        if BufferUtility.FindSetRec(1, RecRef, Instance_p) then begin
            RecRef.SetTable(WorkTable_p);
            exit(true);
        end else begin
            Clear(WorkTable_p);
            exit(false);
        end;
    end;

    local procedure NextWorkTableBuffer(Steps_p: Integer; var WorkTable_p: Record "LSC Trans. Server Work Table" temporary; Instance_p: Integer): Integer
    var
        RecRef: RecordRef;
        Steps: Integer;
    begin
        RecRef.GetTable(WorkTable_p);
        Steps := BufferUtility.NextRec(1, Steps_p, RecRef, Instance_p);
        if Steps <> 0 then
            RecRef.SetTable(WorkTable_p);
        exit(Steps);
    end;

    local procedure UpdateWorkTableBuffer(var WorkTable_p: Record "LSC Trans. Server Work Table" temporary; Instance_p: Integer)
    var
        RecRef: RecordRef;
    begin
        RecRef.GetTable(WorkTable_p);
        BufferUtility.UpdateRec(RecRef, Instance_p);
    end;

    local procedure OpenTransHeaderBuffer(var TransHeader_p: Record "LSC Transaction Header" temporary; Instance_p: Integer)
    var
        RecRef: RecordRef;
    begin
        RecRef.GetTable(TransHeader_p);
        if BufferUtility.IsBufferOpen(RecRef, Instance_p) then
            BufferUtility.CloseBuffer(RecRef, 1);
        BufferUtility.OpenBuffer(RecRef, Instance_p);
    end;

    local procedure CloseTransHeaderBuffer(var TransHeader_p: Record "LSC Transaction Header" temporary; Instance_p: Integer)
    var
        RecRef: RecordRef;
    begin
        RecRef.GetTable(TransHeader_p);
        if BufferUtility.IsBufferOpen(RecRef, Instance_p) then
            BufferUtility.CloseBuffer(RecRef, 1);
    end;

    local procedure SetFilterTransHeaderBuffer(var TransHeader_p: Record "LSC Transaction Header" temporary; Instance_p: Integer)
    var
        RecRef: RecordRef;
    begin
        RecRef.GetTable(TransHeader_p);
        BufferUtility.SetTableFilter(1, RecRef, Instance_p);
    end;

    local procedure FindSetTransHeaderBuffer(var TransHeader_p: Record "LSC Transaction Header" temporary; Instance_p: Integer): Boolean
    var
        RecRef: RecordRef;
    begin
        RecRef.GetTable(TransHeader_p);
        if BufferUtility.FindSetRec(1, RecRef, Instance_p) then begin
            RecRef.SetTable(TransHeader_p);
            exit(true);
        end else begin
            Clear(TransHeader_p);
            exit(false);
        end;
    end;

    local procedure NextTransHeaderBuffer(Steps_p: Integer; var TransHeader_p: Record "LSC Transaction Header" temporary; Instance_p: Integer): Integer
    var
        RecRef: RecordRef;
        Steps: Integer;
    begin
        RecRef.GetTable(TransHeader_p);
        Steps := BufferUtility.NextRec(1, Steps_p, RecRef, Instance_p);
        if Steps <> 0 then
            RecRef.SetTable(TransHeader_p);
        exit(Steps);
    end;

    local procedure UpdateTransHeaderBuffer(var TransHeader_p: Record "LSC Transaction Header" temporary; Instance_p: Integer)
    var
        RecRef: RecordRef;
    begin
        RecRef.GetTable(TransHeader_p);
        BufferUtility.UpdateRec(RecRef, Instance_p);
    end;

    internal procedure CustomerOrderOldTransactionExists(TransactionHeader: Record "LSC Transaction Header"): Boolean
    var
        OldTransactionHeader: Record "LSC Transaction Header";
    begin
        if TransactionHeader."Customer Order ID" = '' then
            exit(false);
        OldTransactionHeader.SetRange("Customer Order ID", TransactionHeader."Customer Order ID");
        if OldTransactionHeader.FindSet then
            repeat
                if OldTransactionHeader."Receipt No." <> TransactionHeader."Receipt No." then
                    exit(true);
            until OldTransactionHeader.Next = 0;
        exit(false);
    end;

    internal procedure TrainingTransHasEntries(TransHeader: Record "LSC Transaction Header"): Boolean
    var
        TransSalesEntry: Record "LSC Trans. Sales Entry";
        TransInfocodeEntry: Record "LSC Trans. Infocode Entry";
        TransHospitalityEntry: Record "LSC Trans. Hospitality Entry";
        TransDiscountEntry: Record "LSC Trans. Discount Entry";
        TransIncomeExpenseEntry: Record "LSC Trans. Inc./Exp. Entry";
        TransPmtEntry: Record "LSC Trans. Payment Entry";
        TransMixMatchEntry: Record "LSC Trans. Mix & Match Entry";
        TransTenderDeclarEntry: Record "LSC Trans. Tender Declar. Entr";
        TransCouponEntry: Record "LSC Trans. Coupon Entry";
        TransInvEntry: Record "LSC Trans. Inventory Entry";
        TransactionStatus: Record "LSC Transaction Status";
        TransSalesEntryStatus: Record "LSC Trans. Sales Entry Status";
        TransCashDeclaration: Record "LSC Trans. Cash Declaration";
        TransSafeEntry: Record "LSC Trans. Safe Entry";
        TransOrderHeader: Record "LSC Transaction Order Header";
    begin
        TransSalesEntry.SetRange("Store No.", TransHeader."Store No.");
        TransSalesEntry.SetRange("POS Terminal No.", TransHeader."POS Terminal No.");
        TransSalesEntry.SetRange("Transaction No.", TransHeader."Transaction No.");
        if not TransSalesEntry.IsEmpty then
            exit(true);

        TransInfocodeEntry.SetRange("Store No.", TransHeader."Store No.");
        TransInfocodeEntry.SetRange("POS Terminal No.", TransHeader."POS Terminal No.");
        TransInfocodeEntry.SetRange("Transaction No.", TransHeader."Transaction No.");
        if not TransInfocodeEntry.IsEmpty then
            exit(true);

        TransPmtEntry.SetRange("Store No.", TransHeader."Store No.");
        TransPmtEntry.SetRange("POS Terminal No.", TransHeader."POS Terminal No.");
        TransPmtEntry.SetRange("Transaction No.", TransHeader."Transaction No.");
        if not TransPmtEntry.IsEmpty then
            exit(true);

        TransIncomeExpenseEntry.SetRange("Store No.", TransHeader."Store No.");
        TransIncomeExpenseEntry.SetRange("POS Terminal No.", TransHeader."POS Terminal No.");
        TransIncomeExpenseEntry.SetRange("Transaction No.", TransHeader."Transaction No.");
        if not TransIncomeExpenseEntry.IsEmpty then
            exit(true);

        TransMixMatchEntry.SetRange("Store No.", TransHeader."Store No.");
        TransMixMatchEntry.SetRange("POS Terminal No.", TransHeader."POS Terminal No.");
        TransMixMatchEntry.SetRange("Transaction No.", TransHeader."Transaction No.");
        if not TransMixMatchEntry.IsEmpty then
            exit(true);

        TransTenderDeclarEntry.SetRange("Store No.", TransHeader."Store No.");
        TransTenderDeclarEntry.SetRange("POS Terminal No.", TransHeader."POS Terminal No.");
        TransTenderDeclarEntry.SetRange("Transaction No.", TransHeader."Transaction No.");
        if not TransTenderDeclarEntry.IsEmpty then
            exit(true);

        TransCouponEntry.SetRange("Store No.", TransHeader."Store No.");
        TransCouponEntry.SetRange("POS Terminal No.", TransHeader."POS Terminal No.");
        TransCouponEntry.SetRange("Transaction No.", TransHeader."Transaction No.");
        if not TransCouponEntry.IsEmpty then
            exit(true);

        TransInvEntry.SetRange("Store No.", TransHeader."Store No.");
        TransInvEntry.SetRange("POS Terminal No.", TransHeader."POS Terminal No.");
        TransInvEntry.SetRange("Transaction No.", TransHeader."Transaction No.");
        if not TransInvEntry.IsEmpty then
            exit(true);

        TransactionStatus.SetRange("Store No.", TransHeader."Store No.");
        TransactionStatus.SetRange("POS Terminal No.", TransHeader."POS Terminal No.");
        TransactionStatus.SetRange("Transaction No.", TransHeader."Transaction No.");
        if not TransactionStatus.IsEmpty then
            exit(true);

        TransSalesEntryStatus.SetRange("Store No.", TransHeader."Store No.");
        TransSalesEntryStatus.SetRange("POS Terminal No.", TransHeader."POS Terminal No.");
        TransSalesEntryStatus.SetRange("Transaction No.", TransHeader."Transaction No.");
        if not TransSalesEntryStatus.IsEmpty then
            exit(true);

        TransCashDeclaration.SetRange("Store No.", TransHeader."Store No.");
        TransCashDeclaration.SetRange("POS Terminal No.", TransHeader."POS Terminal No.");
        TransCashDeclaration.SetRange("Transaction No.", TransHeader."Transaction No.");
        if not TransCashDeclaration.IsEmpty then
            exit(true);

        TransSafeEntry.SetRange("Store No.", TransHeader."Store No.");
        TransSafeEntry.SetRange("POS Terminal No.", TransHeader."POS Terminal No.");
        TransSafeEntry.SetRange("Transaction No.", TransHeader."Transaction No.");
        if not TransSafeEntry.IsEmpty then
            exit(true);

        TransOrderHeader.SetRange("Store No.", TransHeader."Store No.");
        TransOrderHeader.SetRange("POS Terminal No.", TransHeader."POS Terminal No.");
        TransOrderHeader.SetRange("Transaction No.", TransHeader."Transaction No.");
        if not TransOrderHeader.IsEmpty then
            exit(true);

        TransHospitalityEntry.SetRange("Store No.", TransHeader."Store No.");
        TransHospitalityEntry.SetRange("POS Terminal No.", TransHeader."POS Terminal No.");
        TransHospitalityEntry.SetRange("Transaction No.", TransHeader."Transaction No.");
        if not TransHospitalityEntry.IsEmpty then
            exit(true);

        TransDiscountEntry.SetRange("Store No.", TransHeader."Store No.");
        TransDiscountEntry.SetRange("POS Terminal No.", TransHeader."POS Terminal No.");
        TransDiscountEntry.SetRange("Transaction No.", TransHeader."Transaction No.");
        if not TransDiscountEntry.IsEmpty() then
            exit(true);
        exit(false);
    end;

    internal procedure CreateTransHederOnlyRetryEntry(var Trans: Record "LSC Transaction Header"; VoidTrans: Boolean)
    var
        RetryEntry: Record "LSC Trans. Server Work Table";
        Ext: Integer;
        CreateEntry: boolean;
    begin
        IF VoidTrans then
            Ext := 3
        else
            Ext := 2;
        CreateEntry := false;
        if RetryEntry.Get(Database::"LSC Transaction Header", Format(Trans."Transaction No."), '', Trans."Store No.", Trans."POS Terminal No.", Trans."Transaction No.") then begin
            IF (RetryEntry.Int2 = 2) or (RetryEntry.Int2 = 3) then
                CreateEntry := true;
        end else
            CreateEntry := true;
        IF CreateEntry then
            CreateTSRetryEntry(Database::"LSC Transaction Header", Format(Trans."Transaction No."), '', '', TSAction_g::Update, Ext, false, Trans."Store No.", Trans."POS Terminal No.", Trans."Transaction No.", '');
    end;

    [IntegrationEvent(false, false)]
    internal procedure OnAfterSendWholeTmpTransaction(var TransactionHeaderTemp: Record "LSC Transaction Header" temporary; var DCUTIL3: Codeunit "LSC Data Dir. POS Client Util")
    begin
    end;

    [IntegrationEvent(false, false)]
    internal procedure OnBeforePOSTransServerUtilSendTransaction(var POSFuncProfile: Record "LSC POS Func. Profile")
    begin
    end;

    [IntegrationEvent(false, false)]
    internal procedure OnAfterPOSTransServerUtilSendTransaction(var POSFuncProfile: Record "LSC POS Func. Profile")
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeSendUnsentTables()
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeSendAtEndOfTransaction(var Trans: Record "LSC Transaction Header"; var IsHandled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforePosDataEntryInsert(var DataEntry: Record "LSC POS Data Entry"; var ErrorText: Text; var IsHandled: Boolean; var ReturnValue: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnAfterProcessRetryAction(var RetryAction_p: Record "LSC Trans. Server Work Table"; var Ok_p: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeGetPostedTransaction(ReceiptNo: Code[20]; pStoreNo: Code[10]; pTerminalNo: Code[10]; pTransNo: Integer; var ResponseCode: Code[30]; var ErrorText: Text; var IsHandled: Boolean; var RetVal: Boolean)
    begin
    end;

    [IntegrationEvent(true, false)]
    local procedure OnBeforeSendWholeTmpTransaction(var TransactionHeaderTemp_g: Record "LSC Transaction Header" temporary; var DCUTIL3: Codeunit "LSC Data Dir. POS Client Util"; var IsHandled: Boolean; var RetVal: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeSendStaffUpdate(POSFuncProfileID: Code[10]; var ResponseCode: Code[30]; var ErrorText: Text; var StaffTemp: Record "LSC Staff" temporary; var IsHandled: Boolean)
    begin
    end;

    [Obsolete('Not used anymore - Use OnBeforeGetDataEntry2', '27.0')]
    [IntegrationEvent(false, false)]
    internal procedure OnBeforeGetDataEntry(Type: Code[10]; "Code": Code[20]; var DataEntry: Record "LSC POS Data Entry"; var ErrorText: Text; var IsHandled: Boolean; var OK: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    internal procedure OnBeforeGetDataEntry2(Type: Code[10]; var InputCode: Code[20]; var DataEntry: Record "LSC POS Data Entry"; var ErrorText: Text; var IsHandled: Boolean; var OK: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    internal procedure OnBeforeGetInventoryLookup(ItemNo: Code[20]; Variant: Code[20]; StoreNo: Code[10]; LocationProfile: Code[30]; var InventoryLookupTableTemp: Record "LSC Inventory Lookup Table" temporary; var ResponseCode: Code[30]; var ErrorText: Text; var ReturnValue: Boolean; var IsHandled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    internal procedure OnBeforeSendPOSTransSusp(POSFuncProfileID: Code[10]; var ResponseCode: Code[30]; var ErrorText: Text; AddOnly: Boolean; var POSTransactionTemp: Record "LSC POS Transaction" temporary; var IsHandled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    internal procedure OnBeforeModifyDataEntry(var DataEntry: Record "LSC POS Data Entry")
    begin
    end;

    [IntegrationEvent(false, false)]
    internal procedure OnAfterModifyOrInsertInvLookupTable(var InvLookupTable: Record "LSC Inventory Lookup Table"; ValidItemsTemp: Record "LSC Inventory Lookup Table" temporary; Store: Record "LSC Store"; StoreList: Query "LSC Store List"; ModifyExisting: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    internal procedure OnBeforeInsertToValidItemsTEMP(var ValidItemsTEMP: Record "LSC Inventory Lookup Table" temporary; var IsHandled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    internal procedure OnAfterUpdateLookupTable(var LookUpEntry: Record "LSC Inventory Lookup Table"; var Item: Record Item; var ItemVariant: Record "Item Variant"; var ItemGroup: Record "LSC Retail Product Group"; var Store: Record "LSC Store"; var ItemLedgEntry: Record "Item Ledger Entry")
    begin
    end;

    [IntegrationEvent(false, false)]
    internal procedure OnBeforeGetStaff(PosFuncProfileID: Code[10]; var ID: Code[20]; var ResponseCode: Code[30]; var ErrorText: Text; var StaffTemp: Record "LSC Staff" temporary; var StaffStoreLinkTemp: Record "LSC STAFF Store Link" temporary; var IsHandled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeInitializeDDClient(Trans: Record "LSC Transaction Header"; var MsgTxt: Text[30])
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeInitializeDDClientSendWholeTrans(Trans: Record "LSC Transaction Header"; var MsgTxt: Text[30])
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeApplyFiltersOnDataEntrySendAtEndOfTransaction(InfoCode: Record "LSC Infocode"; var DataEntry: Record "LSC POS Data Entry"; var IsHandled: Boolean)
    begin
    end;


    [IntegrationEvent(false, false)]
    local procedure OnBeforeSendMemberProcessEntry(POSFuncProfile: Record "LSC POS Func. Profile"; var TempProcessOrderEntry: Record "LSC Member Process Order Entry" temporary; var ResponseCode: Code[30]; var ErrorText: Text; var IsHandled: Boolean)
    begin
    end;

    [IntegrationEvent(false, false)]
    local procedure OnBeforeInsertLookUpEntryforNonSerialLotItem(var LookUpEntry: Record "LSC Inventory Lookup Table"; var Item: Record Item; var ItemVariant: Record "Item Variant"; var ItemGroup: Record "LSC Retail Product Group"; var Store: Record "LSC Store"; var ItemLedgEntry: Record "Item Ledger Entry")
    begin
    end;
    
    [IntegrationEvent(false, false)]
    local procedure OnBeforeInsertLookUpEntryforNonSerialLotItemVar(var LookUpEntry: Record "LSC Inventory Lookup Table"; var Item: Record Item; var ItemVariant: Record "Item Variant"; var ItemGroup: Record "LSC Retail Product Group"; var Store: Record "LSC Store"; var ItemLedgEntry: Record "Item Ledger Entry")
    begin
    end;
}
