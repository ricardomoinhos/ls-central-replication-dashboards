codeunit 10044701 "LSCNA POS Mgt."
{
    internal procedure PosTransLineCalcPrices(var POSTransLine: Record "LSC POS Trans. Line"; DiscountAmt: Decimal; var IsHandled: Boolean)
    begin
        if not UseSalesTax() then
            exit;

        IsHandled := true;

        POSTransLine."Net Price" := DiscountAmt;
        POSTransLine."LSCNA VAT Calculation Type" := POSTransLine."LSCNA VAT Calculation Type"::"Sales Tax";
        POSTransLine.LSCNAUpdateAmounts();
    end;

    internal procedure ClearCaption(var CaptionTxt: Text)
    begin
        Clear(CaptionTxt);
    end;

    internal procedure SetNetAmountOnPosTransLine(var PosTransLine2: Record "LSC POS Trans. Line"; StoreNo: Code[20])
    begin
        if not UseSalesTax(StoreNo) then
            exit;

        PosTransLine2."Net Amount" := PosTransLine2.Amount;
    end;

    local procedure UseSalesTax(pStoreNo: Code[20]): Boolean
    var
        BOUtils: Codeunit "LSC BO Utils";
    begin
        exit(BOUtils.UseSalesTax(pStoreNo));
    end;

    internal procedure FillTaxDataOnTransOrderHeader(var TransOrderHeader: Record "LSC Transaction Order Header"; Transaction: Record "LSC Transaction Header")
    begin
        TransOrderHeader."LSCNA Tax Area Code" := Transaction."LSCNA Tax Area Code";
        TransOrderHeader."LSCNA Tax Liable" := Transaction."LSCNA Tax Liable";
        TransOrderHeader."LSCNA Tax Exemption No." := Transaction."LSCNA Tax Exemption No.";
    end;

    internal procedure FillTaxDataOnTransOrderLine(var TransOrderLine: Record "LSC Transaction Order Entry"; PosOrderLine: Record "LSC POS Order Line")
    begin
        TransOrderLine."LSCNA Tax Group Code" := PosOrderLine."LSCNA Tax Group Code";
        TransOrderLine."LSCNA VAT Calculation Type" := PosOrderLine."LSCNA VAT Calculation Type";
        TransOrderLine."LSCNA Sales Tax Rounding" := PosOrderLine."LSCNA Sales Tax Rounding";
    end;

    internal procedure OnBeforeSuspTransLineInsert(var SuspTransLine: Record "LSC POS Trans. Line")
    begin
        SuspTransLine."Net Amount" := SuspTransLine.Amount;
    end;

    internal procedure OnBeforeTransLineInsert(var TransLine: Record "LSC POS Trans. Line")
    begin
        TransLine."Net Amount" := TransLine.Amount;
    end;

    internal procedure SetNetAmountBeforeSrcTransLineModify(var SrcTransLine: Record "LSC POS Trans. Line"; var TmpLine: Record "LSC POS Trans. Line")
    begin
        SrcTransLine."Net Amount" := SrcTransLine.Amount;
        TmpLine."Net Amount" := TmpLine.Amount;
    end;

    internal procedure SetTaxOnTmpTrans(var TmpTrans: Record "LSC POS Transaction"; StoreSetup: Record "LSC Store")
    begin
        TmpTrans."LSCNA Tax Area Code" := StoreSetup."LSCNA Tax Area Code";
        TmpTrans."LSCNA Tax Liable" := StoreSetup."LSCNA Tax Liable";
    end;

    internal procedure FindModule(Module: Code[10]; var TabSpecInfo: Record "LSC Table Specific Infocode"; PosFuncProfile: Record "LSC POS Func. Profile"; POSActions: Record "LSC POS Actions"; POSActionInfocode: Code[20]; var RetValue: Boolean)
    var
        Infocode: Record "LSC Infocode";
        POSInfocodeUtility: Codeunit "LSC POS Infocode Utility";
    begin
        case Module of
            'WIC':
                begin
                    if PosFuncProfile."LSCNA WIC Transaction" <> '' then begin
                        Infocode.Get(PosFuncProfile."LSCNA WIC Transaction");
                        TabSpecInfo."Table ID" := 0;
                        TabSpecInfo.Value := '';
                        TabSpecInfo."Infocode Code" := Infocode.Code;
                    end else begin
                        if not POSInfocodeUtility.InfocodePOSActionExists(POSActions."Action Trigger"::"Void Prepayment", POSActionInfocode) then
                            exit;

                        Infocode.Get(POSActionInfocode);
                        TabSpecInfo."Table ID" := 0;
                        TabSpecInfo.Value := '';
                        TabSpecInfo."Infocode Code" := Infocode.Code;
                    end;

                    RetValue := true;
                end;
        end;
    end;

    internal procedure OnBeforeCalculateAmounts(var POSTransLine: Record "LSC POS Trans. Line"; PosFuncProfile: Record "LSC POS Func. Profile"; var IsHandled: Boolean)
    var
        HospitalityMgt: Codeunit "LSCNA Hospitality Mgt.";
    begin
        IsHandled := true;

        POSTransLine."Cost Amount" := POSTransLine."Cost Price" * POSTransLine.Quantity;

        if POSTransLine."LSCNA VAT Calculation Type" = POSTransLine."LSCNA VAT Calculation Type"::"Sales Tax" then begin
            if POSTransLine."Entry Type" = POSTransLine."Entry Type"::Item then begin
                POSTransLine."Net Amount" := Round(POSTransLine.Price * POSTransLine.Quantity, PosFuncProfile."Amount Rounding to") - POSTransLine."Discount Amount";
                POSTransLine."VAT Amount" := HospitalityMgt.CalculateTax(POSTransLine, POSTransLine.Quantity, POSTransLine."Net Amount", PosFuncProfile."Amount Rounding to");
                POSTransLine.Amount := POSTransLine."Net Amount" + POSTransLine."VAT Amount";
            end else begin
                if POSTransLine."Net Price" <> POSTransLine.Price then
                    POSTransLine.Price := POSTransLine."Net Price";
                CalcDealAmounts(POSTransLine, PosFuncProfile);
            end;
        end else begin
            POSTransLine.Amount := Round(POSTransLine.Price * POSTransLine.Quantity, PosFuncProfile."Amount Rounding to") - POSTransLine."Discount Amount";
            POSTransLine."Net Amount" := Round(POSTransLine.Amount / (1 + (POSTransLine."VAT %" / 100)), PosFuncProfile."Amount Rounding to");
            POSTransLine."VAT Amount" := POSTransLine.Amount - POSTransLine."Net Amount";
        end;
    end;

    internal procedure SetNetAmountDeductedByDiscountOnAmountPerLine(pOffers: Record "LSC Periodic Discount"; POSTransLine: Record "LSC POS Trans. Line"; var AmountPerLine: Decimal)
    begin
        if not UseSalesTax() then
            exit;

        if pOffers."Sequence Function" = pOffers."Sequence Function"::Line then
            AmountPerLine := POSTransLine."Net Amount" - POSTransLine."Discount Amount"
        else
            AmountPerLine := POSTransLine."Net Amount";
    end;

    internal procedure SetNetAmountDeductedByDiscountOnAmountPerLine(var pManualTransDiscTemp: Record "LSC POS Trans. Per. Disc. Type" temporary; POSTransLine: Record "LSC POS Trans. Line"; var AmountPerLine: Decimal)
    begin
        if not UseSalesTax() then
            exit;

        if pManualTransDiscTemp."Sequence Function" = pManualTransDiscTemp."Sequence Function"::Line then
            AmountPerLine := POSTransLine."Net Amount" - POSTransLine."Discount Amount"
        else
            AmountPerLine := POSTransLine."Net Amount";
    end;

    internal procedure SetNetAmountDeductedByDiscountOnAmountPerLineWithInfoCodeCheck(var pManualTransDiscTemp: Record "LSC POS Trans. Per. Disc. Type" temporary; POSTransLine: Record "LSC POS Trans. Line"; var AmountPerLine: Decimal)
    begin
        if POSTransLine."InfoCode Disc. Disable" then
            exit;

        SetNetAmountDeductedByDiscountOnAmountPerLine(pManualTransDiscTemp, POSTransLine, AmountPerLine);
    end;

    internal procedure SetNetAmountDeductedByDiscountOnAmountPerLine2(pOffers: Record "LSC Periodic Discount"; POSTransLine: Record "LSC POS Trans. Line"; PreDiscPerLine: Decimal; var AmountPerLine: Decimal)
    begin
        if not UseSalesTax() then
            exit;

        if pOffers."Sequence Function" = pOffers."Sequence Function"::Line then
            AmountPerLine := POSTransLine."Net Amount" - POSTransLine."Discount Amount" + PreDiscPerLine
        else
            AmountPerLine := POSTransLine."Net Amount";
    end;

    internal procedure SetNetAmountDeductedByDiscountOnAmountPerLine2(var POSTransPerDiscType: Record "LSC POS Trans. Per. Disc. Type"; POSTransLine: Record "LSC POS Trans. Line"; PreDiscPerLine: Decimal; var AmountPerLine: Decimal)
    begin
        if not UseSalesTax() then
            exit;

        if POSTransPerDiscType."Sequence Function" = POSTransPerDiscType."Sequence Function"::Line then
            AmountPerLine := POSTransLine."Net Amount" - POSTransLine."Discount Amount" + PreDiscPerLine
        else
            AmountPerLine := POSTransLine."Net Amount";
    end;

    internal procedure CalcVATOnPosTransTenderTemp(var pPosTrans: Record "LSC POS Transaction"; var pPosTransTenderTemp: Record "LSC POS Trans. Line" temporary; Currency: Record Currency)
    var
        POSView: Codeunit "LSC POS View";
    begin
        if not UseSalesTax() then
            exit;

        pPosTransTenderTemp."VAT Amount" :=
          POSView.POSExchangeLCYToFCY(pPosTrans."Trans. Date", Currency.Code, pPosTransTenderTemp."VAT Amount") / pPosTrans."Currency Factor";

        if Currency."Amount Rounding Precision" = 0 then
            exit;

        pPosTransTenderTemp."VAT Amount" :=
          Round(pPosTransTenderTemp."VAT Amount", Currency."Amount Rounding Precision");
    end;

    internal procedure GetPopUpTenderTypeOfferCalculateTotals(var pPosTrans: Record "LSC POS Transaction"; var TotalAmount: Decimal; var Balance: Decimal; var IsHandled: Boolean)
    begin
        if not UseSalesTax() then
            exit;

        IsHandled := true;

        TotalAmount := CalcTransTotal(pPosTrans);
        Balance := pPosTrans."Net Amount" + pPosTrans."LSCNA Net Income/Exp. Amount";
    end;

    internal procedure SetNetAmountOnPOSTransLine2(var PosTransLineTemp: Record "LSC POS Trans. Line" temporary)
    begin
        if not UseSalesTax() then
            exit;

        PosTransLineTemp."Net Amount" := PosTransLineTemp."Net Amount" - PosTransLineTemp."Discount Amount";
        PosTransLineTemp.Modify();
    end;

    internal procedure OnBeforepPosTransTenderTempAmountCalculated(var PosTransLineTemp: Record "LSC POS Trans. Line" temporary; var pPosTrans: Record "LSC POS Transaction"; var pPosTransTenderTemp: Record "LSC POS Trans. Line" temporary; var IsHandled: Boolean)
    begin
        if not UseSalesTax() then
            exit;

        IsHandled := true;

        pPosTransTenderTemp."VAT Amount" := CalcOfferTax(pPosTrans, PosTransLineTemp);
        pPosTransTenderTemp.Amount := pPosTransTenderTemp.Price - pPosTransTenderTemp."Discount Amount" + pPosTransTenderTemp."VAT Amount";
    end;

    internal procedure CalcTotalAmountToDisc(var pOffers: Record "LSC Periodic Discount" temporary; var pPosTransLine: Record "LSC POS Trans. Line" temporary; var TotalAmountToDisc: Decimal; var IsHandled: Boolean)
    begin
        if not UseSalesTax() then
            exit;

        IsHandled := true;

        if pOffers."Sequence Function" = pOffers."Sequence Function"::Line then
            TotalAmountToDisc := TotalAmountToDisc + (pPosTransLine."Net Amount" - pPosTransLine."Discount Amount")
        else
            TotalAmountToDisc := TotalAmountToDisc + pPosTransLine."Net Amount";
    end;

    internal procedure HanldeCalcTransTotal(var POSTransaction: Record "LSC POS Transaction"; var TotalAmount: Decimal; var IsHandled: Boolean)
    begin
        if not UseSalesTax() then
            exit;

        IsHandled := true;

        TotalAmount := CalcTransTotal(POSTransaction);
    end;

    local procedure CalcTransTotal(var pPosTrans: Record "LSC POS Transaction"): Decimal
    var
        PosTransLine: Record "LSC POS Trans. Line";
        BenefitAmount: Decimal;
        TotalAmount: Decimal;
    begin
        TotalAmount := 0;

        pPosTrans.CalcFields("Net Amount", "Line Discount", "LSCNA Net Income/Exp. Amount");
        TotalAmount := pPosTrans."Net Amount" + pPosTrans."Line Discount" + pPosTrans."LSCNA Net Income/Exp. Amount";

        PosTransLine.Reset();
        PosTransLine.SetCurrentKey("Receipt No.", "Entry Type", "Entry Status");
        PosTransLine.SetRange("Receipt No.", pPosTrans."Receipt No.");
        PosTransLine.SetRange("Entry Type", PosTransLine."Entry Type"::Item);
        PosTransLine.SetRange("Entry Status", PosTransLine."Entry Status"::" ");
        PosTransLine.SetRange("Benefit Item", true);
        if PosTransLine.FindSet() then begin
            BenefitAmount := 0;
            repeat
                BenefitAmount := BenefitAmount + PosTransLine."Net Amount"
            until PosTransLine.Next() = 0;

            TotalAmount := TotalAmount - BenefitAmount;
        end;

        exit(TotalAmount);
    end;

    internal procedure HandleCalcTransTotalToDiscount(var pPosTrans: Record "LSC POS Transaction"; var pPosTransLine: Record "LSC POS Trans. Line" temporary; var pOffers: Record "LSC Periodic Discount" temporary; var pOfferLines: Record "LSC Offer Pos Calculation" temporary; var TransTotalAmountToDisc: Decimal; var IsHandled: Boolean)
    begin
        if not UseSalesTax() then
            exit;

        IsHandled := true;

        TransTotalAmountToDisc := CalcTransTotalToDiscount(pPosTrans, pPosTransLine, pOffers, pOfferLines);
    end;

    local procedure CalcTransTotalToDiscount(var pPosTrans: Record "LSC POS Transaction"; var pPosTransLine: Record "LSC POS Trans. Line" temporary; var pOffers: Record "LSC Periodic Discount" temporary; var pOfferLines: Record "LSC Offer Pos Calculation" temporary): Decimal
    var
        TransTotalAmountToDisc: Decimal;
    begin
        TransTotalAmountToDisc := 0;
        pOfferLines.Reset();
        pOfferLines.SetRange("Group No.", pOffers."No.");
        if pOfferLines.FindSet() then
            repeat
                pPosTransLine.Get(pPosTrans."Receipt No.", pOfferLines."Trans. Line No.");
                if pOffers."Sequence Function" = pOffers."Sequence Function"::Line then
                    TransTotalAmountToDisc := TransTotalAmountToDisc + (pPosTransLine."Net Amount" - pPosTransLine."Discount Amount")
                else
                    TransTotalAmountToDisc := TransTotalAmountToDisc + pPosTransLine."Net Amount"
            until pOfferLines.Next() = 0;

        exit(TransTotalAmountToDisc)
    end;

    internal procedure PosPostUtilityDoInsertSalesTaxEntry(var TransSalesTaxEntryTEMP: Record "LSC Trans. SalesTax Entry" temporary; Transaction: Record "LSC Transaction Header"; Sign: Integer)
    begin
        InsertSalesTaxEntryToSingleInstance(Transaction, Sign);
    end;

    internal procedure SetTaxInfoOnSalesEntry(var SalesEntry: Record "LSC Trans. Sales Entry"; var POSTransLineTmp: Record "LSC POS Trans. Line" temporary)
    begin
        SalesEntry."LSCNA Tax Group Code" := POSTransLineTmp."LSCNA Tax Group Code";
        SalesEntry."LSCNA VAT Calculation Type" := POSTransLineTmp."LSCNA VAT Calculation Type";
    end;

    internal procedure CalculateTransactionGrossAmount(var SalesEntry2: Record "LSC Trans. Sales Entry"; var Transaction: Record "LSC Transaction Header"; var IsHandled: Boolean)
    begin
        if not UseSalesTax() then
            exit;

        IsHandled := true;

        Transaction."Gross Amount" += (SalesEntry2."VAT Amount" + SalesEntry2."Net Amount" + SalesEntry2."LSCNA Sales Tax Rounding");
    end;

    internal procedure SetTaxInfoOnIncomeExpenseEntry(var IncomExpenseEntry: Record "LSC Trans. Inc./Exp. Entry"; POSIncomeExpenseEntry: Record "LSC POS Trans. Line"; Sign: Integer)
    begin
        IncomExpenseEntry."LSCNA Sales Tax Rounding" := -Sign * POSIncomeExpenseEntry."LSCNA Sales Tax Rounding";
        IncomExpenseEntry."LSCNA Tax Group Code" := POSIncomeExpenseEntry."LSCNA Tax Group Code";
        IncomExpenseEntry."VAT Calculation Type" := POSIncomeExpenseEntry."LSCNA VAT Calculation Type";
    end;

    internal procedure SkipProcessRoundingDifference(var SkipRoundingDiffProcessing: Boolean)
    begin
        SkipRoundingDiffProcessing := true;
    end;

    internal procedure InitTransactionWithSalesTaxData(POSTrans: Record "LSC POS Transaction"; var POSTransaction: Record "LSC POS Transaction"; var Transaction: Record "LSC Transaction Header")
    begin
        Transaction."LSCNA Tax Area Code" := POSTransaction."LSCNA Tax Area Code";
        Transaction."LSCNA Tax Liable" := POSTransaction."LSCNA Tax Liable";
        if UseSalesTax() then begin
            POSTransaction.CalcFields("LSCNA Net Income/Exp. Amount");
            Transaction."LSCNA Net Income/Exp. Amount" := -POSTransaction."LSCNA Net Income/Exp. Amount";
        end;
        Transaction."LSCNA WIC Transaction" := POSTransaction."LSCNA WIC Transaction";
    end;

    internal procedure DoClearTransSalesTaxEntryTEMP2()
    var
        POSPostUtilitySingleInst: Codeunit "LSCNA POSPostUtilitySingleInst";
    begin
        POSPostUtilitySingleInst.ClearTempTransSalesTaxEntry();
    end;

    internal procedure DistributeCouponDiscountInitPosTransLineAmounts(var POSTransLine: Record "LSC POS Trans. Line"; var IsHandled: Boolean)
    begin
        if not UseSalesTax() then
            exit;

        IsHandled := true;

        POSTransLine."Discount Amount" += POSTransLine."Coupon Discount Amount";
        POSTransLine."Net Amount" -= POSTransLine."Coupon Discount Amount";
        POSTransLine.Amount := POSTransLine."Net Amount" * (1 + (POSTransLine."VAT %" / 100));
        POSTransLine."VAT Amount" := POSTransLine.Amount - POSTransLine."Net Amount";
    end;

    internal procedure DistributeCouponDiscExlCouponValue(var POSTransLine: Record "LSC POS Trans. Line"; var CouponHeaderTmp: Record "LSC Coupon Header" temporary; var IsHandled: Boolean)
    begin
        if not UseSalesTax() then
            exit;

        IsHandled := true;

        POSTransLine."Net Amount" -= CouponHeaderTmp.Value;
        POSTransLine.Amount := POSTransLine."Net Amount" * (1 + (POSTransLine."VAT %" / 100));
        POSTransLine."VAT Amount" := POSTransLine.Amount - POSTransLine."Net Amount";
    end;

    internal procedure InsertSalesTaxEntryToSingleInstance(Transaction: Record "LSC Transaction Header"; Sign: Integer)
    var
        TransSalesTaxEntry: Record "LSC Trans. SalesTax Entry";
        TransSalesTaxEntryTEMP2: Record "LSC Trans. SalesTax Entry" temporary;
        POSPostUtilitySingleInst: Codeunit "LSCNA POSPostUtilitySingleInst";
        TaxSign: Integer;
    begin
        TaxSign := -Sign;

        POSPostUtilitySingleInst.GetTempTransSalesTaxEntryTable2(TransSalesTaxEntryTEMP2, false);

        TransSalesTaxEntryTEMP2.Reset();
        if TransSalesTaxEntryTEMP2.FindSet() then
            repeat
                TransSalesTaxEntry.Init();
                TransSalesTaxEntry.TransferFields(TransSalesTaxEntryTEMP2);
                TransSalesTaxEntry."Store No." := Transaction."Store No.";
                TransSalesTaxEntry."POS Terminal No." := Transaction."POS Terminal No.";
                TransSalesTaxEntry."Transaction No." := Transaction."Transaction No.";
                TransSalesTaxEntry."Entry No." := TransSalesTaxEntryTEMP2."Entry No.";
                TransSalesTaxEntry.Quantity := TaxSign * TransSalesTaxEntry.Quantity;
                TransSalesTaxEntry."Tax Base Amount" := TaxSign * TransSalesTaxEntry."Tax Base Amount";
                TransSalesTaxEntry."Tax Amount" := TaxSign * TransSalesTaxEntry."Tax Amount";
                TransSalesTaxEntry."Tax Difference" := TaxSign * TransSalesTaxEntry."Tax Difference";
                TransSalesTaxEntry.Positive := TransSalesTaxEntry."Tax Base Amount" > 0;
                POSPostUtilitySingleInst.InsertTempTransSalesTaxEntry(TransSalesTaxEntry);
            until TransSalesTaxEntryTEMP2.Next() = 0;

        POSPostUtilitySingleInst.ClearTempTransSalesTaxEntry2();
    end;

    internal procedure InsertAdditionalTransSalesTaxEntry(var TransactionHeader: Record "LSC Transaction Header")
    var
        TransSalesTaxEntryLoc: Record "LSC Trans. SalesTax Entry";
        TransSalesTaxEntryTEMP: Record "LSC Trans. SalesTax Entry" temporary;
        POSPostUtilitySingleInst: Codeunit "LSCNA POSPostUtilitySingleInst";
    begin
        POSPostUtilitySingleInst.GetTempTransSalesTaxEntryTable(TransSalesTaxEntryTEMP);

        TransSalesTaxEntryTEMP.Reset();
        if TransSalesTaxEntryTEMP.FindSet() then
            repeat
                TransSalesTaxEntryLoc := TransSalesTaxEntryTEMP;
                TransSalesTaxEntryLoc."Transaction No." := TransactionHeader."Transaction No.";
                TransSalesTaxEntryLoc.Insert(true);
            until TransSalesTaxEntryTEMP.Next() = 0;
    end;

#pragma warning disable AL0432
    internal procedure GetVatAmountLine(var VATAmountLine: Record "VAT Amount Line"; POSTransLine: Record "LSC POS Trans. Line"; var Found: Boolean; var IsHandled: Boolean)
#pragma warning restore AL0432
    begin
        IsHandled := true;
        Found := VATAmountLine.Get(POSTransLine."VAT Code", 0, '', '', false, POSTransLine."Net Amount" > 0);
    end;

    internal procedure SetNetPriceForSalesTaxVatCalculationType(var CurrLine: Record "LSC POS Trans. Line")
    begin
        if CurrLine."LSCNA VAT Calculation Type" <> CurrLine."LSCNA VAT Calculation Type"::"Sales Tax" then
            exit;

        CurrLine."Net Price" := CurrLine.Price;
    end;

    internal procedure CalculateAmountPerLine(PosTransLine2: Record "LSC POS Trans. Line"; var AmountPerLine: Decimal)
    begin
        if PosTransLine2."LSCNA VAT Calculation Type" <> PosTransLine2."LSCNA VAT Calculation Type"::"Sales Tax" then
            exit;

        AmountPerLine := PosTransLine2."Net Amount" + PosTransLine2."Total Disc. Amount";
    end;

    internal procedure SetDiscTransNetAmount(var DiscTrans: Record "LSC POS Trans. Line"; NewNetAmount: Decimal)
    begin
        DiscTrans."Net Amount" := -NewNetAmount;
    end;

    internal procedure CalcTotAmount(var PosTrans: Record "LSC POS Transaction"; POSTransLine: Record "LSC POS Trans. Line"; var TotAmount: Decimal; var IsHandled: Boolean)
    begin
        if (POSTransLine."LSCNA VAT Calculation Type" = POSTransLine."LSCNA VAT Calculation Type"::"Sales Tax") then
            exit;

        IsHandled := true;

        PosTrans.CalcFields("Net Amount", "Line Discount", "LSCNA Net Income/Exp. Amount");
        TotAmount := PosTrans."Net Amount" + PosTrans."Line Discount" + PosTrans."LSCNA Net Income/Exp. Amount";
    end;

    internal procedure RecalcNetAmountDealPOSTransLine(var DealPOSTransLine: Record "LSC POS Trans. Line")
    begin
        DealPOSTransLine."Net Amount" := (DealPOSTransLine.Quantity * DealPOSTransLine."Net Price") - DealPOSTransLine."Discount Amount";
    end;

    internal procedure CalcTransTotalAmountToDisc(var POSTransLine: Record "LSC POS Trans. Line"; var TransTotalAmountToDisc: Decimal; UsingSalesTax: Boolean; var IsHandled: Boolean)
    begin
        if not UsingSalesTax then
            exit;

        IsHandled := true;

        TransTotalAmountToDisc := TransTotalAmountToDisc + POSTransLine."Net Amount" + POSTransLine."Discount Amount"
    end;

    internal procedure CalculateDiscPercent(MobileTransLine: Record LSCMobileTransactionLine; PosTransLine: Record "LSC POS Trans. Line"; var DiscPercent: Decimal; var IsHandled: Boolean)
    begin
        if not UseSalesTax() then
            exit;

        IsHandled := true;

        if PosTransLine."Net Amount" = 0 then
            exit;

        DiscPercent := MobileTransLine.ManualDiscountAmount / PosTransLine."Net Amount" * 100;
    end;

    internal procedure OnLoadTransactionBeforePosTransInsert(var PosTrans: Record "LSC POS Transaction"; var MobileTransTemp: Record LSCMobileTransaction temporary; Store: Record "LSC Store")
    begin
        if MobileTransTemp."LSCNA TaxAreaCode" <> '' then begin
            PosTrans.Validate("LSCNA Tax Area Code", MobileTransTemp."LSCNA TaxAreaCode");
            PosTrans."LSCNA Tax Liable" := MobileTransTemp."LSCNA TaxLiable";
        end else begin
            PosTrans.Validate("LSCNA Tax Area Code", Store."LSCNA Tax Area Code");
            PosTrans."LSCNA Tax Liable" := Store."LSCNA Tax Liable";
        end;
    end;

    internal procedure OnLoadMobileTransactionBeforeMobileTransTempModify(var MobileTransTemp: Record LSCMobileTransaction temporary; PosTrans: Record "LSC POS Transaction")
    begin
        MobileTransTemp."LSCNA TaxAreaCode" := PosTrans."LSCNA Tax Area Code";
        MobileTransTemp."LSCNA TaxLiable" := PosTrans."LSCNA Tax Liable";
    end;

    internal procedure OnLoadTransactionPreCalcBeforePosTransInsert(var PosTrans: Record "LSC POS Transaction"; var MobileTransTemp: Record LSCMobileTransaction temporary; Store: Record "LSC Store")
    begin
        //same as OnLoadTransactionBeforePosTransInsert
        if MobileTransTemp."LSCNA TaxAreaCode" <> '' then begin
            PosTrans.Validate("LSCNA Tax Area Code", MobileTransTemp."LSCNA TaxAreaCode");
            PosTrans."LSCNA Tax Liable" := MobileTransTemp."LSCNA TaxLiable";
        end else begin
            PosTrans.Validate("LSCNA Tax Area Code", Store."LSCNA Tax Area Code");
            PosTrans."LSCNA Tax Liable" := Store."LSCNA Tax Liable";
        end;
    end;

    internal procedure OnLoadTransactionPreCalcBeforePosTransLineModify(var PosTransLine: Record "LSC POS Trans. Line"; var MobileTransLineTemp: Record LSCMobileTransactionLine temporary)
    begin
        if not UseSalesTax() then
            exit;

        PosTransLine."VAT Amount" := MobileTransLineTemp.TAXAmount;
        PosTransLine.Amount := PosTransLine."Net Amount" + PosTransLine."VAT Amount";
    end;

    internal procedure OnAfterDiscountCalculated_PrepareTransToRefund(var PosTransLineBuffer: Record "LSC POS Trans. Line"; TransSalesEntry: Record "LSC Trans. Sales Entry"; PosFuncProfile: Record "LSC POS Func. Profile")
    var
        VATSetup: Record "VAT Posting Setup";
    begin
        VATSetup.Get(PosTransLineBuffer."Vat Bus. Posting Group", PosTransLineBuffer."Vat Prod. Posting Group");
        PosTransLineBuffer."LSCNA VAT Calculation Type" := VATSetup."VAT Calculation Type";

        if not UseSalesTax() then
            exit;

        if TransSalesEntry.Quantity = -1 then begin
            PosTransLineBuffer."VAT Amount" := -TransSalesEntry."VAT Amount";
            PosTransLineBuffer."Cost Amount" := -TransSalesEntry."Cost Amount";
            PosTransLineBuffer."Discount Amount" := TransSalesEntry."Discount Amount";
            PosTransLineBuffer."Net Amount" := Round(TransSalesEntry.Price - PosTransLineBuffer."Discount Amount", PosFuncProfile."Amount Rounding to");
        end else begin
            PosTransLineBuffer."VAT Amount" := Round(-1 * (-TransSalesEntry."VAT Amount" / TransSalesEntry.Quantity), PosFuncProfile."Amount Rounding to");
            PosTransLineBuffer."Cost Amount" := Round(-1 * (-TransSalesEntry."Cost Amount" / TransSalesEntry.Quantity), PosFuncProfile."Amount Rounding to");
            PosTransLineBuffer."Discount Amount" := Round((-TransSalesEntry."Discount Amount" / TransSalesEntry.Quantity), PosFuncProfile."Amount Rounding to");
            PosTransLineBuffer."Net Amount" := Round(TransSalesEntry.Price - PosTransLineBuffer."Discount Amount", PosFuncProfile."Amount Rounding to");
        end;

        PosTransLineBuffer."LSCNA Tax Base Amount" := -PosTransLineBuffer."Net Amount";
        PosTransLineBuffer.Amount := PosTransLineBuffer."Net Amount" + PosTransLineBuffer."VAT Amount";
        PosTransLineBuffer."LSCNA Tax Group Code" := TransSalesEntry."LSCNA Tax Group Code";
        PosTransLineBuffer."LSCNA VAT Calculation Type" := TransSalesEntry."LSCNA VAT Calculation Type";
        PosTransLineBuffer."LSCNA Sales Tax Rounding" := -TransSalesEntry."LSCNA Sales Tax Rounding";
    end;

    internal procedure ValidatePostedTransactionRefund(TransactionHeader: Record "LSC Transaction Header"; NewReceiptNo: Code[20]; var ReturnValue: Boolean; var IsHandled: Boolean)
    var
        POSTransaction: Codeunit "LSC POS Transaction";
        RefundWICErr: Label 'It is not possible to refund a WIC transaction';
    begin
        if not TransactionHeader."LSCNA WIC Transaction" then
            exit;

        POSTransaction.ErrorBeep(RefundWICErr);

        ReturnValue := false;
        IsHandled := true;
    end;

    internal procedure CopyPOSTransactionTaxDataFromTransactionHeader(var POSTransaction: Record "LSC POS Transaction"; TransactionHeader: Record "LSC Transaction Header")
    begin
        POSTransaction."LSCNA Tax Area Code" := TransactionHeader."LSCNA Tax Area Code";
        POSTransaction."LSCNA Tax Liable" := TransactionHeader."LSCNA Tax Liable";
        POSTransaction."LSCNA Tax Exemption No." := TransactionHeader."LSCNA Tax Exemption No.";
        if POSTransaction."Customer No." <> '' then
            POSTransaction."VAT by InfoCode" := true;
    end;

    internal procedure CreateJournalLinesCaption(var RecRef: RecordRef; pFieldNo: Integer; var tmpText: Text; var EventSaysExit: Boolean)
    var
        POSTransLine: Record "LSC POS Trans. Line";
        Formatting: Codeunit "LSC POS Formatting";
        RecRef2: RecordRef;
    begin
        RecRef2 := RecRef.Duplicate();
        RecRef2.SetTable(POSTransLine);
        //Net Amount
        case pFieldNo of
            POSTransLine.FieldNo("Net Amount"):
                begin
                    if POSTransLine."Deal Line" and not (POSTransLine."Entry Type" = POSTransLine."Entry Type"::FreeText) then
                        tmpText := ''
                    else
                        if (POSTransLine."Entry Type" = POSTransLine."Entry Type"::Payment) and POSTransLine."Special Order Deposit Entry" then
                            tmpText := Formatting.FormatAmount(-POSTransLine."Net Amount")
                        else
                            tmpText := Formatting.FormatAmount(POSTransLine."Net Amount");

                    EventSaysExit := true;
                end;
        end;
    end;

    internal procedure VerifyStorePostingSetup(Store: Record "LSC Store"; var Ishandled: Boolean)
    var
        Text005: Label 'No %1 has been specified for this %2';
    begin
        Ishandled := true;

        if not UseSalesTax() then
            exit;

        if Store."LSCNA Tax Area Code" = '' then
            Error(Text005, Store.FieldCaption("LSCNA Tax Area Code"), Store.TableCaption);
    end;

    internal procedure GetNoVATUsedCaption(var NewCaption: Text; var IsHandled: Boolean) text: Text[50]
    var
        NoTaxUsedLbl: Label 'No Tax Used';
    begin
        IsHandled := true;
        NewCaption := NoTaxUsedLbl;
    end;

    internal procedure GetAddVATToPricesCaption(var NewCaption: Text; var IsHandled: Boolean) text: Text[50]
    var
        AddTaxToPriceLbl: Label 'Add Tax to Prices';
    begin
        IsHandled := true;
        NewCaption := AddTaxToPriceLbl;
    end;

    internal procedure GetSkipVATonReceiptCaption(var NewCaption: Text; var IsHandled: Boolean) text: Text[50]
    var
        SkipTaxOnReceiptsLbl: Label 'Skip Tax on Receipts';
    begin
        IsHandled := true;
        NewCaption := SkipTaxOnReceiptsLbl;
    end;

    internal procedure GetVATRegNoonReceiptCaption(var NewCaption: Text; var IsHandled: Boolean) text: Text[50]
    var
        TaxRegNoOnReceiptLbl: Label 'Tax Reg.No. on Receipt';
    begin
        IsHandled := true;
        NewCaption := TaxRegNoOnReceiptLbl;
    end;

    local procedure CalcOfferTax(var pPosTrans: Record "LSC POS Transaction"; var pPosTransLineTemp: Record "LSC POS Trans. Line" temporary): Decimal
    var
        POSFuncProfile: Record "LSC POS Func. Profile";
        PosTransLine: Record "LSC POS Trans. Line";
        SalesTaxCalculate: Codeunit "Sales Tax Calculate";
        VATAmount: Decimal;
        VATAmountPerGr: Decimal;
        VATAmountTotalBase: Decimal;
        VATQuantity: Decimal;
    begin
        POSFuncProfile := InitFunc(pPosTrans);//new
        VATAmount := 0;

        PosTransLine.Reset();
        PosTransLine.SetCurrentKey("Receipt No.", "LSCNA Tax Group Code", "Entry Status");
        PosTransLine.SetRange("Receipt No.", pPosTrans."Receipt No.");
        PosTransLine.SetRange("Entry Status", PosTransLine."Entry Status"::" ");
        PosTransLine.SetFilter("Entry Type", '%1|%2', PosTransLine."Entry Type"::Item, PosTransLine."Entry Type"::IncomeExpense);
        if PosTransLine.FindSet() then
            repeat
                PosTransLine.SetRange("LSCNA Tax Group Code", PosTransLine."LSCNA Tax Group Code");
                VATAmountTotalBase := 0;
                VATQuantity := 0;
                repeat
                    if pPosTransLineTemp.Get(PosTransLine."Receipt No.", PosTransLine."Line No.") then begin
                        VATAmountTotalBase := VATAmountTotalBase + pPosTransLineTemp."Net Amount";
                        VATQuantity := VATQuantity + pPosTransLineTemp.Quantity;
                    end else begin
                        VATAmountTotalBase := VATAmountTotalBase + PosTransLine."Net Amount";
                        VATQuantity := VATQuantity + PosTransLine.Quantity;
                    end;
                until PosTransLine.Next() = 0;
                VATAmountPerGr :=
                  SalesTaxCalculate.CalculateTax(
                    pPosTrans."LSCNA Tax Area Code", pPosTransLineTemp."LSCNA Tax Group Code", pPosTrans."LSCNA Tax Liable", pPosTrans."Trans. Date",
                    VATAmountTotalBase, VATQuantity, 0);
                VATAmountPerGr := Round(VATAmountPerGr, POSFuncProfile."Amount Rounding to");
                VATAmount := VATAmount + VATAmountPerGr;
                PosTransLine.SetRange("LSCNA Tax Group Code");
            until PosTransLine.Next() = 0;

        exit(VATAmount);
    end;

    local procedure InitFunc(var pPosTrans: Record "LSC POS Transaction"): Record "LSC POS Func. Profile"
    var
        POSFuncProfile: Record "LSC POS Func. Profile";
        RetailSetup: Record "LSC Retail Setup";
        Store: Record "LSC Store";
        Global: Codeunit "LSC POS Session";
    begin
        RetailSetup.Get();

        Store.Get(pPosTrans."Store No.");
        POSFuncProfile.Get(Global.FunctionalityProfileID());
        exit(POSFuncProfile)
    end;

    local procedure UseSalesTax(): Boolean
    var
        ServiceLocator: Codeunit "LSCNA ServiceLocator";
        POSSession: Codeunit "LSC POS Session";
    begin
        exit(ServiceLocator.GetBOUtils().UseSalesTax(POSSession.StoreNo()));
    end;

    internal procedure CalcDealAmounts(var POSTransLine: Record "LSC POS Trans. Line"; var PosFuncProfile: Record "LSC POS Func. Profile")
    var
        ChildItemLine: Record "LSC POS Trans. Line";
        HospitalityMgt: Codeunit "LSCNA Hospitality Mgt.";
        NetAmount, TotalNetAmount, TaxAmount : Decimal;
    begin
        ChildItemLine.SetRange("Receipt No.", POSTransLine."Receipt No.");
        ChildItemLine.SetRange("Parent Line", POSTransLine."Line No.");
        ChildItemLine.SetRange("Entry Type", ChildItemLine."Entry Type"::Item);
        if not ChildItemLine.FindSet() then begin
            ChildItemLine.Reset();
            ChildItemLine.SetRange("Receipt No.", POSTransLine."Receipt No.");
            ChildItemLine.SetRange("Parent Line", POSTransLine."Split Origin Line No.");
            ChildItemLine.SetRange("Entry Type", ChildItemLine."Entry Type"::Item);
            if not ChildItemLine.FindSet() then
                exit;
        end;

        repeat
            NetAmount := Round(ChildItemLine.Price * POSTransLine.Quantity, PosFuncProfile."Amount Rounding to") - POSTransLine."Discount Amount";
            TotalNetAmount += NetAmount;
            TaxAmount += HospitalityMgt.CalculateTax(ChildItemLine, POSTransLine.Quantity, NetAmount, PosFuncProfile."Amount Rounding to");
        until ChildItemLine.Next() = 0;
        POSTransLine."Net Amount" := TotalNetAmount;
        POSTransLine."VAT Amount" := TaxAmount;
        POSTransLine.Amount := POSTransLine."Net Amount" + POSTransLine."VAT Amount";
    end;
}