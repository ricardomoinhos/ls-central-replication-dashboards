codeunit 10012736 "LSC POS Web Template Handler"
{
    Access = Internal;

    var
        _POSCtrl: Codeunit "LSC POS Control Interface";
        _PosSession: Codeunit "LSC POS Session";
        _WSConnection: Codeunit "LSC Web Service Connection";
        _HttpWrapper: Codeunit "LSC Http Wrapper";
        _HttpUtils: Codeunit "LSC Http Utils";
        _wsURL, _wsUserName, _wsDomain : Text;
        _wsPwd: SecretText;
        _SetHtmlContent, _SetJsContent : JsonObject;
        _PendingTemplateImageLinks: Dictionary of [Text, Code[20]];
        _SentTemplateImageLinks: Dictionary of [Text, Code[20]];

    procedure SendToTemplate(pControlID: Code[20]; tmplID: Text; argsJson: JsonObject)
    begin
        SendToTemplate(pControlID, tmplID, '', '###URLDATA', argsJson);
    end;

    procedure SendToTemplate(pControlID: Code[20]; tmplID: Text; methodName: Text; argsJson: JsonObject)
    begin
        if not argsJson.Contains('skipWebCall') then
            argsJson.Add('skipWebCall', 1);
        SendToTemplate(pControlID, tmplID, '', methodName, argsJson);
    end;

    procedure SendToTemplate(pControlID: Code[20]; tmplID: Text; serviceName: Text; methodName: Text; argsJson: JsonObject)
    begin
        _POSCtrl.Navigate(pControlID, StrSubstNo('lstmpl://%1/%2/%3/?%4', tmplID, serviceName, methodName, _HttpUtils.JsonToQueryParameters(argsJson)));
    end;

    procedure UpdatePosTags(jStr: Text)
    var
        jObj: JsonObject;
        jTok: JsonToken;
        k: Text;
        v: Text;
        ks: List of [Text];
    begin
        if jStr = '' then
            exit;
        if not jObj.ReadFrom(jStr) then
            exit;
        ks := jObj.Keys;
        foreach k in ks do begin
            jObj.Get(k, jTok);
            v := jTok.AsValue.AsText;
            _POSCtrl.SetValue(k, v);
        end;
    end;

    procedure SetHtml(pCtrlID: Code[20]; pHtml: Text)
    begin
        if pCtrlID <> '' then
            if _SetHtmlContent.Contains('') then
                _SetHtmlContent.Remove('');
        if _SetHtmlContent.Contains(pCtrlID) then begin
            if pHtml <> '' then
                _SetHtmlContent.Replace(pCtrlID, pHtml)
            else begin
                _SetHtmlContent.Remove(pCtrlID);
                _POSCtrl.Navigate(pCtrlID, '');
                exit;
            end;
        end else
            _SetHtmlContent.Add(pCtrlID, pHtml);
        _POSCtrl.Navigate(pCtrlID, '###FETCH');
    end;

    procedure InvokeScript(pCtrlID: Code[20]; pJavaScript: Text)
    var
        jTok, jTok2 : JsonToken;
        jArr, jArr2 : JsonArray;
    begin
        if pCtrlID <> '' then begin
            if _SetJsContent.Contains('') then begin
                _SetJsContent.Get('', jTok);
                jArr := jTok.AsArray;
                _SetJsContent.Remove('');
            end;
        end;
        if _SetJsContent.Contains(pCtrlID) then begin
            if pJavaScript = '' then begin
                _SetJsContent.Remove(pCtrlID);
                _POSCtrl.Navigate(pCtrlID, '');
                exit;
            end;
            _SetJsContent.Get(pCtrlID, jTok);
            if jArr.Count > 0 then begin
                jArr2 := jTok.AsArray;
                foreach jTok2 in jArr2 do
                    jArr.Add(jTok2); // place pCtrlID's JS after empty ID's JS
                _SetJsContent.Replace(pCtrlID, jArr.AsToken);
            end else
                jArr := jTok.AsArray;
        end else begin
            if pJavaScript = '' then
                if jArr.Count <= 0 then
                    exit;
            _SetJsContent.Add(pCtrlID, jArr);
        end;
        jArr.Add(pJavaScript);
        _POSCtrl.Navigate(pCtrlID, '###FETCH');
    end;

    procedure LoadTemplateResource(pCtrlID: Code[20]; pTemplateID: Code[20]; htmlBit: Integer; cssBit: Integer; jsBit: Integer; pUrl: Text; pProfileID: Code[20])
    var
        j: JsonObject;
        WebTemplate: Record "LSC POS Web Template";
        txt: Text;

        ws: Codeunit "LSC Web Services";
        fNo: Integer;

        lsHtmlScheme: Label 'lshtml://', Locked = true;
        lsFetchScheme: Label '###FETCH', Locked = true;
        schemePart: Text;
        urlParts: List of [Text];
        jTok: JsonToken;
    begin
        _POSCtrl.LogDebug(StrSubstNo('Web Template Fetch: [%1%2]/[%3]/[%4,%5,%6] at [%7]', pProfileID, pCtrlID, pTemplateID, htmlBit, cssBit, jsBit, pUrl));
        schemePart := (StrLen(pUrl) < 9 ? pUrl.PadRight(9, '_') : pUrl.Substring(1, 9)).ToLower();  // 1-based lsHtmlScheme.Count

        case true of
            schemePart.StartsWith(Format(lsFetchScheme).ToLower()):
                begin
                    if htmlBit <> 0 then begin
                        if _SetHtmlContent.Contains(pCtrlID) then begin
                            _SetHtmlContent.Get(pCtrlID, jTok);
                            j.Add('html', jTok.AsValue.AsText);
                            _SetHtmlContent.Remove(pCtrlID);
                            htmlBit := 0;
                        end;
                    end;
                    if jsBit <> 0 then begin
                        if _SetJsContent.Contains(pCtrlID) then begin
                            _SetJsContent.Get(pCtrlID, jTok);
                            j.Add('js', Format(jTok.AsArray));
                            _SetJsContent.Remove(pCtrlID);
                            jsBit := 0;
                        end;
                    end;
                    cssBit := 0;
                    pUrl := lsFetchScheme; // let client know the response was to a fetch request 
                end;
            schemePart = lsHtmlScheme:
                begin
                    if htmlBit = 0 then
                        exit;
                    urlparts := pUrl.Substring(10).Split('/');
                    if urlparts.Count <> 2 then
                        exit;
                    if not Evaluate(fNo, urlparts.Get(2)) then
                        exit;
                    ws.GetPosHtml(urlparts.Get(1), fNo, txt);
                    j.Add('html', txt);
                    htmlBit := 0;
                    cssBit := 0;
                    jsBit := 0;
                end;
            pTemplateID <> '':
                begin
                    if not IsBaseTemplate(pTemplateID) then
                        if not WebTemplate.Get(pTemplateID) then
                            Error('LoadTemplateResource: TemplateID %1 not found', pTemplateID);
                end;
            else
                exit;
        end;

        if htmlBit <> 0 then
            j.Add('html', GetTemplateSourceCode(pTemplateID, "LSC POS Web Template Resource"::Html));
        if cssBit <> 0 then
            j.Add('css', GetTemplateSourceCode(pTemplateID, "LSC POS Web Template Resource"::Css));
        if jsBit <> 0 then
            j.Add('js', GetTemplateSourceCode(pTemplateID, "LSC POS Web Template Resource"::Js));

        j.Add('ctrlId', pCtrlID);
        j.Add('tmplId', pTemplateID);
        j.Add('profileId', pProfileID);
        j.Add('url', pUrl);

        _POSCtrl.PostEvent('RUNCOMMAND', '_SET_TMPL_RSRC', Format(j), '');
    end;

    procedure IsBaseTemplate(pTemplateId: Code[20]): Boolean
    var
        bwt: Interface "LSC IBaseWebTemplates 2";
    begin
        exit(IsBaseTemplate(pTemplateId, bwt));
    end;

    procedure IsBaseTemplate(pTemplateId: Code[20]; var pBwt: Interface "LSC IBaseWebTemplates 2"): Boolean
    var
        i: Integer;
    begin
        foreach i in "LSC Base Web Templates".Ordinals() do begin
            pBwt := "LSC Base Web Templates".FromInteger(i);
            if pBwt.HasBaseWebTemplateId(pTemplateId) then
                exit(true);
        end;
        exit(false);
    end;

    procedure GetTemplateSourceCode(pTemplateId: Code[20]; pType: Enum "LSC POS Web Template Resource"): Text
    var
        t: Text;
        wt: Record "LSC POS Web Template";
        bwt: Interface "LSC IBaseWebTemplates 2";
        tmpBlob: Codeunit "Temp Blob";
        bu: Codeunit "LSC Blob Utils";
    begin
        if IsBaseTemplate(pTemplateId, bwt) then
            exit(bwt.GetBaseTemplateSourceCode(pTemplateId, pType));
        wt.Get(pTemplateId);
        tmpBlob.FromRecord(wt, FieldNoFromResourceType(pType));
        if bu.ReadFromBlob(tmpBlob, t, TextEncoding::UTF8) then;
        exit(t);
    end;

    procedure FieldNoFromResourceType(resourceType: Enum "LSC POS Web Template Resource"): Integer
    var
        PosWebTemplate: Record "LSC POS Web Template";
    begin
        case resourceType of
            resourceType::Html:
                exit(PosWebTemplate.FieldNo(Html));
            resourceType::Css:
                exit(PosWebTemplate.FieldNo(Css));
            resourceType::Js:
                exit(PosWebTemplate.FieldNo(Javascript));
        end;
    end;

    procedure HandleTemplateEvent(pCtrlID: Text; pServiceName: Text; pMethodName: Text; pParamsJson: Text; pRest: Text)
    var
        j: JsonObject;
        data: Text;
        pProfileID: Text;
        pTemplateID: Text;
    begin
        pProfileID := SelectStr(1, pRest);
        pTemplateID := SelectStr(2, pRest);

        data := DoWebApiCall(pCtrlID, pTemplateID, pServiceName, pMethodName, pParamsJson);

        j.Add('ctrlId', pCtrlID);
        j.Add('tmplId', pTemplateID);
        j.Add('serviceName', pServiceName);
        j.Add('methodName', pMethodName);
        j.Add('paramsJson', pParamsJson);
        j.Add('profileId', pProfileID);
        j.Add('data', data);

        _POSCtrl.PostEvent('RUNCOMMAND', '_SET_TMPL_API_CB', Format(j), '');
    end;

    procedure DoWebApiCall(ctrlID: Text; tmplID: Text; serviceName: Text; methodName: Text; paramsJson: Text) resultText: Text
    var
        wsMETHOD: Codeunit "LSC Web Service Method";
        addWebSessionID: Boolean;
        WITHSESSIONIDSUFFIX: Label '_WithSessionID', Locked = True; // legacy

        webApiMethod: Boolean;
        parameters: JsonObject;

        k, v : Text;
        i: Integer;
        jt: JsonToken;

        ErrorInf: ErrorInfo;
        handled: Boolean;

        ErrTitleMsg: Label 'Web Template Request Error';
        ErrDetailCaption: Label 'Web Template Request was not handled by LocalRequest. When trying to connect to a web server (defined in Web Service Setup / Distribution Location) as a fallback, the connection failed (url or username/password). See POS Debug Log for more information.';
    begin
        // Prepare ErrorInfo, in case it's thrown later:
        ErrorInf.Title(ErrTitleMsg);
        ErrorInf.DetailedMessage(ErrDetailCaption);
        // ErrorInf.Collectible(true);

        LogWsInfo(StrSubstNo('Web Template Request: [%1]/[%2]/[%3]/[%4]', ctrlID, tmplID, serviceName, methodName), ErrorInf);
        _POSCtrl.OnLocalRequest(ctrlID, tmplID, serviceName, methodName, paramsJson, resultText, handled);

        if handled then
            exit;

        LogWsInfo(StrSubstNo('Web Template Request not handled, will try to send web request to: [%1]', _wsURL), ErrorInf);

        if _WSConnection.StatusEnum <> 1 then begin // c.StatusEnum::Connected
            if not _WSConnection.Connect(
               _wsURL, // m_webapiconnection,
               3000,
               _WSUserName,
               _WSPwd,
               _WSDomain
           ) then
                ThrowWsError('Error connecting to WebService - ' + _WSConnection.LastError, ErrorInf);
        end;

        if methodName = '' then
            ThrowWsError('No method was provided', ErrorInf);

        _WSConnection.ServiceRef(_HttpWrapper);

        // if not _HttpWrapper.GetType(serviceName) then // webApiType
        //     Error('Webservice %1 not found', serviceName);
        addWebSessionID := false;
        if true in [
            methodName.ToUpper() = UpperCase('RetailHierarchyGet'),
            methodName.StartsWith(UpperCase('ItemGet'))
        ] then
            methodName += WITHSESSIONIDSUFFIX;
        // TODO: webApiMethod was previously validated:
        webApiMethod := methodName <> ''; // webApiMethod := webApiType.GetMethod(methodName, BindingFlags.IgnoreCase | BindingFlags.Instance | BindingFlags.Public);
        if not webApiMethod then begin
            if methodName.ToUpper().EndsWith(UpperCase(WITHSESSIONIDSUFFIX)) then begin //Revert to OLD (check if without session id function exists.)
                addWebSessionID := true;
                methodName := methodName.Substring(1, StrLen(methodName) - 14);
                // webApiMethod := webApiType.GetMethod(methodName, BindingFlags.IgnoreCase | BindingFlags.Instance | BindingFlags.Public);
            end;
            if not webApiMethod then
                ThrowWsError(methodName + ' not found in webservice ' + serviceName, ErrorInf);
        end else
            if methodName.ToUpper().EndsWith(UpperCase(WITHSESSIONIDSUFFIX)) then
                addWebSessionID := true;
        //    parameters := webApiMethod.GetParameters(); //With Session ID
        wsMETHOD.ServiceName := serviceName;
        wsMETHOD.MethodName := methodName;

        if parameters.ReadFrom(paramsJson) then begin
            // Legacy: WebSession and Terminal passed in last parameter:
            if addWebSessionID then begin
                wsMETHOD.SetArgumentCount(parameters.Keys.Count + 1);
                wsMETHOD.SetStringArg(
                    StrSubstNo('{ "Terminal": "%1", "WebSession": "%2", "ResourcePath": "" }', _PosSession.TerminalNo, SessionId),
                    parameters.Keys.Count,
                    'metadata'
                );
            end else
                wsMETHOD.SetArgumentCount(parameters.Keys.Count);
            i := 0;
            foreach k in parameters.Keys do begin
                parameters.Get(k, jt);
                v := jt.AsValue.AsText;
                k := (CopyStr(k, 1, 1)).ToLower() + CopyStr(k, 2); // first letter is lowercase in soap
                wsMETHOD.SetStringArg(v, i, k);
                i += 1;
            end;
        end;

        if not wsMETHOD.InvokeMethod(_WSConnection) then
            ThrowWsError(wsMETHOD.LastError, ErrorInf);
        exit(wsMETHOD.GetLastReturnValue);
    end;

    local procedure LogWsInfo(Msg: Text; var ErrorInf: ErrorInfo)
    begin
        ErrorInf.DetailedMessage(ErrorInf.DetailedMessage + '\' + Msg);
        _POSCtrl.LogDebug(Msg);
    end;

    local procedure ThrowWsError(Msg: Text; var ErrorInf: ErrorInfo)
    begin
        LogWsInfo(StrSubstNo('Web Template WS error for [%1][%2] took [%3]ms: [%3]',
            _HttpWrapper.GetFullUserName,
            _HttpWrapper.GetAuthType,
            _HttpWrapper.TimeDuration,
            _HttpWrapper.ErrorText
        ), ErrorInf);
        LogWsInfo(Msg, ErrorInf);
        Error(ErrorInf);
    end;

    internal procedure AddWebTemplateImage(actualImgCode: Code[20]; imgID: Code[20]): Text
    var
        oldCode: Code[20];
    begin
        if actualImgCode = '' then begin
            if imgID = '' then
                exit('');
            if not _PendingTemplateImageLinks.ContainsKey(imgID) then begin
                if _SentTemplateImageLinks.ContainsKey(imgID) then
                    _PendingTemplateImageLinks.Add(imgID, ''); // remove if already sent
            end else
                _PendingTemplateImageLinks.Set(imgID, '');
            exit('');
        end;
        if imgID = '' then
            imgID := actualImgCode;
        if not _PendingTemplateImageLinks.ContainsKey(imgID) then begin
            if _SentTemplateImageLinks.ContainsKey(imgID) then begin
                oldCode := _SentTemplateImageLinks.Get(imgID);
                if oldCode = actualImgCode then
                    exit(imgID);
            end;
            _PendingTemplateImageLinks.Add(imgID, actualImgCode)
        end else
            _PendingTemplateImageLinks.Set(imgID, actualImgCode);
        exit(imgID);
    end;

    procedure AddWebTemplateImage(recID: RecordId; imgID: Code[20]; linkType: Enum "LSC Retail Image Link Type"): Text
    var
        PosImgUtils: Codeunit "LSC POS Image Utils";
    begin
        // Internal, public access should be through POSSession
        exit(AddWebTemplateImage(PosImgUtils.GetImgCode(recID, linkType), imgID));
    end;

    procedure AddWebTemplateImages(recID: RecordId; imgID: Code[20]; linkType: Enum "LSC Retail Image Link Type") codes: List of [Text]
    var
        PosImgUtils: Codeunit "LSC POS Image Utils";
        actualImgCode: Code[20];
        actualImgCodes: List of [Code[20]];
        newImgId: Text;
        i: Integer;
    begin
        // Internal, public access should be through POSSession
        actualImgCodes := PosImgUtils.GetImgCodes(recID, linkType);
        foreach actualImgCode in actualImgCodes do begin
            if imgID = '' then
                newImgId := actualImgCode
            else
                newImgId := StrSubstNo('%1_%2', imgID, i); // 20 chars + index
            codes.Add(AddWebTemplateImage(actualImgCode, newImgId));
            i += 1;
        end;
    end;

    procedure GetPendingWebTemplateImageLinks() d: Dictionary of [Text, Code[20]]
    begin
        d := _PendingTemplateImageLinks;
    end;

    procedure ClearPendingWebTemplateImageLinks()
    var
        k, v : Text;
    begin
        foreach k in _PendingTemplateImageLinks.Keys do begin
            v := _PendingTemplateImageLinks.Get(k);
            if v <> '' then begin
                if not _SentTemplateImageLinks.ContainsKey(k) then
                    _SentTemplateImageLinks.Add(k, v)
                else
                    _SentTemplateImageLinks.Set(k, v);
            end else
                if _SentTemplateImageLinks.ContainsKey(k) then
                    _SentTemplateImageLinks.Remove(k);
        end;
        Clear(_PendingTemplateImageLinks);
    end;

    procedure ClearImageCache(shouldResend: Boolean) dict: Dictionary of [Text, Text]
    var
        k: Text;
    begin
        if shouldResend then
            foreach k in _SentTemplateImageLinks.Keys do
                dict.Add(k, _SentTemplateImageLinks.Get(k));
        Clear(_SentTemplateImageLinks);
    end;

    procedure SetWsInfo()
    var
        distributionLine: Record "LSC Distribution Location";
        WebServiceSetup: Record "LSC Web Service Setup";
        wsAuthType: Enum "LSC Http AuthType";
        emptyInt: Integer;
        emptyTxt, wsUrl, wsUserName, wsDomain : Text;
        wsPwd: SecretText;
    begin
        _POSCtrl.LogDebug(StrSubstNo('SetWsInfo: Store=%1, Terminal=%2', _PosSession.StoreNo, _PosSession.TerminalNo));
        wsUrl := GetUrl(ClientType::SOAP, CompanyName, ObjectType::Codeunit, Codeunit::"LSC Web Services");

        if distributionLine.Get(_PosSession.TerminalNo()) then begin
            if distributionLine."Extended Web Service URI" <> '' then
                wsUrl := distributionLine."Extended Web Service URI";
            wsUserName := distributionLine."Web Service User Name";
            wsPwd := distributionLine."Web Service Password";
            wsDomain := distributionLine."Web Service Domain";
            wsAuthType := distributionLine."Web Service AuthType";
        end else
            if distributionLine.Get(_PosSession.StoreNo()) then begin
                if distributionLine."Extended Web Service URI" <> '' then
                    wsUrl := distributionLine."Extended Web Service URI";
                wsUserName := distributionLine."Web Service User Name";
                wsPwd := distributionLine."Web Service Password";
                wsDomain := distributionLine."Web Service Domain";
                wsAuthType := distributionLine."Web Service AuthType";
            end else
                if WebServiceSetup.Get() then begin
                    if WebServiceSetup."Extended Web Service URI" <> '' then
                        wsUrl := WebServiceSetup."Extended Web Service URI";
                    wsUserName := WebServiceSetup.Username;
                    wsPwd := WebServiceSetup.Password;
                    wsDomain := WebServiceSetup.Domain;
                    wsAuthType := WebServiceSetup."Http AuthType";
                end;

        if wsUserName = '' then begin
            if WebServiceSetup.Get() then begin
                wsUserName := WebServiceSetup.Username;
                wsPwd := WebServiceSetup.Password;
                wsDomain := WebServiceSetup.Domain;
                wsAuthType := WebServiceSetup."Http AuthType";
            end;
        end;

        _POSCtrl.LogDebug(StrSubstNo('SetWsCredentials: %1, %2, %3, %4, %5', wsUrl, wsUserName, '????', wsDomain, Format(wsAuthType)));
        if wsAuthType = wsAuthType::S2S then
            wsDomain := _HttpUtils.GetDomainFromAuthType(wsAuthType);
        SetWsCredentials(wsUrl, wsUserName, wsPwd, wsDomain);

        _POSCtrl.LogDebug(StrSubstNo('SetWsInfo: %1, %2, %3, %4, %5, %6', '', '', emptyInt, emptyTxt, emptyInt, wsUrl));
        _POSCtrl.OnBeforeSetWSInfo(emptyTxt, emptyTxt, emptyTxt, emptyInt, emptyTxt, emptyInt, wsUrl);

        _wsURL := wsURL.Replace('RetailWebServices', 'RetailWebAPI'); // from .NET
    end;

    procedure SetWsCredentials(wsUrl: Text; wsUserName: Text; wsPwd: SecretText; wsDomain: Text)
    var
        wsPwdTxt: Text;
    begin
        _POSCtrl.OnBeforeSetWsCredentials(wsUrl, wsUserName, wsPwdTxt, wsDomain);
        if wsPwdTxt <> '' then
            wsPwd := wsPwdTxt; // overwrite
        _wsUserName := wsUserName;
        _wsPwd := wsPwd;
        _wsDomain := wsDomain;
    end;

    procedure TestsOnly_GetWsInfo(var wsURL: Text)
    begin
        wsURL := _wsURL;
    end;

    procedure CopyFromWebTemplate(ToWebTemplate: Record "LSC POS Web Template")
    var
        FromWebTemplate: Record "LSC POS Web Template";
        PosWebTemplateList: Page "LSC POS Web Template List";
        HtmlText, CssText, JavascriptText : Text;
        OutStr: OutStream;
    begin
        FromWebTemplate.FilterGroup(2);
        FromWebTemplate.SetFilter(ID, '<>%1', ToWebTemplate.ID);
        FromWebTemplate.FilterGroup(0);
        PosWebTemplateList.SetTableView(FromWebTemplate);
        PosWebTemplateList.SetRecord(FromWebTemplate);
        PosWebTemplateList.LookupMode(true);
        PosWebTemplateList.Editable(false);
        if PosWebTemplateList.RunModal() <> Action::LookupOK then
            exit;
        PosWebTemplateList.GetRecord(FromWebTemplate);

        HtmlText := GetTemplateSourceCode(FromWebTemplate.ID, "LSC POS Web Template Resource"::Html);
        CssText := GetTemplateSourceCode(FromWebTemplate.ID, "LSC POS Web Template Resource"::Css);
        JavascriptText := GetTemplateSourceCode(FromWebTemplate.ID, "LSC POS Web Template Resource"::Js);

        ToWebTemplate.Html.CreateOutStream(OutStr, TextEncoding::UTF8);
        OutStr.Write(HtmlText);

        ToWebTemplate."Css".CreateOutStream(OutStr, TextEncoding::UTF8);
        OutStr.Write(CssText);

        ToWebTemplate.Javascript.CreateOutStream(OutStr, TextEncoding::UTF8);
        OutStr.Write(JavascriptText);

        ToWebTemplate.Modify();
    end;

    procedure InitializeBaseWebTemplates()
    var
        IBwt: Interface "LSC IBaseWebTemplates 2";
        i: Integer;
        BaseTemplateIds: List of [Text];
        BaseTemplateId: Text;
        POSWebTemplate: Record "LSC POS Web Template";
    begin
        foreach i in "LSC Base Web Templates".Ordinals() do begin
            IBwt := "LSC Base Web Templates".FromInteger(i);
            BaseTemplateIds := IBwt.GetBaseTemplateIds();
            foreach BaseTemplateId in BaseTemplateIds do begin
                POSWebTemplate.SetRange(ID, BaseTemplateId);
                if POSWebTemplate.IsEmpty then begin
                    POSWebTemplate.Init();
                    POSWebTemplate.ID := BaseTemplateId;
                    POSWebTemplate.Insert();
                end;
            end;
        end;
    end;

    /// <summary> Note: TempBlob must be in-memory for the Instream to keep its content outside of the function's scope (https://github.com/microsoft/AL/issues/7172) </summary>
    local procedure GetResourceInstream(var TempBlob: Codeunit "Temp Blob"; var InStr: Instream; PosWebTemplate: Record "LSC POS Web Template"; ResourceType: Enum "LSC POS Web Template Resource") HasValue: Boolean
    var
        BlobUtils: Codeunit "LSC Blob Utils";
    begin
        Clear(InStr);
        Clear(TempBlob);
        if IsBaseTemplate(PosWebTemplate.ID) then
            BlobUtils.WriteToBlob(GetTemplateSourceCode(PosWebTemplate.ID, ResourceType), TempBlob, TextEncoding::UTF8)
        else
            TempBlob.FromRecord(PosWebTemplate, FieldNoFromResourceType(ResourceType));
        TempBlob.CreateInStream(InStr, TextEncoding::UTF8);
        HasValue := TempBlob.HasValue();
    end;

    procedure ImportFile(PosWebTemplate: Record "LSC POS Web Template"; ResourceType: Enum "LSC POS Web Template Resource")
    var
        TempBlob: Codeunit "Temp Blob";
        InStr: InStream;
        OutStr: OutStream;
        ResourceFieldRef: FieldRef;
        FileName: Text;
        TxtOverwrite: Label 'Overwrite existing content?';
    begin
        // Rec.CalcFields(Html, CSS, Javascript);
        if not File.UploadIntoStream('', '', '', FileName, InStr) then
            exit;

        ResourceFieldRef := PosWebTemplate.RecordId.GetRecord().Field(FieldNoFromResourceType(ResourceType));
        TempBlob.FromRecord(PosWebTemplate, FieldNoFromResourceType(ResourceType));
        if TempBlob.HasValue() then
            if not Confirm(TxtOverwrite) then
                exit;

        TempBlob.CreateOutStream(OutStr, TextEncoding::UTF8);
        CopyStream(OutStr, InStr);
        TempBlob.ToFieldRef(ResourceFieldRef);
        ResourceFieldRef.Record().Modify(true);
    end;

    procedure ExportFile(PosWebTemplate: Record "LSC POS Web Template"; ResourceType: Enum "LSC POS Web Template Resource")
    var
        TempBlob: Codeunit "Temp Blob";
        InStr: Instream;
        FileName: Text;
    begin
        FileName := StrSubstNo('%1.%2', PosWebTemplate.ID, Format(ResourceType).ToLower());
        if GetResourceInstream(TempBlob, InStr, PosWebTemplate, ResourceType) then
            File.DownloadFromStream(InStr, '', '', '', FileName);
    end;

    procedure DownloadResourcesAsZip(PosWebTemplate: Record "LSC POS Web Template")
    var
        Zip: Codeunit "Data Compression";
        TempBlob: Codeunit "Temp Blob";
        ResourceType: Enum "LSC POS Web Template Resource";
        InStr: InStream;
        OutStr: OutStream;
        FileName: Text;
    begin
        Zip.CreateZipArchive();
        foreach ResourceType in ResourceType.Ordinals() do
            if GetResourceInstream(TempBlob, InStr, PosWebTemplate, ResourceType) then
                Zip.AddEntry(InStr, StrSubstNo('%1.%2', PosWebTemplate.ID, Format(ResourceType).ToLower()));
        FileName := StrSubstNo('%1.zip', PosWebTemplate.ID);
        TempBlob.CreateOutStream(OutStr);
        Zip.SaveZipArchive(OutStr);
        TempBlob.CreateInStream(InStr);
        File.DownloadFromStream(InStr, '', '', '', FileName);
    end;
}